# coding:utf-8
from __future__ import annotations
import traceback
import contextlib
from collections.abc import Callable, Iterator
import sys
import functools
import logging
from typing import List, Tuple
import astroid
from astroid import nodes
from .codebase import CodebaseParser, MANAGER
from .ast_walker import ASTWalker
from .moduleitem import ModuleItem
from . import objtypes
from .define import CLASS_INIT_METHOD
from ..analysis.moduleloader import ModuleLoader
from ..apis import memberkeys
from . import node_utils
from .node_scope import ScopeFinder

if sys.version_info >= (3, 8):
    from typing import Protocol
else:
    from typing_extensions import Protocol


class GetAstProtocol(Protocol):
    def __call__(
        self, filepath: str, modname: str, data: str | None = None
    ) -> nodes.Module:
        ...


logger = logging.getLogger('ide.codefile.parser')


class CodefileParser(CodebaseParser):

    def __init__(self, python_path_analyzer):
        super().__init__(python_path_analyzer)
        self._python_path_analyzer = self.analyzer
        self._fileitem = None
        self._childs: List[Tuple[str, str, nodes.NodeNG]] = []
        self._module = None
        self._finished = True
        self._use_cache = True

    @property
    def use_cache(self):
        return self._use_cache

    @use_cache.setter
    def use_cache(self, val):
        self._use_cache = val

    @property
    def modpath(self):
        return self._fileitem.modname

    @property
    def finished(self):
        return self._finished

    @property
    def childs(self):
        return self._childs

    def get_doc(self):
        return node_utils.get_node_doc(self._module)

    def get_ast(
        self, filepath: str, modname: str, source=True, data: str | None = None
    ) -> nodes.Module | None:
        """
        Return an ast(roid) representation of a module or a string.
        :param filepath: path to checked file.
        :param str modname: The name of the module to be checked.
        :param str data: optional contents of the checked file.
        :returns: the AST
        :rtype: astroid.nodes.Module
        :raises AstroidBuildingError: Whenever we encounter an unexpected exception
        """
        try:
            if data is None:
                return self.ast_from_file(filepath, modname, source=source, use_cache=self._use_cache)
            return astroid.builder.AstroidBuilder(MANAGER).string_build(
                data, modname, filepath
            )
        except astroid.AstroidSyntaxError as ex:
            line = getattr(ex.error, "lineno", None)
            if line is None:
                line = 0
            logger.error('parse file %s syntax-error:%s', filepath, str(ex))
        except astroid.AstroidBuildingError as ex:
            logger.error("parse file %s error:%s", filepath, ex)
        except Exception as ex:
            traceback.print_exc()
            # We raise BuildingError here as this is essentially an astroid issue
            # Creating an issue template and adding the 'astroid-error' message is handled
            # by caller: _check_files
            raise astroid.AstroidBuildingError(
                "Building error when trying to create ast representation of module '{modname}'",
                modname=modname,
            ) from ex
        return None

    def parse_single_file(self, name: str, filepath: str, modname: str) -> None:
        self.parse_single_file_item(ModuleItem(name, filepath, modname))
        return self._module

    def parse_single_file_item(self, file: ModuleItem) -> None:
        """
        Check single file item.
        The arguments are the same that are documented in _check_files
        initialize() should be called before calling this method
        """
        self._fileitem = file
        with self._astroid_module_visitor() as parse_astroid_module:
            self._parse_file(self.get_ast, parse_astroid_module, file)

    def prepare_visitors(self):
        self._visitors.append(self.visit_functiondef)
        self._visitors.append(self.visit_classdef)
        self._visitors.append(self.visit_assign)
        self._visitors.append(self.visit_annassign)
        self._visitors.append(self.visit_import)
        self._visitors.append(self.visit_importfrom)
        self._visitors.append(self.visit_if)
        self._visitors.append(self.visit_tryexcept)
        return self._visitors

    def expand_mod_path(self, names: list):
        return ".".join([self.modpath] + names)

    def visit_functiondef(self, node):
        if ScopeFinder.is_class_range(node):
            parent_class_node = ScopeFinder.get_parent_class_node(node)
            func_mod_path = self.expand_mod_path([parent_class_node.name, node.name])
            # 遍历类初始化init方法体,作为类成员属性
            if node.name == CLASS_INIT_METHOD:
                for child in node.body:
                    self.visit_child(child)
            # 成员方法作为子节点信息保存
            self._childs.append((func_mod_path, objtypes.FUNCTION_DEF, node))
        elif ScopeFinder.is_module_range(node):
            func_mod_path = self.expand_mod_path([node.name])
            self._childs.append((func_mod_path, objtypes.FUNCTION_DEF, node))

    @staticmethod
    def is_support_mro_class(node):
        for base in node.bases:
            if not isinstance(base, (nodes.Name, nodes.Attribute)):
                return False
        return True

    def _check_astroid_module(
        self,
        node: nodes.Module,
        walker: ASTWalker,
        #  rawcheckers: list[checkers.BaseRawFileChecker],
        # tokencheckers: list[checkers.BaseTokenChecker],
    ) -> bool | None:
        """
        Check given AST node with given walker and checkers.
        :param astroid.nodes.Module node: AST node of the module to check
        :param pylint.utils.ast_walker.ASTWalker walker: AST walker
        :param list rawcheckers: List of token checkers to use
        :param list tokencheckers: List of raw checkers to use
        :returns: True if the module was checked, False if ignored,
        None if the module contents could not be parsed
        """
        if not node.pure_python:
            self.add_message("raw-checker-failed", args=node.name)
        else:
            pass

        # generate events to astroid checkers
        walker.walk(node)
        return True

    def visit_import(self, node):
        if not ScopeFinder.is_module_range(node):
            return
        for alias in node.alias:
            name = node_utils.get_alias_name(alias)
            modname = alias.name
            membersfile, memberlistfile = self.check_refmod_analyzed(
                modname, self._fileitem.filepath, raise_exception=False)
            # 导入模块存在但是未完成解析,设置未完成标志,等待导入模块解析完成后再次生成新数据
            if membersfile is None:
                self._finished = False
                break
            # 导入模块未找到
            if membersfile == '':
                break
            import_mod_path = self.expand_mod_path([name])
            mdloader = ModuleLoader(modname, membersfile, memberlistfile)
            mdloader.load()
            module = mdloader.build_simple_node(mdloader.data)
            self._childs.append((import_mod_path, objtypes.MODULE, module))

    def visit_importfrom(self, node):
        if not ScopeFinder.is_module_range(node):
            return
        mod_name = self.get_fromimport_modname(node, self._fileitem.filepath)
        if mod_name is None:
            return
        membersfile, memberlistfile = self.check_refmod_analyzed(
            mod_name, self._fileitem.filepath, raise_exception=False)
        # 导入模块存在但是未完成解析,设置未完成标志,等待导入模块解析完成后再次生成新数据
        if membersfile is None:
            self._finished = False
            return
        # 导入模块未找到
        if membersfile == '':
            return
        mdloader = ModuleLoader(mod_name, membersfile, memberlistfile)
        mdloader.load()
        module = mdloader.build_simple_node(mdloader.data)
        for alias in node.alias:
            name = alias.name
            if name == '*':
                childs = mdloader.data[memberkeys.CHILD_KEY_NAME]
                for child in childs:
                    data = child
                    child_mod_name = data[memberkeys.MODNAME_KEY_NAME]
                    if len(child_mod_name.split(".")) > len(mod_name.split(".")) + 1:
                        continue
                    attr_mod_path = self.expand_mod_path(
                        [data[memberkeys.NAME_KEY_NAME]])
                    node = mdloader.build_simple_node(data, module)
                    if isinstance(node, nodes.ClassDef):
                        mro = self.get_mro(node)
                        node.mros = mro
                    self._childs.append(
                        (attr_mod_path, data[memberkeys.OBJTYPE_KEY_NAME], node))
            else:
                data = mdloader.find_child(name)
                if data is None:
                    logger.error(
                        'could not find name %s in module %s', name, mod_name)
                    continue
                name = node_utils.get_alias_name(alias)
                attr_mod_path = self.expand_mod_path([name])
                node = mdloader.build_simple_node(data, module)
                if isinstance(node, nodes.ClassDef):
                    mro = self.get_mro(node)
                    node.mros = mro
                self._childs.append(
                    (attr_mod_path, data[memberkeys.OBJTYPE_KEY_NAME], node))

    def visit_assign(self, node):
        targets = node.targets
        for target in targets:
            # 连等表达式
            if isinstance(target, nodes.Tuple):
                elts = target.elts
                for elt in elts:
                    if isinstance(elt, nodes.AssignName):
                        name = elt.name
                        if isinstance(node.value, nodes.Tuple):
                            if ScopeFinder.is_module_range(node):
                                attr_mod_path = self.expand_mod_path([name])
                                self._childs.append(
                                    (attr_mod_path, objtypes.MODULE_ATTRIBUTE, node))
                            elif ScopeFinder.is_class_range(node):
                                parent_class_node = ScopeFinder.get_parent_class_node(node)
                                classattr_mod_path = self.expand_mod_path(
                                    [parent_class_node.name, name])
                                self._childs.append(
                                    (classattr_mod_path, objtypes.CLASS_ATTRIBUTE, node))

            elif isinstance(target, nodes.AssignName):
                name = target.name
                if ScopeFinder.is_module_range(node):
                    attr_mod_path = self.expand_mod_path([name])
                    self._childs.append(
                        (attr_mod_path, objtypes.MODULE_ATTRIBUTE, node))
                elif ScopeFinder.is_class_range(node):
                    parent_class_node = ScopeFinder.get_parent_class_node(node)
                    classattr_mod_path = self.expand_mod_path(
                        [parent_class_node.name, name])
                    self._childs.append(
                        (classattr_mod_path, objtypes.CLASS_ATTRIBUTE, node))
            elif isinstance(target, nodes.AssignAttr):
                if not (isinstance(node.parent, nodes.FunctionDef) and node.parent.name == CLASS_INIT_METHOD):
                    return
                # 如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
                if isinstance(target.expr, nodes.Name) and target.expr.name == "self" \
                        and isinstance(node.parent.parent, nodes.ClassDef):
                    name = target.attrname
                    classattr_mod_path = self.expand_mod_path(
                        [node.parent.parent.name, name])
                    self._childs.append(
                        (classattr_mod_path, objtypes.OBJECT_PROPERTY, target))

    @contextlib.contextmanager
    def _astroid_module_visitor(
        self,
    ) -> Iterator[Callable[[nodes.Module], bool | None]]:
        """
        Context manager for checking ASTs.
        The value in the context is callable accepting AST as its only argument.
        """

        _visitors = self.prepare_visitors()
        if not _visitors:
            raise RuntimeError('empty node visitors')
        # notify global begin
        for visitor in _visitors:
            self.walker.add_visitor(visitor)

        yield functools.partial(
            self._check_astroid_module,
            walker=self.walker
        )

    def visit_classdef(self, node):
        if not ScopeFinder.is_module_range(node):
            return
        if self.is_support_mro_class(node):
            mro = self.get_mro(node)
            node.mros = mro
        else:
            node.mros = []
        class_mod_path = self.expand_mod_path([node.name])
        self._childs.append((class_mod_path, objtypes.CLASS_DEF, node))

    def _parse_file(
        self,
        get_ast: GetAstProtocol,
        check_astroid_module: Callable[[nodes.Module], bool | None],
        file: ModuleItem,
    ) -> None:
        try:
            # get the module representation
            ast_node = get_ast(file.filepath, file.name)
        except Exception as ex:
            logger.error('parse file %s modname %s ast error:%s',
                         file.filepath, file.name, str(ex))
            return
        self._module = ast_node
        self._childs = []
        if ast_node is None:
            return

        self._ignore_file = False
        check_astroid_module(ast_node)

    def visit_tryexcept(self, node):
        if not ScopeFinder.is_module_range(node):
            return
        for orelse in node.orelse:
            self.visit_child(orelse)
        for handler in node.handlers:
            self.visit_child(handler)

    def visit_if(self, node):
        if node_utils.is_main_statement(node) or not ScopeFinder.is_module_range(node):
            return

        for orelse in node.orelse:
            if isinstance(orelse, nodes.If):
                for child in orelse.body:
                    self.visit_child(child)
            else:
                self.visit_child(orelse)

    def visit_annassign(self, node):
        target = node.target
        if isinstance(target, nodes.AssignName):
            name = target.name
            if ScopeFinder.is_module_range(node):
                attr_mod_path = self.expand_mod_path([name])
                self._childs.append(
                    (attr_mod_path, objtypes.MODULE_ATTRIBUTE, node))
            elif ScopeFinder.is_class_range(node):
                parent_class_node = ScopeFinder.get_parent_class_node(node)
                classattr_mod_path = self.expand_mod_path(
                    [parent_class_node.name, name])
                self._childs.append(
                    (classattr_mod_path, objtypes.CLASS_ATTRIBUTE, node))

        elif isinstance(target, nodes.AssignAttr):
            pnode = node.parent
            if not (
                isinstance(
                    pnode, nodes.FunctionDef) and pnode.name == CLASS_INIT_METHOD
            ):
                return
            # 如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
            if isinstance(target.expr, nodes.Name) and target.expr.name == "self" \
                    and isinstance(pnode.parent, nodes.ClassDef):
                name = target.attrname
                classattr_mod_path = self.expand_mod_path(
                    [pnode.parent.name, name])
                self._childs.append(
                    (classattr_mod_path, objtypes.CLASS_ATTRIBUTE, target))
