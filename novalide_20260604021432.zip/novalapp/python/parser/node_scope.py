import logging
from typing import List
from astroid import nodes
import astroid
from .definition import Definition
from . import node_utils
from .define import SUPER_CALL_METHOD_NAME, CLASS_INIT_METHOD, SELF_ARG_NAME, PROPERTY_METHOD_NAME
from .exceptions import OutofPythonPathError
from .node_utils import get_node_doc
from ... import get_app
log = logging.getLogger(__name__)


class ScopeFinder:
    def __init__(self, scope):
        self._scope = scope
        self._module = self._scope.root()

    @staticmethod
    def locate_in_scope(scope, line):
        if isinstance(scope, nodes.Module):
            return True
        if scope.lineno <= line <= scope.end_lineno:
            return True
        return False

    @staticmethod
    def is_scope(scope):
        '''
        常量节点有body属性,但是不是scope
        '''
        return hasattr(scope, 'body') and not isinstance(scope, nodes.Const)

    @staticmethod
    def is_class_funcdef_scope(scope):
        '''
        是否class/function scope
        '''
        return isinstance(scope, (nodes.ClassDef, nodes.FunctionDef))

    @classmethod
    def get_class_scope(cls, node):
        return cls.get_parent_node_by_classtype(
            node,
            [nodes.ClassDef]
        )

    @classmethod
    def get_function_scope(cls, node):
        return cls.get_parent_node_by_classtype(
            node,
            [nodes.FunctionDef]
        )

    @classmethod
    def get_parent_node_by_nodeclass(cls, node, node_class_type):
        return cls.get_parent_node_by_classtype(
            node,
            [node_class_type]
        )

    def get_definitions(self, node, code_parser):
        definitions = []
        try:
            for infered in node.infer():
                # 找到节点定义,但是未能推断出类型
                if infered == astroid.Uninferable:
                    datas = self.find_definitions(node, code_parser)
                    definitions.extend(datas)
                elif isinstance(infered, astroid.UnboundMethod) and infered.name == CLASS_INIT_METHOD:
                    datas = self.find_definitions(node, code_parser)
                    definitions.extend(datas)
                # 推断的节点类型非法
                elif isinstance(infered, nodes.Module) and infered.file == '<?>':
                    raise astroid.InferenceError(
                        "unknown infered module %s file %s" % (infered.name, infered.file))
                else:
                    # 成功推断出节点类型
                    infered_module = infered.root()
                    if isinstance(infered_module, nodes.Module):
                        codepath = infered_module.file
                        lineno, col_offset = node_utils.get_node_line_col(
                            infered)
                        definitions.append(
                            Definition(
                                lineno,
                                col_offset,
                                codepath,
                                infered.__class__.__name__.lower(),
                                node.as_string(),
                                infered_module.name,
                                get_node_doc(infered)
                            )
                        )
        # 推断节点类型过程中发生错误,比如节点名称定义不存在等
        except (astroid.InferenceError, astroid.AstroidError) as ex:
            log.error(str(ex))
            log.info(
                'find definitions of node:%s of file %s in intellisence data files',
                node,
                self._module.file
            )
            datas = self.find_definitions(node, code_parser)
            definitions.extend(datas)
        except Exception:
            log.exception('node refer exception:')
        return definitions

    def find_definitions(self, node, code_parser):
        if (
            isinstance(node, nodes.Attribute) and isinstance(
                node.expr, nodes.Call)
        ) and (
            isinstance(
                node.expr.func, nodes.Name) and node.expr.func.name == SUPER_CALL_METHOD_NAME
        ):
            node_scope = self.get_class_scope(node)
            if isinstance(node_scope, nodes.ClassDef):
                return self.find_base_definitions(node_scope, node.attrname, code_parser)
        elif (
            isinstance(node, nodes.Attribute) and isinstance(
                node.expr, nodes.Name)
        ) and node.expr.name == SELF_ARG_NAME:
            definitions = self.find_import_definitions(node, code_parser)
            if not definitions:
                node_scope = self.get_class_scope(node)
                if isinstance(node_scope, nodes.ClassDef):
                    definitions = self.find_base_definitions(
                        node_scope, node.attrname, code_parser)
            return definitions
        else:
            return self.find_import_definitions(node, code_parser)

    def find_base_definitions(self, class_node, atrrname, code_parser):
        class_file = class_node.root().file
        try:
            class_mod_path = code_parser.analyzer.get_relative_path(
                class_file)
        except OutofPythonPathError:
            return []
        if class_mod_path is None:
            return []
        class_mod_name = code_parser.modname_to_path(
            class_mod_path, class_node.name)
        base_mod_names = get_app().intellisence_mananger.load_module_class_bases(class_mod_name)
        definitions = []
        for base_mod_name in base_mod_names:
            get_app().intellisence_mananger.fin_class_member_definitions(
                base_mod_name, atrrname, definitions)
        return definitions

    @classmethod
    def is_parent_node_classtype(
        cls,
        node,
        parent_node_class: nodes.NodeNG
    ):
        return cls.is_parent_node_classtypes(node, [parent_node_class])

    @staticmethod
    def is_parent_node_classtypes(
        node,
        parent_node_classes: List[nodes.NodeNG]
    ):
        '''
        判断多级父节点是否是某个类型
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if any(isinstance(parent_node, parent_node_class) for parent_node_class in parent_node_classes):
                return True
            parent_node = parent_node.parent
        return False

    def get_import_definitions(self, importnode, alias=None):
        attrname = None
        if isinstance(importnode, nodes.ImportFrom):
            importname = importnode.modname
            if alias is not None:
                attrname = alias.name
        else:
            importname = alias.name
        import_modname = importname
        if attrname:
            defname = import_modname + "." + attrname
        else:
            defname = import_modname
        log.info('find defname %s of module %s definitions', defname, import_modname)
        definitions = get_app().intellisence_mananger.get_definitions(defname)
        return definitions

    @classmethod
    def get_parent_class_node(cls, node):
        return cls.get_parent_node_by_classtype(node, [nodes.ClassDef])

    @staticmethod
    def get_class_method_node(classnode, method_name):
        for childnode in classnode.body:
            if isinstance(childnode, nodes.FunctionDef) and childnode.name == method_name:
                return childnode
        return None

    def find_import_definitions(self, node, code_parser, attrname=None):
        nodestr = node.as_string()
        nodenames = nodestr.split('.')
        importname = nodenames[0]
        if attrname is None:
            attrname = nodenames[1:]
        import_modname = code_parser.find_import_modname(
            self._module, importname)
        if import_modname is not None:
            if attrname:
                defname = import_modname + "." + ".".join(attrname)
            else:
                defname = import_modname
            definitions = get_app().intellisence_mananger.get_definitions(defname)
        else:
            definitions = get_app().intellisence_mananger.get_definitions(nodestr)
        return definitions

    @staticmethod
    def get_class_function_property_node(classnode, method_name):
        '''
        类属性get,set节点,方法名称都一样
        '''
        property_get_node = None
        property_set_node = None
        for childnode in classnode.body:
            if isinstance(childnode, nodes.FunctionDef) and childnode.name == method_name:
                decorators = childnode.decorators
                if decorators is not None:
                    for deco in decorators.nodes:
                        if isinstance(deco, nodes.Name) and deco.name == PROPERTY_METHOD_NAME:
                            property_get_node = childnode
                        elif isinstance(deco, nodes.Attribute) and deco.attrname == "setter":
                            property_set_node = childnode
        return property_get_node, property_set_node

    def find_scope(self, line):
        if not self.locate_in_scope(self._scope, line):
            return None
        for child in self._scope.body:
            if self.locate_in_scope(child, line):
                if self.is_scope(child):
                    found_scope = ScopeFinder(child).find_scope(line)
                    return found_scope
                break
        return self._scope

    @staticmethod
    def get_parent_node_by_classtype(
        node,
        parent_node_classes: List[nodes.NodeNG]
    ):
        '''
        获取是某个类型的父节点
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if any(isinstance(parent_node, parent_node_class) for parent_node_class in parent_node_classes):
                return parent_node
            parent_node = parent_node.parent
        return None

    def find_class_funcdef_scope(self, line):
        locate_scope = self.find_scope(line)
        if self.is_class_funcdef_scope(locate_scope):
            return locate_scope
        parent_scope = self.get_parent_node_by_classtype(
            locate_scope,
            [nodes.ClassDef, nodes.FunctionDef]
        )
        if parent_scope:
            return parent_scope
        return self._module

    @staticmethod
    def get_parent_scope(
        node
    ):
        '''
        获取第一个有body属性的父节点,即范围节点
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None:
                break
            if hasattr(parent_node, 'body'):
                return parent_node
            parent_node = parent_node.parent
        return None

    def find_classdef_scope(self, line):
        locate_scope = self.find_scope(line)
        if isinstance(locate_scope, nodes.ClassDef):
            return locate_scope
        parent_scope = self.get_parent_node_by_classtype(
            locate_scope,
            [nodes.ClassDef]
        )
        if parent_scope:
            return parent_scope
        return None

    @staticmethod
    def get_parent_nodes_by_classtype(
        node,
        parent_node_class: nodes.NodeNG
    ):
        '''
        获取是某个类型的父节点集合
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if isinstance(parent_node, parent_node_class):
                yield parent_node
            parent_node = parent_node.parent

    def find_funcdef_scope(self, line):
        locate_scope = self.find_scope(line)
        if isinstance(locate_scope, nodes.FunctionDef):
            return locate_scope
        parent_scope = self.get_parent_node_by_classtype(
            locate_scope,
            [nodes.FunctionDef]
        )
        if parent_scope:
            return parent_scope
        return None

    @classmethod
    def get_parent_scope_node(cls, node):
        parent_node = cls.get_parent_node_by_classtype(
            node, [nodes.ClassDef, nodes.FunctionDef]
        )
        if parent_node is not None:
            return parent_node
        return node.root()

    @classmethod
    def is_class_range(cls, node):
        return cls.is_parent_node_classtype(node, nodes.ClassDef)

    @classmethod
    def is_module_range(cls, node):
        parent_scope = cls.get_parent_scope_node(node)
        if not isinstance(parent_scope, nodes.Module):
            return False
        if cls.is_parent_node_classtype(node, nodes.If):
            pnode = cls.get_parent_node_by_classtype(node, [nodes.If])
            if node_utils.is_main_statement(pnode):
                return False
        return True
