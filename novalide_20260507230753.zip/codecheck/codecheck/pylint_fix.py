import re
import base64
import os
from astroid import nodes
from novalapp import get_app, _
from novalapp.widgets import simpledialog
from novalapp.lib.pyqt import QMessageBox
from novalapp.project import command as projectcommand
from novalapp.util import fileutils, strutils, utils
from .basefix import BasePythonFixer, fix_code_file_msg
from .sarif_loader import SarifLoader
from .strings import PYLINT_TOOL_NAME, COMMON_PYLINT_MESSAGE_ID
from .codeutils import get_node_range, ImportNodes, FixNode
from . import configkeys


class PylintFixer(BasePythonFixer):
    def __init__(self, ruleid, autofix=False, open_file=True):
        super().__init__(ruleid, PYLINT_TOOL_NAME, autofix, open_file)

    @staticmethod
    def is_node_could_deleted(node):
        pnode = node.parent
        if isinstance(pnode, nodes.If) and node in pnode.orelse and len(pnode.orelse) == 1:
            return False
        body_nodes = (nodes.If, nodes.ExceptHandler, nodes.Try, nodes.ClassDef, nodes.FunctionDef)
        if isinstance(pnode, body_nodes) and node in pnode.body and len(pnode.body) == 1:
            return False
        return True

    @classmethod
    def delete_import_name(cls, node, import_name, textview):
        if not cls.is_node_could_deleted(node):
            utils.get_logger().error("%s node could not be deleted", node.__class__.__name__)
            return False
        for i, (name, asname) in enumerate(node.names):
            if import_name in (name, asname):
                del node.names[i]
                break
        else:
            return False
        if not node.names:
            fixrange = get_node_range(node)
            fixrange.replace_with_text(textview, '')
        else:
            fixrange = get_node_range(node)
            fixrange.replace_with_text(textview, node.as_string())
        return True

# for alias in node.alias:
# if import_name in (alias.name, alias.asname):
# lineno, alias.col_offset)
# for i, char in enumerate(line_text[alias.col_offset:]):
# if char == ",":
# break
# for j, char in enumerate(line_text[0:alias.col_offset][::-1]):
# if char == ",":
# break
# if offstr.find(")") != -1:
# if line_text.strip() == '':

    @classmethod
    def replace_variable_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.Name, nodes.AssignName)) and child.name == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, newname)
            else:
                cls.replace_variable_name_in_scope(
                    textview, child, name, newname)

    @classmethod
    def replace_attribute_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.AssignAttr, nodes.Attribute)) and child.attrname == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, "self." + newname)
            else:
                cls.replace_attribute_name_in_scope(
                    textview, child, name, newname)

    @staticmethod
    def replace_module_name(doc, oldpath, new_module_name):
        ext = strutils.get_file_extension(oldpath, keepdot=True)
        newname = os.path.join(
            fileutils.get_filepath_from_path(oldpath), new_module_name)
        newfilepath = strutils.MakeNameEndInExtension(newname, ext)
        return doc.GetCommandProcessor().Submit(
            projectcommand.ProjectRenameFileCommand(doc, oldpath, newfilepath)
        )


class SarifFixer(PylintFixer):
    '''
    通用sarif格式修复器
    '''

    def __init__(self, ruleid, autofix=False, open_file=True):
        PylintFixer.__init__(self, ruleid, autofix, open_file)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        if self.check_tool.output_format != self.check_tool.JSON_OUTPUT_FORMAT:
            return False
        fixes = msg.fixers
        if not fixes:
            return False
        if len(fixes) > 1 and not self.is_autofix_msg:
            choices = [fixer['description']['text'] for fixer in fixes]
            sel = simpledialog.asklist(
                "Fix code",
                "Please choose one fixer option",
                choices,
                selection=0,
                master=text_ctrl
            )

            if sel == -1:
                return False
        else:
            # sarif自动修复有多个修复选项时默认选第一个作为修复方案
            sel = 0
        fixer = fixes[sel]
        chan = fixer['artifactChanges'][0]
        fixuri = chan['artifactLocation']['uri']
        fixpath = SarifLoader.uri_to_path(fixuri)
        if not fileutils.ComparePath(msg.filepath, fixpath):
            textview = get_app().GotoView(
                fixpath,
                lineNum=msg.line,
                colno=msg.column,
                load_outline=False,
                trace_track=False
            )
            if not textview:
                return False
            text_ctrl = textview.GetCtrl()
        replacements = chan['replacements']
        title = fixer['description']['text']
        if not self.check_input_replacements(title, text_ctrl, replacements):
            return False
        for replacement in replacements:
            if "deletedRegion" in replacement:
                if textview.IsModified() and not self.is_autofix_msg:
                    QMessageBox.critical(text_ctrl, _('Error'), _(
                        'Please save your file before fix warnings'))
                    return False
                deleted_region = replacement["deletedRegion"]
                if 'byteOffset' in deleted_region:
                    base64_text = bytearray(
                        replacement["insertedContent"]['binary'], encoding="ascii")
                    inserted_content = base64.b64decode(base64_text)
                    byte_offset = deleted_region['byteOffset']
                    byte_len = deleted_region['byteLength']
                    newbytes = b''
                    with open(fixpath, "rb") as fp:
                        byte_content = fp.read()
                        newbytes = byte_content[0:byte_offset] + bytearray(
                            inserted_content) + byte_content[byte_offset + byte_len:]
                    with open(fixpath, "wb") as fw:
                        fw.write(newbytes)
                elif 'charOffset' in deleted_region:
                    char_offset = deleted_region['charOffset']
                    char_len = deleted_region['charLength']
                    inserted_content = replacement["insertedContent"]["text"]
                    if char_len == 0:
                        text_ctrl.insert_text(char_offset, inserted_content)
                    else:
                        content = text_ctrl._encodeString(text_ctrl.text())
                        chars = content[char_offset:char_offset + char_len]
                        textview.set_region(char_offset, char_offset + char_len, chars,
                                            inserted_content.split("\n"), selrep=False)
                else:
                    start_line = deleted_region["startLine"] - 1
                    start_column = deleted_region["startColumn"] - 1
                    end_column = deleted_region["endColumn"] - 1
                    end_line = deleted_region["endLine"] - 1
                    inserted_content = replacement["insertedContent"]["text"]
                    if start_line == end_line and start_column == end_column:
                        insert_pos = text_ctrl.position_from_linecol(
                            start_line, start_column)
                        text_ctrl.insert_text(insert_pos, inserted_content)
                    else:
                        head, tail, chars, lines = textview.get_region(
                            start_line, start_column, end_line, end_column)
                        textview.set_region(head, tail, chars,
                                            inserted_content.split("\n"), selrep=False)
            elif "newModule" in replacement:
                replacement_content = replacement["newModule"]
                new_module_name = replacement_content['text']
                oldfilepath = fixpath
                return self.replace_module_name(doc, oldfilepath, new_module_name)

        return True

    def check_input_replacements(
        self,
        title,
        text_ctrl,
        replacements,
        initialvalue=''
    ):
        def parse_arg_text(text):
            res = re.search("'(.*)'", text)
            return res.groups()[0]

        replacement = replacements[0]
        replacement_content = {}
        if "insertedContent" in replacement:
            replacement_content = replacement["insertedContent"]
        elif "newModule" in replacement:
            replacement_content = replacement["newModule"]
        else:
            assert False
        replace_txt = replacement_content.get("text", None)
        if replace_txt is None:
            return True
        res = re.search(r"\$input\((.*)\)", replace_txt)
        if res:
            args_text = res.groups()[0]
            args = re.split(r',\s*', args_text)
            input_prompt_text = parse_arg_text(args[0])
            default_ret = ''
            if len(args) == 3:
                initialvalue = parse_arg_text(args[1])
                default_ret = parse_arg_text(args[2])
            elif len(args) == 2:
                initialvalue = parse_arg_text(args[1])
            if self.is_autofix_msg:
                newname = default_ret
                ok = True if len(newname) > 0 else False
            else:
                ok, newname = simpledialog.askstring(
                    title,
                    input_prompt_text,
                    initialvalue=initialvalue,
                    master=text_ctrl
                )
            if not ok:
                return False
            for replacement in replacements:
                replacement_content = {}
                if "insertedContent" in replacement:
                    replacement_content = replacement["insertedContent"]
                elif "newModule" in replacement:
                    replacement_content = replacement["newModule"]
                else:
                    assert False
                replacement_content["text"] = newname
        return True


class PylintCommonFixer(PylintFixer):
    '''
    修复pylint告警之外的一些常见问题
    '''

    def __init__(self):
        PylintFixer.__init__(self, COMMON_PYLINT_MESSAGE_ID, True, True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        try:
            self.load_module(textview, msg.filepath)
        except RuntimeError as ex:
            utils.get_logger().error(str(ex))
            return False
        ret = False
        if self.fix_module_imports_blank_line(textview, textctrl):
            ret = True
        if utils.profile_get_int(configkeys.REMOVE_PRINT_STATEMENT_KEY, False):
            rem_suc = self.remove_print_statements(textview, textctrl)
            if rem_suc:
                ret = rem_suc
        if utils.profile_get_int(configkeys.CONVERT_TABS_SPACES_KEY, False):
            suc = self.convert_tabs_to_spaces(textview, textctrl)
            if suc:
                ret = suc
        return ret

    def fix_module_imports_blank_line(self, textview, textctrl):
        '''
        清除导入语句之间的空行
        '''
        importutils = ImportNodes(textview.ModuleAnalyzer.Module, textview)
        top_import_nodes = importutils.get_top_import_nodes()
        if not top_import_nodes:
            return False
        start_line = top_import_nodes[0].lineno
        end_line = top_import_nodes[-1].lineno
        del_lines = []
        for i in range(start_line - 1, end_line):
            line_text = textctrl.get_line_text(i)
            if line_text.strip() == '':
                del_lines.append(i)
        if not del_lines:
            return False
        del_lines.sort(reverse=True)
        for del_line_index in del_lines:
            textview.delete_line(del_line_index)
        return True

    def remove_print_statements(self, textview, textctrl):
        line_count = textctrl.get_line_count()
        remove_print_nodes = []
        for i in range(line_count):
            line_text = textctrl.get_line_text(i)
            if line_text.lstrip().startswith('print('):
                node = textview.ModuleAnalyzer.find_line_node(i + 1)
                if node is not None:
                    remove_print_nodes.append(node)
                else:
                    utils.get_logger().error(
                        'could not find ast node on line %d with line text `%s`',
                        i + 1,
                        line_text
                    )
        if not remove_print_nodes:
            return False
        remove_print_nodes.sort(key=lambda x: x.lineno, reverse=True)
        for printnode in remove_print_nodes:
            rm_node = FixNode(printnode, textview)
            rm_node.replace_node_with_text('')
            textview.delete_line(printnode.lineno - 1)
        return True

    def convert_tabs_to_spaces(self, textview, textctrl):
        '''
        检查文本是否包含制表符, 并替换制表符为4个空格
        '''
        chars = textctrl.text()
        tab_count = chars.count("\t")
        if tab_count == 0:
            return False
        newchars = textview.expandtabs(chars)
        textctrl.clearall()
        textctrl.insert_text(0, newchars)
        return True
