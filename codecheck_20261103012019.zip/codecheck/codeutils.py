import re
import enum
import os
import platformdirs
from novalapp import constants, get_app, _
from novalapp.python.symbol.replacesymbol.replacesymbol import ReplaceRange, ReplaceNode
from novalapp.python.parser.importnodes import ImportsVisitor
from .strings import CODECHECK_TOOL_NANE


class FilesregType(enum.Enum):
    INCLUDE_FILES = 1
    EXCLUDE_FILES = 2


class ScanMode(enum.Enum):
    CHANGED_FILES_MODE = 1
    FULL_FILES_MODE = 2
    TIME_SECTION_FILES_MODE = 3


class AfterTimeSpan(enum.Enum):
    AFTER_CREATED_TIME = 1
    AFTER_MODIFIED_TIME = 2


class FixChoice(enum.IntEnum):
    FIX_ALL = 1  # 修复所有可修复规则,包括单点修复规则,自动化修复规则
    FIX_AUTOFIX = 2  # 只修复可自动化修复规则


def get_file_excludes_reg(text):
    regs = text.split("|")
    regstrs = [re.escape(regtext) for regtext in regs]
    regstr = "|".join(regstrs)
    return regstr


def get_codecheck_data_path():
    return os.path.dirname(platformdirs.user_data_path(CODECHECK_TOOL_NANE))


def get_tools_data_path():
    return os.path.join(get_codecheck_data_path(), "tools")


class FixRange(ReplaceRange):
    '''
    替换范围内的文本
    '''


class ReplaceOffsetRange:
    def __init__(self, char_offset, char_len):
        self.char_offset = char_offset
        self.char_len = char_len

    def replace_with_text(self, textview, text):
        text_ctrl = textview.GetCtrl()
        if self.char_len == 0:
            text_ctrl.insert_text(self.char_offset, text)
        else:
            content = text_ctrl._encodeString(text_ctrl.text())
            chars = content[self.char_offset:self.char_offset + self.char_len]
            textview.set_region(self.char_offset, self.char_offset + self.char_len, chars,
                                text.split("\n"), selrep=False)


def get_node_range(node):
    return FixRange.node_range(node)


def get_func_args_range(funcnode):
    args = funcnode.args
    args.lineno = args.args[0].lineno
    args.col_offset = args.args[0].col_offset
    args.end_lineno = args.args[-1].end_lineno
    args.end_col_offset = args.args[-1].end_col_offset
    default_args = args.defaults or [] + args.kw_defaults or []
    if default_args:
        args.end_lineno = default_args[-1].end_lineno
        args.end_col_offset = default_args[-1].end_col_offset
    return get_node_range(args)


def get_add_range(line, col):
    return FixRange.add_range(line, col)


def get_scope_range(scope):
    return FixRange(
        scope.lineno,
        0,
        scope.end_lineno + 1,
        0
    )


DEFAULT_TAB_BLANKS = ' ' * constants.DEFAULT_TAB_WIDTH


class ImportNodes(ImportsVisitor):
    '''导入语句处理'''


def check_git_plugin_installed():
    plugin_name = 'gitcli'
    if get_app().GetPluginManager().GetPlugin(plugin_name) is None:
        raise RuntimeError(
            _('Plugin `%s` must be intalled if you use git tool') % plugin_name
        )


class FixNode(ReplaceNode):
    '''
    替换节点文本
    '''
