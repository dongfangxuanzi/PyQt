import abc
import os
import enum
import re
from astroid import nodes
from novalapp.python.syspath import append_to_syspath, remove_syspath
from novalapp.widgets import simpledialog
from novalapp.lib.pyqt import QMessageBox
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp.python.parser.exceptions import CodeSyntaxError
from novalapp import get_app
from novalapp import constants
from novalapp.util import utils, strutils
from novalapp.settings.setting_wrapper import settings
import astroid
from .codeutils import (
    FixRange,
    get_node_range,
    get_add_range,
    ImportNodes,
    get_func_args_range,
    ReplaceOffsetRange,
    FixChoice
)
from .exceptions import FixfileError, LineEmptyNodeError, DeleteNodeError
from .configkeys import TOOL_RULES_AUTOFIX_KEY, STANDARDIZE_MODULE_NAME_STYLE_KEY


class BaseFixer(abc.ABC):
    """description of class"""
    FIX_MSG_OPTION = FixChoice.FIX_ALL

    class FixKind(enum.Enum):
        AUTOFIX = 'autofix'  # 可自动修复所有场景的规则
        SEMI_AUTOFIX = 'semiautofix'  # 可自动修复部分场景,部分场景只能单点修复的规则
        SINGLEFIX = 'singlefix'  # 只能单点修复的规则

    def __init__(self, ruleid, toolname, kind: FixKind, open_file=True):
        self._ruleid = ruleid
        self._toolname = toolname
        autofix_key = TOOL_RULES_AUTOFIX_KEY % (toolname, ruleid)
        self._fixkind = self.FixKind(settings().get_default(autofix_key, kind))
        self._openfile = open_file
        self.fix_tool = None
        self._textview = None
        self._textctrl = None
        self.check_tool = None
        self._doc = None

    @property
    def doc(self):
        return self._doc

    @property
    def textview(self):
        return self._textview

    @property
    def textctrl(self):
        return self._textctrl

    @property
    def ruleid(self):
        return self._ruleid

    @property
    def toolname(self):
        return self._toolname

    @property
    def openfile(self):
        return self._openfile

    @openfile.setter
    def openfile(self, isopen):
        self._openfile = isopen

    @property
    def kind(self):
        return self._fixkind

    @property
    def autofix(self):
        '''判断规则是否可自动修复'''
        return self._fixkind in [self.FixKind.AUTOFIX, self.FixKind.SEMI_AUTOFIX]

    @autofix.setter
    def autofix(self, value):
        if value:
            self._fixkind = self.FixKind.AUTOFIX
        else:
            self._fixkind = self.FixKind.SINGLEFIX

    @staticmethod
    def is_file_rename_or_removed(filepath):
        fix_module_name = utils.profile_get_int(STANDARDIZE_MODULE_NAME_STYLE_KEY, False)
        if fix_module_name and not os.path.exists(filepath):
            utils.get_logger().warning(
                "file %s is renamed or removed when check result",
                filepath
            )
            return True
        return False

    @classmethod
    def fix_only_autofix(cls):
        '''是否只修复可自动化修复的规则'''
        return cls.FIX_MSG_OPTION == FixChoice.FIX_AUTOFIX

    def set_doc(self, doc):
        self._doc = doc

    def get_msg_line_text(self, msg):
        return self._textctrl.get_line_text(msg.line - 1)

    def set_textview(self, textview):
        self._textview = textview
        self._textctrl = self._textview.GetCtrl()

    def open_doc_file(self, doc, msg, is_auto_fix=False):
        filepath = msg.filepath
        if self.is_file_rename_or_removed(filepath):
            return None, None
        if self._doc != doc:
            self.set_doc(doc)
        if is_auto_fix:
            filedoc = get_app().GetDocumentManager().GetDocument(filepath)
            if filedoc is None:
                fileview = get_app().GotoView(
                    filepath,
                    lineNum=msg.line,
                    colno=msg.column,
                    trace_track=False
                )
            else:
                fileview = filedoc.GetFirstView()
                filedoc.reload()
            self.set_textview(fileview)
        else:
            fileview = get_app().GotoView(
                filepath,
                lineNum=msg.line,
                colno=msg.column,
                trace_track=False
            )
            self.set_textview(fileview)
        if fileview is None:
            return None, None
        textctrl = fileview.GetCtrl()
        return fileview, textctrl

    @abc.abstractmethod
    def fix_message(self, msg):
        raise NotImplementedError('You must implemented it in derived class')

    def auto_fix_msg(self, doc, msg):
        textview = None
        if self._openfile:
            if not self.autofix:
                utils.get_logger().warning(
                    "rule %s in tool %s could not autofix code message", msg.ruleid, self.toolname)
                return textview, False
            textview = self.open_doc_file(doc, msg, is_auto_fix=True)[0]
            if textview is None:
                utils.get_logger().error("open document file %s error", msg.filepath)
                return textview, False
        result: bool = self.fix_message(msg)
        utils.get_logger().info(
            'fix msgid:%s in line %d, column %d of tool %s in filename %s,result:%s',
            msg.ruleid,
            msg.line,
            msg.column,
            msg.toolname,
            msg.filepath,
            strutils.bool_to_str(result)
        )
        if not isinstance(result, bool):
            raise AssertionError('fix result type is not bool:%s' % result)
        if textview is not None:
            textdoc = textview.GetDocument()
            textdoc.Save()
        return textview, result

    def replace_line_text(self, line, replace_line_text):
        fix_range = FixRange(line)
        fix_range.replace_line(self._textview, replace_line_text)

    def replace_range_text(
        self,
        start_line,
        replace_text,
        start_col=None,
        end_line=None,
        end_col=None
    ):
        fixrange = FixRange(start_line, start_col, end_line, end_col)
        self.replace_fix_range_text(fixrange, replace_text)

    def replace_fix_range_text(self, fixrange, replace_text):
        fixrange.replace_with_text(self._textview, replace_text)

    def replace_offset_range_text(self, char_offset, char_len, replace_text):
        replace_range = ReplaceOffsetRange(char_offset, char_len)
        replace_range.replace_with_text(self._textview, replace_text)

    def add_range_text(self, line, col, add_content):
        line_count = self.get_line_count()
        # 如果插入文件最后一行,且最后一行没有换行符,需要在插入内容前面添加换行符
        if line > line_count:
            utils.get_logger().warning(
                'add line num %d greater then doc lines count:%d',
                line,
                line_count
            )
            add_content = '\n' + add_content
        add_range = get_add_range(line, col)
        add_range.add_text(self._textview, add_content)

    def ask_input_string(self, title, label, initialvalue=None):
        ok, newname = simpledialog.askstring(
            title,
            label,
            initialvalue=initialvalue,
            master=self._textctrl
        )
        return ok, newname

    def ask_question(self, title, label):
        ret = QMessageBox.question(self._textctrl, title, label)
        if ret == QMessageBox.No:
            return False
        return True

    def ask_input_list(self, title, label, choices, selection=-1):
        sel = simpledialog.asklist(
            title,
            label,
            choices,
            selection=selection,
            master=self._textctrl
        )
        return sel

    def delete_text_line(self, lineno):
        self._textview.delete_line(lineno)

    def get_line_text(self, lineno):
        return self._textctrl.get_line_text(lineno)

    def get_linetext_len(self, lineno):
        linetext = self.get_line_text(lineno)
        return len(self._textctrl._encodeString(linetext))

    def do_rstrip_line(self, line):
        '''
        清除单行尾的空白字符
        '''
        return self._textview.do_rstrip_line(line)

    def reload_text_doc(self):
        self._textview.GetDocument().reload()

    def is_text_modified(self):
        return self._textview.IsModified()

    def get_line_count(self):
        return self._textctrl.get_line_count()

    def convert_tabs_to_spaces(self):
        '''
        检查文本是否包含制表符, 并替换制表符为4个空格
        '''
        chars = self._textctrl.text()
        tab_count = chars.count("\t")
        if not tab_count:
            return False
        newchars = self._textview.expandtabs(chars)
        self._textctrl.clearall()
        self._textctrl.insert_text(0, newchars)
        return True

    def replace_text_eol(self):
        eol, mixed = self._textview.check_eol_mixed()
        if mixed:
            self._textview.replace_eol(self._textview.get_line_end(eol))
            self._textctrl.setEolMode(eol)
            self._textctrl.eol = eol
            get_app().MainFrame.GetNotebook().updateStatusBar()
            return True
        return False

    def back_text_tab(self, lineno, col):
        self._textview.GotoPos(lineno, col)
        # 将块内的语句退格
        self._textview.backtab()


def append_doc_path(func):
    def wrapper(self, *args):
        docpath = self._doc.GetPath()
        append_to_syspath(docpath)
        self.fix_importnodes()
        ret = func(self, *args)
        remove_syspath(docpath)
        return ret
    return wrapper


def append_doc_interpreter_path(func):
    def wrapper(self, *args):
        interpreter = self._doc.GetModel().interpreter
        os_module_path = interpreter.find_module('os')
        interpreter_lib_path = os.path.dirname(os_module_path)
        append_to_syspath(interpreter_lib_path)
        ret = func(self, *args)
        remove_syspath(interpreter_lib_path)
        return ret
    return wrapper


class BasePythonFixer(BaseFixer):
    ''''''

    @staticmethod
    def is_node_could_deleted(node):
        pnode = node.parent
        else_nodes = (nodes.If, nodes.For, nodes.While, nodes.Try)
        if isinstance(pnode, else_nodes) and node in pnode.orelse and len(pnode.orelse) == 1:
            return False
        body_nodes = (nodes.If, nodes.ExceptHandler, nodes.Try, nodes.For, nodes.While, nodes.With)
        if isinstance(pnode, body_nodes) and node in pnode.body and len(pnode.body) == 1:
            return False
        if isinstance(pnode, nodes.Try) and node in pnode.finalbody and len(pnode.finalbody) == 1:
            return False
        class_def_nodes = (nodes.ClassDef, nodes.FunctionDef)
        if isinstance(pnode, class_def_nodes) and node in pnode.body and (
            len(pnode.body) == 1 and pnode.doc_node is None
        ):
            return False
        return True

    def is_comment_line(self, line):
        line_text = self._textctrl.get_line_text(line)
        if line_text.lstrip().startswith('#'):
            return True
        return False

    def get_scope_range_texts(self, scope):
        '''获取函数起使至结束行的文本范围信息,同时包含函数上方的注释信息'''
        line_range_texts = []
        top_comment_lines = self.get_function_top_comment_lines(scope)
        if top_comment_lines:
            for top_comment_line in top_comment_lines[::-1]:
                line_range_texts.append(self.get_line_text(top_comment_line))
        for i in range(scope.lineno - 1, scope.end_lineno):
            line_range_texts.append(self.get_line_text(i))
        return constants.LF.join(line_range_texts)

    def get_function_top_comment_lines(self, funcnode):
        '''获取函数上方的注释信息'''
        top_comment_lines = []
        lineno = funcnode.lineno - 1
        while lineno >= 0:
            lineno -= 1
            if lineno >= 0 and self.is_comment_line(lineno):
                top_comment_lines.append(lineno)
            else:
                break
        return top_comment_lines

    def load_module(self, filepath, reload=False):
        if self._textview.ModuleAnalyzer.Module is None or reload:
            self._textview.ModuleAnalyzer.parse_module(filepath)
            if self._textview.ModuleAnalyzer.Module is None:
                raise CodeSyntaxError(self._textview.ModuleAnalyzer.SyntaxError)

    def find_msg_scope(self, msg):
        self.load_msg_module(msg)
        scope = ScopeFinder(self.get_module()).find_scope(msg.line)
        return scope

    def find_msg_node(self, msg, *, use_column=False, raise_node_exception=True):
        try:
            self.load_msg_module(msg)
        except CodeSyntaxError:
            if not self.module_has_syntax_error():
                ast_error = self._textview.ModuleAnalyzer.SyntaxError
                raise FixfileError('module file %s has ast error:%s' % (msg.filepath, ast_error))
        line = msg.line
        scope = ScopeFinder(self.get_module()).find_scope(line)
        if use_column:
            node = self._textview.ModuleAnalyzer.find_line_col_node(line, msg.column, scope)
        else:
            node = self._textview.ModuleAnalyzer.find_line_node(line, scope)
        if raise_node_exception and node is None:
            raise LineEmptyNodeError('line %d node is empty' % line)
        return node

    def auto_fix_msg(self, doc, msg):
        try:
            textview, result = super().auto_fix_msg(doc, msg)
        except (LineEmptyNodeError, FixfileError) as ex:
            utils.get_logger().error(
                "fix line %d msg of code file %s error:%s",
                msg.line,
                msg.filepath,
                str(ex)
            )
            return False
        # 告警修复成功,表示文件内容有变动, 需要重新解析并加载语法树
        if result and textview:
            # 重新解析并加载语法树
            utils.get_logger().info(
                "file %s parse and reload ast tree again",
                msg.filepath
            )
            try:
                self.load_module(msg.filepath, reload=True)
            except CodeSyntaxError as ex:
                utils.get_logger().error(
                    "fix message file %s may occur syntax eror:%s on rule %s of tool %s",
                    msg.filepath,
                    textview.ModuleAnalyzer.SyntaxError,
                    msg.ruleid,
                    msg.toolname
                )
                syntax_error = textview.ModuleAnalyzer.SyntaxError
                if self.module_has_syntax_error():
                    raise FixfileError(f'Fix file {msg.filepath} Error:{syntax_error}') from ex
                else:
                    utils.get_logger().error(
                        "reload parse code file %s error:%s is not astroid syntax error",
                        msg.filepath,
                        syntax_error
                    )
        return textview, result

    def module_has_syntax_error(self):
        if self._textview.ModuleAnalyzer.Module is None and (
            isinstance(self._textview.ModuleAnalyzer.ex, astroid.AstroidSyntaxError)
        ):
            return True
        return False

    def get_shebang_encoding_line(self):
        return self._textview.get_shebang_encoding_line()

    def fix_node_text(self, node, fixstr):
        fixrange = get_node_range(node)
        fixrange.replace_with_text(self._textview, fixstr)

    def get_import_nodes_visitor(self):
        return ImportNodes(self._textview.ModuleAnalyzer.Module, self._textview)

    def load_msg_module(self, msg):
        self.load_module(msg.filepath)

    def get_module(self):
        module = self._textview.ModuleAnalyzer.Module
        return module

    def insert_comment_template(self):
        self._textview.InsertCommentTemplate()

    def iter_scope_childs(self, scope):
        return self._textview.ModuleAnalyzer.iter_scope_children(scope)

    def build_class_func_name_node(self, scope):
        return self._textview.ModuleAnalyzer.build_name_node(scope)

    def find_node_on_line(self, line):
        return self._textview.ModuleAnalyzer.find_line_node(
            line)

    def delete_node(self, node, delete_node_line=False, check_deleteable=False):
        if check_deleteable and not self.is_node_could_deleted(node):
            err_msg = 'delete node on line %d error: node cannot to be deleted' % node.lineno
            raise DeleteNodeError(err_msg)
        self.fix_node_text(node, "")
        if delete_node_line:
            self.delete_text_line(node.lineno - 1)
        return True

    def insert_declare_encoding(self):
        self._textview.insert_declare_encoding(prompt=False)

    def fix_importnodes(self):
        self._textview.ModuleAnalyzer.fix_module_importnodes()

    def fix_node(self, node):
        self.fix_node_text(node, node.as_string())

    def get_node_line_text(self, node):
        return self.get_line_text(node.lineno - 1)

    def fix_funcdef_args(self, funcnode, argstr):
        arg_node_range = get_func_args_range(funcnode)
        arg_node_range.replace_with_text(
            self._textview,
            argstr
        )

    def add_node_text(self, node, add_content, end=False):
        node_range = FixRange.node_range(node)
        node_range.add_text(self._textview, add_content, end)

    def find_nodes_on_line(self, line):
        line_nodes = []
        self._textview.ModuleAnalyzer.find_line_nodes(line, line_nodes)
        return line_nodes

    def is_position_in_comment(self, line, comment_col_offset):
        linenodes = self.find_nodes_on_line(line)
        end_linenode = linenodes[-1]
        if end_linenode.lineno == end_linenode.end_lineno:
            return comment_col_offset > end_linenode.end_col_offset
        childs = self._textview.ModuleAnalyzer.get_child_nodes_with_line(end_linenode, line)
        end_colnode = childs[-1]
        return comment_col_offset > end_colnode.end_col_offset

    def add_import_node(self, importname):
        '''加入导入语句'''
        visitor = self.get_import_nodes_visitor()
        if not visitor.is_import_exist(importname):
            insert_line = visitor.get_import_line()
            self.add_range_text(insert_line + 1, 0, f"import {importname}" + os.linesep)
            return True
        return False

    def get_else_line(self, line):
        '''获取else语句所在的行,用来删除else行'''
        return self.get_feature_word_line(line, 'else')

    def get_feature_word_line(self, line, word):
        '''获取特征单词所在的行,用来删除else行'''
        i = line
        while i > 0:
            line_text = self.get_line_text(i)
            if re.search(rf"{word}\s*:", line_text):
                return i
            i -= 1
        return -1

    def get_finally_line(self, line):
        '''获取finally语句所在的行,用来删除finally行'''
        return self.get_feature_word_line(line, 'finally')

    def get_node_col_offset_whitespaces_count(self, node):
        linetext = self.get_node_line_text(node)
        col_offset = node.col_offset - 1
        tabs_count = 0
        blanks_count = 0
        while col_offset >= 0:
            if linetext[col_offset] == '\t':
                tabs_count += 1
            else:
                blanks_count += 1
            col_offset -= 1
        return blanks_count, tabs_count

    def get_node_col_offset_blanks(self, node):
        blanks_count, tabs_count = self.get_node_col_offset_whitespaces_count(node)
        if tabs_count > 0:
            return ' ' * blanks_count + '\t' * tabs_count
        return ' ' * node.col_offset

    def get_node_col_offset(self, node):
        _blanks_count, tabs_count = self.get_node_col_offset_whitespaces_count(node)
        if tabs_count > 0:
            return node.col_offset - tabs_count + tabs_count * constants.DEFAULT_TAB_WIDTH
        return node.col_offset
