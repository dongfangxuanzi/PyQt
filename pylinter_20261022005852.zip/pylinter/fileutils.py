import re
import tempfile
import io
import os
import os.path
import logging
import codecs
from .constants import MAX_PYTHON_FILE_DETECTION_BYTES
from .encodings import UTF8_ENCODING, UTF8_SIG_ENCODING
log = logging.getLogger(__name__)

ENCODING_MAGIC_COMMENT = re.compile(
    r'^[ \t\f]*#.*?coding[:=][ \t]*([-_.a-zA-Z0-9]+)'
)

PYTHON_SHEBANG_REGEX = re.compile(r'^#!.*\bpython[23]?\b\s*$')
BLANK_RE = re.compile(br'^[ \t\f]*(?:[#\r\n]|$)', re.ASCII)


def get_file_content(filename, allow_exception=True, enc=UTF8_ENCODING):
    """Provides the file content"""
    try:
        with open(filename, 'r', encoding=enc) as diskfile:
            content = diskfile.read()
        return content
    except Exception:
        if allow_exception:
            raise
        return None


def _get_normal_name(orig_enc):
    """Imitates get_normal_name in tokenizer.c."""
    # Only care about the first 12 characters.
    enc = orig_enc.lower().replace("_", "-")
    if enc == UTF8_ENCODING or enc.startswith(f"{UTF8_ENCODING}-"):
        return UTF8_ENCODING
    if enc in ("latin-1", "iso-8859-1", "iso-latin-1") or \
       enc.startswith(("latin-1-", "iso-8859-1-", "iso-latin-1-")):
        return "iso-8859-1"
    return orig_enc


def readlines_from_file(filename):
    """Return contents of file."""
    with open_with_encoding(filename) as input_file:
        return input_file.readlines()


def read_from_file(filename):
    """Return contents of file."""
    with open_with_encoding(filename) as input_file:
        return input_file.read()


def open_with_encoding(filename, mode='r', encoding=None, limit_byte_check=-1):
    """Return opened file with a specific encoding."""
    if not encoding:
        encoding = detect_encoding(filename, limit_byte_check=limit_byte_check)
    if 'r' in mode:
        log.debug('load code file %s with encoding:%s', filename, encoding)
    elif 'w' in mode:
        log.debug('write code file %s with encoding:%s', filename, encoding)
    return io.open(filename, mode=mode, encoding=encoding,
                   newline='')  # Preserve line endings


def _detect_encoding_from_file(filename: str):
    encoding = UTF8_ENCODING
    try:
        with open(filename, 'rb') as input_file:
            encoding, _lines = detect_readline_encoding(input_file.readline)
    except IOError as ex:
        log.error('open file %s error:%s', filename, str(ex))
    except SyntaxError as exp:
        log.error(str(exp))
    # Python3's default encoding
    return encoding


def detect_readline_encoding(readline):
    """
    The detect_encoding() function is used to detect the encoding that should
    be used to decode a Python source file.  It requires one argument, readline,
    in the same way as the tokenize() generator.
    It will call readline a maximum of twice, and return the encoding used
    (as a string) and a list of any lines (left as bytes) it has read in.
    It detects the encoding from the presence of a utf-8 bom or an encoding
    cookie as specified in pep-0263.  If both a bom and a cookie are present,
    but disagree, a SyntaxError will be raised.  If the encoding cookie is an
    invalid charset, raise a SyntaxError.  Note that if a utf-8 bom is found,
    'utf-8-sig' is returned.
    If no encoding is specified, then the default of 'utf-8' will be returned.
    """
    try:
        filename = readline.__self__.name
    except AttributeError:
        filename = None
    bom_found = False
    encoding = None
    default = UTF8_ENCODING

    def read_or_stop():
        try:
            return readline()
        except StopIteration:
            return b''

    def find_cookie(line):
        try:
            # Decode as UTF-8. Either the line is an encoding declaration,
            # in which case it should be pure ASCII, or it must be UTF-8
            # per default encoding.
            line_string = line.decode(UTF8_ENCODING)
        except UnicodeDecodeError as exc:
            msg = "invalid or missing encoding declaration"
            if filename is not None:
                msg = '{} for {!r}'.format(msg, filename)
            raise SyntaxError(msg) from exc

        match = ENCODING_MAGIC_COMMENT.search(line_string)
        if not match:
            return None
        match_encoding = match.groups()[0]
        encoding = _get_normal_name(match_encoding)
        try:
            codec = codecs.lookup(encoding)
        except LookupError as exc:
            # This behaviour mimics the Python interpreter
            if filename is None:
                msg = "unknown encoding: " + encoding
            else:
                msg = "unknown encoding for {!r}: {}".format(filename,
                                                             encoding)
            raise SyntaxError(msg) from exc

        if bom_found:
            if encoding != UTF8_ENCODING:
                # This behaviour mimics the Python interpreter
                if filename is None:
                    msg = 'encoding problem: utf-8'
                else:
                    msg = 'encoding problem for {!r}: utf-8'.format(filename)
                raise SyntaxError(msg)
            encoding += '-sig'
        return encoding

    first = read_or_stop()
    if first.startswith(codecs.BOM_UTF8):
        bom_found = True
        first = first[3:]
        default = UTF8_SIG_ENCODING
    if not first:
        return default, []

    encoding = find_cookie(first)
    if encoding:
        return encoding, [first]
    if not BLANK_RE.match(first):
        return default, [first]

    second = read_or_stop()
    if not second:
        return default, [first]

    encoding = find_cookie(second)
    if encoding:
        return encoding, [first, second]

    return default, [first, second]


def detect_encoding(filename, limit_byte_check=-1):
    """Return file encoding."""
    encoding = _detect_encoding_from_file(filename)
    log.debug('detect file %s encoding is %s', filename, encoding)
    if encoding == UTF8_SIG_ENCODING:
        return encoding
    try:
        with open_with_encoding(filename, encoding=encoding) as test_file:
            test_file.read(limit_byte_check)
        return encoding
    except (LookupError, SyntaxError, UnicodeDecodeError):
        return 'gbk'


def make_tempfile(content, encoding=UTF8_ENCODING, ext=".py"):
    _, newfname = tempfile.mkstemp(suffix=ext, text=True)
    with open(newfname, 'w', encoding=encoding) as f:
        f.write(content)
    return newfname


def is_python_file(filename):
    """Return True if filename is Python file."""
    if filename.endswith('.py'):
        return True
    try:
        with open_with_encoding(
                filename,
                limit_byte_check=MAX_PYTHON_FILE_DETECTION_BYTES) as f:
            text = f.read(MAX_PYTHON_FILE_DETECTION_BYTES)
            if not text:
                return False
            first_line = text.splitlines()[0]
    except (IOError, UnicodeDecodeError):
        return False
    if not PYTHON_SHEBANG_REGEX.match(first_line):
        return False
    return True


def match_file(filename, exclude):
    """Return True if file is okay for modifying/recursing."""
    base_name = os.path.basename(filename)
    if base_name.startswith('.'):
        return False
    for pattern in exclude:
        if fnmatch.fnmatch(base_name, pattern):
            return False
        if fnmatch.fnmatch(filename, pattern):
            return False
    if not os.path.isdir(filename) and not is_python_file(filename):
        log.debug('file `%s` is not a valid python file', filename)
        return False
    return True


def get_filepath_from_path(path):
    """
    Returns the filename for a full path.
    """
    return os.path.split(path)[0]
