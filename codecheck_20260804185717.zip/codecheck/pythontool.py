import subprocess
import os
import shutil
import re
import json
from novalapp.util.cmp_func import py_sorted
from novalapp.util import strutils, fileutils
from novalapp.util import utils
from novalapp.executable import Executable
from novalapp.common import md5
from novalapp.common.compat import ensure_string
from novalapp import _, get_app
from pkg_resources import resource_filename
from . import configkeys
from .flake8_fix import Flake8Fixer
from .pylint.fixers import *
from .basetool import BasePythonCheckTool
from .strings import (
    PYLINT_TOOL_NAME,
    FLAKE8_TOOL_NAME,
    AUTOPEP8_TOOL_NAME,
    COMMON_PYLINT_MESSAGE_ID,
    PYLINT_PLUGIN_NAMES,
    PYLINT_CFG_MASTER_SECTION,
    PYLINT_CFG_MASTER_CONTROL_SECTION
)
from .exceptions import FixfileError, Flake8EradicateNotInstalledError
from .message import Message
from .pylint_fix import SarifFixer, PylintCommonFixer
from .pkgres import get_pylint_rc_path, get_flake8_config_path, _get_pkg_res_path
from .strings import FLAKE8_ERADICATE_TOOL_NAME


class Flake8Tool(BasePythonCheckTool):
    """description of class"""

    def __init__(self, interpreter=None):
        super().__init__(FLAKE8_TOOL_NAME, interpreter)
        self._command_args.append('--config')
        self._command_args.append(get_flake8_config_path())
        self._command_args.append('--exit-zero')
        self.add_fixer(Flake8Fixer(self))

    @staticmethod
    def build_common_arguments(rules):
        '''
        flake8和autopep8工具共有的参数
        '''
        args = []
        if rules is not None:
            args.append('--select')
            args.append(','.join(rules))
        return args

    @staticmethod
    def compare_file_content(filepath, newfilepath):
        src_file_hash = md5.get_normal_file_md5(filepath)
        dest_file_hash = md5.get_normal_file_md5(newfilepath)
        utils.get_logger().debug(
            "src file %s md5 hash is %s, dest file %s md5 has is %s",
            filepath,
            src_file_hash,
            newfilepath,
            dest_file_hash
        )
        return src_file_hash != dest_file_hash

    @classmethod
    def build_arguments(cls, rules):
        '''
        构造flake8工具运行的参数
        '''
        args = cls.build_common_arguments(rules)
        args.append('--exit-zero')
        return args

    def parse_line_msg(self, linetext):
        result = re.search(r'(.*):(\d+):(\d+): (\w+) (.*)', linetext)
        if result is None:
            return None
        path, line, col, rule, messgae = result.groups()
        msg = Message(int(line), int(col), rule, path, messgae, self.name, [])
        return msg

    def update(self, interpreter):
        super().update(interpreter)
        if utils.profile_get_int(configkeys.DELETE_COMMENT_OUT_CODES_KEY, False):
            if not interpreter.GetInstallPackage(FLAKE8_ERADICATE_TOOL_NAME):
                utils.get_logger().error(
                    '%s tool not installed in interpreter path %s',
                    FLAKE8_ERADICATE_TOOL_NAME,
                    interpreter.path
                )
                raise Flake8EradicateNotInstalledError(
                    f"{FLAKE8_ERADICATE_TOOL_NAME} tool not installed"
                )
        if self._fixers:
            self._fixers[0].update_fix_rules()

    def fix_file(self, processor, doc, filepath):
        if Flake8Fixer.is_file_rename_or_removed(filepath):
            return False
        autopep8_path = self._interpreter.find_tool(AUTOPEP8_TOOL_NAME)
        utils.get_logger().info('find tool %s path is %s',
                                AUTOPEP8_TOOL_NAME, autopep8_path)
        command_args = ["--global-config", get_flake8_config_path()]
        exectable = Executable(self._interpreter.path, args=[
                               "-m", AUTOPEP8_TOOL_NAME] + command_args)
        command = exectable.get_cmd()
        command += " "
        command += strutils.emphasis_path(filepath)
        # 启用深度修复功能,增加多个规则的修复功能
        fix_depth = utils.profile_get_int(configkeys.AUTOPEP8_FIXDEPTH_KEY, 0)
        if fix_depth > 0:
            command += " "
            command += ' '.join(['-a'] * fix_depth)
        utils.get_logger().info('tool %s fix command is %s', AUTOPEP8_TOOL_NAME, command)
        backup_file_path = "%s.bak" % (filepath)
        startupinfo = exectable.hide_startupinfo()
        utils.get_logger().debug('backfile is %s', backup_file_path)
        stdout_log = open(backup_file_path, "w")
        workpath = self.get_work_path(doc)
        process_obj = subprocess.Popen(
            command,
            shell=True,
            startupinfo=startupinfo,
            cwd=workpath,
            stdout=stdout_log,
            stderr=subprocess.PIPE
        )
        process_obj.wait()
        stdout_log.close()
        if process_obj.returncode != 0:
            utils.get_logger().info("tool %s exec command %s returncode is %d",
                                    AUTOPEP8_TOOL_NAME, command, process_obj.returncode)
            utils.get_logger().error("tool %s exec command %s error", AUTOPEP8_TOOL_NAME, command)
            utils.get_logger().error(
                'error output is %s',
                ensure_string(process_obj.stderr.read())
            )
            raise FixfileError(_("tool %s fix file %s error") %
                               (AUTOPEP8_TOOL_NAME, filepath))
        if utils.profile_get_int(configkeys.CHECK_FILE_SYNTAX_KEY, True):
            if not self.check_file_syntax(backup_file_path):
                return False
        # 如果修复后的文件内容没有发生改变, 无需替换文件
        if self.compare_file_content(filepath, backup_file_path):
            utils.get_logger().debug(
                "code file %s content is changed after autopep8 fix, replace with back file %s",
                filepath,
                backup_file_path
            )
            shutil.copy(backup_file_path, filepath)
            filedoc = get_app().GetDocumentManager().GetDocument(filepath)
            if filedoc is not None:
                utils.get_logger().debug(
                    "open code file %s content is changed after autopep8 fix,reparse ast tree again",
                    filepath
                )
                # 代码文件有变动,并且在编辑区打开,需要重新构建语法树
                filedoc.GetFirstView().ModuleAnalyzer.parse_module(filepath, load_from_file=True)
        else:
            utils.get_logger().debug(
                "code file %s content is not changed after autopep8 fix",
                filepath
            )
        # 不管是否有无替换文件, 删除生成的备份文件
        os.remove(backup_file_path)
        utils.get_logger().debug("remove autopep8 fixed backfile %s success", backup_file_path)
        return True

    def build_version(self):
        if self._interpreter is None:
            return
        output = self.get_version_output()
        lines = output.splitlines()
        if not lines:
            utils.get_logger().error("build tool %s version error", self._path)
            return
        self._version = lines[0].strip().split()[0]

    def is_rule_fixable(self, rule_id):
        return rule_id in self._fixers[0].fix_rules

    def find_fixer(self, rule_id):
        if not self.is_rule_fixable(rule_id):
            return None
        return self._fixers[0]

    def update_enable_rules(self, rules):
        super().update_enable_rules(rules)
        flake8_conf_path = get_flake8_config_path()
        self.update_cfg_file(flake8_conf_path)
        if rules is None:
            enabled_rules_text = "all"
        else:
            enabled_rules_text = ",".join(rules)
        utils.get_logger().debug("flake8 enable rules is %s", enabled_rules_text)
        try:
            self.write_key_section_value(
                'flake8', 'select', enabled_rules_text)
        except Exception as ex:
            utils.get_logger().exception(
                'update flake8 conf file %s exception:',
                flake8_conf_path
            )
            fileutils.safe_remove(flake8_conf_path)
            raise ex


class PylintTool(BasePythonCheckTool):
    """description of class"""

    CFG_INIT_HOOK_KEY = 'init-hook'
    CFG_LOAD_PLUGINS_KEY = 'load-plugins'
    CFG_RULES_ENABLE_KEY = 'enable'
    CFG_UNSAFE_LOAD_EXTENSION_KEY = 'unsafe-load-any-extension'

    def __init__(self, interpreter=None, json_output=False):
        super().__init__(PYLINT_TOOL_NAME, interpreter)
        self.fix_flake8_tool = None
        if json_output:
            self._output_format = self.JSON_OUTPUT_FORMAT
            self._command_args = ['--fix', '-f', 'sarif']
            fixrules_file = os.path.join(_get_pkg_res_path(), "fixrules.json")
            utils.get_logger().info("fix rules file is %s", fixrules_file)
            with open(fixrules_file) as fr:
                fix_rules = json.load(fr)
                for key, value in fix_rules.items():
                    if isinstance(value, str):
                        bval = strutils.str_to_bool(value)
                        self.add_fixer(SarifFixer(key, bval))
                    elif isinstance(value, list):
                        assert (value[0] in ["true", "false"])
                        fixer_class = utils.get_class_from_dynamicimport_module(value[1])
                        fixer = fixer_class()
                        self.add_fixer(fixer)
                    else:
                        raise RuntimeError('invalid fix rule value')
        else:
            self._command_args = [
                '--msg-template',
                "{abspath}:{line}:{column}: {msg_id}: {msg} ({symbol})"
            ]
            self.add_fixer(PylintE0710Fixer())
            self.add_fixer(PylintW0402Fixer())
            self.add_fixer(PylintW1512Fixer())

        self._command_args.append('--rcfile')
        self._command_args.append(get_pylint_rc_path())
        self._command_args.append('--exit-zero')
        self.add_fixers()

    @staticmethod
    def compare_with_message_line_column(left, right):
        '''
        按告警行号进行排序,如果左边行号小于右边行号,或者行号相等,左边列号小于右边列号,返回正值表示倒叙,
        否则表示正序,此排序函数表示按行列号进行倒叙排序
        '''
        if left.line < right.line:
            return 1
        if left.line == right.line:
            if left.column < right.column:
                return 1
            if left.column == right.column:
                # 如果行列号相同,则按规则编号等级字母倒叙排序
                if left.ruleid[0] < right.ruleid[0]:
                    return 1
                if left.ruleid[0] == right.ruleid[0]:
                    # 如果编号等级字母相同,则按规则编号数字顺序倒叙排序
                    if int(left.ruleid[1:]) < int(right.ruleid[1:]):
                        return 1
        return -1

    def add_fixers(self):
        self.add_fixer(PylintW0611Fixer())
        self.add_fixer(PylintC0327Fixer())
        self.add_fixer(PylintE0001Fixer())
        self.add_fixer(PylintF0010Fixer())
        self.add_fixer(PylintC2503Fixer())
        self.add_fixer(PylintW0404Fixer())
        self.add_fixer(PylintE0711Fixer())
        self.add_fixer(PylintR0402Fixer())
        self.add_fixer(PylintR1705Fixer())
        self.add_fixer(PylintW0107Fixer())
        self.add_fixer(PylintC0303Fixer())
        self.add_fixer(PylintC0411Fixer())
        self.add_fixer(PylintC0325Fixer())
        self.add_fixer(PylintR0205Fixer())
        self.add_fixer(PylintR1725Fixer())
        self.add_fixer(PylintC0114Fixer())
        self.add_fixer(PylintC0116Fixer())
        self.add_fixer(PylintC0115Fixer())
        self.add_fixer(PylintC0410Fixer())
        self.add_fixer(PylintW0614Fixer())
        self.add_fixer(PylintW0235Fixer())
        self.add_fixer(PylintW1201Fixer())
        self.add_fixer(PylintW1202Fixer())
        self.add_fixer(PylintW0612Fixer())
        self.add_fixer(PylintR0201Fixer())
        self.add_fixer(PylintC0121Fixer())
        self.add_fixer(PylintW0702Fixer())
        self.add_fixer(PylintR1720Fixer())
        self.add_fixer(PylintE0213Fixer())
        self.add_fixer(PylintE0211Fixer())
        self.add_fixer(PylintC0202Fixer())
        self.add_fixer(PylintC0301Fixer())
        self.add_fixer(PylintE0602Fixer())
        self.add_fixer(PylintC0200Fixer())
        self.add_fixer(PylintW0410Fixer())
        self.add_fixer(PylintW0109Fixer())
        self.add_fixer(PylintR1734Fixer())
        self.add_fixer(PylintR1735Fixer())
        self.add_fixer(PylintR1716Fixer())
        self.add_fixer(PylintC0103Fixer())
        self.add_fixer(PylintW1401Fixer())
        self.add_fixer(PylintR1714Fixer())
        self.add_fixer(PylintW1505Fixer())
        self.add_fixer(PylintI0021Fixer())
        self.add_fixer(PylintI0020Fixer())
        self.add_fixer(PylintI0023Fixer())
        self.add_fixer(PylintC0413Fixer())
        self.add_fixer(PylintW1406Fixer())
        self.add_fixer(PylintR1723Fixer())
        self.add_fixer(PylintR1724Fixer())
        self.add_fixer(PylintW0237Fixer())
        self.add_fixer(PylintC0206Fixer())
        self.add_fixer(PylintC2201Fixer())
        self.add_fixer(PylintW0212Fixer())
        self.add_fixer(PylintC1802Fixer())
        self.add_fixer(PylintE0601Fixer())
        self.add_fixer(PylintW0123Fixer())
        self.add_fixer(PylintC0412Fixer())
        self.add_fixer(PylintW0715Fixer())
        self.add_fixer(PylintW0613Fixer())
        self.add_fixer(PylintW0201Fixer())
        self.add_fixer(PylintW0246Fixer())
        self.add_fixer(PylintR1710Fixer())
        self.add_fixer(PylintW0707Fixer())
        self.add_fixer(PylintW0104Fixer())
        self.add_fixer(PylintW0105Fixer())
        self.add_fixer(PylintW0602Fixer())
        self.add_fixer(PylintW0238Fixer())
        self.add_fixer(PylintE1003Fixer())
        self.add_fixer(PylintW0511Fixer())
        self.add_fixer(PylintC0123Fixer())
        self.add_fixer(PylintW0102Fixer())
        self.add_fixer(PylintW4902Fixer())
        self.add_fixer(PylintR1729Fixer())
        self.add_fixer(PylintC1805Fixer())
        self.add_fixer(PylintW0101Fixer())
        self.add_fixer(PylintW9000Fixer())
        self.add_fixer(PylintW9001Fixer())
        self.add_fixer(PylintW9002Fixer())
        self.add_fixer(PylintC0204Fixer())
        self.add_fixer(PylintCommonFixer())
        self.add_fixer(PylintC0207Fixer())
        self.add_fixer(PylintR1701Fixer())
        self.add_fixer(PylintW0231Fixer())
        self.add_fixer(PylintC0321Fixer())
        self.add_fixer(PylintR1719Fixer())
        self.add_fixer(PylintC0117Fixer())
        self.add_fixer(PylintR1731Fixer())
        self.add_fixer(PylintR1730Fixer())
        self.add_fixer(PylintW9003Fixer())
        self.add_fixer(PylintW0012Fixer())
        self.add_fixer(PylintW0120Fixer())
        self.add_fixer(PylintC2801Fixer())
        self.add_fixer(PylintW0622Fixer())
        self.add_fixer(PylintW0621Fixer())
        self.add_fixer(PylintW0401Fixer())
        self.add_fixer(PylintW1514Fixer())
        self.add_fixer(PylintW0221Fixer())
        self.add_fixer(PylintW2301Fixer())

    def parse_line_msg(self, linetext):
        if linetext.find('*************') != -1:
            return None
        result = re.search(r'(.*):(\d+):(\d+): (\w+): (.*)', linetext)
        if result is None:
            return None
        path, line, col, rule, messgae = result.groups()
        msg = Message(int(line), int(col), rule, path, messgae, self.name, [])
        return msg

    def build_version(self):
        if self._interpreter is None:
            return
        output = self.get_version_output()
        lines = output.splitlines()
        if not lines:
            utils.get_logger().error("build tool %s version error", self._path)
            return
        self._version = lines[0].strip().split()[1]

    def fix_file(self, processor, doc, filepath):
        # 修复pylint告警之前是否先格式化代码文件
        if utils.profile_get_int(configkeys.FORMAT_CODEFILE_BEFORE_FIX_KEY, False):
            if self.fix_flake8_tool is None:
                self.fix_flake8_tool = processor.find_tool(FLAKE8_TOOL_NAME)
            if self.fix_flake8_tool is not None:
                self.fix_flake8_tool.fix_file(processor, doc, filepath)
        message_file = self.get_file_log_path(doc, filepath)
        processor.message_viewer._plugin._check_processor.check_single_file(
            doc, filepath, load_messages=False)
        messages = processor.load_messages(self, message_file)
        # 对告警进行按行号倒叙排序,从下往上修复告警,可以避免修复过程中告警行号的波动
        for msg in py_sorted(messages, self.compare_with_message_line_column):
            if self.enable_rules and msg.ruleid not in self.enable_rules:
                utils.get_logger().warning('pylint tool rule %s is not enabled', msg.ruleid)
                continue
            processor.handle_message(doc, self, msg)
        common_msg = Message(
            -1,
            -1,
            COMMON_PYLINT_MESSAGE_ID,
            filepath,
            'common pylint message',
            self.name,
            []
        )
        processor.handle_message(doc, self, common_msg)
        if utils.profile_get_int(configkeys.CHECK_FILE_SYNTAX_KEY, True):
            self.check_file_syntax(filepath)

    def update_enable_rules(self, rules):
        super().update_enable_rules(rules)
        pylint_conf_path = get_pylint_rc_path()
        self.update_cfg_file(pylint_conf_path)
        if rules is None:
            enabled_rules_text = "all"
        else:
            enabled_rules_text = ",".join(rules)
        plugins_path = resource_filename('codecheck', 'pylint')
        init_hook_code = f'\'import sys;sys.path.append(r"{plugins_path}")\''
        utils.get_logger().debug('pylint plugin path is %s', plugins_path)
        utils.get_logger().debug("pylint enable rules is %s", enabled_rules_text)
        pylint_load_plugins = ",".join(PYLINT_PLUGIN_NAMES)
        init_hook_section = self.get_key_section(self.CFG_INIT_HOOK_KEY)
        assert init_hook_section == PYLINT_CFG_MASTER_SECTION, f'{self.CFG_INIT_HOOK_KEY} section error'
        load_plugins_section = self.get_key_section(self.CFG_LOAD_PLUGINS_KEY)
        assert load_plugins_section == PYLINT_CFG_MASTER_SECTION, f'{self.CFG_LOAD_PLUGINS_KEY} section error'
        enable_section = self.get_key_section(self.CFG_RULES_ENABLE_KEY)
        assert enable_section == PYLINT_CFG_MASTER_CONTROL_SECTION, f'{self.CFG_RULES_ENABLE_KEY} section error'
        is_init_hook_changed = self.is_cfg_key_value_changed(
            PYLINT_CFG_MASTER_SECTION,
            self.CFG_INIT_HOOK_KEY,
            init_hook_code
        )
        is_plugins_changed = self.is_cfg_key_value_changed(
            PYLINT_CFG_MASTER_SECTION,
            self.CFG_LOAD_PLUGINS_KEY,
            pylint_load_plugins
        )
        is_enable_rules_changed = self.is_cfg_key_value_changed(
            PYLINT_CFG_MASTER_CONTROL_SECTION,
            self.CFG_RULES_ENABLE_KEY,
            enabled_rules_text
        )
        try:
            if is_init_hook_changed:
                self.write_key_section_value(
                    PYLINT_CFG_MASTER_SECTION,
                    self.CFG_INIT_HOOK_KEY,
                    init_hook_code
                )
            if is_enable_rules_changed:
                self.write_key_section_value(
                    PYLINT_CFG_MASTER_CONTROL_SECTION,
                    self.CFG_RULES_ENABLE_KEY,
                    enabled_rules_text
                )
                self.write_key_section_value(PYLINT_CFG_MASTER_CONTROL_SECTION, 'disable', "all")
            if is_plugins_changed:
                self.write_key_section_value(
                    PYLINT_CFG_MASTER_SECTION,
                    self.CFG_LOAD_PLUGINS_KEY,
                    pylint_load_plugins
                )
        except Exception as ex:
            utils.get_logger().exception(
                'update pylint conf file %s exception:',
                pylint_conf_path
            )
            fileutils.safe_remove(pylint_conf_path)
            raise ex
