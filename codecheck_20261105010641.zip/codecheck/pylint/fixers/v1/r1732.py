'''
Name:        r1732.py
Purpose:
Author:      wukan
Created:     2026-11-05
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ....pylint_fix import PylintFixer
from ....codeutils import DEFAULT_TAB_BLANKS


class PylintR1732Fixer(PylintFixer):
    '''
    规则说明:使用with语句代替手动打开,关闭对象
    '''

    USE_WITH_FUNC_NAME_ITEMS = {
        'open': 'close',
        'subprocess.Popen': 'wait'
    }

    def __init__(self):
        super().__init__('R1732', self.FixKind.SINGLEFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        scope = ScopeFinder(self.get_module()).find_scope(msg.line)
        if isinstance(node, nodes.Assign) and isinstance(node.value, nodes.Call):
            call_func_node = node.value.func
            call_func_name = call_func_node.as_string()
            if call_func_name in self.USE_WITH_FUNC_NAME_ITEMS:
                offset_blanks = self.get_node_col_offset_blanks(node)
                close_func_name = self.USE_WITH_FUNC_NAME_ITEMS[call_func_name]
                target_name = node.targets[0].as_string()
                close_call_func_name = target_name + "." + close_func_name
                line_range_nodes = self.find_line_range_nodes(msg.line, scope=scope)
                with_range_lines = set()
                for linenode in line_range_nodes:
                    if isinstance(linenode, nodes.Call) and linenode.func.as_string() == close_call_func_name:
                        break
                    with_range_lines.add(linenode.lineno)
                else:
                    return False
                end_lineno = max(with_range_lines)
                line_texts = []
                start_line = msg.line
                for i in range(start_line, end_lineno):
                    if i == start_line:
                        linestr = offset_blanks + f'with {node.value.as_string()} as {target_name}:'
                    else:
                        linetext = self.get_line_text(i - 1)[node.col_offset:]
                        linestr = offset_blanks + DEFAULT_TAB_BLANKS + linetext
                    line_texts.append(linestr)
                self.replace_range_text(
                    start_line,
                    '\n'.join(line_texts) + '\n',
                    0,
                    end_lineno + 1,
                    0
                )
                return True
        return False
