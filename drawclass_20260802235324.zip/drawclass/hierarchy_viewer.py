from collections import defaultdict
import json
import os
from pkg_resources import resource_filename
from novalapp.util import utils
from novalapp.python.project import additem
from novalapp.editor.imageview import PixmapWidget
from novalapp import _, get_app
from novalapp.python.interpreter.interpretermanager import InterpreterManager
from novalapp.python.interpreter.interpreter import BuiltinPythonInterpreter
from novalapp.lib.pyqt import (
    QLabel,
    QHBoxLayout,
    QVBoxLayout,
    Qt,
    QFrame,
    QSizePolicy,
    QComboBox,
    QPushButton,
    QMessageBox,
    QMenu,
    QFileDialog,
    QPixmap
)
from novalapp.widgets import simpledialog
from novalapp.executable import Executable
from novalapp.util.exceptions import PluginRequiredPackagesError
from novalapp.python.utility import check_plugin_required_packages
from novalapp.python.apis.memberkeys import QUALNAME_KEY_NAME
from .pkgutils import get_pkg_res_path
from novalapp.qtimage import load_image

PLOT_IMAGE_NAME = 'plot.png'

def get_loading_pixmap_path():
    pkg_dest_res_path = get_pkg_res_path()
    loading_pixmap_path = os.path.join(pkg_dest_res_path, "loaddata.png")
    return loading_pixmap_path

class PlotClassHierarchyPixmapWidget(PixmapWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.class_hierarchy_filename = None

    @property
    def data_file(self):
        return self.class_hierarchy_filename

    def set_classdata_file(self, datafile):
        self.class_hierarchy_filename = datafile


class ClassHierarchyViewer(QFrame):
    """description of class"""

    def __init__(self, parent=None, plugin=None):
        super().__init__(parent)
        self._plugin = plugin
        self.loading_pixmap = load_image(get_loading_pixmap_path())

        frame_layout = QVBoxLayout()

        class_box = QHBoxLayout()
        class_box.setAlignment(Qt.AlignLeft)
        class_box.setContentsMargins(0, 10, 0, 0)

        class_box.addWidget(QLabel(_('Classes') + ":"))
        self.class_entry = QComboBox()
        self.class_entry.setEditable(True)
        self.class_entry.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.class_entry.setFixedWidth(additem.FIXED_LABEL_WIDTH)
        class_box.addWidget(self.class_entry)

        class_box.addWidget(QLabel(_('Interpreter') + ":"))
        self.interpreter_list_combxo = QComboBox()
        self.scan_all_interpreters()
        class_box.addWidget(self.interpreter_list_combxo)

        self.render_button = QPushButton(_('Render Hierarchy'))
        self.render_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.render_button.clicked.connect(self.render)
        class_box.addWidget(self.render_button)
        frame_layout.addLayout(class_box)

        self._image_viewer = PlotClassHierarchyPixmapWidget(self)
        self._image_viewer.pixmaplabel.doubleClicked.connect(self.click_image_view)
        self._image_viewer.pixmaplabel.setToolTip(_('Double click to enlarge the picture'))
        self._image_viewer.pixmaplabel.customContextMenuRequested.connect(self._show_contextmenu)
        frame_layout.addWidget(self._image_viewer)
        self.load_all_classes()
        self.setLayout(frame_layout)
        self.outputview = None

    def get_class_mod_list(self, classname):
        class_def_filepath = os.path.join(utils.get_cache_path(), additem.CLASS_DEFS_FILENAME)
        if os.path.exists(class_def_filepath):
            with open(class_def_filepath, encoding="ascii") as f:
                class_dict = json.load(f)
                return class_dict.get(classname, [])
        return []

    def load_class_defs(self, class_def_filepath):
        if os.path.exists(class_def_filepath):
            with open(class_def_filepath, encoding="ascii") as f:
                class_dict = json.load(f)
                self.class_entry.addItems(sorted(class_dict.keys()))
                class_dict.clear()

    def click_image_view(self):
        if self._image_viewer.data_file is None:
            return
        choose_interpreter = self.get_interpreter()
        if choose_interpreter is None:
            return
        self.render_from_datafile(
            self._image_viewer.data_file,
            choose_interpreter.path,
            show_fig=True
        )

    def scan_all_interpreters(self):
        for interpreter in InterpreterManager.manager().interpreters:
            self.interpreter_list_combxo.addItem(interpreter.name)

    def get_interpreter(self):
        index = self.interpreter_list_combxo.currentIndex()
        choose_interpreter = InterpreterManager.manager().interpreters[index]
        if choose_interpreter.IsBuiltIn:
            return None
        try:
            check_plugin_required_packages(self._plugin, choose_interpreter)
        except PluginRequiredPackagesError:
            return None
        return choose_interpreter

    def render(self):
        self._image_viewer.pixmaplabel.setPixmap(self.loading_pixmap)
        self._image_viewer.pixmaplabel.adjustSize()
        choose_interpreter = self.get_interpreter()
        if choose_interpreter is None:
            self._image_viewer.pixmaplabel.setPixmap(QPixmap())
            return
        class_name = self.class_entry.currentText().strip()
        mod_path_list = self.get_class_mod_list(class_name)
        if mod_path_list:
            if len(mod_path_list) == 1:
                sel = 0
            else:
                sel = simpledialog.asklist(
                    _("Multiple Class Definition"),
                    _("Please choose one base class import module"),
                    mod_path_list,
                    selection=0,
                    master=self
                )
                if sel == -1:
                    self._image_viewer.pixmaplabel.setPixmap(QPixmap())
                    return
        else:
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Class name %s is not exist') % class_name
            )
            self._image_viewer.pixmaplabel.setPixmap(QPixmap())
            return
        modpath = mod_path_list[sel]
        interpreter = InterpreterManager.manager().GetInterpreterByName(
            BuiltinPythonInterpreter.BUILTIN_INTERPRETER_NAME
        )
        get_app().intellisence_mananger.load_intellisence_data(interpreter, async_load=False)
        names = modpath.split(".")
        modname = ".".join(names[0:-1])
        class_dict: defaultdict[str, list[str]] = defaultdict(list)
        self.load_module_class(modname, names[-1], class_dict)
        class_hierarchy_filepath = os.path.join(utils.get_cache_path(), 'class_hierarchy.json')
        with open(class_hierarchy_filepath, 'w', encoding="ascii") as f:
            json.dump(class_dict, f)
        self._image_viewer.set_classdata_file(class_hierarchy_filepath)
        self.render_from_datafile(class_hierarchy_filepath, choose_interpreter.path)

    def render_from_datafile(self, class_hierarchy_filepath, interpreter_path, show_fig=False):
        pkg_dest_path = resource_filename(__name__, '')
        render_script_path = os.path.join(pkg_dest_path, "render.py")
        args = [
            render_script_path,
            "--class-file",
            class_hierarchy_filepath,
            "-o",
            utils.get_cache_path()
        ]
        if show_fig:
            args.append('--show')
        executable = Executable(interpreter_path, None, args=args)
        if self.outputview is None:
            self.outputview = get_app().MainFrame.GetView("Output")
            self.outputview.SIG_EXECUTE_FINISHED.connect(self.executor_finished)
        self.outputview.run(
            executable.path,
            executable.args,
            executable.workdir
        )

    def executor_finished(self, exitcode, stopped=True):
        if exitcode == 0:
            plot_png_name = os.path.join(utils.get_cache_path(), PLOT_IMAGE_NAME)
            self._image_viewer.load_from_file(plot_png_name)
        else:
            QMessageBox.critical(self, _('Error'), _('Render fail') + "...")

    def load_module_class(self, modname, classname, class_dict):
        modloader = get_app().intellisence_mananger.GetModule(modname)
        modloader.load()
        child_data = modloader.find_child(classname)
        if not child_data:
            return
        class_dict[classname] = []
        bases = child_data.get('bases', [])
        for base in bases:
            base_modname = base[QUALNAME_KEY_NAME]
            base_names = base_modname.split(".")
            base_class_module = ".".join(base_names[0:-1])
            base_class_name = base_names[-1]
            base_class_dict: defaultdict[str, list[str]] = defaultdict(list)
            class_dict[classname].append(base_class_dict)
            self.load_module_class(base_class_module, base_class_name, base_class_dict)

    def load_all_classes(self):
        class_def_filepath = os.path.join(utils.get_cache_path(), additem.CLASS_DEFS_FILENAME)
        if os.path.exists(class_def_filepath):
            self.load_class_defs(class_def_filepath)

    def _on_save_pic(self):
        descrs = _("PNG File") + " (*.png)"
        filename, _filetype = QFileDialog.getSaveFileName(
            self,
            _('Save Picture As'),
            '',
            descrs
        )
        if filename == "":
            return
        pix = self._image_viewer.pixmaplabel.pixmap()
        pix.save(filename)

    def _show_contextmenu(self, pos):
        if self._image_viewer.pixmaplabel.pixmap() is None:
            return
        contextmenu = QMenu(self)
        contextmenu.addAction(
            _('Save picture'),
            self._on_save_pic
        )
        contextmenu.popup(self._image_viewer.pixmaplabel.mapToGlobal(pos))
