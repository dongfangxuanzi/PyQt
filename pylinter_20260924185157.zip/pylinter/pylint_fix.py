import os
import logging
from astroid import nodes
from .constants import PYLINT_TOOL_NAME,COMMON_PYLINT_MESSAGE_ID
from .replace import get_node_range
from .codeutils import get_node_line_text
from .node_scope import ScopeFinder
from .basefix import BasePythonFixer
log = logging.getLogger(__name__)


class PylintFixer(BasePythonFixer):
    DOUBLE_QUOTE = '"'
    SINGLE_QUOTE = "'"
    
    # 使用*导入模块成员时允许导入的最大成员数量
    DEFAULT_MAX_MEMBERS_COUNT = 30

    def __init__(self, ruleid, autofix=True):
        super().__init__(ruleid, PYLINT_TOOL_NAME, autofix)

    @staticmethod
    def get_line_str_quote(node):
        '''
        获取行字符串是用单引号还是双引号裹起来
        '''
        linetext = get_node_line_text(node)
        if linetext is None:
            return '"'
        return linetext[node.col_offset]

    @staticmethod
    def get_classtype_parent_node(node, nodeclass, include_node_self=True):
        if include_node_self and isinstance(node, nodeclass):
            return node
        return ScopeFinder.get_parent_node_by_nodeclass(node, nodeclass)

    @staticmethod
    def replace_module_name(doc, oldpath, new_module_name):
        ext = strutils.get_file_extension(oldpath, keepdot=True)
        newname = os.path.join(
            fileutils.get_filepath_from_path(oldpath), new_module_name)
        newfilepath = strutils.MakeNameEndInExtension(newname, ext)
        return doc.GetCommandProcessor().Submit(
            projectcommand.ProjectRenameFileCommand(doc, oldpath, newfilepath)
        )

    @classmethod
    def get_line_str_r_quote(cls, node):
        '''
        获取行字符串是否被r包裹起来,如果有r,获取r后面的引号字符
        '''
        str_quote = cls.get_line_str_quote(node)
        log.debug(
            "str quote of line %d is %s",
            node.lineno,
            str_quote
        )
        # 字符串被r包裹
        if str_quote == "r":
            # 字符串引号在r字符右移1位
            node.col_offset += 1
            str_quote = cls.get_line_str_quote(node)
            node.col_offset -= 1
            return True, str_quote
        return False, str_quote

    @classmethod
    def replace_variable_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.Name, nodes.AssignName)) and child.name == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, newname)
            else:
                cls.replace_variable_name_in_scope(
                    textview, child, name, newname)

    @classmethod
    def replace_attribute_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.AssignAttr, nodes.Attribute)) and child.attrname == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, "self." + newname)
            else:
                cls.replace_attribute_name_in_scope(
                    textview, child, name, newname)

    def delete_import_name(self, node, import_name):
        if not self.is_node_could_deleted(node):
            log.error("%s node could not be deleted", node.__class__.__name__)
            return False
        for i, (name, asname) in enumerate(node.names):
            if import_name in (name, asname):
                del node.names[i]
                break
        else:
            return False
        if not node.names:
            return self.delete_node(node)
        self.fix_node_text(node, node.as_string())
        return True

class PylintCommonFixer(PylintFixer):
    '''
    修复pylint告警之外的一些常见问题
    '''

    def __init__(self):
        PylintFixer.__init__(self, COMMON_PYLINT_MESSAGE_ID, True)
        self.enable_format_module_doc = False
        self.enable_remove_print_expression = False
        self.enable_convert_tabs = False

    @classmethod
    def get_fix_docnodes(cls, scope, doc_nodes: list):
        for bodynode in scope.body[::-1]:
            if isinstance(bodynode, nodes.FunctionDef):
                for child in bodynode.body[::-1]:
                    if isinstance(child, nodes.FunctionDef):
                        doc_nodes.append(child.doc_node)
                doc_nodes.append(bodynode.doc_node)
            elif isinstance(bodynode, nodes.ClassDef):
                for child in bodynode.body[::-1]:
                    if isinstance(child, nodes.FunctionDef):
                        doc_nodes.append(child.doc_node)
                    elif hasattr(child, 'body'):
                        cls.get_fix_docnodes(child, doc_nodes)
                doc_nodes.append(bodynode.doc_node)
            elif hasattr(bodynode, 'body'):
                cls.get_fix_docnodes(bodynode, doc_nodes)

    def format_doc_str(self):
        '''
        格式化(模块/类/函数/方法)的文档字符串,对齐边界,保持整齐好看的排列方式
        '''
        module = self.get_module()
        if module is None:
            return False
        fix_docs = 0
        fix_docnodes = []
        self.get_fix_docnodes(module, fix_docnodes)
        fix_docnodes.append(module.doc_node)
        for docnode in fix_docnodes:
            fix_docs += self.fix_doc_node(docnode)
        log.debug('fix docstr nodes count is %d', fix_docs)
        return fix_docs > 0

    def fix_doc_node(self, docnode):
        if docnode is None:
            return 0
        return int(self.fix_docstr_position(docnode))

    def fix_message(self, msg):
        try:
            self.load_module(msg.filepath, reload=True)
        except RuntimeError as ex:
            log.error(str(ex))
            return False
        ret = False
        if self.enable_format_module_doc:
            suc = self.format_doc_str()
            if suc:
                ret = suc
                self.load_module(msg.filepath, reload=True)
        if self.fix_module_imports_blank_line():
            ret = True
            self.load_module(msg.filepath, reload=True)
        if self.enable_remove_print_expression:
            rem_suc = self.remove_print_statements(msg)
            if rem_suc:
                ret = rem_suc
                try:
                    self.load_module(msg.filepath, reload=True)
                except RuntimeError as ex:
                    log.error("remove print statements error:%s", str(ex))
        if self.enable_convert_tabs:
            suc = self.convert_tabs_to_spaces()
            if suc:
                ret = suc
        return ret

    def fix_module_imports_blank_line(self):
        '''
        清除导入语句之间的空行
        '''
        importutils = self.get_import_nodes_visitor()
        top_import_nodes = importutils.get_top_import_nodes()
        if not top_import_nodes:
            return False
        start_line = top_import_nodes[0].lineno
        end_line = top_import_nodes[-1].lineno
        del_lines = []
        for i in range(start_line - 1, end_line):
            line_text = self.get_line_text(i)
            if not line_text.strip():
                del_lines.append(i)
        if not del_lines:
            return False
        del_lines.sort(reverse=True)
        for del_line_index in del_lines:
            self.delete_text_line(del_line_index)
        return True

    def remove_print_statements(self, msg):
        '''移除打印(print)语句'''
        line_count = self.get_line_count()
        # 按行号大小倒序遍历
        ret = False
        for i in range(line_count, 0, -1):
            node = self.find_node_on_line(i)
            if node is None:
                line_text = self.get_line_text(i - 1)
                log.error(
                    'could not find ast node on line %d with line text `%s`',
                    i + 1,
                    line_text
                )
                continue
            if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call) and (
                isinstance(node.value.func, nodes.Name) and node.value.func.name == "print"
            ):
                try:
                    ret = self.delete_node(node, delete_node_line=True, check_deleteable=True)
                    if ret:
                        self.load_module(msg.filepath, reload=True)
                except DeleteNodeError as ex:
                    log.error('remove print statement error:%s', str(ex))
        return ret
