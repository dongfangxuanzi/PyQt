import builtins

def get_builtin_exceptions(exceptions: list):
    '''搜集所有内建异常类型'''
    for name in dir(builtins):
        builtinobj = getattr(builtins, name)
        if isinstance(builtinobj, type) and issubclass(builtinobj, Exception):
            exceptions.append(name)
