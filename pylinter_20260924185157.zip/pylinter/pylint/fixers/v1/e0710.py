import logging
from astroid import nodes
import astroid
from .... import fileutils
from ....pylint_fix import PylintFixer


log = logging.getLogger(__name__)


class PylintE0710Fixer(PylintFixer):
    '''
    规则说明:异常类没有继承自Exception
    '''

    def __init__(self):
        super().__init__('E0710', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if not isinstance(node, nodes.Raise):
            return False
        target_node = None
        if isinstance(node.exc, nodes.Name):
            target_node = node.exc
        elif isinstance(node.exc, nodes.Call):
            target_node = node.exc.func
        else:
            log.error('invalid type node %s', node)
            return False
        try:
            for infered in target_node.infer():
                if infered == astroid.Uninferable:
                    continue
                # 节点定义在其它文件
                if not fileutils.ComparePath(msg.filepath, infered.root().file):
                    log.error("infer node define in different file path %s", infered.root().file)
                    return False
                if isinstance(infered, (nodes.ClassDef, astroid.Instance)):
                    position = infered.position
                    if not infered.bases:
                        self.add_range_text(position.lineno, position.end_col_offset, "(Exception)")
                    else:
                        base_class_node = infered.bases[0]
                        self.fix_node_text(base_class_node, "Exception")
                    return True
        except astroid.InferenceError as ex:
            log.error(str(ex))
        return False
