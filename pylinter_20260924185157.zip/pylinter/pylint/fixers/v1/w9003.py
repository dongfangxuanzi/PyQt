'''
Name:        w9003.py
Purpose:     类方法排序规则
Author:      wukan
Created:     2026-05-26
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
import logging
from astroid import nodes
from ....node_scope import ScopeFinder
from .... import constants
from .... import node_utils
from ....multifixer import MultiOptionFixer
from ....pylint_fix import PylintFixer
log = logging.getLogger(__name__)


class PylintW9003Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:类方法按规则排序
    '''

    def __init__(self):
        super().__init__('W9003', True)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Adjust function order',
            descr='Choose one order position',
            init_options=[
                'Reverse function node position',
                'Insert bottom function node position',
                'Insert top function node position'
            ]
        )

    def reserve_nodes_position(self, top_node, bottom_node):
        '''
        调换2个节点的位置
        '''
        top_line_texts = self.get_scope_range_texts(top_node)
        bottom_line_texts = self.get_scope_range_texts(bottom_node)
        self.replace_function_scope_range(
            bottom_node, top_line_texts + constants.LF)
        self.replace_function_scope_range(
            top_node, bottom_line_texts + constants.LF)
        return True

    def insert_top_position(self, top_node, bottom_node):
        '''
        将底部的节点插入顶部节点的上方
        '''
        bottom_line_texts = self.get_scope_range_texts(bottom_node)
        bottom_comment_lines = self.get_function_top_comment_lines(bottom_node)
        self.delete_node(bottom_node, delete_node_line=True)
        if bottom_comment_lines:
            for bottom_comment_line in bottom_comment_lines:
                self.delete_text_line(bottom_comment_line)

        start_line = top_node.lineno
        top_comment_lines = self.get_function_top_comment_lines(top_node)
        if top_comment_lines:
            start_line = top_comment_lines[-1]
        self.add_range_text(start_line, 0, bottom_line_texts + constants.LF)
        return True

    def insert_bottom_position(self, top_node, bottom_node):
        '''
        将上方的节点插入底部节点的下方
        '''
        top_line_texts = self.get_scope_range_texts(top_node)
        top_comment_lines = self.get_function_top_comment_lines(top_node)
        self.add_range_text(
            bottom_node.end_lineno + 1,
            0,
            constants.LF + top_line_texts + constants.LF
        )
        self.delete_node(top_node, delete_node_line=True)
        if top_comment_lines:
            for top_comment_line in top_comment_lines:
                self.delete_text_line(top_comment_line)
        return True

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        res = re.search(r'`(.*)` should be after `(.*)` \(class-method-order\)', msg.msg)
        method_quaname, after_method_quaname = res.groups()
        method_quaname_list = method_quaname.split(".")
        if len(method_quaname_list) > 2:
            log.error(
                'method name `%s` is invalid when fix rule %s',
                method_quaname,
                self.ruleid
            )
            return False
        class_name, method_name = method_quaname_list
        class_name, after_method_name = after_method_quaname.split(".")
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and (
            node.parent.name == method_name and node.parent.parent.name == class_name
        ):
            self.get_selection()
            top_function = node.parent
            bottom_function = ScopeFinder.get_class_method_node(
                top_function.parent,
                after_method_name
            )
            if node_utils.is_function_property(bottom_function)[0]:
                property_get_func, property_set_func = ScopeFinder.get_class_function_property_node(
                    top_function.parent,
                    after_method_name
                )
                if property_get_func.lineno <= top_function.lineno:
                    bottom_function = property_set_func
                else:
                    bottom_function = property_get_func
            # after后面的函数必须处于下方
            if bottom_function is None or bottom_function.lineno <= top_function.lineno:
                return False
            if not self.selection:
                return self.reserve_nodes_position(top_function, bottom_function)
            if self.selection == 1:
                return self.insert_top_position(top_function, bottom_function)
            if self.selection == 2:
                return self.insert_bottom_position(top_function, bottom_function)
        return False
