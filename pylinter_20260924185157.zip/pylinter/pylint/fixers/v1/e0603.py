# -*- coding: utf-8 -*-
'''
Name:        e0603.py
Purpose:     E0603:修复模块__all__导出未定义的变量
Author:      wukan
Created:     2023-11-16
Copyright:   (c) wukan 2023
Licence:     <your licence>
'''
import re
from astroid import nodes
from .... import node_utils
from ....pylint_fix import PylintFixer


class PylintE0603Fixer(PylintFixer):
    '''
    规则说明: 模块__all__导出未定义的变量
    '''

    def __init__(self):
        super().__init__('E0603', True)

    def fix_message(self, msg):
        res = re.search(
            r"Undefined variable name '(.*)' in __all__ \(undefined-all-variable\)",
            msg.msg
        )
        undefined_name = res.groups()[0]
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Assign) and isinstance(node.value, nodes.List):
            targets = node.targets
            if isinstance(targets[0], nodes.AssignName) and targets[0].name == "__all__":
                for i, elt in enumerate(node.value.elts):
                    if node_utils.is_const_type(elt, str) and elt.value == undefined_name:
                        del node.value.elts[i]
                        break
                else:
                    return False
                if not node.value.elts:
                    return self.delete_node(node)
                self.fix_node(node.value)
                return True
        return False
