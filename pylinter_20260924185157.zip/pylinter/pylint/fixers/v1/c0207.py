'''
Name:        c0207.py
Purpose:
Author:      wukan
Created:     2026-05-10
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from ....node_scope import ScopeFinder
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintC0207Fixer(PylintFixer):
    '''
    规则说明:字符串分割时指定最大分割数(只分割一部分), 默认分割整个字符串
    '''

    def __init__(self):
        super().__init__('C0207', True)

    def fix_message(self, msg):
        msgnode = self.find_msg_node(msg, use_column=True)
        if not msgnode:
            return False
        res = re.search(r"Use (.*) instead \(use-maxsplit-arg\)", msg.msg)
        if not res:
            return False
        repnode_text = res.groups()[0]
        scope_finder = ScopeFinder(self.get_module())
        if scope_finder.is_parent_node_classtype(msgnode, nodes.Call):
            pnodes = scope_finder.get_parent_nodes_by_classtype(msgnode, nodes.Call)
            for pnode in pnodes:
                if isinstance(pnode.func, nodes.Attribute) and pnode.func.attrname == "split":
                    self.fix_node_text(pnode.parent, repnode_text)
                    return True
        return False
