import os
import re
from astroid import nodes
import astroid
from ....node_utils import infer_all
from ....node_scope import ScopeFinder
from ....define import SELF_ARG_NAME, CLASS_INIT_METHOD
from ....pylint_fix import PylintFixer
from ....multifixer import MultiOptionFixer
from .e0601 import PylintE0601Fixer


##class AttributeInitDialog(simpledialog.SingleChoiceDialog):
##    def __init__(self, title, descrption, choices, selection, master):
##        super().__init__(
##            title,
##            descrption,
##            choices,
##            selection,
##            master
##        )
##        self.rb_remove_attr = QRadioButton('Remove attribute node')
##        self.layout.insertWidget(2, self.rb_remove_attr)


class PylintW0201Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:在__init__方法外初始化类属性
    '''

    def __init__(self):
        super().__init__('W0201', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Init self attribute name',
            init_options=PylintE0601Fixer.get_init_values().values()
        )
        self.remove_attr = False

    @staticmethod
    def get_class_func(funcname, classnode):
        for childnode in classnode.body:
            if isinstance(childnode, nodes.FunctionDef) and childnode.name == funcname:
                return childnode
        return None

    def get_selection(self):
        if self.fix_only_autofix():
            return
        choices = self._options
        dlg = AttributeInitDialog(
            self.title,
            self.description,
            choices,
            selection=self.selection,
            master=self._textctrl
        )
        dlg.exec_()
        self._sel = dlg.selection
        self.remove_attr = dlg.rb_remove_attr.isChecked()

    def fix_message(self, msg):
        self.fix_importnodes()
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r"Attribute '(.*)' defined outside __init__ \(attribute-defined-outside-init\)",
            msg.msg
        )
        classnode = ScopeFinder(self.get_module()).get_class_scope(node)
        if not classnode:
            return False
        attrname = res.groups()[0]
        if isinstance(node, nodes.Name) and node.name == SELF_ARG_NAME and (
            isinstance(node.parent, nodes.AssignAttr) and attrname == node.parent.attrname
        ):
            init_method_node = self.get_class_func(CLASS_INIT_METHOD, classnode)
            if init_method_node is None:
                return False
            descrption = "Please choose attribute '%s' one initial value" % attrname
            self.set_description(descrption)
            self.get_selection()
            init_values = PylintE0601Fixer.get_init_values()
            if self.remove_attr:
                self.delete_node(node.parent.parent)
            node_method = ScopeFinder.get_function_scope(node)
            base_node_method = None
            for basenode in classnode.bases:
                base_classes = infer_all(basenode)
                # 基类是否重载了相同名称的方法
                if base_classes and base_classes[0] != astroid.Uninferable:
                    base_node_method = ScopeFinder.get_class_method_node(
                        base_classes[0],
                        node_method.name
                    )
                    if base_node_method:
                        break
            first_body = init_method_node.body[0]
            insert_line = first_body.lineno
            # 初始化语句是放在调用__init__方法之前还是之后需要特别注意,否则可能导致代码运行错误,
            # 尤其是在基类有重载方法的情况下
            if self.is_init_call_node(first_body) and not base_node_method:
                insert_line += 1
            blanks = first_body.col_offset * ' '
            init_atr_value = list(init_values.keys())[self.selection]
            self.add_range_text(
                insert_line,
                0,
                blanks + f'{node.parent.as_string()}={init_atr_value}' + os.linesep
            )
            return True
        return False
