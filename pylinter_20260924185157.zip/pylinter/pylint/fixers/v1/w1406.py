from .... import node_utils
from ....pylint_fix import PylintFixer


class PylintW1406Fixer(PylintFixer):
    '''
    规则说明:unicode字符串不需要加u前缀
    '''

    def __init__(self):
        super().__init__('W1406', True)

    def fix_message(self, msg):
        line = msg.line
        node = self.find_msg_node(msg, use_column=True)
        if node_utils.is_const_type(node, str):
            linetext = self.get_msg_line_text(msg)
            if linetext.find("u'") != -1 or linetext.find('u"') != -1:
                newlinetext = linetext.replace("u'", self.SINGLE_QUOTE).replace(
                    'u"',
                    self.DOUBLE_QUOTE
                )
                self.replace_line_text(line, newlinetext)
                return True
        return False
