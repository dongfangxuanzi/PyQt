from astroid import nodes
from ....node_scope import ScopeFinder
from ....pylint_fix import PylintFixer


class PylintE1142Fixer(PylintFixer):
    '''
    规则说明: await必须和async def一起使用
    '''

    def __init__(self):
        super().__init__('E1142', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        scope = ScopeFinder.get_function_scope(node)
        if isinstance(node, nodes.Await) and not isinstance(scope, nodes.AsyncFunctionDef):
            blanks = scope.position.col_offset * ' '
            self.add_range_text(
                scope.position.lineno,
                0,
                blanks + 'async '
            )
            return True
        return False
