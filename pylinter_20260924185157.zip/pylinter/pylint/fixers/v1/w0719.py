'''
Name:        w0719.py
Purpose:
抛出异常捕获范围Exception/BaseException太宽泛,需要抛出具体类型的子异常
修复方法:
弹出所有内建异常类型,用户选择抛出某个异常类型
Author:      wukan
Created:     2026-08-13
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from ....utility import get_builtin_exceptions
from ....multifixer import MultiOptionFixer
from ....pylint_fix import PylintFixer


class PylintW0719Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:raise抛出Exception异常,太宽泛了
    '''

    def __init__(self):
        super().__init__('W0719', False)
        MultiOptionFixer.__init__(
            self,
            title='Fix raise bare except',
            descr="Please choose one exception type"
        )

    @staticmethod
    def is_bare_exception(exc):
        if isinstance(exc, nodes.Name) and exc.name in ['Exception', 'BaseException']:
            return True
        if isinstance(exc, nodes.Call) and isinstance(exc.func, nodes.Name) and (
            exc.func.name in ['Exception', 'BaseException']
        ):
            return True
        return False

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Raise) and self.is_bare_exception(node.exc):
            if not self._options:
                # 搜集所有内建异常类型
                get_builtin_exceptions(self._options)
            self.get_selection()
            raise_str = "%s" % self._options[self.selection]
            if isinstance(node.exc, nodes.Name):
                self.fix_node_text(node.exc, raise_str)
            else:
                self.fix_node_text(node.exc.func, raise_str)
            return True
        return False
