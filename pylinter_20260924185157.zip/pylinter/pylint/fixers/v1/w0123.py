import os
from astroid import nodes
from .... import constants
from ....pylint_fix import PylintFixer


class PylintW0123Fixer(PylintFixer):
    '''
    规则说明:使用eval
    '''

    def __init__(self):
        super().__init__('W0123', False)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        if isinstance(node.parent, nodes.Call) and (
            isinstance(node, nodes.Name) and node.name == "eval"
        ):
            if not self.ask_question(
                'Fix eval expression',
                'Are you ensure the string only contains double quote `"`? otherwise please use json.dumps to format str'
            ):
                return False
            self.fix_node_text(node, 'json.loads')
            visitor = self.get_import_nodes_visitor()
            if isinstance(node.parent.parent, nodes.Assign):
                assign_node = node.parent.parent
                target_name = assign_node.targets[0].as_string()
                last_line_chars = self._textctrl.get_line(node.lineno - 1, last_append_linend=False)
                if last_line_chars.endswith((constants.CR, constants.LF, constants.CRLF)):
                    add_char = ''
                else:
                    add_char = os.linesep
                replacestr = f"assert(isinstance({target_name}, (list, dict)))"
                self.add_range_text(
                    node.lineno + 1,
                    0,
                    add_char + assign_node.col_offset * ' ' + replacestr + os.linesep
                )
            if not visitor.is_import_exist('json'):
                insert_line = visitor.get_import_line()
                self.add_range_text(insert_line + 1, 0, "import json" + os.linesep)
            return True
        return False
