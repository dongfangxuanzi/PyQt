from typing import cast
from astroid import nodes
from ....node_scope import ScopeFinder
from ....multifixer import MultiOptionFixer
from ....pylint_fix import PylintFixer


class PylintE1120Fixer(PylintFixer):
    '''
    规则说明: 成员方法按类方法方式调用了
    '''

    def __init__(self):
        super().__init__('E1120', False)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        scope = ScopeFinder.get_function_scope(node)
        if isinstance(node, nodes.Name) and scope and scope.is_method() and isinstance(scope.parent, nodes.ClassDef):
            class_def = cast(nodes.ClassDef, scope.parent)
            basenames = [base.as_string() for base in class_def.bases]
            if node.name in basenames:
                self.fix_node_text(node, 'self')
                return True
        return False


class PylintE1121Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明: 调用函数的参数过多
    '''

    def __init__(self):
        super().__init__('E1121', False)
        MultiOptionFixer.__init__(self, 0, 'Remove more argument', 'Choose one removed argument')

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        parent_node = ScopeFinder.get_parent_node_by_nodeclass(node, nodes.Call)
        if parent_node is not None:
            args = [arg.as_string() for arg in parent_node.args]
            self._options = args
            self.get_selection()
            index = self._sel
            del parent_node.args[index]
            self.fix_node(parent_node)
            return True
        return False
