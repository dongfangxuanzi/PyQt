import re
from astroid import nodes
from ....node_scope import ScopeFinder
from ....pylint_fix import PylintFixer


class PylintW0221Fixer(PylintFixer):
    '''
    规则说明: 继承方法的参数个数改变了
    '''

    def __init__(self):
        super().__init__('W0221', False)

 #   @append_doc_path
    def fix_message(self, msg):
        regstr = r"was (\d+) in '(.*)' and is now (\d+) in overriding '(.*)' method"
        res = re.search(regstr, msg.msg)
        parent_class_name = None
        if res is None:
            res = re.search("Variadics removed in overriding '(.*)' method", msg.msg)
            derived_method = res.groups()[0]
        else:
            _parent_arg_num, parent_method, _derived_arg_num, derived_method = res.groups()
            parent_class_name, _parent_method_name = parent_method.split('.')
        derived_class_name, derived_method_name = derived_method.split('.')
        node = self.find_msg_node(msg)
        pnode = node.parent
        if isinstance(node, nodes.Name) and node.name == derived_method_name and (
            isinstance(pnode, nodes.FunctionDef)
        ):
            if isinstance(pnode.parent, nodes.ClassDef) and pnode.parent.name == derived_class_name:
                class_node = pnode.parent
                mros = class_node.mro()
                mros.remove(class_node)
                for mro in mros:
                    if parent_class_name is None or mro.name == parent_class_name:
                        base_node_method = ScopeFinder.get_class_method_node(mro, pnode.name)
                        if base_node_method:
                            args = base_node_method.args
                            self.fix_funcdef_args(pnode, args.as_string())
                            return True
        return False
