from ....node_scope import ScopeFinder
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR0202Fixer(PylintFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('R0202', False)

    def fix_message(self, msg):
        return False


class PylintR0203Fixer(PylintFixer):
    '''
    规则说明:xxx = staticmethod(xxx)
    staticmethod赋值给类方法,可以使用staticmethod装饰符装饰方法
    '''

    def __init__(self):
        super().__init__('R0203', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Assign) and isinstance(node.value, nodes.Call):
            call_node = node.value
            if isinstance(call_node.func, nodes.Name) and call_node.func.name == "staticmethod":
                if not call_node.args:
                    return False
                first_arg = call_node.args[0]
                first_arg_name = first_arg.as_string()
                parent_scope = ScopeFinder.get_parent_class_node(node)
                target_name = node.targets[0].as_string()
                if target_name == first_arg_name:
                    method_scope = ScopeFinder.get_class_method_node(parent_scope, target_name)
                    self.delete_node(node, delete_node_line=True)
                    blanks = method_scope.position.col_offset * ' '
                    self.add_range_text(
                        method_scope.position.lineno,
                        0,
                        blanks + '@staticmethod' + '\n'
                    )
                    return True
        return False
