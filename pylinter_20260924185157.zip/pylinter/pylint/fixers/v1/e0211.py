import re
from ....define import CLASS_METHOD_NAME
from astroid import nodes
from ....codeutils import get_node_col_offset_blanks
from ....pylint_fix import PylintFixer


class PylintE0211Fixer(PylintFixer):
    '''
    规则说明:类成员方法参数为空,至少需要有1个self参数
    '''

    def __init__(self):
        super().__init__('E0211', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        res = re.search(
            r"Method '(.*)' has no argument \(no-method-argument\)",
            msg.msg
        )
        nodename = res.groups()[0]
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and nodename == node.name:
            if CLASS_METHOD_NAME == node.parent.type:
                start_line = node.lineno
                if not node.parent.args.args:
                    newtext = get_node_col_offset_blanks(node.parent) + f"def {node.name}(cls):"
                    self.replace_line_text(start_line, newtext)
                return True
        return False
