import os
import os.path
from typing import Optional
import re
from .encodings import UTF8_ENCODING
from . import fileutils


def get_filename_without_ext(file_path_name):
    filename = os.path.basename(file_path_name)
    return os.path.splitext(filename)[0]


def get_file_linetext(filepath, lineindex):
    content = fileutils.get_file_content(filepath, allow_exception=False)
    if content is None:
        return None
    linetext = content.splitlines()[lineindex]
    return linetext


def is_none_empty(value: Optional[str]):
    '''
    判断字符串为None或者空
    '''
    if value is None:
        return True
    if value == "":
        return True
    return False


def normalize_line_endings(lines, newline):
    """
    Return fixed line endings.
    All lines will be modified to use the most common line ending.
    """
    line = [line.rstrip('\n\r') + newline for line in lines]
    if line and lines[-1] == lines[-1].rstrip('\n\r'):
        line[-1] = line[-1].rstrip('\n\r')
    return line


def docstring_summary(docstring):
    """Return summary of docstring."""
    return docstring.split('\n')[0] if docstring else ''


def ensure_string(s, encoding=UTF8_ENCODING, errors='strict'):
    if isinstance(s, str):
        return s
    if isinstance(s, (bytes, bytearray)):
        return str(s, encoding=encoding)
    raise ValueError(
        "Expected str or bytes or bytearray, received %s." %
        type(s))


def bool_to_str(b_val):
    return "true" if b_val else "false"


def get_file_extension(filename, tolower=True, keepdot=False):
    basename = os.path.basename(filename)
    names = basename.split(".")
    if len(names) == 1:
        return ""
    if tolower:
        ext = names[-1].lower()
    else:
        ext = names[-1]
    if keepdot:
        ext = "." + ext
    return ext


def make_name_end_in_extension(name, extension):
    if not name:
        return name
    ext = get_file_extension(name)
    if ext == extension:
        return name
    return name + extension


def _split_comma_separated(string):
    """Return a set of strings."""
    return {text.strip() for text in string.split(',') if text.strip()}


def find_chinese_character(linestr):
    res = re.search('[\u4e00-\u9fa5]+', linestr)
    if res:
        return True
    return False
