import os
import logging
from astroid import nodes
from ....pylint_fix import PylintFixer
log = logging.getLogger(__name__)


class PylintC0415Fixer(PylintFixer):
    '''
    规则说明:导入语句应该放在模块开头
    '''

    def __init__(self):
        super().__init__('C0415', self.FixKind.SINGLEFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if not isinstance(node, (nodes.Import, nodes.ImportFrom)):
            return False
        visitor = self.get_import_nodes_visitor()
        insert_line = visitor.get_import_line()
        self.delete_node(node)
        self.add_range_text(insert_line + 1, 0, node.as_string() + os.linesep)
        return True
