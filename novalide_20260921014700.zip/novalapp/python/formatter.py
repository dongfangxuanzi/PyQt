import logging
from .. import constants
from . import utility
from .ui import EncodingdeclareDialog
from ..lib.pyqt import QMessageBox
from .parser.importnodes import ImportsVisitor
from .. import _
log = logging.getLogger(__name__)


class PythoncodeFormatter:
    """description of class"""

    def insert_declare_encoding(self, prompt=True):
        lines = self.GetCtrl().GetTopLines(constants.ENCODING_DECLARE_LINE_NUM)
        coding_name, line_num = utility.get_python_coding_declare(lines)
        # 将下面几步操作作为一个整体,在执行回退时会整体回退操作
        self.GetCtrl().beginUndoAction()
        if coding_name is not None:
            if prompt:
                ret = QMessageBox.question(
                    self.GetFrame(),
                    _("Declare encoding"),
                    _("The Python Document have already declare coding,Do you want to overwrite it?"),
                    QMessageBox.Yes | QMessageBox.No
                )
                if ret != QMessageBox.Yes:
                    return
            self.GetCtrl().set_sel(
                self.GetCtrl().position_from_linecol(line_num - 1),
                self.GetCtrl().position_from_linecol(line_num)
            )
            self.GetCtrl().DeleteBack()
        if prompt:
            dlg = EncodingdeclareDialog(self.GetFrame())
            if dlg.exec_() == EncodingdeclareDialog.Accepted:
                self.GetCtrl().GotoPos(0, 0)
                self.AddText(dlg.name_entry.text() + "\n")
        else:
            self.AddText(EncodingdeclareDialog.DEFAULT_ENCODING_DECLARE + "\n")
        self.GetCtrl().endUndoAction()

    def insert_main_statement(self):
        line = self.GetCtrl().get_current_line()
        pos = self.GetCtrl().position_from_linecol(line)
        self.AddText(
            'if __name__ == "__main__":\n%s' % (
                constants.DEFAULT_TAB_INDENTATION_WIDTH * ' '),
            pos
        )

    def insert_logging_statement(self):
        if self.Module is None:
            log.error("code file %s syntax module is null", self.GetDocument().GetFilename())
            return
        imports_visitor = ImportsVisitor(self.Module, self)
        line = imports_visitor.get_import_line(top_imports=True)
        pos = self.GetCtrl().position_from_linecol(line)
        logging_mod_name = 'logging'
        add_log_text = ''
        if not imports_visitor.is_import_exist(logging_mod_name):
            add_log_text += f'import {logging_mod_name}\n'
        add_log_text += f"log={logging_mod_name}.getLogger(__name__)\n"
        self.AddText(
            add_log_text,
            pos
        )
