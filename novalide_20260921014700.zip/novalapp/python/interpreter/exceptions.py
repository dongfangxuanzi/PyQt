'''
Name:        exceptions.py
Purpose:     解释器所有相关的异常
Author:      wukan
Created:     2026-08-22
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''


class InterpreterError(Exception):
    '''解释器相关的异常'''


class NotsupportInterpreterError(InterpreterError):
    '''不支持的python的解释器'''


class UnknownVersionInterpreterError(InterpreterError):
    '''未知版本的解释器'''


class InvalidInterpreterError(InterpreterError):
    '''不是有效的解释器'''


class InterpreternameExistError(InterpreterError):
    '''解释器名称已经存在'''


class InterpreterpathExistError(InterpreterError):
    '''解释器路径已经存在'''


class InterpretertoolNotExistError(Exception):
    '''解释器安装路径下不存在某个工具'''


class InterpreterSyntaxError(Exception):
    '''解释器语法错误'''


class InterpreterNotExistError(InterpreterError):
    '''解释器不存在'''


class UnParseableSyntaxMessage(Exception):
    '''
    无法解析语法错误信息
    '''


class BaseinterpreterNotExistError(InterpreterError):
    '''虚拟解释器的基础解释器路径不存在'''


class InterpreterPathNotExistError(InterpreterError):
    '''解释器路径不存在'''
    ERROR_MSG = "Interpreter path not exist"


class InterpreterPipNotFoundError(Exception):
    '''解释器pip工具未安装或已损坏'''
    ERROR_MSG = "No module named pip"


class InterpreterLaunchError(InterpreterError):
    '''解释器启动失败'''
    ERROR_MSG = "Interpreter launch error"
