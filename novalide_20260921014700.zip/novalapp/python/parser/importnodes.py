import re
from astroid import nodes


class ImportsVisitor:
    def __init__(self, module, textview):
        self._module = module
        self._textview = textview

    def is_import_exist(self, modname):
        for child in self._module.body:
            if isinstance(child, nodes.Import):
                names = [name[0] for name in child.names]
                if modname in names:
                    return True
        return False

    def is_fromimport_exist(self, modname, import_name):
        for child in self._module.body:
            if isinstance(child, nodes.ImportFrom):
                if child.modname == modname:
                    return import_name in [name[0] for name in child.names]
        return False

    def get_import_nodes(self):
        '''
        获取模块范围内的所有导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, (nodes.Import, nodes.ImportFrom)):
                import_nodes.append(child)
        return import_nodes

    def get_top_import_nodes(self):
        '''
        获取模块开头的导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, nodes.Assign):
                valid_targets = [
                    isinstance(target, nodes.AssignName)
                    and target.name.startswith("__")
                    and target.name.endswith("__")
                    for target in child.targets
                ]
                if all(valid_targets):
                    continue
            if not isinstance(child, (nodes.Import, nodes.ImportFrom)):
                break
            import_nodes.append(child)
        return import_nodes

    def get_lastimport_node(self, top_imports):
        if top_imports:
            import_nodes = self.get_top_import_nodes()
        else:
            import_nodes = self.get_import_nodes()
        if not import_nodes:
            return None
        return import_nodes[-1]

    def is_fromimport_node_multilines(self, fromimport_node):
        '''from xx import结点是否多行'''
        if not isinstance(fromimport_node, nodes.ImportFrom) or len(fromimport_node.names) <= 1:
            return False
        node_line_text = self._textview.GetCtrl().get_line_text(fromimport_node.lineno - 1)
        matched = re.match(r"from\s+.+\s+import\s+\(", node_line_text)
        if not matched:
            return False
        return True

    def get_import_line(self, top_imports=False):
        last_node = self.get_lastimport_node(top_imports)
        if last_node is not None:
            if self.is_fromimport_node_multilines(last_node):
                # from xx import节点存在多行时,结点的行列号值不准确,获取下一个节点的行号
                next_sibl_node = last_node.next_sibling()
                if next_sibl_node is not None:
                    return next_sibl_node.lineno - 1
                return self._textview.GetCtrl().lines() - 1
            return last_node.lineno
        if self._module.doc_node is None:
            shebang_or_encoding_line = self._textview.get_shebang_encoding_line()
            return shebang_or_encoding_line
        return self.get_docstring_line()

    def get_docstring_line(self):
        return self._module.doc_node.end_lineno
