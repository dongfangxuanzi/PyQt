from ...util import utils, ui_utils
from ...lib.pyqt import Qt, QCheckBox, QMessageBox
from ... import _
from ... import globalkeys, get_app


class IntelliSenseOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    代码解析配置面板
    """

    def __init__(self, master):
        """
        Initializes the panel by adding an "Options" folder tab to the parent notebook and
        populating the panel with the generic properties of a pydocview application.
        """
        super().__init__()
        self.layout.setAlignment(Qt.AlignTop)

        self.enable_codeparser_checkbox = QCheckBox(
            _("Enable code parser processor (for project)"))
        self.layout.addWidget(self.enable_codeparser_checkbox)
        self.enable_codeparser_checkbox.setChecked(
            utils.profile_get_int(globalkeys.ENABLE_CODEPARSER_KEY, True))

        self.open_readonly_checkbox = QCheckBox(
            _("Open the code definition file in read-only mode"))
        self.open_readonly_checkbox.setToolTip(_("Current project file excluded"))
        self.layout.addWidget(self.open_readonly_checkbox)
        self.open_readonly_checkbox.setChecked(
            utils.profile_get_int(globalkeys.OPEN_DEFINITION_READONLY_KEY, True))

        self.parse_import_statement_checkbox = QCheckBox(
            _("Parse the import statement as a member of current module")
        )
        self.layout.addWidget(self.parse_import_statement_checkbox)
        self.parse_import_statement_checkbox.setChecked(
            utils.profile_get_int(globalkeys.PARSE_IMPORTS_TATEMENT_KEY, False))

        self.prohibit_star_import_statement_checkbox = QCheckBox(
            _("Prohibit the parsing of import statement that contain *"))
        self.layout.addWidget(self.prohibit_star_import_statement_checkbox)
        self.prohibit_star_import_statement_checkbox.setChecked(
            utils.profile_get_int(globalkeys.PROHIBIT_STAR_IMPORT_STATEMENT_KEY, True))

    def OnOK(self, options_dialog):
        is_codeparser_checked = self.enable_codeparser_checkbox.isChecked()
        is_codeparser_enabled = utils.profile_get_int(globalkeys.ENABLE_CODEPARSER_KEY, True)
        is_codeparser_enable_changed = is_codeparser_checked != is_codeparser_enabled
        if not is_codeparser_checked and is_codeparser_enable_changed:
            QMessageBox.warning(
                self,
                _('Warning'),
                _('Code intellisense function will be effected!')
            )
        utils.profile_set(globalkeys.ENABLE_CODEPARSER_KEY, is_codeparser_checked)
        project_browser = get_app().MainFrame.projectview
        project_browser.codeparser_processor.enabled = is_codeparser_checked
        utils.profile_set(globalkeys.OPEN_DEFINITION_READONLY_KEY,
                          self.open_readonly_checkbox.isChecked())
        utils.profile_set(globalkeys.PROHIBIT_STAR_IMPORT_STATEMENT_KEY,
                          self.prohibit_star_import_statement_checkbox.isChecked())
        utils.profile_set(globalkeys.PARSE_IMPORTS_TATEMENT_KEY,
                          self.parse_import_statement_checkbox.isChecked())
        return True
