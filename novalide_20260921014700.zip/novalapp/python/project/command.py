from ...project.command import ProjectAddFolderCommand


class ProjectAddPackagefolderCommand(ProjectAddFolderCommand):
    def __init__(self, view, doc, folderpath):
        ProjectAddFolderCommand.__init__(self, view, doc, folderpath)

    def AddFolder(self):
        return self._view.add_package_folder(self._folderpath)
