# -*- coding: utf-8 -*-
from .... import get_app, _
from ..commandui import BaseDebuggerUI
from ....lib.pyqt import (
    QFrame,
    QVBoxLayout,
    QMessageBox,
    Qt,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSizePolicy,
    QPlainTextEdit,
    QColor,
    QBrush,
    QTextCursor
)


class InspectConsoleTab(QFrame):
    """description of class"""

    def __init__(self, parent):
        super().__init__(parent)
        framebox = QVBoxLayout()
        framebox.setContentsMargins(0, 5, 0, 0)
        framebox.setSpacing(0)
        self.setLayout(framebox)
        rowbox = QHBoxLayout()
        rowbox.addWidget(QLabel(text=_("Cmd") + ":"))
        self._input_textctrl = QLineEdit()
        rowbox.addWidget(self._input_textctrl)
        self._input_textctrl.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        # 文本框回车键处理事件
        self._input_textctrl.returnPressed.connect(self.on_cmd_button_pressed)
        cmdbutton = QPushButton(text=_("Execute"))
        cmdbutton.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        cmdbutton.clicked.connect(self.on_cmd_button_pressed)
        rowbox.addWidget(cmdbutton)
        clrbutton = QPushButton(_("Clear"))
        clrbutton.clicked.connect(self.on_clr_button_pressed)
        clrbutton.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        rowbox.addWidget(clrbutton)
        framebox.addLayout(rowbox)

        self._output_textctrl = QPlainTextEdit(self)
        self._output_textctrl.setReadOnly(True)
        self._output_textctrl.setHorizontalScrollBarPolicy(
            Qt.ScrollBarAlwaysOff)
        framebox.addWidget(self._output_textctrl)
        self._input_textctrl.setFocus()

        self._normal_format = self._output_textctrl.currentCharFormat()
        self._error_format = self._output_textctrl.currentCharFormat()
        self._error_format.setForeground(QBrush(QColor(Qt.red)))
        self._cmdlist = []
        self._cmdindex = 0

    @property
    def inputctrl(self):
        return self._input_textctrl

    @property
    def outputctrl(self):
        return self._output_textctrl

    @staticmethod
    def execute_command(command):
        get_app().GetDebugger()._debugger_ui.framestab.ExecuteCommand(command)

    def handle_command(self):
        cmdstr = self._input_textctrl.text()
        if not cmdstr:
            return
        self._cmdlist.append(cmdstr)
        self._cmdindex = len(self._cmdlist)
        self._input_textctrl.clear()
        self.execute_command(cmdstr)

    def on_cmd_button_pressed(self):
        if not BaseDebuggerUI.DebuggerRunning():
            QMessageBox.information(
                self, get_app().GetAppName(), _("Debugger has been stopped."))
            return
        self.handle_command()

    def append_command(self, text):
        self._output_textctrl.setReadOnly(False)
        self.__append_text(text)
        self._output_textctrl.setReadOnly(True)

    def append_output(self, text):
        self._output_textctrl.setReadOnly(False)
        self.__append_text(text, True)
        self._output_textctrl.setReadOnly(True)

    def on_clr_button_pressed(self):
        self.Clear()

    def Clear(self):
        self._output_textctrl.setReadOnly(False)
        self._output_textctrl.clear()
        self._output_textctrl.setReadOnly(True)

    def __append_text(self, txt, is_error=False):
        """Append the text"""
        if txt:
            cursor = self._output_textctrl.textCursor()
            cursor.movePosition(QTextCursor.End)
            self._output_textctrl.setTextCursor(cursor)
            if is_error:
                self._output_textctrl.setCurrentCharFormat(self._error_format)
            else:
                self._output_textctrl.setCurrentCharFormat(self._normal_format)
            self._output_textctrl.insertPlainText(txt)
            self._output_textctrl.insertPlainText('\n')
            self._output_textctrl.ensureCursorVisible()
