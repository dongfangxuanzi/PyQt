'''
----------------------------------------------------------------------------
Name:         utillang.py
Purpose:      Provide language specific utilities
Author:       Joel Hare
Created:      8/23/05
CVS-ID:       $Id$
Copyright:    (c) 2004-2005 ActiveGrid, Inc.
License:      wxWindows License
----------------------------------------------------------------------------
'''
import sys
import tempfile
try:
    from UserDict import DictMixin
except ImportError:
    from collections.abc import MutableMapping as DictMixin
from xml.sax import saxutils
from . import parser

PY2WEB_codepages = {
    'cp1251': 'CP-1251',
    'koi8_r': 'KOI8-R',
}


def evalXPath(xpath, data, specialEntries=None):
    codestr = parser.xpathToCode(xpath)
    return evalCode(codestr, data, specialEntries)


def evalCode(codestr, data, special_entries=None):
    if isinstance(data, ObjAsDict):
        namespace = data
    elif isinstance(data, dict):
        namespace = dict(data)
    else:
        namespace = ObjAsDict(data)
    if special_entries:
        for key, value in special_entries.items():
            namespace.addSpecialEntry(key, value)
    return eval(codestr, {}, namespace)


def deriveCharset():
    charset = None
    encoding_string = sys.getdefaultencoding()
    if encoding_string != 'ascii':
        charset = PY2WEB_codepages.get(encoding_string.lower())
        if charset is None:
            charset = encoding_string
    return charset


def getSystemTempDir():
    return tempfile.gettempdir()


class ObjAsDict(DictMixin):
    """
    Passing this to eval as the local variables dictionary allows the
    evaluated code to access properties in the wrapped object
    """

    def __init__(self, obj):
        self.obj = obj
        self.specialEntries = {}

    def __getitem__(self, key):
        try:
            return getattr(self.obj, key)
        except AttributeError as e:
            if self.specialEntries.has_key(key):
                return self.specialEntries[key]
            raise KeyError(e.args) from e

    def __setitem__(self, key, item):
        setattr(self.obj, key, item)

    def __delitem__(self, key):
        delattr(self.obj, key)

    def keys(self):
        ret = []
        for i in list(dir(self.obj) + self.specialEntries.keys()):
            if i in ('__doc__', '__module__'):
                pass
            elif i not in ret:
                ret.append(i)
        return ret

    def addSpecialEntry(self, key, value):
        self.specialEntries[key] = value


global saxXMLescapeDoubleQuote
saxXMLescapeDoubleQuote = {'"': '&quot;'}

global saxXMLescapesAllQuotes
# IE doesn't support &apos; but it doesn't seem like we should need this escaped at all so I
# took it out.
saxXMLescapesAllQuotes = {'"': '&quot;', "'": "&#039;"}

global saxXMLunescapes
saxXMLunescapes = {'&quot;': '"', "&#039;": "'"}


def escape(data, extra_escapes=None):
    """
    Escape ', ", &, <, and > in a string of data.
    Basically, everything that saxutils.escape does (and this calls that, at
    least for now), but with " and ' added as well.
    TODO: make this faster; saxutils.escape() is really slow
    """

    if extra_escapes is None:
        extra_escapes = saxXMLescapeDoubleQuote
    return saxutils.escape(data, extra_escapes)


def unescape(data):
    """
    Unescape ', ", &, <, and > in a string of data.
    Basically, everything that saxutils.unescape does (and this calls that, at
    least for now), but with " and ' added as well.
    TODO: make this faster; saxutils.unescape() is really slow
    """

    return saxutils.unescape(data, saxXMLunescapes)
