'''
-------------------------------------------------------------------------------
Name:        objutils.py
Purpose:
Author:      wukan
Created:     2019-02-15
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import builtins
import types
from . import utillang
from . import datetimeparser

FUNCTION_HAS_ATTR = '_hasAttr'
FUNCTION_GET_ATTR = '_getAttr'
FUNCTION_SET_ATTR = '_setAttr'
FUNCTION_DEL_ATTR = '_delAttr'

PRINT_OBJ_GETATTR = 1
PRINT_OBJ_HIDE_INTERNAL = 2
PRINT_OBJ_COMPACT = 4
PRINT_OBJ_NONONE = 8
PRINT_OBJ_DIFFABLE = 16
PRINT_OBJ_HIDE_EXCLUDED = 32
PRINT_OBJ_INTERNAL = 512


class _C:
    def _m(self):
        pass


ClassType = type(_C)
DictionaryType = dict
long = int
_x = _C()
InstanceType = type(_x)
SliceType = slice
TypeType = type
XRangeType = range


def hasRawAttr(obj, name):
    if obj is None:
        return False
    if name != FUNCTION_HAS_ATTR and hasattr(obj, FUNCTION_HAS_ATTR):
        return obj._hasAttr(name)
    return name in obj.__dict__


def getRawAttr(obj, name):
    if name != FUNCTION_GET_ATTR and hasattr(obj, FUNCTION_GET_ATTR):
        return obj._getAttr(name)
    return obj.__dict__.get(name)


def setRawAttr(obj, name, value):
    if name != FUNCTION_SET_ATTR and hasattr(obj, FUNCTION_SET_ATTR):
        obj._setAttr(name, value)
    else:
        obj.__dict__[name] = value


def delRawAttr(obj, name):
    if name != FUNCTION_DEL_ATTR and hasattr(obj, FUNCTION_DEL_ATTR):
        obj._delAttr(name)
    else:
        del obj.__dict__[name]


def getStaticAttr(obj, attr):
    if isinstance(obj, type):
        class_desc = obj
    else:
        class_desc = obj.__class__
    if hasattr(class_desc, attr):
        return getattr(class_desc, attr)
    return None


def setStaticAttr(obj, attr, value):
    if isinstance(obj, type):
        classdesc = obj
    else:
        classdesc = obj.__class__
    setattr(classdesc, attr, value)


def hasAttrFast(obj, name):
    if hasRawAttr(obj, name):
        return True
    if hasattr(obj, '_complexType'):
        complex_type = obj._complexType
        element = complex_type.findElement(name)
        if element:
            return True
    if hasattr(obj, name):
        return True
    return False


def moduleForName(moduleName):
    module = None
    path_list = moduleName.split('.')
    if len(moduleName) > 0:
        module = __import__(moduleName)
        for name in path_list[1:]:
            if name in module.__dict__:
                module = module.__dict__[name]
            else:
                module = None
                break
    return module


def typeForName(typeName):
    i = typeName.rfind('.')
    if i >= 0:
        module = moduleForName(typeName[:i])
        if module is not None:
            name = typeName[i + 1:]
            if name in module.__dict__:
                return module.__dict__[name]
    elif typeName in builtins.__dict__:
        return builtins.__dict__[typeName]
    return None


def functionForName(functionName):
    ftype = typeForName(functionName)
    ftypes = (
        types.FunctionType,
        types.MethodType,
        types.BuiltinFunctionType,
        types.BuiltinMethodType
    )
    if isinstance(ftype, ftypes):
        return ftype
    return None


def classForName(className):
    ctype = typeForName(className)
    if isinstance(ctype, type):
        return ctype
    return None


def newInstance(className, objargs=None):
    "dynamically create an object based on the className and return it."

    if not isinstance(objargs, list):
        objargs = [objargs]

    if className == "None":
        return None
    if className == "bool":
        if ((len(objargs) < 1) or (objargs[0].lower() == "false") or (not objargs[0])):
            return False
        return True
    if className in ('str', 'unicode'):  # don't strip: blanks are significant
        if len(objargs) > 0:
            try:
                return utillang.unescape(objargs[0])
            except Exception:
                # 如果项目文件节点属性为?, 说明此处出现异常
                return "?"
        else:
            return ""

    if className == "date":
        return datetimeparser.parse(objargs[0], asdate=True)
    if className == "datetime":
        return datetimeparser.parse(objargs[0])
    if className == "time":
        return datetimeparser.parse(objargs[0], astime=True)

    classtype = classForName(className)
    if classtype is None:
        raise Exception("Could not find class %s" % className)

    if len(objargs) > 0:
        return classtype(*objargs)
    return classtype()


def getClassProperty(classType, propertyName):
    return getattr(classType, propertyName)


def toDiffableRepr(value, maxLevel=None):
    if value is None:
        return "None"
    if maxLevel is None:
        maxLevel = 8
    maxLevel -= 1
    if maxLevel < 0:
        return typeToString(value, PRINT_OBJ_DIFFABLE)
    value_types = (
        bool,
        ClassType,
        complex,
        dict,
        DictionaryType,
        float,
        int,
        list,
        str,
        tuple,
        types.BuiltinFunctionType,
        types.BuiltinMethodType,
        types.CodeType,
        types.FrameType,
        types.FunctionType,
        types.GeneratorType,
        InstanceType,
        types.LambdaType,
        types.MethodType,
        types.ModuleType,
        SliceType,
        types.TracebackType,
        TypeType,
        XRangeType
    )
    if not isinstance(value, value_types):
        if hasattr(value, '_toDiffableString'):
            s = value._toDiffableString(maxLevel)
        elif hasattr(value, '__str__'):
            s = str(value)
        elif hasattr(value, '__dict__'):
            s = "%s(%s)" % (type(value), toDiffableString(
                value.__dict__, maxLevel))
        else:
            s = str(type(value))
        ix2 = s.find(" object at 0x")
        if ix2 > 0:
            ix = s.rfind(".")
            if ix > 0:
                s = "<class %s>" % s[ix + 1:ix2]
    elif isinstance(value, bool):
        if value:
            return "True"
        return "False"
    elif (isinstance(value, (tuple, list))):
        items = []
        for v in value:
            if isinstance(v, str):
                if v.find("'") >= 0:
                    items.append('"%s"' % v)
                else:
                    items.append("'%s'" % v)
            else:
                items.append(toDiffableString(v, maxLevel))
        s = "[" + ", ".join(items) + "]"
    elif isinstance(value, dict):
        items = []
        for key, val in value.items():
            if isinstance(val, str):
                items.append("'%s': u'%s'" % (
                    key, toDiffableString(val, maxLevel)))
            elif isinstance(val, str):
                items.append("'%s': '%s'" % (
                    key, toDiffableString(val, maxLevel)))
            else:
                items.append("'%s': %s" % (
                    key, toDiffableString(val, maxLevel)))
        s = "{" + ", ".join(items) + "}"
    else:
        s = str(value)
    return s


def toDiffableString(value, maxLevel=None):
    s = toDiffableRepr(value, maxLevel)
    ds = ""
    i = s.find(" at 0x")
    start = 0
    while i >= 0:
        j = s.find(">", i)
        if j < i:
            break
        ds += s[start:i]
        start = j
        i = s.find(" at 0x", start)
    ds = ds + s[start:]
    i = ds.find("\\src\\")
    if i < 0:
        i = ds.find("/src/")
    else:
        ds = ds.replace("\\", "/")
    if i > 0:
        i += 4
        if ds[i:i + 5] == '\\php\\':
            i += 4
        elif ds[i:i + 8] == '\\python\\':
            i += 7
        ds = "filepath: ..." + ds[i:]
    return ds


def toString(value, options=0):
    if options & PRINT_OBJ_DIFFABLE > 0:
        return toDiffableString(value)
    if not isinstance(value, str):
        return str(value)
    return value


def typeToString(obj, options=0):
    if isinstance(obj, bool):
        return "bool"
    if isinstance(obj, str):
        return "string"
    if isinstance(obj, int):
        return "int"
    if isinstance(obj, long):
        if (options & PRINT_OBJ_DIFFABLE) > 0:
            return "int"
        return "long"
    if isinstance(obj, float):
        return "float"
    if isinstance(obj, list):
        return "list"
    if isinstance(obj, dict):
        return "dict"
    if isinstance(obj, tuple):
        return "tuple"
    if isinstance(obj, InstanceType):
        ds = "<class %s.%s> " % (obj.__module__, obj.__class__.__name__)
    else:
        ds = str(type(obj))
    if options & PRINT_OBJ_DIFFABLE > 0:
        if ds.startswith('<class '):
            ix = ds.rfind(".")
            if ix < 0:
                ix = 8
            ds = "<class %s>" % ds[ix + 1:-2]
    return ds


def nameToString(name, options=0):
    if name.startswith('_v_'):
        return name[3:]
    if options & PRINT_OBJ_DIFFABLE > 0:
        ix = name.find("__")
        if ((ix > 1) and name.startswith("_")):
            name = name[ix:]
        return toDiffableString(name)
    return name


def printObject(
    out,
    object,
    name=None,
    indent=0,
    flags=0,
    exclude=None,
    remove=None,
    max_indent=30
):
    if name is None:
        name = ""
    if ((remove is not None) and (name in remove)):
        return False
    if ((max_indent is not None) and (indent > max_indent)):
        print(" " * indent, "%s: %s" % (name, toString(str(object), flags)), end=' ', file=out)
        if flags & PRINT_OBJ_INTERNAL == 0:
            print(file=out)
        return True
    final_new_line = False
    printed = True
    if flags & (PRINT_OBJ_COMPACT | PRINT_OBJ_HIDE_EXCLUDED) > 0:
        if ((exclude is not None) and ((object in exclude) or (name in exclude))):
            return None
        if flags & PRINT_OBJ_COMPACT > 0:
            indent = 0
    if flags & PRINT_OBJ_INTERNAL == 0:
        final_new_line = True
    flags |= PRINT_OBJ_INTERNAL
    if object is None:
        if (flags & PRINT_OBJ_NONONE) == 0:
            print(" " * indent, name, " = None", end=' ', file=out)
        else:
            final_new_line = False
            printed = False
    elif (name.startswith("_") and ((flags & PRINT_OBJ_HIDE_INTERNAL) > 0) and not name.startswith("_v_")):
        final_new_line = False
        printed = False
    elif (isinstance(object, (list, tuple))):
        if ((exclude is not None) and object in exclude):
            print(
                ' ' * indent,
                name,
                " : ",
                typeToString(object, flags),
                " of length = ",
                len(object),
                " (already printed)",
                end=' ',
                file=out
            )
        elif ((exclude is not None) and name in exclude):
            print(
                ' ' * indent,
                name,
                " : ",
                typeToString(object, flags),
                " of length = ",
                len(object),
                " (excluded)",
                end=' ',
                file=out
            )
        else:
            if ((exclude is not None) and (len(object) > 0)):
                exclude.append(object)
            print(
                ' ' * indent,
                name,
                " : ",
                typeToString(object, flags),
                ' of length = %d' % len(object),
                end=' ',
                file=out
            )
            for i, o in enumerate(object):
                print(file=out)
                printObject(
                    out,
                    o,
                    name='[%d]' % i,
                    indent=indent + 2,
                    flags=flags,
                    exclude=exclude,
                    remove=remove,
                    max_indent=max_indent
                )
    elif isinstance(object, dict):
        if ((exclude is not None) and object in exclude):
            print(
                ' ' * indent,
                name,
                " : ",
                typeToString(object, flags),
                " (already printed)",
                end=' ',
                file=out
            )
        else:
            if ((exclude is not None) and (len(object) > 0)):
                exclude.append(object)
            if len(name) > 0:
                print(" " * indent, name, end=' ', file=out)
                if flags & PRINT_OBJ_COMPACT == 0:
                    print(file=out)
                    indent += 2
            print(" " * indent, "{", end=' ', file=out)
            if flags & PRINT_OBJ_COMPACT == 0:
                print(file=out)
            keys = list(object.keys())
            keys.sort()
            for key in keys:
                if key is not None:
                    n = key
                    if not isinstance(n, str):
                        n = str(n)
                    else:
                        n = nameToString(n, flags)
                    if (not n.startswith("_") or ((flags & PRINT_OBJ_HIDE_INTERNAL) == 0)):
                        if printObject(
                                out,
                                object[key],
                                name=n,
                                indent=indent + 2,
                                flags=(
                                    flags | PRINT_OBJ_INTERNAL),
                                exclude=exclude,
                                remove=remove,
                                max_indent=max_indent):
                            if (flags & PRINT_OBJ_COMPACT) == 0:
                                print(file=out)
                            else:
                                print(",", end=' ', file=out)
            print(" " * indent, "}", end=' ', file=out)
    elif hasattr(object, "__dict__"):
        if name.startswith("_"):
            print(" " * indent, name, " : ", typeToString(object, flags), end=' ', file=out)
        elif ((exclude is not None) and ((object in exclude) or (object.__dict__ in exclude))):
            print(
                ' ' * indent,
                name,
                " : ",
                typeToString(object, flags),
                " (already printed)",
                end=' ',
                file=out
            )
        else:
            if exclude is not None:
                exclude.append(object)
            print(" " * indent, name, " : ", typeToString(object, flags), end=' ', file=out)
            if (flags & PRINT_OBJ_GETATTR) == 0:
                if flags & PRINT_OBJ_COMPACT == 0:
                    print(file=out)
                printObject(
                    out,
                    object.__dict__,
                    indent=indent,
                    flags=flags,
                    exclude=exclude,
                    remove=remove,
                    max_indent=max_indent
                )

            else:
                if flags & PRINT_OBJ_COMPACT == 0:
                    print(file=out)
                print(" " * indent, "{", end=' ', file=out)
                keys = list(object.__dict__.keys())
                keys.sort()
                printed = True
                for key in keys:
                    if ((exclude is not None) and (key in exclude)):
                        continue
                    if (printed and ((flags & PRINT_OBJ_COMPACT) == 0)):
                        print(file=out)
                    n = nameToString(key, flags)
                    printed = printObject(
                        out,
                        getattr(object, n),
                        name=n,
                        indent=indent + 2,
                        flags=flags,
                        exclude=exclude,
                        remove=remove,
                        max_indent=max_indent
                    )

                if (flags & PRINT_OBJ_COMPACT) == 0:
                    print(file=out)
                print(" " * indent, "}", end=' ', file=out)
    elif indent < 0:
        print(object, end=' ', file=out)
    elif isinstance(object, str):
        if ((exclude is not None) and name in exclude):
            print(
                ' ' * indent,
                name,
                " : ",
                typeToString(object, flags),
                " of length = ",
                len(object),
                " (excluded)",
                end=' ',
                file=out
            )
        elif len(object) > 100:
            object = toString(object, flags)
            print(
                ' ' * indent,
                name,
                ":",
                typeToString(object, flags),
                '[%d] = %s...%s' % (len(object), object[:50], object[-50:]),
                end=' ',
                file=out
            )
        else:
            print(
                ' ' * indent,
                name,
                ":",
                typeToString(object, flags),
                "=",
                toString(object, flags),
                end=' ',
                file=out
            )
    else:
        print(
            ' ' * indent,
            name,
            ":",
            typeToString(object, flags),
            "=",
            toString(object, flags),
            end=' ',
            file=out
        )
    if final_new_line:
        print(file=out)
    return printed
