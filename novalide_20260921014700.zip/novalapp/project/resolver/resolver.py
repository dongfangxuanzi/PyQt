import os
from . import xmlutils
# 引用model模块的KNOWNTYPES常量,不能使用from model import KNOWNTYPES来导入,因为在其它地方已修改
from . import model
from ... import _
from .const import PROJECT_VERSION_191025


def load(fileobject):
    version = xmlutils.getAgVersion(fileobject.name)
    # most current versions on top
    if version == PROJECT_VERSION_191025:
        fileobject.seek(0)
        project = xmlutils.load(fileobject.name, knowntypes=model.KNOWNTYPES,
                                known_namespaces=xmlutils.KNOWN_NAMESPACES, createGenerics=True)
    else:
        # assume it is old version without version number
        raise RuntimeError(_('Invalid project doc version') % version)
    if project:
        project._projectDir = os.path.dirname(fileobject.name)
        project.RelativeToAbsPath()
    return project


def save(fileobject, project, production_deployment=False):
    if not project._projectDir:
        project._projectDir = os.path.dirname(fileobject.name)
    project.AbsToRelativePath()  # temporarily change it to relative paths for saving
    saved_homedir = project.homeDir
    if production_deployment:
        # for deployments, we don't want an abs path in homeDir since that
        # would tie the app to the current filesystem. So unset it.
        project.homeDir = None
    xmlutils.save(fileobject.name, project, pretty_print=True,
                  knowntypes=model.KNOWNTYPES, knownnamespaces=xmlutils.KNOWN_NAMESPACES)
    if production_deployment:
        project.homeDir = saved_homedir
    project.RelativeToAbsPath()  # swap it back to absolute path
