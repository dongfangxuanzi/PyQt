DEFAULT_SCREEN_LINES = 24
DEFAULT_SCREEN_COLUMNS = 80
RUN_TERMINAL_BACKENDKEY = "terminal_backend_name"
TERMINAL_SCREEN_LINES_KEY = "terminal_screen_lines"
TERMINAL_SCREEN_COLUMNS_KEY = "terminal_screen_columns"
TERMINAL_ECHO_COMMAND_KEY = "terminal_close_echo_command"
