from .pyqt import QPixmap, QIcon


def empty_pixmap():
    return QPixmap()


def empty_icon():
    return QIcon(QPixmap())


def load_image(path):
    pixmap = QPixmap(path)
    return pixmap
