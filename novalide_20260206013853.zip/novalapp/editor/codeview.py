# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        code.py
Purpose:     程序支持编程语言编辑窗口

Author:      wukan

Created:     2019-01-21
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
from .. import get_app, _
from .textview import TextDocument, TextView
from .texteditor import TextEditor
from .. import menuitems
from ..bars.menubar import find_menu
from ..syntax.syntax import SyntaxThemeManager
from .. import globalkeys, constants
from ..lib.pyqt import QMessageBox, QColor, Qt, QFont
from ..lib.qsci import QsciScintilla, MARGIN_SCRIPT_FOLD_INDEX, MARGIN_SCRIPT_FOLD_WIDTH, QsciAPIs
from ..util import utils, ui_utils
from .formatter import CodeFormatter
from ..lib.docmanager import DOC_SILENT


class CodeDocument(TextDocument):
    def OnOpenDocument(self, filename):
        if not super().OnOpenDocument(filename):
            return False
        return True


class CodeView(TextView, CodeFormatter):
    # ----------------------------------------------------------------------------
    # Overridden methods
    # ----------------------------------------------------------------------------
    def GetCtrlClass(self):
        """ Used in split window to instantiate new instances """
        return CodeCtrl

    def LoadOutLine(self, outlineview, force=False, linenum=-1):
        pass

    def GenCheckSum(self):
        """ Poor man's checksum.  We'll assume most changes will change the length of the file.
        """
        text = self.GetValue()
        if text:
            return len(text)
        return 0
    # ----------------------------------------------------------------------------
    # Format methods
    # ----------------------------------------------------------------------------

    def GetAutoCompleteDefaultKeywords(self):
        """ Replace this method with Editor specific keywords """
        lexer = self.GetCtrl().GetLangLexer()
        return lexer.GetKeywords()

    def GetLangId(self):
        lexer = self.GetCtrl().GetLangLexer()
        return lexer.GetLangId()

    def UpdateUI(self, command_id):
        if command_id == menuitems.ID_INSERT_COMMENT_TEMPLATE:
            langid = self.GetLangId()
            lexer = SyntaxThemeManager.manager().GetLexer(langid)
            enabled = lexer.IsCommentTemplateEnable()
            return enabled and not self.GetCtrl().isReadOnly()
        if command_id == menuitems.ID_INSERT_DECLARE_ENCODING:
            return False
        if command_id in [
            menuitems.ID_COMMENT_LINES,
            menuitems.ID_UNCOMMENT_LINES,
            menuitems.ID_AUTO_COMPLETE,
            menuitems.ID_INDENT_LINES,
            menuitems.ID_DEDENT_LINES
        ]:
            return not self.GetCtrl().isReadOnly()
        return super().UpdateUI(command_id)

    def update_appearance(self):
        super().update_appearance()
        # 设置括号匹配模式
        if utils.profile_get_int(globalkeys.TEXT_HIGHLIGHT_PARENTHESES_KEY, True):
            self.GetCtrl().setBraceMatching(QsciScintilla.SloppyBraceMatch)
        else:
            self.GetCtrl().setBraceMatching(QsciScintilla.NoBraceMatch)
        # 显示虚线垂直线的方式来指示缩进
        if utils.profile_get_int(globalkeys.TEXT_EDITOR_VIEWINDENTATIONGUIDES_KEY, False):
            self.GetCtrl().setIndentationGuides(True)
        else:
            self.GetCtrl().setIndentationGuides(False)
        # 缩进使用制表符
        if utils.profile_get_int(globalkeys.TEXT_INDENTATION_USETABS_KEY, False):
            # 使用制表符缩进
            self.GetCtrl().setIndentationsUseTabs(True)
            # 当启用制表符缩进时,设置tab键的宽度
            self.GetCtrl().setTabWidth(utils.profile_get_int(
                'TextEditorTabsWidth', constants.DEFAULT_TAB_WIDTH))
        # 缩进使用空白字符
        else:
            # 使用空白符代替制表符缩进
            self.GetCtrl().setIndentationsUseTabs(False)
            # 设置缩进的宽度,等于多少个空白字符
            self.GetCtrl().setIndentationWidth(utils.profile_get_int(
                globalkeys.TEXT_EDITOR_INDENT_WIDTH_KEY, constants.DEFAULT_TAB_INDENTATION_WIDTH))
        # 回车键自动缩进
        self.GetCtrl().setAutoIndent(True)
        # 退格缩进
        self.GetCtrl().setBackspaceUnindents(True)

    def SetValue(self, value):
        '''
            代码文件加载时检查是否包含制表符
        '''
        super().SetValue(value)
        self.check_mixed_tabs(value)

    @ui_utils.call_after
    def check_mixed_tabs(self, value):
        replace_tabs = utils.profile_get_int(
            globalkeys.CHECK_CODE_EDITOR_TABS_KEY, True)
        newchars, replaced = self.check_convert_tabs_to_spaces(
            value, replace_tabs)
        # 如果替换了制表符,设置文件修改状态
        if replaced:
            self.reset_text(newchars)

    def check_convert_tabs_to_spaces(self, chars, replace_tabs):
        '''
            检查插入文本是否包含制表符, 并是否弹出警告提示
        '''
        tab_count = chars.count("\t")
        if not replace_tabs or tab_count == 0:
            return chars, False
        indent_width = utils.profile_get_int(
            globalkeys.TEXT_EDITOR_INDENT_WIDTH_KEY, constants.DEFAULT_TAB_INDENTATION_WIDTH)
        ret = QMessageBox.question(
            self.GetCtrl(),
            _("Convert tabs to spaces?"),
            _("NovalIDE (according to Python recommendation) uses spaces for indentation, ")
            + _("but the text you are about to insert/open contains %d tab characters. ") % tab_count
            + _("To avoid confusion, it's better to convert them into spaces (unless you know they should be kept as tabs).\n\n")
            + _("Do you want me to replace each tab with %d spaces?\n\n") % indent_width,
        )
        if ret == QMessageBox.Yes:
            return self.expandtabs(chars, indent_width), True
        return chars, False

    def update_lexer_configs(self):
        return self.GetCtrl().update_lexer_configs()


class CodeCtrl(TextEditor):
    CURRENT_LINE_MARKER_NUM = 2
    BREAKPOINT_MARKER_NUM = 1
    CURRENT_LINE_MARKER_MASK = 0x4
    BREAKPOINT_MARKER_MASK = 0x4
    TYPE_BLANK_WORD = " "

    def __init__(self, master, view):
        super().__init__(master, view)
        self._lang_lexer = None
        self.autocompleter = None
        self.calltip = None
        self._api = None

        # clear some variables
        self.last_highlight = None  # remember the last highlighted line
        self.last_currmarker = None  # remember the last current line
        self.currentline = self.markerDefine(
            QsciScintilla.MarkerSymbol.Background)
        self.__set_linemarker_colours()

    @property
    def api(self):
        return self._api

    def GetFolderMarkVisible(self):
        return self.get_margin_width(MARGIN_SCRIPT_FOLD_INDEX) > 0

    def get_margins_width(self):
        '''
            代码文件,包含行号标签栏和代码折叠栏的宽度
        '''
        margin_width = super().get_margins_width()
        if self.GetFolderMarkVisible():
            margin_width += self.get_margin_width(MARGIN_SCRIPT_FOLD_INDEX)
        return margin_width

    def on_text_click(self, event=None):
        # 关闭文档提示信息
        self.CallTipHide()
        # 关闭自动完成列表框
        self.AutoCompHide()

    def DoIndent(self):
        self.AddText(self.GetEOLChar())
        self.EnsureCaretVisible()
        # Need to do a default one for all languges

    def GetLangLexer(self):
        document = self.get_view().GetDocument()
        file_ext = document.GetDocumentTemplate().GetDefaultExtension()
        self._lang_lexer = SyntaxThemeManager.manager().GetLangLexerFromExt(file_ext)
        return self._lang_lexer

    def SetLangLexer(self):
        '''
            设置编辑器语言渲染
        '''
        if self.lexer() is None:
            self.GetLangLexer()
            lexer = self._lang_lexer.get_lexer(self)
            # 设置渲染语言的字体
            lexer.setDefaultFont(self.font())
            self.setLexer(lexer)
            # 初始化scintilla api接口,以便实现代码自动完成功能
            self._api = QsciAPIs(lexer)
            self.load_api()
            self._api.prepare()
            self.autoCompleteFromAll()
            # 自动完成区分大小写
            self.setAutoCompletionCaseSensitivity(False)
            # 表示错误单词改正时替换先前输入的错误单词
            self.setAutoCompletionReplaceWord(False)
            self.setAutoCompletionUseSingle(QsciScintilla.AcusExplicit)
            self.update_lexer_configs()

    def load_api(self):
        # 各编程语言关键字
        autocompletions = self._lang_lexer.GetKeywords()
        # 编程语言词法分析器关键字
        default_keywords = self._lang_lexer.get_default_keywords(self.lexer())
        for ac in autocompletions + default_keywords:
            self._api.add(ac)

    def update_lexer_configs(self):
        # 是否启用自动完成功能
        autocompletion_enabled = utils.profile_get_int(
            globalkeys.AUTO_COMPLETION_ENABLED_KEY, True)
        self.set_autocompletion_enabled(autocompletion_enabled)

    def set_autocompletion_enabled(self, enable):
        """
        Public method to enable/disable autocompletion.

        @param enable flag indicating the desired autocompletion status
            (boolean)
        """
        if enable:
            # 输入多少个字符才弹出补全提示
            self.setAutoCompletionThreshold(
                constants.DEFAULT_AUTOCOMPLETION_THRESHOLD_NUM)
            self.setAutoCompletionSource(QsciScintilla.AcsAll)
        else:
            self.setAutoCompletionThreshold(-1)
            self.setAutoCompletionSource(QsciScintilla.AcsNone)

    def update_margins(self):
        super().update_margins()
        if utils.profile_get_int(globalkeys.CODE_EDITOR_VIEWFOLD_KEY, True):
            self.setMarginWidth(MARGIN_SCRIPT_FOLD_INDEX,
                                MARGIN_SCRIPT_FOLD_WIDTH)
            self.setFolding(QsciScintilla.CircledTreeFoldStyle)
        else:
            self.setMarginWidth(MARGIN_SCRIPT_FOLD_INDEX, 0)
            self.setFolding(QsciScintilla.NoFoldStyle)

    def ClearCurrentLineMarkers(self):
        '''
            调试下一步时,先要删除所有断点调试的标记,以便标记下一行
        '''
        if self.last_currmarker is not None:
            self.markerDeleteHandle(self.last_currmarker)
            self.setReadOnly(False)

    def highlight_visible(self):
        """
        Public method to make sure that the highlight is visible.
        """
        if self.last_highlight is not None:
            lineno = self.markerLine(self.last_highlight)
            self.ensure_visible(lineno + 1)

    def ensure_visible(self, line, expand=False):
        """
        Public slot to ensure, that the specified line is visible.

        @param line line number to make visible
        @type int
        @param expand flag indicating to expand all folds
        @type bool
        """
        self.ensureLineVisible(line - 1)
        if expand:
            self.call(
                QsciScintilla.SCI_FOLDCHILDREN,
                line - 1,
                QsciScintilla.SC_FOLDACTION_EXPAND,
            )

    def highlight(self, line=None, error=False, syntaxerror=False):
        """
        Public method to highlight [or de-highlight] a particular line.

        @param line line number to highlight (integer)
        @param error flag indicating whether the error highlight should be
            used (boolean)
        @param syntaxError flag indicating a syntax error (boolean)
        """
        if line is None:
            self.last_highlight = None
            if self.lastErrorMarker is not None:
                self.markerDeleteHandle(self.lastErrorMarker)
            self.lastErrorMarker = None
            if self.last_currmarker is not None:
                self.markerDeleteHandle(self.last_currmarker)
            self.last_currmarker = None
        else:
            if error:
                if self.lastErrorMarker is not None:
                    self.markerDeleteHandle(self.lastErrorMarker)
                self.lastErrorMarker = self.markerAdd(line - 1, self.errorline)
                self.last_highlight = self.lastErrorMarker
            else:
                self.last_currmarker = self.markerAdd(
                    line - 1, self.currentline)
                self.last_highlight = self.last_currmarker
            self.setCursorPosition(line - 1, 0)

    def MarkerAdd(self, line):
        '''
            标记并高亮断点调试的当前行
        '''
        # Change the highlighted line.
        self.highlight(line)
        self.highlight_visible()

    def __set_linemarker_colours(self):
        """
        Private method to set the line marker colours.
        """
        self.setMarkerForegroundColor(
            QColor(Qt.GlobalColor.yellow), self.currentline
        )
        self.setMarkerBackgroundColor(
            QColor(Qt.GlobalColor.yellow), self.currentline
        )

    def CreatePopupMenu(self):
        super().CreatePopupMenu()
        edits_menu = find_menu(_("&Edit"), get_app().Menubar)
        self._menu.insert_menu_after(
            menuitems.ID_SELECTALL,
            menuitems.ID_ADVANCE,
            edits_menu.GetMenu(menuitems.ID_ADVANCE)
        )
        self._menu.add_separator()
        format_menu = find_menu(_("&Format"), get_app().Menubar)
        self._menu.AppendItem(
            format_menu.FindMenuItem(menuitems.ID_COMMENT_LINES))
        self._menu.AppendItem(format_menu.FindMenuItem(
            menuitems.ID_UNCOMMENT_LINES))

        self._menu.Append(
            menuitems.ID_OPEN_IN_BROWSER,
            _("&Open in browser"),
            handler=self.open_in_browser,
            img=get_app().GetImage("browser.png")
        )
        view_menu = find_menu(_("&View"), get_app().Menubar)
        self._menu.AppendMenu(
            menuitems.ID_DISPLAY_SYMBOL,
            view_menu.GetMenu(menuitems.ID_DISPLAY_SYMBOL)
        )
        find_menu_item = edits_menu.FindMenuItem(menuitems.ID_FIND)
        self._menu.AppendItem(find_menu_item)

    def open_in_browser(self):
        webview_template = get_app().GetDocumentManager().FindTemplateForTestPath(".com")
        get_app().GetDocumentManager().CreateTemplateDocument(
            webview_template,
            self.get_view().GetDocument().GetFilename(),
            DOC_SILENT
        )

    def set_syntax(self, syntax_options):
        super().set_syntax(syntax_options)
        # 是否高亮语法
        if utils.profile_get_int(globalkeys.TEXT_HIGHLIGHT_SYNTAX_KEY, True):
            self.SetLangLexer()
            if not syntax_options:
                return
            styles = syntax_options['styles']
            lexer = self.lexer()
            # 设置文字默认颜色和背景色
            lexer.setColor(QColor(syntax_options['forecolor']))
            lexer.setPaper(QColor(syntax_options['paper']))
            font = self.font()
            for style_name in styles:
                syntax_style_id = getattr(lexer, style_name)
                style_values = styles[style_name]
                # 语法文字颜色
                foreground_color = style_values['foreground']
                try:
                    forecolor = self.check_color_value(foreground_color)
                except:
                    raise RuntimeError(
                        "style_name %s forecolor value %s in theme file %s is invalid" % (
                            style_name, foreground_color, self._lang_lexer.theme_file()
                        )
                    )
                # 语法文字背景色
                background_color = style_values.get('background', None)
                try:
                    backcolor = self.check_color_value(background_color)
                except:
                    raise RuntimeError(
                        "style_name %s background value %s in theme file %s is invalid" % (
                            style_name, background_color, self._lang_lexer.theme_file()
                        )
                    )
                # 是否粗体
                is_bold = style_values.get('bold', False)
                # 是否斜体
                is_italic = style_values.get('italic', False)
                # 设置语法元素颜色
                lexer.setColor(QColor(forecolor), syntax_style_id)
                font = QFont(font.family(), font.pointSize())
                if is_bold:
                    font.setBold(True)
                if is_italic:
                    font.setItalic(True)
                lexer.setFont(font, syntax_style_id)
                # 设置语法元素背景色
                if backcolor:
                    lexer.setPaper(QColor(backcolor), syntax_style_id)
        else:
            self.GetCtrl().setLexer(None)

    def check_color_value(self, color):
        if color is None:
            return None
        if color.startswith('#'):
            return color
        if color.lower() in QColor.colorNames():
            return color.lower()
        raise
