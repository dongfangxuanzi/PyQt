# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""Text editor implementation"""
from .. import get_app
from ..findrep.mixin import FindMixin
from ..lib.pyqt import (Qt,
                        QApplication, QAction,
                        QFontMetrics, QColor)
from ..lib.qsci import QsciScintilla, MARGIN_LINENUMBER_INDEX, DEFAULT_MARGIN_INDEX
from .contextmenus import EditorContextMenuMixin
from .. import constants, globalkeys, menuitems
from ..util import utils
from .textctrl import TextCtrl
from ..findrep import findui
from ..common.compat import ensure_string
from ..widgets.event import EscapeEvent

CTRL_SHIFT = int(Qt.ShiftModifier | Qt.ControlModifier)
SHIFT = int(Qt.ShiftModifier)
CTRL = int(Qt.ControlModifier)
ALT = int(Qt.AltModifier)
CTRL_KEYPAD = int(Qt.KeypadModifier | Qt.ControlModifier)
NO_MODIFIER = int(Qt.NoModifier)


class TextEditor(TextCtrl, EditorContextMenuMixin, FindMixin, EscapeEvent):
    """Text editor implementation"""

    def __init__(self, parent, view):
        self._parent = parent
        self._view = view
        TextCtrl.__init__(self, parent)
        EditorContextMenuMixin.__init__(self)
        FindMixin.__init__(self)
        self.call = self.SendScintilla
        self.setAttribute(Qt.WA_KeyCompression)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        # 代码编辑不能自动换行
        self.set_wrap_mode(QsciScintilla.WrapNone)
        # 隐藏默认显示的1号边栏
        self.setMarginWidth(DEFAULT_MARGIN_INDEX, 0)
        self.setAcceptDrops(False)
        # 换行模式,使用系统默认换行
        self.eol = self.eolMode()
        self.__openedLine = None
        self.setFocusPolicy(Qt.StrongFocus)
        self.__lastTabPosition = None

    def get_view(self):
        return self._view

    def set_wrap_mode(self, mode: int):
        # 1表示自动换行,0表示取消自动换行
        # QTextOption.NoWrap的值为0,QTextOption.WordWrap的值为1
        self.call(QsciScintilla.SCI_SETWRAPMODE, mode)

    def is_modified(self):
        return self.call(QsciScintilla.SCI_GETMODIFY)

    def setModified(self, modified=True):
        super().setModified(modified)

    def dedentLine(self):
        """Dedent the current line or selection"""
        self.decreaseIndentAction.activate(QAction.Trigger)

    def wheelEvent(self, event):
        """Mouse wheel event"""
        if QApplication.keyboardModifiers() == Qt.ControlModifier:
            angle_delta = event.angleDelta()
            if not angle_delta.isNull():
                if angle_delta.y() > 0:
                    # 放大字体
                    self.zoomIn(1)
                else:
                    # 缩小字体
                    self.zoomOut(1)
            event.accept()
        else:
            QsciScintilla.wheelEvent(self, event)

    def focusInEvent(self, event):
        """Enable Shift+Tab when the focus is received"""
        get_app().MainFrame.check_external_changes()
        if self._parent.shouldAcceptFocus():
            QsciScintilla.focusInEvent(self, event)
        else:
            self._parent.setFocus()

    def focusOutEvent(self, event):
        """Disable Shift+Tab when the focus is lost"""
# self.__completer.hide()
# if not self.__inCompletion:
# self.__resetCalltip()
        QsciScintilla.focusOutEvent(self, event)

    def get_line_count(self):
        return self.call(QsciScintilla.SCI_GETLINECOUNT)

    def estimated_linenumber_margin_width(self):
        '''
            估算行号空白栏最大长度
        '''
        linenum = self.get_line_count()
        base_numbers = " %d " % (linenum)
        linenum = linenum // 100
        while linenum >= 10:
            linenum = linenum / 10
            base_numbers = base_numbers + " "
        font = self.font()
        fontmetrics = QFontMetrics(font)
        return fontmetrics.width(base_numbers)

    def UpdateLineNumberWidth(self, show_linenumber_margin=True):
        # 不显示行号
        if not show_linenumber_margin:
            # 设置行号宽度为0
            self.setMarginWidth(MARGIN_LINENUMBER_INDEX, 0)
            return
        # 行号栏原始宽度
        linemargin_widthnow = self.get_margin_width(MARGIN_LINENUMBER_INDEX)
        # 数字适应宽度
        linenumber_width = self.estimated_linenumber_margin_width()
        if linemargin_widthnow != linenumber_width:
            # 改变行边宽度,以适应数字大小
            self.setMarginWidth(MARGIN_LINENUMBER_INDEX, linenumber_width)

    def get_margin_width(self, margin):
        return self.marginWidth(margin)

    def update_margins(self):
        """Initializes the editor margins"""
        show_linenumber_margin = utils.profile_get_int(
            globalkeys.TEXT_VIEW_LINENUMBERS_KEY, True)
        self.setMarginLineNumbers(
            MARGIN_LINENUMBER_INDEX, show_linenumber_margin)
        self.UpdateLineNumberWidth(show_linenumber_margin)

    def keyPressEvent(self, event):
        """Handles wx.EVT_KEY_UP"""
        # 处理esc键,按esc键退出全屏模式
        if not self.is_escape_pressed(event):
            super().keyPressEvent(event)

    def mouseReleaseEvent(self, event):
        if self._view is not None:
            self.get_view().activate_view()
            self.get_view().record_track()
        super().mouseReleaseEvent(event)

    def getCurrentPosFont(self):
        """Provides the font of the current character"""
        if self.lexer_ is not None:
            font = self.lexer_.font(self.styleAt(self.currentPosition()))
        else:
            font = self.font()
        font.setPointSize(font.pointSize() + self.getZoom())
        return font

    def resizeEvent(self, event):
        """Resize the parent panels if required"""
        QsciScintilla.resizeEvent(self, event)
        if hasattr(self._parent, 'resizeBars'):
            self._parent.resizeBars()

    def CanUndo(self):
        """Undo implementation"""
        return self.isUndoAvailable()

    def CanRedo(self):
        """Redo implementation"""
        return self.isRedoAvailable()

    def CanCopy(self):
        return self.selectedText() != ""

    def CanCut(self):
        return self.CanCopy() and not self.isReadOnly()

    def CanPaste(self):
        return QApplication.clipboard().text() != "" and not self.isReadOnly()

    def get_current_line(self, plus=False):
        '''
        获取鼠标所在当前行,由于语法节点行号比编辑器控件内部行号大1个数,
        plus参数表示是否行号+1
        '''
        current_pos = self.get_current_pos()
        curline = self.call(QsciScintilla.SCI_LINEFROMPOSITION, current_pos)
        if plus:
            curline += 1
        return curline

    def get_current_column(self):
        current_pos = self.get_current_pos()
        return self.call(QsciScintilla.SCI_GETCOLUMN, current_pos)

    def styleAt(self, pos):
        """
        Public method to get the style at a position in the text.

        @param pos position in the text (integer)
        @return style at the requested position or 0, if the position
            is negative or past the end of the document (integer)
        """
        return self.call(QsciScintilla.SCI_GETSTYLEAT, pos)

    def getSubStyleRange(self, stylenr):
        """
        Public method to get the sub style range for given style number.

        @param styleNr Number of the base style
        @type int
        @return start index of the sub style and their count
        @rtype int, int
        """
        start = self.call(QsciScintilla.SCI_GETSUBSTYLESSTART, stylenr)
        count = self.call(QsciScintilla.SCI_GETSUBSTYLESLENGTH, stylenr)
        return start, count

    def hasSelection(self):
        """
        Public method to check for a selection.

        @return flag indicating the presence of a selection (boolean)
        """
        return self.getSelection()[0] != -1

    def get_current_line_column(self, plus_line=False):
        '''
        获取鼠标所在当前行和列,由于语法节点行号比编辑器控件内部行号大1个数,
        plus_line参数表示是否行号+1
        '''
        current_pos = self.get_current_pos()
        curline = self.call(QsciScintilla.SCI_LINEFROMPOSITION, current_pos)
        if plus_line:
            curline += 1
        return curline, self.call(QsciScintilla.SCI_GETCOLUMN, current_pos)

    def set_sel(self, start, end):
        self.call(
            QsciScintilla.SCI_SETSEL,
            start,
            end
        )

    def insert_text(self, pos, chars):
        self.call(QsciScintilla.SCI_INSERTTEXT, pos, self._encodeString(chars))

    def append_text(self, chars):
        encode_chars = self._encodeString(chars)
        length = len(encode_chars)
        self.call(QsciScintilla.SCI_APPENDTEXT, length, encode_chars)
        return length

    def addtext(self, chars, pos=None):
        if pos is None:
            pos = self.get_current_pos()
        self.insert_text(pos, chars)
        self.gotopos(pos + len(chars))

    def clear(self):
        '''
            删除选中文本
        '''
        self.call(QsciScintilla.SCI_CLEAR)

    def clearall(self):
        '''
            清空编辑区域所有文本
        '''
        self.call(QsciScintilla.SCI_CLEARALL)

    def select_all(self):
        self.call(QsciScintilla.SCI_SELECTALL)

    def get_current_pos(self):
        return self.call(QsciScintilla.SCI_GETCURRENTPOS)

    def gotoLine(self, lineno):
        self.call(QsciScintilla.SCI_GOTOLINE, lineno)

    def lineIndexFromPosition(self, pos):
        """
        Public method to convert an absolute position to line and index.

        @param pos absolute position in the editor (integer)
        @return tuple of line number (integer) and index number (integer)
        """
        line = self.call(QsciScintilla.SCI_LINEFROMPOSITION, pos)
        linepos = self.position_from_linecol(line)
        return line, pos - linepos

    def position_from_linecol(self, line, col=0):
        '''
        行列位置转换为文档内偏移位置
        '''
        return self.call(QsciScintilla.SCI_POSITIONFROMLINE, line) + col

    def DeleteBack(self):
        self.call(QsciScintilla.SCI_DELETEBACK)

    def delete_target(self, head, tail):
        self.set_sel(
            head,
            tail
        )
        self.DeleteBack()

    def get_line_text(self, line):
        '''
            获取行文本不包含换行符,和get_line方法不一样
        '''
        # 文本总行数
        line_num = self.lines()
        # 超过文本总行数
        if line > line_num - 1:
            return None
        linetext = self.text(line)
        if linetext.endswith(constants.CRLF):
            return linetext[0:-len(constants.CRLF)]
        if linetext.endswith(constants.CR) or linetext.endswith(constants.LF):
            return linetext[0:-len(constants.CR)]
        return linetext

    def get_line(self, line, last_append_linend=True):
        '''
            获取行文本包含换行符,如果最后一行不包含换行符,默认添加一个
            如果行数超出文本总行数,返回None
        '''
        # 文本总行数
        line_num = self.lines()
        # 超过文本总行数
        if line > line_num - 1:
            return None
        linetext = self.text(line)
        # 最后一行
        if line == line_num - 1:
            # 如果最后一行不包含换行符,默认添加\n,以支持文本搜索功能
            if not linetext.endswith((constants.CR, constants.LF, constants.CRLF)) and last_append_linend:
                linetext += constants.LF
        return linetext

    def _encodeString(self, source_str):
        """
        Protected method to encode a string depending on the current mode.

        @param string string to be encoded (str)
        @return encoded string (bytes)
        """
        if isinstance(source_str, bytes):
            return source_str
        if self.isUtf8():
            return source_str.encode("utf-8")
        return source_str.encode("latin-1")

    def set_target_start(self, pos):
        self.call(QsciScintilla.SCI_SETTARGETSTART, pos)

    def set_target_end(self, pos):
        self.call(QsciScintilla.SCI_SETTARGETEND, pos)

    def encode_line(self, lineindex):
        return self._encodeString(self.text(lineindex))

    def get_chars(self, startline, startindex, endline, endindex):
        '''
            获取区域范围内的字符串
            startline:起始行号
            startindex:起始列号
            endline:末尾行号
            endindex:末尾列号
            列号的索引位置均指相对字节数的位置,
            必须将字符串转换为二进制字符,因为中文会占用多个字节,在文本中的位置
            也占用多个字节
        '''
        startline_text = self.text(startline)
        # 获取单行区间范围的内容
        if startline == endline:
            chars = self._encodeString(startline_text)[startindex:endindex]
            return ensure_string(chars)
        chars = b''
        for line in range(startline, endline + 1):
            if line == startline:
                # 考虑到中文字符串,需要转换为二进制字符
                chars += self.encode_line(startline)[startindex:]
            elif line == endline:
                chars += self.encode_line(endline)[0:endindex]
            else:
                chars += self.encode_line(line)
        # 最后要将二进制字符转换为utf-8编码的字符串
        return ensure_string(chars)

    def replace_target(self, startpos, endpos, repstr):
        self.set_target_start(startpos)
        self.set_target_end(endpos)
        encode_repstr = self._encodeString(repstr)
        self.call(QsciScintilla.SCI_REPLACETARGET,
                  len(encode_repstr), encode_repstr)

    def get_selection(self):
        startline, startindex, endline, endindex = self.getSelection()
        if -1 == startline:
            startpos = self.get_current_pos()
            startline, startindex = self.lineIndexFromPosition(startpos)
            endline, endindex = startline, startindex
        return startline, startindex, endline, endindex

    def getEolIndicator(self):
        """
        Public method to get the eol indicator for the current eol mode.

        @return eol indicator (string)
        """
        m = self.eol
        if m == QsciScintilla.EolWindows:
            eol = 'CRLF'
        elif m == QsciScintilla.EolUnix:
            eol = 'LF'
        elif m == QsciScintilla.EolMac:
            eol = 'CR'
        else:
            eol = 'MIXED'
        return eol

    def GetLineMarkVisible(self):
        return self.marginLineNumbers(MARGIN_LINENUMBER_INDEX)

    def get_margins_width(self):
        '''
            获取编辑器所有标签栏的宽度之和,如果仅仅是文本文件,只包含行号标签栏的宽度
        '''
        margin_width = 0
        if self.GetLineMarkVisible():
            margin_width += self.get_margin_width(MARGIN_LINENUMBER_INDEX)
        return margin_width

    def GotoPos(self, line, col):
        pos = self.position_from_linecol(line, col)
        self.gotopos(pos)

    def gotopos(self, pos):
        return self.call(QsciScintilla.SCI_GOTOPOS, pos)

    def LowerCase(self):
        self.call(QsciScintilla.SCI_LOWERCASE)

    def UpperCase(self):
        self.call(QsciScintilla.SCI_UPPERCASE)

    def tab(self):
        '''
            增加缩进
        '''
        self.call(QsciScintilla.SCI_TAB)

    def backtab(self):
        '''
            减少缩进
        '''
        self.call(QsciScintilla.SCI_BACKTAB)

    def startStyling(self, pos):
        self.call(QsciScintilla.SCI_STARTSTYLING, pos, 1)

    def setStyling(self, textlen, style):
        self.call(QsciScintilla.SCI_SETSTYLING, textlen, style)

    def set_style_spec(self, family, foregroud, backgroud, size, style):
        self.call(QsciScintilla.SCI_STYLESETFONT,
                  style, self._encodeString(family))
        self.call(QsciScintilla.SCI_STYLESETFORE, style, foregroud)
        self.call(QsciScintilla.SCI_STYLESETBACK, style, backgroud)
        self.call(QsciScintilla.SCI_STYLESETSIZE, style, size)

    def ProcessEvent(self, command_id):
        if command_id == menuitems.ID_CUT:
            self.cut()
        elif command_id == menuitems.ID_PASTE:
            self.paste()
        elif command_id == menuitems.ID_SELECTALL:
            self.select_all()
        elif command_id == menuitems.ID_COPY:
            self.copy()
        elif command_id == menuitems.ID_CLEAR:
            self.clear()
        elif command_id == menuitems.ID_FIND:
            self.DoFind()
        else:
            return False
        return True

    def ProcessUpdateEvent(self, command_id):
        if command_id == menuitems.ID_COPY:
            return self.CanCopy()
        if command_id in [menuitems.ID_CUT, menuitems.ID_CLEAR]:
            return self.CanCut()
        if command_id == menuitems.ID_PASTE:
            return self.CanPaste()
        if command_id == menuitems.ID_SELECTALL:
            return True
        if command_id == menuitems.ID_FIND:
            return True

    def DoFind(self):
        findui.show_findreplace_dialog(self,
                                       False,
                                       self.selectedText()
                                       )
        return False

    def scroll_to_end(self):
        self.call(QsciScintilla.SCI_SCROLLTOEND)

    def line_end_position(self, linenum):
        return self.call(QsciScintilla.SCI_GETLINEENDPOSITION, linenum)

    def set_syntax(self, syntax_options):
        if not syntax_options:
            return
        # 设置文本控件的文字颜色和背景色
        self.setColor(QColor(syntax_options['forecolor']))
        self.setPaper(QColor(syntax_options['paper']))

    def get_position_chars(self, startpos, endpos):
        '''
        获取2个位置之间的字符串
        '''
        assert endpos >= startpos
        endline, endindex = self.lineIndexFromPosition(
            endpos)
        startline, startindex = self.lineIndexFromPosition(
            startpos)
        subchars = self.get_chars(
            startline, startindex, endline, endindex)
        return subchars
