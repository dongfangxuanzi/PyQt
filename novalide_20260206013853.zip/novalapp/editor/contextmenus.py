# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""Sets up and handles the text editor conext menus"""


from .. import get_app, _
from ..lib.pyqt import QAction
from ..menuitems import ID_REDO, ID_UNDO, ID_CUT, ID_COPY, ID_PASTE, ID_CLEAR, ID_SELECTALL
from ..bars.menubar import find_menu, NewQMenu, MenuItem


class EditorContextMenuMixin:

    """Encapsulates the context menu handling"""

    def __init__(self):
        self._menu = None

    @property
    def menu(self):
        return self._menu

    def CreatePopupMenu(self):
        self.setFocus()
        # 如果弹出菜单存在,先销毁菜单
        if self._menu is not None:
            self._menu.destroy()
            self._menu = None
        self._menu = NewQMenu(self)
        edits_menu = find_menu(_("&Edit"), get_app().Menubar)
        self._menu.AppendItem(edits_menu.FindMenuItem(ID_UNDO))
        self._menu.AppendItem(edits_menu.FindMenuItem(ID_REDO))
        self._menu.add_separator()

        self._menu.AppendItem(edits_menu.FindMenuItem(ID_CUT))
        self._menu.AppendItem(edits_menu.FindMenuItem(ID_COPY))
        self._menu.AppendItem(edits_menu.FindMenuItem(ID_PASTE))

        self._menu.AppendItem(edits_menu.FindMenuItem(ID_CLEAR))
        self._menu.AppendItem(edits_menu.FindMenuItem(ID_SELECTALL))
        self._menu.add_separator()

    def contextMenuEvent(self, event):
        """Called just before showing a context menu"""
        # Accepting needs to suppress the native menu
        # 只在可编辑区域弹出菜单,在空白处不允许弹出菜单
        if event.pos().x() < self.get_margins_width():
            return
        # Show the menu
        self.CreatePopupMenu()
        # when popup right menu,activate the document view
        get_app().GetDocumentManager().ActivateView(self.get_view())
        if hasattr(self.parent(), 'SIG_EDIT_TEXT_POPUP_MENU'):
            self.parent().SIG_EDIT_TEXT_POPUP_MENU.emit(self._menu, self)
            get_app().MainFrame.projectview.SIG_EDIT_TEXT_POPUP_MENU.emit(
                get_app().get_current_project(),
                self._menu,
                self
            )
        self._menu.popup(event.globalPos())

    def onUndo(self):
        """Undo implementation"""
        if self.document().isUndoAvailable():
            self.undo()
            self._parent.modificationChanged()

    def onRedo(self):
        """Redo implementation"""
        if self.document().isRedoAvailable():
            self.redo()
            self._parent.modificationChanged()

    def create_edit_menuitem(self, edit_menu, item_id):
        edit_menuitem = edit_menu.FindMenuItem(item_id)
        action = edit_menuitem.action
        new_edit_action = QAction(action.text(), self)
        new_edit_action.setIcon(action.icon())
        new_edit_action.setShortcut(action.shortcut())
        new_edit_action.triggered.connect(lambda: self.ProcessEvent(item_id))
        new_edit_item = MenuItem(
            edit_menuitem.id,
            new_edit_action,
            lambda: self.ProcessUpdateEvent(item_id),
            None
        )
        return new_edit_item
