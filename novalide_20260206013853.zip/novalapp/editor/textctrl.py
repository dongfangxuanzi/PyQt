from ..lib.qsci import QsciScintilla
from ..lib.pyqt import QFont
from .. import constants, globalkeys
from ..util import utils


class TextCtrl(QsciScintilla):
    """description of class"""

    def __init__(self, parent):
        super().__init__(parent)

    def init_editor_font(self):
        '''
            设置编辑器默认字体
            如果未设置,默认字体为SimSun 9
        '''
        self.update_font()

    def update_font(self, family=None, fontsize=None):
        font = QFont()
        if family is None:
            family = utils.profile_get(
                globalkeys.EDITOR_FONT_FAMILY_KEY, constants.DEFAULT_FONT_FAMILY)
        font.setFamily(family)
        font.setFixedPitch(True)

        if fontsize is None:
            fontsize = self._guard_font_size(
                utils.profile_get_int(
                    globalkeys.EDITOR_FONT_SIZE_KEY, constants.DEFAULT_FONT_SIZE)
            )
        font.setPointSize(fontsize)
        self.setFont(font)
        lexer = self.lexer()
        if lexer is not None:
            lexer.setFont(font)
            lexer.setDefaultFont(font)
        # 设置空白边栏字体
        self.setMarginsFont(font)

    @staticmethod
    def _guard_font_size(size):
        if size < constants.MIN_FONT_SIZE:
            return constants.MIN_FONT_SIZE
        if size > constants.MAX_FONT_SIZE:
            return constants.MAX_FONT_SIZE
        return size
