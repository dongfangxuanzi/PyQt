# -*- coding: utf-8 -*-
import os
from .. import get_app, _, newid
from ..lib.document import Document
from .. import menuitems
from .. import constants
from .. import globalkeys
from ..bars.toolbar import ToolBar
from ..lib.pyqt import (
    QPushButton,
    QAction,
    QSize,
    QWebEngineView,
    QUrl,
    QSizePolicy,
    QHBoxLayout,
    QLabel,
    QLineEdit
)
from ..widgets import simpledialog
from .commonview import NocreateView
from ..util import ui_utils, utils
from ..api.api import ApiServer


class WebDocument(Document):
    def OnOpenDocument(self, filename):
        return True

    def reload(self):
        self.GetFirstView().webview.reload()


class HtmlwebViewer(QWebEngineView):
    """Markdown rendered content viewer"""

    def __init__(self, parent):
        super().__init__(parent)

    def get_view(self):
        return self.parent().GetView()


class WebView(NocreateView):
    def __init__(self):
        super().__init__()
        self.webview = None
        self.navigation_bar = None
        self.start_url = ''
        self.zoom_level = 0
        self.theme = None

    def OnClose(self, deleteWindow=True):
        self.Activate(False)
        if deleteWindow and self.GetFrame():
            self.GetFrame().Destroy()
        return True

    def LoadUrl(self, url):
        self.webview.load(QUrl(url))

    def OnCreate(self, doc, flags):
        template = doc.GetDocumentTemplate()
        template_icon = template.GetIcon()
        if flags & constants.APPLICATION_STARTUP_PAGE:
            template.SetIcon(None)
        frame = get_app().CreateDocumentFrame(self, doc, flags)
        frame.attach_vertical_layout()
        layout = frame.layout()
        template.SetIcon(template_icon)
        self.webview = HtmlwebViewer(frame)
        if not (flags & constants.APPLICATION_STARTUP_PAGE):
            self.navigation_bar = NavigationBar(frame, self)
            layout.addWidget(self.navigation_bar)
            # 让浏览器相应url地址的变化
            self.webview.urlChanged.connect(self.navigation_bar.renew_urlbar)
            if not (flags & constants.INTERNAL_WEB_BROWSER):
                file_url = NavigationBar.to_url(doc.GetFilename())
                self.LoadUrl(file_url)
        layout.addWidget(self.webview)
        # 切换并激活web窗口
        self.webview.setFocus()
        return True

    def UpdateUI(self, command_id):
        if command_id in [menuitems.ID_CLOSE, menuitems.ID_CLOSE_ALL, menuitems.ID_ZOOM_IN, menuitems.ID_ZOOM_OUT]:
            return True
        return super().UpdateUI(command_id)

    def ZoomView(self, delta=0):
        if self.zoom_level >= 15 and delta > 0:
            return
        if self.zoom_level <= -10 and delta < 0:
            return
        self.zoom_level += delta
        self.webview.setZoomFactor(self.zoom_level)

    def GetCtrl(self):
        return self.webview


class NavigationBar(ToolBar):

    ID_OPEN_URL = newid()
    ID_GO_BACK = newid()
    ID_GO_FORWARD = newid()
    ID_RELOAD = newid()
    ID_STOP = newid()

    def __init__(self, master, view):
        self.webview = view
        ToolBar.__init__(self, master)
        self.setIconSize(QSize(16, 16))

        go_button = QAction(get_app().GetImage(
            'web/go.png'), _('Open URL'), self)
        self.AddButton(self.ID_OPEN_URL, go_button)
        go_button.triggered.connect(self.GoUrl)

        # Back button
        back_button = QAction(get_app().GetImage(
            'web/back.png'), _('Go Back'), self)
        self.AddButton(self.ID_GO_BACK, back_button, tester=self.__can_goback)
        back_button.triggered.connect(self.go_back)

        # Forward button
        forward_button = QAction(get_app().GetImage(
            'web/forward.png'), _('Go Forward'), self)
        self.AddButton(self.ID_GO_FORWARD, forward_button,
                       tester=self.__can_goforward)
        forward_button.triggered.connect(self.go_forward)

        # Stop button
        stop_button = QAction(get_app().GetImage(
            'web/stop.png'), _('Stop'), self)
        self.AddButton(self.ID_STOP, stop_button)
        stop_button.triggered.connect(self.Stop)

        # Reload button
        reload_button = QAction(get_app().GetImage(
            'web/reload.png'), _('Reload'), self)
        self.AddButton(self.ID_RELOAD, reload_button)
        reload_button.triggered.connect(self.reload)

        self.AddLabel(text=_("URL:"))
        self.url_entry = self.AddCombox(editable=True)
        self.url_entry.setDuplicatesEnabled(True)
        self.url_entry.setSizePolicy(QSizePolicy.Expanding,
                                     QSizePolicy.Fixed)

        # 让地址栏能响应回车按键信号
        self.url_entry.lineEdit().returnPressed.connect(self.navigate_to_url)
        self.url_entry.currentIndexChanged.connect(self.on_load_url)
        # Update state of buttons
        self.Update()

    @staticmethod
    def to_url(url):
        if os.path.isfile(url):
            q = QUrl.fromLocalFile(url)
        else:
            q = QUrl(url)
            if q.scheme() == '':
                q.setScheme('http')
        return q
    # 显示地址

    def navigate_to_url(self):
        self.webview.webview.setUrl(
            self.to_url(self.url_entry.lineEdit().text()))

    def GoUrl(self):
        ok, url = simpledialog.askstring(
            _("Open URL:"),
            _("Enter a full URL or local path")
        )
        if not ok:
            return
        self.load_url(self.to_url(url))

    def go_back(self):
        if self.webview.webview:
            self.webview.webview.back()
            self.Update()

    def go_forward(self):
        if self.webview.webview:
            self.webview.webview.forward()
            self.Update()

    def reload(self):
        if self.webview.webview:
            self.webview.webview.reload()

    # 响应输入的地址
    def renew_urlbar(self, q):
        # 将当前网页的链接更新到地址栏
        url = q.toString()
        url = self.to_url(url).toString()
        self.url_entry.lineEdit().setText(url)
        self.url_entry.lineEdit().setCursorPosition(0)
        for index in range(self.url_entry.count()):
            if url == self.url_entry.itemText(index):
                return
        else:
            self.url_entry.addItem(url)

    def Stop(self):
        if self.webview.webview:
            self.webview.webview.stop()

    def on_load_url(self, i):
        self.load_url(self.url_entry.lineEdit().text())

    def load_url(self, url):
        if self.webview.webview:
            self.webview.webview.stop()
            self.webview.LoadUrl(url)
            self.webview.webview.loadFinished.connect(self.Update)

    def __can_goback(self):
        history = self.webview.webview.history()
        return history.canGoBack()

    def __can_goforward(self):
        history = self.webview.webview.history()
        return history.canGoForward()


class InternalBrowserOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    """

    def __init__(self, parent):
        super().__init__()
        homepage_layout = QHBoxLayout()
        homepage_layout.addWidget(QLabel(_('Homepage') + ":"))
        self.homepage_ctrl = QLineEdit()
        home_page = utils.profile_get(
            globalkeys.WEB_HOME_PAGE_KEY, ApiServer.HOST_SERVER_ADDR)
        self.homepage_ctrl.setText(home_page)
        homepage_layout.addWidget(self.homepage_ctrl)
        self.layout.addLayout(homepage_layout)
        restore_default_btn = QPushButton(_('Restore default'))
        restore_default_btn.clicked.connect(self.restore_default_homepage)
        self.layout.addWidget(restore_default_btn)
        self.layout.addStretch(1)

    def restore_default_homepage(self):
        self.homepage_ctrl.setText(ApiServer.HOST_SERVER_ADDR)

    def OnOK(self, options_dialog):
        url = NavigationBar.to_url(self.homepage_ctrl.text())
        utils.profile_set(globalkeys.WEB_HOME_PAGE_KEY, url.url())
        return True
