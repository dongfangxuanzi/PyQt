import os
from .util import appdirs, strutils
from .lib.pyqt import QPixmap, QIcon


def get_image_path(path):
    if not os.path.isabs(path):
        path = os.path.join(appdirs.get_app_image_location(), path)
    path = os.path.normpath(path)
    return path


def load_image(path):
    image_path = get_image_path(path)
    pixmap = QPixmap(image_path)
    return pixmap


def load_icon(path):
    """Provides a pixmap as an icon"""
    if strutils.get_file_extension(path) == 'ico':
        image_path = get_image_path(path)
        return QIcon(image_path)
    return QIcon(load_image(path))


def application_icon():
    path = os.path.join(appdirs.get_app_path(), "noval.ico")
    return QIcon(path)


def blank_icon():
    return load_icon("file/blank.png")


def text_icon():
    return load_icon("file/file.gif")


def image_icon():
    return load_icon("file/photo.png")


def python_icon():
    return load_icon("file/python_module.png")


def package_folder_icon():
    return load_image("project/python/package_obj.gif")


def folder_closed_icon():
    return load_icon("project/folder_close.png")


def project_icon():
    return load_icon("project/project.png")


def python_project_icon():
    return load_icon("project/python/project.png")
