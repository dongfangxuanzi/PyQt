# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        executable.py
Purpose:     调用可执行的命令,获取命令输出等

Author:      wukan

Created:     2019-01-10
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import os
import logging
import subprocess
import shutil
import tempfile
from typing import Optional
from .common.compat import ensure_string
from .util import strutils, utils
from .util.exceptions import CommandlineLengthExceedLimitError
from . import _

logger = logging.getLogger('ide.executable')
BUFFER_SIZE = 100 * 1000


class Executable:

    EXE_EXTENSION = ".exe"
    # 命令行参数长度不能太长超过限制
    MAX_COMMAND_LINE_LENGTH = 1000

    def __init__(self, path, cwd=None, env=None, args: Optional[list]=None):
        self._path = path
        self._install_path = os.path.dirname(self._path)
        self.args = [] if args is None else args
        self.args = self.format_args(self.args)
        # 可执行文件如果当前工作目录为空, 需要转换为None类型,否则会执行命令出错
        self._workdir = None if strutils.is_none_empty(cwd) else cwd
        self._env = env

    @staticmethod
    def format_args(args):
        new_args = []
        for arg in args:
            # 参数有空格加上引号
            arg = strutils.emphasis_path(arg)
            new_args.append(arg)
        return new_args

    @classmethod
    def cmd_list_to_str(cls, cmdlist):
        cmd_args = cls.format_args(cmdlist)
        return ' '.join(cmd_args)

    @property
    def workdir(self):
        return self._workdir

    @workdir.setter
    def workdir(self, cwd):
        self._workdir = cwd

    @property
    def path(self):
        return self._path

    @property
    def install_path(self):
        return self._install_path

    def exec_std_err_out(self, command, cwd=None, encoding=None):
        command_length = len(command)
        if command_length > self.MAX_COMMAND_LINE_LENGTH:
            logger.error(
                "command line length %d exceed max command line length %d",
                command_length,
                self.MAX_COMMAND_LINE_LENGTH
            )
            raise CommandlineLengthExceedLimitError(_('The command line is to long'))
        try:
            # 使用with可以使进程自动结束并获取错误码,
            # 程序不退出获取不到错误码
            with subprocess.Popen(
                command,
                shell=True,
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=self._env
            ) as proc:
                output = proc.stdout.read()
                err_output = proc.stderr.read()
                if encoding is not None:
                    output = ensure_string(output, encoding=encoding)
                    err_output = ensure_string(err_output, encoding=encoding)
                else:
                    output = ensure_string(output)
                    err_output = ensure_string(err_output)
            return proc.returncode, output, err_output
        except UnicodeDecodeError as ex:
            raise ex
        except Exception as exc:
            logger.error(
                "exec command %s stdout/stderr error:%s", command, exc)
            logger.exception(
                "exec command %s stdout/stderr exception:", command)
            raise exc

    @staticmethod
    def hide_startupinfo():
        '''
            隐藏可执行文件黑色窗口的启动信息
        '''
        if utils.is_windows():
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
        else:
            startupinfo = None
        return startupinfo

    @classmethod
    def get_exe_name(cls, exe):
        ext = strutils.get_file_extension(exe, keepdot=True)
        if ext == cls.EXE_EXTENSION:
            return exe
        if utils.is_windows():
            return exe + cls.EXE_EXTENSION
        return exe

    def get_cmd(self):
        path = strutils.emphasis_path(self.path)
        if self.args:
            cmd_args = self.cmd_list_to_str(self.args)
            return path + " " + cmd_args
        return path

    def combine_command(self, cmdstr):
        command = self.get_cmd()
        return command + " " + cmdstr

    def exec_command_output(self, command, cwd=None):
        '''
        执行命令获取其输出,取其标准输出或者错误输出中的一种,
        这种管道方式只能获取不太长的命令输出
        '''
        output = self.exec_command_exit_output(command, cwd)[1]
        return output

    def exec_std_err_out_encoding(self, command, cwd=None):
        try:
            exitcode, stdout_str, stderr_str = self.exec_std_err_out(
                command, cwd)
        except UnicodeDecodeError as ex:
            exitcode, stdout_str, stderr_str = self.exec_std_err_out(
                command, cwd, encoding=utils.get_default_locale_encoding()
            )
        logger.debug(
            'exec command is %s, exitcode is %d, stdout is %s, stderr is %s',
            command,
            exitcode,
            stdout_str,
            stderr_str
        )
        return exitcode, stdout_str, stderr_str

    def exec_command_exit_output(self, command, cwd=None):
        '''
             执行命令获取其输出以及退出码
        '''
        if isinstance(command, (list, tuple)):
            command = self.cmd_list_to_str(command)
        exec_command = self.combine_command(command)
        # 同时获取标准输出和错误输出,取其中一个作为程序输出,优先以标准输出为主
        exitcode, stdout_str, stderr_str = self.exec_std_err_out_encoding(exec_command, cwd)
        if 0 == exitcode:
            return exitcode, stdout_str.strip()
        return exitcode, stderr_str.strip()

    def exc_proc(self, stdout=None, stderr=None):
        cmd = self.get_cmd()
        logger.debug("exec command is %s", self.get_cmd())
        proc = subprocess.Popen(
            cmd,
            startupinfo=self.hide_startupinfo(),
            cwd=self._workdir,
            stdout=stdout,
            stderr=stderr,
            env=self._env,
            shell=True
        )
        return proc

    def popen(self):
        proc = self.exc_proc()
        proc.wait()
        returncode = proc.returncode
        logger.debug("exec command %s exit code is %d",
                     self.get_cmd(), returncode)

    @classmethod
    def get_location(cls, executable_name):
        exe_name = cls.get_exe_name(executable_name)
        path = shutil.which(exe_name)
        return path

    def exec_command_output_tempfile(self, command, cwd=None):
        '''
        调用输出巨大的命令,输出到临时文件中
        '''
        exec_command = self.combine_command(command)
        logger.info('huge output command is %s', exec_command)
        temp_file = tempfile.SpooledTemporaryFile(buffering=BUFFER_SIZE)
        fileno = temp_file.fileno()
        # 这里不能用管道,PIPE本身可容纳的量比较小,所以程序会卡死，所以一大堆内容输出过来的时候,会导致PIPE不足够处理这些内容,
        # 因此需要将输出内容定位到其他地方,例如临时文件等
        proc = subprocess.Popen(
            exec_command,
            shell=True,
            stdout=fileno,
            stderr=fileno,
            cwd=cwd,
            env=self._env
        )
        # 读取临时文件的内容,打印错误输出信息
        # 从头读取,和一般文件对象不同,seek方法的执行不能少
        proc.wait()
        temp_file.seek(0)
        return temp_file

    def run(self):
        cmd = self.get_cmd()
        subprocess.call(cmd, cwd=self.workdir, shell=True)
