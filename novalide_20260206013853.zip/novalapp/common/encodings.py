# 文本默认编码
ASCII_FILE_ENCODING = "ascii"
UTF8_FILE_ENCODING = "utf-8"
UTF8_SIG_FILE_ENCODING = "utf-8-sig"
ANSI_FILE_ENCODING = "cp936"
BINARY = 'binary'

SUPPORTED_CODECS = [
    UTF8_FILE_ENCODING,
    "iso-8859-1",
    "iso-8859-2",
    "iso-8859-3",
    "iso-8859-4",
    "iso-8859-5",
    "iso-8859-6",
    "iso-8859-7",
    "iso-8859-8",
    "iso-8859-9",
    "iso-8859-10",
    "iso-8859-11",
    "iso-8859-13",
    "iso-8859-14",
    "iso-8859-15",
    "iso-8859-16",
    "latin-1",
    "koi8-r",
    "koi8-t",
    "koi8-u",
    "utf-7",
    "utf-16",
    "utf-16-be",
    "utf-16-le",
    "utf-32",
    "utf-32-be",
    "utf-32-le",
    "cp037",
    "cp273",
    "cp424",
    "cp437",
    "cp500",
    "cp720",
    "cp737",
    "cp775",
    "cp850",
    "cp852",
    "cp855",
    "cp856",
    "cp857",
    "cp858",
    "cp860",
    "cp861",
    "cp862",
    "cp863",
    "cp864",
    "cp865",
    "cp866",
    "cp869",
    "cp874",
    "cp875",
    "cp932",
    ANSI_FILE_ENCODING,
    "cp949",
    "cp950",
    "cp1006",
    "cp1026",
    "cp1125",
    "cp1140",
    "windows-1250",
    "windows-1251",
    "windows-1252",
    "windows-1253",
    "windows-1254",
    "windows-1255",
    "windows-1256",
    "windows-1257",
    "windows-1258",
    "gb2312",
    "hz",
    "gb18030",
    "gbk",
    "iso-2022-jp",
    "iso-2022-jp-1",
    "iso-2022-jp-2",
    "iso-2022-jp-2004",
    "iso-2022-jp-3",
    "iso-2022-jp-ext",
    "iso-2022-kr",
    "mac-cyrillic",
    "mac-greek",
    "mac-iceland",
    "mac-latin2",
    "mac-roman",
    "mac-turkish",
    ASCII_FILE_ENCODING,
    "big5",
]

UTF8_ENCODING = 0
UTF8_SIG_ENCODING = 1
GBK_ENCODING = 2
ANSI_ENCODING = 3
UNKNOWN_ENCODING = -1


_KNOWN_ENCODINGS = {
    UTF8_FILE_ENCODING: UTF8_ENCODING,
    UTF8_SIG_FILE_ENCODING: UTF8_SIG_ENCODING,
    "gbk": GBK_ENCODING,
    "gb2312": GBK_ENCODING,
    "gb18030": GBK_ENCODING,
    ANSI_FILE_ENCODING: ANSI_ENCODING
}


def get_doc_encoding(encoding):
    lower_encoding = encoding.lower()
    if lower_encoding in _KNOWN_ENCODINGS:
        return _KNOWN_ENCODINGS[lower_encoding]
    return UNKNOWN_ENCODING
