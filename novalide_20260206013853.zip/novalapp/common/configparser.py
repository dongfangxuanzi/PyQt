from configparser import ConfigParser
import os
from .encodings import UTF8_FILE_ENCODING


class ConfigReader:
    """description of class"""

    def __init__(self, config_path):
        self._config_path = config_path

    def get_config(self, section, key, value=None):
        '''
            读取配置文件的属性值
        '''
        if not os.path.exists(self._config_path):
            return value
        cfg = ConfigParser()
        try:
            cfg.read(self._config_path)
        except UnicodeDecodeError:
            cfg.read(self._config_path, encoding=UTF8_FILE_ENCODING)
        if not cfg.has_option(section, key):
            return value
        return cfg.get(section, key)


class ConfigWriter:
    """description of class"""

    def __init__(self, config_path, space_around_delimiters=True):
        self._config_path = config_path
        # 键值对等于号前后是否有空格
        self._space_around_delimiters = space_around_delimiters

    def write_cofig(self, section, key, value):
        '''
            写入配置文件的属性值,以追加模式写入文件
        '''
        cfg = ConfigParser()
        cfg_encoding = None
        if os.path.exists(self._config_path):
            try:
                cfg.read(self._config_path)
            except UnicodeDecodeError:
                cfg_encoding = UTF8_FILE_ENCODING
                cfg.read(self._config_path, encoding=cfg_encoding)
        if not cfg.has_section(section):
            cfg.add_section(section)
        cfg.set(section, key, str(value))
        with open(self._config_path, "w+", encoding=cfg_encoding) as fp:
            # 写入配置文件时等于号前后是否有空格
            cfg.write(fp, self._space_around_delimiters)
