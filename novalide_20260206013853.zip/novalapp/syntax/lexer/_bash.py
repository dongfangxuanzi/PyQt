# -- coding: utf-8 --
# -------------------------------------------------------------------------------
# Name:        _bash.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-17
# Copyright:   (c) wukan 2019
# Licence:     <your licence>
# -------------------------------------------------------------------------------
# -----------------------------------------------------------------------------#
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.lib.qsci import QsciLexerBash
from novalapp.qtimage import load_icon

# -----------------------------------------------------------------------------#
# ---- Keyword Specifications ----#

kwlist = [
    'shift',
    'unset',
    'set',
    'export',
    'exit',
    'readonly',
    'if',
    'fi',
    'do',
    'then',
    'elif',
    'else',
    'for',
    'done'
]


_builtinlist = ['cat', 'echo', 'cp', 'sed', 'cd', 'sudo', 'sleep', 'grep', 'cut', 'ls', 'mv', 'rm',
                'du', 'df', 'more', 'less', 'clear', 'head', 'tail', 'wc', 'chown', 'time', 'mkdir']


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Shell/Bash"""
    # ---- Syntax Style Specs ----#

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_BASH")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('Bash/Shell Script')

    def GetExt(self):
        return "sh bash"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['#']

    def GetShowName(self):
        return "Bash/Shell"

    def GetDefaultExt(self):
        return "sh"

    def GetDocTypeName(self):
        return "Bash/Shell Document"

    def GetViewTypeName(self):
        return _("Bash/Shell Editor")

    def GetDocIcon(self):
        return load_icon("file/shell.png")

    def GetKeywords(self):
        return kwlist + _builtinlist

    def get_lexer(self, parent):
        return QsciLexerBash(parent)
