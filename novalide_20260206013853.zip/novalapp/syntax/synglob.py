import os
import importlib
import sys
from ..util import utils, strutils
from .syntax import SyntaxThemeManager
from ..lib.template import DocTemplate
from .. import qtimage


class LexerFactory:
    """description of class"""

    @staticmethod
    def CreateLexers(lang=""):
        app_dir = "novalapp"
        if lang == "":
            lexer_path = os.path.join(
                utils.get_app_path(), app_dir, "syntax", "lexer")
        else:
            lexer_path = os.path.join(
                utils.get_app_path(), app_dir, lang, "syntax", "lexer")
        sys.path.append(lexer_path)
        for fname in os.listdir(lexer_path):
            if not fname.endswith(".py"):
                continue
            modname = strutils.get_filename_without_ext(fname)
            try:
                module = importlib.import_module(modname)
                if not hasattr(module, "SyntaxLexer"):
                    continue
                cls_lexer = getattr(module, "SyntaxLexer")
                lexer_instance = cls_lexer()
                lexer_instance.register()
            except Exception as e:
                utils.get_logger().exception("")
                utils.get_logger().error("load lexer error:%s", e)

    @staticmethod
    def AddLexer(docmanager, lexer):
        utils.get_logger().info("load lexer id:%d description %s ",
                                lexer.LangId, lexer.GetDescription())
        template_icon = lexer.GetDocIcon()
        if template_icon is None:
            template_icon = qtimage.blank_icon()
        doc_template = DocTemplate(docmanager,
                                   lexer.GetDescription(),
                                   lexer.GetExtStr(),
                                   os.getcwd(),
                                   "." + lexer.GetDefaultExt(),
                                   lexer.GetDocTypeName(),
                                   lexer.GetViewTypeName(),
                                   lexer.GetDocTypeClass(),
                                   lexer.GetViewTypeClass(),
                                   icon=template_icon)
        docmanager.AssociateTemplate(doc_template)

    @classmethod
    def CreateLangLexer(cls, lang=""):
        cls.CreateLexers(lang)

    @classmethod
    def LoadLexerTemplates(cls, docmanager):
        for lexer in SyntaxThemeManager.manager().Lexers:
            cls.AddLexer(docmanager, lexer)
