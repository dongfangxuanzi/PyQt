# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""Codimension main window menu"""
import copy
import json
from typing import NamedTuple, Callable
import os
import logging
from .. import _, get_app
from ..keybinds import DEFAULT_KEY_BINDS
from ..lib.images import empty_icon
from ..lib.pyqt import (
    QMenu,
    QAction,
    QActionGroup,
    QMessageBox
)
from ..constants import (
    NORMAL_MENU_ITEM_KIND,
    CHECK_MENU_ITEM_KIND,
    RADIO_MENU_ITEM_KIND,
    USER_CACHE_DIR
)
from ..util import utils, exceptions
from .. import menuitems
log = logging.getLogger(__name__)


class MenuItem(NamedTuple):
    id: int
    action: QAction
    tester: Callable
    menu: QMenu


class KeyBinder:
    """Class for managing keybinding configurations"""
    key_binds = copy.copy(DEFAULT_KEY_BINDS)  # Active Profile (dict)
    KEY_BINDS_FILE = "keybinds.json"

    def __init__(self):
        """Create the KeyBinder object"""
        # Attributes
        self.cache = None

    @classmethod
    def CheckKeybindsConflict(cls):
        '''
            检查快捷键冲突
        '''
        accels = list(cls.key_binds.values())
        for accel in accels:
            temp_list = accels
            temp_list.remove(accel)
            if temp_list.count(accel) != 0:
                raise exceptions.ShortcutConflictedError(
                    _("Accelerator '%s' is conflicted...") % accel)

    def LoadCacheKeybinds(self):
        '''
        从配置文件中加载自定义快捷键配置
        '''
        self.GetCachedir()
        key_binds_file = os.path.join(self.cache, self.KEY_BINDS_FILE)
        if os.path.exists(key_binds_file):
            try:
                with open(key_binds_file) as f:
                    data = json.load(f)
                    binds = {}
                    for key in data:
                        keyval = self.get_menu_id_value(key)
                        binds[keyval] = data[key]
                    # 替换默认快捷键配置
                    KeyBinder.key_binds = binds
            except:
                utils.get_logger().exception("load keybind settings error:")

    def GetCachedir(self):
        if self.cache is None:
            self.cache = os.path.join(
                utils.get_user_data_path(), USER_CACHE_DIR)
        utils.get_logger().debug('user cache path is %s', self.cache)
        return self.cache

    @classmethod
    def GetBinding(cls, item_id):
        """Get the raw key binding tuple
        @param cls: Class Object
        @param item_id: MenuItem Id
        @return: tuple

        """
        return cls.key_binds.get(item_id, None)

    @classmethod
    def find_menu_id(cls, idval):
        """Find the menu item ID that the
        keybinding is currently associated with.
        @param cls: Class Object
        @param keyb: tuple of unicode (u'Ctrl', u'C')
        @return: int (-1 if not found)
        """
        menu_id = None
        for key, val in menuitems.__dict__.items():
            if val == idval:
                menu_id = key
                break
        return menu_id

    @classmethod
    def get_menu_id_value(cls, keyb):
        """
        获取menu id对应的值
        """
        return menuitems.__dict__[keyb]

    @classmethod
    def LoadDefaults(cls):
        """Load the default key profile"""
        cls.key_binds = copy.copy(DEFAULT_KEY_BINDS)


class NewQMenu(QMenu):
    """Custom wxMenu class that makes it easier to customize and access items.

    """
    INVALID_ITEM_POS = -1
    INVALID_ITEM_ID = -1

    def __init__(self, parent_or_name, menubar=None):
        """Initialize a Menu Object
        @param title: menu title string
        @param style: type of menu to create

        """
        if menubar is not None:
            super().__init__(parent_or_name, menubar)
            menubar.addMenu(self)
        else:
            super().__init__(parent_or_name)
        self.name = parent_or_name
        self.images = []
        self._items = []
        self._submenus = []
        # 菜单弹出或展开时更长菜单的状态
        self.aboutToShow.connect(self._update_menu)

    @property
    def SubMenus(self):
        return self._submenus

    @staticmethod
    def create_new_action(action):
        new_action = QAction(action.text())
        new_action.setIcon(action.icon())
        new_action.setShortcut(action.shortcut())
        return new_action

    @classmethod
    def create_invalid_item(cls, action):
        return MenuItem(cls.INVALID_ITEM_ID, action, None, None)

    def Append(self,
               item_id,
               label,
               handler=None,
               img=None,
               accelerator=None,
               tester=None,
               kind=NORMAL_MENU_ITEM_KIND
               ):
        """Append a MenuItem
        @param id_: New MenuItem ID
        @keyword text: Menu Label
        @keyword helpstr: Help String
        @keyword kind: MenuItem type
        @keyword use_bmp: try and set a bitmap if an appropriate one is
                          available in the ArtProvider

        """
        if img is None:
            img = empty_icon()
        args = [img, label, handler]
        if accelerator is not None:
            args.append(accelerator)
        if kind == NORMAL_MENU_ITEM_KIND:
            action = self.addAction(*args)
        elif kind == CHECK_MENU_ITEM_KIND:
            action = self.addAction(*args)
            action.setCheckable(True)
        elif kind == RADIO_MENU_ITEM_KIND:
            action = self.addAction(*args)
            action.setCheckable(True)
        menu_item = MenuItem(item_id, action, tester, None)
        self._items.append(menu_item)
        return menu_item

    def AppendItem(self, item, handler=None):
        """Appends a MenuItem to the menu and adds an associated
        bitmap if one is available, unless use_bmp is set to false.
        @param item: wx.MenuItem
        @keyword use_bmp: try and set a bitmap if an appropriate one is
                          available in the ArtProvider

        """
        if handler is None:
            action = item.action
        else:
            action = self.create_new_action(item.action)
            action.triggered.connect(handler)
        self.addAction(action)
        menu_item = MenuItem(item.id, action, item.tester, item.menu)
        self._items.append(menu_item)

    def AppendMenu(self, menu_id, menu):
        self._submenus.append((menu_id, menu))
        menu_item = MenuItem(menu_id, menu.menuAction(), None, menu)
        self._items.append(menu_item)
        self.addMenu(menu)

    def InsertMenu(self, pos, id_, menu):
        self._submenus.append((id_, menu))
        menu_menu_item = MenuItem(id_, menu.menuAction(), None, menu)
        before_action = self._items[pos].action
        self.insertMenu(before_action, menu)
        self._items.insert(pos, menu_menu_item)
        return menu_menu_item

    def insert_menu_after(self, item_id, id_, menu):
        '''
        插入某个子菜单之后
        '''
        pos = -1
        for i, menu_item in enumerate(self._items):
            if menu_item.id == item_id:
                pos = i
                break
        if pos > -1:
            mitem = self.InsertMenu(pos + 1, id_, menu)
        else:
            mitem = self.AppendMenu(id_, menu)
        return mitem

    def insert_menu_before(self, item_id, id_, menu):
        '''
        插入某个子菜单之前
        '''
        pos = -1
        for i, menu_item in enumerate(self._items):
            if menu_item.id == item_id:
                pos = i
                break
        if pos > -1:
            mitem = self.InsertMenu(pos, id_, menu)
        else:
            mitem = self.AppendMenu(id_, menu)
        return mitem

    def GetMenu(self, menuid):
        for menu in self._submenus:
            if menu[0] == menuid:
                return menu[1]
        return None

    def GetMenuByname(self, menu_name):
        menu_item = self.FindMenuItemByname(menu_name)
        if not menu_item:
            return None
        for menu in self._submenus:
            if menu[0] == menu_item.id:
                return menu[1]
        return None

    def find_pos(self, item_id):
        pos = self.INVALID_ITEM_POS
        for i, menu_item in enumerate(self._items):
            if menu_item.id == item_id:
                pos = i
                break
        return pos

    def InsertAfter(
        self,
        after_id,
        item_id,
        label,
        helpstr='',
        handler=None,
        img=None,
        accelerator=None,
        kind=NORMAL_MENU_ITEM_KIND,
        tester=None
    ):
        pos = self.find_pos(after_id)
        if pos == self.INVALID_ITEM_POS:
            return self.Insert(pos, item_id, label, helpstr, handler, img, accelerator, kind, tester)
        return self.Insert(pos + 1, item_id, label, helpstr, handler, img, accelerator, kind, tester)

    def InsertBefore(
        self,
        before_id,
        item_id,
        label,
        helpstr='',
        handler=None,
        img=None,
        accelerator=None,
        kind=NORMAL_MENU_ITEM_KIND,
        tester=None
    ):
        pos = self.find_pos(before_id)
        return self.Insert(pos, item_id, label, helpstr, handler, img, accelerator, kind, tester)

    def Insert(
        self,
        pos,
        item_id,
        label,
        helpstr='',
        handler=None,
        img=None,
        accelerator=None,
        kind=NORMAL_MENU_ITEM_KIND,
        tester=None
    ):
        """Insert an item at position and attach a bitmap
        if one is available.
        @param pos: Position to insert new item at
        @param id_: New MenuItem ID
        @keyword label: Menu Label
        @keyword helpstr: Help String
        @keyword kind: MenuItem type
        @keyword use_bmp: try and set a bitmap if an appropriate one is
                          available in the ArtProvider
        插入某个菜单项
        """
        if img is None:
            img = empty_icon()
        if pos == self.INVALID_ITEM_POS:
            return self.Append(
                item_id,
                label,
                handler,
                img,
                accelerator,
                tester,
                kind
            )
        item = self._items[pos]
        before_action = item.action
        action = QAction(img, label)
        if accelerator is not None:
            action.setShortcut(accelerator)
        if before_action is None:
            self.insertAction(
                self._items[pos].menu.menuAction(),
                action
            )
        else:
            self.insertAction(
                before_action,
                action
            )
        action.triggered.connect(handler)
        menu_item = MenuItem(item_id, action, tester, None)
        self._items.insert(pos, menu_item)
        return menu_item

    def RemoveItemByName(self, name):
        """Removes an item by the label. It will remove the first
        item matching the given name in the menu, the matching is
        case sensitive. The return value is the either the id of the
        removed item or None if the item was not found.
        @param name: name of item to remove
        @return: id of removed item or None if not found

        """
        menu_id = None
        for pos in range(self.GetMenuItemCount()):
            item = self.FindItemByPosition(pos)
            if name == item.GetLabel():
                menu_id = item.GetId()
                self.Remove(menu_id)
                break
        return menu_id

    def FindMenuItem(self, menu_id):
        '''
            通过id查找菜单项
        '''
        # 先从主菜单查找
        for menu_item in self._items:
            if menu_item.id == menu_id:
                return menu_item
        # 如果主菜单没有找到,则在子菜单中递归查找
        else:
            for submenu in self._submenus:
                item = submenu[1].FindMenuItem(menu_id)
                if item:
                    return item
        return None

    def GetMenuIndex(self, menu_id):
        for i, menu_item in enumerate(self._items):
            if menu_item.id == menu_id:
                return i
        return self.INVALID_ITEM_POS

    def FindMenuItemByname(self, menu_name):
        for menu_item in self._items:
            if menu_item.action.text() == menu_name:
                return menu_item
        return None

    def add_separator(self):
        action = super().addSeparator()
        menu_item = self.create_invalid_item(action)
        self._items.append(menu_item)

    def insert_separator(self, menu_item):
        last_menu_index = self.GetMenuIndex(menu_item.id)
        last_action = self._items[last_menu_index].action
        action = super().insertSeparator(last_action)
        menu_item = self.create_invalid_item(action)
        self._items.insert(last_menu_index, menu_item)

    def GetItemCount(self):
        return len(self._items)

    def GetItemByIndex(self, index):
        return self._items[index]

    def delete(self, start, end="end"):
        if end == "end":
            end_index = len(self._items) - 1
        else:
            end_index = end

        # 倒序删除,防止数组越界或者索引错误
        for i in range(end_index, start - 1, -1):
            item = self._items[i]
            super().removeAction(item.action)
            log.debug(
                'remove menu %s item index %d,id %d,text %s',
                self.name,
                i,
                item.id,
                item.action.text()
            )
            del self._items[i]

    def _update_menu(self):
        '''
            弹出菜单时更新菜单的可用状态
        '''
        for item in self._items:
            tester = item.tester
            # 根据菜单回调函数返回bool值设置菜单是否是灰色状态
            # 分割线
            if item.id == self.INVALID_ITEM_ID or item.action is None:
                continue
            if tester and not tester():
                item.action.setEnabled(False)
            else:
                item.action.setEnabled(True)

    def Enable(self, menu_id, enabled=True):
        for item in self._items:
            if menu_id == item.id:
                if not enabled:
                    item.action.setEnabled(False)
                else:
                    item.action.setEnabled(True)
                break


def find_menu(name, menubar):
    for child in menubar.children()[1:]:
        # todo 这里不知道什么地方会插入QMenu类型的子菜单，所有代码中添加的子菜单都是NewQMenu类型的
        # 不知道pyqt框架内部什么时候会插入QMenu类型的,需要了解其内部机制,理解后再优化
        assert (isinstance(child, (QMenu, NewQMenu)))
        if child.title() == name:
            return child
    newmenu = NewQMenu(name, menubar)
    return newmenu


def find_menu_item(name, item_id):
    menu = find_menu(name, get_app().Menubar)
    menu_item = menu.FindMenuItem(item_id)
    return menu_item


def create_action_group(parent):
    return QActionGroup(parent)


class MenubarMixin:
    """Main window menu mixin"""
    KEY_BINDER = KeyBinder()

    def __init__(self):
        self.KEY_BINDER.LoadCacheKeybinds()
        # 检查快捷键是否有冲突
        try:
            self.KEY_BINDER.CheckKeybindsConflict()
        except exceptions.ShortcutConflictedError as ex:
            QMessageBox.critical(self, _('Shortcut Conflict'), str(ex))

    def _init_main_menu(self):
        """Initializes the main menu bar"""
        menubar = self.menuBar()
        self.__build_filesmenu(menubar)
        self.__build_editmenu(menubar)
        self.__build_viewmenu(menubar)
        self.__build_formatmenu(menubar)
        self.__build_projectmenu(menubar)
        self.__build_runmenu(menubar)
        self.__build_toolsmenu(menubar)
        self.__build_helpmenu(menubar)

    def __build_filesmenu(self, menubar):
        """Build the tab menu"""
        filesmenu = NewQMenu(_("&File"), menubar)
        filesmenu.setObjectName('tab')
        return filesmenu

    def __build_editmenu(self, menubar):
        """Builds edit menu"""
        editmenu = NewQMenu(_("&Edit"), menubar)
        editmenu.setObjectName('edit')
        return editmenu

    def __build_viewmenu(self, menubar):
        """Build the view menu"""
        viewmenu = NewQMenu(_("&View"), menubar)
        viewmenu.setObjectName('view')
        return viewmenu

    def __build_formatmenu(self, menubar):
        """Build the view menu"""
        formatmenu = NewQMenu(_("&Format"), menubar)
        formatmenu.setObjectName('format')
        return formatmenu

    def __build_projectmenu(self, menubar):
        """Build the view menu"""
        projmenu = NewQMenu(_("&Project"), menubar)
        projmenu.setObjectName('project')
        return projmenu

    def __build_helpmenu(self, menubar):
        """Build the view menu"""
        helpmenu = NewQMenu(_("&Help"), menubar)
        helpmenu.setObjectName('help')
        return helpmenu

    def __build_toolsmenu(self, menubar):
        """Build the view menu"""
        toolsmenu = NewQMenu(_("&Tools"), menubar)
        toolsmenu.setObjectName('tools')
        return toolsmenu

    def __build_runmenu(self, menubar):
        """Build the view menu"""
        runmenu = NewQMenu(_("&Run"), menubar)
        runmenu.setObjectName('run')
        return runmenu
