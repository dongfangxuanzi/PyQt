from ..lib.pyqt import QProgressDialog, pyqtSignal, QLabel, Qt
from .. import constants


class FindTextQProgressDialog(QProgressDialog):

    update_progress_signal = pyqtSignal(int, str)

    def __init__(self, label, cancel_button_name, minimum, maximum, parent):
        super().__init__(label, cancel_button_name, minimum, maximum, parent)
        self.update_progress_signal.connect(self.update_progress)

        info_label = self.get_info_label()
        if info_label is not None:
            info_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

    def get_info_label(self):
        for childctrl in self.children():
            if isinstance(childctrl, QLabel):
                return childctrl
        return None

    def update_progress(self, curval, msg):
        if msg == constants.PROGRESS_END:
            self.setValue(self.maximum())
            self.close()
        else:
            self.setValue(curval)
            self.setLabelText(msg)
