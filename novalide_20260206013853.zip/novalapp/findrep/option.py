from typing import List
from dataclasses import dataclass


class FindOpt:
    def __init__(
        self,
        findstr: str,
        *,
        match_case: bool = False,
        match_whole_word: bool = False,
        wrap: bool = True,
        down: bool = True,
        regex: bool = False
    ):
        self.findstr = findstr
        self.match_case = match_case
        self.match_whole_word = match_whole_word
        self.wrap = wrap
        self.down = down
        self.regex = regex


@dataclass
class FindindirOpt:
    path: str
    recursive: bool
    hiddendir: bool
    filetypes: List
