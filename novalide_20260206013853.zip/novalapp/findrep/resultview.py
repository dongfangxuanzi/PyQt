# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""Find in files viewer implementation"""
import re
import os
from .. import get_app, _
from ..qtimage import load_icon
from ..lib.pyqt import (
    Qt,
    QSize,
    QToolBar,
    QHBoxLayout,
    QWidget,
    QAction,
    QLabel,
    QPlainTextEdit,
    QMessageBox,
    pyqtSignal,
    QRadioButton,
    QTextFormat,
    QTextEdit,
    QTextCursor
)
from ..widgets.spacers import ToolBarExpandingSpacer
from .findindir import (
    FILENAME_MARKER,
    FindService,
    FindResult,
    FindtoPath,
    FindWhere,
    FindIndirDialog,
    FindInprojectDialog,
    FindInfileDialog
)
from ..editor.textview import TextView
from ..util import ui_utils

MAX_RESULTS = 32


def set_position_inblock(cursor, position_inblock, anchor=QTextCursor.MoveAnchor):
    return cursor.setPosition(cursor.block().position() + position_inblock, anchor)


class DoubleClickTextEdit(QPlainTextEdit):

    INVALID_LINENO = -1

    def __init__(self, parent):
        super().__init__(parent)
        self.currentline_number = self.INVALID_LINENO

    def get_searchresult_lineno(self, line):
        doc = self.document()
        line_text = doc.findBlockByNumber(line).text()
        res = re.match(r"^Line\s(?P<line>\d+):.*", line_text)
        if res is not None:
            return int(res.groupdict().get('line'))
        return self.INVALID_LINENO

    def get_next_searchresult_lineno(self, lineno=0):
        while lineno <= self.document().blockCount():
            result_lineno = self.get_searchresult_lineno(lineno)
            if result_lineno > self.INVALID_LINENO:
                return lineno, result_lineno
            lineno += 1
        return self.INVALID_LINENO, self.INVALID_LINENO

    def get_prev_searchresult_lineno(self, lineno):
        while lineno >= 0:
            result_lineno = self.get_searchresult_lineno(lineno)
            if result_lineno > self.INVALID_LINENO:
                return lineno, result_lineno
            lineno -= 1
        return self.INVALID_LINENO, self.INVALID_LINENO

    def mouseDoubleClickEvent(self, event):
        cursor = self.textCursor()
        line = cursor.block().blockNumber()
        result_lineno = self.get_searchresult_lineno(line)
        if result_lineno > self.INVALID_LINENO:
            defLineNum = line
            filename = self.GetDefineFilename(defLineNum)
            foundDoc = get_app().GetDocumentManager().GetDocument(filename)
            if not foundDoc:
                if not os.path.exists(filename):
                    QMessageBox.critical(
                        self,
                        _("Open File Error"),
                        _("The file '%s' doesn't exist and couldn't be opened!") % filename
                    )
                    return
            # 双击搜索结果时高亮当前行
            self.highligt_currentline()
            get_app().GotoView(filename, lineNum=result_lineno, load_outline=False)
        # 不要屏蔽默认双击事件
        super().mouseDoubleClickEvent(event)

    def GetDefineFilename(self, linenum):
        while linenum > 0:
            linetext = self.document().findBlockByNumber(linenum).text()
            if linetext.find(FILENAME_MARKER) != -1 and linetext.find(FindService.LINE_PREFIX) == -1:
                filename = linetext.replace(FILENAME_MARKER, "").strip()
                return filename
            linenum -= 1
        return None

    def highligt_currentline(self):
        '''
            高亮显示搜索结果的行
        '''
        new_currentline_number = self.textCursor().blockNumber()
        if new_currentline_number != self.currentline_number:
            # 加载当前高亮行的配置颜色
            linecolor = get_app().skin['currentLinePaper']
            self.currentline_number = new_currentline_number
            hi_selection = QTextEdit.ExtraSelection()
            hi_selection.format.setBackground(linecolor)
            hi_selection.format.setProperty(
                QTextFormat.FullWidthSelection, True)
            hi_selection.cursor = self.textCursor()
            hi_selection.cursor.clearSelection()
            self.setExtraSelections([hi_selection])

    def firstVisibleLine(self):
        """Provides the first visible line. 0-based"""
        return self.firstVisibleBlock().blockNumber()

    def lastVisibleLine(self):
        """Provides the last visible line. 0-based"""
        editor_height = self.height()
        hbar = self.horizontalScrollBar()
        if hbar:
            if hbar.isVisible():
                editor_height -= hbar.height()
        block = self.firstVisibleBlock()

        last_visible = block.blockNumber()
        blocks_height = 0.0
        while block.isValid():
            if not block.isValid():
                break
            blocks_height += self.blockBoundingRect(block).height()
            if blocks_height > editor_height:
                break
            last_visible = block.blockNumber()
            block = block.next()
        return last_visible

    @property
    def cursorPosition(self):
        cursor = self.textCursor()
        return cursor.block().blockNumber(), cursor.positionInBlock()

    def check_and_convert_index(self, index):
        """Check integer index, convert from less than zero notation
        """
        if index < 0:
            index = self.document().blockCount() + index
        if index < 0 or index >= self.document().blockCount():
            raise IndexError('Invalid block index', index)
        return index

    def remove_block(self, block_index):
        block = self.document().findBlockByNumber(block_index)
        if block.next().isValid():  # not the last
            cursor = QTextCursor(block)
            cursor.movePosition(QTextCursor.NextBlock, QTextCursor.KeepAnchor)
        elif block.previous().isValid():  # the last, not the first
            cursor = QTextCursor(block.previous())
            cursor.movePosition(QTextCursor.EndOfBlock)
            cursor.movePosition(QTextCursor.NextBlock, QTextCursor.KeepAnchor)
            cursor.movePosition(QTextCursor.EndOfBlock, QTextCursor.KeepAnchor)
        else:  # only one block
            cursor = QTextCursor(block)
            cursor.movePosition(QTextCursor.EndOfBlock, QTextCursor.KeepAnchor)
        cursor.removeSelectedText()

    @cursorPosition.setter
    def cursorPosition(self, pos):
        line, col = pos

        line = min(line, self.document().blockCount() - 1)
        linetext = self.document().findBlockByNumber(line).text()
        if col is not None:
            col = min(col, len(linetext))
        else:
            col = len(linetext) - len(linetext.lstrip())
        cursor = QTextCursor(self.document().findBlockByNumber(line))
        set_position_inblock(cursor, col)
        self.setTextCursor(cursor)

    def setFirstVisible(self, lineno):
        """Scrolls the editor to make sure the first visible line is lineno"""
        current_visible = self.firstVisibleLine()
        if current_visible == lineno:
            return

        # Initial setting
        self.verticalScrollBar().setValue(lineno)
        current_visible = self.firstVisibleLine()

        while current_visible != lineno:
            vbvalue = self.verticalScrollBar().value()
            distance = lineno - current_visible
            if distance > 0:
                distance = min(2, distance)
            else:
                distance = max(-2, distance)
            self.verticalScrollBar().setValue(vbvalue + distance)
            vb_value_after = self.verticalScrollBar().value()
            if vb_value_after == vbvalue:
                break
            current_visible = self.firstVisibleLine()
        self.setHScrollOffset(0)

    def setHScrollOffset(self, value):
        """Sets the new horizontal scroll bar value"""
        hbar = self.horizontalScrollBar()
        if hbar:
            hbar.setValue(value)


class FindtextChoiceDialog(ui_utils.BaseModalDialog):
    '''
    '''

    def __init__(self, master, path_options):
        super().__init__(_("Find text"), master)
        # 禁止对话框改变大小
        label_ctrl = QLabel(_("Please choose one find option") + ":")
        self.layout.addWidget(label_ctrl)
        self.find_path_option = -1

        assert len(path_options) > 1
        self.radio_buttons = []
        for path_option in path_options:
            if path_option == FindWhere.FIND_IN_DIR:
                find_radio_button = QRadioButton(_("Find in dir"))
                self.radio_buttons.append([path_option, find_radio_button])
            elif path_option == FindWhere.FIND_IN_PROJECT:
                find_radio_button = QRadioButton(_("Find in project"))
                self.radio_buttons.append([path_option, find_radio_button])
            elif path_option == FindWhere.FIND_IN_FILE:
                find_radio_button = QRadioButton(_("Find in file"))
                self.radio_buttons.append([path_option, find_radio_button])
            self.layout.addWidget(find_radio_button)
        radio_button = self.radio_buttons[0][1]
        radio_button.setChecked(True)
        self.create_standard_buttons()

    def _ok(self):
        for findwere, radiobutton in self.radio_buttons:
            if radiobutton.isChecked():
                self.find_path_option = findwere
        super()._ok()


class FindResultsview(QWidget):
    """Search results viewer tab widget"""
    MAX_LINES = 10000
    append_result_signal = pyqtSignal(str)
    SIG_END_FIND_RESULT = pyqtSignal(str, str, int)

    def __init__(self, parent=None):
        QWidget.__init__(self, parent)

        self.__isempty = True

        self.__findtopath = None
        self.__findresult = None

        self.__results = DoubleClickTextEdit(self)
        self.__results.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.__results.setReadOnly(True)
        self.__results.setMaximumBlockCount(FindResultsview.MAX_LINES)

        # Default font size is good enough for most of the systems.
        # 12.0 might be good only in case of the XServer on PC (Xming).
        # self.messages.setFontPointSize( 12.0

        self.__create_layout(parent)
        self.__update_buttons_status()
        self.append_result_signal.connect(self.AddLine)
        self.SIG_END_FIND_RESULT.connect(self.add_find_result)

    def emit_result_signal(self, line):
        self.append_result_signal.emit(line)

    def getResultsViewer(self):
        """Provides a reference to the results tree"""
        return self.__results

    def setFocus(self):
        """Overridden setFocus"""
        self.__results.setFocus()

    def gotoline(self, line, pos=None, firstvisible=None):
        """Jumps to the given position and scrolls if needed.

        line and pos and firstVisible are 1-based
        """
        # Normalize editor line and pos
        editorline = line - 1
        if editorline < 0:
            editorline = 0
        if pos is None or pos <= 0:
            editorpos = 0
        else:
            editorpos = pos - 1

        if self.is_line_onscreen(editorline):
            if firstvisible is None:
                self.__results.cursorPosition = editorline, editorpos
                return

        self.ensure_line_onscreen(editorline)
        # Otherwise we would deal with scrolling any way, so normalize
        # the first visible line
        if firstvisible is None:
            editor_first_visible = editorline - 1
        else:
            editor_first_visible = firstvisible - 1
        if editor_first_visible < 0:
            editor_first_visible = 0

        self.__results.cursorPosition = editorline, editorpos
        self.__results.setFirstVisible(editor_first_visible)

    def ensure_line_onscreen(self, line):
        """Makes sure the line is visible on screen. line is 0-based."""
        # Prerequisite: the cursor has to be on the desired position
        if not self.is_line_onscreen(line):
            self.__results.ensureCursorVisible()

    @staticmethod
    def get_find_options():
        options = []
        current_view = get_app().GetDocumentManager().GetCurrentView()
        if current_view is not None and isinstance(current_view, TextView):
            options.append(FindWhere.FIND_IN_FILE)
        if get_app().get_current_project() is not None:
            options.append(FindWhere.FIND_IN_PROJECT)
        options.append(FindWhere.FIND_IN_DIR)
        return options

    def do_again(self):
        """Performs the action once again"""
        if self.__findtopath is None:
            options = self.get_find_options()
            find_where = -1
            if len(options) > 1:
                findtext_dlg = FindtextChoiceDialog(self, options)
                if findtext_dlg.exec_() == FindtextChoiceDialog.Accepted:
                    find_where = findtext_dlg.find_path_option
            else:
                find_where = options[0]
            if find_where == -1:
                return
            if find_where == FindWhere.FIND_IN_DIR:
                dlg = FindIndirDialog(self)
                dlg.exec_()
            elif find_where == FindWhere.FIND_IN_PROJECT:
                dlg = FindInprojectDialog(
                    self, get_app().MainFrame.GetNotebook().get_find_str())
                dlg.exec_()
            elif find_where == FindWhere.FIND_IN_FILE:
                dlg = FindInfileDialog(
                    self, get_app().MainFrame.GetNotebook().get_find_str())
                dlg.exec_()
        else:
            if self.__findtopath.findwhere == FindWhere.FIND_IN_DIR:
                dlg = FindIndirDialog(self, self.__findresult.findstr)
                dlg.path_entry.setText(self.__findtopath.findpath)
                dlg._ok()
            elif self.__findtopath.findwhere == FindWhere.FIND_IN_PROJECT:
                dlg = FindInprojectDialog(self, self.__findresult.findstr)
                dlg._ok()
            elif self.__findtopath.findwhere == FindWhere.FIND_IN_FILE:
                dlg = FindInfileDialog(self, self.__findresult.findstr)
                dlg._ok()

    def is_line_onscreen(self, line):
        """True if the line is on screen. line is 0-based."""
        if line < self.__results.firstVisibleLine():
            return False
        return line <= self.__results.lastVisibleLine()

    def AddLine(self, line_text):
        self.__results.appendPlainText(line_text.strip())
        self.__results.ensureCursorVisible()
        self.__isempty = False
        self.__update_buttons_status()

    def ClearLines(self):
        # 只读状态时无法删除数据需要先解除只读
        self.__isempty = True
        self.__results.clear()
        self.__update_buttons_status()

    def add_head_text(self, headtext, findwhere, findpath):
        self.AddLine(headtext)
        self.__findtopath = FindtoPath(findpath, findwhere)

    def add_find_result(self, resultmsg, findtext, findnum):
        self.AddLine(resultmsg)
        self.__findresult = FindResult(findtext, findnum)
        self.__isempty = False if findnum > 0 else True
        self.__update_buttons_status()

    def __removeitem(self):
        """Removes one entry of the search"""
        current_lineno = self.__results.currentline_number
        if current_lineno > self.__results.INVALID_LINENO:
            index = self.__results.check_and_convert_index(current_lineno)
            self.__results.remove_block(index)
            self.__update_buttons_status()

    def __clear(self):
        """Clears the content of the vertical layout"""
        self.__isempty = True
        self.__results.clear()
        self.__update_buttons_status()

    def __previous(self):
        """Switch to the previous results"""
        current_lineno = self.__results.currentline_number
        prev_lineno, prev_result_lineno = self.__results.get_prev_searchresult_lineno(
            current_lineno - 1)
        if prev_lineno > self.__results.INVALID_LINENO:
            self.gotoline(prev_lineno + 1)
            self.__results.highligt_currentline()
            self.__update_buttons_status()

    def __next(self):
        """Switch to the next results"""
        current_lineno = self.__results.currentline_number
        next_lineno, next_result_lineno = self.__results.get_next_searchresult_lineno(
            current_lineno + 1)
        if next_lineno > self.__results.INVALID_LINENO:
            self.gotoline(next_lineno + 1)
            self.__results.highligt_currentline()
            self.__update_buttons_status()

    def __update_buttons_status(self):
        """Updates the buttons status"""
        if not self.__isempty:
            self.__clearbtn.setEnabled(True)
            self.__prevbtn.setEnabled(True)
            self.__nextbtn.setEnabled(True)
        else:
            self.__prevbtn.setEnabled(False)
            self.__nextbtn.setEnabled(False)
            self.__removeitembtn.setEnabled(False)
            self.__clearbtn.setEnabled(False)
        self.__doagainbtn.setEnabled(True)
        if self.__results.currentline_number > self.__results.INVALID_LINENO:
            self.__removeitembtn.setEnabled(True)
        else:
            self.__removeitembtn.setEnabled(False)

    def __create_layout(self, parent):
        """Creates the toolbar and layout"""
        del parent  # unused argument

        # Buttons etc.
        self.__clearbtn = QAction(load_icon('trash.png'),
                                  _('Delete current results'), self)
        self.__clearbtn.triggered.connect(self.__clear)

        self.__prevbtn = QAction(load_icon('1leftarrow.png'),
                                 _('Previous results'), self)
        self.__prevbtn.triggered.connect(self.__previous)

        self.__nextbtn = QAction(load_icon('1rightarrow.png'),
                                 _('Next results'), self)
        self.__nextbtn.triggered.connect(self.__next)

        self.__doagainbtn = QAction(load_icon('searchagain.png'),
                                    _('Do again'), self)
        self.__doagainbtn.triggered.connect(self.do_again)

        self.__removeitembtn = QAction(load_icon('delitem.png'),
                                       _('Remove currently selected item (Del)'),
                                       self)
        self.__removeitembtn.triggered.connect(self.__removeitem)

        # The toolbar
        self.toolbar = QToolBar(self)
        self.toolbar.setOrientation(Qt.Vertical)
        self.toolbar.setMovable(False)
        self.toolbar.setAllowedAreas(Qt.RightToolBarArea)
        self.toolbar.setIconSize(QSize(16, 16))
        self.toolbar.setFixedWidth(28)
        self.toolbar.setContentsMargins(0, 0, 0, 0)

        self.toolbar.addAction(self.__prevbtn)
        self.toolbar.addAction(self.__nextbtn)
        self.toolbar.addAction(self.__doagainbtn)
        self.toolbar.addWidget(ToolBarExpandingSpacer(self.toolbar))
        self.toolbar.addAction(self.__removeitembtn)
        self.toolbar.addAction(self.__clearbtn)

        self.__hlayout = QHBoxLayout()
        self.__hlayout.setContentsMargins(0, 0, 0, 0)
        self.__hlayout.setSpacing(0)
        self.__hlayout.addWidget(self.toolbar)
        self.__hlayout.addWidget(self.__results)
        self.setLayout(self.__hlayout)
