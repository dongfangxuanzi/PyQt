# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------------
# Name:        findctrl.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-03-14
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
# -------------------------------------------------------------------------------
import re
from .. import _


class FindMixin:

    def __init__(self):
        self.last_processed_index = None

    def SetOption(self, find_option):
        self._find_option = find_option

    def getcookedpat(self):
        path = self._find_option.findstr
        if not self._find_option.regex:  # if True, see setcookedpat
            path = re.escape(path)
        if self._find_option.match_whole_word:
            path = r"\b%s\b" % path
        return path

    def getprog(self):
        "Return compiled cooked search pattern."
        path = self._find_option.findstr
        if not path:
            return None
        path = self.getcookedpat()
        flags = 0
        if not self._find_option.match_case:
            flags = flags | re.IGNORECASE
        prog = re.compile(path, flags)
        return prog

    def do_find(self, find_option, ok=0):
        '''Return (lineno, matchobj) or None for forward/backward search.

        This function calls the right function with the right arguments.
        It directly return the result of that call.

        Text is a text widget. Prog is a precompiled pattern.
        The ok parameter is a bit complicated as it has two effects.

        If there is a selection, the search begin at either end,
        depending on the direction setting and ok, with ok meaning that
        the search starts with the selection. Otherwise, search begins
        at the insert mark.

        To aid progress, the search functions do not return an empty
        match at the starting position unless ok is True.
        ok标志在替换字符串时需要设置为1
        '''
        self.SetOption(find_option)
        prog = self.getprog()
        if not prog:
            return None  # Compilation failed -- stop
        wrap = self._find_option.wrap
        firstline, firstindex, lastline, lastindex = self.get_selection()
        startline, startindex = None, None
        if not self._find_option.down:
            if ok:
                startline, startindex = lastline, lastindex
            else:
                startline, startindex = firstline, firstindex
            line, col = startline, startindex
            res = self.search_backward(prog, line, col, wrap, ok)
        else:
            if ok:
                startline, startindex = firstline, firstindex
            else:
                startline, startindex = lastline, lastindex
            line, col = startline, startindex
            res = self.search_forward(prog, line, col, wrap, ok)
        return res

    def search_forward(self, prog, line, col, wrap, ok=0):
        '''
            向下搜索
        '''
        wrapped = 0
        startline = line
        chars = self.get_line(line)
        while chars:
            m = prog.search(chars[:-1], col)
            if m:
                if ok or m.end() > col:
                    return line, m
            line += 1
            if wrapped and line > startline:
                break
            col = 0
            ok = 1
            try:
                chars = self.get_line(line)
            except IndexError:
                chars = []
            if not chars and wrap:
                wrapped = 1
                wrap = 0
                line = 0
                chars = self.get_line(0)
        return None

    def search_backward(self, prog, line, col, wrap, ok=0):
        '''
            向上搜索
        '''
        wrapped = 0
        startline = line
        chars = self.get_line(line)
        while True:
            m = self.search_reverse(prog, chars[:-1], col)
            if m:
                if ok or m.start() < col:
                    return line, m
            line -= 1
            if wrapped and line < startline:
                break
            ok = 1
            if line <= 0:
                if not wrap:
                    break
                wrapped = 1
                wrap = 0
                line_count = self.lines()
                line, col = line_count - 1, len(self.text(line_count - 1))
            chars = self.get_line(line)
            col = len(chars) - 1
        return None

    def search_reverse(self, prog, chars, col):
        '''Search backwards and return an re match object or None.

        This is done by searching forwards until there is no match.
        Prog: compiled re object with a search method returning a match.
        Chars: line of text, without \\n.
        Col: stop index for the search; the limit for match.end().
        '''
        m = prog.search(chars)
        if not m:
            return None
        found = None
        i, j = m.span()  # m.start(), m.end() == match slice indexes
        while i < col and j <= col:
            found = m
            if i == j:
                j = j + 1
            m = prog.search(chars, j)
            if not m:
                break
            i, j = m.span()
        return found

    def find_and_select(self, res):
        line, m = res
        i, j = m.span()
        sel_start = self.positionFromLineIndex(line, i)
        sel_end = self.positionFromLineIndex(line, j)
        self.set_sel(sel_start, sel_end)
        self.ensureLineVisible(line)
        return line, j

    def do_wrap_search(self, line, col, infotext_label):
        wrap_search = False
        if self.last_processed_index:
            if self._find_option.down:
                if self.last_processed_index[0] > line:
                    wrap_search = True
                elif self.last_processed_index[0] == line and self.last_processed_index[1] >= col:
                    wrap_search = True
                if wrap_search:
                    infotext_label.setText(
                        _("search from the document begging!"))
            else:
                if self.last_processed_index[0] < line:
                    wrap_search = True
                elif self.last_processed_index[0] == line and self.last_processed_index[1] <= col:
                    wrap_search = True
                if wrap_search:
                    infotext_label.setText(
                        _("search from the document endding!"))

        self.last_processed_index = line, col
        if wrap_search:
            self.last_processed_index = None
