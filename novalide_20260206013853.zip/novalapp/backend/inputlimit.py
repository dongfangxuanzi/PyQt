import logging

log = logging.getLogger(__name__)


class InputtextLimit:
    """description of class"""

    def __init__(self, shell_name="shell"):
        self._shell_name = shell_name
        self._input_start = 0

    @property
    def input_start(self):
        return self._input_start

    def _in_current_input_range(self, index=None, is_backspace=False):
        if index is None:
            index = self.get_current_pos()
        log.debug('%s current index is %d, input start index is %d',
                  self._shell_name, index, self._input_start)
        if is_backspace:
            return index > self._input_start
        return index >= self._input_start

    def trace_to_end(self):
        self.scroll_to_end()
        endpos = self.line_end_position(self.get_line_count())
        self.gotopos(endpos)
        # 记住最后输出的位置即为输入的位置
        self._input_start = self.get_current_pos()
        log.debug('%s input start index is %d',
                  self._shell_name, self._input_start)

    def get_submit_text(self):
        # 按回车键时光标当前的位置
        enter_pos = self.get_current_pos()
        # 最后的输出位置为本次输入的起始位置
        startpos = self.input_start
        submit_text = self.get_position_chars(startpos, enter_pos)
        return submit_text.strip()
