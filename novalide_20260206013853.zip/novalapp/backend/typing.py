from typing import NamedTuple
from .running import BackendProxy


class BackendSpec(NamedTuple):
    name: str
    proxy_class: BackendProxy
    description: str
    sort_key: str
