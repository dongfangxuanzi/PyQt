# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        about.py
Purpose:     关于对话框

Author:      wukan

Created:     2019-05-10
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
import datetime
from .. import get_app, _
from ..util import apputils, ui_utils
from ..qtimage import load_image
from ..plugin import iface, plugin
from ..lib.pyqt import QLabel, Qt
from .. import menuitems


class AboutDialog(ui_utils.BaseModalDialog):

    _FULL_VERSION = None

    def __init__(self, parent):
        """
        Initializes the about dialog.
        """
        title = _("About ") + get_app().GetAppName()
        super().__init__(title, parent)
        app_version = apputils.get_app_version()
        if apputils.is_dev():
            app_version += "dev"

        head_text = get_app().GetAppName() + ' ' + app_version
        heading_label = QLabel(head_text)
        heading_label.setStyleSheet(
            "font-size:19px;font-weight:bold;font-family:Arial;")
        heading_label.setAlignment(Qt.AlignCenter)
        self.layout.setSpacing(20)
        self.layout.addWidget(heading_label)

        logo_img = load_image("logo.png")
        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignCenter)
        logo_label.setPixmap(logo_img)
        self.layout.addWidget(logo_label)

        url = "http://www.novalide.com"
        url_label = QLabel()
        url_label.setText(f"<A href='{url}'>{url}</a>")
        url_label.setAlignment(Qt.AlignCenter)
        url_label.setOpenExternalLinks(True)
        self.layout.addWidget(url_label)

        platform_label = QLabel()
        self.full_version()
        text = self._FULL_VERSION + '\nMAIL wekay102200@sohu.com\nQQ 273655394\nWX w89730387'
        platform_label.setText(text)
        platform_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(platform_label)

        credits_label = QLabel()
        credits_label.setText("<A href='https://gitee.com/wekay/NovalIDE'>%s</a>" %
                              _("Based on the open source version →"))
        credits_label.setAlignment(Qt.AlignCenter)
        credits_label.setOpenExternalLinks(True)
        self.layout.addWidget(credits_label)

        text = _("Copyright © 2018-") + str(datetime.datetime.now().year) + \
            _(" wukan\nAll rights reserved")
        license_label = QLabel()
        license_label.setText(text)
        license_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(license_label)
        self.create_ok_button(center=True)

    @classmethod
    def full_version(cls):
        if cls._FULL_VERSION is None:
            python_version = "Python " + apputils.get_embed_python_version()
            pyqt_version = "PyQt " + ui_utils.getQtVersion()
            cls._FULL_VERSION = python_version + pyqt_version

    @classmethod
    def update_version(cls, update_text):
        cls.full_version()
        cls._FULL_VERSION = cls._FULL_VERSION + update_text


class AboutLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)

    def Load(self):
        get_app().AddCommand(
            menuitems.ID_ABOUT,
            _("&Help"),
            _("&About"),
            self.on_about,
            image="about.png"
        )

    def on_about(self):
        aboutdlg = AboutDialog(get_app().GetTopWindow())
        aboutdlg.exec_()
