# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2018  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""Markdown support"""
import os
import logging
from mistune.renderers.html import HTMLRenderer
import mistune

log = logging.getLogger(__name__)

CODE_BLOCK_STYLE = 'style="border-collapse:collapse;border-width:1px;border-style:solid;' \
                   'border-color:#ccc;margin-top:.5em;margin-bottom:.5em;"'


class MarkdownRenderer(HTMLRenderer):
    """Codimension custom markdown renderer"""

    def __init__(self, escape, filename):
        # 为了防止url因为安全设置转换为虚拟路径,需要设置allow_harmful_protocols为True
        super().__init__(escape=escape, allow_harmful_protocols=True)
        self.__filename = filename

    def image(self, text: str, url: str, title=None) -> str:
        """Custom image handler"""
        if url and self.__filename:
            if not os.path.isabs(url) and not url.startswith(('http://', 'https://')):
                newsrcpath = ''.join([os.path.dirname(self.__filename),
                                      os.path.sep, url])
                # 将图片路径转换为绝对路径
                url = os.path.normpath(newsrcpath)
        return super().image(text, url, title)

    def table(self, text):
        """Custom table tag renderer"""
        replacement = '<table border="1px" cellspacing="0" cellpadding="4"' + \
                      CODE_BLOCK_STYLE + '>'
        return replacement + '\n' + text + '</table>\n'


def render_markdown(text, filename):
    """Renders the given text"""
    errors = []
    renderedtext = None
    try:
        markdown = mistune.create_markdown(
            escape=False,
            plugins=['strikethrough', 'footnotes', 'table', 'speedup'],
            renderer=MarkdownRenderer(False, filename)
        )
        renderedtext = markdown(text)
    except Exception as exc:
        errors.append(str(exc))
        log.exception('render file %s html content exception:', filename)
    return renderedtext, errors
