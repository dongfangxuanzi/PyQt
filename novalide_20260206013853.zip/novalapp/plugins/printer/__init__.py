# -*- coding: utf-8 -*-
import os.path
import tempfile
import webbrowser
from pathlib import Path
import platform
import subprocess
from ... import get_app, _
from ...plugin import iface, plugin
from ... import menuitems
from ...lib.qsci import QsciScintilla
from ...lib.pyqt import QFontInfo
from ...common.encodings import UTF8_FILE_ENCODING


def print_current_script():
    editor = _get_current_editor()
    assert editor is not None

    template_fn = os.path.join(
        Path(os.path.abspath(__file__)).parent, "template.html")

    with open(template_fn, encoding=UTF8_FILE_ENCODING) as f:
        template_html = f.read()
    script_html, style_css = _export_text_as_html(editor)
    title_html = escape_html(os.path.basename(
        editor.get_view().GetDocument().GetFilename()))
    full_html = template_html.replace("%title%", title_html).replace(
        "%style%", style_css).replace("%script%", script_html)

    temp_handle, temp_fn = tempfile.mkstemp(suffix=".html", prefix="novalide_")
    with os.fdopen(temp_handle, "w", encoding=UTF8_FILE_ENCODING) as f:
        f.write(full_html)

    if platform.system() == "Darwin":
        subprocess.Popen(["open", temp_fn])
    else:
        webbrowser.open(temp_fn)


def escape_css(lex, style_isused, editor, bg_colour, wysiwyg=True):
    css = """\n"""
    if lex:
        istyle = 0
        while istyle <= QsciScintilla.STYLE_MAX:
            if (
                istyle <= QsciScintilla.STYLE_DEFAULT
                or istyle > QsciScintilla.STYLE_LASTPREDEFINED
            ) and style_isused[istyle]:
                if lex.description(istyle) or istyle == QsciScintilla.STYLE_DEFAULT:
                    font = lex.font(istyle)
                    colour = lex.color(istyle)
                    paper = lex.paper(istyle)
                    if istyle == QsciScintilla.STYLE_DEFAULT:
                        css += """span {\n"""
                    else:
                        css += """.S{0:d} {{\n""".format(istyle)
                    if font.italic():
                        css += """    font-style: italic;\n"""
                    if font.bold():
                        css += """    font-weight: bold;\n"""
                    if wysiwyg:
                        css += """    font-family: '{0}';\n""".format(
                            font.family()
                        )
                    css += """    color: {0};\n""".format(colour.name())
                    if (
                        istyle != QsciScintilla.STYLE_DEFAULT
                        and bg_colour != paper.name()
                    ):
                        css += """    background: {0};\n""".format(
                            paper.name())
                        css += """    text-decoration: inherit;\n"""
                    if wysiwyg:
                        css += """    font-size: {0:d}pt;\n""".format(
                            QFontInfo(font).pointSize()
                        )
                    css += """}\n"""

                    # get substyles
                    subs_start, subs_count = editor.getSubStyleRange(istyle)
                    for subs_idx in range(subs_count):
                        style_isused[subs_idx - subs_start] = True
                        font = lex.font(subs_start + subs_idx)
                        colour = lex.color(subs_start + subs_idx)
                        paper = lex.paper(subs_start + subs_idx)
                        html += ".S{0:d} {{\n".format(subs_idx - subs_start)
                        if font.italic():
                            html += "    font-style: italic;\n"
                        if font.bold():
                            html += "    font-weight: bold;\n"
                        if wysiwyg:
                            html += "    font-family: '{0}';\n".format(
                                font.family()
                            )
                        html += "    color: {0};\n".format(colour.name())
                        if wysiwyg:
                            html += "    font-size: {0:d}pt;\n".format(
                                QFontInfo(font).pointSize()
                            )
                        html += "}\n"
                        # __IGNORE_WARNING_Y113__
                else:
                    style_isused[istyle] = False
            istyle += 1
    else:
        colour = editor.color()
        paper = editor.paper()
        font = editor.font()
        css += """.S0 {\n"""
        if font.italic():
            css += """    font-style: italic;\n"""
        if font.bold():
            css += """    font-weight: bold;\n"""
        if wysiwyg:
            css += """    font-family: '{0}';\n""".format(font.family())
        css += """    color: {0};\n""".format(colour.name())
        if bg_colour != paper.name():
            css += """    background: {0};\n""".format(paper.name())
            css += """    text-decoration: inherit;\n"""
        if wysiwyg:
            css += """    font-size: {0:d}pt;\n""".format(
                QFontInfo(font).pointSize()
            )
        css += """}\n"""
    return css


def can_print_current_script():
    if not get_app().UpdateEditorUI(menuitems.ID_PRINT):
        return False
    active_view = get_app().GetDocumentManager().GetCurrentView()
    if hasattr(active_view, "GetLangId"):
        return True
    return False


def _export_text_as_html(editor):
    editor.recolor(0, -1)
    length_doc = editor.length()
    style_isused = {}
    onlystyles_used = True
    if onlystyles_used:
        for index in range(QsciScintilla.STYLE_MAX + 1):
            style_isused[index] = False
        # check the used styles
        pos = 0
        while pos < length_doc:
            style_isused[editor.styleAt(pos) & 0x7F] = True
            pos += 1
    else:
        for index in range(QsciScintilla.STYLE_MAX + 1):
            style_isused[index] = True
    style_isused[QsciScintilla.STYLE_DEFAULT] = True
    lex = editor.lexer()
    bgcolour = (
        lex.paper(QsciScintilla.STYLE_DEFAULT).name()
        if lex
        else editor.paper().name()
    )

    style_css = escape_css(lex, style_isused, editor, bgcolour)
    last_line = editor.lines()
    result = ""
    for i in range(0, last_line):
        result += "<code>" + \
            _export_line_as_html(editor, i, style_isused) + "</code>\n"
    return result, style_css


def _export_line_as_html(text, lineno, style_isused):
    s = text.get_line_text(lineno)
    parts = []
    for i in range(len(s)):
        pos = text.position_from_linecol(lineno, i)
        style = text.styleAt(pos)
        style_name = "S{0:d}".format(style)
        if style_isused[style] and (not parts or parts[-1][1] != style_name):
            parts.append([s[i], style_name])
        else:
            parts[-1][0] += s[i]
    result = ""
    for s, tags in parts:
        if tags:
            result += "<span class='%s'>%s</span>" % (tags, escape_html(s))
        else:
            result += escape_html(s)
    return result


def escape_html(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _get_current_editor():
    return get_app().MainFrame.GetNotebook().get_current_editor()


class FileprinterPluginLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)

    def Load(self):
        menu_item = get_app().InsertCommand(
            menuitems.ID_EXIT,
            menuitems.ID_PRINT,
            _("&File"),
            _("Print..."),
            handler=print_current_script,
            tester=can_print_current_script,
            image="toolbar/print.png"
        )
        action = menu_item.action
        get_app().MainFrame.GetToolBar().AddButton(
            menuitems.ID_PRINT,
            action,
            tester=menu_item.tester,
            pos=3,
        )
        get_app().MainFrame.UpdateToolbar()
