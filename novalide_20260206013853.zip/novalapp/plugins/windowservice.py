from novalapp.lib.pyqt import QListWidget, QVBoxLayout, QListWidgetItem
from ..plugin import iface, plugin
from ..preference.manager import PreferenceManager
from ..lib.pyqt import (
    QHBoxLayout,
    QPushButton,
    QComboBox,
    QMessageBox,
    Qt,
    QLabel,
    QCheckBox
)
from ..util import ui_utils, utils
from .. import globalkeys
from ..enums import AppStyle
from .. import menuitems
from .. import get_app, _, newid


class WindowsManagerDialog(ui_utils.BaseModalDialog):

    def __init__(self, parent):
        """
        窗口管理对话框
        """
        title = _("Windows Manager")
        super().__init__(title, parent)
        self.setFixedSize(700, 600)

        left_hbox = QHBoxLayout()
        self.contents = QListWidget()
        self.contents.setAlternatingRowColors(True)
        self.contents.itemClicked.connect(self.onItemClicked)
        left_hbox.addWidget(self.contents)

        button_vbox = QVBoxLayout()
        button_vbox.setAlignment(Qt.AlignTop)
        self.activate_button = QPushButton(_('Activate'))
        self.activate_button.clicked.connect(self.activate_doc_window)
        self.contents.itemDoubleClicked.connect(self.on_item_doubleclicked)
        button_vbox.addWidget(self.activate_button)

        self.close_button = QPushButton(_('Close'))
        button_vbox.addWidget(self.close_button)
        self.close_button.clicked.connect(self.clsoe_doc_window)

        self.save_button = QPushButton(_('Save'))
        button_vbox.addWidget(self.save_button)
        self.save_button.clicked.connect(self.save_doc_window)

        self.close_all_button = QPushButton(_('Close All'))
        button_vbox.addWidget(self.close_all_button)

        left_hbox.addLayout(button_vbox)
        self.layout.addLayout(left_hbox)

        self.close_all_button.clicked.connect(self.close_all_doc_windows)
        self.create_ok_button()
        self.load_open_docs()
        self.update_ui()

    def onItemClicked(self, item):
        self.update_ui()

    def on_item_doubleclicked(self, item):
        self.activate_item_window(item)
        self.close()

    def activate_doc_window(self):
        current_item = self.contents.currentItem()
        self.activate_item_window(current_item)

    def activate_item_window(self, item):
        doc = item.data(Qt.UserRole)
        get_app().GotoView(doc.GetFilename())

    def clsoe_doc_window(self):
        current_item = self.contents.currentItem()
        doc = current_item.data(Qt.UserRole)
        cur_row = self.contents.currentRow()
        if doc.DeleteAllViews():
            self.reload_open_docs()
        if cur_row > 0:
            self.contents.setCurrentItem(self.contents.item(cur_row - 1))
        self.update_ui()

    def save_doc_window(self):
        current_item = self.contents.currentItem()
        doc = current_item.data(Qt.UserRole)
        doc.Save()
        self.update_ui()

    def close_all_doc_windows(self):
        get_app().MainFrame.CloseAllDocs()
        self.reload_open_docs()
        self.update_ui()

    def reload_open_docs(self):
        self.contents.clear()
        self.load_open_docs()

    def load_open_docs(self):
        notebook = get_app().MainFrame.GetNotebook()
        for index in range(notebook.count()):
            doc = notebook.GetDocumentFromPageIndex(index)
            listitem = QListWidgetItem('')
            listitem.setData(Qt.UserRole, doc)
            self.contents.addItem(listitem)
            self.update_item_path(listitem)

    def update_item_path(self, item):
        doc = item.data(Qt.UserRole)
        filepath = doc.GetFilename()
        if doc.IsModified():
            filepath += "*"
        item.setText(filepath)

    def update_ui(self):
        if self.contents.count() > 0:
            self.close_all_button.setEnabled(True)
        else:
            self.close_all_button.setEnabled(False)
        current_item = self.contents.currentItem()
        if current_item is None:
            self.activate_button.setEnabled(False)
            self.close_button.setEnabled(False)
            self.save_button.setEnabled(False)
        else:
            self.activate_button.setEnabled(True)
            self.close_button.setEnabled(True)
            doc = current_item.data(Qt.UserRole)
            if doc.IsModified():
                self.save_button.setEnabled(True)
            else:
                self.save_button.setEnabled(False)
            self.update_item_path(current_item)


class WindowsOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    """

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.layout.setAlignment(Qt.AlignTop)
        self.loadlayout_checkbox = QCheckBox(
            _("Load the last window layout at start up"))
        self.loadlayout_checkbox.setChecked(
            utils.profile_get_int(globalkeys.LOAD_LAST_PERSPECTIVE_KEY, True))
        self.layout.addWidget(self.loadlayout_checkbox)

        self.maximize_window_checkbox = QCheckBox(
            _("Launch to maximize the window at start up"))
        self.maximize_window_checkbox.setChecked(
            utils.profile_get_int(globalkeys.MAXIMIZE_WINDOW_KEY, False))
        self.layout.addWidget(self.maximize_window_checkbox)

        self.hidemenubar_checkbox = QCheckBox(
            _("Hide menubar When full screen display"))
        self.hidemenubar_checkbox.setChecked(
            utils.profile_get_int(globalkeys.HIDE_MENUBAR_KEY, False))
        self.layout.addWidget(self.hidemenubar_checkbox)

        hbox = QHBoxLayout()
        hbox.setAlignment(Qt.AlignLeft)
        hbox.addWidget(QLabel(_("Application look") + ":"))
        self.application_looks_combobox = QComboBox()
        self.application_looks_combobox.addItems(get_app().application_looks)
        app_style_name = get_app().app_style_name
        if app_style_name != AppStyle.DEFAULT_APP_STYLE.value:
            index = get_app().application_looks.index(app_style_name)
        else:
            index = get_app().application_looks.index(get_app().app_skin_name)
        if index == -1:
            index = 0
        self.application_looks_combobox.setCurrentIndex(index)
        self._current_applook_index = index
        hbox.addWidget(self.application_looks_combobox)
        self.layout.addLayout(hbox)

        clear_window_layout_btn = QPushButton(
            _("Clear Window layout configuration information"))
        clear_window_layout_btn.clicked.connect(
            self.ClearWindowLayoutConfiguration)
        self.layout.addWidget(clear_window_layout_btn)

    def OnOK(self, optionsDialog):
        # if utils.profile_get('UI_SCALING_FACTOR','') != self._scaleVar.get():
        # messagebox.showinfo(GetApp().GetAppName(),_("Scale changes will not appear until the application is restarted."),parent=self)
        utils.profile_set(globalkeys.LOAD_LAST_PERSPECTIVE_KEY,
                          self.loadlayout_checkbox.isChecked())
        utils.profile_set(globalkeys.MAXIMIZE_WINDOW_KEY,
                          self.maximize_window_checkbox.isChecked())
        utils.profile_set(globalkeys.HIDE_MENUBAR_KEY,
                          self.hidemenubar_checkbox.isChecked())

        current_app_look = self.application_looks_combobox.currentText()
        app_look_changed = self._current_applook_index != self.application_looks_combobox.currentIndex()
        # 修改程序样式
        if app_look_changed:
            get_app().update_applook_config(current_app_look)
            get_app().load_skin()
        # 发送界面主题更改信号
        get_app().MainFrame.UI_WINDOW_THEME_CHANGED.emit()
        return True

    def ClearWindowLayoutConfiguration(self):
        config = get_app().GetConfig()
        config.DeleteEntry("DefaultPerspective")
        config.DeleteEntry(globalkeys.LAST_PERSPECTIVE_KEY)
        QMessageBox.information(self, get_app().GetAppName(), _(
            "Already Clear Window layout configuration information"))


class WindowServiceLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)

    def Load(self):
        PreferenceManager.manager().AddOptionsPanelClass(
            _("Environment"),
            "Appearance",
            _("Appearance"),
            WindowsOptionPanel
        )

        get_app().InsertCommand(
            menuitems.ID_PREFERENCES,
            newid(),
            _("&Tools"),
            _("&Windows Manager"),
            self.open_windows_manager
        )

    def open_windows_manager(self):
        external_dlg = WindowsManagerDialog(get_app().GetTopWindow())
        external_dlg.exec_()
