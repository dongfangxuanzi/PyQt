# -*- coding: utf-8 -*-
import os
import sys
import time
from . import process
from ..lib.pyqt import QThread
from ..util import strutils, utils, terminal
from .. import globalkeys, constants
from ..util.exceptions import StartupPathNotExistError

SOURCE_DEBUG = 'Debug'


class OutputReaderThread(QThread):
    def __init__(self, parent, proc, file, callback_function, callbackOnExit=None, accumulate=True):
        super().__init__(parent)
        self._file = file
        self._proc = proc
        self._callback_function = callback_function
        self._keep_going = True
        self._linecount = 0
        # 每行允许输出的最大字符数
        self._max_line_length = sys.maxsize
        # 限制行字符个数
        self._limit_line_length = utils.profile_get_int(
            globalkeys.OUTPUT_LIMIT_LINELENGTH_KEY,
            True
        )
        if self._limit_line_length:
            self._max_line_length = utils.profile_get_int(
                globalkeys.MAX_OUTPUT_LINELENGTH_KEY, constants.MAX_OUTPUT_LINELENGTH)
        self._accumulate = accumulate
        self._callbackOnExit = callbackOnExit

    def __del__(self):
        # See comment on PythonDebuggerUI.StopExecution
        self._keep_going = False

    def run(self):
        file = self._file
        start = time.time()
        output = ""
        while self._keep_going:
            try:
                # This could block--how to handle that?
                text = file.readline()
                # 截取行长度
                if self._limit_line_length and len(text) > self._max_line_length:
                    utils.get_logger().info(
                        'line text length %d will truncate to %d',
                        len(text),
                        self._max_line_length
                    )
                    text = text[:self._max_line_length]
                if strutils.is_none_empty(text):
                    self._keep_going = False
                elif not self._accumulate and self._keep_going:
                    self.wrap_callback(text)
                else:
                    # Should use a buffer? StringIO?
                    output += text
                # Seems as though the read blocks if we got an error, so, to be
                # sure that at least some of the exception gets printed, always
                # send the first hundred lines back as they come in.
                if self._linecount < 100 and self._keep_going:
                    self.wrap_callback(output)
                    self._linecount += 1
                    output = ""
                elif time.time() - start > 0.25 and self._keep_going:
                    try:
                        self.wrap_callback(output)
                    except wx._core.PyDeadObjectError:
                        # GUI was killed while we were blocked.
                        self._keep_going = False
                    start = time.time()
                    output = ""
                elif not self._keep_going:
                    self.wrap_callback(output)
                    output = ""
            except:
                utils.get_logger().exception("Exception in OutputReaderThread.run():")
                self._keep_going = False
        if self._callbackOnExit:
            try:
                if self._proc.poll() is not None:
                    utils.get_logger().info(
                        'run command %s exitcode is %d',
                        self._proc._cmd,
                        self._proc.returncode
                    )
                    self._callbackOnExit(self._proc.returncode)
                else:
                    raise RuntimeError('Poll proc returcode error')
            except Exception as e:
                utils.get_logger().exception("")
        utils.get_logger().debug("Exiting OutputReaderThread")

    def wrap_callback(self, content):
        self._callback_function(content)

    def AskToStop(self):
        utils.get_logger().info('User stop running process pid: %d', self._proc._processId)
        self._keep_going = False


class TerminalExecutor:
    def __init__(self, run_parameter):
        self._run_parameter = run_parameter
        # should convert to unicode when interpreter path contains chinese self._run_parameter.Environmentcharacter
        self._path = self._run_parameter.ExePath
        self._cmd = strutils.emphasis_path(self._path)

    # Better way to do this? Quotes needed for windows file paths.
    def spaceAndQuote(self, text):
        '''
            将路径用双引号括起来,防止路径包含空格出错
        '''
        if text.startswith("\"") and text.endswith("\""):
            return ' ' + text
        return ' \"' + text + '\"'

    def GetStartupPath(self):
        startin = self._run_parameter.StartupPath
        if not startin:
            startin = os.getcwd()
        if not os.path.exists(startin):
            raise StartupPathNotExistError(startin)
        return startin

    def GetExecuteCommand(self):
        arguments = self._run_parameter.Arg
        if arguments and arguments != " ":
            command = self._cmd + ' ' + arguments
        else:
            command = self._cmd
        return command

    def Execute(self):
        command = self.GetExecuteCommand()
        utils.get_logger().debug("start run executable: %s in terminal", command)
        startin = self.GetStartupPath()
        terminal.run_in_terminal(
            command,
            startin,
            self._run_parameter.Environment,
            keep_open=False,
            pause=utils.profile_get_int(
                globalkeys.KEEP_TERMINAL_PAUSE_KEY, True),
            title="abc",
            overwrite_env=False
        )

    def GetExecPath(self):
        return self._path


class Executor(TerminalExecutor):
    def __init__(self, run_parameter, wxComponent, finish_stopped=True, source=SOURCE_DEBUG):
        TerminalExecutor.__init__(self, run_parameter)
        self._stdout_callback = self.OutCall
        self._stderr_callback = self.ErrCall
        self._callback_onexit = self.callbackOnExit
        self._finish_stopped = finish_stopped
        self._component = wxComponent
        self._stdout_reader = None
        self._stderr_reader = None
        self._process = None
        self.source = source

    @property
    def process(self):
        return self._process

    def OutCall(self, text):
        self._component.SIG_UPDATE_STDTEXT.emit(text, self.source)

    def ErrCall(self, text):
        self._component.SIG_UPDATE_ERRTEXT.emit(text, self.source)

    def callbackOnExit(self, exitcode):
        self._component.SIG_EXECUTE_FINISHED.emit(exitcode, self._finish_stopped)

    def Execute(self):
        command = self.GetExecuteCommand()
        startin = self.GetStartupPath()
        utils.get_logger().debug("start debugger executable: %s", command)
        self._process = process.ProcessOpen(
            command, mode='b', cwd=startin, env=self._run_parameter.Environment)
        # Kick off threads to read stdout and stderr and write them
        # to our text control.
        self._stdout_reader = OutputReaderThread(
            self._component,
            self._process,
            self._process.stdout,
            self._stdout_callback,
            callbackOnExit=self._callback_onexit
        )
        self._stdout_reader.start()
        self._stderr_reader = OutputReaderThread(
            self._component,
            self._process,
            self._process.stderr,
            self._stderr_callback,
            accumulate=False
        )
        self._stderr_reader.start()

    def DoStopExecution(self):
        # See comment on PythonDebuggerUI.StopExecution
        if self._process is not None:
            self._stdout_reader.AskToStop()
            self._stderr_reader.AskToStop()
            try:
                self._process.kill(gracePeriod=2.0)
            except:
                pass
            self._process = None

    def write_input(self, text):
        if None == self._process:
            return
        self._process.stdin.write(text)
