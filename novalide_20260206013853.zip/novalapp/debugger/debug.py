# -*- coding: utf-8 -*-
import os
from .. import _, newid, get_app
from ..editor.texteditor import TextEditor
from ..lib.pyqt import QFrame, QVBoxLayout, QColor, QFont, Qt, QFileDialog, QMessageBox
from ..lib.qsci import QsciScintilla
from ..editor.textctrl import TextCtrl
from .. import constants, menuitems, globalkeys
from ..util import utils, strutils, ui_utils
from ..bars.menubar import find_menu, NewQMenu
from ..preference.manager import GetOptionName
from ..preference.preference import PreferenceDialog
from ..backend.inputlimit import InputtextLimit
from ..common.encodings import UTF8_FILE_ENCODING


class DebugCtrl(TextEditor, InputtextLimit):
    '''
        调式输出控件同时兼顾查找功能
    '''
    TEXT_WRAP_ID = newid()
    EXPORT_TEXT_ID = newid()
    CLEAR_OUTPUT_ID = newid()
    SETTINGS_ID = newid()

    DEFAULT_OUTPUT_FONTSIZE = 9
    ERROR_COLOR_STYLE = 2
    INPUT_COLOR_STYLE = 1

    def __init__(self, parent):
        '''
            公共输出文本控件
        '''
        TextEditor.__init__(self, parent, get_app().GetDebugger().GetView())
        InputtextLimit.__init__(self, "debug output")
        self._executor = None
        # 设置输出默认字体大小
        self._font = QFont(constants.DEFAULT_FONT_FAMILY,
                           self.DEFAULT_OUTPUT_FONTSIZE)
        self.setFont(self._font)
        self.UpdateLineNumberWidth(False)
        self.cursorPositionChanged.connect(self.__cursorPositionChanged)
        self.update_config_styles()
        self._is_wrap = utils.profile_get_int(
            globalkeys.OUTPUT_WORDWRAP_KEY, False)
        self.SetWrap()

    def update_config_styles(self):
        io_background_color = get_app().skin['ioconsolePaper']
        # 设置输出配置背景色
        self.setPaper(io_background_color)

        input_foreground_color = utils.profile_get(
            globalkeys.OUTPUT_STANDARD_INPUT_COLOR_KEY,
            get_app().skin['ioconsoleStdinColor'].name()
        )
        self.set_style_spec(constants.DEFAULT_FONT_FAMILY, QColor(
            input_foreground_color), io_background_color, self.DEFAULT_OUTPUT_FONTSIZE, self.INPUT_COLOR_STYLE)

        output_foreground_color = utils.profile_get(
            globalkeys.OUTPUT_STANDARD_OUTPUT_COLOR_KEY,
            get_app().skin['ioconsoleColor'].name()
        )
        # 设置默认输出字体颜色
        self.setColor(QColor(output_foreground_color))

        err_foreground_color = utils.profile_get(
            globalkeys.OUTPUT_STANDARD_ERROR_COLOR_KEY,
            get_app().skin['ioconsoleStderrColor'].name()
        )
        self.set_style_spec(constants.DEFAULT_FONT_FAMILY, QColor(
            err_foreground_color), io_background_color, self.DEFAULT_OUTPUT_FONTSIZE, self.ERROR_COLOR_STYLE)

    def keyPressEvent(self, event):
        """Handles the key press events"""
        key = event.key()
        if self.isReadOnly():
            # 文本只读时按这些键及时响告警声音
            if key in [
                Qt.Key_Enter,
                Qt.Key_Return,
                Qt.Key_Backspace,
                Qt.Key_Delete,
                Qt.Key_Space,
                Qt.Key_X,
                Qt.Key_Tab
            ]:
                get_app().beep()
                event.ignore()
            else:
                super().keyPressEvent(event)
        else:
            # 组合键
            modifiers = event.modifiers()
            # 单个按键限制键盘输入, 包括数字小键盘
            if int(modifiers) == Qt.NoModifier or modifiers & Qt.KeypadModifier:
                is_backspace = True if key == Qt.Key_Backspace else False
                if not self._in_current_input_range(is_backspace=is_backspace):
                    get_app().beep()
                    event.ignore()
                else:
                    # Key_Enter表示键盘右侧的回车键(数字小键盘), Key_Return表示键盘中部的回车键
                    if key in [Qt.Key_Enter, Qt.Key_Return]:
                        input_chars = self.get_submit_text()
                        # 继续执行原有的回车事件
                        super().keyPressEvent(event)
                        # 向进程写入输入文本
                        self._executor.write_input(input_chars + "\n")
                    else:
                        super().keyPressEvent(event)
                        # 允许键盘输入的asd字符可以作为输入
                        if int(Qt.Key_Space) <= key <= 126:
                            # 对输入字符进行着色
                            self.startStyling(self.input_start)
                            current_pos = self.get_current_pos()
                            self.setStyling(
                                current_pos - self.input_start, self.INPUT_COLOR_STYLE)
            else:
                # 组合键基本不限制,除了极个别之外
                # Ctrl+X/Shift+Del/Alt+D/Alt+X deletes something
                if key in [Qt.Key_X, Qt.Key_V]:
                    if not self._in_current_input_range():
                        get_app().beep()
                        event.ignore()
                        return
                super().keyPressEvent(event)

    def get_edit_menuitem(self, edit_menu, item_id):
        new_item = self.create_edit_menuitem(edit_menu, item_id)
        self._menu.AppendItem(new_item)

    def CanCut(self):
        if not self._in_current_input_range():
            return False
        return super().CanCut()

    def CanPaste(self):
        if not self._in_current_input_range():
            return False
        return super().CanPaste()

    def CreatePopupMenu(self):
        if self._menu is None:
            self._menu = NewQMenu(self)
            edits_menu = find_menu(_("&Edit"), get_app().Menubar)
            self.get_edit_menuitem(edits_menu, menuitems.ID_CUT)
            self.get_edit_menuitem(edits_menu, menuitems.ID_COPY)
            self.get_edit_menuitem(edits_menu, menuitems.ID_PASTE)
            self.get_edit_menuitem(edits_menu, menuitems.ID_CLEAR)
            self.get_edit_menuitem(edits_menu, menuitems.ID_SELECTALL)
            self._menu.add_separator()
            item = self._menu.Append(self.TEXT_WRAP_ID, _(
                "Word wrap"), kind=constants.CHECK_MENU_ITEM_KIND, handler=self.toogle_wrap)
            item.action.setChecked(self._is_wrap)
            self.get_edit_menuitem(edits_menu, menuitems.ID_FIND)
            self._menu.Append(self.EXPORT_TEXT_ID, _(
                "Export output"), handler=self.SaveAll)
            self._menu.Append(self.CLEAR_OUTPUT_ID, _(
                "Clear all"), handler=self.ClearOutput, img=get_app().GetImage('icon_clear_console.png'))
            self._menu.Append(self.SETTINGS_ID, _(
                "Settings"), handler=self.SetOutput)

    def SetOutput(self):
        preference_dlg = PreferenceDialog(
            self, selection=GetOptionName(_("Debug|Run"), "Output"))
        preference_dlg.exec_()

    def SetWrap(self):
        '''
            设置是否自动换行
        '''
        if self._is_wrap:
            # 自动换行模式, 在单词边界处环绕
            self.set_wrap_mode(QsciScintilla.WrapWord)
        else:
            # 不自动换行
            self.set_wrap_mode(QsciScintilla.WrapNone)

    def toogle_wrap(self):
        self._is_wrap = not self._is_wrap
        self.SetWrap()

    def ActivateView(self):
        self.setFocus()
        get_app().GetDocumentManager().ActivateView(self.get_view())

    def mouseReleaseEvent(self, event):
        self.ActivateView()
        TextCtrl.mouseReleaseEvent(self, event)

    def ClearOutput(self):
        self.setReadOnly(False)
        self.clearall()
        self.setReadOnly(True)

    def SaveAll(self):
        text_template = get_app().GetDocumentManager().FindTemplateForPath("test.txt")
        descrs = strutils.get_template_filter(text_template)
        filename, filetype = QFileDialog.getSaveFileName(
            self,
            _('Save As'),
            os.path.join(text_template.GetDirectory(), "outputs.txt"),
            descrs  # 设置文件扩展名过滤,用双分号间隔
        )

        if filename == "":
            return
        try:
            with open(filename, "w", encoding=UTF8_FILE_ENCODING) as f:
                content = self.text()
                # w模式表示文本模式,此模式下解释器会自动将\n换行符转换成系统适配的换行符.
                # 故需要把换行符统一替换为\n,然后会自动适配系统对应的换行符,否则会导致导出的文本文件有很多多余的空行
                content = content.replace(os.linesep, "\n")
                f.write(content)
        except Exception as e:
            QMessageBox.critical(self, _("Error"), str(e))

    def mouseDoubleClickEvent(self, event):
        super().mouseDoubleClickEvent(event)

    def AppendStdoutText(self, source, text, last_readonly=False):
        '''
            输出文本时输出框不要设置为readonly,在最后一次输出,即程序完成或者退出时才执行readonly
        '''
        self.setReadOnly(False)
        self.append_text(text)
        self.trace_to_end()
        if last_readonly:
            self.setReadOnly(True)

    @ui_utils.call_after_with_time(10)
    def AppendStdErrorText(self, source, text, last_readonly=False):
        '''
            输出文本时输出框不要设置为readonly,在最后一次输出,即程序完成或者退出时才执行readonly
        '''
        self.setReadOnly(False)
        pos = self.get_current_pos()
        chars_length = self.append_text(text)
        self.startStyling(pos)
        self.setStyling(chars_length, self.ERROR_COLOR_STYLE)
        self.trace_to_end()
        if last_readonly:
            self.setReadOnly(True)

    def SetExecutor(self, executor):
        self._executor = executor

    def __cursorPositionChanged(self):
        """Triggered when the cursor position changed"""
        self.ActivateView()


class DebugFrame(QFrame):
    def __init__(self, master, is_debug=False):
        super().__init__(master)
        self.text = self.GetOuputctrlClass()(self)
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.text)
        self.setLayout(layout)

    def SetExecutor(self, executor):
        self.text.SetExecutor(executor)

    def GetOutputCtrl(self):
        return self.text

    def GetOuputctrlClass(self):
        return DebugCtrl

    def shouldAcceptFocus(self):
        return True
