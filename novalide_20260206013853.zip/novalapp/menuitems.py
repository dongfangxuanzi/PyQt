# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        menuitems.py
Purpose:     菜单id定义模块

Author:      wukan

Created:     2019-01-16
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
from . import newid


# File Menu IDs

ID_NEW = newid()
ID_OPEN = newid()
ID_CLOSE = newid()
ID_CLOSE_ALL = newid()
ID_SAVE = newid()
ID_SAVEAS = newid()
ID_SAVEALL = newid()
ID_PRINT = newid()
ID_EXIT = newid()


# Edit Menu IDs

ID_UNDO = newid()
ID_REDO = newid()
ID_CUT = newid()
ID_COPY = newid()
ID_PASTE = newid()
ID_CLEAR = newid()
ID_SELECTALL = newid()

ID_FIND = newid()            # for bringing up Find dialog box
ID_FIND_PREVIOUS = newid()   # for doing Find Next
ID_FIND_NEXT = newid()       # for doing Find Prev
ID_REPLACE = newid()         # for bringing up Replace dialog box
ID_GOTO_LINE = newid()       # for bringing up Goto dialog box

ID_FINDFILE = newid()        # for bringing up Find in File dialog box
ID_FINDALL = newid()         # for bringing up Find All dialog box
ID_FINDDIR = newid()         # for bringing up Find Dir dialog box

ID_INSERT = newid()
ID_INSERT_DATETIME = newid()
ID_INSERT_COMMENT_TEMPLATE = newid()
ID_INSERT_FILE_CONTENT = newid()
ID_INSERT_DECLARE_ENCODING = newid()
ID_INSERT_MAIN_STATEMENT = newid()

ID_ADVANCE = newid()
ID_UPPERCASE = newid()
ID_LOWERCASE = newid()
ID_FIRST_UPPERCASE = newid()
ID_COPY_LINE = newid()
ID_CUT_LINE = newid()
ID_DELETE_LINE = newid()
ID_CLONE_LINE = newid()
ID_TAB_SPACE = newid()
ID_SPACE_TAB = newid()

ID_GOTO_DEFINITION = newid()
ID_FIND_OCCURRENCES = newid()
ID_WORD_LIST = newid()
ID_AUTO_COMPLETE = newid()
ID_LIST_MEMBERS = newid()

# View Menu IDs
ID_VIEW_TOOLBAR = newid()
ID_VIEW_STATUSBAR = newid()
ID_VIEW_APPLICAITON_LOOK = newid()

ID_OUTLINE_SORT = newid()
ID_SORT_BY_LINE = newid()
ID_SORT_BY_NAME = newid()
ID_SORT_BY_NONE = newid()
ID_SORT_BY_TYPE = newid()


ID_DISPLAY_SYMBOL = newid()
ID_VIEW_WHITESPACE = newid()
ID_VIEW_EOL = newid()
ID_VIEW_INDENTATION_GUIDES = newid()
ID_VIEW_RIGHT_EDGE = newid()
ID_VIEW_LINE_NUMBERS = newid()

ID_ZOOM = newid()
ID_ZOOM_NORMAL = newid()
ID_ZOOM_IN = newid()
ID_ZOOM_OUT = newid()

ID_NEXT_POS = newid()
ID_PRE_POS = newid()
ID_SHOW_FULLSCREEN = newid()
ID_HIDE_SIDEBARS = newid()

# Format Menu IDs
ID_CLEAN_WHITESPACE = newid()
ID_COMMENT_LINES = newid()
ID_UNCOMMENT_LINES = newid()
ID_INDENT_LINES = newid()
ID_DEDENT_LINES = newid()
ID_USE_TABS = newid()
ID_SET_INDENT_WIDTH = newid()

ID_EOL_MODE = newid()
ID_EOL_MAC = newid()
ID_EOL_UNIX = newid()
ID_EOL_WIN = newid()

# Project Menu IDs
ID_NEW_PROJECT = newid()
ID_OPEN_PROJECT = newid()
ID_SAVE_PROJECT = newid()
ID_CLOSE_PROJECT = newid()
ID_DELETE_PROJECT = newid()
ID_CLEAN_PROJECT = newid()
ID_ARCHIVE_PROJECT = newid()
ID_ADD_FOLDER = newid()
ID_REFRESH_FOLDER = newid()
ID_IMPORT_FILES = newid()
ID_ADD_NEW_FILE = newid()
ID_ADD_PACKAGE_FOLDER = newid()
ID_ADD_FILES_TO_PROJECT = newid()
ID_ADD_CURRENT_FILE_TO_PROJECT = newid()
ID_ADD_DIR_FILES_TO_PROJECT = newid()
ID_PROPERTIES = newid()

# project popup Menu IDs
ID_OPEN_SELECTION = newid()
ID_OPEN_SELECTION_WITH = newid()
ID_REMOVE_FROM_PROJECT = newid()
ID_RENAME = newid()
ID_SET_PROJECT_STARTUP_FILE = newid()
ID_OPEN_FOLDER_PATH = newid()
ID_COPY_PATH = newid()
ID_OPEN_TERMINAL_PATH = newid()
ID_OPEN_IN_BROWSER = newid()

# Run Menu IDs
ID_RUN = newid()
ID_DEBUG = newid()
ID_SET_EXCEPTION_BREAKPOINT = newid()
ID_STEP_INTO = newid()
ID_STEP_CONTINUE = newid()
ID_STEP_OUT = newid()
ID_STEP_NEXT = newid()

ID_EXECUTE_CODE = newid()
ID_BREAK_INTO_DEBUGGER = newid()
ID_RESTART_DEBUGGER = newid()
ID_QUICK_ADD_WATCH = newid()
ID_ADD_WATCH = newid()
ID_ADD_TO_WATCH = newid()
ID_TERMINATE_DEBUGGER = newid()


ID_CHECK_SYNTAX = newid()
ID_SET_PARAMETER_ENVIRONMENT = newid()
ID_RUN_LAST = newid()
ID_DEBUG_LAST = newid()

ID_TOGGLE_BREAKPOINT = newid()
ID_CLEAR_ALL_BREAKPOINTS = newid()
ID_START_WITHOUT_DEBUG = newid()

# Tools Menu IDs
ID_OPEN_TERMINAL = newid()
ID_UNITTEST = newid()
ID_OPEN_INTERPRETER = newid()
ID_OPEN_BROWSER = newid()
ID_PLUGIN = newid()
ID_PREFERENCES = newid()


# Help Menu IDs
ID_OPEN_PYTHON_HELP = newid()
ID_OPEN_DOCUMENTATION = newid()
ID_TIPS_DAY = newid()
ID_CHECK_UPDATE = newid()
ID_GOTO_OFFICIAL_WEB = newid()
ID_GOTO_PYTHON_WEB = newid()
ID_FEEDBACK = newid()
ID_ABOUT = newid()
ID_REGISTER_LOGOUT = newid()


# Document popup Menu IDs
ID_NEW_MODULE = newid()
ID_SAVE_DOCUMENT = newid()
ID_SAVE_AS_DOCUMENT = newid()
ID_CLOSE_DOCUMENT = newid()
ID_CLOSE_ALL_WITHOUT = newid()
ID_OPEN_DOCUMENT_DIRECTORY = newid()
ID_OPEN_TERMINAL_DIRECTORY = newid()
ID_COPY_DOCUMENT_PATH = newid()
ID_COPY_DOCUMENT_NAME = newid()
ID_COPY_MODULE_NAME = newid()
ID_MAXIMIZE_EDITOR_WINDOW = newid()
ID_RESTORE_EDITOR_WINDOW = newid()
ID_RELOAD_DOCUMENT = newid()

# toolbar combo interpreter list
ID_COMBO_INTERPRETERS = newid()
ID_OUTLINE_SYNCTREE = newid()


ID_REFRESH_PATH = newid()
ID_OPEN_DIR_PATH = newid()
ID_OPEN_CMD_PATH = newid()
ID_COPY_FULLPATH = newid()
ID_ADD_FOLDER = newid()
ID_CREATE_NEW_FILE = newid()


ID_WEB_BROWSER = newid()
ID_SHOW_WELCOME_PAGE = newid()
