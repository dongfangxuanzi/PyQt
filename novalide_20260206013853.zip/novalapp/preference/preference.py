# -*- coding: utf-8 -*-
from .. import _, get_app
from .manager import PreferenceManager, GetOptionName
from ..lib.pyqt import (
    QHBoxLayout,
    Qt,
    QVBoxLayout,
    QFrame,
    QTreeWidget,
    QTreeWidgetItem
)
from ..util import ui_utils, utils
from ..widgets.separator import Separator

# option item names
GENERAL_ITEM_NAME = "General"
TEXT_ITEM_NAME = "Text"
PROJECT_ITEM_NAME = "Project"
FONTS_CORLORS_ITEM_NAME = "Fonts and Colors"
INTERPRETER_CONFIGURATIONS_ITEM_NAME = "Configuration List"

EXTENSION_ITEM_NAME = "Extension"
PREFERENCE_DLG_WIDITH = 820
PREFERENCE_DLG_HEIGHT = 540


class PreferenceDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, selection=None):
        super().__init__(_("Options"), master)
        self.setFixedSize(PREFERENCE_DLG_WIDITH, PREFERENCE_DLG_HEIGHT)
        if not selection:
            selection = _("Environment") + "/" + GENERAL_ITEM_NAME
        self.current_panel = None
        self.current_item = None
        self._options_panels = {}

        contentbox = QHBoxLayout()
        # 设置path列存储模板路径,并隐藏改列
        self.tree = QTreeWidget()
        self.tree.setFixedWidth(200)
        contentbox.addWidget(self.tree)
        self.rootitem = self.tree.invisibleRootItem()
        # 不显示表头
        self.tree.setHeaderHidden(True)
        self.tree.itemSelectionChanged.connect(self._on_select)

        # configure the only tree column
        right_box = QVBoxLayout()
        self.page_frame = QFrame()
        page_box = QVBoxLayout()
        page_box.setContentsMargins(0, 0, 0, 0)
        self.page_frame.setLayout(page_box)
        right_box.addWidget(self.page_frame)

        bottom_separator = Separator()
        right_box.addWidget(bottom_separator)
        contentbox.addLayout(right_box)

        self.layout.addLayout(contentbox)
        option_catetory, sel_option_name = self.GetOptionNames(selection)
        category_list = PreferenceManager.manager().GetOptionList()
        category_dct = PreferenceManager.manager().GetOptionPageClasses()
        for category in category_list:
            item = QTreeWidgetItem()
            item.setText(0, category.replace("|", "/"))
            self.rootitem.addChild(item)
            option_panel_infos = category_dct[category]
            for noption_panel_info in option_panel_infos:
                name = noption_panel_info.name
                option_panel = noption_panel_info.option_class(
                    self.page_frame, **noption_panel_info.extra_args)
                option_name = noption_panel_info.path
                self._options_panels[option_name] = option_panel
                child = QTreeWidgetItem()
                child.setData(0, Qt.UserRole, noption_panel_info)
                child.setText(0, noption_panel_info.label)
                item.addChild(child)
                # select the default item,to avoid select no item
                if name == GENERAL_ITEM_NAME and category == _("Environment"):
                    self.tree.setCurrentItem(child)
                if name == sel_option_name and category == option_catetory:
                    self.tree.setCurrentItem(child)
        self.create_standard_buttons()

    def GetOptionNames(self, selection_name):
        names = selection_name.split("/")
        if 1 >= len(names):
            return "", selection_name
        return names[0], names[1]

    def GetOptionPanel(self, category, option_name):
        return self._options_panels[GetOptionName(category, option_name)]

    def _on_select(self):
        nodes = self.tree.selectedItems()
        sel = nodes[0]
        if sel.childCount() > 0:
            sel = sel.child(0)
        option_panel_info = sel.data(0, Qt.UserRole)
        panel = self._options_panels[option_panel_info.path]
        if self.current_item is not None and sel != self.current_item:
            if not self.current_panel.Validate():
                self.tree.SelectItem(self.current_item)
                return
        if self.current_panel is not None and panel != self.current_panel:
            self.current_panel.setVisible(False)
            self.page_frame.layout().removeWidget(self.current_panel)
        self.current_panel = panel
        self.page_frame.layout().addWidget(self.current_panel)
        self.current_panel.setVisible(True)

    def _ok(self):
        if not self.current_panel.Validate():
            return
        for name in self._options_panels:
            options_panel = self._options_panels[name]
            if not options_panel.OnOK(self):
                return
        sel = self.tree.currentItem()
        if sel.childCount() > 0:
            sel = sel.child(0)
        panel_info = sel.data(0, Qt.UserRole)
        path = panel_info.path
        utils.profile_set("PrefereceOptionName", path)
        super()._ok()

    def _cancel(self):
        for name, options_panel in self._options_panels.items():
            if hasattr(options_panel, "OnCancel") and not options_panel.OnCancel(self):
                return
        super()._cancel()

    def keyPressEvent(self, event):
        """
            屏蔽模态对话框的enter回车键,
            默认模态对话框按回车键会触发确定按钮,
            从而关闭对话框,需要屏蔽触发此类事件
        """
        key = event.key()
        if key in [
            Qt.Key_Enter,
            Qt.Key_Return
        ]:
            get_app().beep()
            event.ignore()
        else:
            super().keyPressEvent(event)
