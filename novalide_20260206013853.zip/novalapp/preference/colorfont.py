# -*- coding: utf-8 -*-
from .. import _, get_app
from ..syntax.syntax import SyntaxThemeManager
from .. import constants
from ..syntax import lang
from ..syntax import themes
from ..editor.codeview import CodeCtrl
from ..editor.texteditor import TextEditor
from ..editor.textview import TextView
from ..lib.pyqt import (
    QHBoxLayout,
    QMessageBox,
    QPushButton,
    QComboBox,
    QFontComboBox,
    QVBoxLayout,
    QLabel,
    QSizePolicy
)
from ..util import ui_utils, utils
from .. import globalkeys
from ..widgets.codesample import CodeSampleCtrl


class SyntaxthemeCodeCtrl(CodeSampleCtrl):

    def __init__(self, parent):
        super().__init__(parent)
        self.setReadOnly(True)

    def set_content(self, content):
        self.setReadOnly(False)
        self.setText(content)
        self.setReadOnly(True)

    def update_theme(self, theme_name):
        lexer = SyntaxThemeManager.manager().GetLexer(self._lang_lexer.GetLangId())
        syntax_options = lexer.style_items.get(theme_name, {})
        if lexer.GetLangId() == lang.ID_LANG_TXT:
            TextEditor.set_syntax(self, syntax_options)
        else:
            self.set_syntax(syntax_options)


class ColorfontOptionsPanel(ui_utils.BaseConfigurationPanel):
    """description of class"""

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        # 默认值
        lexer_label = QLabel(_("Lexers") + ":")
        self.layout.addWidget(lexer_label)
        defualt_lexer_name = ''
        names = []
        for lexer in SyntaxThemeManager.manager().Lexers:
            if lexer.IsVisible():
                names.append(lexer.GetShowName())
            if lexer.GetLangId() == get_app().GetDefaultLangId():
                defualt_lexer_name = lexer.GetShowName()
        hbox = QHBoxLayout()
        self.lexer_combo = QComboBox()
        self.lexer_combo.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.lexer_combo.addItems(names)
        hbox.addWidget(self.lexer_combo)
        self.lexer_combo.currentIndexChanged.connect(self.on_select_lexer)
        defaultbutton = QPushButton(_("Restore default"))
        defaultbutton.clicked.connect(self.restore_default)
        hbox.addWidget(defaultbutton)
        self.layout.addLayout(hbox)

        hbox = QHBoxLayout()
        vbox = QVBoxLayout()
        vbox.addWidget(QLabel(_("Font") + ":"))
        self.fontcombo = QFontComboBox()
        family = self.get_save_fontname()
        self.fontcombo.setCurrentText(family)
        vbox.addWidget(self.fontcombo)
        self.fontcombo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        hbox.addLayout(vbox)

        vbox = QVBoxLayout()
        vbox.addWidget(QLabel(_("Size") + ":"))
        hbox.addLayout(vbox)
        self.layout.addLayout(hbox)

        choices = []
        min_size = 6
        max_size = 25
        for i in range(min_size, max_size):
            choices.append(str(i))
        self.sizecombo = QComboBox()
        self.sizecombo.addItems(choices)
        vbox.addWidget(self.sizecombo)
        editor_font_size = CodeCtrl._guard_font_size(self.get_save_fontsize())
        self.sizecombo.setCurrentIndex(choices.index(str(editor_font_size)))
        hbox = QHBoxLayout()
        hbox.addWidget(QLabel(_("Code sample") + ":"))
        hbox.addStretch(1)
        hbox.addWidget(QLabel(_("Syntax themes") + ":"))

        theme_names = list(SyntaxThemeManager.manager().syntax_themes)
        current_theme_name = self.get_save_theme()
        self.themcombo = QComboBox()
        hbox.addWidget(self.themcombo)
        self.themcombo.addItems(theme_names)
        self.layout.addLayout(hbox)

        self.code_sample_ctrl = SyntaxthemeCodeCtrl(self)
        self.code_sample_ctrl.setSizePolicy(QSizePolicy.Expanding,
                                            QSizePolicy.Expanding)
        self.layout.addWidget(self.code_sample_ctrl)
        self.themcombo.setCurrentIndex(theme_names.index(current_theme_name))
        if defualt_lexer_name != '':
            self.lexer_combo.setCurrentText(defualt_lexer_name)
        self.sizecombo.currentIndexChanged.connect(self.on_select_size)
        self.fontcombo.currentIndexChanged.connect(self.on_select_font)
        self.themcombo.currentIndexChanged.connect(self.on_select_theme)

    def restore_default(self):
        self.fontcombo.setCurrentText(constants.DEFAULT_FONT_FAMILY)
        self.sizecombo.setCurrentText(str(constants.DEFAULT_FONT_SIZE))
        self.themcombo.setCurrentText(themes.DEFAULT_SYNTAX_THEME)

    def on_select_lexer(self, i):
        showname = self.lexer_combo.itemText(i)
        lexer = SyntaxThemeManager.manager().GetLangLexerFromShowname(showname)
        self.GetLexerStyles(lexer)

    @staticmethod
    def get_save_fontname():
        return utils.profile_get(globalkeys.EDITOR_FONT_FAMILY_KEY, constants.DEFAULT_FONT_FAMILY)

    def on_select_font(self, i):
        fontfamily = self.fontcombo.itemText(i)
        self.code_sample_ctrl.update_font(family=fontfamily)
        if self.is_fontname_changed():
            self.NotifyConfigurationChanged()

    def is_fontname_changed(self):
        current_fontname = self.fontcombo.currentText()
        return True if current_fontname != self.get_save_fontname() else False

    @staticmethod
    def get_save_fontsize():
        return utils.profile_get_int(globalkeys.EDITOR_FONT_SIZE_KEY, constants.DEFAULT_FONT_SIZE)

    @staticmethod
    def get_save_theme():
        return utils.profile_get(globalkeys.SYNTAX_THEME_KEY, themes.DEFAULT_SYNTAX_THEME)

    def is_fontsize_changed(self):
        current_size = int(self.sizecombo.currentText())
        return True if current_size != self.get_save_fontsize() else False

    def on_select_size(self, i):
        fontsize = self.sizecombo.itemText(i)
        self.code_sample_ctrl.update_font(fontsize=int(fontsize))
        if self.is_fontsize_changed():
            self.NotifyConfigurationChanged()

    def is_theme_changed(self):
        current_theme = self.themcombo.currentText()
        return True if current_theme != self.get_save_theme() else False

    def on_select_theme(self, i):
        theme = self.themcombo.itemText(i)
        self.code_sample_ctrl.update_theme(theme)
        if self.is_theme_changed():
            self.NotifyConfigurationChanged()

    def OnOK(self, options_dialog):
        is_font_changed = self.is_fontsize_changed() or self.is_fontname_changed()
        # 更新文本视图的字体和主题颜色
        if is_font_changed:
            utils.profile_set(globalkeys.EDITOR_FONT_SIZE_KEY,
                              int(self.sizecombo.currentText()))
            utils.profile_set(globalkeys.EDITOR_FONT_FAMILY_KEY,
                              self.fontcombo.currentText())
            utils.get_logger().debug("font size changed:%s, font name changed:%s",
                                     self.is_fontsize_changed(), self.is_fontname_changed())
            self.update_font_options()
        else:
            utils.get_logger().debug("font name and size is not changed")
        if self.is_theme_changed() or is_font_changed:
            utils.get_logger().debug("theme is changed")
            theme = self.themcombo.itemText(self.themcombo.currentIndex())
            utils.profile_set(globalkeys.SYNTAX_THEME_KEY, theme)
            self.update_syntax_options()
        else:
            utils.get_logger().debug("theme is not changed")
        return True

    def GetLexerStyles(self, lexer):
        self.code_sample_ctrl.set_lang_lexer(lexer.GetLangId())
        self.code_sample_ctrl.set_content(lexer.GetSampleCode())
        self.on_select_theme(self.themcombo.currentIndex())

    def OnCancel(self, options_dialog):
        '''
            取消时恢复存储的值
        '''
        if self._configuration_changed:
            ret = QMessageBox.question(
                self,
                _("Save configuration"),
                _("fonts and colors configuration has already been modified outside,Do you want to save?")
            )
            if ret == QMessageBox.Yes:
                self.OnOK(options_dialog)
                return True
        return True

    def update_syntax_options(self):
        notebook = get_app().MainFrame.GetNotebook()
        for index in range(notebook.count()):
            view_frame = notebook.widget(index)
            view = view_frame.GetView()
            if isinstance(view, TextView):
                # 更新语法主题
                view.set_lexer_syntax()

    def update_font_options(self):
        notebook = get_app().MainFrame.GetNotebook()
        for index in range(notebook.count()):
            view_frame = notebook.widget(index)
            view = view_frame.GetView()
            if isinstance(view, TextView):
                # 更新字体
                view.GetCtrl().update_font()

    def shouldAcceptFocus(self):
        return True
