# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        generalopt.py
Purpose:

Author:      wukan

Created:     2019-04-18
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import os
import glob
from .. import _, get_app
from ..lib.locale import Locale
from ..lib.pyqt import (
    QHBoxLayout,
    QComboBox,
    QMessageBox,
    Qt,
    QLabel,
    QSpinBox,
    QCheckBox
)
from .. import globalkeys, constants
from ..lib import ui_lang
from ..util import ui_utils, utils, apputils
from ..lib.limits import MAX_MRU_FILE_LIMIT, DEFAULT_MRU_FILE_NUM
from ..lib.defaultkeys import AppDefaultKey

MIN_MRU_FILE_LIMIT = 1


def get_avail_locales():
    """Gets a list of the available locales that have been installed
    for the editor. Returning a list of strings that represent the
    canonical names of each language.
    @return: list of all available local/languages available

    """
    avail_loc = []
    locale_path = os.path.join(apputils.mainModuleDir, 'novalapp', 'locale')
    utils.get_logger().debug('avail locale path is %s', locale_path)
    loc = glob.glob(os.path.join(locale_path, "*"))
    for path in loc:
        the_path = os.path.join(path, "LC_MESSAGES",
                                constants.APPLICATION_NAME.lower() + ".mo")
        if os.path.exists(the_path):
            avail_loc.append(os.path.basename(path))
    return avail_loc


def GetLocaleDict(loc_list):
    """Takes a list of cannonical locale names and by default returns a
    dictionary of available language values using the canonical name as
    the key. Supplying the Option OPT_DESCRIPT will return a dictionary
    of language id's with languages description as the key.
    @param loc_list: list of locals
    @keyword opt: option for configuring return data
    @return: dict of locales mapped to wx.LANGUAGE_*** values

    """
    lang_dict = {}
    for lang in [x for x in dir(ui_lang) if x.startswith("LANGUAGE_")]:
        langid = getattr(ui_lang, lang)
        langok = Locale.is_available(langid)
        if langok:
            loc_i = Locale(langid)
            if loc_i.GetLanguageCanonicalName() in loc_list:
                lang_dict[loc_i.GetLanguageName()] = langid
    return lang_dict


def GetLangName(langid):
    """Gets the ID of a language from the description string. If the
    language cannot be found the function simply returns the default language
    @param lang_n: Canonical name of a language
    @return: wx.LANGUAGE_*** id of language

    """
    langok = Locale.is_available(langid)
    if not langok:
        raise RuntimeError("unknown lang id %d", langid)

    loc_i = Locale(langid)
    return loc_i.GetLanguageName()


def GetLangList():
    lang_list = []
    available_locales = get_avail_locales()
    lang_ids = GetLocaleDict(available_locales).values()
    for i, lang_id in enumerate(lang_ids):
        loc_i = Locale(lang_id)
        lang_list.append((i, lang_id, loc_i.GetLanguageName()),)
    return lang_list


def get_lang_index(lang_id, lang_list):
    for lang in lang_list:
        if lang[1] == lang_id:
            return lang[0]
    return -1


class GeneralOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    A general options panel that is used in the OptionDialog to configure the
    generic properties of a pydocview application, such as "show tips at startup"
    and whether to use SDI or MDI for the application.
    """

    def __init__(self, master):
        """
        Initializes the panel by adding an "Options" folder tab to the parent notebook and
        populating the panel with the generic properties of a pydocview application.
        """
        super().__init__()
       # self._showTipsCheckBox = wx.CheckBox(self, -1, _("Show tips at start up"))
        # self._showTipsCheckBox.SetValue(config.ReadInt("ShowTipAtStartup", True))
        self.chkplugin_update_checkbox = QCheckBox(
            _("Check plugin update at start up"))
        self.layout.addWidget(self.chkplugin_update_checkbox)
        self.chkplugin_update_checkbox.setChecked(
            utils.profile_get_int(globalkeys.CHECK_PLUGIN_UPDATE_KEY, True))

        self.show_splash_checkbox = QCheckBox(
            _("Show splash screen at start up"))
        self.layout.addWidget(self.show_splash_checkbox)
        self.show_splash_checkbox.setChecked(
            utils.profile_get_int(globalkeys.SHOW_SPLASHSCREEN_KEY, True))

        self.lang_list = GetLangList()
        languages = [_(lang[2]) for lang in self.lang_list]
        # 优先从注册表中读取语言配置,其次从安装目录的配置文件中读取语言配置,是安装包语言选择时设置的
        self.lang_id = utils.profile_get_int(
            globalkeys.LANGUANGE_ID_KEY, utils.get_lang_config())
        hbox = QHBoxLayout()
        hbox.setAlignment(Qt.AlignLeft)
        hbox.addWidget(QLabel(_("Language") + ":"))
        self.language_combox = QComboBox()
        self.language_combox.addItems(languages)
        self.language_combox.setCurrentIndex(
            get_lang_index(self.lang_id, self.lang_list))
        hbox.addWidget(self.language_combox)
        self.layout.addLayout(hbox)

        self.enable_mru_checkbox = QCheckBox(_("Enable MRU Menu"))
        self.enable_mru_checkbox.setChecked(
            utils.profile_get_int(AppDefaultKey.ENABLE_MRU_KEY.value, True))
        self.layout.addWidget(self.enable_mru_checkbox)

        mru_hbox = QHBoxLayout()
        mru_hbox.setAlignment(Qt.AlignLeft)
        self.mru_ctrl = QSpinBox(value=utils.profile_get_int(
            AppDefaultKey.MRU_LENGTH_KEY.value,
            DEFAULT_MRU_FILE_NUM
        ),
            maximum=MAX_MRU_FILE_LIMIT,
            minimum=MIN_MRU_FILE_LIMIT,
            singleStep=1)
        mru_hbox.addWidget(QLabel(_("File History length in MRU Files") +
                           "(%d-%d): " % (MIN_MRU_FILE_LIMIT, MAX_MRU_FILE_LIMIT)))
        mru_hbox.addWidget(self.mru_ctrl)
        self.enable_mru_checkbox.toggled.connect(self.checkEnableMRU)
        self.layout.addLayout(mru_hbox)

        self.redirect_output_checkbox = QCheckBox(
            _("Redirect Application exception output to Message dialog"))
        self.redirect_output_checkbox.setChecked(utils.profile_get_int(
            globalkeys.REDIRECT_APP_EXCEPTION, True if get_app().GetDebug() else False))
        self.layout.addWidget(self.redirect_output_checkbox)
        self.layout.addStretch(1)
        self.checkEnableMRU()

    def checkEnableMRU(self):
        enablemru = self.enable_mru_checkbox.isChecked()
        if enablemru:
            self.mru_ctrl.setEnabled(True)
        else:
            self.mru_ctrl.setEnabled(False)

    def GetLangId(self):
        current = self.language_combox.currentIndex()
        if current == -1:
            return ui_lang.LANGUAGE_DEFAULT
        for i, lang in enumerate(self.lang_list):
            if i == current:
                return lang[1]
        raise RuntimeError('invalid ui language.....')

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        is_mru_enabled = self.enable_mru_checkbox.isChecked()
        mru_val = self.mru_ctrl.value()
        if is_mru_enabled and mru_val > MAX_MRU_FILE_LIMIT:
            QMessageBox.critical(
                self,
                get_app().GetAppName(),
                _("MRU Length must not be greater than %d") % MAX_MRU_FILE_LIMIT,
            )
            return False

        if is_mru_enabled and mru_val < 1:
            QMessageBox.critical(self, get_app().GetAppName(), _(
                "MRU Length must not be less than 1"))
            return False

       # utils.WriteInt("ShowTipAtStartup", self._showTipsCheckBox.GetValue())
        if self.GetLangId() != self.lang_id:
            QMessageBox.information(
                self,
                _("Language Options"),
                _("Language changes will not appear until the application is restarted.")
            )
        utils.profile_set(globalkeys.LANGUANGE_ID_KEY, self.GetLangId())
        utils.profile_set(AppDefaultKey.MRU_LENGTH_KEY.value, mru_val)
        utils.profile_set(AppDefaultKey.ENABLE_MRU_KEY.value, is_mru_enabled)
        utils.profile_set(globalkeys.REDIRECT_APP_EXCEPTION,
                          self.redirect_output_checkbox.isChecked())
        utils.profile_set(globalkeys.CHECK_PLUGIN_UPDATE_KEY,
                          self.chkplugin_update_checkbox.isChecked())
        utils.profile_set(globalkeys.SHOW_SPLASHSCREEN_KEY,
                          self.show_splash_checkbox.isChecked())
        return True

    def GetIcon(self):
        """ Return icon for options panel on the Mac. """
        return wx.GetApp().GetDefaultIcon()
