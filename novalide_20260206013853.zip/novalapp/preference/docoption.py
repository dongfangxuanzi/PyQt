from .. import _, get_app
from ..lib.pyqt import (
    QHBoxLayout,
    QComboBox,
    QGroupBox,
    QTabWidget,
    QRadioButton,
    Qt,
    QVBoxLayout,
    QLabel,
    QSpinBox,
    QCheckBox
)
from ..util import utils
from .. import globalkeys
from .. import constants
from ..util import ui_utils
from ..common.encodings import SUPPORTED_CODECS, ASCII_FILE_ENCODING
from ..lib.defaultkeys import AppDefaultKey


class DocumentOptionsPanel(ui_utils.BaseConfigurationPanel):
    """
    A general options panel that is used in the OptionDialog to configure the
    generic properties of a pydocview application, such as "show tips at startup"
    and whether to use SDI or MDI for the application.
    """

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)

        self._allow_drag_openfile_checkbox = QCheckBox(
            _("Allows drag and drop to open files"))
        self.layout.addWidget(self._allow_drag_openfile_checkbox)
        self._allow_drag_openfile_checkbox.setChecked(
            utils.profile_get_int(globalkeys.ALLOW_DRAP_OPENFILES_KEY, True))

        drap_hbox = QHBoxLayout()
        drap_hbox.setAlignment(Qt.AlignLeft)
        drap_hbox.addWidget(
            QLabel(_("Maximum number of files that can be opened at one time") + ":"))
        max_openfiles = utils.profile_get_int(
            globalkeys.MAX_OPEN_FILES_KEY, constants.DEFUALT_MAX_OPEN_FILES)
        self.max_openfiles_spin = QSpinBox(
            value=max_openfiles,
            maximum=10,
            minimum=2,
            singleStep=1
        )
        drap_hbox.addWidget(self.max_openfiles_spin)
        self.layout.addLayout(drap_hbox)

        sbox = QGroupBox(_("Tabs position"))
        group_box_layout = QVBoxLayout()
        self.tabs_north_radio = QRadioButton(_("Located north of tabs"))
        tab_position = utils.profile_get_int(
            globalkeys.TAB_POSITION_KEY, QTabWidget.North)
        if tab_position == QTabWidget.North:
            self.tabs_north_radio.setChecked(True)
        group_box_layout.addWidget(self.tabs_north_radio)

        self.tabs_south_radio = QRadioButton(_("Located south of tabs"))
        group_box_layout.addWidget(self.tabs_south_radio)
        if tab_position == QTabWidget.South:
            self.tabs_south_radio.setChecked(True)
        sbox.setLayout(group_box_layout)
        self.layout.addWidget(sbox)

        self.maximize_editor_chkbox = QCheckBox(
            self, text=_("Maximize editor when double click tabs"))
        self.maximize_editor_chkbox.setChecked(
            utils.profile_get_int(globalkeys.MAXIMIZE_EDITOR_KEY, True))
        self.layout.addWidget(self.maximize_editor_chkbox)

        self._show_closebtn_checkbox = QCheckBox(
            _("Show close button on tabs"))
        self.layout.addWidget(self._show_closebtn_checkbox)
        self._show_closebtn_checkbox.setChecked(
            utils.profile_get_int(globalkeys.TAB_SHOW_CLOSEBUTTON_KEY, False))

        self.rember_checkbox = QCheckBox(
            self, text=_("Remember File Position"))
        self.rember_checkbox.setChecked(
            utils.profile_get_int(globalkeys.REMBER_FILE_KEY, True))
        self.layout.addWidget(self.rember_checkbox)

        self.load_last_open_documents_checkbox = QCheckBox(
            self, text=_("Load last open documents when start up"))
        self.load_last_open_documents_checkbox.setChecked(
            utils.profile_get_int(globalkeys.LOAD_LAST_OPENDOCS, False))
        self.layout.addWidget(self.load_last_open_documents_checkbox)

        encoding_hbox = QHBoxLayout()
        encoding_hbox.setAlignment(Qt.AlignLeft)
        encoding_hbox.addWidget(QLabel(_("Default file encoding") + ":"))
        default_encoding = utils.profile_get(
            globalkeys.DEFAULT_FILE_ENCODING_KEY, ASCII_FILE_ENCODING)
        self.encodings_combo = QComboBox()
        self.encodings_combo.setEditable(False)
        self.encodings_combo.addItems(SUPPORTED_CODECS)
        self.encodings_combo.setCurrentIndex(
            SUPPORTED_CODECS.index(default_encoding))
        encoding_hbox.addWidget(self.encodings_combo)
        self.layout.addLayout(encoding_hbox)

        self.chk_modify_checkbox = QCheckBox(
            _("Check if on disk file has been modified by others"))
        self.chk_modify_checkbox.setChecked(
            utils.profile_get_int(globalkeys.CHECK_FILE_MODIFY_KEY, True))
        self.layout.addWidget(self.chk_modify_checkbox)

        self.__chk_eol_checkbox = QCheckBox(
            _("Warn when mixed eol characters are detected"))
        self.__chk_eol_checkbox.setChecked(
            utils.profile_get_int(globalkeys.CHECK_EOL_KEY, False))
        self.layout.addWidget(self.__chk_eol_checkbox)

        row_box = QHBoxLayout()
        row_box.setAlignment(Qt.AlignLeft)
        row_box.addWidget(QLabel(_("Default document type") + ":"))
        document_type_names, index, self.templates = self.GetDocumentTypes()
        self.document_types_combox = QComboBox()
        self.document_types_combox.setEditable(False)
        self.document_types_combox.addItems(document_type_names)
        row_box.addWidget(self.document_types_combox)
        self.layout.addLayout(row_box)
        self.document_types_combox.setCurrentIndex(index)
        self.layout.addStretch(1)

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        utils.profile_set(
            globalkeys.DEFAULT_FILE_ENCODING_KEY,
            SUPPORTED_CODECS[self.encodings_combo.currentIndex()]
        )
        utils.profile_set(globalkeys.REMBER_FILE_KEY,
                          self.rember_checkbox.isChecked())
        utils.profile_set(globalkeys.CHECK_FILE_MODIFY_KEY,
                          self.chk_modify_checkbox.isChecked())
        template = self.templates[self.document_types_combox.currentIndex()]
        utils.profile_set(AppDefaultKey.DEFAULT_DOCUMENT_TYPE_KEY.value,
                          template.GetDocumentName())
        utils.profile_set(globalkeys.CHECK_EOL_KEY,
                          self.__chk_eol_checkbox.isChecked())
        utils.profile_set(globalkeys.MAX_OPEN_FILES_KEY,
                          int(self.max_openfiles_spin.value()))
        utils.profile_set(globalkeys.ALLOW_DRAP_OPENFILES_KEY,
                          self._allow_drag_openfile_checkbox.isChecked())
        utils.profile_set(globalkeys.TAB_SHOW_CLOSEBUTTON_KEY,
                          self._show_closebtn_checkbox.isChecked())
        utils.profile_set(globalkeys.MAXIMIZE_EDITOR_KEY,
                          self.maximize_editor_chkbox.isChecked())
        utils.profile_set(globalkeys.LOAD_LAST_OPENDOCS,
                          self.load_last_open_documents_checkbox.isChecked())
        if self.tabs_north_radio.isChecked():
            utils.profile_set(globalkeys.TAB_POSITION_KEY, QTabWidget.North)
        elif self.tabs_south_radio.isChecked():
            utils.profile_set(globalkeys.TAB_POSITION_KEY, QTabWidget.South)
        # 更新标签页选项
        get_app().MainFrame.GetNotebook().update_tabs_option()
        return True

    def GetDocumentTypes(self):
        type_names = []
        default_document_typename = utils.profile_get(
            AppDefaultKey.DEFAULT_DOCUMENT_TYPE_KEY.value,
            get_app().GetDefaultTextDocumentType()
        )
        current_document_typename = ''
        templates = []
        for temp in get_app().GetDocumentManager().GetTemplates():
            # filter image document and any file document
            if temp.IsVisible() and temp.IsNewable():
                templates.append(temp)
        for temp in templates:
            descr = temp.GetDescription()
            if default_document_typename == temp.GetDocumentName():
                current_document_typename = _(descr)
            type_names.append(_(descr))
        return type_names, type_names.index(current_document_typename), templates
