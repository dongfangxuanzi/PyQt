from typing import NamedTuple, Type, Dict
from ..common.singleton import SingletonMeta


class OptionTemplate(NamedTuple):
    # 目录名称
    catlog: str
    # 节点名称,英文名称
    name: str
    # 节点显示名称,中英文
    label: str
    # 节点路径
    path: str
    # 页面类,可以是字符串也可以是类对象
    option_class: Type
    # 页面初始化参数
    extra_args: Dict


def GetOptionName(caterory, name):
    return caterory + "/" + name


class PreferenceManager(object, metaclass=SingletonMeta):

    def __init__(self):
        self._options_panel_classes = {}
        self.category_list = []

    @staticmethod
    def manager():
        return PreferenceManager()

    def GetOptionPageClasses(self):
        return self._options_panel_classes

    def AddOptionsPanelClass(self, category, name, label, options_panel_class, **kwargs):
        path = GetOptionName(category, name)
        if category not in self._options_panel_classes:
            self._options_panel_classes[category] = [OptionTemplate(
                category, name, label, path, options_panel_class, kwargs), ]
            self.category_list.append(category)
        else:
            self._options_panel_classes[category].append(OptionTemplate(
                category, name, label, path, options_panel_class, kwargs),)

    def remove_option_panel_class(self, category, name):
        if category not in self._options_panel_classes:
            raise RuntimeError(f"Cannot find category:`{category}` in optional panels")
        for option_panel in self._options_panel_classes[category]:
            if option_panel.name == name:
                self._options_panel_classes[category].remove(option_panel)
                break
        if 0 == len(self._options_panel_classes[category]):
            del self._options_panel_classes[category]
            self.category_list.remove(category)

    def insert_option_panel_class(
        self,
        insert_category,
        category,
        name,
        label,
        options_panel_class,
        **kwargs
    ):
        path = GetOptionName(category, name)
        assert category not in self._options_panel_classes
        assert insert_category in self._options_panel_classes
        insert_index = self.category_list.index(insert_category)
        self._options_panel_classes[category] = [OptionTemplate(
            category, name, label, path, options_panel_class, kwargs), ]
        self.category_list.insert(insert_index, category)

    def GetOptionList(self):
        return self.category_list
