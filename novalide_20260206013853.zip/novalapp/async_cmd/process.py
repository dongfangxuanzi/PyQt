import subprocess
from .output import AsyncCommandOutput


class AsyncProcess:
    def __init__(self, parent):
        self._parent = parent

    def create_process(self, command, work_path, callback_exit=None):
        p = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=work_path
        )
        stdout_thread = AsyncCommandOutput(
            self._parent, p.stdout, p, callback_exit=callback_exit)
        stdout_thread.start()
        stderr_thread = AsyncCommandOutput(self._parent, p.stderr, p, errout=True)
        stderr_thread.start()
        return p
