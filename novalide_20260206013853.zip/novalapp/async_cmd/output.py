import logging
from ..common.compat import ensure_string
from ..lib.pyqt import QThread
from ..util import utils

log = logging.getLogger(__name__)


class AsyncCommandOutput(QThread):
    '''
    进程输出使用多线程异步输出
    '''

    def __init__(self, parent, outfile, process, callback_exit=None, errout=False):
        super().__init__(parent)
        self._outfile = outfile
        self._process = process
        self._is_running = True
        self._callback_exit = callback_exit
        self.parent_ui = parent
        self._errout = errout

    def run(self):
        while self._is_running:
            out = self._outfile.readline()
            if out == b'':
                if self._process.poll() is not None:
                    self._is_running = False
                    log.debug('command process is exit.....')
                    if self._callback_exit is not None:
                        self._callback_exit(self._process.returncode)
                    break
            else:
                parent = self.parent()
                # 在线程中启动另外一个线程时,获取self.parent()为None,所以
                # 使用另外一种方式获取parent对象
                if parent is None:
                    parent = self.parent_ui
                try:
                    outmsg = ensure_string(out)
                except Exception as ex:
                    outmsg = ensure_string(out, encoding=utils.get_default_locale_encoding())
                if self._errout:
                    log.error(outmsg.strip())
                else:
                    log.debug(outmsg.strip())
                parent.SIG_APPEND_TEXT.emit(outmsg)
