'''
Name:        pathutils.py
Purpose:     安全处理文件目录操作的模块

Author:      wukan

Created:     2023-12-27
Copyright:   (c) wukan 2023
Licence:     <your licence>
'''
import os
import shutil
import logging
from . import exceptions
from .fileutils import open_file_directory
from .. import _

filelog = logging.getLogger(__name__)


@exceptions.catch_exception
def safe_open_file_directory(path):
    open_file_directory(path)


@exceptions.catch_exception
def delete_dir(dirpath):
    try:
        # 删除空文件夹
        os.removedirs(dirpath)
        filelog.info('Delete dir %s success', dirpath)
    except Exception as e:
        try:
            # 如果不为空文件夹,则递归删除文件夹及其内容
            shutil.rmtree(dirpath)
            filelog.info('Delete dir %s success', dirpath)
        except Exception as e:
            raise RuntimeError(
                _("Could not delete empty directory '%s'.\n%s") % (dirpath, e))
