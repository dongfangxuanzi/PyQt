# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        strutils.py
Purpose:

Author:      wukan

Created:     2019-01-18
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import shlex
import re
import os
from typing import Optional
from . import apputils
from .. import get_app


def case_insensitive_compare(s1, s2):
    """ Method used by sort() to sort values in case insensitive order """
    s1L = s1.lower()
    s2L = s2.lower()
    if s1L == s2L:
        return 0
    if s1L < s2L:
        return -1
    return 1


def multiSplit(string_list, token_list=[" "]):
    """Splits strings in stringList by tokens, returns list of string."""
    if not string_list:
        return []
    if isinstance(token_list, basestring):
        token_list = [token_list]
    if isinstance(string_list, basestring):
        string_list = [string_list]
    rtn_list = string_list
    for token in token_list:
        rtn_list = rtn_list[:]
        for string in rtn_list:
            if string.find(token) > -1:
                rtn_list.remove(string)
                names = string.split(token)
                for name in names:
                    name = name.strip()
                    if name:
                        rtn_list.append(name)
    return rtn_list


QUOTES = ("\"", "'")


def _findArgStart(argstr):
    i = -1
    for c in argstr:
        i += 1
        if c == ' ':
            continue
        elif c == ',':
            continue
        return i
    return None


def _findArgEnd(argstr):
    quotedarg = True
    argEndChar = [argstr[0]]
    if not argEndChar[0] in QUOTES:
        argEndChar = [",", " "]
        quotedarg = False
    i = -1
    firstchar = True
    for c in argstr:
        i += 1
        if firstchar:
            firstchar = False
            if quotedarg:
                continue
        if c in argEndChar:
            if quotedarg:
                return min(i + 1, len(argstr))
            return i
    return i


def parse_cmd_args(argstr, stripQuotes=False):
    """
    Given a str representation of method arguments, returns list arguments (as
    strings).

    Input: "('[a,b]', 'c', 1)" -> Output: ["'[a,b]'", "'c'", "1"].

    If stripQuotes, removes quotes from quoted arg.
    """
    if argstr.startswith('('):
        argstr = argstr[1:]
        if argstr.endswith(')'):
            argstr = argstr[:-1]
        else:
            raise AssertionError("Expected argStr to end with ')'")

    rtn = []
    argstr = argstr.strip()
    while True:
        startIndex = _findArgStart(argstr)
        if startIndex is None:
            break
        argstr = argstr[startIndex:]
        endIndex = _findArgEnd(argstr)
        if endIndex == len(argstr) - 1:
            rtn.append(argstr.strip())
            break
        t = argstr[:endIndex].strip()
        if (stripQuotes and t[0] in QUOTES and t[-1] in QUOTES):
            t = t[1:-1]
        rtn.append(t)
        argstr = argstr[endIndex:]
    return rtn


def get_file_extension(filename, tolower=True, keepdot=False):
    basename = os.path.basename(filename)
    names = basename.split(".")
    if 1 == len(names):
        return ""
    if tolower:
        ext = names[-1].lower()
    else:
        ext = names[-1]
    if keepdot:
        ext = "." + ext
    return ext


def MakeNameEndInExtension(name, extension):
    if not name:
        return name
    ext = get_file_extension(name)
    if ext == extension:
        return name
    return name + extension


def get_filename_without_ext(file_path_name):
    filename = os.path.basename(file_path_name)
    return os.path.splitext(filename)[0]


def emphasis_path(path):
    '''
    如果路径中有空格,将路径加上双引号
    以免命令行中路径包含空格会提示路径不存在
    '''
    if path.find(' ') == -1 or path[0] == '"':
        return path
    path = "\"%s\"" % path
    return path


def get_template_filter(template):
    return get_app().GetDocumentManager().get_filter(template)


def HexToRGB(hex_str):
    """Returns a list of red/green/blue values from a
    hex string.
    @param hex_str: hex string to convert to rgb

    """
    hexval = hex_str
    if hexval[0] == '#':
        hexval = hexval[1:]
    ldiff = 6 - len(hexval)
    hexval += ldiff * '0'
    # Convert hex values to integer
    red = int(hexval[0:2], 16)
    green = int(hexval[2:4], 16)
    blue = int(hexval[4:], 16)
    return [red, green, blue]


def RGBToHex(clr):
    return "#%02x%02x%02x" % (clr.Red(), clr.Green(), clr.Blue())


def isInArgs(argname, argv):
    result = False
    if ("-" + argname) in argv:
        result = True
    if apputils.is_windows() and ("/" + argname) in argv:
        result = True
    return result


def path_startswith(child_name, dir_name):
    '''
    判断路径是否包含另外一个路径
    '''
    normchild = os.path.normpath(os.path.normcase(child_name))
    normdir = os.path.normpath(os.path.normcase(dir_name))
    return normdir == normchild or normchild.startswith(normdir.rstrip(os.path.sep) + os.path.sep)


def normpath_with_actual_case(name):
    """In Windows return the path with the case it is stored in the filesystem"""
    assert os.path.isabs(name) or os.path.ismount(
        name), "Not abs nor mount: " + name
    assert os.path.exists(name), "Not exists: " + name
    if os.name == "nt":
        name = os.path.realpath(name)
        from ctypes import create_unicode_buffer, windll
        buf = create_unicode_buffer(512)
        windll.kernel32.GetShortPathNameW(name, buf, 512)  # @UndefinedVariable
        windll.kernel32.GetLongPathNameW(
            buf.value, buf, 512)  # @UndefinedVariable
        if len(buf.value):
            result = buf.value
        else:
            result = name
        assert isinstance(result, str)
        if result[1] == ":":
            # ensure drive letter is capital
            return result[0].upper() + result[1:]
        return result
    return os.path.normpath(name)


def is_sample_file(file_1, file_2):
    return os.path.samefile(file_1, file_2)


def shorten_repr(original_repr, max_len=1000):
    if len(original_repr) > max_len:
        return original_repr[: max_len - 1] + "…"
    return original_repr


def parse_cmd_line(s, posix=False):
    return shlex.split(s, posix=posix)


def find_chinese_character(path):
    res = re.search('[\u4e00-\u9fa5]+', path)
    if res:
        return True
    return False


def contains_emoji(chars):
    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"  # emoticons
        "\U0001F300-\U0001F5FF"  # miscellaneous symbols and pictographs
        "\U0001F680-\U0001F6FF"  # transport and map symbols
        "\U0001F1E0-\U0001F1FF"  # flags(ios)
        "\U00002600-\U000026FF"  # miscellaneous symbols
        "\U00002700-\U000027BF"  # dingbats
        "]+",
        flags=re.UNICODE
    )
    result = emoji_pattern.search(chars)
    return bool(result)


def is_none_empty(value: Optional[str]):
    '''
    判断字符串为None或者空
    '''
    if value is None:
        return True
    if value == "":
        return True
    return False


def bool_to_str(b_val):
    return "true" if b_val else "false"


def str_to_bool(str_val):
    return True if str_val == "true" else False
