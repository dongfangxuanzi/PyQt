import json
import io


class DataObject:

    def __init__(self, data_type="str"):
        self._data_type = data_type
        self._data = ''

    def SetData(self, data):
        self._data = data

    def GetData(self):
        return self._data

    def GetDataSize(self):
        return len(self._data)

    @property
    def RawData(self):
        return self._data

    @RawData.setter
    def RawData(self, data):
        self._data = data


class JsonDataobject(DataObject):

    def __init__(self):
        DataObject.__init__(self, data_type="json")

    def SetData(self, data):
        DataObject.SetData(self, json.dumps(data))

    def GetData(self):
        data = DataObject.GetData(self)
        d = json.loads(data)
        return json.loads(data)


class Clipboard:
    def __init__(self):
        self._is_opened = False

    def Open(self):
        if self._is_opened:
            return True
        self.buf = io.StringIO()
        self._is_opened = True
        return self._is_opened

    def Close(self):
        self.buf.close()
        self._is_opened = False

    def IsOpened(self):
        return self._is_opened

    def AddData(self, data_ojbect):
        self.buf.write(data_ojbect.RawData)

    def SetData(self, data_ojbect):
        self.Clear()
        self.AddData(data_ojbect)

    def GetData(self, data_ojbect):
        if not self.buf.getvalue():
            return False
        data_ojbect.RawData = self.buf.getvalue()
        return True

    def Clear(self):
        self.buf.truncate(0)
        self.buf.seek(0)

    def Flush(self):
        self.buf.flush()

    def Get(*args, **kwargs):
        """
        Get() -> Clipboard

        Returns global instance (wxTheClipboard) of the object.
        """
        return _misc_.Clipboard_Get(*args, **kwargs)
