# -*- coding: utf-8 -*-
from threading import Event
import queue
import os
from ... import _, get_app
from ...lib.pyqt import (
    QHBoxLayout,
    QTimer,
    QTreeWidgetItem,
    QCoreApplication,
    QDialog,
    QMessageBox,
    QPushButton,
    pyqtSignal,
    QTreeWidget,
    QProgressBar,
    QListWidgetItem,
    QListWidget,
    Qt,
    QLabel,
    QSizePolicy,
    QLineEdit,
    QFileDialog
)
from ...util import utils, fileutils, strutils, apputils
from . import page as wizardpage
from .filters import FileFilterDialog
from ... import constants, globalkeys
from ...syntax.syntax import SyntaxThemeManager
from .namelocation import ProjectNameLocationPage


class ImportfilesPage(wizardpage.BitmapTitledContainerWizardPage):

    # 添加项目文件覆盖已有文件时默认处理方式
    DEFAULT_PROMPT_MESSAGE_ID = QMessageBox.Yes

    update_progress_signal = pyqtSignal(int, str)
    sig_show_messagebox = pyqtSignal(str)

    def __init__(self, master, rejects=[], folderPath=None):
        '''
        '''
        self.folder_path = folderPath
        self.dest_path = ''
        default_filters = SyntaxThemeManager().GetLexer(
            get_app().GetDefaultLangId()).Exts
        # 文件类型过滤列表
        self.filters = utils.profile_get(
            globalkeys.PROJECT_FILE_FILTERS,
            default_filters
        )
        self.project_browser = get_app().MainFrame.projectview
        self.rejects = rejects
        super().__init__(
            master,
            _("Import codes from File System"),
            _("Local File System"),
            self.project_browser.get_titled_bitmap()
        )
        self.can_finish = True
        self.update_progress_signal.connect(self.update_progress)
        self.sig_show_messagebox.connect(self.show_messagebox)

        self.__update_progress_timer = QTimer(self)
        self.__update_progress_timer.setSingleShot(True)
        self.__update_progress_timer.timeout.connect(self.update_progress_que)

        # 等待用户确认事件
        self.wait_event = Event()

    def CreateContent(self, content_frame, **kwargs):
        content_frame.setContentsMargins(0, 0, 0, 0)
        path_hbox = QHBoxLayout()
        dir_label = QLabel(_("Source location:"))
        path_hbox.addWidget(dir_label)
        self.dir_entry = QLineEdit()
        path_hbox.addWidget(self.dir_entry)
        self.dir_entry.textChanged.connect(self.ChangeDir)
        self.browser_button = QPushButton(_("Browse..."))
        self.browser_button.clicked.connect(self.BrowsePath)
        path_hbox.addWidget(self.browser_button)
        content_frame.addLayout(path_hbox)

        list_hbox = QHBoxLayout()
        self.check_box_view = QTreeWidget()
        self.check_box_view.setHeaderHidden(True)
        list_hbox.addWidget(self.check_box_view)
        self.check_box_view.itemSelectionChanged.connect(self._on_select)
        self.current_item = None

        self.check_listbox = QListWidget()
        list_hbox.addWidget(self.check_listbox)
        content_frame.addLayout(list_hbox)

        button_hbox = QHBoxLayout()
        button_hbox.setAlignment(Qt.AlignLeft)

        self.file_filter_btn = QPushButton(_("File filters"))
        self.file_filter_btn.clicked.connect(self.__set_filters)
        button_hbox.addWidget(self.file_filter_btn)
        self.file_filter_btn.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed)

        self.select_all_btn = QPushButton(_("Select all"))
        self.select_all_btn.clicked.connect(self.SelectAll)
        self.select_all_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        button_hbox.addWidget(self.select_all_btn)

        self.unselect_all_btn = QPushButton(_("UnSelect all"))
        self.unselect_all_btn.clicked.connect(self.UnselectAll)
        self.unselect_all_btn.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed)
        button_hbox.addWidget(self.unselect_all_btn)
        content_frame.addLayout(button_hbox)
        self.create_progress(content_frame)
        self.root_item = None
        self.is_cancel = False

    def GetDestpath(self):
        # 目的路径必须用相对路径
        current_project = self.project_browser.GetView().GetDocument()
        if current_project is None:
            raise RuntimeError(_('There is no available project yet.'))

        project_path = os.path.dirname(current_project.GetFilename())
        self.dest_path = os.path.basename(project_path)
        if self.folder_path:
            self.dest_path = os.path.join(self.dest_path, self.folder_path)

        # 格式化系统标准路径
        if apputils.is_windows():
            self.dest_path = self.dest_path.replace("/", os.sep)

    def create_progress(self, content_box):
        self.info_label = QLabel()
        content_box.addWidget(self.info_label)
        self.pb = QProgressBar()
        content_box.addWidget(self.pb)
        self.pb.setVisible(False)

    def ShowProgress(self):
        self.pb.setVisible(True)

    def is_progress_visible(self):
        return self.pb.isVisible()

    def update_progress(self, curval, msg):
        if msg == constants.PROGRESS_END:
            self.pb.setValue(self.pb.maximum())
            self.top_widget().accept()
        else:
            self.pb.setValue(curval)
            self.info_label.setText(_("Importing file ") + msg)
            # 告诉qt在处理复杂逻辑工作的时候同时处理其他工作,并返回用户调用之处
            QCoreApplication.processEvents()

    def __set_filters(self):
        filter_dlg = FileFilterDialog(self, self.filters, self.rejects)
        if filter_dlg.exec_() == FileFilterDialog.Accepted:
            dlg_filters = filter_dlg.filters
            dlg_filters.extend(self.filters)
            # 过滤掉重复数据
            self.filters = list(set(dlg_filters))
            if self.current_item is not None:
                self.__list_dir_files(
                    self.current_item, self.current_item.checkState(0))

    def BrowsePath(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog | QFileDialog.ShowDirsOnly
        dirname = QFileDialog.getExistingDirectory(
            self, _("Select source directory"), self.dir_entry.text(),
            options)
        if dirname:
            self.dir_entry.setText(fileutils.opj(dirname))

    def ChangeDir(self, *args):
        path = self.dir_entry.text().strip()
        if path == "":
            self.clear_tree()
            return
        path = fileutils.opj(path)
        self.ListDirItemFiles(path.rstrip(os.sep))

    def clear_tree(self):
        self.check_box_view.clear()
        self.check_listbox.clear()
        self.root_item = None

    def ListDirItemFiles(self, path):
        self.clear_tree()
        rootitem = QTreeWidgetItem()
        rootitem.setText(0, os.path.basename(path))
        rootitem.setFlags(Qt.ItemFlag.ItemIsAutoTristate |
                          Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
        rootitem.setCheckState(0, Qt.Checked)
        rootitem.setData(0, Qt.UserRole, path)
        self.check_box_view.invisibleRootItem().addChild(rootitem)
        self.root_item = rootitem
        self.current_item = self.root_item
        self.ListDirTreeItem(self.root_item, path)
        self.__list_dir_files(self.root_item, Qt.Checked)
        if self.root_item is not None:
            self.check_box_view.setCurrentItem(self.root_item)

    def _on_select(self,):
        item = self.check_box_view.currentItem()
        self.SelectItem(item)

    def SelectItem(self, item):
        # 同一个节点无需遍历目录
        if self.current_item == item:
            self.CheckListbox(item.checkState(0))
            return
        self.current_item = item
        self.__list_dir_files(item, item.checkState(0))

    def ListDirTreeItem(self, parent_item, path):
        if not os.path.exists(path):
            return
        files = os.listdir(path)
        for f in files:
            file_path = os.path.join(path, f)
            if os.path.isdir(file_path) and not fileutils.is_file_path_hidden(file_path):
                diritem = QTreeWidgetItem()
                diritem.setText(0, f)
                diritem.setFlags(Qt.ItemFlag.ItemIsAutoTristate |
                                 Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
                diritem.setCheckState(0, Qt.Checked)
                diritem.setData(0, Qt.UserRole, file_path)
                parent_item.addChild(diritem)
                self.ListDirTreeItem(diritem, file_path)
        parent_item.setExpanded(True)

    def __list_dir_files(self, item, checkstate):
        '''
        列出目录下的所有后缀过滤后的子文件
        '''
        path = item.data(0, Qt.UserRole)
        if not os.path.exists(path):
            self.clear_tree()
            return
        self.check_listbox.clear()
        files = os.listdir(path)
        for f in files:
            file_path = os.path.join(path, f)
            file_ext = strutils.get_file_extension(file_path)
            # 不符合文件后缀的不允许添加
            is_file_allowed = file_ext in self.filters and file_ext not in self.rejects
            if os.path.isfile(file_path) and not fileutils.is_file_path_hidden(file_path) and is_file_allowed:
                listitem = QListWidgetItem(f)
                self.check_listbox.addItem(listitem)
                listitem.setCheckState(checkstate)

    def Finish(self):
        global DEFAULT_PROMPT_MESSAGE_ID
        file_list = self.GetImportFileList()
        total_file_count = len(file_list)
        if 0 == total_file_count:
            return False
        utils.get_logger().debug("there is total %d import files", total_file_count)
        self.GetDestpath()
        if not self.is_progress_visible():
            self.ShowProgress()
        self.DisableUI()
        top_dlg = self.top_widget()
        top_dlg.sig_import_files.emit()
        self.pb.setMaximum(total_file_count)
        root_path = self.root_item.data(0, Qt.UserRole)
        self.root_item.setExpanded(True)
        self.notify_queue = queue.Queue()
        self.start_timer()
        self.project_browser.copy_progress_files_to_project(
            self, file_list, root_path, self.dest_path, self.notify_queue)
        return False

    def start_timer(self):
        if not self.__update_progress_timer.isActive():
            self.__update_progress_timer.start(1)

    def update_progress_que(self):
        while not self.notify_queue.empty():
            try:
                curval, msg = self.notify_queue.get()
                self.update_progress(curval, msg)
            except queue.Empty:
                pass
        self.start_timer()

    def top_widget(self):
        top = self
        while top:
            if isinstance(top, QDialog):
                break
            top = top.parent()
        return top

    def GetImportFileList(self):
        file_list = []
        root_path = self.root_item.data(0, Qt.UserRole)
        # 如果根节点未选中则直接从硬盘中获取根路径的文件列表,
        # 这里选中是指鼠标是否选中,不是指复选框勾选中
        if not self.IsItemSelected(self.root_item):
            fileutils.get_dir_files(root_path, file_list, self.filters)
        else:
            # 如果根节点选中则从界面获取有哪些文件被选中了
            self.GetCheckedItemFiles(self.root_item, file_list)
        # 扫描根节点下的所有文件列表
        self.RotateItems(self.root_item, file_list)
        if 0 == len(file_list):
            QMessageBox.information(
                self, get_app().GetAppName(), _("You don't select any file"))
            return file_list
        project_file_path = self.project_browser.GetView().GetDocument().GetFilename()
        # 如果项目文件在文件列表中剔除
        if project_file_path in file_list:
            file_list.remove(project_file_path)
        return file_list

    def DisableUI(self):
        self.dir_entry.setEnabled(False)
        self.browser_button.setEnabled(False)
        self.select_all_btn.setEnabled(False)
        self.unselect_all_btn.setEnabled(False)
        self.file_filter_btn.setEnabled(False)
        self.check_box_view.setEnabled(False)
        self.check_listbox.setEnabled(False)

    def IsItemSelected(self, item):
        '''
        鼠标是否选中当前节点
        '''
        return self.check_box_view.currentItem() == item

    def GetCheckedItemFiles(self, item, file_list):
        dir_path = item.data(0, Qt.UserRole)
        for i in range(self.check_listbox.count()):
            listitem = self.check_listbox.item(i)
            if listitem.checkState() == Qt.Checked:
                f = os.path.join(dir_path, listitem.text())
                if self.filters != []:
                    if strutils.get_file_extension(f) in self.filters:
                        file_list.append(f)
                else:
                    file_list.append(f)

    def RotateItems(self, parent_item, file_list):
        for i in range(parent_item.childCount()):
            item = parent_item.child(i)
            if item.checkState(0) != Qt.Unchecked:
                dir_path = item.data(0, Qt.UserRole)
                # 如果节点未选中则直接从硬盘中获取路径的文件列表
                if not self.IsItemSelected(item):
                    fileutils.get_dir_files(
                        dir_path, file_list, filters=self.filters, rejects=self.rejects)
                else:
                    # 如果节点选中则从界面获取有哪些文件被选中了
                    self.GetCheckedItemFiles(item, file_list)
            # 递归子节点
            self.RotateItems(item, file_list)

    def SelectAll(self):
        if self.root_item is None:
            return
        self.root_item.setCheckState(0, Qt.Checked)
        self.CheckListbox(Qt.Checked)

    def CheckListbox(self, checkstate):
        for i in range(self.check_listbox.count()):
            listitem = self.check_listbox.item(i)
            listitem.setCheckState(checkstate)

    def UnselectAll(self):
        if self.root_item is None:
            return
        self.root_item.setCheckState(0, Qt.Unchecked)
        self.CheckListbox(Qt.Unchecked)

    def Validate(self):
        if self.root_item is None or self.root_item.checkState(0) == Qt.Unchecked:
            QMessageBox.information(
                self, get_app().GetAppName(), _("You don't select any file"))
            return False
        return True

    def Cancel(self):
        if self.is_progress_visible():
            self.info_label.setText(_("User cancel importing file....."))
        self.is_cancel = True

    def show_messagebox(self, filepath):
        ret = QMessageBox.question(
            self,
            _("Project File Exists"),
            ("The file %s is already exist in project ,Do You Want to overwrite it?") % filepath,
            QMessageBox.Yes | QMessageBox.No | QMessageBox.YesToAll | QMessageBox.NoToAll
        )
        self.DEFAULT_PROMPT_MESSAGE_ID = ret
        # 设置事件,让程序取消等待
        self.wait_event.set()

    @classmethod
    def reset_prompt_message_id(cls):
        cls.DEFAULT_PROMPT_MESSAGE_ID = QMessageBox.Yes

    def Init(self):
        '''
        如果项目名称路径页面用户选择不创建项目目录,导入页面默认加载并导入项目所在路径下的代码
        '''
        prev_page = self.GetPrev()
        if prev_page is None:
            return

        name_location_page = None
        while prev_page is not None:
            if isinstance(prev_page, ProjectNameLocationPage):
                name_location_page = prev_page
                break
            prev_page = prev_page.GetPrev()

        if name_location_page is None:
            return

        if name_location_page.create_projectdir_checkbtn.isEnabled() and (
            not name_location_page.create_projectdir_checkbtn.isChecked()
        ):
            self.dir_entry.setText(name_location_page.dir_entry.lineEdit().text().strip())
        else:
            self.dir_entry.setText('')
