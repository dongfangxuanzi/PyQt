import os
import uuid
from ... import _, get_app
from ...lib.pyqt import (
    QPushButton,
    QComboBox,
    QLabel,
    QSizePolicy,
    QLineEdit,
    QFileDialog,
    QCheckBox,
    QMessageBox,
    QGridLayout,
    Qt
)
from . import page as wizardpage
from ... import globalkeys
from ...util import appdirs, utils, fileutils, strutils
from .templatemanager import WizardtemplateManager
from .. import ext
from ..config import NewprojectConfig
from ...lib.docmanager import DOC_NEW
from .. import variables as variablesutils
from ...widgets.redlabel import QRedLabel

NEW_PROJECT_DIRECTORY_DEFAULT = appdirs.getSystemDir()


class ProjectNameLocationPage(wizardpage.BitmapTitledContainerWizardPage):
    def __init__(self, master, **kwargs):
        self._startup_path = kwargs.get('startup_path', None)
        self.enable_create_project_dir = kwargs.get('enable_create_project_dir', True)
        wizardpage.BitmapTitledContainerWizardPage.__init__(
            self,
            master,
            _("Enter the name and location for the project"),
            _("Name and Location"),
            get_app().MainFrame.projectview.get_titled_bitmap(),
            **kwargs
        )
        self.can_finish = kwargs.get('can_finish', True)
        self.allow_overwrite_on_prompt = True
        self.new_project_doc = None

    def CreateContent(self, content_frame, **kwargs):
        info_label = QLabel(_("Enter the name and location for the project."))
        info_label.setSizePolicy(QSizePolicy.Expanding,
                                 QSizePolicy.Fixed)
        content_frame.addWidget(info_label)
        self.CreateNamePage(content_frame)
        self.CreateBottomFrame(content_frame)
        self.infotext_label = QRedLabel()
        content_frame.addWidget(self.infotext_label)
        # 这等于说是给控件间添加了一个空白控件，并把它两边，或上下的控件向两端推，像弹簧一样
        content_frame.addStretch(1)

    def get_startup_file(self):
        if self._startup_path is None:
            return self._startup_path
        eval_path = variablesutils.VariablesManager(
            self.new_project_doc).EvalulateValue(self._startup_path)
        return fileutils.opj(eval_path)

    def GetChoiceDirs(self, choice_dirs):
        choice_dirs.append(utils.profile_get(
            globalkeys.PROJECT_DIRECTORY_KEY, NEW_PROJECT_DIRECTORY_DEFAULT))
        cur_project_doc = get_app().MainFrame.projectview.GetCurrentProject()
        project_dirs = []
        # 先添加当前项目文档的路径到可选路径列表中
        if cur_project_doc:
            homedir = os.path.dirname(cur_project_doc.GetAppDocMgr().homeDir)
            if homedir and (homedir not in choice_dirs):
                choice_dirs.append(homedir)
        # 再添加其它项目文档的路径到可选路径列表中
        for projectdoc in get_app().MainFrame.projectview.GetOpenProjects():
            if projectdoc == cur_project_doc:
                continue
            homedir = os.path.dirname(projectdoc.GetAppDocMgr().homeDir)
            if homedir and (homedir not in project_dirs):
                project_dirs.append(homedir)
        for projectdir in project_dirs:
            if projectdir not in choice_dirs:
                choice_dirs.append(projectdir)

        # 添加当前路径到可选路径列表中
        cwdir = None
        try:
            cwdir = os.getcwd()
        except:
            pass
        if cwdir and cwdir not in choice_dirs:
            choice_dirs.append(cwdir)
        # 最后添加系统默认路径到可选路径列表中
        if appdirs.getSystemDir() not in choice_dirs:
            choice_dirs.append(appdirs.getSystemDir())

    def CreateNamePage(self, content_box):
        name_grid_layout = QGridLayout()
        name_label = QLabel(_("Project Name") + ":")
        name_label.setSizePolicy(QSizePolicy.Fixed,
                                 QSizePolicy.Fixed)
        name_grid_layout.addWidget(name_label, 0, 0)
        self.name_entry = QLineEdit()
        self.name_entry.setSizePolicy(QSizePolicy.Expanding,
                                      QSizePolicy.Fixed)
        name_grid_layout.addWidget(self.name_entry, 0, 1, 1, 2)

        dir_label = QLabel(_("Location") + ":")
        dir_label.setSizePolicy(QSizePolicy.Fixed,
                                QSizePolicy.Fixed)
        name_grid_layout.addWidget(dir_label, 1, 0)
        choice_dirs = []
        self.GetChoiceDirs(choice_dirs)
        utils.get_logger().debug('choice dirs is :%s', choice_dirs)
        self.dir_entry = QComboBox()
        self.dir_entry.setSizePolicy(QSizePolicy.Expanding,
                                     QSizePolicy.Fixed)
        self.dir_entry.setEditable(True)
        self.dir_entry.addItems(choice_dirs)
        name_grid_layout.addWidget(self.dir_entry, 1, 1)
        self.browser_button = QPushButton(_("Browse"))
        self.browser_button.setSizePolicy(QSizePolicy.Fixed,
                                          QSizePolicy.Fixed)
        name_grid_layout.addWidget(self.browser_button, 1, 2, Qt.AlignRight)
        self.browser_button.clicked.connect(self.BrowsePath)
        content_box.addLayout(name_grid_layout)
        return name_grid_layout

    def CreateBottomFrame(self, content_box):
        # 默认创建项目目录
        self.create_projectdir_checkbtn = QCheckBox(
            _("Create project directory"))

        if self.enable_create_project_dir:
            self.create_projectdir_checkbtn.setChecked(True)
        else:
            self.create_projectdir_checkbtn.setEnabled(False)
        content_box.addWidget(self.create_projectdir_checkbtn)

    def Init(self):
        # 项目模板是导入文件模板时不显示创建项目目录复选框
        if WizardtemplateManager.get_manager().current_template.name == WizardtemplateManager.PROJECT_FROM_EXIST_CODE:
            self.create_projectdir_checkbtn.setChecked(False)
        else:
            if self.create_projectdir_checkbtn.isEnabled():
                self.create_projectdir_checkbtn.setChecked(True)

    def BrowsePath(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog | QFileDialog.ShowDirsOnly
        dirname = QFileDialog.getExistingDirectory(
            self, _("Select project directory"), self.get_location(),
            options)
        if dirname:
            self.dir_entry.lineEdit().setText(fileutils.opj(dirname))

    def Validate(self):
        self.infotext_label.setText("")
        projname = self.get_name()
        if projname == "":
            self.infotext_label.setText(_("Please provide a file name."))
            return False
        # 项目名称不能包含空格
        if projname.find(' ') != -1:
            self.infotext_label.setText(
                _("Please provide a file name that does not contains spaces."))
            return False

        if projname[0].isdigit():
            self.infotext_label.setText(
                _("File name cannot start with a number.  Please enter a different name."))
            return False
        for prj_extension in get_app().GetDocumentManager().project_extensions:
            if projname.endswith(prj_extension):
                proj_name2 = projname[:-len(prj_extension)]
                break
        else:
            proj_name2 = projname
        # 项目名称必须是字母或数字,下划线字符串允许合法
        # [a-zA-Z0-9_]  note '_' is allowed and ending '.agp'.
        if not proj_name2.replace("_", "a").isalnum():
            self.infotext_label.setText(
                _("Name must be alphanumeric ('_' allowed).  Please enter a valid name."))
            return False

        dirname = self.get_location()
        if dirname == "":
            self.infotext_label.setText(
                _("No directory.  Please provide a directory."))
            return False
        if os.sep == "\\" and dirname.find("/") != -1:
            self.infotext_label.setText(
                _("Wrong delimiter '/' found in directory path.  Use '%s' as delimiter.") % os.sep)
            return False
        return True

    def GetProjectLocation(self):
        projname = self.get_name()
        dirname = self.get_location()
        # 是否创建项目名称目录,如果是则目录包含项目名称
        if self.create_projectdir_checkbtn.isChecked():
            dirname = os.path.join(dirname, projname)
        return dirname

    def Finish(self):
        dirname = self.GetProjectLocation()
        # if dir not exist,create it first
        if not os.path.exists(dirname):
            try:
                fileutils.makedirs(dirname)
            except Exception as e:
                # 如果不是最后的页面,错误提示控件不可见
                # 错误的信息需要弹出来,来醒目地提示用户错误,否则用户看不到错误信息
                if self.infotext_label.isVisible():
                    self.infotext_label.setText("%s" % str(e))
                else:
                    QMessageBox.critical(self.parent(), _('Error'), str(e))
                return False

        projname = self.get_name()
        full_project_path = os.path.join(dirname, strutils.MakeNameEndInExtension(
            projname, self.get_project_extension()))
        if os.path.exists(full_project_path):
            documents = get_app().MainFrame.projectview.GetOpenProjects()
            docfiles = [document.GetFilename().lower()
                        for document in documents]
            if self.allow_overwrite_on_prompt:
                res = QMessageBox.question(
                    self.parent(),
                    _("File Exists"),
                    _("That project file already exists. Would you like to overwrite it."),
                    QMessageBox.Yes | QMessageBox.No
                )
                if res != QMessageBox.Yes:
                    return False
                # 如果同名的项目文档已经打开, 必须先关闭
                if full_project_path.lower() in docfiles:
                    document = documents[docfiles.index(
                        full_project_path.lower())]
                    # make sure it doesn't ask to save the project
                    # 强制关闭项目文档
                    get_app().MainFrame.projectview.GetView().close_doc(document, force=True)
            else:
                # 如果不是最后的页面,错误提示控件不可见
                # 错误的信息需要弹出来,来醒目地提示用户错误,否则用户看不到错误信息
                if self.infotext_label.isVisible():
                    self.infotext_label_var.set(
                        _("That file already exists. Please choose a different name."))
                else:
                    QMessageBox.critical(self.parent(), _('File Exists'), _(
                        "That file already exists. Please choose a different name."))
                return False

            # What if the document is already open and we're overwriting it?
            documents = get_app().GetDocumentManager().GetDocuments()
            for document in documents:
                # If the renamed document is open, update it
                if os.path.normcase(document.GetFilename()) == os.path.normcase(full_project_path):
                    document.DeleteAllViews()
                    break
            os.remove(full_project_path)
        self._new_project_config = self.GetNewprojectConfig()
        utils.profile_set(globalkeys.PROJECT_DIRECTORY_KEY,
                          self._new_project_config.Location)
        if not self.SaveProject(full_project_path):
            return False
        return True

    def get_project_extension(self):
        return ext.COMMON_PROJECT_EXTENSION

    def create_project_doc(self, path):
        template = self.GetProjectTemplate()
        self.new_project_doc = template.CreateDocument(path, flags=DOC_NEW)
        # set project name
        self.new_project_doc.GetModel().Name = self._new_project_config.Name
        self.new_project_doc.GetModel().Id = str(uuid.uuid1()).upper()
        return self.new_project_doc

    def SaveProject(self, path):
        self.create_project_doc(path)
        if not self.new_project_doc.OnSaveDocument(path):
            return False
        view = get_app().MainFrame.projectview.GetView()
        view.AddProjectToView(self.new_project_doc)
        # 添加到历史项目文件列表中
        get_app().GetDocumentManager().GetProjectHistory().AddFileToHistory(path)
        # 强制显示项目视图
        get_app().MainFrame.activateProjectTab()
        return True

    def GetProjectTemplate(self):
        return get_app().GetDocumentManager().FindTemplateForTestPath(self.get_project_extension())

    def is_projectdir_created(self):
        return self.create_projectdir_checkbtn.isChecked()

    def get_name(self):
        return self.name_entry.text().strip()

    def get_location(self):
        return self.dir_entry.lineEdit().text().strip()

    def GetNewprojectConfig(self):
        return NewprojectConfig(
            self.get_name(),
            self.get_location(),
            self.is_projectdir_created()
        )
