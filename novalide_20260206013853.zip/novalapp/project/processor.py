import time
from ..util.exceptions import ProcessordocNotmatchedErrror
from ..util import utils


class Processor:
    """description of class"""

    def __init__(self, statusbar, processor_name, enabled=True):
        self._statusbar = statusbar
        # 是否禁止处理器
        self._enabled = enabled
        # 处理器名称
        self._processor_name = processor_name
        self._doc = None
        self._start_time = None
        self._end_time = None
        # 处理器处理总的文件数
        self.total_file_count = -1
        # 处理器当前处理的文件数,以便追踪处理进度
        self.updated_file_count = -1
        self._running = False
        self._stopped = False

    @property
    def doc(self):
        return self._doc

    @doc.setter
    def doc(self, prj_doc):
        self._doc = prj_doc

    @property
    def name(self):
        return self._processor_name

    @property
    def enabled(self):
        return self._enabled

    @enabled.setter
    def enabled(self, value):
        self._enabled = value

    def init(self, doc):
        self._doc = doc
        self._start_time = time.time()
        self.set_running()
        return True

    def end(self, doc):
        self.check_doc_matched_ornot(doc, isend=True)
        self._end_time = time.time()
        utils.get_logger().info("%s processor elapse time:%d(s)",
                                self._processor_name, int(self._end_time - self._start_time))
        self.set_stopped()

    def run(self, doc, filepath):
        if self._doc is None:
            self._doc = doc
        self.check_doc_matched_ornot(doc)

    def find_doc_file(self, doc, filepath):
        if not doc.GetModel().FindFile(filepath):
            utils.get_logger().error('file %s is not in project %s',
                                     filepath, doc.GetModel().name)
            return False
        return True

    def check_doc_matched_ornot(self, doc, isend=False):
        if self._doc and self._doc != doc:
            raise ProcessordocNotmatchedErrror(
                'processor name %s project doc %s is not matched doc file %s when %s processor' % (
                    self.name,
                    doc.GetFilename(),
                    self._doc.GetFilename(),
                    "running" if not isend else "end"
                )
            )

    def update_progress(self, filepath):
        self.updated_file_count += 1
        utils.get_logger().debug('processor %s update file %s',
                                 self._processor_name, filepath)
        utils.get_logger().debug(
            'processor %s total files is %s, current update files is %d',
            self._processor_name,
            self.total_file_count,
            self.updated_file_count
        )

    def init_progress(self, total_num):
        self.total_file_count = total_num
        self.updated_file_count = 0

    @property
    def running(self):
        return self._running

    @running.setter
    def running(self, value):
        self._running = value

    @property
    def stopped(self):
        return self._stopped

    def stop(self, reason=''):
        self.set_stopped()

    def set_stopped(self):
        self._stopped = True
        self.running = False

    def set_running(self):
        self._stopped = False
        self.running = True
