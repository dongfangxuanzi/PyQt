# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""project viewer implementation"""
# pylint: disable=W0703
import threading
import os
from typing import Optional, List
from ..qtimage import load_icon
from ..util import fileutils, ui_utils, strutils, utils, pathutils
from ..lib.docmanager import DOC_SILENT, DOC_OPEN_ONCE, DOC_NEW
from ..lib.pyqt import (
    QSize,
    Qt,
    QWidget,
    QVBoxLayout,
    QToolBar,
    QAction,
    QToolButton,
    QSizePolicy,
    QDialog,
    QMessageBox,
    QCursor,
    pyqtSignal,
    QComboBox,
    QFileDialog,
    QDir,
    QUrl,
    QAbstractItemView
)
from .property.service import PropertiesService
from .treeview.treectrl import ProjectTreeCtrl
from .treeview import treeitems
from ..syntax.syntax import SyntaxThemeManager
from .view import ProjectView, AddProjectMapping
from . import document as projectdocument
from . import ext
from .wizard.progressfiles import ImportProgressFiles, ImportFiles
from .. import menuitems
from .. import globalkeys
from ..bars.menubar import find_menu, NewQMenu, MenuItem
from .ui.openwith import EditorSelectionDlg
from .clipboard import Clipboard
from . import command as projectcommand
from ..widgets.spacers import ToolBarExpandingSpacer
from .sched import SchedulerRun
from ..editor.texteditor import TextEditor
from ..editor.textview import TextView
from .. import get_app, _


class ProjectBrowser(QWidget):
    """Project viewer widget"""
    # 文件保存时发出的信号
    sigFileUpdated = pyqtSignal(projectdocument.ProjectDocument, str)
    # 关闭项目文档信号
    SIG_CLOSE_PROJECT_DOC = pyqtSignal(projectdocument.ProjectDocument)
    # 项目根节点右键弹出菜单发送给插件的消息,插件接收消息在消息函数里面就可以添加自定义菜单项了
    SIG_PROJECTVIEW_POPUP_ROOT_MENU = pyqtSignal(
        NewQMenu, treeitems.TreeViewItem)
    # 项目文件节点右键弹出菜单信号
    SIG_PROJECTVIEW_POPUP_FILE_MENU = pyqtSignal(
        NewQMenu, treeitems.TreeViewItem)
    # 编辑区文件右键弹出菜单信号
    SIG_EDIT_TEXT_POPUP_MENU = pyqtSignal(
        projectdocument.ProjectDocument,
        NewQMenu,
        TextEditor
    )
    # 项目文件编辑器内容发生变动
    SIG_BUFFER_MODIFIED = pyqtSignal(projectdocument.ProjectDocument, TextView)

    def __init__(self, parent):
        super().__init__(parent)
        self._view = None
        # 文档和项目的对照表
        self._mapToProject = {}
        self.__mainwindow = parent
        self.prjContextItem = None
        self.__prjContextMenu = None
        self.sched_runner = None
        self.event = threading.Event()
        self._clip_board = Clipboard()
        self.upper = self.__create_project_partlayout()
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)

        layout.addWidget(self.upper)
        self.setLayout(layout)
        self.__updatePrjToolbarButtons()

        # 软件启动时加载存储配置保存的历史项目列表,记住这个状态
        self._is_loading = False
        self._lock = threading.Lock()
        # 创建项目视图,所有项目共享同一个视图,必须在函数的最后创建
        view = self.CreateView()
        self.SetView(view)
        self.GetView().AddProjectRoot(_("Projects"))
        default_filters = SyntaxThemeManager().GetLexer(
            get_app().GetDefaultLangId()).Exts
        self.__filters = utils.profile_get(
            globalkeys.PROJECT_FILE_FILTERS,
            default_filters
        )

    @property
    def filters(self):
        return self.__filters

    @filters.setter
    def filters(self, filterlist):
        self.__filters = filterlist

    @property
    def prj_newdir_button(self):
        return self._prjnewdirbutton

    @property
    def is_loading(self):
        return self._is_loading

    @property
    def TheClipboard(self):
        return self._clip_board

    def GetView(self):
        return self._view

    def CreateView(self):
        return ProjectView(self)

    def SetView(self, view):
        self._view = view

    def AddProject(self, name):
        self.project_combox.addItem(name)
        itemcount = self.project_combox.count()
        return itemcount - 1

    def setTooltips(self, switchon):
        """Triggers the tooltips mode"""
        self.project_treeview.model().sourceModel().setTooltips(switchon)
        self.filesystemView.model().sourceModel().setTooltips(switchon)

    def GetProjectTreectrl(self):
        return ProjectTreeCtrl(self)

    def reload(self):
        selected_item = self.project_treeview.GetSingleSelectItem()
        if selected_item is not None:
            self.Refresh(selected_item)

    def copyToClipboard(self):
        selected_item = self.project_treeview.GetSingleSelectItem()
        if selected_item is not None:
            self.CopyPath(selected_item)

    def _on_select(self):
        self.ActivateView()

    def open_tree_node(self, index):
        # 项目列表为空时不处理事件
        if self.GetView().GetDocument() is None:
            return
        self.GetView().SaveFolderState()

    def select_project(self, i):
        if i < 0:
            utils.get_logger().error('invalid item index `%d` when loading project', i)
            return
        # 项目浏览器列表框关闭项目文档时候,可能会多次触发这个函数
        # 从而会导致启动多个处理器线程,须防止多线程处理混乱
        self.GetView().ProjectSelect()
        if not self._is_loading:
            self.Rundoc(self.GetView().GetDocument())
        self.__updatePrjToolbarButtons()

    def is_sched_running(self):
        if self.sched_runner is None:
            return False
        return self.sched_runner.running

    def stop_sched(self):
        utils.get_logger().info(
            'start stop running doc %s',
            self.sched_runner.project.GetFilename()
        )
        self.sched_runner.stop()
        self.event.wait()
        self.event.clear()
        utils.get_logger().info(
            'stop running doc %s success',
            self.sched_runner.project.GetFilename()
        )

    def force_stop_sched(self):
        if self.is_sched_running():

            self.stop_sched()

    @ui_utils.call_after_with_time(3000)
    def Rundoc(
        self,
        doc,
        processors: Optional[List]=None,
        files: Optional[List]=None,
        stop_running_doc=True
    ):
        with self._lock:
            if doc is None or self.GetView().GetDocument() is None:
                self.force_stop_sched()
                return
            # 是否开启项目文件扫描器,扫描文件给其他程序使用
            if not utils.profile_get_int(globalkeys.ENABLE_PROJECT_SCANNER_KEY, True):
                return
            # 是否停止正在运行的项目文档,切换文档时需要停止,如果是启动新处理器时,无需停止
            if stop_running_doc:
                self.force_stop_sched()
                if self.is_sched_running():
                    return
            self.sched_runner = SchedulerRun(self, doc, processors, files)
            self.sched_runner.start()

    def register_sched_processor(self, processor):
        SchedulerRun.SCHED_PROCESSORS.append(processor)

    def get_processor(self, processor_name):
        for processor in SchedulerRun.SCHED_PROCESSORS:
            if processor.name == processor_name:
                return processor
        return None

    def getProjectToolbar(self):
        """Provides a reference to the project toolbar"""
        return self.upper_toolbar

    def unloadProject(self):
        """Unloads the project"""
        # Check first if the project can be unloaded
        self.CloseProject()

    def projectProperties(self):
        """Triggered when the project properties button is clicked"""
        self.OnProjectProperties()

    def create_context_menu(self):
        if self.__prjContextMenu is not None:
            self.__prjContextMenu.destroy()
            self.__prjContextMenu = None
        self.__prjContextMenu = NewQMenu(self)

    def get_refresh_id_pos(self, menu):
        '''
            刷新菜单的位置,在分割线前一个位置
        '''
        pos = menu.find_pos(menuitems.ID_ADD_FOLDER)
        menuitem = menu.GetItemByIndex(pos)
        while menuitem.id != menu.INVALID_ITEM_ID:
            pos += 1
            menuitem = menu.GetItemByIndex(pos)
        return pos

    def popup_project_menu(self):
        edit_menu = get_app().get_menu(_("&Edit"))
        self.create_context_menu()
        common_item_ids = self.GetPopupProjectItemIds()
        self.GetProjectItemsMenu(self.__prjContextMenu, common_item_ids)
        if self.GetCurrentProject() is not None:
            pos = self.get_refresh_id_pos(self.__prjContextMenu)
            self.__prjContextMenu.Insert(
                pos,
                menuitems.ID_REFRESH_FOLDER,
                _("&Refresh folder"),
                img=get_app().GetImage("project/refresh.png"),
                handler=lambda: self.ProcessEvent(menuitems.ID_REFRESH_FOLDER)
            )

            self.get_edit_item_menu(
                edit_menu, self.__prjContextMenu, menuitems.ID_PASTE)

            self.__prjContextMenu.Append(
                menuitems.ID_RENAME,
                _("&Rename"),
                handler=lambda: self.ProcessEvent(menuitems.ID_RENAME)
            )
            self.get_edit_item_menu(
                edit_menu, self.__prjContextMenu, menuitems.ID_CLEAR)
            self.__prjContextMenu.Append(
                menuitems.ID_OPEN_TERMINAL_PATH,
                _("Open Command Prompt here..."),
                handler=lambda: self.ProcessEvent(
                    menuitems.ID_OPEN_TERMINAL_PATH)
            )
            self.__prjContextMenu.Append(
                menuitems.ID_COPY_PATH,
                _("Copy full path"),
                handler=lambda: self.ProcessEvent(menuitems.ID_COPY_PATH)
            )
        self.SIG_PROJECTVIEW_POPUP_ROOT_MENU.emit(
            self.__prjContextMenu, self.prjContextItem)
        self.__prjContextMenu.popup(QCursor.pos())

    def GetPopupProjectItemIds(self):
        project_item_ids = [menuitems.ID_NEW_PROJECT,
                            menuitems.ID_OPEN_PROJECT]
        if self.GetCurrentProject() is not None:
            project_item_ids.extend([
                menuitems.ID_CLOSE_PROJECT,
                menuitems.ID_SAVE_PROJECT,
                menuitems.ID_DELETE_PROJECT,
                menuitems.ID_CLEAN_PROJECT,
                menuitems.ID_ARCHIVE_PROJECT
            ]
            )
            project_item_ids.extend(
                [
                    None,
                    menuitems.ID_IMPORT_FILES,
                    menuitems.ID_ADD_FILES_TO_PROJECT,
                    menuitems.ID_ADD_DIR_FILES_TO_PROJECT,
                    None,
                    menuitems.ID_ADD_NEW_FILE,
                    menuitems.ID_ADD_FOLDER
                ]
            )
            project_item_ids.extend(
                [None, menuitems.ID_PROPERTIES, menuitems.ID_OPEN_FOLDER_PATH]
            )
        return project_item_ids

    def AppendFileFoderCommonMenu(self, menu):
        menu.add_separator()
        menu.Append(menuitems.ID_PROPERTIES, _("&Properties"),
                    handler=lambda: self.ProcessEvent(menuitems.ID_PROPERTIES))
        menu.Append(menuitems.ID_OPEN_FOLDER_PATH, _("Open Path in Explorer"),
                    handler=lambda: self.ProcessEvent(menuitems.ID_OPEN_FOLDER_PATH))
        menu.Append(menuitems.ID_OPEN_TERMINAL_PATH, _("Open Command Prompt here..."),
                    handler=lambda: self.ProcessEvent(menuitems.ID_OPEN_TERMINAL_PATH))
        menu.Append(menuitems.ID_COPY_PATH, _("Copy Full Path"),
                    handler=lambda: self.ProcessEvent(menuitems.ID_COPY_PATH))

    def popup_folder_menu(self):
        self.create_context_menu()
        common_item_ids = self.GetPopupFolderItemIds()
        self.GetProjectItemsMenu(
            self.__prjContextMenu, common_item_ids, is_folder=True)
        self.__prjContextMenu.add_separator()
        edit_menu = find_menu(_("&Edit"), get_app().Menubar)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_UNDO)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_REDO)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_CUT)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_COPY)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_PASTE)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_CLEAR)
        self.__prjContextMenu.add_separator()

        self.__prjContextMenu.Append(menuitems.ID_RENAME, _(
            "&Rename"), handler=lambda: self.ProcessEvent(menuitems.ID_RENAME))
        self.__prjContextMenu.Append(menuitems.ID_REMOVE_FROM_PROJECT, _(
            "Remove from Project"), handler=lambda: self.ProcessEvent(menuitems.ID_REMOVE_FROM_PROJECT))
        pos = self.get_refresh_id_pos(self.__prjContextMenu)
        self.__prjContextMenu.Insert(
            pos,
            menuitems.ID_REFRESH_FOLDER,
            _("&Refresh folder"),
            handler=lambda: self.ProcessEvent(menuitems.ID_REFRESH_FOLDER),
            img=get_app().GetImage("project/refresh.png")
        )
        self.AppendFileFoderCommonMenu(self.__prjContextMenu)
        self.__prjContextMenu.popup(QCursor.pos())

    @ui_utils.update_toolbar
    def ActivateView(self):
        self.project_treeview.setFocus()
        get_app().GetDocumentManager().ActivateView(self.GetView())

    def GetPopupFolderItemIds(self):
        folder_item_ids = [
            menuitems.ID_IMPORT_FILES,
            menuitems.ID_ADD_FILES_TO_PROJECT,
            menuitems.ID_ADD_DIR_FILES_TO_PROJECT,
            None,
            menuitems.ID_ADD_NEW_FILE,
            menuitems.ID_ADD_FOLDER
        ]
        return folder_item_ids

    def popup_file_menu(self):
        self.create_context_menu()
        self.__prjContextMenu.Append(
            menuitems.ID_OPEN_SELECTION,
            _("&Open"),
            handler=lambda: self.ProcessEvent(menuitems.ID_OPEN_SELECTION)
        )
        self.__prjContextMenu.Append(
            menuitems.ID_OPEN_SELECTION_WITH,
            _("&Open With..."),
            handler=lambda: self.ProcessEvent(menuitems.ID_OPEN_SELECTION_WITH)
        )
        self.__prjContextMenu.add_separator()
        edit_menu = find_menu(_("&Edit"), get_app().Menubar)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_UNDO)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_REDO)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_CUT)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_COPY)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_PASTE)
        self.get_edit_item_menu(
            edit_menu, self.__prjContextMenu, menuitems.ID_CLEAR)
        self.__prjContextMenu.add_separator()

        self.__prjContextMenu.Append(menuitems.ID_RENAME, _(
            "&Rename"), handler=lambda: self.ProcessEvent(menuitems.ID_RENAME))
        self.__prjContextMenu.Append(menuitems.ID_REMOVE_FROM_PROJECT, _(
            "Remove from Project"), handler=lambda: self.ProcessEvent(menuitems.ID_REMOVE_FROM_PROJECT))
        self.AppendFileMenu(self.__prjContextMenu)
        self.SIG_PROJECTVIEW_POPUP_FILE_MENU.emit(
            self.__prjContextMenu, self.prjContextItem)
        self.__prjContextMenu.popup(QCursor.pos())

    def AppendFileMenu(self, menu):
        self.AppendFileFoderCommonMenu(menu)

    def get_edit_item_menu(self, edit_menu, popmenu, item_id):
        menu_item = edit_menu.FindMenuItem(item_id)
        action = menu_item.action
        new_action = QAction(action.text(), self)
        new_action.setIcon(action.icon())
        new_action.setShortcut(action.shortcut())
        new_action.triggered.connect(lambda: self.ProcessEvent(item_id))
        new_item = MenuItem(menu_item.id, new_action,
                            lambda: self.GetView().UpdateUI(item_id), None)
        popmenu.AppendItem(new_item)

    def GetProjectItemsMenu(self, menu, menu_item_ids, is_folder=False):
        project_menu = find_menu(_("&Project"), get_app().Menubar)
        for item_id in menu_item_ids:
            if item_id is None:
                menu.add_separator()
                continue
            menu_item = project_menu.FindMenuItem(item_id)
            if menu_item is not None:
                menu.AppendItem(menu_item)

    def GetFilesFromCurrentProject(self):
        view = self.GetView()
        if view:
            project = view.GetDocument()
            if project:
                return project.GetFiles()
        return None

    def on_double_click(self, model_index):
        if not model_index.isValid():
            return
        item = self.project_treeview.model().item(model_index)
        self.OpenSelection(item)

    def OpenSelection(self, treeitem):
        doc = None
        try:
            # 项目文件的打开方式模板
            file_template = None
            if treeitem.itemType == treeitems.FileItemType:
                filepath = treeitem.path
                # 标准化文件路径
                filepath = fileutils.opj(filepath)
                if not os.path.exists(filepath):
                    msg_title = get_app().GetAppName()
                    if not msg_title:
                        msg_title = _("File Not Found")
                    ret = QMessageBox.question(
                        self,
                        msg_title,
                        _("The file '%s' was not found in '%s'.\n\nWould you like to browse for the file?")
                        % (fileutils.get_filename_from_path(filepath), fileutils.get_filepath_from_path(filepath)),
                        QMessageBox.Yes | QMessageBox.No
                    )
                    # 选中否
                    if ret == QMessageBox.No:
                        return
                    options = QFileDialog.Options()
                    options |= QFileDialog.DontUseNativeDialog
                    newpath, _f = QFileDialog.getOpenFileName(
                        self,
                        _("Choose a file"),
                        None,
                        options=options
                    )
                    if newpath:
                        newpath = fileutils.opj(newpath)
                        parent_item = treeitem.parent()
                        # update Project Model with new location
                        self.GetView().GetDocument().UpdateFilePath(filepath, newpath)
                        filepath = os.path.join(
                            fileutils.get_filepath_from_path(filepath),
                            fileutils.get_filename_from_path(newpath)
                        )
                        fileitem = self.project_treeview.FindItem(
                            filepath, parent_item)
                        if fileitem:
                            self.project_treeview.setCurrentItem(fileitem)
                    else:
                        # 选择取消按钮
                        return
                else:
                    project_file = self.GetItemFile(filepath)
                    # 获取项目文件的打开方式模板
                    file_template = self.GetView().GetOpenDocumentTemplate(project_file)
                # 如果存在项目文件的打开方式模板,则以打开方式模板打开项目文件
                if file_template:
                    doc = get_app().GetDocumentManager().CreateTemplateDocument(
                        file_template, filepath, DOC_SILENT | DOC_OPEN_ONCE)
                    docs = [doc]
                # 否则以扩展名默认模板打开项目文件
                else:
                    docs = get_app().GetDocumentManager().CreateDocument(
                        filepath, DOC_SILENT | DOC_OPEN_ONCE)
                if not docs and filepath.endswith(
                    tuple(get_app().GetDocumentManager().project_extensions)
                ):  # project already open
                    self.SetProject(filepath)
                elif docs:
                    AddProjectMapping(docs[0])
                    # 检查文件扩展名是否有对应的文件扩展插件
                    # ui_utils.CheckFileExtension(filepath,False)
        except IOError as e:
            msg_title = get_app().GetAppName()
            if not msg_title:
                msg_title = _("File Error")
            QMessageBox.critical(
                self,
                msg_title,
                "Could not open '%s'." % filepath,
            )

    def SetFocus(self):
        self.setFocus()
        self.project_treeview.setFocus()

    def OpenSelectionWith(self, treeitem):
        '''
            用户选择打开方式来打开项目文件
        '''
        selected_file_path = treeitem.path
        item_file = self.GetItemFile(selected_file_path)
        dlg = EditorSelectionDlg(
            get_app().GetTopWindow(), item_file, self.GetView().GetDocument())
        if dlg.exec_() == EditorSelectionDlg.Accepted:
            found_doc = get_app().GetDocumentManager().GetDocument(selected_file_path)
            if found_doc:
                ret = QMessageBox.question(
                    self,
                    get_app().GetAppName(),
                    _("The document \"%s\" is already open,Do you want to close it?") % selected_file_path,
                    QMessageBox.Yes | QMessageBox.No
                )
                # 关闭已打开窗口
                if ret == QMessageBox.Yes:
                    found_view = found_doc.GetFirstView()
                    found_view.Close()
                    if found_doc in get_app().GetDocumentManager().GetDocuments():
                        found_doc.Destroy()
                    frame = found_view.GetFrame()
                    if frame:
                        frame.Destroy()
                else:
                    return
            doc = get_app().GetDocumentManager().CreateTemplateDocument(
                dlg.selected_template, selected_file_path, DOC_SILENT)
            # 用户更改了打开方式
            if doc is not None and dlg._is_changed and get_app().GetDocumentManager().GetDocument(selected_file_path):
                # 打开方式的模板图标
                template_icon = dlg.selected_template.GetIcon()
                if dlg.Openwith == dlg.OPEN_WITH_PATH:
                    utils.profile_set(self.GetView().GetDocument().GetFileKey(
                        item_file, "Open"), dlg.selected_template.GetDocumentName())
                    file_template = get_app().GetDocumentManager(
                    ).FindTemplateForPath(selected_file_path)
                    if file_template != dlg.selected_template:
                        if template_icon is not None:
                            # 更改文件item的模板图标
                            treeitem.setIcon(template_icon)
                # 以所有文件名方式打开
                elif dlg.Openwith == dlg.OPEN_WITH_NAME:
                    filename = os.path.basename(selected_file_path)
                    # 保存文件名对应的模板
                    utils.profile_set(
                        "Open/filenames/%s" % filename, dlg.selected_template.GetDocumentName())
                    if template_icon is not None:
                        # 批量更改所有文件名的图标
                        self.ChangeItemsImageWithFilename(
                            self.GetView()._treeCtrl.GetRootItem(), filename, template_icon)
                # 以所有扩展名方式打开
                elif dlg.Openwith == dlg.OPEN_WITH_EXTENSION:
                    extension = strutils.get_file_extension(
                        os.path.basename(selected_file_path))
                    # 保存扩展名对应的模板
                    utils.profile_set(
                        "Open/extensions/%s" % extension, dlg.selected_template.GetDocumentName())
                    if template_icon is not None:
                        # 批量更改所有扩展名的图标
                        self.ChangeItemsImageWithExtension(
                            self.GetView()._treeCtrl.GetRootItem(), extension, template_icon)
                else:
                    assert False

    def GetItemFile(self, file_path):
        return self.GetView().GetDocument().GetModel().FindFile(file_path)

    def FindProjectByFile(self, filename):
        '''查找包含文件的所有项目文档,当前项目文档放在第一位'''
        retval = []
        for document in get_app().GetDocumentManager().GetDocuments():
            # 文档类型为项目文档
            if isinstance(document.GetDocumentTemplate(), projectdocument.ProjectDocument):
                if document.GetFilename() == filename:
                    retval.append(document)
                # 项目文档是否包含该文件
                elif document.IsFileInProject(filename):
                    retval.append(document)

        # 将当前项目置于第一位
        curr_project = self.GetCurrentProject()
        if curr_project and curr_project in retval:
            retval.remove(curr_project)
            retval.insert(0, curr_project)

        return retval

    def GetCurrentProject(self):
        view = self.GetView()
        if view:
            return view.GetDocument()
        return None

    def AddProjectMapping(self, key, projectdoc=None):
        """ 设置文档或者其他对象对应的项目
        """
        if not projectdoc:
            projectdoc = self.GetCurrentProject()
        self._mapToProject[key] = projectdoc

    def NewProject(self):
        '''
            新建项目
        '''
        template = get_app().GetDocumentManager().FindTemplateForTestPath(
            ext.COMMON_PROJECT_EXTENSION)
        template.CreateDocument("", flags=DOC_NEW)

    @ui_utils.update_toolbar
    def OpenProject(self):
        '''
            打开项目
        '''
        dialog = QFileDialog(self, _('Open project'))
        dialog.setFileMode(QFileDialog.ExistingFile)
        # 这里必须设置为False
        dialog.setOption(QFileDialog.DontUseNativeDialog, False)
        descr = get_app().GetDocumentManager().get_project_filter()
        dialog.setNameFilter(descr)
        urls = []
        for dname in QDir.drives():
            urls.append(QUrl.fromLocalFile(dname.absoluteFilePath()))
        urls.append(QUrl.fromLocalFile(QDir.homePath()))
        dialog.setDirectory(QDir.homePath())
        dialog.setSidebarUrls(urls)
        if dialog.exec_() != QDialog.Accepted:
            return

        filenames = dialog.selectedFiles()
        filename = os.path.realpath(str(filenames[0]))
        project_path = fileutils.opj(filename)
        current_project = self.GetCurrentProject()
        if current_project is not None and project_path == current_project.GetFilename():
            utils.get_logger().warning("The selected project to load is the currently loaded one.")
            return
        self.GetView().OpenProject(project_path)

    @ui_utils.update_toolbar
    def CloseProject(self):
        self.GetView().CloseProject()
        self.__updatePrjToolbarButtons()

    @ui_utils.update_toolbar
    def SaveProject(self):
        self.GetView().SaveProject()

    @ui_utils.update_toolbar
    def DeleteProject(self):
        self.GetView().DeleteProject()

    def ArchiveProject(self):
        self.GetView().ArchiveProject()

    def CleanProject(self):
        self.GetView().CleanProject()

    def GetOpenProjects(self):
        return self.GetView().Documents

    def copy_progress_files_to_project(
        self,
        progress_ui,
        file_list,
        src_path,
        dest_path,
        progress_que
    ):
        ImportProgressFiles(
            self,
            progress_ui,
            file_list,
            src_path,
            dest_path,
            progress_que
        ).start()

    def build_file_list(self, file_list, src_path, dest_path):
        return ImportFiles(
            self, file_list, src_path, dest_path).build_file_list()

    def FindProjectFromMapping(self, key):
        """ 从对照表中快速查找文档对应的项目"""
        return self._mapToProject.get(key, None)

    def ProcessEvent(self, menu_id):
        view = self.GetView()
        if view.ProcessEvent(menu_id):
            return True
        if menu_id == menuitems.ID_OPEN_SELECTION:
            self.OpenSelection(self.prjContextItem)
        elif menu_id == menuitems.ID_OPEN_SELECTION_WITH:
            self.OpenSelectionWith(self.prjContextItem)
        elif menu_id == menuitems.ID_PROPERTIES:
            self.OnProperties(self.prjContextItem)
        elif menu_id == menuitems.ID_OPEN_FOLDER_PATH:
            self.OpenFolderPath(self.prjContextItem)
        elif menu_id == menuitems.ID_OPEN_TERMINAL_PATH:
            self.OpenPromptPath(self.prjContextItem)
        elif menu_id == menuitems.ID_COPY_PATH:
            self.CopyPath(self.prjContextItem)
        elif menu_id == menuitems.ID_REFRESH_FOLDER:
            self.Refresh(self.prjContextItem)
        else:
            return False
        return True

    def Refresh(self, item):
        filepath = self.GetItemPath(item)
        self.RefreshPath(filepath)

    def GetItemPath(self, item):
        if self.GetView()._IsItemFile(item):
            filepath = self.GetView()._GetItemFilePath(item)
        else:
            document = self.GetCurrentProject()
            project_path = os.path.dirname(document.GetFilename())
            filepath = fileutils.opj(os.path.join(
                project_path, self.GetView()._GetItemFolderPath(item)))
        return filepath

    def RefreshPath(self, path):
        '''
            刷新文件夹添加新文件
        '''
        add_count = 0
        doc = self.GetCurrentProject()
        item = self.project_treeview.GetSingleSelectItem()
        folderpath = self.GetView()._GetItemFolderPath(item)
        default_filters = self.__filters
        # 加载默认过滤项目文件扩展名列表,刷新项目文件夹时使用
        self.__filters = utils.profile_get(
            globalkeys.PROJECT_FILE_FILTERS,
            default_filters
        )
        try:
            # 扫描文件夹下的新文件
            for l in os.listdir(path):
                file_path = os.path.join(path, l)
                if fileutils.is_file_path_hidden(file_path):
                    continue
                if os.path.isfile(file_path) and strutils.get_file_extension(l, keepdot=False) in self.__filters:
                    if not doc.GetModel().FindFile(file_path):
                        add_count += 1
                        doc.GetCommandProcessor().Submit(
                            projectcommand.ProjectAddFilesCommand(
                                doc,
                                [file_path],
                                folderPath=folderpath
                            )
                        )
                elif os.path.isdir(file_path):
                    if folderpath:
                        child_folderPath = folderpath + "/" + l
                    else:
                        child_folderPath = l
                    folder = self.GetView()._treeCtrl.FindFolder(child_folderPath)
                    if not folder:
                        doc.GetCommandProcessor().Submit(
                            projectcommand.ProjectAddFolderCommand(self.GetView(), doc, child_folderPath))
        except Exception as e:
            QMessageBox.critical(self, get_app().GetAppName(), str(e))
            return

        # 检查节点文件或文件夹是否存在
        for child in item.children():
            item_path = self.GetItemPath(child)
            project_view = self.GetView()
            if project_view._IsItemFile(child):
                if not os.path.isfile(item_path):
                    project_view._treeCtrl.delete_node(child)
                    doc.GetCommandProcessor().Submit(
                        projectcommand.ProjectRemoveFilesCommand(doc, [item_path]))
            else:
                if not os.path.exists(item_path):
                    folderpath = project_view._GetItemFolderPath(child)
                    doc.GetCommandProcessor().Submit(
                        projectcommand.ProjectRemoveFolderCommand(project_view, doc, folderpath))
        if 0 == add_count:
            QMessageBox.information(
                self, get_app().GetAppName(), _("there is not files to add"))
        else:
            QMessageBox.information(self, get_app().GetAppName(), _(
                "total add %d files to project") % add_count)

    def OnProperties(self, item):
        PropertiesService().ShowPropertyDialog(item)

    def OnProjectProperties(self, item_name=None):
        PropertiesService().ShowPropertyDialog(
            self.project_treeview.GetRootItem(), option_name=item_name)

    def OpenProjectPath(self):
        document = self.GetCurrentProject()
        pathutils.safe_open_file_directory(document.GetFilename())

    def OpenFolderPath(self, item):
        filepath = self.GetItemPath(item)
        pathutils.safe_open_file_directory(filepath)

    def OpenPromptPath(self, item):
        filepath = self.GetItemPath(item)
        get_app().open_terminator(filename=filepath)

    def CopyPath(self, item):
        filepath = self.GetItemPath(item)
        ui_utils.copytoclipboard(filepath)

    def RemoveProjectMapping(self, key):
        """ Remove mapping from model or document to project.  """
        if key in self._mapToProject:
            del self._mapToProject[key]

    @staticmethod
    def get_titled_bitmap():
        return "logo-64.png"

    def SetCurrentProject(self):
        # 如果是命令行打开项目,则设置该项目为当前项目
        # 否则从存储配置中加载当前项目
        if self.GetCurrentProject() is None:
            curr_project = utils.profile_get(globalkeys.CURRENT_PROJECT_KEY)
            doclist = [document.GetFilename()
                       for document in self.GetView().Documents]
            # 从所有存储项目中查找是否存在当前项目,如果存在则加载为活跃项目
            if curr_project in doclist:
                self.GetView().SetProject(curr_project)

    def LoadSavedProjects(self):
        self._is_loading = True
        opened_docs = False
        if utils.profile_get_int(globalkeys.LOAD_LAST_SAVEDOCS_KEY, True):
            doclist = utils.profile_get(globalkeys.PROJECT_SAVE_DOCS_KEY, [])
            doc = None
            get_app().GetDocumentManager().load_project_template()
            project_extensions = get_app().GetDocumentManager().project_extensions
            for filename in doclist:
                if isinstance(filename, str) and strutils.get_file_extension(filename, keepdot=True) in project_extensions:
                    if os.path.exists(filename):
                        doc = get_app().GetDocumentManager().CreateDocument(
                            filename, DOC_SILENT | DOC_OPEN_ONCE)
                if doc:
                    opened_docs = True
        self._is_loading = False
        if utils.profile_get_int(globalkeys.ENABLE_PROJECT_SCANNER_KEY, True):
            self.Rundoc(self.GetView().GetDocument())
        return opened_docs

    def SaveProjectConfig(self):
        return self.GetView().WriteProjectConfig()

    def close_window(self):
        return self.SaveProjectConfig()

    def _init_commands(self):
        project_menu = find_menu(_("&Project"), get_app().Menubar)
        get_app().AddCommand(menuitems.ID_NEW_PROJECT, project_menu, _(
            "New Project"), self.NewProject, image="project/new.png")
        get_app().AddCommand(menuitems.ID_OPEN_PROJECT, project_menu, _(
            "Open Project"), self.OpenProject, image="project/open.png")
        get_app().AddCommand(
            menuitems.ID_CLOSE_PROJECT,
            project_menu,
            _("Close Project"),
            self.CloseProject,
            image='project/unloadproject.png',
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_CLOSE_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_SAVE_PROJECT,
            project_menu,
            _("Save Project"),
            self.SaveProject,
            image="project/save.png",
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_SAVE_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_DELETE_PROJECT,
            project_menu,
            _("Delete Project"),
            self.DeleteProject,
            image="project/trash.png",
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_DELETE_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_CLEAN_PROJECT,
            project_menu,
            _("Clean Project"),
            self.CleanProject,
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_CLEAN_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_ARCHIVE_PROJECT,
            project_menu,
            _("Archive Project"),
            self.ArchiveProject,
            image="project/archive.png",
            add_separator=True,
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_ARCHIVE_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_IMPORT_FILES,
            project_menu,
            _("Import Files..."),
            image="project/import.png",
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_IMPORT_FILES),
            handler=lambda: self.ProcessEvent(menuitems.ID_IMPORT_FILES)
        )
        get_app().AddCommand(
            menuitems.ID_ADD_FILES_TO_PROJECT,
            project_menu,
            _("Add &Files to Project..."),
            handler=lambda: self.ProcessEvent(
                menuitems.ID_ADD_FILES_TO_PROJECT),
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_ADD_FILES_TO_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_ADD_DIR_FILES_TO_PROJECT,
            project_menu,
            _("Add Directory Files to Project..."),
            handler=lambda: self.ProcessEvent(
                menuitems.ID_ADD_DIR_FILES_TO_PROJECT),
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_ADD_DIR_FILES_TO_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_ADD_CURRENT_FILE_TO_PROJECT,
            project_menu,
            _("&Add Active File to Project..."),
            handler=lambda: self.ProcessEvent(
                menuitems.ID_ADD_CURRENT_FILE_TO_PROJECT),
            add_separator=True,
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_ADD_CURRENT_FILE_TO_PROJECT)
        )

        get_app().AddCommand(
            menuitems.ID_ADD_NEW_FILE,
            project_menu,
            _("New File"),
            image="project/new_file.png",
            handler=lambda: self.ProcessEvent(menuitems.ID_ADD_NEW_FILE),
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_ADD_NEW_FILE)
        )
        get_app().AddCommand(
            menuitems.ID_ADD_FOLDER,
            project_menu, _("New Folder"),
            image="project/folder.png",
            handler=lambda: self.ProcessEvent(menuitems.ID_ADD_FOLDER),
            add_separator=True,
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_ADD_FOLDER)
        )

        get_app().AddCommand(
            menuitems.ID_PROPERTIES,
            project_menu,
            _("Project Properties"),
            self.OnProjectProperties,
            image="project/properties.png",
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_PROPERTIES)
        )
        get_app().AddCommand(
            menuitems.ID_OPEN_FOLDER_PATH,
            project_menu,
            _("Open Project Path in Explorer"),
            handler=self.OpenProjectPath,
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_OPEN_FOLDER_PATH)
        )

    def _createdir(self):
        """Triggered when a new subdir should be created"""
        self.GetView().OnAddFolder()

    def __create_project_partlayout(self):
        """Creates the upper part of the project viewer"""
        self.project_treeview = self.GetProjectTreectrl()
        self.project_treeview.setHeaderHidden(True)
        self.project_treeview.setSelectionMode(
            QAbstractItemView.ExtendedSelection)
        self.project_treeview.doubleClicked.connect(self.on_double_click)
        self.project_treeview.expanded.connect(self.open_tree_node)
        self.project_treeview.clicked.connect(self._on_select)

        # Header part: label + i-button
        self.project_combox = QComboBox(self)
        self.project_combox.setSizePolicy(QSizePolicy.Expanding,
                                          QSizePolicy.Fixed)
        self.project_combox.currentIndexChanged.connect(self.select_project)

        self.properties_button = QToolButton(self)
        self.properties_button.setAutoRaise(True)
        self.properties_button.setIcon(load_icon("project/properties.png"))
        self.properties_button.setFixedSize(self.project_combox.height(),
                                            self.project_combox.height())
        self.properties_button.setToolTip(_('Project properties'))
        self.properties_button.setEnabled(False)
        self.properties_button.setFocusPolicy(Qt.NoFocus)
        self.properties_button.clicked.connect(self.projectProperties)

        self.unload_button = QToolButton(self)
        self.unload_button.setAutoRaise(True)
        self.unload_button.setIcon(load_icon('project/unloadproject.png'))
        self.unload_button.setFixedSize(self.project_combox.height(),
                                        self.project_combox.height())
        self.unload_button.setToolTip(_('Unload project'))
        self.unload_button.setEnabled(False)
        self.unload_button.setFocusPolicy(Qt.NoFocus)
        self.unload_button.clicked.connect(self.unloadProject)

        self.prjheader_toolbar = QToolBar(self)
        self.prjheader_toolbar.setIconSize(QSize(18, 18))
        self.prjheader_toolbar.setContentsMargins(1, 1, 1, 1)
        self.prjheader_toolbar.addWidget(self.unload_button)
        self.prjheader_toolbar.addWidget(self.project_combox)
        self.prjheader_toolbar.addWidget(self.properties_button)

        # Toolbar part - buttons
        self.__prjcollapsebutton = QAction(
            load_icon('project/collapse.png'),
            _('Collapse all'), self)
        self.__prjcollapsebutton.triggered.connect(self.__collapseall)

        self.__prjnewfilebutton = QAction(
            load_icon('project/new_file.png'), _('New project file'), self)
        self.__prjnewfilebutton.triggered.connect(self.__createfile)

        self._prjnewdirbutton = QAction(
            load_icon('project/newdir.png'), _('New project sub directory'), self)
        self._prjnewdirbutton.triggered.connect(self._createdir)

        self.__prjcopypathbutton = QAction(
            load_icon('project/copypath.png'), _('Copy path to clipboard'), self)
        self.__prjcopypathbutton.triggered.connect(
            self.copyToClipboard)

        self.__fsreloadbutton = QAction(load_icon('project/reload.png'),
                                        _('Re-read project file system tree'), self)
        self.__fsreloadbutton.triggered.connect(self.reload)

        self.upper_toolbar = QToolBar()
        self.upper_toolbar.setMovable(False)
        self.upper_toolbar.setAllowedAreas(Qt.TopToolBarArea)
        self.upper_toolbar.setIconSize(QSize(16, 16))
        self.upper_toolbar.setContentsMargins(0, 0, 0, 0)
        self.upper_toolbar.addAction(self.__prjcollapsebutton)
        self.upper_toolbar.addAction(self.__prjnewfilebutton)
        self.upper_toolbar.addAction(self._prjnewdirbutton)
        self.upper_toolbar.addAction(self.__prjcopypathbutton)
        # 工具栏拉伸控件,可以挤压其他控件
        # 将刷新按钮挤压到最右边
        self.upper_toolbar.addWidget(ToolBarExpandingSpacer(self))
        self.upper_toolbar.addAction(self.__fsreloadbutton)

        self.project_treeview.sigFirstSelectedItem.connect(
            self.__prjSelectionChanged)

        self.project_treeview.setContextMenuPolicy(Qt.CustomContextMenu)
        self.project_treeview.customContextMenuRequested.connect(
            self.__prjContextMenuRequested)
        playout = QVBoxLayout()
        playout.setContentsMargins(0, 0, 0, 0)
        playout.setSpacing(0)
        playout.addWidget(self.prjheader_toolbar)
        playout.addWidget(self.upper_toolbar)
        playout.addWidget(self.project_treeview)

        upper_container = QWidget()
        upper_container.setContentsMargins(0, 0, 0, 0)
        upper_container.setLayout(playout)
        return upper_container

    def __collapseall(self):
        """Triggers analysis where the highlighted item is used"""
        rootitem = self.project_treeview.GetRootItem()
        self.project_treeview.collapse(rootitem)

    def __createfile(self):
        self.GetView().OnAddNewFile()

    def __prjSelectionChanged(self, index):
        """Handles the changed selection in the project browser"""
        if index.isValid():
            self.prjContextItem = self.project_treeview.model().item(index)
        else:
            self.prjContextItem = None
       # self.__updatePrjToolbarButtons()

    def __updatePrjToolbarButtons(self):
        """Updates the toolbar buttons depending on the prjContextItem"""
        if self.GetCurrentProject() is None:
            self.__prjcollapsebutton.setEnabled(False)
            self.__prjnewfilebutton.setEnabled(False)
            self._prjnewdirbutton.setEnabled(False)
            self.__prjcopypathbutton.setEnabled(False)
            self.__fsreloadbutton.setEnabled(False)
        else:
            self.__prjcollapsebutton.setEnabled(True)
            self.__prjnewfilebutton.setEnabled(True)
            self._prjnewdirbutton.setEnabled(True)
            self.__prjcopypathbutton.setEnabled(True)
            self.__fsreloadbutton.setEnabled(True)

    def __prjContextMenuRequested(self, coord):
        """Triggered before the project context menu is shown"""
        index = self.project_treeview.indexAt(coord)
        if not index.isValid():
            return

        # This will update the prjContextItem
        self.__prjSelectionChanged(index)
        if self.prjContextItem is None:
            return
        self.ActivateView()
        if self.prjContextItem.itemType == treeitems.ProjectRootType:
            self.popup_project_menu()
        elif self.prjContextItem.itemType == treeitems.FileItemType:
            self.popup_file_menu()
        elif self.prjContextItem.itemType == treeitems.FolderItemType:
            self.popup_folder_menu()
