# -*- coding: utf-8 -*-
from bz2 import BZ2File
import xml.etree.ElementTree as ET
import os
from ... import get_app, _
from ...lib.locale import Locale
from ... import qtimage
from ...util import ui_utils, appdirs, utils, apputils, fileutils
from ...syntax.syntax import SyntaxThemeManager
from ...lib.pyqt import (
    QHBoxLayout,
    QPushButton,
    QLabel,
    QMessageBox,
    QVBoxLayout,
    QSize,
    Qt,
    QListView,
    QLineEdit,
    QSizePolicy,
    QListWidgetItem,
    QListWidget,
    QTreeWidget,
    QTreeWidgetItem
)
from ... import constants, globalkeys
from ...common import compat
from ...widgets.imagebutton import ImageButton
from .filetemplate import FiletemplateDialog


class NewFileDialog(ui_utils.BaseModalDialog):
    # 以大图标排列
    LIST_ICON_LARGE = 1
    # 大图标大小为32像素
    LARGE_ICON_SIZE = 32
    # 以小图标排列
    LIST_ICON_SMALL = 2
    # 小图标大小为16像素
    SMALL_ICON_SIZE = 16

    def __init__(self, parent, title, folderPath):
        super().__init__(title, parent)
        self.setFixedSize(500, 300)
        top_box = QHBoxLayout()
        left_box = QVBoxLayout()
        type_label = QLabel(_('Category') + ":")
        type_label.setFixedHeight(NewFileDialog.SMALL_ICON_SIZE)
        left_box.addWidget(type_label)
        self.tree = QTreeWidget()
        self.tree.setFixedWidth(130)
        self.rootitem = self.tree.invisibleRootItem()
        self.current_item = None
        self.file_templates = []
        # 不显示表头
        self.tree.setHeaderHidden(True)
        left_box.addWidget(self.tree)
        top_box.addLayout(left_box)

        right_box = QVBoxLayout()
        hbox = QHBoxLayout()
        template_label = QLabel(_('Template') + ":")
        template_label.setAlignment(Qt.AlignTop)
        hbox.addWidget(template_label)

        app_image_path = appdirs.get_app_image_location()
        large_view_image_path = os.path.join(
            app_image_path, "project/ViewLarge.png")

        self._largeview_btn = ImageButton(_("Listed as large icon"), self)
        self._largeview_btn.setCheckable(True)
        self._largeview_btn.setChecked(True)
        # 默认以大图标排列
        self._list_icon_mode = self.LIST_ICON_LARGE
        self._largeview_btn.toggled.connect(self.toogle_largeicon_view)
        self._largeview_btn.setIcon(qtimage.load_icon(large_view_image_path))
        hbox.addWidget(self._largeview_btn)

        small_view_image_path = os.path.join(
            app_image_path, "project/ViewSmall.png")
        self._smallview_btn = ImageButton(_("Listed as samll icon"), self)
        self._smallview_btn.setCheckable(True)
        self._smallview_btn.setChecked(False)
        self._smallview_btn.toggled.connect(self.toogle_smallicon_view)
        self._smallview_btn.setIcon(qtimage.load_icon(small_view_image_path))
        hbox.addWidget(self._smallview_btn)

        right_box.addLayout(hbox)
        right_box.setSpacing(0)
        self.list = QListWidget()
        self.list.itemSelectionChanged.connect(self.update_file_name)
        # 双击创建文件
        self.list.doubleClicked.connect(self._ok)
        # 设置单个Icon大小
        self.list.setIconSize(
            QSize(self.LARGE_ICON_SIZE, self.LARGE_ICON_SIZE))
        # 设置显示模式,分为图标模式和列表模式,这里使用图标模式
        self.list.setViewMode(QListView.IconMode)
        # 从左到右排列图标
        self.list.setFlow(QListView.LeftToRight)
        # 大小自适应
        self.list.setResizeMode(QListView.Adjust)
        # 设置列表每一项不可移动
        self.list.setMovement(QListView.Static)
        right_box.addWidget(self.list)
        top_box.addLayout(right_box)
        self.layout.addLayout(top_box)
        current_project_document = get_app().MainFrame.projectview.GetCurrentProject()
        project_path = os.path.dirname(current_project_document.GetFilename())
        self.dest_path = project_path
        if folderPath != "":
            self.dest_path = os.path.join(self.dest_path, folderPath)
        if apputils.is_windows():
            self.dest_path = self.dest_path.replace("/", os.sep)

        name_box = QHBoxLayout()
        name_box.addWidget(QLabel(_('Filename:')))
        self.name_entry = QLineEdit()
        self.name_entry.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        name_box.addWidget(self.name_entry)
        self.layout.addLayout(name_box)

        button_layout = QHBoxLayout()
        buttonbox = self.create_standard_buttons_box()
        edit_btn = QPushButton(_("&Edit template"))
        edit_btn.clicked.connect(self.edit_template)
        button_layout.addWidget(edit_btn)
        button_layout.addWidget(buttonbox)
        self.layout.addLayout(button_layout)
        self.ok_button.setText(_("&Create"))
        self.tree.itemSelectionChanged.connect(self.LoadFileTemplate)
        self.load_file_templates()
        self.load_templates()
        self.update_file_name()

    def edit_template(self):
        dlg = FiletemplateDialog(self, _("File Template"), self.file_templates)
        if dlg.exec_() == FiletemplateDialog.Accepted:
            self.reload_templates()

    def toogle_largeicon_view(self):
        if self._largeview_btn.isChecked():
            self._smallview_btn.setChecked(False)
            self._list_icon_mode = self.LIST_ICON_LARGE
            self.list.setIconSize(
                QSize(self.LARGE_ICON_SIZE, self.LARGE_ICON_SIZE))
        else:
            self._smallview_btn.setChecked(True)
            self._list_icon_mode = self.LIST_ICON_SMALL
            self.list.setIconSize(
                QSize(self.SMALL_ICON_SIZE, self.SMALL_ICON_SIZE))
        self.LoadFileTemplate()

    def toogle_smallicon_view(self):
        if self._smallview_btn.isChecked():
            self._list_icon_mode = self.LIST_ICON_SMALL
            self._largeview_btn.setChecked(False)
            self.list.setIconSize(QSize(16, 16))
        else:
            self._largeview_btn.setChecked(True)
            self._list_icon_mode = self.LIST_ICON_LARGE
            self.list.setIconSize(QSize(32, 32))
        self.LoadFileTemplate()

    def GetTemplate(self, name):
        for file_template in self.file_templates:
            if name == file_template['Name']:
                return file_template
        return None

    def update_file_name(self):
        item = self.list.currentItem()
        if item is None:
            self.ok_button.setEnabled(False)
            self.name_entry.setEnabled(False)
        else:
            self.ok_button.setEnabled(True)
            self.name_entry.setEnabled(True)
            template = item.data(Qt.UserRole)
            self.name_entry.setText(template.get('DefaultName', ''))

    def _ok(self, event=None):
        item = self.list.currentItem()
        if item is None:
            QMessageBox.information(
                self, get_app().GetAppName(), _("You don't select any item"))
            return
        file_template = item.data(Qt.UserRole)
        default_name = file_template.get('DefaultName', '')
        entry_file_name = self.name_entry.text().strip()
        file_name = entry_file_name
        if not file_name:
            file_name = default_name
        if not file_name:
            file_name = _("Untitled") + file_template.get('Ext')
        content = file_template['Content'].strip()
        root_data_path = appdirs.get_app_data_location()
        content_zip_path = fileutils.opj(os.path.join(root_data_path, content))
        if not os.path.exists(content_zip_path):
            content_zip_path = fileutils.opj(
                os.path.join(appdirs.get_user_data_path(), content))
        if entry_file_name and entry_file_name != default_name:
            self.file_path = os.path.join(self.dest_path, file_name)
        else:
            name, ext = os.path.splitext(file_name)
            i = 0
            while True:
                if i > 0:
                    file_name = "%s%d%s" % (name, i, ext)
                else:
                    file_name = "%s%s" % (name, ext)
                self.file_path = os.path.join(self.dest_path, file_name)
                if not os.path.exists(self.file_path):
                    break
                i += 1
        try:
            with open(self.file_path, "w") as fp:
                try:
                    with BZ2File(content_zip_path, "r") as f:
                        for i, line in enumerate(f):
                            if i == 0:
                                continue
                            line = compat.ensure_string(line)
                            fp.write(line.strip('\0').strip('\r').strip('\n'))
                            fp.write('\n')
                except Exception as e:
                    utils.get_logger().exception('')
                    QMessageBox.critical(self, get_app().GetAppName(), _(
                        "Load File Template Content Error.%s") % e)
                    return
        except Exception as e:
            QMessageBox.critical(self, get_app().GetAppName(),
                                 _("New File Error.%s") % e)
            return
        super()._ok()

    def GetFileTypeTemplate(self, node):
        file_type = {}
        root_image_path = appdirs.get_app_image_location()
        for item in node:
            if item.tag == "Icon":
                try:
                    small_path = item.get('Small', "")
                    if os.path.isabs(small_path):
                        small_icon_path = small_path
                    else:
                        small_icon_path = os.path.join(
                            root_image_path, small_path)
                    file_type['SmallIconPath'] = small_icon_path
                    if not os.path.exists(small_icon_path):
                        small_icon_path = os.path.join(
                            root_image_path, "project/template/default-small.bmp")
                    file_type['small_icon'] = qtimage.load_icon(
                        small_icon_path)
                    large_path = item.get('Large', "")
                    if os.path.isabs(large_path):
                        large_icon_path = large_path
                    else:
                        large_icon_path = os.path.join(
                            root_image_path, large_path)
                    file_type['LargeIconPath'] = large_icon_path
                    if not os.path.exists(large_icon_path):
                        large_icon_path = os.path.join(
                            root_image_path, "project/template/default.bmp")
                    file_type['large_icon'] = qtimage.load_icon(
                        large_icon_path)
                except Exception as e:
                    utils.get_logger().exception('load file template error:')
                    continue
            else:
                file_type[item.tag] = item.text
        return file_type

    def LoadFileTemplate(self):
        self.list.clear()
        nodes = self.tree.selectedItems()
        if not nodes or 0 == self.rootitem.childCount():
            return
        sel = nodes[0]
        templates = sel.data(0, Qt.UserRole)
        for template in templates:
            item = QListWidgetItem(template.get('Name', ""))
            if self._list_icon_mode == self.LIST_ICON_LARGE:
                item.setIcon(template.get('large_icon'))
            else:
                item.setIcon(template.get('small_icon'))
            item.setData(Qt.UserRole, template)
            # 设置文字对齐方式：水平居中
            item.setTextAlignment(Qt.AlignHCenter)
            self.list.addItem(item)
        self.update_file_name()

    def load_file_templates(self):
        user_template_path = os.path.join(appdirs.get_user_data_path(
        ), constants.USER_CACHE_DIR, constants.TEMPLATE_FILE_NAME)
        sys_template_path = os.path.join(
            appdirs.get_app_path(), constants.TEMPLATE_FILE_NAME)
        if os.path.exists(user_template_path):
            file_template_path = user_template_path
        elif os.path.exists(sys_template_path):
            file_template_path = sys_template_path
        else:
            return
        self.load_file_template(file_template_path)
        # if load template fail,load template from default path
        if 0 == len(self.file_templates):
            self.load_file_template(sys_template_path)

    def load_file_template(self, file_template_path):
        utils.get_logger().debug('file template path is:%s', file_template_path)
        try:
            tree = ET.parse(file_template_path)
            doc = tree.getroot()
        except Exception as e:
            messagebox.showerror(GetApp().GetAppName(), _(
                "Load Template File Error.%s") % e)
            return
        langid = utils.profile_get_int(globalkeys.LANGUANGE_ID_KEY, -1)
        if langid != -1:
            lang = Locale(langid).GetLanguageCanonicalName()
        else:
            lang = "en_US"
        self.LoadLangTemplate(doc, lang)
        # 如果未找到该语言对应的模板,默认加载英语模板
        if 0 == len(self.file_templates):
            self.LoadLangTemplate(doc, "en_US")

    def LoadLangTemplate(self, doc, lang):
        for element in doc:
            if element.tag == lang:
                for node in element:
                    value_type = node.get('value')
                    file_types = []
                    for child in node:
                        file_type = self.GetFileTypeTemplate(child)
                        file_type.update({
                            'Category': value_type
                        })
                        if SyntaxThemeManager.manager().IsExtSupported(file_type['Ext']):
                            file_types.append(file_type)
                            self.file_templates.append(file_type)

    def load_templates(self):
        dct = {}
        for template in self.file_templates:
            template_catlog = template.get('Category')
            if template_catlog not in dct:
                dct[template_catlog] = [template]
            else:
                dct[template_catlog].append(template)
        for name, templates in dct.items():
            item = QTreeWidgetItem()
            item.setData(0, Qt.UserRole, templates)
            item.setText(0, name)
            self.rootitem.addChild(item)
            if self.current_item is None:
                self.current_item = item
        self.tree.setCurrentItem(self.current_item)

    def reload_templates(self):
        self.tree.clear()
        self.current_item = None
        self.load_templates()
