# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------------
# Name:        openwith.py
# Purpose:     文件打开方式对话框
#
# Author:      Administrator
#
# Created:     2020-03-13
# Copyright:   (c) Administrator 2020
# Licence:     <your licence>
# -------------------------------------------------------------------------------
import os
from ... import get_app, _
from ...util import ui_utils, strutils, utils
from ...lib.pyqt import (
    QRadioButton,
    QListWidgetItem,
    QListWidget,
    Qt,
    QLabel
)
from ...editor.textview import TextDocument
from ...project.document import ProjectDocument


class EditorSelectionDlg(ui_utils.BaseModalDialog):

    OPEN_WITH_PATH = 1
    OPEN_WITH_NAME = 2
    OPEN_WITH_EXTENSION = 3

    def __init__(self, parent, item_file, project_document):
        super().__init__(_("Editor Selection"), parent)
        self._item_file = item_file
        self._file_path = item_file.filePath
        self._open_with_mode = self.OPEN_WITH_PATH
        self._is_changed = False

        self.layout.addWidget(QLabel(
            _("Choose an editor you want to open") + " '%s':" % os.path.basename(self._file_path)))
        self.tree = QListWidget()
        self.layout.addWidget(self.tree)
        self.tree.itemDoubleClicked.connect(self._ok)
        self.templates = self.GetTemplates()
        document_template_name = utils.profile_get(
            project_document.GetFileKey(self._item_file, "Open"), "")
        filename = os.path.basename(self._file_path)
        if not document_template_name:
            document_template_name = utils.profile_get(
                "Open/filenames/%s" % filename, "")
            if not document_template_name:
                document_template_name = utils.profile_get(
                    "Open/extensions/%s" % strutils.get_file_extension(filename), "")
                if document_template_name:
                    self._open_with_mode = self.OPEN_WITH_EXTENSION
            else:
                self._open_with_mode = self.OPEN_WITH_NAME

        self._document_template_name = document_template_name
        for i, temp in enumerate(self.templates):
            show_name = temp.GetViewName()
            if 0 == i:
                show_name += (" (" + _("Default") + ")")
            item = QListWidgetItem(show_name)
            item.setIcon(temp.GetIcon())
            item.setData(Qt.UserRole, temp)
            self.tree.addItem(item)
            if document_template_name == temp.GetDocumentName():
                self.tree.setCurrentItem(item)
        if document_template_name == "":
            self._document_template_name = self.templates[0].GetDocumentName()
            self.tree.setCurrentItem(self.tree.item(0))

        self.val_radio_btn = QRadioButton(
            _("Use this editor for all files named") + " '%s'" % os.path.basename(self._file_path))
        self.val_radio_btn.toggled.connect(
            self.check_val_radio_btn)  # 状态发生改变信号  调用槽函数

        self.layout.addWidget(self.val_radio_btn)
        ext = strutils.get_file_extension(os.path.basename(self._file_path))
        if ext != "":
            self.ext_radio_btn = QRadioButton(
                text=_("Use it for all files with extension") + " '.%s'" % ext)
            self.ext_radio_btn.toggled.connect(self.check_ext_radio_btn)
            self.layout.addWidget(self.ext_radio_btn)

        self.create_standard_buttons()

    def check_ext_radio_btn(self, is_checked):
        if is_checked:
            self._open_with_mode = self.OPEN_WITH_EXTENSION
            self._is_changed = True

    def check_val_radio_btn(self, is_checked):
        if is_checked:
            self._open_with_mode = self.OPEN_WITH_NAME
            self._is_changed = True

    def GetTemplates(self):
        templates = []
        default_template = get_app().GetDocumentManager().FindTemplateForPath(self._file_path)
        # 默认模板不可见,使用文本模板
        if not default_template.IsVisible():
            default_template = get_app().GetDocumentManager().FindTemplateForPath("test.txt")
        for temp in get_app().GetDocumentManager().GetTemplates():
            if issubclass(temp.GetDocumentType(), ProjectDocument):
                continue
            want = False
            if temp.IsVisible() and temp.GetViewName() and temp != default_template:
                want = True
            elif not temp.IsVisible() and temp.GetDocumentType() != TextDocument:
                want = True
            if want:
                templates.append(temp)
        templates.insert(0, default_template)
        templates.append(get_app().default_project_template)
        return templates

    @property
    def Openwith(self):
        return self._open_with_mode

    def _ok(self):
        selection = self.tree.currentItem()
        if not selection:
            messagebox.showinfo(GetApp().GetAppName(), _(
                "Please choose one editor"), master=self)
            return
        self.selected_template = selection.data(Qt.UserRole)
        if not self._is_changed:
            self._is_changed = False if self._document_template_name == self.selected_template.GetDocumentName() else True
        super()._ok()
