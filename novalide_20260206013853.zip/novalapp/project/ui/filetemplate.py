import tempfile
import tarfile
import uuid
import os
from bz2 import BZ2File
import xml.etree.ElementTree as ET
from ... import _, get_app
from ...lib.locale import Locale
from ...util import (
    ui_utils,
    fileutils,
    appdirs,
    utils
)
from ...lib.pyqt import (
    QHBoxLayout,
    QLabel,
    QPushButton,
    QAbstractItemView,
    QGroupBox,
    QMessageBox,
    QVBoxLayout,
    QTableWidget,
    Qt,
    QTableWidgetItem,
    QLineEdit,
    QSizePolicy,
    QComboBox
)
from ... import qtimage, constants
from ...syntax.syntax import SyntaxThemeManager
from ...widgets.codesample import CodeSampleCtrl
from ...common import compat
from ... import globalkeys


class FiletemplateDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, title, templates):
        super().__init__(title, parent)
        self.setFixedSize(600, 500)
        columns = [_('Name'), _('Category')]
        self.lc = QTableWidget(0, len(columns), self)
        self.layout.addWidget(self.lc)
        self._templates = templates
        self.lc.itemSelectionChanged.connect(self.OnSelectTemplate)
        # 选中整行
        self.lc.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.lc.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.lc.setColumnWidth(0, 400)
        self.lc.setColumnWidth(1, 150)
        self.lc.setHorizontalHeaderLabels(columns)
        # 最后一列自动伸缩扩展
        self.lc.horizontalHeader().setStretchLastSection(True)
        self.lc.verticalHeader().hide()
        for file_template in self._templates[::-1]:
            insertrow = 0
            self.insert_template(
                file_template.get('Name', ''),
                file_template.get('Category', ''),
                file_template,
                insertrow
            )

        button_box = QHBoxLayout()
        button_box.setAlignment(Qt.AlignCenter)

        new_btn = QPushButton(_("New"))
        new_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        new_btn.clicked.connect(self.NewItem)
        new_btn.setIcon(qtimage.load_icon("project/template/add.ico"))
        button_box.addWidget(new_btn)

        self.delete_btn = QPushButton(_("Delete"))
        self.delete_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.delete_btn.clicked.connect(self.DeleteItem)
        self.delete_btn.setIcon(qtimage.load_icon(
            "project/template/delete.ico"))
        button_box.addWidget(self.delete_btn)

        self.up_btn = QPushButton(_("Up"))
        self.up_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.up_btn.clicked.connect(self.UpItem)
        self.up_btn.setIcon(qtimage.load_icon("project/template/up.ico"))
        button_box.addWidget(self.up_btn)

        self.down_btn = QPushButton(_("Down"))
        self.down_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.down_btn.clicked.connect(self.DownItem)
        self.down_btn.setIcon(qtimage.load_icon("project/template/down.ico"))
        button_box.addWidget(self.down_btn)

        self.refresh_btn = QPushButton(_("Refresh"))
        self.refresh_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.refresh_btn.clicked.connect(self.RefreshItem)
        self.refresh_btn.setIcon(qtimage.load_icon(
            "project/template/refresh.ico"))
        button_box.addWidget(self.refresh_btn)
        self.layout.addLayout(button_box)
        group_box = QGroupBox(_("Template property"))
        sbox_sizer = QVBoxLayout()
        group_box.setLayout(sbox_sizer)
        topsizer = QHBoxLayout()

        left_sizer = QVBoxLayout()
        linesizer = QHBoxLayout()
        linesizer.addWidget(QLabel(_("Name") + ":"))
        self.name_ctrl = QLineEdit()
        linesizer.addWidget(self.name_ctrl)
        left_sizer.addLayout(linesizer)

        linesizer = QHBoxLayout()
        linesizer.addWidget(QLabel(_("Default Extension") + ":"))
        self.ext_ctrl = QLineEdit()
        linesizer.addWidget(self.ext_ctrl)
        left_sizer.addLayout(linesizer)

        topsizer.addLayout(left_sizer)

        right_sizer = QVBoxLayout()
        linesizer = QHBoxLayout()
        linesizer.addWidget(QLabel(_("Category") + ":"))
        self.category_ctrl = QLineEdit()
        linesizer.addWidget(self.category_ctrl)
        right_sizer.addLayout(linesizer)

        linesizer = QHBoxLayout()
        linesizer.addWidget(QLabel(_("Syntax Highlight") + ":"))
        self._syntax_combo = QComboBox()
        self._syntax_combo.addItems(
            SyntaxThemeManager.manager().GetShowNameList())
        linesizer.addWidget(self._syntax_combo)
        right_sizer.addLayout(linesizer)

        topsizer.addLayout(right_sizer)
        sbox_sizer.addLayout(topsizer)
        sbox_sizer.addWidget(QLabel(_("Template Content") + ":"))

        self.template_code_ctrl = CodeSampleCtrl(self)
        self.template_code_ctrl.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Expanding)
        sbox_sizer.addWidget(self.template_code_ctrl)

        self.layout.addWidget(group_box)
        self.create_standard_buttons()
        # 选择第一行
        self.lc.selectRow(0)
        self.UpdateUI()

    def insert_template(self, name, category, data, insertrow=0):
        self.lc.insertRow(insertrow)
        nameitem = QTableWidgetItem(name)
        self.lc.setItem(insertrow, 0, nameitem)
        versionitem = QTableWidgetItem(category)
        self.lc.setItem(insertrow, 1, versionitem)
        nameitem.setData(Qt.UserRole, data)

    def UpdateUI(self):
        select_row = self.lc.currentRow()
        if select_row == -1:
            self.delete_btn.setEnabled(False)
            self.down_btn.setEnabled(False)
            self.up_btn.setEnabled(False)
            self.refresh_btn.setEnabled(False)
        else:
            self.delete_btn.setEnabled(True)
            if 0 == select_row:
                self.up_btn.setEnabled(False)
            else:
                self.up_btn.setEnabled(True)
            if self.lc.rowCount() - 1 == select_row:
                self.down_btn.setEnabled(False)
            else:
                self.down_btn.setEnabled(True)
            self.refresh_btn.setEnabled(True)

    def NewItem(self, event):
        name = self.name_ctrl.text().strip()
        if name == "":
            QMessageBox.information(
                self, get_app().GetAppName(), _("template name is empty"))
            return
        if self.IsTemplateNameExist(name):
            QMessageBox.information(self, get_app().GetAppName(), _(
                "template name '%s' already exist") % name)
            return
        category = self.category_ctrl.text().strip()
        if category == "":
            QMessageBox.information(
                self, get_app().GetAppName(), _("category is empty"))
            return
        ext = self.ext_ctrl.text()
        if not ext.startswith("."):
            ext = "." + ext
        code_sample_text = self.template_code_ctrl.text()
        try:
            user_template_path = os.path.join(
                appdirs.get_user_data_path(), constants.USER_CACHE_DIR, "template")
            fileutils.makedirs(user_template_path)
            template_file_path = os.path.join(
                user_template_path, str(uuid.uuid1()) + ".tar.bz2")
            archive = tarfile.open(template_file_path, 'w:bz2')
            # windows下生成的tar包包含@PaxHeader 文件,,必须切换为linux下的打包格式
            # 设置为linux打包格式
            archive.format = tarfile.GNU_FORMAT
            fd, newfname = tempfile.mkstemp(suffix=ext, text=True)
            with open(newfname, 'w') as f:
                # 必须先写入一个空行,保证模板文件第一行是空行,第一行不会作为文件内容显示
                f.write("\n")
                f.write(code_sample_text)
            # d:\myfiles contains the files to compress
            archive.add(newfname, arcname=os.path.basename(newfname))
            archive.close()
            content = template_file_path.replace(
                appdirs.get_app_path(), "").strip().lstrip(os.sep)
            template = {
                'Ext': ext,
                'Name': name,
                'Category': category,
                'Content': content,
                'DefaultName': 'Untitle' + ext
            }
            i = self.lc.rowCount()
            self.insert_template(name, category, template, i)
            self.lc.selectRow(i)
        except IOError as ex:
            QMessageBox.critical(self, _("Error"), str(ex))
        self.UpdateUI()

    def _ok(self):

        def CreateDataElement(parent, name, data):
            data_el = ET.SubElement(parent, name)
            data_el.text = data.get(name)

        def CreateIconDataElement(parent, name, data):
            data_el = ET.SubElement(parent, name)
            data_el.text = data.get(name)
            root_image_path = appdirs.get_app_image_location()
            default_large_icon_path = os.path.join(
                root_image_path, "project/template/default.bmp")
            data_el.attrib['Large'] = data.get(
                'LargeIconPath', default_large_icon_path)
            default_small_icon_path = os.path.join(
                root_image_path, "project/template/default-small.bmp")
            data_el.attrib['Small'] = data.get(
                'SmallIconPath', default_small_icon_path)
            if data.get('large_icon', None) is None:
                data['large_icon'] = qtimage.load_icon(default_large_icon_path)
            if data.get('small_icon', None) is None:
                data['small_icon'] = qtimage.load_icon(default_small_icon_path)

        root = ET.Element('FileType')
        lang_id = utils.profile_get_int(
            globalkeys.LANGUANGE_ID_KEY, utils.get_lang_config())
        lang_el = ET.SubElement(root, Locale(
            lang_id).GetLanguageCanonicalName())
        elments = {}
        self._templates.clear()
        for row in range(self.lc.rowCount()):
            item = self.lc.item(row, 0)
            template = item.data(Qt.UserRole)
            self._templates.append(template)
            catlog = template.get('Category')
            if catlog not in elments:
                template_el = ET.SubElement(lang_el, 'TemplateData')
                template_el.attrib['value'] = catlog
                elments[catlog] = template_el
            else:
                template_el = elments[catlog]
            data_el = ET.SubElement(template_el, 'Template')
            CreateDataElement(data_el, 'Ext', template)
            CreateDataElement(data_el, 'Name', template)
            CreateDataElement(data_el, 'Content', template)
            CreateDataElement(data_el, 'DefaultName', template)
            CreateIconDataElement(data_el, 'Icon', template)
        tree = ET.ElementTree(root)
        user_template_path = os.path.join(
            appdirs.get_user_data_path(),
            constants.USER_CACHE_DIR,
            constants.TEMPLATE_FILE_NAME
        )
        tree.write(user_template_path, encoding='utf-8')
        super()._ok()

    def IsTemplateNameExist(self, name):
        for file_template in self._templates:
            template_name = file_template.get('Name', '')
            if template_name.lower() == name.lower():
                return True
        return False

    def DeleteItem(self, event):
        select_row = self.lc.currentRow()
        self.lc.removeRow(select_row)
        self.UpdateUI()

    def UpItem(self, event):
        select_index = self.lc.currentRow()
        prev_item_index = select_index - 1
        tmp_template = self.lc.item(prev_item_index, 0).data(Qt.UserRole)
        self.lc.removeRow(prev_item_index)
        self.insert_template(tmp_template.get('Name', ''), tmp_template.get(
            'Category', ''), tmp_template, select_index)
        self.UpdateUI()

    def DownItem(self, event):
        select_index = self.lc.currentRow()
        next_item_index = select_index + 1
        tmp_template = self.lc.item(next_item_index, 0).data(Qt.UserRole)
        self.lc.removeRow(next_item_index)
        self.insert_template(tmp_template.get('Name', ''), tmp_template.get(
            'Category', ''), tmp_template, select_index)
        self.UpdateUI()

    def RefreshItem(self, event):
        self.OnSelectTemplate()

    def OnUnSelectTemplate(self, event):
        self.UpdateUI()

    def OnSelectTemplate(self):
        index = self.lc.currentRow()
        nameitem = self.lc.item(index, 0)
        template = nameitem.data(Qt.UserRole)
        self.name_ctrl.setText(template.get('Name', ''))
        self.category_ctrl.setText(template.get('Category', ''))
        ext = template.get('Ext', '')
        self.ext_ctrl.setText(ext)
        syntax_manager = SyntaxThemeManager.manager()
        lang_lexer = syntax_manager.GetLangLexerFromExt(ext)

        name_list = syntax_manager.GetShowNameList()
        self._syntax_combo.setCurrentIndex(
            name_list.index(lang_lexer.GetShowName()))
        content = template['Content'].strip()
        content_zip_path = fileutils.opj(
            os.path.join(appdirs.get_app_path(), content))
        if not os.path.exists(content_zip_path):
            content_zip_path = fileutils.opj(os.path.join(
                appdirs.get_app_data_location(), content))
        self.UpdateUI()
        content = ""
        try:
            with BZ2File(content_zip_path, "r") as f:
                for i, line in enumerate(f):
                    if i == 0:
                        continue
                    line = compat.ensure_string(line)
                    content += line.strip('\0').strip('\r').strip('\n')
                    content += '\n'
        except Exception as e:
            QMessageBox.critical(self, _('Error'), _(
                "Load File Template Content Error.%s") % e)
            return
        self.template_code_ctrl.set_lang_lexer(lang_lexer.GetLangId())
        self.template_code_ctrl.setText(content)

    def shouldAcceptFocus(self):
        return True
