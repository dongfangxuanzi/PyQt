# -*- coding: utf-8 -*-
from ... import get_app, _
from ...util import ui_utils, utils
from ...lib.pyqt import QListWidgetItem, QHBoxLayout, QListWidget, Qt
# import noval.util.apputils as apputils
# import noval.util.fileutils as fileutils
# import noval.project.resource as proejctresource
# import noval.consts as consts
# import noval.ui_base as ui_base

RESOURCE_ITEM_NAME = _("Resource")

PROJECT_PROPERTY = 'root'
FILE_PROPERTY = 'file'
FOLDER_PROPERTY = 'folder'


class PropertyDialog(ui_utils.BaseModalDialog):
    """
    A default options dialog used by the OptionsService that hosts a notebook
    tab of options panels.
    """
    PROPERTY_DLG_WIDITH = 700
    PROPERTY_DLG_HEIGHT = 500

    def __init__(self, master, title, selected_item, option_pages, option_name=None):  # item_type
        """
        Initializes the options dialog with a notebook page that contains new
        instances of the passed optionsPanelClasses.
        """
        super().__init__(title, master)
        self.setFixedSize(self.PROPERTY_DLG_WIDITH, self.PROPERTY_DLG_HEIGHT)
        self._options_panels = {}
        self.current_panel = None
        self.current_item = None
        self._selected_project_item = selected_item

        self.topbox = QHBoxLayout()
        # 设置path列存储模板路径,并隐藏改列
        self.tree = QListWidget()
        self.tree.setFixedWidth(150)
        self.topbox.addWidget(self.tree)
        self.tree.itemSelectionChanged.connect(self.DoSelection)
        current_project_document = get_app().MainFrame.projectview.GetCurrentProject()
        self._current_project_document = current_project_document
        # 用户选中的项目节点的类型,文件,文件夹还是项目根节点
        self.property_item_type = None
        # force select one option
        if option_name:
            selection = option_name
        else:
            selection = utils.profile_get(
                current_project_document.GetKey("Selection"), "")
        for name, node_item_type, options_panel_class in option_pages:
            self.property_item_type = node_item_type
            item = self.add_panel_item(name, options_panel_class)
            # select the default item,to avoid select no item
            if name == RESOURCE_ITEM_NAME:
                self.tree.setCurrentItem(item)
            if name == selection:
                self.tree.setCurrentItem(item)
        self.layout.addLayout(self.topbox)
        self.create_standard_buttons()
        # 通过发送弹出项目属性对话框的消息以便接收者动态添加属性页面
        get_app().MainFrame.SIG_SHOW_PROPERTY_DIALOG.emit(self, self.property_item_type)

    def add_panel_item(self, name, options_panel_class):
        item = QListWidgetItem(_(name))
        self.tree.addItem(item)
        option_panel = options_panel_class(
            self,
            item=self._selected_project_item,
            current_project=self._current_project_document
        )
        item.setData(Qt.UserRole, option_panel)
        self._options_panels[name] = option_panel
        return item

    @property
    def CurrentProject(self):
        return self._current_project_document

    def DoSelection(self):
        sel = self.tree.currentItem()
        panel = sel.data(Qt.UserRole)
        if self.current_item is not None and sel != self.current_item:
            if not self.current_panel.Validate():
                self.tree.SelectItem(self.current_item)
                return
        if self.current_panel is not None and panel != self.current_panel:
            self.current_panel.setVisible(False)
            self.topbox.removeWidget(self.current_panel)
        self.current_panel = panel
        self.current_panel.setVisible(True)
        self.topbox.addWidget(self.current_panel)

    def _ok(self):
        """
        Calls the OnOK method of all of the OptionDialog's embedded panels
        """
        if not self.current_panel.Validate():
            return
        for name in self._options_panels:
            options_panel = self._options_panels[name]
            # 如果配置页面被禁止了,不能调用ok方法
            if not options_panel.IsDisabled() and not options_panel.OnOK(self):
                return
        selection = self.tree.currentItem()
        if selection:
            text = selection.text()
            if self._current_project_document is not None:
                utils.profile_set(
                    self._current_project_document.GetKey("Selection"), text)
        super()._ok()

    def GetOptionPanel(self, option_name):
        return self._options_panels[option_name]

    def HasPanel(self, option_name):
        return option_name in self._options_panels
