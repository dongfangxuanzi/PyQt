DEFAULT_PLUGINS = (
    "novalapp.plugins.printer.FileprinterPluginLoader",
    "novalapp.plugins.about.AboutLoader",
    "novalapp.plugins.update.UpdateLoader",
    "novalapp.plugin.gui.PluginManagerGUI",
    "novalapp.plugins.windowservice.WindowServiceLoader",
    "novalapp.plugins.mdviewer.mdloader.MarkdownLoader",
    "novalapp.plugins.external_tools.ExternalToolsLoader",
    "novalapp.plugins.ziploader.ZipLoaderPlugin",
    "novalapp.plugins.outputview.OutputViewPlugin"
    #  "novalapp.plugins.terminator.terminal.PseudoterminalLoader"
)
