# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2016  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

#
# The file was taken from eric 4.4.3 and adopted for codimension.
# Original copyright:
# Copyright (c) 2007 - 2010 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""Sidebar implementation"""

from ..lib.pyqt import (QEvent, QSize, Qt, QTabBar, QWidget, QStackedWidget,
                        QBoxLayout, pyqtSignal)


class SideBar(QWidget):

    """Sidebar with a widget area which is hidden or shown.

    On by clicking any tab, off by clicking the current tab.
    """

    North = 0
    East = 1
    South = 2
    West = 3

    sigTabCloseRequested = pyqtSignal(int)

    def __init__(self, orientation, parent=None):
        QWidget.__init__(self, parent)

        self.__tabbar = QTabBar()
        self.__tabbar.setDrawBase(True)
        self.__tabbar.setFocusPolicy(Qt.NoFocus)
        self.__tabbar.setUsesScrollButtons(True)
        self.__tabbar.setElideMode(1)
        self.__tabbar.tabCloseRequested.connect(self.__onCloseRequest)
        self.__stackedwidget = QStackedWidget(self)
        self.__stackedwidget.setContentsMargins(0, 0, 0, 0)
        self.barlayout = QBoxLayout(QBoxLayout.LeftToRight)
        self.barlayout.setContentsMargins(0, 0, 0, 0)
        self.layout = QBoxLayout(QBoxLayout.TopToBottom)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        self.barlayout.addWidget(self.__tabbar)
        self.layout.addLayout(self.barlayout)
        self.layout.addWidget(self.__stackedwidget)
        self.setLayout(self.layout)

        self.__minimized = False
        self.__minsize = 0
        self.__maxsize = 0
        self.__bigsize = QSize()
        self.splitter = None
        self.__tabbar.installEventFilter(self)
        self.__orientation = orientation
        self.setOrientation(orientation)

        self.__tabbar.currentChanged.connect(
            self.__stackedwidget.setCurrentIndex)

    def setSplitter(self, splitter):
        """Set the splitter managing the sidebar"""
        self.splitter = splitter

    def __getIndex(self):
        """Provides the widget index in splitters"""
        if self.__orientation == SideBar.West:
            return 0
        if self.__orientation == SideBar.East:
            return 2
        if self.__orientation == SideBar.South:
            return 1
        return 0

    def shrink(self):
        """Shrink the sidebar"""
        if self.__minimized:
            return

        self.__minimized = True
        self.__bigsize = self.size()
        if self.__orientation in [SideBar.North, SideBar.South]:
            self.__minsize = self.minimumHeight()
            self.__maxsize = self.maximumHeight()
        else:
            self.__minsize = self.minimumWidth()
            self.__maxsize = self.maximumWidth()

        self.__stackedwidget.hide()

        sizes = self.splitter.sizes()
        self_index = self.__getIndex()
        if self.__orientation in [SideBar.North, SideBar.South]:
            new_height = self.__tabbar.minimumSizeHint().height()
            self.setFixedHeight(new_height)
            diff = sizes[self_index] - new_height
            sizes[self_index] = new_height
        else:
            new_width = self.__tabbar.minimumSizeHint().width()
            self.setFixedWidth(new_width)
            diff = sizes[self_index] - new_width
            sizes[self_index] = new_width

        if self_index == 0:
            sizes[1] += diff
        else:
            sizes[self_index - 1] += diff

        self.splitter.setSizes(sizes)

    def expand(self):
        """Expand the sidebar"""
        if not self.__minimized:
            return

        self.__minimized = False
        self.__stackedwidget.show()
        self.resize(self.__bigsize)

        sizes = self.splitter.sizes()
        self_index = self.__getIndex()

        if self.__orientation in [SideBar.North, SideBar.South]:
            self.setMinimumHeight(self.__minsize)
            self.setMaximumHeight(self.__maxsize)

            diff = self.__bigsize.height() - sizes[self_index]
            sizes[self_index] = self.__bigsize.height()
        else:
            self.setMinimumWidth(self.__minsize)
            self.setMaximumWidth(self.__maxsize)

            diff = self.__bigsize.width() - sizes[self_index]
            sizes[self_index] = self.__bigsize.width()

        if self_index == 0:
            sizes[1] -= diff
        else:
            sizes[self_index - 1] -= diff

        self.splitter.setSizes(sizes)

    def isMinimized(self):
        """Provides the minimized state"""
        return self.__minimized

    def eventFilter(self, obj, evt):
        """Handle click events for the tabbar"""
        if obj == self.__tabbar:
            if evt.type() == QEvent.MouseButtonPress:
                # 单击鼠标左键显示隐藏侧边框
                if evt.button() == Qt.LeftButton:
                    pos = evt.pos()
                    index = None
                    for index in range(self.__tabbar.count()):
                        if self.__tabbar.tabRect(index).contains(pos):
                            break
                    if index == self.__tabbar.currentIndex():
                        if self.isMinimized():
                            self.expand()
                        else:
                            self.shrink()
                        return True

                    if self.isMinimized():
                        if self.isTabEnabled(index):
                            self.expand()

        return QWidget.eventFilter(self, obj, evt)

    @staticmethod
    def __toVariant(name, priority):
        """A tab stores its name and priority"""
        if priority is None:
            return ':' + name
        return str(priority) + ':' + name

    @staticmethod
    def __fromVariant(data):
        """A tab stores its name and priority"""
        val = data.split(':')
        if val[0] == '':
            return val[1], None
        return val[1], int(val[0])

    def __appendTab(self, widget, icon, label, name, priority):
        """Appends a new widget to the end"""
        self.__tabbar.addTab(icon, label)
        self.__stackedwidget.addWidget(widget)
        self.__tabbar.setTabData(self.count - 1,
                                 self.__toVariant(name, priority))

    def __pickInsertIndex(self, priority):
        """Picks the tab insert index in accordance to the priority"""
        for index in range(self.__tabbar.count()):
            data = self.__tabbar.tabData(index)
            _, tabPriority = self.__fromVariant(data)
            if tabPriority is None:
                return index
            if priority < tabPriority:
                return index
        return None

    def addTab(self, widget, icon, label, name, priority):
        """Add a tab to the sidebar"""
        if priority is None:
            # Appending to the end
            self.__appendTab(widget, icon, label, name, priority)
        else:
            # Pick the index in accordance to the priority
            index = self.__pickInsertIndex(priority)
            if index is None:
                self.__appendTab(widget, icon, label, name, priority)
            else:
                self.__tabbar.insertTab(index, icon, label)
                self.__stackedwidget.insertWidget(index, widget)
                self.__tabbar.setTabData(index,
                                         self.__toVariant(name, priority))

    def clear(self):
        """Remove all tabs"""
        while self.count > 0:
            self.removeTab(0)

    def prevTab(self):
        """Show the previous tab"""
        index = self.currentIndex() - 1
        if index < 0:
            index = self.count - 1

        self.setCurrentIndex(index)
        self.currentWidget().setFocus()

    def nextTab(self):
        """Show the next tab"""
        index = self.currentIndex() + 1
        if index >= self.count:
            index = 0

        self.setCurrentIndex(index)
        self.currentWidget().setFocus()

    @property
    def count(self):
        """Provides the number of tabs"""
        return self.__tabbar.count()

    def currentIndex(self):
        """Provides the index of the current tab"""
        return self.__stackedwidget.currentIndex()

    def currentWidget(self):
        """Provide a reference to the current widget"""
        return self.__stackedwidget.currentWidget()

    def currentTabName(self):
        """Provides the name of the current tab"""
        return self.getTabName(self.currentIndex())

    def __getWidgetIndex(self, index_or_namewidget):
        """Provides the widget index via the provided index, name or widget"""
        if index_or_namewidget is None:
            return None
        if isinstance(index_or_namewidget, int):
            if index_or_namewidget >= self.count:
                return None
            return index_or_namewidget
        if isinstance(index_or_namewidget, str):
            for index in range(self.__tabbar.count()):
                data = self.__tabbar.tabData(index)
                tabname, _ = self.__fromVariant(data)
                if tabname == index_or_namewidget:
                    return index
            return None
        return self.__stackedwidget.indexOf(index_or_namewidget)

    def getTabName(self, index_or_widget):
        """Provides the tab name by index or widget"""
        index = self.__getWidgetIndex(index_or_widget)
        if index is not None:
            data = self.__tabbar.tabData(index)
            tabname, _ = self.__fromVariant(data)
            return tabname
        return None

    def updateTabName(self, index_or_namewidget, newname):
        """Updates the tab name"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            data = self.__tabbar.tabData(index)
            _, priority = self.__fromVariant(data)
            self.__tabbar.setTabData(index,
                                     self.__toVariant(newname, priority))

    def setCurrentTab(self, index_or_namewidget):
        """Sets the current widget approprietly"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            self.__tabbar.setCurrentIndex(index)
            self.__stackedwidget.setCurrentIndex(index)
            if self.isMinimized():
                self.expand()

    def removeTab(self, index_or_namewidget):
        """Remove a tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            self.__stackedwidget.removeWidget(
                self.__stackedwidget.widget(index))
            self.__tabbar.removeTab(index)

    def isTabEnabled(self, index_or_namewidget):
        """Check if the tab is enabled"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            return self.__tabbar.isTabEnabled(index)
        return False

    def setTabEnabled(self, index_or_namewidget, enabled):
        """Set the enabled state of the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            self.__tabbar.setTabEnabled(index, enabled)

    def orientation(self):
        """Provides the orientation of the sidebar"""
        return self.__orientation

    def setOrientation(self, orient):
        """Set the orientation of the sidebar"""
        if orient == SideBar.North:
            self.__tabbar.setShape(QTabBar.RoundedNorth)
            self.barlayout.setDirection(QBoxLayout.LeftToRight)
            self.layout.setDirection(QBoxLayout.TopToBottom)
            self.layout.setAlignment(self.barlayout, Qt.AlignLeft)
        elif orient == SideBar.East:
            self.__tabbar.setShape(QTabBar.RoundedEast)
            self.barlayout.setDirection(QBoxLayout.TopToBottom)
            self.layout.setDirection(QBoxLayout.RightToLeft)
            self.layout.setAlignment(self.barlayout, Qt.AlignTop)
        elif orient == SideBar.South:
            self.__tabbar.setShape(QTabBar.RoundedSouth)
            self.barlayout.setDirection(QBoxLayout.LeftToRight)
            self.layout.setDirection(QBoxLayout.BottomToTop)
            self.layout.setAlignment(self.barlayout, Qt.AlignLeft)
        else:
            # default
            orient = SideBar.West
            self.__tabbar.setShape(QTabBar.RoundedWest)
            self.barlayout.setDirection(QBoxLayout.TopToBottom)
            self.layout.setDirection(QBoxLayout.LeftToRight)
            self.layout.setAlignment(self.barlayout, Qt.AlignTop)
        self.__orientation = orient

    def tabIcon(self, index_or_namewidget):
        """Provide the icon of the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            return self.__tabbar.tabIcon(index)
        return None

    def setTabIcon(self, index_or_namewidget, icon):
        """Set the icon of the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            self.__tabbar.setTabIcon(index, icon)

    def tabText(self, index_or_namewidget):
        """Provide the text of the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            return self.__tabbar.tabText(index)
        return None

    def tabButton(self, index_or_namewidget, position):
        """Provide the button of the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            return self.__tabbar.tabButton(index, position)
        return None

    def setTabText(self, index_or_namewidget, text):
        """Set the text of the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            self.__tabbar.setTabText(index, text)

    def tabToolTip(self, index_or_namewidget):
        """Provide the tooltip text of the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            return self.__tabbar.tabToolTip(index)
        return None

    def setTabToolTip(self, index_or_namewidget, tip):
        """Set the tooltip text of the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            self.__tabbar.setTabToolTip(index, tip)

    def tabWhatsThis(self, index_or_namewidget):
        """Provide the WhatsThis text of the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            return self.__tabbar.tabWhatsThis(index)
        return None

    def setTabWhatsThis(self, index_or_namewidget, text):
        """Set the WhatsThis text for the tab"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            self.__tabbar.setTabWhatsThis(index, text)

    def widget(self, index_or_namewidget):
        """Provides the reference to the widget: QWidget or None"""
        index = self.__getWidgetIndex(index_or_namewidget)
        if index is not None:
            return self.__stackedwidget.widget(index)
        return None

    def setTabsClosable(self, closable):
        """Sets the tabs closable"""
        self.__tabbar.setTabsClosable(closable)

    def __onCloseRequest(self, index):
        """Re-emits the close request signal"""
        self.sigTabCloseRequested.emit(index)

    @property
    def tabbar(self):
        return self.__tabbar
