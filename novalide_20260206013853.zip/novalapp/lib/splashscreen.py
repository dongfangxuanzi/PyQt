# -*- coding: utf-8 -*-
"""Splash screen implementation"""

from ..qtimage import load_image
from .pyqt import (Qt, QColor, QApplication, QSplashScreen)


class SplashScreen(QSplashScreen):
    """Splash screen class"""

    def __init__(self, welcome_image_path):
        self.labelAlignment = Qt.Alignment(Qt.AlignBottom |
                                           Qt.AlignRight |
                                           Qt.AlignAbsolute)

        # The window flags are needed for some X Servers. E.g. Xwin-32
        # on windows draws a normal window outline if the flags are not here
        QSplashScreen.__init__(self, None, load_image(welcome_image_path),
                               Qt.SplashScreen |
                               Qt.WindowStaysOnTopHint |
                               Qt.X11BypassWindowManagerHint)

    def show(self):
        super().show()
        QApplication.flush()

    def show_message(self, msg):
        """Show the message in the bottom part of the splashscreen"""
        super().showMessage(msg,
                            self.labelAlignment, QColor(Qt.black))
        QApplication.processEvents()

    def clearMessage(self):
        """Clear the splash screen message"""
        QSplashScreen.clearMessage(self)
        QApplication.processEvents()
