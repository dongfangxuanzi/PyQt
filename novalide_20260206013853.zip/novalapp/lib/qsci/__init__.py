
from PyQt5.Qsci import (
    QsciScintilla,
    QsciLexerPython,
    QsciLexerCPP,
    QsciLexerXML,
    QsciLexerHTML,
    QsciLexerCSS,
    QsciLexerJavaScript,
    QsciLexerMarkdown,
    QsciLexerBash,
    QsciAPIs
)

# 行号页边
MARGIN_LINENUMBER_INDEX = 0
# sci控件初始化时默认显示的页边
DEFAULT_MARGIN_INDEX = 1
# 代码折叠页边
MARGIN_SCRIPT_FOLD_INDEX = 2
# 代码折叠页边宽度
MARGIN_SCRIPT_FOLD_WIDTH = 11
