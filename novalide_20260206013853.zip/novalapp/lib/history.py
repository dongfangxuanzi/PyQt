# -*- coding: utf-8 -*-
'''
Name:        history.py
Purpose:     历史文件和历史项目加载以及保存相关的模块

Author:      wukan

Created:     2024-01-22
Copyright:   (c) wukan 2024
Licence:     <your licence>
'''
import os
import sys
import logging
from .path import is_sample_path
from .hiscache import CycleCache
from . import get_app
from .defaultkeys import AppDefaultKey
logger = logging.getLogger(__name__)


class FileHistory(CycleCache):
    '''
    历史文件列表是一个循环列表,如果超过限制文件个数,会删除最后一个文件,
    新添加文件放在头部
    '''

    def __init__(self, maxFiles, idBase):
        '''
            maxFiles表示最大允许的历史文件列表个数,从注册表或配置文件中读取
        '''
        # hiscache.CycleCache.TRIM_LAST表示超过限制文件个数后,删除最后一个文件
        super().__init__(size=maxFiles, trim=CycleCache.TRIM_LAST, add=CycleCache.ADD_FIRST)
        self._filesmenu = None
        self._id_base = idBase

    @property
    def IdBase(self):
        return self._id_base

    def GetMaxFiles(self):
        return self._size

    def AddFileToHistory(self, file_path):
        # 检查文件路径是否在历史文件列表中,如果存在则删除
        index = self.GetHistoryFileIndex(file_path)
        if index != -1:
            del self._list[index]
        # 打开文件总是放在历史文件列表最前面
        self.PutPath(file_path)
        # 按照文件顺序重新构建历史文件列表菜单
        self.RebuildFilesMenu()

    def RemoveFileFromHistory(self, i):
        # 从历史文件列表中删除文件
        del self._list[i]
        # 从新构建历史文件菜单
        self.RebuildFilesMenu()

    def Load(self, config):
        index = 1
        paths = []
        while True:
            key = "%s/file%d" % (AppDefaultKey.RECENT_FILES_KEY.value, index)
            path = config.Read(key)
            if path:
                paths.append(path)
                index += 1
            else:
                break
        # 务必按照倒序加载文件列表
        for path in paths[::-1]:
            self.PutPath(path)

    def PutPath(self, path):
        if self.GetCurrentSize() >= self._size:
            logger.debug('history file list size %d is greater then max list size %d,will trim the last file item',
                         self.GetCurrentSize(), self._size)
        # 这里超过文件限制,会删除最后一个文件
        self.PutItem(path)

    def Clear(self, config):
        '''
            清空存储历史文件列表
        '''
        index = 1
        while True:
            key = "%s/file%d" % (AppDefaultKey.RECENT_FILES_KEY.value, index)
            path = config.Read(key)
            if path:
                config.DeleteEntry(key)
                index += 1
            else:
                break

    def Save(self, config):
        # 保存历史文件之前先要清空
        self.Clear(config)
        for i, item in enumerate(self._list):
            config.Write("%s/file%d" %
                         (AppDefaultKey.RECENT_FILES_KEY.value, i + 1), item)

        if sys.platform.startswith("linux"):
            config.Save()

    def UseMenu(self, menu):
        self._filesmenu = menu

    def AddFilesToMenu(self):
        if 0 == len(self._list):
            return
        assert self._filesmenu is not None
        assert len(self._list) <= self._size
        self._filesmenu.add_separator()
        # 以第一个文件(一般为新添加的文件)作为参考目录
        ref_dir = os.path.dirname(self._list[0])
        for i, item in enumerate(self._list):
            # 如果历史文件目录为参考目录,则显示短文件名
            if os.path.dirname(item) == ref_dir:
                label = "%d %s" % (i + 1, os.path.basename(item))
            # 否则显示长文件名
            else:
                label = "%d %s" % (i + 1, item)

            def load(n=i):
                self.OpenFile(n)
            get_app().AddCommand(self._id_base + i, self._filesmenu, label, handler=load)

    def RebuildFilesMenu(self):
        first_file_index = self._filesmenu.find_pos(self._id_base)
        if first_file_index != self._filesmenu.INVALID_ITEM_POS:
            # 先要删除原先的所有历史菜单项
            self._filesmenu.delete(first_file_index - 1)
        # 重新生成历史菜单项
        self.AddFilesToMenu()

    def OpenFile(self, n):
        get_app().open_mru_file(n)

    def GetHistoryFileIndex(self, path):
        for i, item in enumerate(self._list):
            if is_sample_path(item, path):
                return i
        return -1

    def GetHistoryFile(self, i):
        assert 0 <= i < len(self._list)
        return self._list[i]


class ProjectHistory(CycleCache):
    '''
        记录历史项目列表,在起始页显示
    '''

    def __init__(self, maxFiles):
        super().__init__(size=maxFiles, trim=CycleCache.TRIM_LAST, add=CycleCache.ADD_FIRST)

    def GetMaxFiles(self):
        return self._size

    def AddFileToHistory(self, file_path):
        # 检查文件路径是否在历史项目列表中,如果存在则删除
        index = self.GetHistoryFileIndex(file_path)
        if index != -1:
            del self._list[index]
        self.PutPath(file_path)

    def Load(self, config):
        index = 1
        paths = []
        while True:
            key = "%s/file%d" % (AppDefaultKey.RECENT_PROJECTS_KEY.value, index)
            path = config.Read(key)
            if path:
                paths.append(path)
                index += 1
            else:
                break
        # 务必按照倒序加载文件列表
        for path in paths[::-1]:
            self.PutPath(path)

    def PutPath(self, path):
        if self.GetCurrentSize() >= self._size:
            logger.debug('history project list size %d is greater then max list size %d,will trim the last file item',
                         self.GetCurrentSize(), self._size)
        # 这里超过文件限制,会删除最后一个文件
        self.PutItem(path)

    def Clear(self, config):
        '''
            清空存储历史项目列表
        '''
        index = 1
        while True:
            key = "%s/file%d" % (AppDefaultKey.RECENT_PROJECTS_KEY.value, index)
            path = config.Read(key)
            if path:
                config.DeleteEntry(key)
                index += 1
            else:
                break

    def Save(self, config):
        # 保存历史项目之前先要清空
        self.Clear(config)
        for i, item in enumerate(self._list):
            config.Write("%s/file%d" %
                         (AppDefaultKey.RECENT_PROJECTS_KEY.value, i + 1), item)

        if sys.platform.startswith("linux"):
            config.Save()

    def GetHistoryFile(self, i):
        assert 0 <= i < len(self._list)
        return self._list[i]

    def GetHistoryFileIndex(self, path):
        for i, item in enumerate(self._list):
            if is_sample_path(item, path):
                return i
        return -1

    def RemoveFileFromHistory(self, path):
        i = self.GetHistoryFileIndex(path)
        if i == -1:
            return
        del self._list[i]
