from .pyqt import QPixmap, QIcon


def empty_icon():
    return QIcon(QPixmap())
