import os
import logging
from .limits import MAX_MRU_FILE_LIMIT, DEFAULT_MRU_FILE_NUM, DEFAULT_MRU_PROJECT_NUM
from .history import FileHistory, ProjectHistory
from .pyqt import QFileDialog, QMessageBox
from ..widgets import simpledialog
from .docview import DOC_NO_VIEW
from .template import TEMPLATE_INVISIBLE
from ..project import ext as projectext
from . import get_app, _, newid
from .profile import Profile
from .defaultkeys import AppDefaultKey
from .path import find_extension

log = logging.getLogger(__name__)

# 新建文档类型
DOC_NEW = 1
# 静默打开文档,适用于双击打开文件,不需要打开文件对话框
DOC_SILENT = 2
# 相同路径的文档只打开一次
DOC_OPEN_ONCE = 4
DEFAULT_DOCMAN_FLAGS = DOC_OPEN_ONCE

ID_MRU_FILE1 = -1

# 初始化历史文件菜单id,必须保证id的连续性


def init_mru_ids():
    global ID_MRU_FILE1
    for i in range(MAX_MRU_FILE_LIMIT):
        if i == 0:
            ID_MRU_FILE1 = newid()
        else:
            newid()
    return ID_MRU_FILE1


class DocManager:

    def __init__(self, flags=DEFAULT_DOCMAN_FLAGS, initialize=True):
        """
        Constructor. Create a document manager instance dynamically near the
        start of your application before doing any document or view operations.

        flags is used in the Python version to indicate whether the document
        manager is in DOC_SDI or DOC_MDI mode.

        If initialize is true, the Initialize function will be called to
        create a default history list object. If you derive from wxDocManager,
        you may wish to call the base constructor with false, and then call
        Initialize in your own constructor, to allow your own Initialize or
        OnCreateFileHistory functions to be called.
        """
        self._default_document_namecounter = 1
        self._flags = flags
        self._currentview = None
        self._last_activeview = None
        self._max_docs_open = 10000
        # 存储历史文件对象
        self._file_history = None
        self._project_history = None
        self.project_extensions = []
        self._templates = []
        self._docs = []
        self._last_directory = ""
        # 初始化历史文件菜单id列表,文件id的值必须是连续增长的
        init_mru_ids()
        if initialize:
            # 初始化历史文件存储列表
            self.Initialize()

    def GetFlags(self):
        """
        Returns the document manager's flags.  This method has been
        added to wxPython and is not in wxWindows.
        """
        return self._flags

    def CloseDocument(self, doc, force=True):
        """
        Closes the specified document.
        """
        if force or doc.Close():
            doc.DeleteAllViews()
            if doc in self._docs:
                doc.Destroy()
            return True
        return False

    def CloseDocuments(self, force=True):
        """
        Closes all currently opened documents.
        """
        for document in self._docs[::-1]:  # Close in lifo (reverse) order.  We clone the list to make sure we go through all docs even as they are deleted
            if not self.CloseDocument(document, force):
                return False
           # if document:
            #    document.DeleteAllViews() # Implicitly delete the document when the last view is removed
        return True

    def Clear(self, force=True):
        """
        Closes all currently opened document by callling CloseDocuments and
        clears the document manager's templates.
        """
        if not self.CloseDocuments(force):
            return False
        self._templates = []
        return True

    def Initialize(self):
        """
        Initializes data; currently just calls OnCreateFileHistory. Some data
        cannot always be initialized in the constructor because the programmer
        must be given the opportunity to override functionality. In fact
        Initialize is called from the wxDocManager constructor, but this can
        be vetoed by passing false to the second argument, allowing the
        derived class's constructor to call Initialize, possibly calling a
        different OnCreateFileHistory from the default.

        The bottom line: if you're not deriving from Initialize, forget it and
        construct wxDocManager with no arguments.
        """
        self.OnCreateFileHistory()
        return True

    def GetDocument(self, filename):
        founddoc = None
        open_docs = self.GetDocuments()
        for opendoc in open_docs:
            if os.path.normcase(opendoc.GetFilename()) == os.path.normcase(filename):
                founddoc = opendoc
                break
        return founddoc

    def GetCurrentView(self):
        """
        Returns the currently active view.
        """
        if self._currentview:
            return self._currentview
        if len(self._docs) == 1:
            return self._docs[0].GetFirstView()
        return None

    def GetLastActiveView(self):
        """
        Returns the last active view.  This is used in the SDI framework where dialogs can be mistaken for a view
        and causes the framework to deactivete the current view.  This happens when something like a custom dialog box used
        to operate on the current view is shown.
        """
        if len(self._docs) >= 1:
            return self._last_activeview
        return None

    def get_filter(self, template):
        descr = template.GetFileFilter()
        return template.GetDescription() + f' ({descr})'

    def get_filters(self, exclude_template_type=None):
        templates = get_app().GetDocumentManager().GetTemplates()
        # 所有文件过滤器放在第一位
        filters = [self.get_filter(templates[0])]
        for temp in templates:
            if exclude_template_type is not None and issubclass(temp.GetDocumentType(), exclude_template_type):
                continue
            elif exclude_template_type is None and temp.GetDefaultExtension() in self.project_extensions:
                continue
            if temp.IsVisible():
                temp_filter = self.get_filter(temp)
                log.debug(
                    "file template %s filter is %s",
                    temp.GetDocumentName(),
                    temp_filter
                )
                filters.append(temp_filter)
        # 项目文件后缀放在过滤器最后
        if exclude_template_type is None:
            filters.append(self.get_project_filter())
        return ';;'.join(filters)

    def SelectDocumentPath(self, templates, flags, save):
        """
        Under Windows, pops up a file selector with a list of filters
        corresponding to document templates. The wxDocTemplate corresponding
        to the selected file's extension is returned.

        On other platforms, if there is more than one document template a
        choice list is popped up, followed by a file selector.

        This function is used in wxDocManager.CreateDocument.
        """
        descrs = self.get_filters()
        # 支持同时选择多个文件
        paths, filetype = QFileDialog.getOpenFileNames(
            get_app().MainFrame,
            _('Open File'),
            None,  # 记住上次选择的路径
            descrs  # 设置文件扩展名过滤,用双分号间隔
        )
        path_templates = []
        if paths:
            for path in paths:
                # 将路径转换成操作系统下标准的路径格式
                realpath = os.path.realpath(path)
                the_template = self.FindTemplateForPath(realpath)
                path_templates.append((the_template, realpath),)
        return path_templates

    def OnFileSaveAs(self, event):
        doc = self.GetCurrentDocument()
        if not doc:
            return
        doc.SaveAs()

    def OnCreateFileHistory(self):
        """
        A hook to allow a derived class to create a different type of file
        history. Called from Initialize.
        """
        max_files = Profile.get_int(
            AppDefaultKey.MRU_LENGTH_KEY.value, DEFAULT_MRU_FILE_NUM)
        if max_files > MAX_MRU_FILE_LIMIT:
            max_files = MAX_MRU_FILE_LIMIT
        enable_mru = Profile.get_int(AppDefaultKey.ENABLE_MRU_KEY.value, True)
        if enable_mru:
            self._file_history = FileHistory(
                maxFiles=max_files, idBase=ID_MRU_FILE1)
       # 获取配置最大历史项目个数
        max_project_files = Profile.get_int(
            AppDefaultKey.RECENTPROJECT_LENGTH_KEY.value, DEFAULT_MRU_PROJECT_NUM)
        self._project_history = ProjectHistory(maxFiles=max_project_files)

    def SelectDocumentType(self, temps, sort=False):
        """
        Returns a document template by asking the user (if there is more than
        one template). This function is used in wxDocManager.CreateDocument.

        Parameters

        templates - list of templates from which to choose a desired template.

        sort - If more than one template is passed in in templates, then this
        parameter indicates whether the list of templates that the user will
        have to choose from is sorted or not when shown the choice box dialog.
        Default is false.
        """
        templates = []
        for temp in temps:
            if temp.IsVisible():
                want = True
                for temp2 in templates:
                    if temp.GetDocumentName() == temp2.GetDocumentName() and temp.GetViewName() == temp2.GetViewName():
                        want = False
                        break
                if want:
                    templates.append(temp)

        if len(templates) == 0:
            return None
        if len(templates) == 1:
            return templates[0]

        if sort:
            def tempcmp(a, b):
                return cmp(a.GetDescription(), b.GetDescription())
            templates.sort(tempcmp)

        default_document_type = Profile.get(
            AppDefaultKey.DEFAULT_DOCUMENT_TYPE_KEY.value,
            get_app().GetDefaultTextDocumentType()
        )
        default_document_template = self.FindTemplateForDocumentType(
            default_document_type)
        strings = []
        default_selection = -1
        for i, temp in enumerate(templates):
            if temp == default_document_template:
                default_selection = i
            strings.append(temp.GetDescription())
        selection = simpledialog.asklist(
            _("New document"),
            _("Select a document type") + ":",
            strings,
            default_selection
        )
        if selection == -1:
            return None
        return templates[selection]

    def FindTemplateForDocumentType(self, document_type):
        """
        Given a path, try to find template that matches the extension. This is
        only an approximate method of finding a template for creating a
        document.

        Note this wxPython verson looks for and returns a default template if no specific template is found.
        """
        default = None
        for temp in self._templates:
            if temp.GetDocumentName() == document_type:
                return temp
        return default

    def CreateTemplateDocument(self, template, path, flags=0):
        # the document has been opened,switch to the document view
        if path and flags & DOC_OPEN_ONCE:
            found_doc = self.GetDocument(path)
            if found_doc:
                found_view = found_doc.GetFirstView()
                if found_view and found_view.GetFrame() and not (flags & DOC_NO_VIEW):
                    found_view.GetFrame().SetFocus()  # Not in wxWindows code but useful nonetheless
                    # Not in wxWindows code but useful nonetheless
                    if hasattr(found_view.GetFrame(), "IsIconized") and found_view.GetFrame().IsIconized():
                        found_view.GetFrame().Iconize(False)
                return found_doc

        doc = template.CreateDocument(path, flags)
        if doc:
            doc.SetDocumentName(template.GetDocumentName())
            doc.SetDocumentTemplate(template)
            if not doc.OnOpenDocument(path):
                frame = doc.GetFirstView().GetFrame()
                doc.DeleteAllViews()  # Implicitly deleted by DeleteAllViews
                if frame:
                    # DeleteAllViews doesn't get rid of the frame, so we'll explicitly destroy it.
                    frame.Destroy()
                return None
            # 不可见文件模板不能加入历史文件列表
            if not (template.GetFlags() & TEMPLATE_INVISIBLE):
                self.AddFileToHistory(path)
        return doc

    def CreateDocument(self, path, flags=0):
        """
        Creates a new document in a manner determined by the flags parameter,
        which can be:

        wx.lib.docview.DOC_NEW Creates a fresh document.
        wx.lib.docview.DOC_SILENT Silently loads the given document file.

        If wx.lib.docview.DOC_NEW is present, a new document will be created and returned,
        possibly after asking the user for a template to use if there is more
        than one document template. If wx.lib.docview.DOC_SILENT is present, a new document
        will be created and the given file loaded into it. If neither of these
        flags is present, the user will be presented with a file selector for
        the file to load, and the template to use will be determined by the
        extension (Windows) or by popping up a template choice list (other
        platforms).

        If the maximum number of documents has been reached, this function
        will delete the oldest currently loaded document before creating a new
        one.

        wxPython version supports the document manager's wx.lib.docview.DOC_OPEN_ONCE
        and wx.lib.docview.DOC_NO_VIEW flag.

        if wx.lib.docview.DOC_OPEN_ONCE is present, trying to open the same file multiple
        times will just return the same document.
        if wx.lib.docview.DOC_NO_VIEW is present, opening a file will generate the document,
        but not generate a corresponding view.
            manager里面CreateDocument除了创建文档,还加载文档内容
            template里面CreateDocument只是创建文档对象,并没有加载文档内容
        """
        templates = []
        for temp in self._templates:
            if temp.IsVisible():
                templates.append(temp)
        if len(templates) == 0:
            log.error("app has no visible templates")
            return []

        if len(self.GetDocuments()) >= self._max_docs_open:
            doc = self.GetDocuments()[0]
            if not self.CloseDocument(doc, False):
                return []

        if flags & DOC_NEW:
            for temp in templates[:]:
                if not temp.IsNewable():
                    templates.remove(temp)
            if len(templates) == 1:
                temp = templates[0]
            else:
                temp = self.SelectDocumentType(templates)
            if temp:
                newdoc = temp.CreateDocument(path, flags)
                if newdoc:
                    newdoc.SetDocumentName(temp.GetDocumentName())
                    newdoc.SetDocumentTemplate(temp)
                    newdoc.OnNewDocument()
                return newdoc
            return None

        if path and flags & DOC_SILENT:
            temp = self.FindTemplateForPath(path)
            path_templates = [(temp, path), ]
        else:
            # 同时选择了多个文件路径
            path_templates = self.SelectDocumentPath(templates, path, flags)

        ret_docs = []
        for temp, path in path_templates:
            # Existing document
            if path and self.GetFlags() & DOC_OPEN_ONCE:
                doc_exists = False
                for document in self._docs:
                    if document.GetFilename() and os.path.normcase(document.GetFilename()) == os.path.normcase(path):
                        """ check for file modification outside of application """
                        if not document.IsDocumentModificationDateCorrect():
                            msg_title = get_app().GetAppName()
                            if not msg_title:
                                msg_title = _("Warning")
                            shortname = document.GetPrintableName()
                            answer = QMessageBox.question(
                                document.GetFirstView().GetFrame(),
                                _("Reload.."),
                                _("File \"%s\" has already been modified outside,Do You Want to reload it?") % shortname,
                                QMessageBox.Yes | QMessageBox.No
                            )
                            if answer == QMessageBox.Yes:
                                if not self.CloseDocument(document, False):
                                    QMessageBox.warning(
                                        document.GetFirstView().GetFrame(),
                                        msg_title,
                                        _("Couldn't reload '%s'.  Unable to close current '%s'.") % (
                                            shortname, shortname)
                                    )
                                    return None
                                return self.CreateDocument(path, flags)
                            document.SetDocumentModificationDate()

                        firstview = document.GetFirstView()
                        if not firstview and not (flags & wx.lib.docview.DOC_NO_VIEW):
                            document.GetDocumentTemplate().CreateView(document, flags)
                            document.UpdateAllViews()
                            firstview = document.GetFirstView()

                        if firstview and firstview.GetFrame() and not (flags & DOC_NO_VIEW):
                            # 不能使用setFocus(),只有使用SetFocus才能保证正确切换文档标签页
                            firstview.GetFrame().SetFocus()  # Not in wxWindows code but useful nonetheless
                            # Not in wxWindows code but useful nonetheless
                            if hasattr(firstview.GetFrame(), "IsIconized") and firstview.GetFrame().IsIconized():
                                firstview.GetFrame().Iconize(False)
                        # return None
                        doc_exists = True
                        ret_docs.append(document)
                        break

            if temp and not doc_exists:
                newdoc = temp.CreateDocument(path, flags)
                # 创建文档成功
                if newdoc:
                    newdoc.SetDocumentName(temp.GetDocumentName())
                    newdoc.SetDocumentTemplate(temp)
                    if not newdoc.OnOpenDocument(path):
                        frame = newdoc.GetFirstView().GetFrame()
                        # 这里销毁文档的时候有可能已经把文档框架对象也同时销毁了
                        newdoc.DeleteAllViews()  # Implicitly deleted by DeleteAllViews
                        if frame:
                            # 这里销毁文档框架的时候需要判断文档框架是否已经不存在了
                            # DeleteAllViews doesn't get rid of the frame, so we'll explicitly destroy it.
                            frame.Destroy()
                        return []
                    self.AddFileToHistory(path)
                    ret_docs.append(newdoc)

        return ret_docs

    def CreateView(self, doc, flags=0):
        """
        Creates a new view for the given document. If more than one view is
        allowed for the document (by virtue of multiple templates mentioning
        the same document type), a choice of view is presented to the user.
        """
        templates = []
        for temp in self._templates:
            if temp.IsVisible():
                if temp.GetDocumentName() == doc.GetDocumentName():
                    templates.append(temp)
        if len(templates) == 0:
            return None

        if len(templates) == 1:
            temp = templates[0]
            view = temp.CreateView(doc, flags)
            if view:
                view.SetViewName(temp.GetViewName())
            return view

        temp = SelectViewType(templates)
        if temp:
            view = temp.CreateView(doc, flags)
            if view:
                view.SetViewName(temp.GetViewName())
            return view
        return None

    def GetCurrentDocument(self):
        """
        Returns the document associated with the currently active view (if any).
        """
        view = self.GetCurrentView()
        if view:
            return view.GetDocument()
        return None

    def load_project_template(self):
        if not self.project_extensions:
            self.project_extensions = self.load_project_exts()

    def load_project_exts(self, keepstar=False):
        common_project_template = get_app().GetDocumentManager(
        ).FindTemplateForTestPath(projectext.COMMON_PROJECT_EXTENSION)
        return common_project_template.exts(keepstar=keepstar)

    def get_project_filter(self):
        template = get_app().GetDocumentManager().FindTemplateForTestPath(
            projectext.COMMON_PROJECT_EXTENSION)
        descr = get_app().GetDocumentManager().get_filter(template)
        return descr

    def AddFileToHistory(self, filename):
        """
        Adds a file to the file history list, if we have a pointer to an
        appropriate file menu.
        """
        self.load_project_template()
        # 项目文件添加到历史项目列表
        if self._project_history is not None and find_extension(filename) in self.project_extensions:
            self._project_history.AddFileToHistory(filename)
        # 非项目文件添加到历史文件列表
        elif self._file_history is not None:
            self._file_history.AddFileToHistory(filename)

    def RemoveFileFromHistory(self, i):
        """
        Removes a file from the file history list, if we have a pointer to an
        appropriate file menu.
        """
        if self._file_history:
            self._file_history.RemoveFileFromHistory(i)

    def RemoveProjectFromHistory(self, path):
        """
        Removes a file from the file history list, if we have a pointer to an
        appropriate file menu.
        """
        if self._project_history:
            self._project_history.RemoveFileFromHistory(path)

    def GetFileHistory(self):
        """
        Returns the file history.
        """
        return self._file_history

    def GetProjectHistory(self):
        """
        Returns the file history.
        """
        return self._project_history

    def GetHistoryFile(self, i):
        """
        Returns the file at index i from the file history.
        """
        if self._file_history:
            return self._file_history.GetHistoryFile(i)
        return None

    def FileHistoryUseMenu(self, menu):
        """
        Use this menu for appending recently-visited document filenames, for
        convenient access. Calling this function with a valid menu enables the
        history list functionality.

        Note that you can add multiple menus using this function, to be
        managed by the file history object.
        """
        if self._file_history is not None:
            self._file_history.UseMenu(menu)

    def FileHistoryRemoveMenu(self, menu):
        """
        Removes the given menu from the list of menus managed by the file
        history object.
        """
        if self._file_history:
            self._file_history.RemoveMenu(menu)

    def FileHistoryLoad(self, config):
        """
            加载历史文件列表和历史项目列表.
        """
        if self._file_history is not None:
            self._file_history.Load(config)

        if self._project_history is not None:
            self._project_history.Load(config)

    def FileHistorySave(self, config):
        """
            保存历史文件列表和历史项目列表.
        """
        if self._file_history:
            self._file_history.Save(config)

        if self._project_history:
            self._project_history.Save(config)

    def FileHistoryAddFilesToMenu(self, menu=None):
        """
        Appends the files in the history list, to all menus managed by the
        file history object.

        If menu is specified, appends the files in the history list to the
        given menu only.
        """
        if self._file_history is not None:
            if menu:
                self._file_history.AddFilesToThisMenu(menu)
            else:
                self._file_history.AddFilesToMenu()

    def GetHistoryFilesCount(self):
        """
        Returns the number of files currently stored in the file history.
        """
        if self._file_history:
            return self._file_history.GetNoHistoryFiles()
        return 0

    def FindTemplateForPath(self, path):
        """
        Given a path, try to find template that matches the extension. This is
        only an approximate method of finding a template for creating a
        document.

        Note this wxPython verson looks for and returns a default template if no specific template is found.
        """
        default = None
        for temp in self._templates:
            if temp.FileMatchesTemplate(path):
                return temp

            if "*.*" in temp.GetFileFilter():
                default = temp
        return default

    def FindTemplateForTestPath(self, ext):
        '''
            根据扩展名获取对应的模板,通过扩展名组成一个测试文件名来获取对应的模板
        '''
        assert '.' in ext
        return self.FindTemplateForPath("test" + ext)

    def SelectViewType(self, temps, sort=False):
        """
        Returns a document template by asking the user (if there is more than one template), displaying a list of valid views. This function is used in wxDocManager::CreateView. The dialog normally will not appear because the array of templates only contains those relevant to the document in question, and often there will only be one such.
        """
        templates = []
        strings = []
        for temp in temps:
            if temp.IsVisible() and temp.GetViewTypeName():
                if temp.GetViewName() not in strings:
                    templates.append(temp)
                    strings.append(temp.GetViewTypeName())

        if len(templates) == 0:
            return None
        if len(templates) == 1:
            return templates[0]

        if sort:
            def tempcmp(a, b):
                return cmp(a.GetViewTypeName(), b.GetViewTypeName())
            templates.sort(tempcmp)

        res = wx.GetSingleChoiceIndex(_("Select a document view:"),
                                      _("Views"),
                                      strings,
                                      self.FindSuitableParent())
        if res == -1:
            return None
        return templates[res]

    def GetTemplates(self):
        """
        Returns the document manager's template list.  This method has been added to
        wxPython and is not in wxWindows.
        """
        return self._templates

    def AssociateTemplate(self, doc_template):
        """
        Adds the template to the document manager's template list.
        """
        if doc_template not in self._templates:
            self._templates.append(doc_template)

    def DisassociateTemplate(self, doc_template):
        """
        Removes the template from the list of templates.
        """
        self._templates.remove(doc_template)

    def AddDocument(self, document):
        """
        Adds the document to the list of documents.
        """
        if document not in self._docs:
            self._docs.append(document)

    def RemoveDocument(self, doc):
        """
        Removes the document from the list of documents.
        """
        if doc in self._docs:
            self._docs.remove(doc)

    def ActivateView(self, view, activate=True, deleting=False):
        """
        Sets the current view.
        """
        if activate:
            self._currentview = view
            self._last_activeview = view
        else:
            self._currentview = None

    def GetMaxDocsOpen(self):
        """
        Returns the number of documents that can be open simultaneously.
        """
        return self._max_docs_open

    def SetMaxDocsOpen(self, max_docsopen):
        """
        Sets the maximum number of documents that can be open at a time. By
        default, this is 10,000. If you set it to 1, existing documents will
        be saved and deleted when the user tries to open or create a new one
        (similar to the behaviour of Windows Write, for example). Allowing
        multiple documents gives behaviour more akin to MS Word and other
        Multiple Document Interface applications.
        """
        self._max_docs_open = max_docsopen

    def GetDocuments(self):
        """
        Returns the list of documents.
        """
        return self._docs

    def MakeDefaultName(self):
        """
        Returns a suitable default name. This is implemented by appending an
        integer counter to the string "Untitled" and incrementing the counter.
        """
        name = _("Untitled %d") % self._default_document_namecounter
        self._default_document_namecounter = self._default_document_namecounter + 1
        return name
