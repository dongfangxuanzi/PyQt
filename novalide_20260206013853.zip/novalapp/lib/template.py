from .path import find_extension

TEMPLATE_VISIBLE = 1
# 不可见模板,不会在文件对话框中出现
TEMPLATE_INVISIBLE = 2
# 不能新建的文档类型,例如图片文件等
TEMPLATE_NO_CREATE = (4 | TEMPLATE_VISIBLE)
DEFAULT_TEMPLATE_FLAGS = TEMPLATE_VISIBLE


class DocTemplate:
    """
    The wxDocTemplate class is used to model the relationship between a
    document class and a view class.
    """

    def __init__(
        self,
        manager,
        description,
        filter,
        dir,
        ext,
        doc_typename,
        view_typename,
        doctype,
        viewtype,
        flags=DEFAULT_TEMPLATE_FLAGS,
        icon=None
    ):
        """
        Constructor. Create instances dynamically near the start of your
        application after creating a wxDocManager instance, and before doing
        any document or view operations.

        manager is the document manager object which manages this template.

        description is a short description of what the template is for. This
        string will be displayed in the file filter list of Windows file
        selectors.

        filter is an appropriate file filter such as *.txt.

        dir is the default directory to use for file selectors.

        ext is the default file extension (such as txt).

        docTypeName is a name that should be unique for a given type of
        document, used for gathering a list of views relevant to a
        particular document.

        viewTypeName is a name that should be unique for a given view.

        docClass is a Python class. If this is not supplied, you will need to
        derive a new wxDocTemplate class and override the CreateDocument
        member to return a new document instance on demand.

        viewClass is a Python class. If this is not supplied, you will need to
        derive a new wxDocTemplate class and override the CreateView member to
        return a new view instance on demand.

        flags is a bit list of the following:
        wx.TEMPLATE_VISIBLE The template may be displayed to the user in
        dialogs.

        wx.TEMPLATE_INVISIBLE The template may not be displayed to the user in
        dialogs.

        wx.DEFAULT_TEMPLATE_FLAGS Defined as wxTEMPLATE_VISIBLE.
        """
        self._docmanager = manager
        self._description = description
        self._file_filter = filter
        self._directory = dir
        self._default_ext = ext
        self._doc_typename = doc_typename
        self._view_typename = view_typename
        self._doctype = doctype
        self._viewtype = viewtype
        self._flags = flags
        self._icon = icon
        self._docmanager.AssociateTemplate(self)

    def GetDefaultExtension(self):
        """
        Returns the default file extension for the document data, as passed to
        the document template constructor.
        """
        return self._default_ext

    def SetDefaultExtension(self, default_ext):
        """
        Sets the default file extension.
        """
        self._default_ext = default_ext

    def GetDescription(self):
        """
        Returns the text description of this template, as passed to the
        document template constructor.
        """
        return self._description

    def SetDescription(self, description):
        """
        Sets the template description.
        """
        self._description = description

    def GetDirectory(self):
        """
        Returns the default directory, as passed to the document template
        constructor.
        """
        return self._directory

    def SetDirectory(self, dir):
        """
        Sets the default directory.
        """
        self._directory = dir

    def GetDocumentManager(self):
        """
        Returns the document manager instance for which this template was
        created.
        """
        return self._docmanager

    def set_document_manager(self, manager):
        """
        Sets the document manager instance for which this template was
        created. Should not be called by the application.
        """
        self._docmanager = manager

    def GetFileFilter(self):
        """
        Returns the file filter, as passed to the document template
        constructor.
        """
        return self._file_filter

    def SetFileFilter(self, filter):
        """
        Sets the file filter.
        """
        self._file_filter = filter

    def GetFlags(self):
        """
        Returns the flags, as passed to the document template constructor.
        (see the constructor description for more details).
        """
        return self._flags

    def SetFlags(self, flags):
        """
        Sets the internal document template flags (see the constructor
        description for more details).
        """
        self._flags = flags

    def GetIcon(self):
        """
        Returns the icon, as passed to the document template
        constructor.  This method has been added to wxPython and is
        not in wxWindows.
        """
        return self._icon

    def SetIcon(self, icon):
        """
        Sets the icon.  This method has been added to wxPython and is not
        in wxWindows.
        """
        self._icon = icon

    def GetDocumentType(self):
        """
        Returns the Python document class, as passed to the document template
        constructor.
        """
        return self._doctype

    def GetViewType(self):
        """
        Returns the Python view class, as passed to the document template
        constructor.
        """
        return self._viewtype

    def IsVisible(self):
        """
        Returns true if the document template can be shown in user dialogs,
        false otherwise.
        """
        return (self._flags & TEMPLATE_VISIBLE) == TEMPLATE_VISIBLE

    def IsNewable(self):
        """
        Returns true if the document template can be shown in "New" dialogs,
        false otherwise.

        This method has been added to wxPython and is not in wxWindows.
        """
        return (self._flags & TEMPLATE_NO_CREATE) != TEMPLATE_NO_CREATE

    def GetDocumentName(self):
        """
        Returns the document type name, as passed to the document template
        constructor.
        """
        return self._doc_typename

    def GetViewName(self):
        """
        Returns the view type name, as passed to the document template
        constructor.
        """
        return self._view_typename

    def CreateDocument(self, path, flags):
        """
        Creates a new instance of the associated document class. If you have
        not supplied a class to the template constructor, you will need to
        override this function to return an appropriate document instance.
            这里CreateDocument只是创建文档对象,并不加载文档内容
        """
        doc = self._doctype()
        doc.SetFilename(path)
        doc.SetDocumentTemplate(self)
        self.GetDocumentManager().AddDocument(doc)
        if doc.OnCreate(path, flags):
            return doc
        if doc in self.GetDocumentManager().GetDocuments():
            doc.DeleteAllViews()
        return None

    def CreateView(self, doc, flags):
        """
        Creates a new instance of the associated document view. If you have
        not supplied a class to the template constructor, you will need to
        override this function to return an appropriate view instance.
        """
        view = self._viewtype()
        view.SetDocument(doc)
        if view.OnCreate(doc, flags):
            return view
        view.Destroy()
        return None

    def FileMatchesTemplate(self, path):
        """
        Returns True if the path's extension matches one of this template's
        file filter extensions.
        """
        ext = find_extension(path)
        if not ext:
            return False
        extlist = self.exts(keepstar=False)
        return ext in extlist

    def exts(self, keepstar=True):
        temp_filter = self.GetFileFilter()
        if keepstar:
            extlist = temp_filter.split(';')
        else:
            extlist = temp_filter.replace('*', '').split(';')
        return extlist
