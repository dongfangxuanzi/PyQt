import os
import os.path
import sys


def filename_from_path(path):
    """
    Returns the filename for a full path.
    """
    return os.path.split(path)[1]


def find_extension(path):
    """
    Returns the extension of a filename for a full path.
    """
    return os.path.splitext(path)[1].lower()


def file_exists(path):
    """
    Returns True if the path exists.
    """
    return os.path.isfile(path)


def filepath_from_path(path):
    """
    Returns the path of a full path without the filename.
    """
    return os.path.split(path)[0]


def is_sample_path(lpath, rpath):
    if sys.platform.startswith("win"):
        return os.path.normpath(lpath.lower()) == os.path.normpath(rpath.lower())
    return os.path.normpath(lpath) == os.path.normpath(rpath)
