# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        registry.py
Purpose:     win注册表相关操作的实现文件

Author:      wukan

Created:     2019-01-10
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
from winreg import (
    CloseKey,
    CreateKey,
    DeleteKey,
    DeleteValue,
    EnumKey,
    HKEY_CURRENT_USER,
    KEY_READ,
    OpenKey,
    QueryInfoKey,
    QueryValue,
    QueryValueEx,
    REG_SZ,
    SetValue,
    SetValueEx,
    HKEY_LOCAL_MACHINE
)
import logging
log = logging.getLogger(__name__)


REG_ROOT_KEYS = {
    'HKEY_LOCAL_MACHINE': HKEY_LOCAL_MACHINE,
    'HKEY_CURRENT_USER': HKEY_CURRENT_USER
}


def get_root_key_path(hkey):
    for path, rootkey in REG_ROOT_KEYS.items():
        if rootkey == hkey:
            return path
    raise RuntimeError('error root key')


class Registry:
    """win注册表操作类"""

    def __init__(self, hkey=HKEY_CURRENT_USER, path=None):
        self._hkey = hkey
        self._path = path
        if self._path is None:
            self._path = get_root_key_path(hkey)

    @property
    def path(self):
        return self._path

    @property
    def RootKey(self):
        return self._hkey

    def Open(self, subkey, access=KEY_READ, check_key_exist=False):
        # 打开子健
        try:
            if check_key_exist and not self.Exist(subkey):
                log.debug('child key `%s` is not exist in key path:%s', subkey, self._path)
                return None
            open_key = OpenKey(self.RootKey, subkey, 0, access)
        except FileNotFoundError:
            # key不存在
            return None
        except Exception as e:
            log.error(
                'open subkey `%s` in key path `%s` error:%s',
                subkey,
                self._path,
                str(e)
            )
            return None
        return Registry(open_key, path=self._path + "\\" + subkey)

    def Exist(self, key):
        subkeys = key.split('\\')
        child_keys = list(self.EnumChildKeyNames())
        # 只检测第一层子健是否存在,更深层的子健很难实现
        return subkeys[0].lower() in child_keys

    def Read(self, value_name):
        # 读取健的默认值
        return QueryValue(self.RootKey, value_name)

    def ReadEx(self, value_name):
        # 读取健的值对应数据
        # 返回(value,value_type)类型的值,只需取第一个即可
        return QueryValueEx(self.RootKey, value_name)[0]

    def EnumChildKey(self):
        child_key_count = QueryInfoKey(self.RootKey)[0]
        for i in range(int(child_key_count)):
            name = EnumKey(self.RootKey, i)
            child_key = self.Open(name)
            yield child_key

    def EnumChildKeyNames(self, tolower=True):
        # 获取该键的所有键值,遍历枚举
        child_key_count = QueryInfoKey(self.RootKey)[0]
        for i in range(int(child_key_count)):
            name = EnumKey(self.RootKey, i)
            # 注册表名称不区分大小写,允许统一用小写,否则即使存在key也无法匹配
            if tolower:
                yield name.lower()
            else:
                yield name

    def DeleteKey(self, key_name):
        # 删除键
        DeleteKey(self.RootKey, key_name)

    def DeleteValue(self, value_name):
        # 删除键值
        DeleteValue(self.RootKey, value_name)

    def CreateKey(self, key_name):
        # 创建新的子键
        new_key = CreateKey(self.RootKey, key_name)
        return Registry(new_key)

    def WriteValue(self, key_name, value, val_type=REG_SZ):
        # 创建子健并给键添加默认值
        SetValue(self.RootKey, key_name, val_type, value)

    def WriteValueEx(self, value_name, value, val_type=REG_SZ):
        # 给键添加一个值
        SetValueEx(self.RootKey, value_name, 0, val_type, value)

    def CreateKeys(self, key_str):
        # 创建多级子健,以/字符分割
        keys = key_str.split("/")
        loop_key = None
        for key in keys:
            if loop_key is None:
                loop_key = self.CreateKey(key)
            else:
                loop_key = loop_key.CreateKey(key)
        return loop_key

    def DeleteKeys(self, key_str):
        key_path = key_str.replace("/", "\\")
        registry = self.Open(key_path)
        if registry is None:
            return
        names = list(registry.EnumChildKeyNames())
        if 0 == len(names):
            self.DeleteKey(key_path)
        else:
            for name in names:
                self.DeleteKeys(key_str + "/" + name)
            self.DeleteKeys(key_str)

    def close_key(self):
        CloseKey(self.RootKey)

    def __enter__(self):
        # with语句进入
        return self

    def __exit__(self, e_t, e_v, t_b):
        # with语句退出时关闭键
        self.close_key()
