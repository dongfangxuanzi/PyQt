import threading

_lock = threading.Lock()


def newid():
    global _idCounter

    with _lock:
        _idCounter += 1
    return _idCounter


def get_app():
    global _AppInstance

    assert _AppInstance is not None
    return _AppInstance


def _get_translation(raw_text):
    global _AppInstance
    if _AppInstance is None:
        return raw_text
    return _AppInstance.GetLocale().get_text(raw_text)


_ = _get_translation

_idCounter = 1000
_AppInstance = None
