# -*- coding: utf-8 -*-
from . import prog_lang
from .lib import _, get_app, newid


def get_prog_lang():
    return prog_lang.LANGUAGE_DEFAULT
