from novalapp.lib.pyqt import QLabel


class QRedLabel(QLabel):
    """红色文本标签"""

    def __init__(self, title=''):
        super().__init__(title)
        self.setStyleSheet("color:red")
