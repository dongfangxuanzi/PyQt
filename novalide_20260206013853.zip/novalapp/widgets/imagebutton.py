from ..lib.pyqt import QToolButton, QSizePolicy, Qt


class ImageButton(QToolButton):
    """description of class"""

    def __init__(self, tooltip, parent=None):
        super().__init__(parent)
        self.setToolButtonStyle(Qt.ToolButtonIconOnly)
        self.setAutoRaise(True)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.setToolTip(tooltip)
