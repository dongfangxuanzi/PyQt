from ..lib.qsci import DEFAULT_MARGIN_INDEX
from ..syntax.syntax import SyntaxThemeManager
from ..editor.textctrl import TextCtrl
from ..editor.codeview import CodeCtrl
from ..syntax import lang


class CodeSampleCtrl(CodeCtrl):
    """description of class"""

    def __init__(self, parent):
        super().__init__(parent, None)
        self.init_editor_font()
        self.setMarginWidth(DEFAULT_MARGIN_INDEX, 0)

    def contextMenuEvent(self, event):
        '''
            使用原生的弹出菜单
        '''
        return TextCtrl.contextMenuEvent(self, event)

    def set_lang_lexer(self, lang_id):
        self._lang_lexer = SyntaxThemeManager.manager().GetLexer(lang_id)
        if lang_id == lang.ID_LANG_TXT:
            lexer = None
        else:
            lexer = self._lang_lexer.get_lexer(self)
            # 设置渲染语言的字体
            lexer.setDefaultFont(self.font())
        self.setLexer(lexer)
