# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2019  Sergey Satskiy sergey.satskiy@gmail.com
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""About dialog implementation"""
from ..lib.pyqt import QTextEdit, QSizePolicy
from ..util import ui_utils


class ScrolledMessageDialog(ui_utils.BaseModalDialog):
    """Codimension about dialog"""

    def __init__(self, title, msg, parent=None):
        super().__init__(title, parent)
        self.__create_layout(msg)

    def __create_layout(self, msg):
        """Creates the dialog layout"""
        self.resize(640, 480)
        self.setSizeGripEnabled(True)
        text_ctrl = QTextEdit()
        text_ctrl.setText(msg)
        text_ctrl.setReadOnly(True)
        self.layout.addWidget(text_ctrl)
        text_ctrl.setSizePolicy(QSizePolicy.Expanding,
                                QSizePolicy.Expanding)
        # Button at the bottom
        self.create_ok_button()
