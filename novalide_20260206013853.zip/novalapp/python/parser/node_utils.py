from __future__ import annotations
from functools import lru_cache
import astroid
from astroid import nodes
from astroid.exceptions import AstroidError
from astroid.context import InferenceContext
from astroid.typing import InferenceResult
from .define import MAIN_FUNCTION_NAME
from ...util import strutils


def get_builtin_type(typevalue):
    return typevalue.pytype().replace('builtins.', '')


def get_const_node_value(node):
    if isinstance(node, nodes.Const):
        const_type = get_builtin_type(node)
        if const_type == "bytes":
            return {'value_kind': const_type}
        return {'value': node.value, 'value_kind': const_type}
    if isinstance(node, nodes.UnaryOp):
        if node.op == '-' or node.op == '+':
            kw = get_const_node_value(node.operand)
            if kw:
                kw['value'] = node.as_string()
                return kw
    elif isinstance(node, nodes.List):
        return {'value_kind': 'list'}
    elif isinstance(node, nodes.Set):
        return {'value_kind': 'set'}
    elif isinstance(node, nodes.Dict):
        return {'value_kind': 'dict'}
    elif isinstance(node, nodes.Tuple):
        return {'value_kind': 'tuple'}
    elif isinstance(node, nodes.Call):
        if isinstance(node.func, nodes.Name):
            func_name = node.func.name
            if func_name in ['list', 'tuple', 'set', 'dict']:
                return {'value_kind': func_name}
    return {}


def get_const_annnode_value(node):
    annotation = node.annotation
    if isinstance(annotation, nodes.Subscript):
        if isinstance(annotation.value, nodes.Name):
            if annotation.value.name in ['list', 'tuple', 'set', 'dict']:
                return {'value_kind': annotation.value.name}
    elif isinstance(annotation, nodes.Name):
        if annotation.name in ['bool', 'int', 'float', 'complex', 'str', 'bytes']:
            kw = {'value_kind': annotation.name}
            if isinstance(node.value, nodes.Const):
                kw.update({'value': node.value.value})
            return kw
    return {}


def is_main_statement(element):
    if isinstance(element, nodes.If) and isinstance(element.test, nodes.Compare) and isinstance(element.test.left, nodes.Name) and element.test.left.name == "__name__" \
            and element.test.ops and isinstance(element.test.ops[0][1], nodes.Const) \
            and element.test.ops[0][1].value == MAIN_FUNCTION_NAME:
        return True
    return False


def get_node_type(node):
    if is_main_statement(node):
        return config.MAIN_FUNCTION_NAME
    if isinstance(node, (nodes.Assign, nodes.AnnAssign)):
        if isinstance(node.parent, nodes.ClassDef):
            return config.CLASS_PROPERTY
        return config.OBJECT_PROPERTY
    return node.__class__.__name__.lower()


def _get_python_type_of_node(node: nodes.NodeNG) -> str | None:
    pytype: Callable[[], str] | None = getattr(node, "pytype", None)
    if callable(pytype):
        return pytype()
    return None


def get_node_doc(node):
    if not isinstance(
        node,
        (nodes.Module, nodes.ClassDef, nodes.FunctionDef)
    ):
        return None
    if node.doc_node is None:
        return None
    return node.doc_node.value


def get_node_line_col(node):
    if isinstance(node, (nodes.FunctionDef, nodes.ClassDef)):
        if node.position is not None:
            return node.position.lineno, node.position.col_offset
    return node.lineno, node.col_offset


@lru_cache(maxsize=1024)
def safe_infer(
    node: nodes.NodeNG,
    context: InferenceContext | None = None,
    *,
    compare_constants: bool = False,
) -> InferenceResult | None:
    """Return the inferred value for the given node.

    Return None if inference failed or if there is some ambiguity (more than
    one node has been inferred of different types).

    If compare_constants is True and if multiple constants are inferred,
    unequal inferred values are also considered ambiguous and return None.
    """
    inferred_types: set[str | None] = set()
    try:
        infer_gen = node.infer(context=context)
        value = next(infer_gen)
    except astroid.InferenceError:
        return None
    except Exception as e:  # pragma: no cover
        raise AstroidError from e

    if value is not astroid.Uninferable:
        inferred_types.add(_get_python_type_of_node(value))

    # pylint: disable = too-many-try-statements
    try:
        for inferred in infer_gen:
            inferred_type = _get_python_type_of_node(inferred)
            if inferred_type not in inferred_types:
                return None  # If there is ambiguity on the inferred node.
            if (
                compare_constants
                and isinstance(inferred, nodes.Const)
                and isinstance(value, nodes.Const)
                and inferred.value != value.value
            ):
                return None
            if (
                isinstance(inferred, nodes.FunctionDef)
                and inferred.args.args is not None
                and isinstance(value, nodes.FunctionDef)
                and value.args.args is not None
                and len(inferred.args.args) != len(value.args.args)
            ):
                return None  # Different number of arguments indicates ambiguity
    except astroid.InferenceError:
        return None  # There is some kind of ambiguity
    except StopIteration:
        return value
    except Exception as e:  # pragma: no cover
        raise AstroidError from e
    return value if len(inferred_types) <= 1 else None


@lru_cache(maxsize=512)
def infer_all(
    node: nodes.NodeNG, context: InferenceContext | None = None
) -> list[InferenceResult]:
    try:
        return list(node.infer(context=context))
    except astroid.InferenceError:
        return []
    except Exception as e:  # pragma: no cover
        raise AstroidError from e


def get_fromimport_modname(fromimport_node):
    mod_name = fromimport_node.modname
    # 处理相对导入的情况
    # 有相对导入
    if fromimport_node.level is not None:
        # 如果相对导入全是dot符合,则包或模块名称为空字符串
        if strutils.is_none_empty(mod_name):
            mod_name = "." * fromimport_node.level
        # 相对导入含包或模块名称
        else:
            mod_name = "." * fromimport_node.level + mod_name
    return mod_name


def get_alias_name(alias):
    return alias.asname if alias.asname is not None else alias.name
