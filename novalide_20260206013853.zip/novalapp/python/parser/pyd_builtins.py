import argparse
import sys
import os
import logging
from pathlib import Path
import re
from novalapp.python.parser import builtin_types
from novalapp.python import prog_lang_ext


class PydExtensionsAnalyzer(builtin_types.BuiltinModulesAnalyzer):

    def __init__(
        self,
        dbver,
        outpath,
        ext
    ):
        super().__init__(dbver, outpath)
        self._ext = ext

    @staticmethod
    def pathlist_contains_path(pathlist, path):
        for pathstr in pathlist:
            if path.startswith(pathstr):
                return True
        return False

    @staticmethod
    def syspath_contains_path(path):
        for syspath in sys.path:
            if Path(syspath) == path:
                return True
        return False

    @classmethod
    def path_to_mod_pathlist(cls, pyd_file_path):
        root_dir_path = Path(pyd_file_path).parent
        parent_path = root_dir_path
        while parent_path:
            if cls.syspath_contains_path(parent_path):
                break
            if parent_path == parent_path.parent:
                break
            parent_path = parent_path.parent
        if parent_path == root_dir_path:
            return []
        relative_path = str(root_dir_path).replace(
            str(parent_path) + os.sep, '').split('.')[0]
        relative_path = relative_path.replace(os.sep, '/')
        paths = str(relative_path).split('/')
        return paths

    def analyze(self):
        scan_path_list = []
        for syspath in sys.path:
            if not self.pathlist_contains_path(scan_path_list, syspath) and (
                syspath.startswith(sys.exec_prefix) or (
                    syspath.startswith(sys.base_exec_prefix) or
                    syspath.find('site-packages') != -1
                )
            ):
                scan_path_list.append(syspath)
        for syspath in scan_path_list:
            logging.info('scan sys path is %s', syspath)
            self.scan_pyd(syspath)

    def scan_pyd(self, syspath):
        for root, _, files in os.walk(syspath):
            for filename in files:
                filepath = os.path.join(root, filename)
                basename, ext = os.path.splitext(filename)
                ext = ext.lower()[1:]
                if ext != self._ext:
                    continue
                modname = basename
                if ext == prog_lang_ext.PYTHON_PYD_FILE_EXT:
                    # Windows extension module
                    platform_suffix = re.search(
                        r'[.]cp[0-9]+-win[_a-z0-9]*$', basename, re.I)
                    if platform_suffix:
                        modname = basename[:platform_suffix.start()]
                elif ext == prog_lang_ext.PYTHON_SO_FILE_EXT:
                    # Linux/Unix/Mac extension module
                    platform_suffix = re.search(
                        r'[.](?:cpython|pypy)-[0-9]+[-_a-z0-9]*$', basename, re.I)
                    if platform_suffix:
                        modname = basename[:platform_suffix.start()]
                modpath_list = self.path_to_mod_pathlist(filepath)
                modpath_list.append(modname)
                modpath = ".".join(modpath_list)
                logging.debug(
                    "filepath is %s, filename is %s, modname is %s",
                    filepath,
                    basename,
                    modpath
                )
                builtin_types.BuiltintypesApiGen(modpath, self._datapath).gen()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--debug",
        action='store_true',
        dest="debug",
        help='show debug log of program or not',
        default=False
    )

    parser.add_argument(
        "-o",
        "--out",
        type=str,
        dest="outpath",
        help='dest out path of intellisense data',
        required=True
    )
    parser.add_argument(
        "-v",
        "--dbver",
        type=str,
        dest="dbver",
        help='database version of intellisense data',
        required=True
    )
    parser.add_argument(
        "-ext",
        "--extension",
        type=str,
        dest="extension",
        help='',
        default="",
        required=False
    )
    args = parser.parse_args()
    if args.debug:
        # 配置日志器的日志级别为debug,高于debug或等于debug的都会报出
        logging.basicConfig(level=logging.DEBUG)
    # 因为logging模块提供的日志记录函数所使用的日志器设置的日志级别是WARNING,
    # 因此只有WARNING级别的日志记录以及大于它的ERROR和CRITICAL级别的日志记录被输出了,而小于它的DEBUG和INFO级别的日志记录被丢弃了
    else:
        logging.basicConfig(level=logging.INFO)
    if args.extension == "":
        builtin_types.BuiltinModulesAnalyzer(
            args.dbver,
            args.outpath,
        ).analyze()
    elif args.extension in [prog_lang_ext.PYTHON_PYD_FILE_EXT, prog_lang_ext.PYTHON_SO_FILE_EXT]:
        sys.path.sort()
        for path in sys.path:
            logging.info('sys path is %s', path)
        PydExtensionsAnalyzer(
            args.dbver,
            args.outpath,
            args.extension
        ).analyze()
    else:
        assert False, "invalid extension name %s" % args.extension
