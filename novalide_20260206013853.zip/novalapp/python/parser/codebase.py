import logging
import os
from collections.abc import Sequence
import astroid
from astroid import nodes
from . import node_utils
from .ast_walker import ASTWalker
from .. import prog_lang_ext
from ..analysis.moduleloader import ModuleLoader
from .exceptions import (
    ReferenceModuleNotAnalyzedError,
    BuiltinModuleNotExistError,
    OutofPythonPathError
)
from .define import PACKAGE_INIT_FILE
from ..apis import memberkeys
from ...util import strutils

logger = logging.getLogger(__name__)


class CodebaseParser:
    """description of class"""

    def __init__(self, analyzer):
        self._analyzer = analyzer
        self.builtinmodule = None
        if self._analyzer is not None:
            self.builtinmodule = self.analyzer.BuiltinModule
            if self.builtinmodule is None:
                raise BuiltinModuleNotExistError
        self._visitors = []
        self.walker = ASTWalker()

    @property
    def analyzer(self):
        return self._analyzer

    @staticmethod
    def modname_to_path(import_modname, names):
        if isinstance(names, list):
            if names:
                return import_modname + "." + ".".join(names)
            return import_modname
        return import_modname + "." + names

    def set_analyzer(self, analyzer):
        self._analyzer = analyzer
        if self.analyzer is None:
            return
        self.builtinmodule = self.analyzer.BuiltinModule

    def prepare_visitors(self):
        raise NotImplementedError

    def visit_functiondef(self, node):
        raise NotImplementedError

    def visit_asyncfunctiondef(self, node):
        raise NotImplementedError

    def visit_classdef(self, node):
        raise NotImplementedError

    def visit_assign(self, node):
        raise NotImplementedError

    def visit_annassign(self, node):
        raise NotImplementedError

    def visit_import(self, node):
        raise NotImplementedError

    def visit_importfrom(self, node):
        raise NotImplementedError

    def visit_if(self, node):
        raise NotImplementedError

    def visit_tryexcept(self, node):
        raise NotImplementedError

    def visit_for(self, node):
        raise NotImplementedError

    def visit_return(self, node):
        raise NotImplementedError

    def visit_with(self, node):
        raise NotImplementedError

    def visit_while(self, node):
        raise NotImplementedError

    def is_module_range(self, node):
        parent = node.parent
        if isinstance(parent, nodes.Module):
            return True
        if isinstance(
            parent,
            (nodes.Try, nodes.ExceptHandler, nodes.TryStar, nodes.If)
        ):
            while parent:
                if not isinstance(
                    parent,
                    (nodes.If, nodes.Try, nodes.ExceptHandler, nodes.TryStar, nodes.Module)
                ):
                    return False
                if node_utils.is_main_statement(parent):
                    return False
                parent = parent.parent
            return True
        return False

    def is_class_range(self, node):
        return isinstance(node.parent, nodes.ClassDef)

    def visit_child(self, child_node):
        cid = child_node.__class__.__name__.lower()
        visit_events: Sequence[ASTWalker.AstCallback] = self.walker.visit_events.get(
            cid, ())
        for callback in visit_events:
            callback(child_node)

        # recurse on children
        # 递归遍历类成员
        if hasattr(child_node, 'body') and not isinstance(child_node, nodes.FunctionDef):
            for child in child_node.body:
                self.visit_child(child)

    def get_mro(self, node):
        base_names = []
        try:
            mros = node.mro()
        except Exception as ex:
            logger.error("%s", str(ex))
            return []
        mros.remove(node)
        for mro in mros:
            base_classname = mro.name
            mro_module = mro.root()
            if mro_module.name == "":
                continue
            file = mro_module.file
            modname = None
            if file is not None:
                try:
                    modpath = self.analyzer.get_relative_path(file)
                    if modpath is not None:
                        modname = self.modname_to_path(modpath, base_classname)
                except OutofPythonPathError as ex:
                    logger.error("parse file %s mros error", file)
            else:
                modname = self.modname_to_path(mro_module.name, base_classname)
            if modname is not None:
                base_names.append(modname)
        bases = node.bases
        for base in bases:
            infer_base = node_utils.safe_infer(base)
            modname = None
            if infer_base is None or infer_base is astroid.Uninferable:
                basname = base.as_string()
                basnames = basname.split(".")
                name = basnames[0]
                import_modname = self.find_import_modname(node.root(), name)
                if import_modname is not None:
                    modname = self.modname_to_path(
                        import_modname, basnames[1:])
            else:
                base_module = infer_base.root()
                file = base_module.file
                if file is not None and base_module.name != '':
                    try:
                        modpath = self.analyzer.get_relative_path(file)
                        if modpath is not None:
                            modname = self.modname_to_path(
                                modpath, infer_base.name)
                    except OutofPythonPathError as ex:
                        logger.error("parse base file %s mros error", file)
            if modname not in base_names and modname is not None:
                base_names.append(modname)
        return base_names

    def relative_path_to_abs(self, filepath, mod_name, level):
        def get_relative_level_path(path, level):
            '''
                将相对导入from ... import 这样的路径转换为实际路径
            '''
            if level <= 2:
                return os.path.join(path, "." * level)
            # 当省略号格个数大于2时,../表示源文件所在目录的上一级目录，../../表示源文件所在目录的上上级目录，以此类推
            root = os.path.join(path, "." * 2)
            path = root
            for i in range(level - 2):
                path = os.path.join(path, '.' * 2)
            return path

        dir_path = os.path.dirname(filepath)
        # 处理相对导入的情况
        # 有相对导入
        if level is not None:
            # 相对导入不含包或模块名称
            if strutils.is_none_empty(mod_name):
                modpath = os.path.abspath(
                    get_relative_level_path(dir_path, level))
            # 相对导入含包或模块名称
            else:
                mod_relatve_path = mod_name.replace(".", os.sep)
                relative_level_path = get_relative_level_path(dir_path, level)
                modpath = os.path.abspath(os.path.join(
                    relative_level_path, mod_relatve_path)) + "." + prog_lang_ext.PYTHON_CODE_FILE_EXT[0]
                if not os.path.exists(modpath):
                    modpath = os.path.abspath(os.path.join(
                        relative_level_path, mod_relatve_path)) + os.sep + PACKAGE_INIT_FILE
                    if not os.path.exists(modpath):
                        return None
            try:
                mod_name = self.analyzer.get_relative_path(modpath)
            except Exception as ex:
                logger.error(str(ex))
                return None
        return mod_name

    def get_fromimport_modname(self, node, filepath):
        return self.relative_path_to_abs(filepath, node.modname, node.level)

    def get_api_file(self, modname):
        # 查找内建模块
        if self.analyzer.interpreter.is_builtin_module(modname):
            apifile = self.analyzer.builtin_analyzer.get_api_file(modname)
        else:
            # 查找系统路径下的模块
            apifile = self.analyzer.get_api_file(modname)
        return apifile

    def check_refmod_analyzed(self, modname, filepath, raise_exception=True):
        # 查找内建模块
        if self.analyzer.interpreter.is_builtin_module(modname):
            membersfile, memberlistfile = self.analyzer.builtin_analyzer.get_api_files(
                modname)
            ref_api_files = [[membersfile, memberlistfile]]
        else:
            # 查找解释器智能提示数据库路径下的数据文件
            # 如果是解析解释器系统路径下的文件,则从解释器智能数据路径下查找
            # 如果是项目路径下的文件,则需要解释器智能数据路径下和项目智能数据路径下2个查找
            ref_api_files = self.analyzer.get_refmod_apifiles(modname)
        ref_apifile_exist = False
        for mfile, apifile in ref_api_files:
            logger.debug('reference module %s members file is %s',
                         modname, mfile)
            if os.path.exists(mfile):
                ref_apifile_exist = True
                membersfile = mfile
                memberlistfile = apifile
                break
        if not ref_apifile_exist:
            # 导入模块不存在,返回空字符串,和下面的情况进行区分
            if self.analyzer.get_mod_file_path(modname) is None:
                logger.error(
                    'reference module %s in file %s is not found', modname, filepath)
                return '', ''
            # 导入模块存在,但是还未生成智能数据信息,可以抛出异常亦可以不抛出异常
            if raise_exception:
                raise ReferenceModuleNotAnalyzedError(
                    f'reference module {modname} has not analyzed yet in python file {filepath}')
            logger.error(
                (f'reference module {modname} has not analyzed yet in python file {filepath}'))
            return None, None
        return membersfile, memberlistfile

    def find_import_modname(self, module, importname):
        for child in module.body:
            if isinstance(child, nodes.Import):
                for name, asname in child.names:
                    if asname is not None and importname == asname:
                        return name
                    if asname is None and importname == name:
                        return name
            elif isinstance(child, nodes.ImportFrom):
                for name, asname in child.names:
                    if asname is not None and importname == asname:
                        frommodname = self.get_fromimport_modname(
                            child, child.root().file)
                        if frommodname is not None:
                            return frommodname + "." + name
                    elif asname is None and importname == name:
                        frommodname = self.get_fromimport_modname(
                            child, child.root().file)
                        if frommodname is not None:
                            return frommodname + "." + name
                    elif name == "*":
                        frommodname = self.get_fromimport_modname(
                            child, child.root().file)
                        if frommodname is None:
                            continue
                        for membersfile, memberlistfile in self.analyzer.get_refmod_apifiles(frommodname):
                            if os.path.exists(membersfile):
                                mdloader = ModuleLoader(
                                    frommodname, membersfile, memberlistfile)
                                mdloader.load()
                                data = mdloader.find_child(importname)
                                if data is None:
                                    logger.error(
                                        'could not find name %s in module %s', importname, frommodname)
                                    continue
                                return frommodname + "." + data[memberkeys.NAME_KEY_NAME]
        return None
