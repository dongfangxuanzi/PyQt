from typing import NamedTuple


class ModuleItem(NamedTuple):
    """Represents data about a file handled by pylint.

    Each file item has:
    - name: full name of the module
    - filepath: path of the file
    - modname: module name
    """
    # 应为完整的模块路径,Analyzer程序作为文件名使用,否则会导致Analyzer程序卡死
    name: str
    # 模块文件路径
    filepath: str
    # 模块名
    modname: str
