import os
import logging
import glob
import copy
from ... import get_app, _
from ...analytics.share import ShareData
from . import define
from ...util import utils, apputils, strutils
from .builtinmodule import BuiltinModule
from ...common.version import UpdateVersion

logger = logging.getLogger(__name__)


class LoadintellisenceData(ShareData):
    def __init__(self, statusbar, dataloader, interpreter):
        super().__init__(statusbar, get_app().GetDebug())
        self.statusbar = statusbar
        self._interpreter = interpreter
        self._dataloader = dataloader

    def run(self):
        self._dataloader.LoadInterperterData(self._interpreter)
        self.share()


class IntellisencedataLoader:
    def __init__(self, data_location, intellisencemanager, statusbar):
        self._data_location = data_location
        self.module_dicts = {}
        self.import_list = []
        self._builtin_module = None
        self.intellisencemanager = intellisencemanager
        self.statusbar = statusbar

    @property
    def datalocation(self):
        return self._data_location

    def LoadBuiltInData(self, interpreter):
        builtin_data_path = self.intellisencemanager.GetInterpreterBuiltinIntellisenceDataPath(
            interpreter)
        logger.info('load builtin data path:%s', builtin_data_path)
        if not os.path.exists(builtin_data_path):
            logger.error('interpreter %s builtin data path:%s is not exist',
                         interpreter.name, builtin_data_path)
        self.LoadIntellisenceDirData(interpreter, builtin_data_path, True)

    def LoadIntellisenceDirData(self, interpreter, data_path, is_builtin=False):
        # 检查加载的智能提示数据库版本号是否与当前的版本号一致
        # 如果加载的智能提示数据库版本是老版本,停止加载数据
        update_version = UpdateVersion(data_path)
        old_database_version = update_version.get_old_version()
        if old_database_version is None:
            logmsg = 'could not get interpreter %s database version'
            if is_builtin:
                logmsg = 'could not get interpreter %s builtin database version'
            utils.get_logger().error(
                logmsg,
                interpreter.name
            )
            return
        # 内建解释器数据库版本使用程序版本号
        if is_builtin and interpreter.IsBuiltIn:
            newversion = apputils.get_app_version()
        else:
            newversion = define.DATABASE_VERSION
        if update_version.need_update_version(newversion):
            utils.get_logger().error(
                'interpreter %s database version %s is deprecated,newest version is %s',
                interpreter.name,
                old_database_version,
                define.DATABASE_VERSION
            )
            return
        self.load_databases(data_path, self.module_dicts)

    @staticmethod
    def load_databases(data_path: str, modules: dict):
        name_sets = set()
        for filepath in glob.glob(os.path.join(data_path, "*" + define.MEMBERS_FILE_EXTENSION)):
            filename = os.path.basename(filepath)
            # 放弃中文模块名
            if strutils.find_chinese_character(filename):
                continue
            module_name = '.'.join(filename.split(".")[0:-1])
            utils.get_logger().debug('filename %s module name is %s', filename, module_name)
            name_sets.add(module_name)
        for name in name_sets:
            d = {
                "members": os.path.join(data_path, name + define.MEMBERS_FILE_EXTENSION),
                "apis": os.path.join(data_path, name + define.MEMBERLIST_FILE_EXTENSION)
            }
            modules[name] = d

    def Load(self, interpreter, async_load=True):
        self.statusbar.emit_statusbar_permanent_messgae(
            _("Loading intellisence database"))
        self.module_dicts.clear()
        # should copy builtin list to import_list,otherwise it will change
        # the interpreter.Builtins when load import list
        self.import_list = copy.copy(interpreter.Builtins)
        # 使用线程异步方式读取智能提示数据
        if async_load:
            LoadintellisenceData(self.statusbar, self, interpreter).start()
        else:
            # 使用同步方式读取数据,因为已经处于异步线程中了
            self.LoadInterperterData(interpreter)

    def LoadInterperterData(self, interpreter):
        self.LoadBuiltInData(interpreter)
        intellisence_data_path = self.intellisencemanager.GetInterpreterIntellisenceDataPath(
            interpreter)
        logger.info('load interpreter %s data path is %s',
                    interpreter.name, intellisence_data_path)
        if not os.path.exists(intellisence_data_path):
            logger.error('interpreter %s data path %s is not exist',
                         interpreter.name, intellisence_data_path)
        else:
            self.LoadIntellisenceDirData(interpreter, intellisence_data_path)
        self.LoadImportList(self.import_list, self.module_dicts)
        self.LoadBuiltinModule(interpreter)
        self.statusbar.emit_statusbar_messgae(
            _("Finish load intellisence database"))
        logger.info('finish load intellisence database')

    @staticmethod
    def LoadImportList(import_list: list, module_dicts: dict):
        for key in module_dicts.keys():
            if key.find(".") == -1:
                if key not in import_list:
                    import_list.append(key)
        import_list.sort()

    @property
    def ImportList(self):
        return self.import_list

    def LoadBuiltinModule(self, interpreter):
        builtin_module_loader = self.intellisencemanager.GetModule(
            define.BUILTMODULE_NAME)
        if builtin_module_loader is None:
            logger.debug(
                "could not find builtin module %s, builtin database is not success loaded",
                define.BUILTMODULE_NAME
            )
            return
        data = builtin_module_loader.load()
        self._builtin_module = BuiltinModule(builtin_module_loader.apifile)
        self._builtin_module.load(data)

    @property
    def BuiltinModule(self):
        return self._builtin_module
