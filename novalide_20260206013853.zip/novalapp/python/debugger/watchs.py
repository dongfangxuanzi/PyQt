from xml.dom.minidom import parseString
import bz2
from ... import get_app, _
from ...util import ui_utils, utils
from ...widgets.messagedialog import ScrolledMessageDialog
from ... import constants
from ...lib.pyqt import (
    QTreeWidgetItem,
    Qt,
    QRadioButton,
    QVBoxLayout,
    QSizePolicy,
    QHBoxLayout,
    QLineEdit,
    QLabel,
    QTextEdit,
    QGroupBox,
    QMessageBox
)
from . import debugcfg


def getAddWatchBitmap():
    return get_app().GetImage("python/debugger/newWatch.png")


def getQuickAddWatchBitmap():
    return get_app().GetImage("python/debugger/watch.png")


def getAddtoWatchBitmap():
    return get_app().GetImage("python/debugger/addToWatch.png")


def getClearWatchBitmap():
    return get_app().GetImage("python/debugger/delete.png")


class CommonWatcher:
    def GetItemIndex(self, parent, item):
        childcount = parent.childCount()
        for i in range(childcount):
            child = parent.child(i)
            if child == item:
                return i
        return -1

    def AppendSubTreeFromNode(self, node, name, parent, insert_before=None):
        treenode = QTreeWidgetItem()
        treenode.setText(0, name)
        if insert_before is not None:
            index = self.GetItemIndex(parent, insert_before)
            parent.insertChild(index, treenode)
        else:
            parent.addChild(treenode)
        return self.UpdateSubTreeFromNode(node, name, treenode)

    def GetNodeValueType(self, node):
        value_type = node.getAttribute("type").replace(
            'class ', "").strip("<").strip(">").strip("'")
        if value_type == debugcfg.DEBUG_UNKNOWN_VALUE_TYPE:
            value_type = _(debugcfg.DEBUG_UNKNOWN_VALUE_TYPE)
        return value_type

    def UpdateSubTreeFromNode(self, node, name, treenode, watch=False):
        '''
            单步调试过程中,不断更新监视节点的值,这个方法被监视面板和堆栈面板公用,需要通过watch参数来区分
        '''
        children = node.childNodes
        intro = node.getAttribute('intro')
        if intro == "True":
            # 这些节点只有展开时才能实时获取监视值
            self.SetItemHasChildren(treenode)
            self.SetPyData(treenode, "Introspect")
        if node.getAttribute("value"):
            treenode.setText(1, self.StripOuterSingleQuotes(
                node.getAttribute("value")))
            if watch:
                treenode.setText(2, self.GetNodeValueType(node))
        for index in range(0, children.length):
            subnode = children.item(index)
            if self.HasChildren(subnode):
                self.AppendSubTreeFromNode(
                    subnode, subnode.getAttribute("name"), treenode)
            else:
                name = subnode.getAttribute("name")
                value = self.StripOuterSingleQuotes(
                    subnode.getAttribute("value"))
                n = QTreeWidgetItem()
                n.setText(0, name)
                n.setText(1, value)
                treenode.addChild(n)
                if watch:
                    n.setText(2, self.GetNodeValueType(subnode))
                intro = subnode.getAttribute('intro')
                if intro == "True":
                    # 这些节点只有展开时才能实时获取监视值
                    self.SetItemHasChildren(n)
                    self.SetPyData(n, "Introspect")
        if name.find('[') == -1:
            self.SortChildren(treenode)
        return treenode

    def StripOuterSingleQuotes(self, string):
        if string.startswith("'") and string.endswith("'"):
            retval = string[1:-1]
        elif string.startswith("\"") and string.endswith("\""):
            retval = string[1:-1]
        else:
            retval = string
        if retval.startswith("u'") and retval.endswith("'"):
            retval = retval[1:]
        return retval

    def HasChildren(self, node):
        try:
            return node.childNodes.length > 0
        except:
            tp, val, tb = sys.exc_info()
            return False

    def SortChildren(self, node):
        # update tree
        children = []
        for i in range(node.childCount()):
            children.append(node.child(i))
        ids_sorted_by_name = sorted(children, key=self.CompareItemKey)
        node.takeChildren()
        node.addChildren(ids_sorted_by_name)

    def CompareItemKey(self, item):
        return item.text(0).upper()

    def SetPyData(self, item, data):
        item.setData(0, Qt.UserRole, data)

    def GetPyData(self, item):
        return item.data(0, Qt.UserRole)

    def SetItemHasChildren(self, item):
        child = QTreeWidgetItem()
        child.setText(0, "")
        item.addChild(child)

    def GetItemChain(self, item):
        parent_chain = []
        if item:
            utils.get_logger().debug('Exploding: %s', item.text(0))
            while item != self._root and item:
                text = item.text(0)
                utils.get_logger().debug("Appending %s,item is %s", text, item.data(0, Qt.UserRole))
                parent_chain.append(text)
                item = item.parent()
            parent_chain.reverse()
        return parent_chain

    def view_expression(self, item):
        title = item.text(0)
        value = item.text(1)
        dlg = ScrolledMessageDialog(title, value, get_app().GetTopWindow())
        dlg.exec_()

    def IntrospectCallback(self, item, is_watch=False):
        '''
            展开节点时实时获取节点的所有子节点的值
        '''
        if is_watch:
            panel = constants.WATCH_TAB_NAME
        else:
            panel = constants.STACKFRAME_TAB_NAME
        utils.get_logger().debug("In %s introspectCallback item is %s, pydata is %s",
                                 panel, item, self.GetPyData(item))
        if self.GetPyData(item) != "Introspect":
            return
        self._introspectItem = item
        self._parent_chain = self.GetItemChain(item)
        self.OnIntrospect()

    @ui_utils.wait_cursor
    def OnIntrospect(self):
        try:
            framenode = self.GetFrameNode()
            message = framenode.getAttribute("message")
            bintype = get_app().GetDebugger()._debugger_ui.framestab.attempt_introspection(
                message, self._parent_chain)
            xmldoc = bz2.decompress(bintype.data)
            domdoc = parseString(xmldoc)
            nodelist = domdoc.getElementsByTagName('replacement')
            replacement_node = nodelist.item(0)
            if len(replacement_node.childNodes):
                thing_to_walk = replacement_node.childNodes.item(0)
                parent = self._introspectItem.parent()
                treenode = self.AppendSubTreeFromNode(thing_to_walk, thing_to_walk.getAttribute(
                    'name'), parent, insertBefore=self._introspectItem)
                if thing_to_walk.getAttribute('name').find('[') == -1:
                    self.SortChildren(treenode)
                treenode.setExpanded(True)
                parent.removeChild(self._introspectItem)
        except:
            utils.get_logger().exception('')

    def GetFrameNode(self):
        assert False, "GetFrameNode not overridden"


class Watch:
    CODE_ALL_FRAMES = 0
    CODE_THIS_BLOCK = 1
    CODE_THIS_LINE = 2
    CODE_RUN_ONCE = 3

    NAME_KEY = 'name'
    EXPERSSION_KEY = 'expression'
    SHOW_CODE_FRAME_KEY = 'showcodeframe'
    # saved watches key
    WATCH_LIST_KEY = 'MasterWatches'

    def __init__(self, name, command, show_code=CODE_ALL_FRAMES):
        self._name = name
        self._command = command
        self._show_code = show_code

    @property
    def Name(self):
        return self._name

    @property
    def Expression(self):
        return self._command

    @property
    def ShowCodeFrame(self):
        return self._show_code

    @staticmethod
    def CreateWatch(name, expression):
        return Watch(name, expression)

    @classmethod
    def Dump(cls, watchs):
        watch_list = []
        for watch in watchs:
            dct = {
                cls.NAME_KEY: watch.Name,
                cls.EXPERSSION_KEY: watch.Expression,
                cls.SHOW_CODE_FRAME_KEY: watch.ShowCodeFrame,
            }
            watch_list.append(dct)
        utils.profile_set(cls.WATCH_LIST_KEY, watch_list)

    @classmethod
    def Load(cls):
        watch_list = utils.profile_get(cls.WATCH_LIST_KEY, [])
        watchs = []
        for dct in watch_list:
            watch = Watch(dct[cls.NAME_KEY], dct[cls.EXPERSSION_KEY], dct.get(
                cls.SHOW_CODE_FRAME_KEY, cls.CODE_ALL_FRAMES))
            watchs.append(watch)
        return watchs

    def IsRunOnce(self):
        return self.ShowCodeFrame == self.CODE_RUN_ONCE


class WatchDialog(ui_utils.BaseModalDialog):
    WATCH_ALL_FRAMES = "Watch in all frames"
    WATCH_THIS_FRAME = "Watch in this frame only"
    WATCH_ONCE = "Watch once and delete"

    def __init__(self, parent, title, chain, is_quick_watch=False, watch_obj=None):
        super().__init__(title, parent)
        self._chain = chain
        self._is_quick_watch = is_quick_watch
        self._watch_obj = watch_obj
        self._watch_frame_type = Watch.CODE_ALL_FRAMES
        row = QHBoxLayout()
        row.addWidget(QLabel(_("Watch name") + ":"))

        self._watchname_textctrl = QLineEdit()
        self._watchname_textctrl.setSizePolicy(QSizePolicy.Expanding,
                                               QSizePolicy.Fixed)
        row.addWidget(self._watchname_textctrl)
        self.layout.addLayout(row)
        self._watchname_textctrl.textChanged.connect(self.set_name_expresstion)

        self.layout.addWidget(QLabel(_("Expression") + ":"))
        self._watchvalue_textctrl = QTextEdit()
        self._watchvalue_textctrl.setSizePolicy(QSizePolicy.Expanding,
                                                QSizePolicy.Expanding)
        self.layout.addWidget(self._watchvalue_textctrl)
        if is_quick_watch:
            self._watchvalue_textctrl.setEnabled(False)
        sbox_frame = QGroupBox(_("Watch information"))
        sbox_layout = QVBoxLayout()
        self.watchs_all_radio = QRadioButton(WatchDialog.WATCH_ALL_FRAMES)
        sbox_layout.addWidget(self.watchs_all_radio)

        self.watchs_this_radio = QRadioButton(WatchDialog.WATCH_THIS_FRAME)
        sbox_layout.addWidget(self.watchs_this_radio)

        self.watchs_once_radio = QRadioButton(WatchDialog.WATCH_ONCE)
        sbox_layout.addWidget(self.watchs_once_radio)
        sbox_frame.setLayout(sbox_layout)
        self.layout.addWidget(sbox_frame)

        self.create_standard_buttons()
        self.__set_properties()

    def GetSettings(self):
        if self.watchs_all_radio.isChecked():
            watch_code_frame = Watch.CODE_ALL_FRAMES
        elif self.watchs_this_radio.isChecked():
            watch_code_frame = Watch.CODE_THIS_LINE
        elif self.watchs_once_radio.isChecked():
            watch_code_frame = Watch.CODE_RUN_ONCE
        return Watch(self._watchname_textctrl.text(), self.expresstion, watch_code_frame)

    def GetSendFrame(self):
        return WatchDialog.WATCH_ALL_FRAMES != self.radio_box_1.GetStringSelection()

    def GetRunOnce(self):
        return WatchDialog.WATCH_ONCE == self.radio_box_1.GetStringSelection()

    def __set_properties(self):
        if self._watch_obj is not None:
            self._watch_frame_type = self._watch_obj.ShowCodeFrame
            self._watchname_textctrl.setText(self._watch_obj.Name)
            self._watchvalue_textctrl.setText(self._watch_obj.Expression)
        if self._watch_frame_type == Watch.CODE_ALL_FRAMES:
            self.watchs_all_radio.setChecked(True)
        if self._watch_frame_type == Watch.CODE_THIS_LINE:
            self.watchs_this_radio.setChecked(True)
        if self._watch_frame_type == Watch.CODE_RUN_ONCE:
            self.watchs_once_radio.setChecked(True)

    def set_name_expresstion(self, *args):
        if self._is_quick_watch:
            self._watchvalue_textctrl.setEnabled(True)
            self._watchvalue_textctrl.setText(self._watchname_textctrl.text())
            self._watchvalue_textctrl.setEnabled(False)

    def _ok(self):
        if self._watchname_textctrl.text().strip() == "":
            QMessageBox.information(
                get_app().GetTopWindow(),
                _("Add a watch"),
                _("You must enter a name for the watch.")
            )
            return
        if self._watchvalue_textctrl.toPlainText() == "":
            QMessageBox.information(
                get_app().GetTopWindow(),
                _("Add a watch"),
                _("You must enter some code to run for the watch.")
            )
            return
        self.expresstion = self._watchvalue_textctrl.toPlainText()
        super()._ok()
