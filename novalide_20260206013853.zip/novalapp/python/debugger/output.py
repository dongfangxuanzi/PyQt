# -*- coding: utf-8 -*-
from ...debugger.debug import DebugCtrl, DebugFrame
from ...widgets.textedit import JumpoPythoncodeFile


class DebugOutputctrl(DebugCtrl, JumpoPythoncodeFile):
    def __init__(self, parent, is_debug=False, **kwargs):
        DebugCtrl.__init__(self, parent, **kwargs)
        self._is_debug = is_debug

    def mouseDoubleClickEvent(self, event):
        # Looking for a stack trace line.
        line = self.get_current_line()
        line_text = self.get_line(line, last_append_linend=False).rstrip()
        jump_to_line = self.jumpto_line(line_text)
        if not jump_to_line:
            last_line_text = self.get_line(
                line - 1, last_append_linend=False).rstrip()
            jump_to_line = self.jumpto_line(last_line_text)
        # 如果找到代码行,则跳转到代码行,高亮代码行,否则激活调试窗口
        if not jump_to_line:
            # last activiate debug view
            self.ActivateView()
            # 继续执行原有的双击事件
        super().mouseDoubleClickEvent(event)

        # python程序崩溃有3种错误方式
        # 1:主程序报错
        # 2:线程报错
        # 3:语法错误

        # 这是线程错误格式
        # Thread 0x00001704 (most recent call first):
        #  File "D:\env\project\Noval\noval\launcher.py", line 33 in run

        # 这是主程序报错格式
        # Traceback (most recent call last):
        # File "D:\env\project\Noval\noval\ui_base.py", line 572, in _dispatch_tk_operation

        # 这是语法错误格式
        # File "D:\env\project\Noval\tests\test_utils.py", line 15


class DebugOutputView(DebugFrame):
    def __init__(self, master, is_debug=False):
        DebugFrame.__init__(self, master)

    def GetOuputctrlClass(self):
        return DebugOutputctrl
