# -*- coding: utf-8 -*-
'''
----------------------------------------------------------------------------
Name:         DebuggerService.py
Purpose:      Debugger Service for Python and PHP

Author:       Matt Fryer

Created:      12/9/04
CVS-ID:       $Id$
Copyright:    (c) 2004-2005 ActiveGrid, Inc.
License:      wxWindows License
----------------------------------------------------------------------------
'''
import traceback
import sys
import os
from ... import get_app, _
from ...debugger.debugger import *
from ...lib.pyqt import (
    pyqtSlot,
    QPixmap,
    QDialog,
    QIcon,
    QMessageBox,
    QHBoxLayout,
    QLineEdit,
    QIntValidator,
    QColor,
    QColorDialog,
    QPushButton,
    Qt,
    QFrame,
    QVBoxLayout,
    QLabel,
    QGridLayout,
    QSpinBox,
    QCheckBox,
    QSizePolicy
)
from .commandui import RunCommandUI, PythonDebuggerUI, BaseDebuggerUI, show_breakdebug_views
from .executor import PythonExecutor
from ...util import ui_utils, utils, fileutils
from ..ui import ParserErrorsDialog
from ... import globalkeys, constants
from . import debugcfg as debugconfig
from ... import menuitems
from ...bars.menubar import find_menu
from ..interpreter.exceptions import UnParseableSyntaxMessage


class PythonDebugger(Debugger):
    # ----------------------------------------------------------------------------
    # Constants
    # ----------------------------------------------------------------------------
    RUN_PARAMETERS = []
    # 异常中断列表
    EXCEPTIONS = []
    # 调试器只允许运行一个
    _debugger_ui = None

    # ----------------------------------------------------------------------------
    # Overridden methods
    # ----------------------------------------------------------------------------

    def __init__(self):
        Debugger.__init__(self)
        self._frame = None
        self._watch_separater = None

    @classmethod
    def CloseDebugger(cls):
        try:
            if cls._debugger_ui is not None:
                # 保存监视信息
                cls._debugger_ui.framestab.watchsTab.SaveWatchs()
                # 保存断点信息
                cls._debugger_ui.framestab.breakPointsTab.SaveBreakpoints()
            if not RunCommandUI.StopAndRemoveAllUI():
                return False
        except:
            tp, val, tb = sys.exc_info()
            traceback.print_exception(tp, val, tb)
        return True

    @classmethod
    def SetDebuggerUI(cls, debugger_ui):
        cls._debugger_ui = debugger_ui

    def GetExceptions(self):
        return PythonDebugger.EXCEPTIONS

    def SetExceptions(self, exceptions):
        PythonDebugger.EXCEPTIONS = exceptions

    # ----------------------------------------------------------------------------
    # Service specific methods
    # ----------------------------------------------------------------------------
    # ----------------------------------------------------------------------------
    # Class Methods
    # ----------------------------------------------------------------------------

    @ui_utils.update_toolbar
    def CheckScript(self):
        def showParsingErrors(path, errorfile, errors, parent):
            """Fires the show errors dialog window"""
            dialog = ParserErrorsDialog(path, errors, parent, errorfile)
            dialog.exec_()

        if not PythonExecutor.GetPythonExecutablePath():
            return
        interpreter = get_app().GetCurrentInterpreter()
        doc_view = self.GetActiveView()
        if not doc_view:
            return
        document = doc_view.GetDocument()
        if not document.Save() or document.IsNewDocument:
            return
        if not os.path.exists(interpreter.path):
            QMessageBox.information(
                doc_view.GetFrame(),
                _("Interpreter not exists"),
                _("Could not find '%s' on the path.") % interpreter.path
            )
            return
        try:
            ok, filename, line, msg = interpreter.check_syntax(
                document.GetFilename())
            if ok:
                QMessageBox.information(
                    doc_view.GetFrame(), get_app().GetAppName(), _("Check syntax ok!"))
                return
            showParsingErrors(document.GetFilename(), filename,
                              msg, parent=doc_view.GetFrame())
            # 语法错误文件和实际代码文件不一样
            if filename and not fileutils.ComparePath(document.GetFilename(), filename):
                doc_view = get_app().GotoView(filename)
            if line > 0:
                doc_view.GotoLine(line)
        except UnParseableSyntaxMessage as error:
            utils.get_logger().error(
                "Could not parse syntax error message `%s` of interpreter `%s`",
                str(error),
                interpreter.path
            )
            QMessageBox.critical(
                doc_view.GetFrame(),
                _("Error"),
                str(error)
            )

    def Runfile(self, file_to_run=None):
        self.GetCurrentProject().Run(file_to_run)

    @catch_run_exception
    def RunWithoutDebug(self, filetoRun=None):
        self.GetCurrentProject().RunWithoutDebug(filetoRun)

    @catch_run_exception
    def RunLast(self):
        self.GetCurrentProject().RunLast()

    @catch_run_exception
    def DebugLast(self):
        self.GetCurrentProject().DebugRunLast()

    @catch_run_exception
    def RunLast(self):
        self.GetCurrentProject().RunLast()

    def StepNext(self):
        # 如果调试器在运行,则执行单步调试
        if BaseDebuggerUI.DebuggerRunning():
            self._debugger_ui.OnNext()
        else:
            # 否则进入断点调试并在开始出中断
            self.GetCurrentProject().BreakintoDebugger()

    def StepInto(self):
        # 如果调试器在运行,则执行调试方法
        if BaseDebuggerUI.DebuggerRunning():
            self._debugger_ui.OnSingleStep()
        else:
            # 否则进入断点调试并在开始出中断
            self.GetCurrentProject().BreakintoDebugger()

    def SetParameterAndEnvironment(self):
        self.GetCurrentProject().SetParameterAndEnvironment()

    def AppendRunParameter(self, run_paramteter):
        if len(self.RUN_PARAMETERS) > 0:
            self.GetCurrentProject().SaveRunParameter(self.RUN_PARAMETERS[-1])
        self.RUN_PARAMETERS.append(run_paramteter)

    def IsFileContainBreakPoints(self, document):
        '''
            判断单个文件是否包含断点信息
        '''
        doc_path = document.GetFilename()
        master_bp_dict = get_app().MainFrame.GetView(
            constants.BREAKPOINTS_TAB_NAME).GetMasterBreakpointDict()
        if doc_path in master_bp_dict and len(master_bp_dict[doc_path]) > 0:
            return True
        return False

    def CreateDebuggerMenuItem(self, runmenu, menu_id, text, image, handler, menu_index):
        '''
            添加断点调式菜单项,如果菜单项已经存在不能重复添加
        '''
        if not runmenu.FindMenuItem(menu_id):
            runmenu.Insert(menu_index, menu_id, text,
                           img=image, handler=handler)

    def DeleteDebuggerMenuItem(self, runmenu, menu_id):
        '''
            删除断点调式菜单项,只有在菜单项已经存在时才能删除
        '''
        if runmenu.FindMenuItem(menu_id):
            menu_index = runmenu.GetMenuIndex(menu_id)
            runmenu.delete(menu_index, menu_index)

    def ShowHideDebuggerMenu(self, show=True):
        run_menu = find_menu(_("&Run"), get_app().Menubar)
        if show:
            menu_index = 3
            self.CreateDebuggerMenuItem(run_menu, menuitems.ID_RESTART_DEBUGGER, _(
                "&Restart"), self._debugger_ui.restart_bmp, self._debugger_ui.RestartDebugger, menu_index)
            self.CreateDebuggerMenuItem(run_menu, menuitems.ID_TERMINATE_DEBUGGER, _(
                "&Stop Debugging"), self._debugger_ui.stop_bmp, self._debugger_ui.StopExecution, menu_index)
            self.CreateDebuggerMenuItem(run_menu, menuitems.ID_BREAK_INTO_DEBUGGER, _(
                "&Break"), self._debugger_ui.break_bmp, self._debugger_ui.BreakExecution, menu_index)
            self.CreateDebuggerMenuItem(run_menu, menuitems.ID_STEP_CONTINUE, _(
                "&Continue"), self._debugger_ui.continue_bmp, self._debugger_ui.OnContinue, menu_index)
            self.CreateDebuggerMenuItem(run_menu, menuitems.ID_STEP_OUT, _(
                "&Step Out"), self._debugger_ui.stepout_bmp, self._debugger_ui.OnStepOut, 11)
            self.CreateDebuggerMenuItem(run_menu, menuitems.ID_QUICK_ADD_WATCH, _(
                "&Quick add Watch"), self._debugger_ui.quick_watch_bmp, self._debugger_ui.OnQuickAddWatch, 12)
            self.CreateDebuggerMenuItem(run_menu, menuitems.ID_ADD_WATCH, _(
                "&Add Watch"), self._debugger_ui.watch_bmp, self._debugger_ui.OnAddWatch, 13)
            show_breakdebug_views(True)
        else:
            self.DeleteDebuggerMenuItem(run_menu, menuitems.ID_STEP_OUT)
            self.DeleteDebuggerMenuItem(
                run_menu, menuitems.ID_TERMINATE_DEBUGGER)
            self.DeleteDebuggerMenuItem(run_menu, menuitems.ID_STEP_CONTINUE)
            self.DeleteDebuggerMenuItem(
                run_menu, menuitems.ID_BREAK_INTO_DEBUGGER)
            self.DeleteDebuggerMenuItem(
                run_menu, menuitems.ID_RESTART_DEBUGGER)
            self.DeleteDebuggerMenuItem(run_menu, menuitems.ID_ADD_WATCH)
            self.DeleteDebuggerMenuItem(run_menu, menuitems.ID_QUICK_ADD_WATCH)
            show_breakdebug_views(False)

    def AddtoWatchText(self, text):
        self._debugger_ui.framestab.AddtoWatchExpression(text, text)

    def AddWatchText(self, text, quick_watch=False):
        self._debugger_ui.framestab.AddWatchExpression(text, text, quick_watch)


class DebuggerOptionsPanel(ui_utils.BaseConfigurationPanel):
    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.layout.setAlignment(Qt.AlignTop)
        self.disable_edit_chk_box = QCheckBox(
            _("Disable edit code file When debugger is running"))
        self.disable_edit_chk_box.setChecked(utils.profile_get_int(
            globalkeys.DISABLE_EDIT_WHEN_DEBUGGERING_KEY, True))
        self.layout.addWidget(self.disable_edit_chk_box)

        self.show_tip_value_chk_box = QCheckBox(
            _("Show memory value when mouse hover over word while debugger is running"))
        self.show_tip_value_chk_box.setChecked(
            utils.profile_get_int(globalkeys.SHOW_TIPVALUE_WHEN_DEBUGGING_KEY, True))
        self.layout.addWidget(self.show_tip_value_chk_box)

        hbox = QHBoxLayout()
        hbox.addWidget(QLabel(_("Local host name") + ":"))
        self._localhost_textctrl = QLineEdit()
        self._localhost_textctrl.setText(utils.profile_get(
            "DebuggerHostName", debugconfig.DEFAULT_HOST))
        hbox.addWidget(self._localhost_textctrl)
        self.layout.addLayout(hbox)

        hbox = QHBoxLayout()
        hbox.addWidget(QLabel(_("Port range") + ":"))
        starting_port = utils.profile_get_int(
            "DebuggerStartingPort", debugconfig.DEFAULT_PORT)
        max_ending_port = 60000

        self._portnumber_textctrl = QLineEdit()
        # 验证端口文本控件输入是否合法,端口只能输入数字
        intvalidator = QIntValidator(starting_port, max_ending_port, self)
        hbox.addWidget(self._portnumber_textctrl)
        intvalidator.setRange(starting_port, max_ending_port)
        self._portnumber_textctrl.setValidator(intvalidator)
        self._portnumber_textctrl.setText(str(starting_port))

        hbox.addWidget(QLabel(_("Through to")))
        self._endportnumber_textctrl = QLineEdit()
        self._endportnumber_textctrl.setText(
            str(starting_port + debugconfig.PORT_COUNT))
        self._endportnumber_textctrl.setEnabled(False)
        hbox.addWidget(self._endportnumber_textctrl)
        self.layout.addLayout(hbox)
        self._portnumber_textctrl.textChanged.connect(self.minport_change)

        self._flushports_button = QPushButton(_("Reset port list"))
        self._flushports_button.clicked.connect(self.FlushPorts)
        self._flushports_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.layout.addWidget(self._flushports_button)

    def validatePortInput(self, contents):
        if not contents.isdigit():
            self._portnumber_textctrl.bell()
            self._endportnumber_textctrl.bell()
            return False
        return True

    def IsStartportInbounds(self):
        if int(self._portnumber_textctrl.text()) >= 1 and int(self._portnumber_textctrl.text()) <= 65514:
            return True
        return False

    def IsEndportInbounds(self):
        if int(self._endportnumber_textctrl.text()) >= 22 and int(self._endportnumber_textctrl.text()) <= 65535:
            return True
        return False

    def FlushPorts(self):
        if self.IsStartportInbounds():
            utils.profile_set("DebuggerStartingPort",
                              int(self._portnumber_textctrl.text()))
            PythonDebuggerUI.NewPortRange()
        else:
            QMessageBox.information(
                self,
                _("Invalid Starting Port Number"),
                _("The starting port is not valid. Please change the value and try again.")
            )

    def minport_change(self, *args):
        self._endportnumber_textctrl.setEnabled(True)
        end_port_value = int(self._portnumber_textctrl.text()
                             ) + debugconfig.PORT_COUNT
        self._endportnumber_textctrl.setText(str(end_port_value))
        self._endportnumber_textctrl.setEnabled(False)

    def OnOK(self, options_dialog):
        if self.IsStartportInbounds():
            utils.profile_set("DebuggerStartingPort", int(
                self._portnumber_textctrl.text()))
        else:
            QMessageBox.critical(self, _("Error"), _(
                "Debugger start port is out of range"))
            return False

        if not self.IsEndportInbounds():
            QMessageBox.critical(self, _("Error"), _(
                "Debugger end port is out of range"))
            return False
        utils.profile_set("DebuggerHostName", self._localhost_textctrl.text())
        utils.profile_set(globalkeys.DISABLE_EDIT_WHEN_DEBUGGERING_KEY,
                          self.disable_edit_chk_box.isChecked())
        utils.profile_set(globalkeys.SHOW_TIPVALUE_WHEN_DEBUGGING_KEY,
                          self.show_tip_value_chk_box.isChecked())
        return True

    def GetIcon(self):
        return getContinueIcon()


class OutputOptionsPanel(ui_utils.BaseConfigurationPanel):
    def __init__(self, parent):
        super().__init__()
        self.__coloursDict = {}
        self.layout.setAlignment(Qt.AlignTop)
        self.wrap_chk_box = QCheckBox(_("Word wrap"))
        self.wrap_chk_box.setChecked(utils.profile_get_int(
            globalkeys.OUTPUT_WORDWRAP_KEY, False))
        self.layout.addWidget(self.wrap_chk_box)

        self.limit_chk_box = QCheckBox(_("Limit console line output"))
        self.limit_chk_box.clicked.connect(self.CheckLimitLine)
        self.limit_chk_box.setChecked(utils.profile_get_int(
            globalkeys.OUTPUT_LIMIT_LINELENGTH_KEY, True))
        self.layout.addWidget(self.limit_chk_box)

        limit_line_length = utils.profile_get_int(
            globalkeys.MAX_OUTPUT_LINELENGTH_KEY, constants.MAX_OUTPUT_LINELENGTH)
        limit_hbox = QHBoxLayout()
        limit_hbox.setAlignment(Qt.AlignLeft)
        self.limit_ctrl = QSpinBox(
            value=limit_line_length,
            maximum=constants.MAX_OUTPUT_LINELENGTH,
            minimum=500,
            singleStep=10
        )
        self.limit_ctrl.setValue(limit_line_length)
        self.limit_ctrl.setToolTip(
            _('NB!Maximum value is %d, Large values may cause poor performance!') % constants.MAX_OUTPUT_LINELENGTH
        )
        limit_hbox.addWidget(
            QLabel(_("Console line length(characters)") + ":"))
        limit_hbox.addWidget(self.limit_ctrl)
        self.layout.addLayout(limit_hbox)

        self.CheckLimitLine()

        self.starts_up_chkbox = QCheckBox(
            _("The program starts up with an actual execution command")
        )
        self.starts_up_chkbox.setChecked(utils.profile_get_int(
            globalkeys.START_UP_COMMAND_KEY, False))
        self.layout.addWidget(self.starts_up_chkbox)

        self.output_exitcode_chkbox = QCheckBox(
            _("The program exits with an additional exit code")
        )
        self.output_exitcode_chkbox.setChecked(utils.profile_get_int(
            globalkeys.OUTPUT_EXITCODE_KEY, False))
        self.layout.addWidget(self.output_exitcode_chkbox)
        color_grid_layout = QGridLayout()
        color_grid_layout.setAlignment(Qt.AlignLeft)
        self._output_color_button = QPushButton()
        color_grid_layout.addWidget(
            QLabel(_("Standard Output text color") + ":"), 0, 0)
        color_grid_layout.addWidget(self._output_color_button, 0, 1)
        self.init_colour(globalkeys.OUTPUT_STANDARD_OUTPUT_COLOR_KEY, get_app(
        ).skin['ioconsoleColor'].name(), self._output_color_button)

        self._error_color_button = QPushButton()
        color_grid_layout.addWidget(
            QLabel(_("Standard Error text color") + ":"), 1, 0)
        color_grid_layout.addWidget(self._error_color_button, 1, 1)
        self.init_colour(globalkeys.OUTPUT_STANDARD_ERROR_COLOR_KEY, get_app(
        ).skin['ioconsoleStderrColor'].name(), self._error_color_button)

        self._input_color_button = QPushButton()
        color_grid_layout.addWidget(
            QLabel(_("Standard Input text color") + ":"), 2, 0)
        color_grid_layout.addWidget(self._input_color_button, 2, 1)
        self.init_colour(globalkeys.OUTPUT_STANDARD_INPUT_COLOR_KEY, get_app(
        ).skin['ioconsoleStdinColor'].name(), self._input_color_button)
        self.layout.addLayout(color_grid_layout)

    def init_colour(self, colourkey, default_color, button, byname=False, has_alpha=False):
        """
        Public method to initialize a colour selection button.

        @param colourKey key of the colour resource (string)
        @param button reference to a button to show the colour on (QPushButton)
        @param prefMethod preferences method to get the colour
        @param byName flag indicating to retrieve/save by colour name
            (boolean)
        @param hasAlpha flag indicating to allow alpha channel (boolean)
        """
        colour = QColor(utils.profile_get(colourkey, default_color))
        button.setFixedSize(100, 23)
        size = button.size()
        pm = QPixmap(size.width() // 2, size.height() // 2)
        pm.fill(colour)
        button.setIconSize(pm.size())
        button.setIcon(QIcon(pm))
        button.setProperty("colorKey", colourkey)
        button.setProperty("hasAlpha", has_alpha)
        button.clicked.connect(lambda: self.__select_colour_slot(button))
        self.__coloursDict[colourkey] = [colour, byname]

    @pyqtSlot()
    def __select_colour_slot(self, button):
        """
        Private slot to select a color.

        @param button reference to the button been pressed
        @type QPushButton
        """
        colourkey = button.property("colorKey")
        has_alpha = button.property("hasAlpha")

        coldlg = QColorDialog(self)
        if has_alpha:
            coldlg.setOptions(QColorDialog.ColorDialogOption.ShowAlphaChannel)
        # Set current color last to avoid conflicts with alpha channel
        coldlg.setCurrentColor(self.__coloursDict[colourkey][0])
        coldlg.exec()

        if coldlg.result() == QDialog.DialogCode.Accepted:
            colour = coldlg.selectedColor()
            size = button.iconSize()
            pm = QPixmap(size.width(), size.height())
            pm.fill(colour)
            button.setIcon(QIcon(pm))
            self.__coloursDict[colourkey][0] = colour

        # Update color selection
    #    self.colourChanged.emit(colorKey, self.__coloursDict[colorKey][0])

    def CheckLimitLine(self):
        if not self.limit_chk_box.isChecked():
            self.limit_ctrl.setEnabled(False)
        else:
            self.limit_ctrl.setEnabled(True)

    def OnOK(self, optionsDialog):
        utils.profile_set(globalkeys.OUTPUT_WORDWRAP_KEY,
                          self.wrap_chk_box.isChecked())
        utils.profile_set(globalkeys.OUTPUT_LIMIT_LINELENGTH_KEY,
                          self.limit_chk_box.isChecked())
        if self.limit_chk_box.isChecked() and self.limit_ctrl.value() < 500:
            QMessageBox.information(self, get_app().GetAppName(), _(
                'Max line length must greater then 500'))
            return False
        utils.profile_set(globalkeys.MAX_OUTPUT_LINELENGTH_KEY,
                          self.limit_ctrl.value())
        utils.profile_set(
            globalkeys.OUTPUT_EXITCODE_KEY,
            self.output_exitcode_chkbox.isChecked()
        )

        utils.profile_set(
            globalkeys.START_UP_COMMAND_KEY,
            self.starts_up_chkbox.isChecked()
        )
        self.save_colours()
        views = get_app().MainFrame.GetViews()
        # 将输出颜色设置应用到所有输出窗口
        for view_name in views:
            if view_name.find("Debugger") != -1:
                view = views[view_name]
                instance = view["instance"]
                instance.GetOutputCtrl().update_config_styles()
        return True

    def save_colours(self):
        """
        Public method to save the colour selections.

        @param prefMethod preferences method to set the colour
        """
        for key in self.__coloursDict:
            utils.profile_set(key, self.__coloursDict[key][0].name())


class RunOptionsPanel(ui_utils.BaseConfigurationPanel):
    def __init__(self, parent):
        super().__init__()
        self.layout.setAlignment(Qt.AlignTop)
        self.keep_pause_chk_box = QCheckBox(
            _("Keep terminal window pause after python process ends"))
        self.keep_pause_chk_box.setChecked(utils.profile_get_int(
            globalkeys.KEEP_TERMINAL_PAUSE_KEY, True))
        self.layout.addWidget(self.keep_pause_chk_box)

    def OnOK(self, optionsDialog):
        utils.profile_set(globalkeys.KEEP_TERMINAL_PAUSE_KEY,
                          self.keep_pause_chk_box.isChecked())
        return True
