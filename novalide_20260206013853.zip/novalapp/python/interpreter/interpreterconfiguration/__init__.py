# -*- coding: utf-8 -*-
from .... import _, get_app
from .pythonbuiltins import PythonBuiltinsPanel
from .environment import EnvironmentPanel
from .pythonpackages import PackagePanel
from .pythonpath import PythonPathPanel
from ....util import ui_utils
from ....lib.pyqt import (
    QTabWidget,
    QCheckBox,
    QMessageBox,
    QVBoxLayout,
    Qt,
    QLabel,
    QSizePolicy,
    QLineEdit,
    QHBoxLayout,
    QPushButton
)
from .... import qtimage
from ..combo import InterpreterComboBox


class InterpreterConfigurationPanel(ui_utils.BaseConfigurationPanel):
    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        interpreter_box = QHBoxLayout()
        interpreter_box.setAlignment(Qt.AlignLeft)
        interpreter_box.addWidget(QLabel(_("Interpreter") + ":"))
        self.interpreters_combo = InterpreterComboBox()
        self.interpreters_combo.currentIndexChanged.connect(
            self.selectinterpreter)
        interpreter_box.addWidget(self.interpreters_combo)
        self.layout.addLayout(interpreter_box)

        self.nb = QTabWidget()

        self.package_icon = qtimage.load_icon("project/python/package_obj.gif")
        self.search_path_icon = qtimage.load_icon("python/jar_l_obj.gif")
        self.builtin_icon = qtimage.load_icon("python/builtin.png")
        self.environment_icon = qtimage.load_icon("environment.png")

        self.package_panel = PackagePanel(self.nb)
        index = self.nb.addTab(self.package_panel, _("Packages"))
        self.nb.setTabIcon(index, self.package_icon)

        self.path_panel = PythonPathPanel(self.nb)
        index = self.nb.addTab(self.path_panel, _("Search path"))
        self.nb.setTabIcon(index, self.search_path_icon)

        self.builtin_panel = PythonBuiltinsPanel(self.nb)
        index = self.nb.addTab(self.builtin_panel, _("Builtin modules"))
        self.nb.setTabIcon(index, self.builtin_icon)

        self.environment_panel = EnvironmentPanel(self.nb)
        index = self.nb.addTab(self.environment_panel,
                               _("Environment variables"))
        self.nb.setTabIcon(index, self.environment_icon)
        self.layout.addWidget(self.nb)
        self.selectinterpreter(self.interpreters_combo.currentIndex())
        self._interpreters = []
        self._current_interpreter = None
       # self.ScanAllInterpreters()
       # self.UpdateUI()
        self.menu = None

    def selectinterpreter(self, i):
        if i == -1:
            return
        interpreter = self.interpreters_combo.get_interpreter(i)
        for index in range(self.nb.count()):
            page = self.nb.widget(index)
            page.set_interpreter(interpreter)
            page.update_ui()

    def OnOK(self, options_dialog):
        # 如果加载包信息的线程仍在运行,强制退出
        if self.package_panel.packages_load_thread is not None:
            self.package_panel.stop_load_packages()
        is_pythonpath_changed = self.path_panel.CheckPythonPathList()
        self._configuration_changed = self._configuration_changed or is_pythonpath_changed
        is_environment_changed = self.environment_panel.CheckEnviron()
        self._configuration_changed = self._configuration_changed or is_environment_changed
        return True

    def OnCancel(self, options_dialog):
        # 如果加载包信息的线程仍在运行,强制退出
        if self.package_panel.packages_load_thread is not None:
            self.package_panel.stop_load_packages()
        self._configuration_changed = self._configuration_changed or self.path_panel.CheckPythonPath()
        self._configuration_changed = self._configuration_changed or self.environment_panel.CheckEnviron()
        if self._configuration_changed:
            ret = QMessageBox.question(
                self,
                _("Save configuration"),
                _("Interpreter configuration has already been modified outside,Do you want to save?")
            )
            if ret == QMessageBox.Yes:
                self.OnOK(options_dialog)
        return True
