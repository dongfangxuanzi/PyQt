# -*- coding: utf-8 -*-
import subprocess
import os
from .... import _, get_app
from ....util import utils, strutils
from ....lib.pyqt import (
    pyqtSignal,
    Qt,
    QFileDialog,
    QHBoxLayout,
    QVBoxLayout,
    QTableWidget,
    QPushButton,
    QMessageBox,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView
)
from .interpreterpanel import BaseInterpreterPanel
from ..base import Interpreter
from .pipenv import InstallPackagesDialog, UninstallPackagesDialog
from .packagesloader import PackagesLoader
from ..exceptions import InterpreterPipNotFoundError


def get_package_versions(name):
    '''
    '''
    # Fetch info from novalide server
    api_addr = '%s/member/get_package' % (UserDataDb.HOST_SERVER_ADDR)
    data = utils.RequestData(api_addr, method='get', arg={'name': name})
    if not data:
        # 未能从服务器上找到包
        return []
    return sorted(data['releases'])


class SortHeaderView(QHeaderView):
    '''可排序的表格头部'''

    def mouseReleaseEvent(self, event):
        index = self.visualIndexAt(event.pos().x())
        logical_index = self.logicalIndex(index)
        # 只允许第1列可排序
        if logical_index == 0:
            super().mouseReleaseEvent(event)


class PackagePanel(BaseInterpreterPanel):
    sigLoadPackagesFinished = pyqtSignal(Interpreter, str)

    def __init__(self, parent):
        BaseInterpreterPanel.__init__(self, parent)
        columns = [_('Name'), _('Version')]
        # 加载包信息的线程对象,比较耗时
        self.packages_load_thread = None
        h_box = QHBoxLayout()
        self.tableview = QTableWidget(1, len(columns), self)
        self.tableview.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableview.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableview.setAlternatingRowColors(True)
        # 初始化可排序的头部
        self.header = SortHeaderView(Qt.Horizontal)
        self.header.setSectionsClickable(True)
        self.tableview.setHorizontalHeader(self.header)
        self.tableview.setSortingEnabled(True)

        self.tableview.verticalHeader().hide()
        self.tableview.setHorizontalHeaderLabels(columns)
        self.tableview.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        h_box.addWidget(self.tableview)
        # 设置第一列可排序,且必须设置为倒序
        # 设置为DescendingOrder还是AscendingOrder和插入表格数据方式有关
        # 这里插入数据的方式要求必须采用DescendingOrder才行
        self.column_sort_order = Qt.DescendingOrder
        self.tableview.sortByColumn(0, self.column_sort_order)

        self.buttonbox = QVBoxLayout()
        self.buttonbox.setAlignment(Qt.AlignTop)
        # 设置内容边距,四个参数是边距顺时针,从左开始,左边距为0
        self.buttonbox.setContentsMargins(0, 5, 5, 5)
        self.install_btn = QPushButton(_("Install"))
        self.install_btn.clicked.connect(self.InstallPip)
        self.buttonbox.addWidget(self.install_btn)

        self.uninstall_btn = QPushButton(_("Uninstall"))
        self.uninstall_btn.clicked.connect(self.UninstallPip)
        self.buttonbox.addWidget(self.uninstall_btn)

        self.freeze_btn = QPushButton(_("Freeze"))
        self.freeze_btn.clicked.connect(self.__freeze_package)
        self.buttonbox.addWidget(self.freeze_btn)
        self.fixpip_btn = None
        h_box.addLayout(self.buttonbox)
        self.layout.addLayout(h_box)
        self.update_ui()
        self.sigLoadPackagesFinished.connect(self.LoadPackageEnd)

    def add_fixpip_button(self):
        if self.fixpip_btn is None:
            self.fixpip_btn = QPushButton(_("Fix pip"))
            self.fixpip_btn.clicked.connect(self.fix_pip)
        self.buttonbox.addWidget(self.fixpip_btn)
        self.fixpip_btn.setVisible(True)

    def remove_fixpip_button(self):
        if self.fixpip_btn is not None:
            self.buttonbox.removeWidget(self.fixpip_btn)
            self.fixpip_btn.setVisible(False)

    def fix_pip(self):
        exitcode, output = self._interpreter.exec_command_exit_output(
            '-m ensurepip --default-pip'
        )
        utils.get_logger().info(
            "ensurepip command exit code is %d, output is %s",
            exitcode,
            output
        )
        self.LoadPackages(reload=True)

    def InstallCallback(self, python_package, interpreter):
        '''
            安装完后如果包已经存在,则删除已有包
        '''
        # 必须首先更新表头的排序方式
        self.column_sort_order = self.tableview.horizontalHeader().sortIndicatorOrder()
        if python_package:
            # 如果包已经存在,删除现有包,添加包信息
            self.RemovePackage(python_package.name, interpreter)
            interpreter.Packages[python_package.name] = python_package
            self.LoadPackageList(self._interpreter)
            # 定位到包行
            items = self.tableview.findItems(
                python_package.name, Qt.MatchExactly)
            assert items
            item = items[0]
            row = item.row()
            # 定位到指定行
            self.tableview.verticalScrollBar().setSliderPosition(row)
            self.tableview.selectRow(row)
            self.tableview.setCurrentItem(item)
        self.NotifyPackageConfigurationChange()

    def InstallPip(self):
        pkg_name = self.get_select_pkgname()
        dlg = InstallPackagesDialog(
            self, self._interpreter, pkg_name=pkg_name, call_back=self.InstallCallback)
        dlg.exec_()

    def UninstallCallback(self, pkg_name, interpreter):
        '''
            卸载完后则删除已有包
        '''
        if pkg_name:
            self.RemovePackage(pkg_name, interpreter)
        else:
            # 必须首先更新表头的排序方式
            self.column_sort_order = self.tableview.horizontalHeader().sortIndicatorOrder()
        self.NotifyPackageConfigurationChange()

    def get_select_pkgname(self):
        sel = self.tableview.currentRow()
        pkgname = ''
        if sel != -1:
            pkgname = self.tableview.item(sel, 0).text()
        return pkgname

    def UninstallPip(self):
        package_name = self.get_select_pkgname()
        dlg = UninstallPackagesDialog(self, self._interpreter, pkg_name=package_name,
                                      uninstall_args=package_name, call_back=self.UninstallCallback)
        dlg.exec_()

    def update_ui(self):
        # 获取表头箭头所表示的数据排序方式
        self.column_sort_order = self.tableview.horizontalHeader().sortIndicatorOrder()
        self.LoadPackages()

    def add_simple_item(self, itemtext):
        self.tableview.insertRow(0)
        nameitem = QTableWidgetItem(itemtext)
        self.tableview.setItem(0, 0, nameitem)
        if itemtext == InterpreterPipNotFoundError.ERROR_MSG:
            self.add_fixpip_button()

    def LoadPackages(self, reload=False):
        if self._interpreter is None or self._interpreter.IsBuiltIn or self._interpreter.GetPipPath() is None:
            self.install_btn.setEnabled(False)
            self.uninstall_btn.setEnabled(False)
            self.freeze_btn.setEnabled(False)
        else:
            self.install_btn.setEnabled(True)
            self.uninstall_btn.setEnabled(True)
            self.freeze_btn.setEnabled(True)
        self.clear_table_rows()
        if self._interpreter is None:
            return
        utils.get_logger().debug('load interpreter %s packages', self._interpreter.name)
        # 包信息除非强制更新,否则只加载一次
        if (not self._interpreter._is_loading_package and 0 == len(self._interpreter._packages)) or reload:
            # 注意这里的线程对象不能设为局部变量,必须设为范围更大的类属性变量
            # 否则会出现QThread: Destroyed while thread is still running
            self.packages_load_thread = PackagesLoader(self, self._interpreter)
            self.packages_load_thread.start()
            self.add_simple_item(_("Loading package list..."))
            return
        self.LoadPackageList(self._interpreter, '')

    def stop_load_packages(self):
        '''
            处理正在加载包信息时,关闭对话框,导致线程突然中断,无法访问界面
        '''
        if self.packages_load_thread.isRunning():
            utils.get_logger().debug(
                'load packages thread is still running when dialog exit, stop it...')
            self.packages_load_thread.quit()
            self.packages_load_thread.wait()
            utils.get_logger().debug('stop load packages thread success')
        else:
            utils.get_logger().debug('load packages thread is already finished when dialog exit')

    def clear_table_rows(self):
        # 清空表格所有内容
        self.tableview.clearContents()
        while self.tableview.rowCount():
            self.tableview.removeRow(0)

    def LoadPackageList(self, interpreter, errmsg):
        # 再一次清空表格所有内容,有上面临时写入的内容
        self.clear_table_rows()
        self.remove_fixpip_button()
        if not strutils.is_none_empty(errmsg):
            utils.get_logger().error(
                'occur error:%s when load interpreter `%s` packages',
                errmsg,
                interpreter.name
            )
            self.add_simple_item(errmsg)
        else:
            # 所有包的列表
            package_names = list(interpreter.Packages.keys())
            # 必须将包列表排序才能使用排序功能,按包名称字母排序,不区分大小写
            package_names.sort(key=lambda name: name.lower())
            for i, name in enumerate(package_names):
                self.AddPackage(i, interpreter.Packages[name])
        utils.get_logger().debug('load interpreter %s package end', interpreter.name)

    def LoadPackageEnd(self, interpreter, errmsg):
        '''
            频繁切换解释器时,加载包信息的线程会比较混乱,通过判断当前解释器来避免此混乱
        '''
        if self._interpreter != interpreter and self._interpreter is not None:
            utils.get_logger().debug(
                "interpreter %s is not page current interprter,current interpreter is %s",
                interpreter.name,
                self._interpreter.name
            )
            return
        self.LoadPackageList(interpreter, errmsg)

    def AddPackage(self, row, python_package):
        # 根据排序方式决定数据插入方式
        if self.column_sort_order == Qt.DescendingOrder:
            insertrow = 0
        elif self.column_sort_order == Qt.AscendingOrder:
            insertrow = row
        self.tableview.insertRow(insertrow)
        nameitem = QTableWidgetItem(python_package.name)
        self.tableview.setItem(insertrow, 0, nameitem)

        versionitem = QTableWidgetItem(python_package.version)
        self.tableview.setItem(insertrow, 1, versionitem)

    def RemovePackage(self, name, interpreter):
        row, package_name = self.GetPackageItem(name)
        if row == -1:
            return
        self.tableview.removeRow(row)
        if not package_name in interpreter.Packages:
            utils.get_logger().error(
                "package name %s is not exist in packages when remove it....", package_name)
            return
        python_package = interpreter.Packages[package_name]
        utils.get_logger().info("package name %s version %s already exist,remove package first!",
                                python_package.name, python_package.version)
        interpreter.Packages.pop(package_name)

    def GetPackageItem(self, package_name):
        package_name = str(package_name)
        for i in range(self.tableview.rowCount()):
            item = self.tableview.item(i, 0)
            if item.text().lower() == package_name.lower():
                return i, item.text()
        return -1, ""

    def NotifyPackageConfigurationChange(self):
        self.parent().parent().parent().NotifyConfigurationChanged()

    def __freeze_package(self):
        text_doctemplate = get_app().GetDocumentManager().FindTemplateForPath("test.txt")
        descrs = strutils.get_template_filter(text_doctemplate)
        filename, filetype = QFileDialog.getSaveFileName(
            self,
            _('Save as'),
            os.path.join(text_doctemplate.GetDirectory(), "requirements.txt"),
            descrs  # 设置文件扩展名过滤,用双分号间隔
        )
        if filename == "":
            return
        try:
            with open(filename, "wb") as f:
                command = self._interpreter.get_pip_exectable().combine_command(
                    "freeze")
                subprocess.call(command, shell=True, stdout=f,
                                stderr=subprocess.STDOUT)
        except Exception as e:
            QMessageBox.critical(self, _("Error"), str(e))
