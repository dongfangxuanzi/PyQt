import os
from urllib.parse import urlparse
from .... import _, get_app
from ....util import ui_utils, utils, fileutils
from ....lib.pyqt import (
    QHBoxLayout,
    QLabel,
    QTextEdit,
    QFileDialog,
    Qt,
    QRadioButton,
    QSizePolicy,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QComboBox,
    pyqtSignal
)
from ....async_cmd.process import AsyncProcess
from ....common.configparser import ConfigReader
from ....widgets.separator import Separator
from ....widgets import simpledialog


def url_parse_host(url):
    '''
        解析url中的host
    '''
    parts = urlparse(url)
    host = parts.netloc
    return host


class PackageActionChoiceDialog(ui_utils.BaseModalDialog):
    '''
        检查到安装包时包已经存在,提示用户可供选择的几个操作选项对话框
    '''
    # 重新安装
    REINSTALL = 0
    # 安装最新版本
    UPDATE_LATEST = 1
    # 安装指定版本
    UPDATE_SPECIFIED = 2

    def __init__(self, master, pkg_name):
        super().__init__(_("Package '%s' installed") % pkg_name, master)
        # 禁止对话框改变大小
        label_ctrl = QLabel(_("Please choose the action you want") + ":")
        self.layout.addWidget(label_ctrl)

        self.choice_value = self.UPDATE_LATEST
        self.reinstall_radiobutton = QRadioButton(_("Reinstall"))
        self.layout.addWidget(self.reinstall_radiobutton)
        if self.choice_value == self.REINSTALL:
            self.reinstall_radiobutton.setChecked(True)

        self.update_latest_radiobutton = QRadioButton(
            _("Update to latest version"))
        self.layout.addWidget(self.update_latest_radiobutton)
        if self.choice_value == self.UPDATE_LATEST:
            self.update_latest_radiobutton.setChecked(True)

        self.update_specified_radiobutton = QRadioButton(
            _("Update to specified version"))
        self.layout.addWidget(self.update_specified_radiobutton)
        if self.choice_value == self.UPDATE_SPECIFIED:
            self.update_specified_radiobutton.setChecked(True)

        separator = Separator()
        self.layout.addWidget(separator)
        self.create_standard_buttons()

    def _ok(self):
        if self.update_specified_radiobutton.isChecked():
            self.choice_value = self.UPDATE_SPECIFIED
        elif self.update_latest_radiobutton.isChecked():
            self.choice_value = self.UPDATE_LATEST
        elif self.reinstall_radiobutton.isChecked():
            self.choice_value = self.REINSTALL
        super()._ok()

    def get_choice(self):
        return self.choice_value


class CommonManagePackagesDialog(ui_utils.BaseModalDialog):
    SIG_APPEND_TEXT = pyqtSignal(str)
    SIG_COMMAND_EXIT = pyqtSignal(int)

    def __init__(
        self,
        parent,
        title,
        interpreter,
        pkg_name,
        pkg_args='',
        autorun=False,
        call_back=None
    ):
        ui_utils.BaseModalDialog.__init__(self, title, parent)
        self.layout.setAlignment(Qt.AlignTop)
        # 包安装的解释器
        # 解释器列表
        self.interpreter = interpreter
        # 包名称
        self.pkg_name = pkg_name
        # 参数
        self.pkg_args = pkg_args
        # 是否自动运行
        self.autorun = autorun
        # 执行完成后的回调函数
        self.end_callback = call_back
        self.SIG_APPEND_TEXT.connect(self.AppendText)
        self.SIG_COMMAND_EXIT.connect(self.command_exit)

    def CreateWidgets(self, interpreter_lablel, pkg_args_label, extra_label):
        row = QHBoxLayout()
        row.setAlignment(Qt.AlignLeft)
        row.addWidget(QLabel(interpreter_lablel))
        names = self.GetNames()

        self._interpreter_combo = QComboBox()
        self._interpreter_combo.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._interpreter_combo.addItems(names)
        row.addWidget(self._interpreter_combo)
        self.layout.addLayout(row)

        self.layout.addWidget(QLabel(pkg_args_label))
        args_box = QHBoxLayout()
        self.args_ctrl = QLineEdit()
        self.args_ctrl.setText(self.pkg_args)
        args_box.addWidget(self.args_ctrl)
       # self.args_ctrl.bind("<Return>", self._ok, False)

        browser_btn = QPushButton(_("Browse..."))
        browser_btn.clicked.connect(self.BrowsePath)
        args_box.addWidget(browser_btn)
        self.layout.addLayout(args_box)
        self.layout.addWidget(QLabel(extra_label))

        self.output_box = QHBoxLayout()
        self.output_ctrl = QTextEdit()
        self.output_ctrl.setReadOnly(True)
        self.output_box.addWidget(self.output_ctrl)
        self.layout.addLayout(self.output_box)

        bottom_box = QHBoxLayout()
        self.detail_btn = QPushButton(_("Show details") + "↓")
        self.detail_btn.clicked.connect(self.ShowHideDetails)
        bottom_box.addWidget(self.detail_btn)
        self._show_details = False
        buttonbox = self.create_standard_buttons_box()
        bottom_box.addWidget(buttonbox)
        self.layout.addLayout(bottom_box)
        self.ShowHideDetails()

    def ShowHideDetails(self):
        if not self._show_details:
            self.detail_btn.setText(_("Show details") + "↓")
            self.output_box.removeWidget(self.output_ctrl)
            self.output_ctrl.setVisible(False)
            self._show_details = True
        else:
            self.output_box.addWidget(self.output_ctrl)
            self.detail_btn.setText(_("Hide details") + "↑")
            self.output_ctrl.setVisible(True)
            self._show_details = False

    def BrowsePath(self):
        path, _filetype = QFileDialog.getOpenFileName(
            self,
            _('Choose requirements.txt'),
            os.path.join(os.getcwd(), "requirements.txt"),
            _("Text File") + " (*.txt)"
        )
        if not path:
            return
        self.SetRequirementsArgs(path)

    def SetRequirementsArgs(self, path):
        ''''''

    def AppendText(self, content):
        self.output_ctrl.append(content)

    def GetNames(self):
        return [self.interpreter.name]

    def _ok(self, event=None):
        if self.args_ctrl.text().strip() == "":
            QMessageBox.information(
                self, get_app().GetAppName(), _("Package name is empty"))
            return False

        if self.interpreter.IsBuiltIn or self.interpreter.GetPipPath() is None:
            QMessageBox.critical(self, get_app().GetAppName(), _(
                "Could not find pip on the path"))
            return False
        self.EnableButton(enable=False)
        return True

    def EnableButton(self, enable=True):
        if enable:
            self.args_ctrl.setEnabled(True)
            self.ok_button.setEnabled(True)
        else:
            self.args_ctrl.setEnabled(False)
            self.ok_button.setEnabled(False)

    def run(self):
        pass

    def auto_run(self):
        if not self.autorun:
            return
        self._ok()

    def GetPackageName(self):
        # 包名称为空,获取输入参数是否为包名称
        pkg_name = self.pkg_name
        if not pkg_name:
            args_name = self.args_ctrl.text().strip()
            # 输入参数没有空格,则输入为包名称
            if args_name.find(" ") == -1:
                pkg_name = args_name
        return pkg_name

    def run_command(self, command):
        async_proc = AsyncProcess(self)
        async_proc.create_process(command, self.interpreter.install_path, self.callback_exit)

    def callback_exit(self, exitcode):
        self.SIG_COMMAND_EXIT.emit(exitcode)

    def command_exit(self, exitcode):
        self.EndDialog(exitcode)


class InstallPackagesDialog(CommonManagePackagesDialog):
    SOURCE_LIST = [
        "https://pypi.org/simple",
    ]
    BEST_PIP_SOURCE = None

    def __init__(
        self,
        parent,
        interpreter,
        pkg_name='',
        install_args='',
        autorun=False,
        install_update=False,
        call_back=None
    ):
        CommonManagePackagesDialog.__init__(
            self,
            parent,
            _("Install Package"),
            interpreter,
            pkg_name,
            install_args,
            autorun,
            call_back
        )
        self.SOURCE_NAME_LIST = [
            _('Default Source'),
        ]
        # 是否更新安装
        self.install_update = install_update
        row = QHBoxLayout()
        row.setAlignment(Qt.AlignLeft)
        row.addWidget(QLabel(_("We will use the pip source") + ":"))
        self._pipSourceCombo = QComboBox()
        self._pipSourceCombo.addItems(self.SOURCE_NAME_LIST)
        self._pipSourceCombo.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        row.addWidget(self._pipSourceCombo)

        check_source_btn = QPushButton(_("Check the best source"))
        check_source_btn.clicked.connect(self.CheckTheBestSource)
        row.addWidget(check_source_btn)
        self.layout.addLayout(row)
        self.CreateWidgets(
            _("We will download and install it in the interpreter:"),
            _("Type the name of package or args to install:"),
            _("To install the specific version,type \"xxx==1.0.1\"\nTo install more packages,please specific the path of requirements.txt")
        )
        if pkg_name:
            self.args_ctrl.setText(pkg_name)
        check_best_source = True
        pip_source = self.BEST_PIP_SOURCE
        if utils.profile_get_int("RemberPipsource", True):
            pip_source_path = self.GetPipsourcePath()
            # 读取上次保存的pip源,并无需检查最佳pip源
            if os.path.exists(pip_source_path):
                check_best_source = False
                with open(pip_source_path) as f:
                    pip_source = f.read().strip()
        if self.BEST_PIP_SOURCE is None and check_best_source:
            self.CheckBestPipSource()
        else:
            self.SelectPipSource(pip_source)
            self.auto_run()

    def InstallPackage(self, interpreter):
        install_args = self.args_ctrl.text().strip()
        exectable = interpreter.get_pip_exectable()
        exectable.args.append("install")
        command = exectable.combine_command(install_args)
        utils.get_logger().debug('pip install command is %s', command)
        # linux系统下安装包可能需要root权限
        if not utils.is_windows():
            # 如果参数里面包含--user则包安装在$HOME目录下,无需root权限
            root = False if '--user ' in install_args else True
            if root:
                # 这里是提示root权限
                command = "pkexec " + command
        pip_source = self.get_pip_source()
        utils.get_logger().info('user pip source is %s', pip_source)
        command += " -i " + pip_source
        host = url_parse_host(pip_source)
        command += " --trusted-host " + host
        utils.get_logger().info("install command is %s", command)
        self.AppendText(command)
        self.run_command(command)

    def get_pip_source(self):
        '''
            使用默认源或者用户自己添加的源
        '''
        current_index = self._pipSourceCombo.currentIndex()
        if current_index == 0:
            return self.get_default_pip_source()
        return self.SOURCE_LIST[current_index]

    @classmethod
    def get_default_pip_source(cls):
        '''
            获取默认python pip源
            如果在pip.ini文件中配置源,则使用此源,否则使用国外的默认源
        '''
        pip_cfg_path = os.path.expanduser("~")
        pipdirs = ['.pip', 'pip']
        for pipdir in pipdirs:
            pip_cfg_file = os.path.join(pip_cfg_path, pipdir, 'pip.ini')
            if os.path.exists(pip_cfg_file):
                pip_url = ConfigReader(pip_cfg_file).get_config(
                    'global', 'index-url', None)
                if pip_url is not None:
                    return pip_url
        return cls.SOURCE_LIST[0]

    def CheckBestPipSource(self):
        return
        t = threading.Thread(target=self.GetBestPipSource)
        t.start()

    def GetBestPipSource(self):
        self.AppendText(_("Checking the best pip source...\n"))
        self.EnableCheckSourcButton(False)
        sort_pip_source_dct = {}
        for i, pip_source_name in enumerate(self.SOURCE_NAME_LIST):
            pip_source = self.SOURCE_LIST[i]
            api_addr = pip_source + "/ok"
            start = time.time()
            if urlutils.RequestData(api_addr, timeout=10, to_json=False):
                end = time.time()
                elapse = end - start
                sort_pip_source_dct[pip_source] = elapse
                utils.get_logger().debug("response time of pip source %s is %.2fs", pip_source, elapse)

        if len(sort_pip_source_dct) == 0:
            self.AppendText(_("Could not get the best pip source...\n"))
            return

        best_source, elapse = sorted(
            sort_pip_source_dct.items(), key=lambda x: x[1], reverse=False)[0]
        utils.get_logger().info(
            "the best pip source is %s,response time is %.2fs", best_source, elapse)
        self.AppendText(_("the best pip source is %s\n") % best_source)
        InstallPackagesDialog.BEST_PIP_SOURCE = best_source
        self.SelectPipSource(self.BEST_PIP_SOURCE)
        self.EnableCheckSourcButton(True)
        self.auto_run()

    def SelectPipSource(self, pip_source_url=None):
        return
        index = -1
        values = list(self._pipSourceCombo['values'])
        # 删除原来的最优源选项
        for i, value in enumerate(values):
            if value.find(_("The Best Source")) != -1:
                values.remove(value)
                values.insert(i, self.SOURCE_NAME_LIST[i])
                break

        # 设置新的最优源
        for i, pip_source in enumerate(self.SOURCE_LIST):
            if pip_source == self.BEST_PIP_SOURCE:
                best_source_name = self.SOURCE_NAME_LIST[i] + \
                    "(" + _("The Best Source") + ")"
                values.remove(self.SOURCE_NAME_LIST[i])
                values.insert(i, best_source_name)
                break
        # 选中需要显示的源
        for i, pip_source in enumerate(self.SOURCE_LIST):
            if pip_source == pip_source_url:
                index = i
                break
        self._pipSourceCombo['values'] = tuple(values)
        if index != -1:
            self._pipSourceCombo.current(index)

    def CheckTheBestSource(self):
        self.CheckBestPipSource()

    def EnableCheckSourcButton(self, enable=True):
        if enable:
            self.check_source_btn['state'] = "normal"
            self.check_source_btn.configure(text=_("Check the best source"))
        else:
            self.check_source_btn.configure(text=_("Checking the best source"))
            self.check_source_btn['state'] = tk.DISABLED

    def EndDialog(self, retcode):
        pkg_name = self.GetPackageName()
        install_suc = False
        utils.get_logger().debug('install ret code is %d', retcode)
        if retcode == 0:
            if pkg_name:
                # 检查包是否安装到解释器中
                python_package = self.interpreter.GetInstallPackage(pkg_name)
                # 如果包存在说明安装成功
                install_suc = True if python_package else False
            # 用户自定义输入安装参数
            else:
                python_package = None
                self.parent().LoadPackages(reload=True)
                install_suc = True
        if install_suc:
            # 只有安装成功才执行回调函数
            if self.end_callback:
                self.end_callback(python_package, self.interpreter)
            if self.install_update:
                QMessageBox.information(
                    self, get_app().GetAppName(), _("Update success"))
            else:
                QMessageBox.information(
                    self, get_app().GetAppName(), _("Install success"))
            self.close()
        else:
            if self.install_update:
                QMessageBox.critical(
                    self, get_app().GetAppName(), _("Update failed"))
            else:
                QMessageBox.critical(
                    self, get_app().GetAppName(), _("Install failed"))
            self.EnableButton()

    def run(self):
        self.InstallPackage(self.interpreter)

    def GetPipsourcePath(self):
        cache_path = utils.get_cache_path()
        pip_source_path = os.path.join(cache_path, "pip_source.txt")
        return pip_source_path

    def _ok(self):
        if not CommonManagePackagesDialog._ok(self):
            return False
        # 保存选择的pip源
        if utils.profile_get_int("RemberPipsource", True):
            pip_source_path = self.GetPipsourcePath()
            with open(pip_source_path, "w") as f:
                f.write(self.SOURCE_LIST[self._pipSourceCombo.currentIndex()])

        pkg_name = self.GetPackageName()
        if pkg_name:
            # 安装包时查找包是否已经安装了,如果已经安装提示用户操作选项
            python_package = self.interpreter.GetInstallPackage(pkg_name)
            if python_package:
                choice_dlg = PackageActionChoiceDialog(self, pkg_name)
                if PackageActionChoiceDialog.Accepted == choice_dlg.exec_():
                    choice = choice_dlg.get_choice()
                    if choice != PackageActionChoiceDialog.REINSTALL:
                        self.install_update = True
                        # 用户选择安装最新版本
                        if choice == PackageActionChoiceDialog.UPDATE_LATEST:
                            # pip更新到最新版本命令
                            self.args_ctrl.setText("-U %s" % pkg_name)
                        # 用户选择安装指定版本
                        else:
                            versions = self.interpreter.get_pkg_versions(
                                pkg_name)
                            if not versions:
                                self.EnableButton()
                                return False
                            selection = simpledialog.asklist(
                                _("Choose the specified version"),
                                _("Please choose the specified version to install") + ":",
                                versions,
                                selection=0,
                                master=self
                            )
                            if selection > -1:
                                install_version = versions[selection]
                                # pip更新到指定版本命令
                                self.args_ctrl.setText("%s==%s" %
                                                       (pkg_name, install_version))
                            else:
                                self.EnableButton()
                                return False

                else:
                    self.EnableButton()
                    return False
            else:
                utils.get_logger().warning('could not find package named %s in interpreter %s',
                                           pkg_name, self.interpreter.name)
        self.run()

    def SetRequirementsArgs(self, path):
        '''
            设置通过requirements文件安装批量包的参数
        '''
        args = "-r "
        # 如果不是虚拟解释器,通过user参数安装
        if not self.interpreter.is_venv_interpreter():
            args = "--user " + args
        self.args_ctrl.setText(args + fileutils.opj(path))


class UninstallPackagesDialog(CommonManagePackagesDialog):
    def __init__(
        self,
        parent,
        interpreter,
        pkg_name='',
        uninstall_args='',
        autorun=False,
        call_back=None
    ):
        CommonManagePackagesDialog.__init__(
            self,
            parent,
            _("Uninstall Package"),
            interpreter,
            pkg_name,
            uninstall_args,
            autorun,
            call_back
        )
        self.CreateWidgets(
            _("We will uninstall it in the interpreter:"),
            _("Type the name of package or args to uninstall:"),
            _("To uninstall more packages,please specific the path of requirements.txt")
        )
        self.auto_run()

    def EndDialog(self, retcode):
        pkg_name = self.GetPackageName()
        uninstall_suc = False
        if retcode == 0:
            if pkg_name:
                # 如果包不存在说明卸载成功
                python_package = self.interpreter.GetInstallPackage(pkg_name)
                uninstall_suc = False if python_package else True
            else:
                python_package = None
                self.parent().LoadPackages(reload=True)
                uninstall_suc = True
        if uninstall_suc:
            # 只有卸载成功才执行回调函数
            if self.end_callback:
                self.end_callback(pkg_name, self.interpreter)
            QMessageBox.information(
                self, get_app().GetAppName(), _("Uninstall success"))
            self.close()
        else:
            QMessageBox.critical(
                self, get_app().GetAppName(), _("Uninstall fail"))
            self.EnableButton()

    def UninstallPackage(self, interpreter):
        uninstall_args = self.args_ctrl.text().strip()
        exectable = interpreter.get_pip_exectable()
        exectable.args.extend(["uninstall", '-y', uninstall_args])
        command = exectable.get_cmd()
        utils.get_logger().debug('pip uninstall command is %s', command)
        pkg_name = self.GetPackageName()
        python_package = self.interpreter.GetInstallPackage(pkg_name)
        # linux系统卸载包可能需要root权限
        if not utils.is_windows():
            root = False
            if python_package:
                pkg_location = python_package.Location
                if pkg_location is not None:
                    # 判断包安装目录是否有当前用户写的权限,如果有则不需要root,否则需要root
                    root = not fileutils.is_writable(pkg_location)
            if root:
                # 这里是提示root权限
                command = "pkexec " + command
        self.AppendText(command)
        self.run_command(command)

    def run(self):
        self.UninstallPackage(self.interpreter)

    def _ok(self):
        if not CommonManagePackagesDialog._ok(self):
            return False
        self.run()

    def SetRequirementsArgs(self, path):
        '''
            设置通过requirements文件安装卸载包的参数
        '''
        args = "-r "
        self.args_ctrl.setText(args + fileutils.opj(path))
