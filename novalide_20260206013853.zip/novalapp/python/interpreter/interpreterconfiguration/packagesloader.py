from ....lib.pyqt import QThread
from ..exceptions import (
    InterpreterPathNotExistError,
    InterpreterLaunchError,
    InterpreterPipNotFoundError
)


class PackagesLoader(QThread):
    """description of class"""

    def __init__(self, parent, interpreter):
        super().__init__(parent)
        self.interpreter = interpreter

    def run(self):
        err = ''
        try:
            self.interpreter.LoadPackageList()
        except (InterpreterPathNotExistError, InterpreterLaunchError, InterpreterPipNotFoundError) as ex:
            err = ex.ERROR_MSG
        # 多线程访问主界面控件需要通过信号发送的方式操作
        self.parent().sigLoadPackagesFinished.emit(self.interpreter, err)
        self.interpreter._is_loading_package = False
