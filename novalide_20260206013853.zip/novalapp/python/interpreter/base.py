import os
import re
import abc
import builtins
import logging
from .. import pythonenv
from ... import get_app
from .exceptions import UnParseableSyntaxMessage
from ...util import fileutils
from ...executable import Executable
logger = logging.getLogger(__name__)


class PythonEnvironment:
    def __init__(self):
        self._include_system_environ = True
        self.environ = {}

    def Exist(self, key):
        return key in self.environ

    def GetEnviron(self):
        environ = {}
        environ.update(self.environ)
        if self._include_system_environ:
            environ.update(os.environ.copy())
        return environ

    def SetEnviron(self, dct):
        self.environ = {}
        for key in dct:
            self.environ[str(key)] = str(dct[key])
        # must use this environment variable to unbuffered binary stdout and stderr
        # environment value must be a string,not a digit,which linux os does not support a digit value
        self.environ[pythonenv.PYTHON_UNBUFFERED] = '1'

    @property
    def IncludeSystemEnviron(self):
        return self._include_system_environ

    @IncludeSystemEnviron.setter
    def IncludeSystemEnviron(self, v):
        self._include_system_environ = v

    def __next__(self):
        '''
            python3迭代方法
        '''
        return self.next()

    def __iter__(self):
        self.iter = iter(self.environ)
        return self

    def next(self):
        '''
            python2迭代方法
        '''
        return builtins.next(self.iter)

    def GetCount(self):
        return len(self.environ)

    def __getitem__(self, name):
        return self.environ[name]


class Interpreter(abc.ABC, Executable):
    UNKNOWN_VERSION_NAME = "--"

    def __init__(self, name, executable_path, interpreter_id=None, init_build=True):
        super().__init__(executable_path)
        self.name = name
        self._id = interpreter_id
        self._is_builtin = False
        self._is_default = False
        self._version = Interpreter.UNKNOWN_VERSION_NAME
        self._minor_version = Interpreter.UNKNOWN_VERSION_NAME
        # 系统搜索路径
        self._sys_path_list = []
        # 用户自定义搜索路径
        self._python_path_list = []
        self._builtins = []
        if init_build:
            self.build()

        self.Environ = PythonEnvironment()
        self._packages = {}
        self._help_path = ""
        self._is_loading_package = False

    @property
    def IsBuiltIn(self):
        return self._is_builtin

    @property
    def MinorVersion(self):
        return self._minor_version

    @property
    def Version(self):
        return self._version

    @property
    def HelpPath(self):
        return self._help_path

    @HelpPath.setter
    def HelpPath(self, help_path):
        self._help_path = help_path

    @property
    def Default(self):
        return self._is_default

    @Default.setter
    def Default(self, is_default):
        self._is_default = is_default

    @property
    def sys_path_list(self):
        return self._sys_path_list

    @property
    def python_path_list(self):
        return self._python_path_list

    @python_path_list.setter
    def python_path_list(self, path_list):
        self._python_path_list = path_list

    @property
    def Builtins(self):
        return self._builtins

    @property
    def Id(self):
        return self._id

    @property
    def Packages(self):
        return self._packages

    @Packages.setter
    def Packages(self, packages):
        self._packages = packages

    @property
    def IsLoadingPackage(self):
        return self._is_loading_package

    @property
    def Analysing(self):
        return False

    @staticmethod
    def parse_syntax_message(message):
        '''
            解析语法错误信息
            分为:SyntaxError和IndentationError 2种输出信息
        '''
        lines = message.splitlines()
        file_lines = []
        for i, line in enumerate(lines):
            # 解析SyntaxError格式类信息
            pattern = r'File "(.*)", line (\d+)'
            res = re.search(pattern, line)
            if res is not None:
                filename, linenum = res.groups()
                # 可能包含多行文件堆栈信息
                file_lines.append([i, filename, int(linenum)])
        # 取堆栈最后一个文件的错误信息
        if file_lines:
            lineindex, filename, linenum = file_lines[-1]
            syntax_msg = '\n'.join(lines[lineindex + 1:])
            # 语法错误信息文件可能不是本文件
            return filename, linenum, syntax_msg
        # 解析IndentationError格式类信息
        pattern = r'(.*) \(.*, line (\d+)\)'
        res = re.search(pattern, lines[0])
        if res:
            indentation_msg, linenum = res.groups()
            # 缩进错误必定是本文件,返回空字符串
            return '', int(linenum), indentation_msg
        logger.error("could not parse syntax message:%s", message)
        raise UnParseableSyntaxMessage(message)

    @staticmethod
    def normalize_sys_path(pathlist):
        '''
            格式化python系统路径,有的系统路径是相对路径,转换为绝对路径,
            比如系统路径里面可能为空字符串.需要转换为实际路径
        '''
        for i, path in enumerate(pathlist):
            pathlist[i] = os.path.normcase(os.path.abspath(path))
        return pathlist

    @staticmethod
    def get_help_path(rootpath):
        '''
        获取python帮助文档路径,python311版本之前为chm格式的帮助文档,
        python311版本之后为html格式的帮助文档
        '''
        files = []
        docpath = os.path.join(rootpath, "doc")
        fileutils.get_dir_files(
            docpath,
            files,
            "chm"
        )
        if files:
            return files[0]
        html_doc_path = os.path.join(docpath, "html")
        fileutils.get_dir_files(
            html_doc_path,
            files,
            "html"
        )
        if files:
            for htmlfile in files:
                if fileutils.get_filename_from_path(htmlfile) == "index.html":
                    return htmlfile
        return None

    def gen_id(self):
        self._id = get_app().GetInterpreterManager().GenerateId()
        return self._id

    def build(self):
        # 获取python的完整版本号
        self._build_version()
        self._build_syspath_list()
        self._build_builtins()
        self._build_help_path()

    def build_from_data(self, **kwargs):
        self._version = kwargs.get('version')
        if self._version == self.UNKNOWN_VERSION_NAME:
            return
        self._minor_version = kwargs.get('minor_version', '')
        self._builtins = kwargs.get('builtins')
        self._sys_path_list = self.normalize_sys_path(
            kwargs.get('sys_path_list'))
        python_path_list = kwargs.get('python_path_list')
        self._python_path_list = [
            pythonpath for pythonpath in python_path_list if str(pythonpath.strip()) != '']
        self._is_builtin = kwargs.get('is_builtin')

    def IsV2(self):
        return False

    def IsV3(self):
        return False

    def GetExedirs(self):
        return [self.InstallPath, ]

    def is_venv_interpreter(self):
        return False

    def GetPythonLibPath(self):
        return None

    def LoaPackagesFromDict(self, package_dct):
        return {}

    def detect_help_path(self):
        helppath = self.get_help_path(self.install_path)
        if helppath:
            self.HelpPath = helppath

    def is_builtin_module(self, name):
        return name in self._builtins

    @abc.abstractmethod
    def _build_builtins(self):
        raise NotImplementedError('you must implement this in derived class')

    @abc.abstractmethod
    def _build_syspath_list(self):
        raise NotImplementedError('you must implement this in derived class')

    @abc.abstractmethod
    def _build_version(self):
        raise NotImplementedError('you must implement this in derived class')

    def _build_help_path(self):
        self.detect_help_path()
