import sys
from ... import _
from ...util import fileutils
from .exceptions import (
    InterpreternameExistError,
    InterpreterpathExistError
)
from . import interpreter as pythoninterpreter


class InterpreterAdmin:
    def __init__(self, interpreters):
        self.interpreters = interpreters

    def check_interpreter_exist(self, interpreter):
        for kb in self.interpreters:
            if kb.name.lower() == interpreter.name.lower():
                raise InterpreternameExistError(
                    _("Interpreter name %s already exist") % kb.name)
            # 解释器路径有可能不存在了
            if fileutils.ComparePath(kb.path, interpreter.path):
                raise InterpreterpathExistError(
                    _("Interpreter path %s already exist") % kb.path)

    def add_python_interpreter(self, interpreter_path, name):
        if fileutils.ComparePath(interpreter_path, sys.executable):
            interpreter = pythoninterpreter.BuiltinPythonInterpreter()
        else:
            interpreter = pythoninterpreter.PythonInterpreter(
                name, interpreter_path)
        interpreter.gen_id()
        self.add_one_interpreter(interpreter)
        return interpreter

    def add_one_interpreter(self, interpreter):
        self.check_interpreter_exist(interpreter)
        self.interpreters.append(interpreter)
        # first interpreter should be the default interpreter by default
        if 1 == len(self.interpreters):
            self.make_default_interpreter()

    def GetInterpreterbyName(self, name):
        for interpreter in self.interpreters:
            if interpreter.name == name:
                return interpreter
        return None

    def make_default_interpreter(self):
        self.interpreters[0].Default = True
