import os
from .. import _, get_app
from .parser import objtypes
from ..lib.pyqt import (QTextEdit,
                        QSizePolicy, QLineEdit, QCheckBox, QMessageBox)
from ..widgets.labels import FitLabel
from ..widgets import simpledialog
from ..util import ui_utils, fileutils
from ..preference.manager import GetOptionName
from ..preference.preference import PreferenceDialog


class ParserErrorsDialog(ui_utils.BaseModalDialog):
    """Python code parser errors dialog"""

    def __init__(self, filename, info=None, parent=None, errorfile=''):
        super().__init__('Lexer/parser errors: ' + os.path.basename(filename), parent)
        # 语法错误文件可能和被检测的代码文件不同
        if errorfile == '':
            errorfile = filename
        self.__create_layout(errorfile, info)
        self.show()

    def __create_layout(self, filename, info):
        """Creates the dialog layout"""
        self.resize(600, 220)
        self.setSizeGripEnabled(True)

        # Info label
        infolabel = FitLabel(self)
        sizepolicy = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Preferred)
        sizepolicy.setHorizontalStretch(0)
        sizepolicy.setVerticalStretch(0)
        sizepolicy.setHeightForWidth(
            infolabel.sizePolicy().hasHeightForWidth())
        infolabel.setSizePolicy(sizepolicy)
        infolabel.setText('Lexer/parser errors for ' + filename)
        self.layout.addWidget(infolabel)

        # Result window
        result_edit = QTextEdit(self)
        result_edit.setTabChangesFocus(False)
        result_edit.setAcceptRichText(False)
        result_edit.setReadOnly(True)
        if info is not None:
            modInfo = info
        if modInfo is None:
            result_edit.setText('No errors found')
        else:
            result_edit.setText(modInfo)
        self.layout.addWidget(result_edit)
        # Buttons
        self.create_ok_button()


class EncodingdeclareDialog(ui_utils.BaseModalDialog):

    DEFAULT_ENCODING_DECLARE = "# -*- coding: utf-8 -*-"

    def __init__(self, parent):
        super().__init__(_("Declare encoding"), parent)
        self.name_entry = QLineEdit()
        self.name_entry.setText(self.DEFAULT_ENCODING_DECLARE)
        self.name_entry.setSizePolicy(QSizePolicy.Expanding,
                                      QSizePolicy.Fixed)
        self.name_entry.setEnabled(False)
        self.layout.addWidget(self.name_entry)

        self.check_box = QCheckBox(_("Edit"))
        self.check_box.clicked.connect(self.__on_checked)
        self.layout.addWidget(self.check_box)
        self.check_box.setChecked(False)
        self.create_standard_buttons()

    def __on_checked(self):
        if self.check_box.isChecked():
            self.name_entry.setEnabled(True)
        else:
            self.name_entry.setEnabled(False)


def show_interpreter_configuration_page():
    preference_dlg = PreferenceDialog(
        get_app().MainFrame,
        selection=GetOptionName(_("Interpreter"), "InterpreterList")
    )
    return preference_dlg.exec_()


def show_definitions_dialog(definitions, text_view):
    linenames = []
    for definition in definitions:
        if definition.path is not None:
            if fileutils.ComparePath(text_view.GetDocument().GetFilename(), definition.path):
                path = os.path.basename(text_view.GetDocument().GetFilename())
            else:
                path = definition.path
        if definition.locatable():
            linename = "%s- (%d,%d)" % (path, definition.line, definition.col)
        else:
            # 如果定义无法定位到行,显示节点模块名称
            linename = definition.defname + "(%s)" % definition.module
        linenames.append(linename)

    sel = simpledialog.asklist(
        _('Multiple definitions'),
        _("Please choose one definition"),
        linenames,
        selection=0,
        master=text_view.GetCtrl()
    )
    if sel < 0:
        return
    definition = definitions[sel]
    if not definition.locatable():
        unable_locate_definition(definition.defname, text_view.GetCtrl())
        return
    if definition.typname == objtypes.MODULE:
        get_app().open_definition_file(definition.path)
    else:
        get_app().open_definition_file(
            definition.path,
            lineno=definition.line - 1,
            column=definition.col
        )


def definition_not_found(txt, parent):
    '''无法找到文本定义'''
    QMessageBox.warning(
        parent,
        _("Goto definition"),
        _("Cannot find definition") + "\"" + txt + "\""
    )


def unable_locate_definition(txt, parent):
    '''无法定位到文本定义行号,如内建模块'''
    QMessageBox.warning(
        parent,
        _("Goto definition"),
        _("Cannot goto definition") + "\"" + txt + "\""
    )
