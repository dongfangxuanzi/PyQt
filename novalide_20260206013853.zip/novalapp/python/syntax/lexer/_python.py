# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        _python.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
import builtins
import os
import keyword
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.util import appdirs
from novalapp.python import editor as pythoneditor
from novalapp.qtimage import python_icon, load_icon
from novalapp.python import prog_lang_ext
from novalapp.lib.qsci import QsciLexerPython
# -----------------------------------------------------------------------------#

# 内建成员列表,不以下划线开头并且不在python默认关键字列表中
builtinlist = [
    str(name) for name in dir(builtins)
    if not name.startswith('_') and name not in keyword.kwlist
]

# ---- Keyword Specifications ----#


class LexerShellPython(QsciLexerPython):
    '''
    重新设定python shell关键字,默认1集合为python关键字列表,设定2集合内建成员也作为关键字列表
    '''

    def keywords(self, kwset):
        if kwset == 2:
            return " ".join(builtinlist)
        return super().keywords(kwset)


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_PYTHON")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('Python Script')

    def GetExt(self):
        return " ".join(prog_lang_ext.PYTHON_CODE_FILE_EXT)

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['#']

    def GetShowName(self):
        return "Python"

    def GetDefaultExt(self):
        return prog_lang_ext.PYTHON_CODE_FILE_EXT[0]

    def GetDocTypeName(self):
        return "Python Document"

    def GetViewTypeName(self):
        return _("Python Editor")

    def GetDocTypeClass(self):
        return pythoneditor.PythonDocument

    def GetViewTypeClass(self):
        return pythoneditor.PythonView

    def GetDocIcon(self):
        return python_icon()

    def GetFileViewIcon(self):
        return load_icon('files/python-file.gif')

    def GetSampleCode(self):
        sample_file_path = os.path.join(
            appdirs.get_app_data_location(), "sample", "python.sample")
        return self.GetSampleCodeFromFile(sample_file_path)

    def GetCommentTemplate(self):
        return '''\'\'\'
Name:        {File}
Purpose:

Author:      {Author}

Created:     {Date}
Copyright:   (c) {Author} {Year}
Licence:     {Licence}
\'\'\'
'''

    def GetKeywords(self):
        return keyword.kwlist

    def get_lexer(self, parent):
        return QsciLexerPython(parent)

    def get_shell_lexer(self, parent):
        return LexerShellPython(parent)

    def theme_file(self):
        return "_python.json"
