# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2020  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""Find in files search result providers"""
import logging
from ... import _, get_app
from .resultprovideriface import SearchResultProviderIFace
from .findsymboldialog import FindSymbolDialog
from .parameter import FindSymbolParameter, FindSymbolIn


class PythonsymbolsSearchProvider(SearchResultProviderIFace):
    """Find in files search results provider"""

    def __init__(self):
        SearchResultProviderIFace.__init__(self)

    @staticmethod
    def serialize(parameter: FindSymbolParameter):
        """Provides a string which serializes the search parameters"""
        # Parameters dictionary:
        ret = [
            (_("Symbol"), parameter.findstr),
            (_('Type'), FindSymbolDialog.SYMBOL_NAME_LIST[parameter.symbol]),
            (_("Case"), parameter.match_case),
            (_("Whole symbol"), parameter.match_whole_word)
        ]
        if parameter.find_in == FindSymbolIn.IN_FILE:
            ret.append((_('In'), _('File')))
        elif parameter.find_in == FindSymbolIn.IN_PROJECT:
            ret.append((_('In'), _('Project')))
        elif parameter.find_in == FindSymbolIn.IN_OPEN_FILES:
            ret.append((_('In'), _('Opened files')))
        elif parameter.find_in == FindSymbolIn.IN_DIRECTORY:
            ret.append((_('In'), parameter.path))
        return ret

    @staticmethod
    def searchAgain(searchId, parameter, resultsViewer):
        """Repeats the search"""
        try:
            dlg = FindSymbolDialog(
                get_app().GetTopWindow(),
                resultsViewer,
                parameter=parameter
            )
            dlg.exec_()
            resultsViewer.showReport(PythonsymbolsSearchProvider.getName(),
                                     dlg.searchResults,
                                     parameter, searchId)
        except Exception as exc:
            logging.error(str(exc))

    @staticmethod
    def getName():
        """Provides the display name"""
        return _('Find Symbol')
