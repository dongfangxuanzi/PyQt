# -*- coding: utf-8 -*-
'''
Name:        replacesymbol.py
Purpose:

Author:      wukan

Created:     2026-01-11
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import os
from .... import _, get_app
from ..findsymboldialog import FindSymbolDialog
from ....util import utils
from ....lib.pyqt import (
    QLabel,
    QHBoxLayout,
    QPushButton,
    QComboBox,
    QDialogButtonBox
)

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------


class ReplaceSymbolDialog(FindSymbolDialog):

    def __init__(self, master, results_view, findstr=''):
        super().__init__(master, results_view, findstr)
        self.setWindowTitle(_("Replace Symbol"))

        # Replace text label
        replace_box_layout = QHBoxLayout()
        replace_label = QLabel(_('Replace what') + ":")
        replace_box_layout.addWidget(replace_label)
        # Replace text field
        self.replace_entry_combo = QComboBox()
        self._tune_combo(self.replace_entry_combo)
        replace_box_layout.addWidget(self.replace_entry_combo)
        self.layout.insertLayout(2, replace_box_layout)

        self.replace_button = QPushButton(_('Replace'))
        self.button_box.addButton(self.replace_button, QDialogButtonBox.AcceptRole)

    def _ok(self):
        global IS_DETECT_ENCODING
        findstr = self.find_entry.get_text()
        if findstr == "" or not self.search_button.isEnabled():
            return
        self.GetFindDirOption()
        findprog = FindInfileDialog.get_find_prog(self)
        if not findprog:
            return

        path = FIND_DIR_OPTION.path
        result_view = get_app().MainFrame.resultsview
        result_view.ClearLines()
        result_view.add_head_text(
            _("Searching for '%s' in '%s'\n\n") % (findstr, path),
            FindWhere.FIND_IN_DIR,
            path
        )
        findserivice = FindService()
        IS_DETECT_ENCODING = utils.profile_get_int(
            'detect_encoding', IS_DETECT_ENCODING)
        if os.path.isfile(path):
            found_line = findserivice.FindTextInFile(
                path, findui.CURERNT_FIND_OPTION.findstr, findprog, result_view)
            result_view.add_find_result(
                _("Search completed,Find total %d results.") % found_line,
                findui.CURERNT_FIND_OPTION.findstr,
                found_line
            )
        else:
            findserivice.findin_dir(
                FIND_DIR_OPTION, findui.CURERNT_FIND_OPTION.findstr, findprog, result_view)
        self.SaveConfig()
        super()._ok()
