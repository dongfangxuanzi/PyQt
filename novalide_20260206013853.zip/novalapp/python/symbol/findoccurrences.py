import re
from .searchsupport import ItemToSearchIn
from ... import get_app
from .symbols import Symbol
from .parameter import OccurrencesParameter
from ...util import utils
from ... import globalkeys


class FindOccurrences:
    """description of class"""

    def __init__(self, name):
        self.__name = name
        self.search_results = []
        self.current_docview = get_app().MainFrame.GetNotebook().get_current_view()

    def search(self):
        item = ItemToSearchIn(
            self.current_docview.GetDocument().GetFilename(),
            self.current_docview
        )
        regexp_text = re.escape(self.__name)
        regexp_text = "\\b%s\\b" % regexp_text
        flags = re.UNICODE
        if not utils.profile_get_int(
            globalkeys.MATCH_CASE_OCCURRENCES_KEY,
            True
        ):
            flags |= re.IGNORECASE
        search_regexp = re.compile(regexp_text, flags)
        item.search(
            search_regexp,
            Symbol.ALL.value
        )
        found = len(item.matches)
        if found > 0:
            self.search_results.append(item)

    def get_parameter(self):
        return OccurrencesParameter(
            self.__name,
            self.current_docview.GetDocument().GetFilename(),
            self.current_docview.GetCtrl().get_current_line(),
            self.current_docview.GetCtrl().get_current_column()
        )
