# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2020  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""Search support"""
import os
import re
import logging
from html import escape
from astroid import nodes
from ..parser.codeparser import CodeParser
from ...util import fileutils, utils, strutils
from ..parser.node_utils import get_node_doc
from .symbols import Symbol
from ... import globalkeys


class Match:
    """Stores info about one match in a file"""

    def __init__(self, line, start, finish, symbol_type):
        self.line = line        # Matched line
        self.start = start      # Match start pos
        self.finish = finish    # Match end pos
        self.tooltip = "not implemented"
        self.text = ""
        self.symbol_type = symbol_type


def getSearchItemIndex(items, fileName):
    """Provides the search item index basing on the file name"""
    index = 0
    for item in items:
        if item.fileName == fileName:
            return index
        index += 1
    return -1


class ItemToSearchIn:
    """Stores information about one item to search in"""
    contextLines = 15

    def __init__(self, fname, editor_view=None):
        self.fileName = fname       # Could be absolute -> for existing files
        # or relative -> for newly created
        self.tooltip = ""           # For python files only -> docstring
        self.matches = []
        self._editor_view = editor_view
        self._code_parser = CodeParser()
        self.contains_function_args = utils.profile_get_int(
            globalkeys.CONTAINS_FUNCTION_ARGS_KEY,
            True
        )
        self._contains_class_bases = utils.profile_get_int(
            globalkeys.CONTAINS_CLASS_BASES_KEY,
            False
        )

    @staticmethod
    def is_parent_node_type(node, parent_node_type):
        parent_node = node
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if isinstance(parent_node, parent_node_type):
                return True
            parent_node = parent_node.parent
        return False

    def addMatch(self, name, lineNumber, customMessage=None):
        """Used to add a match which was found outside of find in files"""
        match = Match(lineNumber, 0, 0)

        # Load the file and identify matched line and tooltip
        try:
            if self.bufferUUID != "":
                mainWindow = GlobalData().mainWindow
                widget = mainWindow.getWidgetByUUID(self.bufferUUID)
                if widget is not None:
                    content = widget.getEditor().lines
                else:
                    raise Exception('Inconsistency. Buffer disappeared.')
            else:
                content = getFileContent(self.fileName).splitlines()
            self.__fillInMatch(match, content, name, lineNumber, customMessage)
        except Exception as exc:
            logging.error('Error adding match: %s', str(exc))
        self.matches.append(match)

    def __fillInMatch(self, match, content, name, lineNumber,
                      customMessage=None):
        """Fills in the match fields from the content"""
        # Form the regexp corresponding to a single word search
        line = content[lineNumber - 1]
        if customMessage:
            match.text = customMessage
        else:
            match.text = line.strip()

        if name:
            regexpText = re.escape(name)
            regexpText = "\\b%s\\b" % regexpText
            flags = re.UNICODE
            searchRegexp = re.compile(regexpText, flags)

            contains = searchRegexp.search(line)
            match.start = contains.start()
            match.finish = contains.end()
        else:
            match.start = 0
            match.finish = len(line)

        match.tooltip = self.__buildTooltip(content, lineNumber - 1,
                                            len(content),
                                            match.start, match.finish)

        self.__extractDocstring(content)

    def search(self, expression, symbol_type):
        """Perform search within this item"""
        self.matches = []
        # Here: there were no buffer or have not found it
        #       try searching in a file
        if not os.path.isabs(self.fileName) or not os.path.exists(self.fileName):
            # Unfortunately not all network file systems report the
            # fact that a file has been deleted from the disk so
            # let's simply ignore such files
            return
        # File exists, search in the file
        try:
            content = fileutils.get_file_content(self.fileName).splitlines()
            if self._editor_view is None:
                module = self._code_parser.parse_file(self.fileName)
            else:
                module = self._code_parser.parse_content(
                    self.fileName,
                    self._editor_view.GetCtrl().text()
                )
            self.__lookThroughLines(content, module, expression, symbol_type)
        except Exception as exc:
            logging.exception('Error searching in %s:', self.fileName)

    def __buildTooltip(self, content, lineIndex, totalLines,
                       startPos, finishPos):
        """Forms the tooltip for the given match"""
        start, end = self.__calculateContextStart(lineIndex, totalLines)
        lines = content[start:end]
        matchIndex = lineIndex - start

        # Avoid incorrect tooltips for HTML/XML files
        for index in range(0, len(lines)):
            if index != matchIndex:
                lines[index] = escape(lines[index])

        lines[matchIndex] = \
            escape(lines[matchIndex][:startPos]) + \
            "<b>" + \
            escape(lines[matchIndex][startPos:finishPos]) + \
            "</b>" + \
            escape(lines[matchIndex][finishPos:])

        # Strip empty lines at the end and at the beginning
        index = len(lines) - 1
        while index >= 0:
            if lines[index].strip() == '':
                del lines[index]
                index -= 1
                continue
            break
        while len(lines) > 0:
            if lines[0].strip() == '':
                del lines[0]
                continue
            break

        return '<p>' + '<br/>'.join(lines).replace(' ', '&nbsp;') + '</p>'

    def get_class_ranges(self, classnode):
        search_ranges = [
            (classnode.name,
             classnode.position.lineno,
             classnode.position.end_col_offset - len(classnode.name)
             )
        ]
        if self._contains_class_bases:
            for base in classnode.bases:
                search_ranges.append(
                    (base.as_string(), base.lineno, base.col_offset
                     ))
        return search_ranges

    def get_func_ranges(self, funcnode):
        search_ranges = [(
            funcnode.name,
            funcnode.position.lineno,
            funcnode.position.end_col_offset - len(funcnode.name)
        )]
        if self.contains_function_args:
            for arg in funcnode.args.args:
                if isinstance(arg, (nodes.Name, nodes.AssignName)):
                    search_ranges.append((arg.name, arg.lineno, arg.col_offset))
        return search_ranges

    def get_import_ranges(self, importnode, linetext):
        node_ranges = []
        for alias in importnode.alias:
            node_ranges.append(
                (alias.name, alias.lineno, alias.col_offset)
            )
            if alias.asname is not None:
                result = re.search(r'import\s+(.*)\s+as\s+(.*)', linetext)
                importas_node_span = result.span(2)
                utils.get_logger().debug(
                    'import node:%s as column span is %s',
                    alias.name,
                    importas_node_span
                )
                node_ranges.append(
                    (alias.asname, alias.lineno, importas_node_span[0])
                )
        return node_ranges

    def get_import_modname(self, importnode):
        import_modname = importnode.modname
        if not strutils.is_none_empty(importnode.level):
            import_modname = importnode.level * '.' + import_modname
        return import_modname

    def get_from_import_ranges(self, importnode, linetext):
        node_ranges = []
        import_modname = self.get_import_modname(importnode)
        result = re.search(r'from\s+(.*)\s+import', linetext)
        # 第0个分组为整个词句, 第1个分组为匹配分组的子句
        fromimport_node_span = result.span(1)
        utils.get_logger().debug('modname:%s column span is %s', import_modname, fromimport_node_span)
        node_ranges.append(
            (import_modname, importnode.lineno, fromimport_node_span[0])
        )
        for alias in importnode.alias:
            node_ranges.append(
                (alias.name, alias.lineno, alias.col_offset)
            )
            if alias.asname is not None:
                node_ranges.append(
                    (alias.asname, alias.lineno, alias.col_offset + len(alias.name))
                )
        return node_ranges

    def get_call_ranges(self, callnode):
        search_ranges = [(
            callnode.func.as_string(),
            callnode.func.lineno,
            callnode.func.col_offset
        )
        ]
        if self.contains_function_args:
            for arg in callnode.args:
                if isinstance(arg, (nodes.Name, nodes.Attribute)):
                    search_ranges.append((arg.as_string(), arg.lineno, arg.col_offset))
        return search_ranges

    def get_var_ranges(self, targets):
        node_ranges = []
        for target in targets:
            if isinstance(target, nodes.Subscript):
                target = target.value
                node_ranges.append((
                    target.as_string(),
                    target.lineno,
                    target.col_offset
                )
                )
            else:
                node_ranges.append((
                    target.as_string(),
                    target.lineno,
                    target.col_offset
                )
                )
        return node_ranges

    def get_attribute_ranges(self, attrnode):
        return [(
                attrnode.as_string(),
                attrnode.lineno,
                attrnode.col_offset
                )
                ]

    def __look_through_body(self, content, totalLines, node, expression, symbol_type):
        for child in node.get_children():
            if symbol_type == Symbol.CLASSES.value and not isinstance(child, nodes.ClassDef):
                continue
            elif symbol_type == Symbol.FUNCTIONS.value and not isinstance(
                child, (nodes.ClassDef, nodes.FunctionDef)
            ):
                continue
            elif symbol_type == Symbol.IMPORTS.value and not isinstance(
                child, (nodes.Import, nodes.ImportFrom)
            ):
                continue
            elif symbol_type == Symbol.CALLS.value and not isinstance(child, nodes.Call):
                continue
            elif symbol_type == Symbol.VARS.value and not isinstance(child, nodes.Assign):
                continue
            node_name_ranges = []
            node_symbol_type = Symbol.ALL
            if isinstance(child, nodes.ClassDef):
                node_symbol_type = Symbol.CLASSES
                node_name_ranges = self.get_class_ranges(child)
                if symbol_type == Symbol.FUNCTIONS.value:
                    node_name_ranges = []
            elif isinstance(child, nodes.FunctionDef):
                node_symbol_type = Symbol.FUNCTIONS
                node_name_ranges = self.get_func_ranges(child)
            elif isinstance(child, nodes.Import):
                node_symbol_type = Symbol.IMPORTS
                line = content[child.lineno - 1]
                node_name_ranges = self.get_import_ranges(child, line)
            elif isinstance(child, nodes.ImportFrom):
                node_symbol_type = Symbol.IMPORTS
                line = content[child.lineno - 1]
                node_name_ranges = self.get_from_import_ranges(child, line)
            elif isinstance(child, nodes.Call):
                node_symbol_type = Symbol.CALLS
                node_name_ranges = self.get_call_ranges(child)
            elif isinstance(child, nodes.Assign):
                node_symbol_type = Symbol.VARS
                node_name_ranges = self.get_var_ranges(child.targets)
            elif isinstance(child, nodes.Attribute) and (
                not self.is_parent_node_type(child, nodes.Call) and not self.is_parent_node_type(child, nodes.Assign)
            ):
                node_symbol_type = Symbol.VARS
                node_name_ranges = self.get_attribute_ranges(child)

            for nodename, lineno, col_offset in node_name_ranges:
                contains = expression.search(nodename)
                if contains:
                    match = Match(
                        lineno,
                        col_offset + contains.start(),
                        col_offset + contains.end(),
                        node_symbol_type
                    )
                    line = content[lineno - 1]
                    match.text = line.strip()
                    match.tooltip = self.__buildTooltip(
                        content,
                        lineno - 1,
                        totalLines,
                        match.start,
                        match.finish
                    )
                    if len(self.matches) > 1024:
                        # Too much entries, stop here
                        utils.get_logger().warning(
                            "More than 1024 matches in %s. Stop further search in this file.",
                            self.fileName
                        )
                    else:
                        self.matches.append(match)
            self.__look_through_body(content, totalLines, child, expression, symbol_type)

    def __lookThroughLines(self, content, module: nodes.Module, expression, symbol_type):
        """Searches through all the given lines"""
        lineIndex = 0
        totalLines = len(content)
        self.__look_through_body(content, totalLines, module, expression, symbol_type)
        # Extract docsting if applicable
        if len(self.matches) > 0:
            self.__extract_docstring(module)

    def __extract_docstring(self, module):
        """Extracts a docstring and sets it as a tooltip if needed"""
        if self.tooltip != "":
            return
        self.tooltip = ""
        docstring = get_node_doc(module)
        if not strutils.is_none_empty(docstring):
            self.tooltip = docstring

    @staticmethod
    def __calculateContextStart(matchedLine, totalLines):
        """Calculates the start line number for the context tooltip"""
        # matchedLine is a zero based index
        if ItemToSearchIn.contextLines >= totalLines:
            return 0, totalLines

        start = matchedLine - int(ItemToSearchIn.contextLines / 2)
        if start < 0:
            start = 0
        end = start + ItemToSearchIn.contextLines
        if end < totalLines:
            return start, end
        return totalLines - ItemToSearchIn.contextLines, totalLines
