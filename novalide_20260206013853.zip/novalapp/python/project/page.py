import os
from ... import get_app, _
from ...project import command, variables
from ...project.wizard.namelocation import ProjectNameLocationPage
from ...project.config import NewprojectConfig
from ...lib.pyqt import (
    Qt,
    QVBoxLayout,
    QLabel,
    QSizePolicy,
    QGroupBox,
    QRadioButton,
    QDialog
)
from . import ext
from .config import PythonNewprojectConfig
from ...util import fileutils, utils
from ...widgets.labels import LinkLabel
from ...project.wizard.templatemanager import WizardtemplateManager
from ..interpreter.combo import InterpreterComboBox
from ..ui import show_interpreter_configuration_page


class BasePythonProjectNameLocationPage(ProjectNameLocationPage):
    def __init__(self, master, **kwargs):
        ProjectNameLocationPage.__init__(self, master, **kwargs)

    def CreateNamePage(self, content_box):
        name_grid_layout = ProjectNameLocationPage.CreateNamePage(self, content_box)
        name_grid_layout.addWidget(QLabel(_("Interpreter") + ":"), 2, 0)

        self.interpreter_combo = InterpreterComboBox()
        self.interpreter_combo.setSizePolicy(QSizePolicy.Expanding,
                                             QSizePolicy.Fixed)
        name_grid_layout.addWidget(self.interpreter_combo, 2, 1)
        link_label = LinkLabel(
            _("Interpreters list"), self.OpenInterpreterConfiguration, Qt.AlignCenter)
        link_label.setToolTip(_('Click add or modify interpreters'))
        name_grid_layout.addWidget(link_label, 2, 2)
        return name_grid_layout

    def OpenInterpreterConfiguration(self, *args):
        if show_interpreter_configuration_page() == QDialog.Accepted:
            self.interpreter_combo.reload()

    def get_project_extension(self):
        return ext.PYTHON_PROJECT_EXTENSION

    def create_project_doc(self, path):
        project_doc = super().create_project_doc(path)
        project_doc.GetModel().update_interpreter_info(
            self._new_project_config.Interpreter)
        return project_doc

    def GetNewprojectConfig(self):
        return PythonNewprojectConfig(
            self.get_name(),
            self.get_location(),
            self.get_select_interpreter(),
            self.is_projectdir_created(),
            self.get_pythonpath_pattern()
        )

    def get_select_interpreter(self):
        return self.interpreter_combo.GetChooseInterpreter()

    def get_pythonpath_pattern(self):
        return PythonNewprojectConfig.PROJECT_PATH_ADD_TO_PYTHONPATH

    def Validate(self):
        if not super().Validate():
            return False
        if self.interpreter_combo.currentIndex() == -1:
            self.infotext_label.setText(
                _("Please choose a python interpreter."))
            return False
        return True


class PythonProjectNameLocationPage(BasePythonProjectNameLocationPage):
    def __init__(self, master, **kwargs):
        BasePythonProjectNameLocationPage.__init__(self, master, **kwargs)

    def CreateBottomFrame(self, content_box, **kwargs):
        sbox = QGroupBox(_("Option"))
        group_box_layout = QVBoxLayout()

        self.add_src_radiobutton = QRadioButton(
            _("Create %s Folder And Add it to the PYTHONPATH") % NewprojectConfig.DEFAULT_PROJECT_SRC_PATH
        )
        self.add_src_radiobutton.setChecked(True)
        group_box_layout.addWidget(self.add_src_radiobutton)

        self.add_project_path_radiobutton = QRadioButton(
            _("Add Project Directory to the PYTHONPATH"))
        group_box_layout.addWidget(self.add_project_path_radiobutton)

        self.configure_no_path_radiobutton = QRadioButton(
            _("Don't Configure PYTHONPATH(later manually configure it)"))
        group_box_layout.addWidget(self.configure_no_path_radiobutton)
        sbox.setLayout(group_box_layout)
        sbox.setSizePolicy(QSizePolicy.Expanding,
                           QSizePolicy.Expanding)
        content_box.addWidget(sbox)
        ProjectNameLocationPage.CreateBottomFrame(self, content_box)

    def Finish(self):
        if not ProjectNameLocationPage.Finish(self):
            return False
        dirname = self.GetProjectLocation()
        # 创建Src文件夹
        if self.add_src_radiobutton.isChecked():
            project_src_path = os.path.join(
                dirname, PythonNewprojectConfig.DEFAULT_PROJECT_SRC_PATH)
            if not os.path.exists(project_src_path):
                try:
                    fileutils.makedirs(project_src_path)
                except Exception as e:
                    self.infotext_label.setText("%s" % str(e))
                    return False

        projectview = get_app().MainFrame.projectview.GetView()
        doc = self.new_project_doc
        # 将项目路径添加到PYTHONPATH
        if self._new_project_config.PythonpathPattern == PythonNewprojectConfig.PROJECT_PATH_ADD_TO_PYTHONPATH:
            utils.profile_set(doc.GetKey() + "/AppendProjectPath", True)
        else:
            # 不将项目路径添加到PYTHONPATH
            utils.profile_set(doc.GetKey() + "/AppendProjectPath", False)
            if self._new_project_config.PythonpathPattern == PythonNewprojectConfig.PROJECT_SRC_PATH_ADD_TO_PYTHONPATH:
                doc.GetCommandProcessor().Submit(
                    command.ProjectAddFolderCommand(
                        projectview,
                        doc,
                        PythonNewprojectConfig.DEFAULT_PROJECT_SRC_PATH
                    )
                )
                src_path = os.path.join(
                    variables.create_variable_name(
                        variables.PROJECT_DIR_VARIABLE),
                    PythonNewprojectConfig.DEFAULT_PROJECT_SRC_PATH
                )
                # 将项目里面的Src文件夹路径添加到PYTHONPATH
                utils.profile_set(doc.GetKey() + "/InternalPath", [src_path])
        return True

    def get_pythonpath_pattern(self):
        if self.add_src_radiobutton.isChecked():
            return PythonNewprojectConfig.PROJECT_SRC_PATH_ADD_TO_PYTHONPATH
        if self.add_project_path_radiobutton.isChecked():
            return PythonNewprojectConfig.PROJECT_PATH_ADD_TO_PYTHONPATH
        if self.configure_no_path_radiobutton.isChecked():
            return PythonNewprojectConfig.NONE_PATH_ADD_TO_PYTHONPATH

    def Init(self):
        super().Init()
        # 项目模板是导入文件模板时默认选中第二个选项
        if WizardtemplateManager.get_manager().current_template.name == WizardtemplateManager.PROJECT_FROM_EXIST_CODE:
            self.add_project_path_radiobutton.setChecked(True)
        else:
            self.add_project_path_radiobutton.setChecked(False)
