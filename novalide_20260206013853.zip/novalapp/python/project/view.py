# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        view.py
Purpose:     python项目文件视图

Author:      wukan

Created:     2019-02-15
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import os
from ... import _, get_app
from ...project.view import ProjectView, ProjectTemplate, NewProjectWizard
from ... import menuitems
from ...lib.pyqt import QMessageBox
from ...project.wizard.templatemanager import WizardtemplateManager
from .config import PythonNewprojectConfig
from .command import ProjectAddPackagefolderCommand
from ...project.command import ProjectAddFilesCommand
from ..parser.define import PACKAGE_INIT_FILE
from ...project.property.property import PROJECT_PROPERTY, FILE_PROPERTY, FOLDER_PROPERTY
from .document import PythonProjectDocument, ProjectDocument
from .page import PythonProjectNameLocationPage


class PythonProjectTemplate(ProjectTemplate):

    @staticmethod
    def CreateProjectTemplate():
        project_template = PythonProjectTemplate(GetApp().GetDocumentManager(),
                                                 _("Project File"),
                                                 "*%s" % consts.PROJECT_EXTENSION,
                                                 os.getcwd(),
                                                 consts.PROJECT_EXTENSION,
                                                 "Project Document",
                                                 _("Project Viewer"),
                                                 GetApp().project_document_class,
                                                 PythonProjectView,
                                                 icon=imageutils.getProjectIcon())
        GetApp().GetDocumentManager().AssociateTemplate(project_template)
        return projectTtemplate

    def GetPropertiPages(self):
        return super().GetPropertiPages() + [
            (_("Debug/Run"), PROJECT_PROPERTY,
             "novalapp.python.project.property.debugrun.DebugRunPanel"),
            ("PythonPath", PROJECT_PROPERTY,
             "novalapp.python.project.property.pythonpath.PythonPathPanel"),
            (_("Interpreter"), PROJECT_PROPERTY,
             "novalapp.python.project.property.interpreter.PythonInterpreterPanel"),
            (_("Project References"), PROJECT_PROPERTY,
             "novalapp.python.project.property.referrence.ProjectReferrencePanel"),
            (_("Debug/Run"), FILE_PROPERTY,
             "novalapp.python.project.property.debugrun.DebugRunPanel"),
            (_("Debug/Run"), FOLDER_PROPERTY,
             "novalapp.python.project.property.debugrun.DebugRunPanel")
        ]

    def GetRunconfigClass(self):
        return "novalapp.python.project.config.PythonRunconfig"


class NewPythonProjectWizard(NewProjectWizard):
    @staticmethod
    def LoadDefaultProjectTemplates():
        '''
            加载python项目模板
        '''
        WizardtemplateManager.get_manager().AddProjectTemplate(
            _("General"),
            WizardtemplateManager.PROJECT_FROM_EXIST_CODE,
            _("New Common Project From Existing Code"),
            [
                ("novalapp.project.wizard.namelocation.ProjectNameLocationPage", {
                 'can_finish': False}),
                "novalapp.project.wizard.importfiles.ImportfilesPage"
            ]
        )

        WizardtemplateManager.get_manager().AddProjectTemplate(
            "Python",
            WizardtemplateManager.EMPTY_PROJECT,
            _("Empty Project"),
            [(PythonProjectNameLocationPage, {'is_empty_project': True}), ]
        )
        # 导入代码时默认不创建项目目录,并且项目创建页面不能做完成操作,只能下一步和上一部操作,导入代码页面才能做完成操作
        WizardtemplateManager.get_manager().AddProjectTemplate(
            "Python",
            WizardtemplateManager.PROJECT_FROM_EXIST_CODE,
            _("New Python Project From Existing Code"),
            [
                ("novalapp.python.project.page.PythonProjectNameLocationPage", {'can_finish': False,
                                                                                'pythonpath_pattern': PythonNewprojectConfig.PROJECT_PATH_ADD_TO_PYTHONPATH, 'create_project_dir': False}),
                ("novalapp.project.wizard.importfiles.ImportfilesPage",
                 {'rejects': PythonProjectDocument.BAN_FILE_EXTS})
            ]
        )


class PythonProjectView(ProjectView):
    def __init__(self, frame):
        ProjectView.WIZARD_CLS = NewPythonProjectWizard
        ProjectView.__init__(self, frame)

    def AddFolderItem(self, document, folderPath):
        dest_folder_path = os.path.join(
            document.GetModel().homeDir, folderPath)
        package_file_path = os.path.join(dest_folder_path, PACKAGE_INIT_FILE)
        is_package = False
        # 判断文件夹下__init__.py文件是否存在,如果存在则为包文件夹
        if os.path.exists(package_file_path):
            is_package = True
        # 普通文件夹
        if not is_package or not isinstance(document, PythonProjectDocument):
            return ProjectView.AddFolderItem(self, document, folderPath)
        # 包文件夹
        return self._treeCtrl.AddPackageFolder(folderPath)

    def OnAddPackageFolder(self):
        document = self.GetDocument()
        if not document:
            return
        if isinstance(document, PythonProjectDocument):
            items = self._treeCtrl.selection()
            if items:
                item = items[0]
                if self._IsItemFile(item):
                    item = item.parent()
                folderdir = self._GetItemFolderPath(item)
            else:
                folderdir = ""
            if folderdir:
                folderdir += "/"
            folderpath = "%sPackage" % folderdir
            i = 1
            while self._treeCtrl.FindFolder(folderpath):
                i += 1
                folderpath = "%sPackage%s" % (folderdir, i)
            projectdir = self.GetDocument().GetModel().homeDir
            dest_package_path = os.path.join(projectdir, folderpath)
            try:
                os.mkdir(dest_package_path)
            except Exception as e:
                QMessageBox.critical(
                    self.GetFrame(), get_app().GetAppName(), str(e))
                return
            self.GetDocument().GetCommandProcessor().Submit(
                ProjectAddPackagefolderCommand(self, self.GetDocument(), folderpath))
            dest_package_file = os.path.join(
                dest_package_path, PACKAGE_INIT_FILE)
            with open(dest_package_file, "w") as f:
                self.GetDocument().GetCommandProcessor().Submit(
                    ProjectAddFilesCommand(self.GetDocument(), [dest_package_file], folderpath))
            item = self._treeCtrl.FindFolder(folderpath)
            self._treeCtrl.setCurrentItem(item)
            self.OnRename(item)
        elif isinstance(document, ProjectDocument):
            super().OnAddFolder()

    def Run(self):
        selected_file_path = self.GetSelectedFilePath()
        get_app().GetDebugger().Runfile(filetoRun=selected_file_path)

    def DebugRun(self):
        selected_file_path = self.GetSelectedFilePath()
        get_app().GetDebugger().RunWithoutDebug(filetoRun=selected_file_path)

    def BreakintoDebugger(self):
        selected_file_path = self.GetSelectedFilePath()
        get_app().GetDebugger().GetCurrentProject(
        ).BreakintoDebugger(file_to_run=selected_file_path)

    def GetSelectedFilePath(self):
        selected_file_path = self.GetSelectedFile()
        if selected_file_path is None and not fileutils.is_python_file(selected_file_path):
            return None
        return selected_file_path

    def AddPackageFolder(self, folderpath):
        self._treeCtrl.AddPackageFolder(folderpath)
        return True

    def UpdateUI(self, command_id):
        if command_id in [menuitems.ID_ADD_PACKAGE_FOLDER]:
            document = self.GetDocument()
            return document is not None and isinstance(document, PythonProjectDocument)
        return ProjectView.UpdateUI(self, command_id)

    def AddProjectRoot(self, document_or_name):
        document = self.GetDocument()
        if document:
            if isinstance(document, PythonProjectDocument):
                self._prject_browser.prj_newdir_button.setToolTip(
                    _('New project package directory')
                )
            elif isinstance(document, ProjectDocument):
                self._prject_browser.prj_newdir_button.setToolTip(
                    _('New project sub directory')
                )
        return super().AddProjectRoot(document_or_name)
