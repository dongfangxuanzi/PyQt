# -*- coding: utf-8 -*-
from ... import get_app, _, qtimage, newid
from ...project.browser import ProjectBrowser
from ...project.treeview import treectrl
from ... import menuitems
from .view import PythonProjectView
from ...bars.menubar import find_menu, NewQMenu
from .. import utility
from . import ext
from .document import PythonProjectDocument
from ..parser.define import PACKAGE_INIT_FILE
from .fileanalyzer import FileAnalyzer
from .processor import CodeparserProcessor


class PythonProjectTreeCtrl(treectrl.ProjectTreeCtrl):
    # ----------------------------------------------------------------------------
    # Overridden Methods
    # ----------------------------------------------------------------------------
    def __init__(self, master):
        super().__init__(master, ext.PYTHON_PROJECT_EXTENSION)
        self._packagefolder_img = qtimage.package_folder_icon()

    def AddPackageFolder(self, folderpath):
        '''
            添加包文件夹
        '''
        folder_items = super().AddFolder(folderpath)
        if folder_items:
            # 最后一个节点为包文件夹,包文件夹节点图标和普通文件夹图标不一样
            lastitem = folder_items[-1]
            lastitem.icon = self._packagefolder_img
        return folder_items

    def GetProjectIcon(self):
        template = get_app().GetDocumentManager().FindTemplateForTestPath(
            ext.PYTHON_PROJECT_EXTENSION)
        project_file_image = self.GetTemplateIcon(template)
        return project_file_image

    def append_file_item(self, parent_item, filename, project_file, doc):
        fileitem = self.AppendItem(parent_item, filename, project_file)
        if isinstance(doc, PythonProjectDocument) and filename == PACKAGE_INIT_FILE:
            parent_item.icon = self._packagefolder_img
        return fileitem


class PythonprojectBrowser(ProjectBrowser):
    """description of class"""

    def __init__(self, parent):
        super().__init__(parent)
        self._prjnewdirbutton.setToolTip(_('New project package directory'))
        # 代码智能分析器
        self._codeparse_processor = CodeparserProcessor(
            get_app().MainFrame.GetStatusBar())
        self.register_sched_processor(self._codeparse_processor)
        # 保存文件时更新智能提示数据库信息
        self.sigFileUpdated.connect(self.update_analysis_data)

    def update_analysis_data(self, doc, filepath):
        if not self._codeparse_processor.get_doc_interpreter(doc):
            return
        if not self._codeparse_processor.find_doc_file(doc, filepath):
            return
        # 更新单个文件的智能提示数据库信息
        FileAnalyzer(self, self._codeparse_processor, doc, filepath).start()

    def GetProjectTreectrl(self):
        return PythonProjectTreeCtrl(self)

    def CreateView(self):
        return PythonProjectView(self)

    def Run(self):
        self.GetView().Run()

    def DebugRun(self):
        self.GetView().DebugRun()

    def BreakintoDebugger(self):
        self.GetView().BreakintoDebugger()

    def AppendFileMenu(self, menu):
        super().AppendFileMenu(menu)
        if not isinstance(self.GetCurrentProject(), PythonProjectDocument):
            return
        filepath = self.GetView()._GetItemFilePath(self.prjContextItem)
        if self.GetView()._IsItemFile(self.prjContextItem) and utility.is_python_file(filepath):
            runmenu = find_menu(_("&Run"), get_app().Menubar)
            menu_item = runmenu.FindMenuItem(menuitems.ID_RUN)
            menu.InsertAfter(
                menuitems.ID_REMOVE_FROM_PROJECT,
                menuitems.ID_RUN,
                menu_item.action.text(),
                img=menu_item.action.icon(),
                handler=lambda: self.ProcessEvent(menuitems.ID_RUN)
            )
            debug_menu = NewQMenu(_("Debug"))
            debug_id = newid()
            menu.insert_menu_after(menuitems.ID_RUN, debug_id, debug_menu)
            menu_item = runmenu.FindMenuItem(menuitems.ID_DEBUG)
            debug_menu.AppendItem(menu_item)

            debug_menu.Append(
                menuitems.ID_BREAK_INTO_DEBUGGER,
                _("&Break into Debugger"),
                handler=lambda: self.ProcessEvent(menuitems.ID_BREAK_INTO_DEBUGGER)
            )

            menu.InsertAfter(
                debug_id,
                menuitems.ID_SET_PROJECT_STARTUP_FILE,
                _("Set as Startup File..."),
                handler=lambda: self.ProcessEvent(
                    menuitems.ID_SET_PROJECT_STARTUP_FILE)
            )

        return menu

    def ProcessEvent(self, menu_id):
        if menu_id == menuitems.ID_SET_PROJECT_STARTUP_FILE:
            self.GetView().SetProjectStartupFile()
            return True
        if menu_id == menuitems.ID_RUN:
            self.Run()
            return True
        if menu_id == menuitems.ID_DEBUG:
            self.DebugRun()
            return True
        if menu_id == menuitems.ID_BREAK_INTO_DEBUGGER:
            self.BreakintoDebugger()
            return True
        if menu_id == menuitems.ID_ADD_PACKAGE_FOLDER:
            self.GetView().OnAddPackageFolder()
            return True
        return super().ProcessEvent(menu_id)

    def GetPopupFolderItemIds(self):
        folder_item_ids = super().GetPopupFolderItemIds()
        i = folder_item_ids.index(menuitems.ID_ADD_FOLDER)
        folder_item_ids.insert(i + 1, menuitems.ID_ADD_PACKAGE_FOLDER)
        return folder_item_ids

    def GetPopupProjectItemIds(self):
        project_item_ids = super().GetPopupProjectItemIds()
        if menuitems.ID_ADD_FOLDER in project_item_ids:
            i = project_item_ids.index(menuitems.ID_ADD_FOLDER)
            project_item_ids.insert(i + 1, menuitems.ID_ADD_PACKAGE_FOLDER)
        return project_item_ids

    def SetCurrentProject(self):
        super().SetCurrentProject()

    @staticmethod
    def get_titled_bitmap():
        return "python/python_logo.png"

    def _createdir(self):
        """Triggered when a new subdir should be created"""
        self.GetView().OnAddPackageFolder()

    def _init_commands(self):
        super()._init_commands()
        project_menu = find_menu(_("&Project"), get_app().Menubar)
        project_menu.InsertAfter(
            menuitems.ID_ADD_FOLDER,
            menuitems.ID_ADD_PACKAGE_FOLDER,
            _("New package"),
            img=get_app().GetImage("project/python/package.png"),
            handler=lambda: self.ProcessEvent(menuitems.ID_ADD_PACKAGE_FOLDER),
            tester=lambda: self.GetView().UpdateUI(menuitems.ID_ADD_PACKAGE_FOLDER)
        )
