import os
import logging
from ... import get_app, _
from ...project.processor import Processor
from ...util import fileutils, strutils
from ...syntax import lang
from ...syntax.syntax import SyntaxThemeManager
from ..interpreter.interpreter import PythonInterpreter
from ..parser.define import DATABASE_VERSION
from ..parser.exceptions import BuiltinModuleNotExistError
from ..analysis.project_analyzer import ProjectAnalyzer, CODEPARSE_RPROCESSOR_NAME
from ..parser.dataload import IntellisencedataLoader
from .document import PythonProjectDocument
from ..syspath import insert_to_syspath, remove_syspath

log = logging.getLogger(__name__)


class PythonProcessor(Processor):

    def __init__(self, statusbar, processor_name, enabled=True):
        super().__init__(statusbar, processor_name, enabled)
        self.interpreter = None

    def get_doc_interpreter(self, doc):
        if isinstance(doc, PythonProjectDocument):
            interpreter = doc.GetModel().interpreter
            if interpreter is None or not isinstance(interpreter, PythonInterpreter):
                log.error('intepreter is not exist in project file %s',
                          doc.GetFilename())
                return False
            self.interpreter = interpreter
        return True

    def init(self, doc):
        super().init(doc)
        return self.get_doc_interpreter(doc)


class CodeparserProcessor(PythonProcessor):
    """description of class"""
    UPDATE_FILE = 'update.time'
    # 每次分析的代码文件数量,不能太多,否则会导致程序变慢卡死
    MAX_PER_UPDATE_FILES = 100

    def __init__(self, statusbar):
        super().__init__(statusbar, CODEPARSE_RPROCESSOR_NAME)
        self.exts = SyntaxThemeManager.manager().GetLexer(lang.ID_LANG_PYTHON).Exts
        self.path_list = []
        self.data_out_path = None
        self.analyzer = None
        # 实际更新的文件数量
        self.total_updated_count = 0
        self.module_dicts = {}
        self._import_list = []

    @property
    def importlist(self):
        return self._import_list

    def init(self, doc):
        self.add_root_path(doc)
        if not super().init(doc):
            return False
        project_location = doc.GetPath()
        self.path_list = [project_location]
        self.make_analyzer(doc)
        self.analyzer.check_last_timestamp()
        self.analyzer.check_database_renew()
        return True

    def make_analyzer(self, doc):
        self.analyzer = self.make_project_analyzer(
            doc, get_app().GetCurrentInterpreter())
        self.analyzer.load_builtin_module()

    def end(self, doc):
        super().end(doc)
        log.debug('total update %d code files', self.total_updated_count)
        if self.total_updated_count > 0:
            self.analyzer.update_last_timestamp()
            if self.analyzer.need_renew_database:
                self.analyzer.save_new_version(DATABASE_VERSION)
        self.load_cachedata_path()
        if self.analyzer is not None:
            self.analyzer.clean_deleted_files()

    def is_python_file(self, filepath):
        ext = strutils.get_file_extension(filepath)
        return ext in self.exts

    def run(self, doc, filepath):
        if not self.is_python_file(filepath) or not self.get_doc_interpreter(doc):
            super().update_progress(filepath)
            return
        super().run(doc, filepath)
        if self.analyzer is None:
            self.make_analyzer(doc)
        modname = self.analyzer.get_relative_path(filepath)
        if strutils.find_chinese_character(modname):
            super().update_progress(filepath)
            return
        fileutils.makedirs(self.analyzer.data_out_path)
        if not self.analyzer.need_renew_module(modname, filepath):
            log.debug(
                "code filepath %s is no need update intellisence data", filepath)
            super().update_progress(filepath)
            return
        if self.total_updated_count > self.MAX_PER_UPDATE_FILES:
            log.info(
                'update total %d files greater then max update files %d',
                self.total_updated_count,
                self.MAX_PER_UPDATE_FILES
            )
            return
        filename = os.path.basename(filepath)
        try:
            self.update_progress(filepath)
            # 项目文件更新频繁 ,不能使用模块缓存功能,否则会导致智能提示数据文件内容过上
            if self.analyzer.make_code_api_files(filename, filepath, modname, use_cache=False):
                log.debug('update code filepath %s ,module %s success',
                          filepath, modname)
            else:
                log.error('update code filepath %s ,module %s fail',
                          filepath, modname)
        except BuiltinModuleNotExistError as ex:
            log.error("builtin module is not load")
            log.error('update code filepath %s ,module %s fail',
                      filepath, modname)
        self.total_updated_count += 1

    def make_project_analyzer(self, doc, interpreter):
        dbver = DATABASE_VERSION
        interpreter_data_output_path = get_app(
        ).intellisence_mananger.GetInterpreterDatabasePath(interpreter)
        log.debug("interpreter %s common data output path is %s",
                  interpreter.name, interpreter_data_output_path)
        project_analyzer = ProjectAnalyzer.make_analyzer(
            interpreter,
            dbver,
            interpreter_data_output_path,
            doc
        )
        log.debug(
            "project %s codeparser data path is %s",
            doc.GetModel().name,
            project_analyzer.data_out_path
        )
        fileutils.makedirs(project_analyzer.data_out_path)
        return project_analyzer

    def load_cachedata_path(self):
        if self.analyzer is not None:
            IntellisencedataLoader.load_databases(
                self.analyzer.dbpath, self.module_dicts)
        IntellisencedataLoader.LoadImportList(
            self._import_list, self.module_dicts)

    def add_root_path(self, doc):
        # 从pythonpath列表中移除上一个项目的路径
        if self._doc is not None:
            prev_docpath = self._doc.GetPath()
            remove_syspath(prev_docpath)
        # 将项目路径添加到pythonpath列表中
        current_docpath = doc.GetPath()
        insert_to_syspath(current_docpath)

    def update_progress(self, filepath):
        self._statusbar.emit_statusbar_messgae(
            _('Analyzing code file:%s') % filepath)
        super().update_progress(filepath)
