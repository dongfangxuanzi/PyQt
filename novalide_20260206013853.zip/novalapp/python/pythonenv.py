'''
Name:        pythonenv.py
Purpose:     python解释器使用的环境变量常量列表

Author:      wukan

Created:     2023-04-18
Copyright:   (c) wukan 2023
Licence:     <your licence>
'''
PYTHON_PATH_NAME = 'PYTHONPATH'
PYTHON_UNBUFFERED = 'PYTHONUNBUFFERED'
