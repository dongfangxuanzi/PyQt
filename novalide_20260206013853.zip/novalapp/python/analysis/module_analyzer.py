# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        analyzer.py
Purpose:   解析Python语法

Author:      wukan

Created:     2019-02-20
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import os
import threading
from astroid import nodes
import astroid
from ..parser import codeparser
from ..parser.node_utils import get_node_doc
from ..parser.define import DATABASE_VERSION
from ... import get_app, globalkeys
from ...util import utils
from .project_analyzer import ProjectAnalyzer
_code_parser = codeparser.CodeParser()


class PythonModuleAnalyzer:
    """description of class"""

    def __init__(self, mod_view, prj):
        global _code_parser
        self._mod_view = mod_view
        self._lock = threading.Lock()
        self._module = None
        self._project = prj
        self.ex = None
        self._syntax_error_msg = ''
        _code_parser.set_analyzer(self.make_pythonpath_analyzer())
        self._apifiles = set()

    @property
    def SyntaxError(self):
        return self._syntax_error_msg

    @property
    def View(self):
        return self._mod_view

    @property
    def Module(self):
        return self._module

    def make_pythonpath_analyzer(self):
        analyzer = None
        current_interpreter = get_app().GetCurrentInterpreter()
        if current_interpreter is not None:
            outpath = get_app().intellisence_mananger.GetInterpreterDatabasePath(current_interpreter)
            analyzer = ProjectAnalyzer.make_analyzer(
                current_interpreter,
                DATABASE_VERSION,
                outpath,
                self._project
            )
        return analyzer

    def load_import_api(self):
        qsciapi = self._mod_view.GetCtrl().api
        for body in self._module.body:
            if isinstance(body, nodes.Import):
                names = body.names
                for name, asname in names:
                    api_filepath_list = _code_parser.analyzer.get_refmod_apilist(
                        name)
                    for api_file_path in api_filepath_list:
                        if os.path.exists(api_file_path):
                            if asname is None:
                                # 加载子模块api文件信息
                                if self.load_child_apis(qsciapi, name):
                                    # 加载父模块api文件信息
                                    self.load_apifile(qsciapi, api_file_path)
                            else:
                                # import xx as yy语句时需要替换api文字信息
                                self.load_asname_apis(
                                    qsciapi, api_file_path, name, asname)
                                self._apifiles.add(api_file_path)
                            break
        qsciapi.prepare()

    def load_apifile(self, qsciapi, api_filepath):
        '''
        加载api文件,不能重复加载
        '''
        if api_filepath not in self._apifiles:
            qsciapi.load(api_filepath)
            self._apifiles.add(api_filepath)

    def load_asname_apis(self, qsciapi, api_file_path, name, asname):
        with open(api_file_path) as freader:
            for line in freader:
                line = line.strip()
                startname = name + "."
                assert line.startswith(startname)
                startindex = len(startname)
                api_name = asname + "." + line[startindex:]
                qsciapi.add(api_name)

    def load_child_apis(self, qsciapi, parent_mod_name):
        modules = get_app().intellisence_mananger.GetModules()
        if not modules:
            return False
        for modname in modules:
            api_filepath = modules[modname]['apis']
            if modname != parent_mod_name and modname.startswith(parent_mod_name + "."):
                self.load_apifile(qsciapi, api_filepath)
        return True

    def fix_module_importnodes(self):
        '''
        astroid模块不支持相对导入推断类型,将所有相对导入转换为绝对导入,
        以便推断节点类型
        '''
        for child in self._module.body:
            if isinstance(child, nodes.ImportFrom) and child.level is not None:
                filepath = self._mod_view.GetDocument().GetFilename()
                full_import_path = _code_parser.relative_path_to_abs(
                    filepath,
                    child.modname,
                    child.level
                )
                if full_import_path is not None:
                    child.level = None
                    child.modname = full_import_path

    def parse_module(self, filename):
        document = self._mod_view.GetDocument()
        try:
            self._module = _code_parser.parse_content(
                document.GetFilename(),
                self._mod_view.GetValue(),
                document.file_encoding
            )
            if utils.profile_get_int(globalkeys.FIX_IMPORT_NODES_KEY, True):
                self.fix_module_importnodes()
            self.load_import_api()
        except astroid.AstroidSyntaxError as ex:
            self.ex = ex
            self._syntax_error_msg = str(ex)
            self._module = None
        except Exception as exp:
            self.ex = exp
            utils.get_logger().error('parse file %s ast error:%s', filename, str(exp))
            self._syntax_error_msg = "internal error"
            self._module = None

    def AnalyzeModuleSynchronizeTree(self, view, outlineview, force, linenum):
        self.LoadMouduleSynchronizeTree(view, outlineview, force, linenum)

    def LoadMouduleSynchronizeTree(self, callback_view, outlineview, force, linenum):
        with self._lock:
            document = self._mod_view.GetDocument()
            filename = document.GetFilename()
            if not force and callback_view == self._mod_view:
                return False
            if force:
                self.parse_module(filename)
            if self._module is not None:
                # should freeze control to prevent update and treectrl flick
                self.load_module_ast(outlineview, linenum)
                notebook = get_app().MainFrame.GetNotebook()
                index = notebook.get_tab_index(self._mod_view.GetFrame())
                if utils.profile_get_int(globalkeys.DOCINFO_TIPS_ENABLED_KEY, True):
                    docstr = get_node_doc(self._module)
                    if docstr is not None:
                        notebook.setTabToolTip(index, docstr)
                else:
                    notebook.setTabToolTip(index, filename)
            # todo暂时注释,待以后实现
            # self.View.update_bar()
            # 如果语法解析错误,则清除大纲视图内容
            else:
                if isinstance(self.ex, astroid.AstroidSyntaxError):
                    outlineview.show_syntax_error(self.ex, filename)
                else:
                    outlineview.show_exception_error(self.ex, filename)
            return True

    def load_module_ast(self, outline_view, linenum=-1):
        outline_view._clear_tree()
        outline_view.update_tree_module(self._module)
        _code_parser.walker.walk(self._module)
        if linenum >= 0:
            outline_view.SyncToPosition(self._mod_view, linenum)

    def find_line_nodes(self, lineno, linenodes: list, scope=None):
        if scope is None:
            scope = self._module
        for child in scope.get_children():
            if isinstance(child, nodes.ImportFrom) and (
                child.lineno <= lineno <= child.end_lineno
            ):
                linenodes.append(child)
            elif child.lineno == lineno:
                linenodes.append(child)
            else:
                self.find_line_nodes(lineno, linenodes, child)

    def find_line_range_nodes(self, lineno, linenodes: list, scope=None):
        if scope is None:
            scope = self._module
        for child in scope.get_children():
            if child.lineno <= lineno <= child.end_lineno:
                linenodes.append(child)
            else:
                self.find_line_nodes(lineno, linenodes, child)

    def find_line_node(self, lineno, scope=None):
        nodes = []
        self.find_line_nodes(lineno, nodes, scope)
        if nodes:
            return nodes[0]
        utils.get_logger().error(
            "could not find line nodes on line %d of file %s",
            lineno,
            self._module.file
        )
        return None

    def find_line_col_node(self, lineno, col, scope=None):
        linenodes = []
        self.find_line_nodes(lineno, linenodes, scope)
        if not linenodes:
            utils.get_logger().error(
                "could not find line nodes on line %d of file %s",
                lineno,
                self._module.file
            )
            return None
        return self.find_col_node(lineno, col, linenodes)

    def find_col_node(self, lineno, col, linenodes: list):
        for linenode in linenodes:
            colnode = self._find_col_node(lineno, col, linenode)
            if colnode:
                return colnode
        utils.get_logger().warning(
            "could not find node on col %d, line %d of file %s",
            col,
            lineno,
            self._module.file
        )
        return linenodes[-1]

    def _find_col_node(self, lineno, col, node):
        for child in node.get_children():
            if child.col_offset is not None and (
                child.col_offset <= col <= child.end_col_offset and lineno == child.lineno
            ):
                col_node = self._find_col_node(lineno, col, child)
                if col_node:
                    return col_node
                return child
            col_node = self._find_col_node(lineno, col, child)
            if col_node:
                return col_node
        if node.col_offset is not None and node.col_offset <= col <= node.end_col_offset:
            return node
        return None
