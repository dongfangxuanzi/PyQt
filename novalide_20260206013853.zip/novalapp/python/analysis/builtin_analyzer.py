import os
import logging
import pkgutil
from ...util import utils, fileutils
from .base_analyzer import BaseAnalyzer
from ..parser.define import BUILTINS_DATA_FOLDER, BUILTMODULE_NAME
from ..parser.exceptions import BuiltinModuleNotExistError
from ..parser.builtin_types import BuiltinmoduleGen, BuiltinTypes

logger = logging.getLogger('ide.builtin.analyzer')


class BuiltinAnalyzer(BaseAnalyzer):
    SPECIAL_MODULES = ['os.path']

    def __init__(self, dbver, data_outpath, interpreter, check_file_updated=False):
        # 解释器自带内建模块数据存放位置
        data_out_path = os.path.join(data_outpath, BUILTINS_DATA_FOLDER)
        super().__init__(dbver, data_out_path, interpreter, check_file_updated)

    def check_builtin_members(self):
        '''
        检查builtins模块的数据文件是否存在,如果不存在,重新更新所有内建模块的数据文件
        '''
        membersfile, memberlistfile = self.get_api_files(BUILTMODULE_NAME)
        if not os.path.exists(membersfile):
            raise BuiltinModuleNotExistError(
                'builtins module data file %s is not exist' % membersfile)
        if not os.path.exists(memberlistfile):
            raise BuiltinModuleNotExistError(
                'builtins module data file %s is not exist' % memberlistfile)

    @utils.compute_time
    def run(self):
        fileutils.makedirs(self.data_out_path)
        self.check_database_renew()
        if not self._need_renew_database:
            try:
                self.check_builtin_members()
                logger.info(
                    'builtin database is the lates version %s,not analyze again', self.dbver)
                return
            except BuiltinModuleNotExistError as ex:
                logger.error("%s", str(ex))
                self._need_renew_database = True

        if self.interpreter.IsBuiltIn:
            # 首先创建内建解释器的内建模块数据
            for builtin_module_name in self.interpreter.Builtins:
                BuiltinmoduleGen(builtin_module_name, self.dbpath).gen()

            # 其次查找内建解释器包含的其它嵌入模块
            for loader, module_name, is_pkg in pkgutil.iter_modules():
                BuiltinmoduleGen(module_name, self.dbpath).gen()
                if is_pkg:
                    mod = BuiltinTypes.import_builtin_module(module_name)
                    sub_module_names = []
                    BuiltinTypes.get_sub_modules(mod, sub_module_names)
                    for sub_module_name in sub_module_names:
                        BuiltinmoduleGen(sub_module_name, self.dbpath).gen()
            self.make_specialmodule_api_files()
        else:
            self.create_builtintypes_members()
        self.update_new_version(self.dbver)
        self.update_last_timestamp()

    def make_specialmodule_api_files(self):
        for special_module_name in self.SPECIAL_MODULES:
            if not self.need_renew_module(special_module_name):
                continue
            BuiltinmoduleGen(special_module_name, self.dbpath).gen()
