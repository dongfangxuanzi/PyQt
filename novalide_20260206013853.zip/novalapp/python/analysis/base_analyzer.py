import os
import logging
import glob
from pathlib import Path
from ...common.version import UpdateVersion
from ..syspath import insert_thirdparty_to_syspath
# 添加第三方解析包astroid的搜索路径,以便能找到包
insert_thirdparty_to_syspath()
from ..parser.define import MEMBERS_FILE_EXTENSION, MEMBERLIST_FILE_EXTENSION
from .moduleloader import ModuleLoader
from ...util import fileutils, utils
from ..apis.apigen import APIGenerator
from ...executable import Executable
from ..parser.parser_checker import FileupdateTimeChecker

logger = logging.getLogger(__name__)


class BaseAnalyzer(UpdateVersion, FileupdateTimeChecker):
    """description of class"""

    def __init__(
        self,
        dbver,
        data_outpath,
        interpreter,
        check_file_updated=False
    ):
        UpdateVersion.__init__(self, data_outpath)
        FileupdateTimeChecker.__init__(self, data_outpath)
        self.dbver = dbver
        self.data_out_path = data_outpath
        self.interpreter = interpreter
        # 是否检查代码文件被更新,如果更新则更新相应的代码分析
        self._check_file_updated = check_file_updated
        self._need_renew_database = False

    @property
    def need_renew_database(self):
        return self._need_renew_database

    @property
    def dbpath(self):
        return self.data_out_path

    def check_database_renew(self):
        '''
            检查代码数据库是否需要更新,如果需要更新需要清理以前的数据
            防止加载错误的数据格式
        '''
        if self.dbver is None:
            self._need_renew_database = True
            return
        self._need_renew_database = self.need_update_version(self.dbver)
        if self._need_renew_database and self.get_old_version() is not None:
            # 清除过期版本格式的数据
            self.clear_deprecated_data()

    def clear_deprecated_data(self):
        dest_path = os.path.join(self.data_out_path, "*%s" %
                                 MEMBERS_FILE_EXTENSION)
        logger.debug("delete deprecated data path %s", dest_path)
        for f in glob.glob(dest_path):
            file_path = os.path.join(self.data_out_path, f)
            logger.debug("delete deprecated database file %s", file_path)
            fileutils.safe_remove(file_path)

    def get_api_file(self, modname):
        api_file_path = os.path.abspath(os.path.join(
            self.data_out_path, modname + MEMBERLIST_FILE_EXTENSION))
        return api_file_path

    def get_members_file(self, modname):
        api_file_path = os.path.abspath(os.path.join(
            self.data_out_path, modname + MEMBERS_FILE_EXTENSION))
        return api_file_path

    def get_api_files(self, modname):
        members_file_name = self.get_members_file(modname)
        memberlist_file_name = self.get_api_file(modname)
        return members_file_name, memberlist_file_name

    def make_members_file(self, module, modname, childs, finished=True):
        members_file_name, memberlist_file_name = self.get_api_files(modname)
        apigen = APIGenerator(self.data_out_path, childs, module, modname)
        try:
            apigen.gen_api(self)
        except Exception as ex:
            logger.error(
                "generate api file %s of module %s fail:%s",
                memberlist_file_name,
                modname,
                str(ex)
            )
        apigen.gen_members(self, finished)
        return members_file_name, memberlist_file_name

    def load_module(self, modname):
        membersfile, memberlistfile = self.get_api_files(modname)
        if not os.path.exists(membersfile):
            return None
        mdloader = ModuleLoader(modname, membersfile, memberlistfile)
        mdloader.load()
        return mdloader

    def create_builtintypes_members(self, ext=None):
        '''
            创建内建模块和pyd/so扩展模块的数据文件
            ext为None表示创建内建模块数据文件,否则为创建pyd/so扩展模块数据文件
            必须使用原生的解释器路径启动进程的方式创建数据文件
        '''
        work_dir = utils.get_app_path()
        builtins_script_path = Path(
            work_dir) / "novalapp" / "python" / "parser" / "pyd_builtins.py"
        cmd_list = [
            str(builtins_script_path),
            "-o",
            self.data_out_path,
            "-v",
            self.dbver
        ]
        if ext is not None:
            cmd_list.extend(['-ext', ext])
        env = os.environ.copy()
        env['PYTHONPATH'] = work_dir
        exectable = Executable(self.interpreter.path,
                               env=env, cwd=work_dir, args=cmd_list)
        exectable.popen()

    def need_renew_module(self, modname, filepath=None):
        '''模块更新数据库文件机制,如果文件已存在不用更新'''
        if self._need_renew_database:
            return True
        is_file_updated = False
        if self._check_file_updated:
            is_file_updated = self.is_filetime_updated(filepath)
        return is_file_updated or not self.is_mod_finish_analyzed(modname)

    def is_mod_finish_analyzed(self, modname):
        '''
            模块文件是否已经完成解析生成数据库文件
        '''
        mod_loader = self.load_module(modname)
        if mod_loader:
            finished = mod_loader.data.get('finished', False)
            logger.debug(
                'modname %s members file %s finish analyzed:%s',
                modname,
                mod_loader.membersfile,
                'Yes' if finished else 'No'
            )
            return finished
        return False
