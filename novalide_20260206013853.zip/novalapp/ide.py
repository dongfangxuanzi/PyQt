# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        ide.py
Purpose:     应用程序类的实现

Author:      wukan

Created:     2019-01-08
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
from typing import Dict
import traceback
import subprocess
import abc
import os
import sys
from pkg_resources import resource_filename
from .lib.locale import Locale
from . import _, newid
from .enums import AppStyle, AppSkin, MenuItemPosition
from .lib.app import App
from . import qtimage
from .util import strutils, logger, utils, ui_utils, fileutils, exceptions
from . import constants
from . import globalkeys
from . import menuitems
from .skin import Skin, QT_NATIVE_APP_CSSS, NativeSkin
from .bars.menubar import find_menu, MenubarMixin, NewQMenu, create_action_group
from .widgets.exceptiondlg import ExceptionMessageDialog
from .widgets.fullscreen import FullscreenWidget
from .widgets.textstyle import ZHN_TEXT_STYLE
from .syntax.synglob import LexerFactory
from .syntax.syntax import SyntaxThemeManager
from .syntax import lang
from .preference import preference
from .editor.docposition import DocMgr
from .analytics.userdb import UserdataDb
from .analytics.share import ShareData
from .backend.typing import BackendSpec
from .lib.docmanager import DEFAULT_DOCMAN_FLAGS, DOC_NEW, DOC_SILENT, DOC_OPEN_ONCE
from .lib.pyqt import QMessageBox, QEvent
from .api.api import ApiServer
from .lib import ui_lang

# ----------------------------------------------------------------------------
# Classes
# ----------------------------------------------------------------------------


class IDEApplication(App):

    def __init__(self):
        self.search_providers = {}
        self.app_style_name = None
        self.app_skin_name = None
        super().__init__()

    @property
    def MainFrame(self):
        return self.frame

    @property
    def application_looks(self):
        return self._application_looks

    @property
    def Menubar(self):
        return self.MainFrame.menuBar()

    def on_init(self):
        args = sys.argv
        # 设置软件是否处于调式模式运行
        if strutils.isInArgs("debug", args):
            self.SetAppName(constants.DEBUG_APPLICATION_NAME)
            self.SetDebug(True)
            self.SetSingleInstance(False)
        else:
            self.SetAppName(constants.APPLICATION_NAME)
            self.SetDebug(False)
            self.SetSingleInstance(True)

        # 必须在日志初始化之前启动
        from . import boot_common
        # python脚本用pyinstaller转换成可执行程序后需要重定向输入到日志文件
        boot_common.boot_init()
        logger.init_logging(self.GetDebug())
        # 将qt程序的异常输出重定向
        self.old_excepthook = sys.excepthook
        sys.excepthook = self.__hook_callback_exception
        from .lib.config import Config
        self._config = Config(self.GetAppName())

        # locale must be set as app member property,otherwise
        # it will only workable when app start up,
        # it will not workable after app start up,
        # the translation also will not work
        # 默认从配置文件获取语言id
        lang_id = utils.profile_get_int(
            globalkeys.LANGUANGE_ID_KEY, utils.get_lang_config())
        if Locale.is_available(lang_id):
            self.locale = Locale(lang_id)
            self.locale.add_catalog_lookup_pathprefix(
                os.path.join(utils.get_app_path(), 'novalapp/locale'))
            self.locale.add_catalog(constants.APPLICATION_NAME.lower())
            self.locale.add_catalog("wxstd")
            self.locale.add_catalog("wxstock")
        else:
            utils.get_logger().error("lang id %d is not available", lang_id)

        if not super().on_init():
            return False
        # 是否显示启动图片
        if utils.profile_get_int(globalkeys.SHOW_SPLASHSCREEN_KEY, True):
            self.show_splash(self.get_ide_splash_bitmap())
            self.show_splash_message(_('Welcome to use %s...') % self.GetAppName())
        self.show_splash_message(_('Importing packages...'))
        # 尽量少在文件头部导入太多模块,会导致程序启动很慢
        from .lib.template import DocTemplate, TEMPLATE_INVISIBLE, TEMPLATE_NO_CREATE
        from .editor.imageview import ImageDocument, ImageView
        from .editor.textview import TextDocument, TextView, TextOptionsPanel
        from .editor.webview import WebDocument, WebView, InternalBrowserOptionPanel
        from .editor.startup.option_panel import StartupOptionPanel
        from .project import view as projectview
        from .preference.colorfont import ColorfontOptionsPanel
        from .preference.general import GeneralOptionPanel
        from .preference.docoption import DocumentOptionsPanel
        from .findrep.optionpage import SearchTextOptionPanel
        from .preference.shortcut import KeybindOptionPanel
        self.frame = None
        self.skin = None
        self._pluginmgr = None
        self.default_project_template = None

        self._debugger_class = None

        self._application_looks = []

        docmanager = self.create_document_manager()
        self.set_document_manager(docmanager)

        # Note:  These templates must be initialized in display order for the "Files of type" dropdown for the "File | Open..." dialog
        # 这个是默认模板,所有未知扩展名的文件类型均使用这个模板
        default_template = DocTemplate(docmanager,
                                       _("All Files"),
                                       "*.*",
                                       os.getcwd(),
                                       ".*",
                                       "Blank Document",
                                       _("Blank Editor"),
                                       TextDocument,
                                       TextView,
                                       TEMPLATE_INVISIBLE,
                                       icon=qtimage.blank_icon()
                                       )
        docmanager.AssociateTemplate(default_template)

        image_template = DocTemplate(docmanager,
                                     _("Image File"),
                                     "*.bmp;*.ico;*.gif;*.jpg;*.jpeg;*.png",
                                     os.getcwd(),
                                     ".png",
                                     "Image Document",
                                     _("Image Viewer"),
                                     ImageDocument,
                                     ImageView,
                                     # could not be newable
                                     TEMPLATE_NO_CREATE,
                                     icon=qtimage.image_icon()
                                     )
        docmanager.AssociateTemplate(image_template)

        webview_template = DocTemplate(docmanager,
                                       _("WebView"),
                                       "*.com;*.org",
                                       os.getcwd(),
                                       ".com",
                                       "WebView Document",
                                       _("Internal web browser"),
                                       WebDocument,
                                       WebView,
                                       TEMPLATE_INVISIBLE,
                                       icon=self.GetImage("web.png"))
        docmanager.AssociateTemplate(webview_template)
        # 创建各种支持编程语言的模板
        self.CreateLangLexer()
        self.LoadLexerTemplates()
        self.CreateProjectTemplate()
        self.SetDefaultIcon(qtimage.application_icon())
        self.init_app_configs()
        self.load_skin()
        # 貌似在这里配置翻译才生效
        if lang_id == ui_lang.LANGUAGE_CHINESE_SIMPLIFIED:
            old_app_css = self.styleSheet()
            new_app_css = old_app_css + constants.LF + ZHN_TEXT_STYLE
            # 通过QSS样式的方式翻译按钮中文文字
            self.setStyleSheet(new_app_css)
        self._backends: Dict[str, BackendSpec] = {}
        # 先创建主框架
        self._init_main_frame()
        # 再初始化程序菜单及其命令
        self._init_commands()
        self._init_sidebars()
        # 创建工具栏调试窗口
        self.create_debug_combo()
        self.share()
        # 添加通用首选项面板
        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("Environment"),
            preference.GENERAL_ITEM_NAME,
            _("General"),
            GeneralOptionPanel
        )
        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("Environment"),
            preference.PROJECT_ITEM_NAME,
            _("Project"),
            projectview.ProjectOptionsPanel
        )

        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("Environment"),
            "WebBrowser",
            _("Web browser"),
            InternalBrowserOptionPanel
        )

        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("Environment"),
            "Startpage",
            _("Start page"),
            StartupOptionPanel
        )
        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("Editor"),
            preference.TEXT_ITEM_NAME,
            _('Text'),
            TextOptionsPanel
        )
        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("Editor"),
            "Document",
            _("Document"),
            DocumentOptionsPanel
        )
        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("Environment"),
            preference.FONTS_CORLORS_ITEM_NAME,
            _("Themes"),
            ColorfontOptionsPanel
        )
        preference.PreferenceManager().AddOptionsPanelClass(
            _("Misc"),
            "SearchText",
            _("Search Text"),
            SearchTextOptionPanel
        )
        preference.PreferenceManager().AddOptionsPanelClass(
            _("Misc"),
            "KeyBindings",
            _("KeyBindings"),
            KeybindOptionPanel
        )
        # 必须等菜单栏和主窗口初始化完成才在此处初始化插件
        self.init_plugins()
        # 因为需要查询插件信息, 起始页必须在插件初始化后才能创建
        self.MainFrame.GetNotebook().create_startup_page()
        # 加载上次程序退出时的活跃项目
        self.SetCurrentProject()
        # 先加载历史项目文件,然后打开从命令行传递的项目参数文件
        self._open_commandline_args()
        # self.ShowTipfOfDay()
        self.initializing = False
        self.installEventFilter(self)
        return True

    def create_document_manager(self):
        from .lib.docmanager import DocManager
        return DocManager()

    def eventFilter(self, obj, event):
        """Event filter to catch ESC application wide.

        Pass focus explicitly on broken window managers when the app is
        activated; Catch Ctrl+1 and Ctrl+2 application wide;
        """
        del obj     # unused argument
        try:
            event_type = event.type()
            if event_type == QEvent.ApplicationActivate:
                if self.frame:
                    self.frame.check_external_changes()
        except:
            pass
        if not self.GetDebug():
            self.background_listen_load()
        return False

    def init_app_styles(self):
        # 加载应用程序支持的皮肤样式,如果皮肤样式为空,则表示使用qt程序原生的应用程序样式
        for key, value in constants.APPLICATION_LOOKS.items():
            if value == []:
                self.add_applicatioin_look(key)
            else:
                for skin_name in value:
                    self.add_applicatioin_look(skin_name)

    def init_app_configs(self):
        '''
            初始化配置文件以及应用程序信息
        '''
        self.init_app_styles()
        # 初始化api服务器地址,优先使用配置文件配置的地址,如果没有配置使用默认地址
        config_api_server = utils.get_app_config("IDE", "api_server", None)
        if config_api_server is not None:
            ApiServer.HOST_SERVER_ADDR = config_api_server

    # 统计插件加载时间
    @utils.compute_time
    def init_plugins(self):
        self.show_splash_message(_('Loading plugins...'))
        self.LoadDefaultPlugins()
        # 鉴于首选项面板的加载顺序, 在此处加载文件视图选项面板正合适
        from .sidebar.fileview import FileviewOptionPanel
        # 首选项文件视图面板
        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("Misc"),
            "FileView",
            _("File View"),
            FileviewOptionPanel
        )
        self.MainFrame.init_plugins()
        # 在插件初始化完后才创建项目菜单和外观菜单
        self.MainFrame.projectview._init_commands()
        self.init_ui_theme_menu()
        if self._splash is None:
            self.frame.show()
        else:
            # 启动图片显示时隐藏主窗口并且设置窗口透明度为0
            self.frame.hide()
            self.frame.setWindowOpacity(0.0)
        self.MainFrame.restoreSplitterSizes()

    def report_exception(self, exc, val, tb):
        title = _("Internal error")
        utils.get_logger().exception(title, exc_info=(exc, val, tb))
        # 是否重定向异常信息到消息对话框
        if utils.profile_get_int(globalkeys.REDIRECT_APP_EXCEPTION, self.GetDebug()):
            msg = ''.join(traceback.format_exception(exc, val, tb))
            # 异常输出重定向到消息对话框中
            dlg = ExceptionMessageDialog(title, msg, self.MainFrame)
            dlg.exec_()

    def LoadDefaultPlugins(self):
        '''
            默认插件在consts.DEFAULT_PLUGINS中指定
        '''

    def CreateLangLexer(self):
        '''
            创建编辑器支持的各种编程语言信息,
            这里仅创建通用的编程语言
        '''
        LexerFactory.CreateLangLexer()

    def LoadLexerTemplates(self):
        '''
            将编程语言转换为软件支持的文档模板
        '''
        LexerFactory.LoadLexerTemplates(self.GetDocumentManager())

    def CreateProjectTemplate(self):
        from .project import view as projectview
        from .project import document as projectdocument
        from .project import ext
        self.default_project_template = projectview.ProjectTemplate(
            self.GetDocumentManager(),
            _("Project File"),
            "*%s" % ext.COMMON_PROJECT_EXTENSION,
            os.getcwd(),
            ext.COMMON_PROJECT_EXTENSION,
            "Project Document",
            _("Project viewer"),
            projectdocument.ProjectDocument,
            projectview.ProjectView,
            icon=qtimage.project_icon()
        )
        self.GetDocumentManager().AssociateTemplate(self.default_project_template)
        return self.default_project_template

    def GetDefaultLangId(self):
        return lang.ID_LANG_TXT

    def GotoView(self, file_path, *, lineNum=-1, colno=-1, trace_track=True, load_outline=True):
        docs = self.GetDocumentManager().CreateDocument(
            file_path, DOC_SILENT | DOC_OPEN_ONCE)
        if docs == []:
            return None
        foundview = docs[0].GetFirstView()
        if foundview:
            foundview.GetFrame().SetFocus()
            foundview.Activate()
            if not hasattr(foundview, "GotoLine"):
                return None
            if colno == -1:
                foundview.GotoLine(lineNum)
            else:
                # 定位到具体位置时是否追踪位置
                if trace_track:
                    foundview.GotoPos(lineNum, colno)
                else:
                    foundview.GetCtrl().GotoPos(lineNum, colno)
            return foundview
        return None

    def GetPluginManager(self):
        """Returns the plugin manager used by this application
        @return: Apps plugin manager
        @see: L{plugin}

        """
        return self._pluginmgr

    def set_plugin_manager(self, pluginmgr):
        self._pluginmgr = pluginmgr

    def add_message_catalog(self, name, path):
        """
            添加翻译文件的查找路径,在插件中使用,如果插件需要翻译,可以在egg文件里面添加翻译文件在egg文件里面的相对路径
        """
        if self.locale is not None:
            # 这里会把egg文件解压到一个临时的目录,以便程序能搜索到翻译文件的绝对路径
            # windows egg文件的临时目录
            utils.get_logger().debug('temp cache egg path is %s', path)
            path = resource_filename(path, 'locale')
            self.locale.add_catalog_lookup_pathprefix(path)
            self.locale.add_catalog(name)

    def InsertCommand(
        self,
        insert_command_id,
        command_id,
        menu,
        command_label,
        handler,
        accelerator=None,
        image=None,
        add_separator=False,
        tester=None,
        kind=constants.NORMAL_MENU_ITEM_KIND,
        pos=MenuItemPosition.INSERT_BEFORE
    ):
        assert isinstance(command_id, int)
        if image is not None and isinstance(image, str):
            image = self.GetImage(image)
        if isinstance(menu, str):
            menu = find_menu(menu, self.Menubar)
        if accelerator is None:
            accelerator = MenubarMixin.KEY_BINDER.GetBinding(command_id)
        if pos == MenuItemPosition.INSERT_BEFORE:
            menu_item = menu.InsertBefore(
                insert_command_id,
                command_id,
                command_label,
                handler=handler,
                img=image,
                accelerator=accelerator,
                kind=kind,
                tester=tester
            )
        elif pos == MenuItemPosition.INSERT_AFTER:
            menu_item = menu.InsertAfter(
                insert_command_id,
                command_id,
                command_label,
                handler=handler,
                img=image,
                accelerator=accelerator,
                kind=kind,
                tester=tester
            )
        if add_separator:
            menu.insert_separator(menu_item)
        return menu_item

    def AddDefaultCommand(self,
                          command_id,
                          menu,
                          command_label,
                          handler,
                          accelerator=None,
                          image=None,
                          include_in_toolbar=False,
                          add_separator=False,
                          kind=constants.NORMAL_MENU_ITEM_KIND
                          ):
        return self.AddCommand(
            command_id,
            menu,
            command_label,
            handler,
            accelerator,
            image,
            include_in_toolbar,
            add_separator,
            lambda: self.UpdateUI(command_id),
            kind
        )

    def AddDefaultEditorCommand(self,
                                command_id,
                                menu,
                                command_label,
                                handler,
                                accelerator=None,
                                image=None,
                                include_in_toolbar=False,
                                add_separator=False,
                                kind=constants.NORMAL_MENU_ITEM_KIND
                                ):
        return self.AddCommand(
            command_id,
            menu,
            command_label,
            handler,
            accelerator,
            image,
            include_in_toolbar,
            add_separator,
            lambda: self.UpdateEditorUI(command_id),
            kind
        )

    def AddCommand(self,
                   command_id,
                   menu,
                   command_label,
                   handler,
                   accelerator=None,
                   image=None,
                   include_in_toolbar=False,
                   add_separator=False,
                   tester=None,
                   kind=constants.NORMAL_MENU_ITEM_KIND
                   ):
        '''
            tester表示菜单状态更新的回调函数,返回bool值
            default_command表示菜单是否在文本编辑区为空白时(即没有一个文本编辑窗口),菜单状态为灰选
        '''
        if image is not None and isinstance(image, str):
            image = self.GetImage(image)

        if accelerator is None:
            accelerator = MenubarMixin.KEY_BINDER.GetBinding(command_id)

        if isinstance(menu, str):
            menu = find_menu(menu, self.Menubar)

        item = menu.Append(
            command_id,
            command_label,
            handler=handler,
            img=image,
            kind=kind,
            accelerator=accelerator,
            tester=tester
        )
        if add_separator:
            menu.add_separator()
        if include_in_toolbar:
            self.MainFrame.AddToolbarButton(
                command_id, item.action, add_separator, tester)
        return item

    def UpdateUI(self, command_id):
        '''
            处理所有窗口的菜单工具栏更新事件,有的菜单工具栏按钮适用于多个窗口,
            有的只适用于编辑区域窗口
        '''
        current_view = self.GetDocumentManager().GetCurrentView()
        if current_view is None:
            return self.MainFrame.UpdateUI(command_id)
        return current_view.UpdateUI(command_id) or self.MainFrame.UpdateUI(command_id)

    def UpdateEditorUI(self, command_id):
        '''
            处理编辑区域窗口的菜单工具栏更新事件,大部分菜单工具栏按钮只适用于编辑窗口
        '''
        current_editor = self.MainFrame.GetNotebook().currentWidget()
        if current_editor is None:
            return False
        active_editor_view = current_editor.GetView()
        return active_editor_view.UpdateUI(command_id)

    def create_debug_combo(self):
        self.debuger_combo = self.MainFrame.GetToolBar().AddCombox()
        self.debuger_combo.addItem(_("Configuration"))
        self.debuger_combo.setCurrentIndex(-1)
        self.debuger_combo.currentIndexChanged.connect(self.selectdebugger)

    def goto_web_view(self, webview_template):
        doc = self.GetDocumentManager().CreateTemplateDocument(
            webview_template,
            _("Internal web browser"),
            DOC_SILENT | DOC_OPEN_ONCE | constants.INTERNAL_WEB_BROWSER
        )
        if doc:
            home_page = utils.profile_get(
                globalkeys.WEB_HOME_PAGE_KEY, ApiServer.HOST_SERVER_ADDR)
            doc.GetFirstView().LoadUrl(home_page)

    def get_current_project(self):
        return self.MainFrame.projectview.GetCurrentProject()

    @ui_utils.update_toolbar
    @ui_utils.check_debugger
    def Run(self):
        '''
            在终端中运行程序
        '''
        if self.get_current_project() is not None:
            self.MainFrame.activateProjectTab()
        self.GetDebugger().Run()

    @ui_utils.update_toolbar
    @ui_utils.check_debugger
    def Debug(self):
        '''
            在程序调试窗口中运行程序
        '''
        if self.get_current_project() is not None:
            self.MainFrame.activateProjectTab()
        self.GetDebugger().Debug()

    @exceptions.catch_exception
    def open_terminator(self, filename=None):
        if filename:
            if os.path.isdir(filename):
                cwd = filename
            else:
                cwd = os.path.dirname(filename)
        else:
            cwd = os.getcwd()
        if utils.is_windows():
            subprocess.Popen('start cmd.exe', shell=True, cwd=cwd)
        else:
            subprocess.Popen('gnome-terminal', shell=True, cwd=cwd)

    def GetImage(self, file_name):
        return qtimage.load_icon(file_name)

    def get_project_browser_class(self):
        '''
            项目浏览器类,可能在派生类中继承
        '''
        from .project.browser import ProjectBrowser
        return ProjectBrowser

    @ui_utils.update_toolbar
    def on_open(self):
        docs = self.GetDocumentManager().CreateDocument('', DEFAULT_DOCMAN_FLAGS)
        # 检查文件扩展名是否有对应的文件扩展插件
        # if docs:
        #   ui_utils.CheckFileExtension(docs[0].GetFilename(),False)

    @ui_utils.update_toolbar
    def on_new(self):
        self.GetDocumentManager().CreateDocument('', DOC_NEW)

    @ui_utils.update_toolbar
    def on_close(self):
        self.MainFrame.CloseDoc()

    @ui_utils.update_toolbar
    def on_closeall(self):
        self.MainFrame.CloseAllDocs()

    @ui_utils.update_toolbar
    def on_filesave(self):
        """
        Saves the current document by calling wxDocument.Save for the current
        document.
        """
        doc = self.GetDocumentManager().GetCurrentDocument()
        if not doc:
            return
        doc.Save()

    @ui_utils.update_toolbar
    def on_filesave_as(self):
        """
        Calls wxDocument.SaveAs for the current document.
        """
        doc = self.GetDocumentManager().GetCurrentDocument()
        if not doc:
            return
        self.saveas_document(doc)

    def saveas_document(self, doc):
        '''
            另存为文件
        '''
        # 另存文件之前的文件名
        old_filename = doc.GetFilename()
        if not doc.SaveAs():
            return
        # 另存文件之后的文件名
        new_filename = doc.GetFilename()
        # 比较另存文件之前和之后的文件名,如果不一致,则从监视中删除先前的文件,并监视新的文件名
        if doc.IsWatched and not fileutils.ComparePath(new_filename, old_filename):
            doc.FileWatcher.RemoveFile(old_filename)

    @ui_utils.update_toolbar
    def on_filesave_all(self):
        """
        Saves all of the currently open documents.
        """
        docs = self.GetDocumentManager().GetDocuments()
        # save child documents first
        for doc in docs:
            doc.Save()

    def can_quit(self):
        # 程序退出时问询所有插件是否可以退出
        try:
            if not self._pluginmgr.Exit(query_exit=False):
                return False
        except Exception:
            utils.get_logger().exception('')
            utils.get_logger().error("query plugin exit error...")
        # 先询问是否允许关闭调试器
        if self.GetDebugger() is not None and not self.GetDebugger().CloseDebugger():
            return False
        # 查询是否允许关闭所有窗口
        if not self.MainFrame.close_windows():
            return False
        if not self.GetDocumentManager().Clear(force=False):
            return False
        return True

    def save_layout(self):
        # 获取窗口是否处于最大化状态
        is_maximized = self.MainFrame.isMaximized()
        # 退出时记住窗口是否最大化
        utils.profile_set(globalkeys.FRAME_MAXIMIZED_KEY, is_maximized)
        # 窗口处于非最大化时保存窗口的位置和大小信息
        if not is_maximized:
            # 程序退出时记住界面的坐标位置以及宽高
            utils.get_logger().debug(
                "save current windows geometry is x:%d,y:%d,width:%d,height:%d",
                self.MainFrame.x(),
                self.MainFrame.y(),
                self.MainFrame.width(),
                self.MainFrame.height()
            )
            # 位置可能出现负值, 不允许负值, 最小值为0
            ypos = max(self.MainFrame.y(), 0)
            xpos = max(self.MainFrame.x(), 0)
            utils.profile_set(globalkeys.FRAME_TOP_LOC_KEY, ypos)
            utils.profile_set(globalkeys.FRAME_LEFT_LOC_KEY, xpos)
            utils.profile_set(globalkeys.FRAME_WIDTH_KEY,
                              self.MainFrame.width())
            utils.profile_set(globalkeys.FRAME_HEIGHT_KEY,
                              self.MainFrame.height())
        self.MainFrame.save_layout()

    def on_exit(self):
        # 退出程序时首先移除事件过滤器
        self.removeEventFilter(self)
        if not self.can_quit():
            return
        # 程序退出时通知所有插件退出
        try:
            if not self._pluginmgr.Exit():
                return
        except:
            utils.get_logger().error("plugin exit error....")
        UserdataDb.get_db().record_end()
        self.save_layout()
        DocMgr.write_book()
        # 保存插件信息
        self._pluginmgr.write_plugin_config()
        utils.get_logger().info("application exit now....")
        self.quit()

    @ui_utils.update_toolbar
    def open_mru_file(self, n):
        """
        Opens the appropriate file when it is selected from the file history
        menu.
        """
        filename = self._docmanager.GetHistoryFile(n)
        if filename and os.path.exists(filename):
            self._docmanager.CreateDocument(filename, DOC_SILENT)
        else:
            self._docmanager.RemoveFileFromHistory(n)
            msg_title = self.GetAppName()
            if not msg_title:
                msg_title = _("File Error")
            if filename:
                QMessageBox.critical(
                    self.MainFrame,
                    msg_title,
                    _("The file '%s' doesn't exist and couldn't be opened!") % filename
                )

    def SetCurrentProject(self):
        self.show_splash_message(_('Loading project...'))
        # 先加载上次保存的所有项目
        self.MainFrame.projectview.LoadSavedProjects()
        # 再从上次保存的所有项目中加载上次运行的前台项目
        self.MainFrame.projectview.SetCurrentProject()

    def add_applicatioin_look(self, name):
        self.application_looks.append(name)

    def load_skin(self):
        self.show_splash_message(_('Loading themes...'))
        self.app_style_name = utils.profile_get(
            globalkeys.APP_STYLE_KEY, AppStyle.DEFAULT_APP_STYLE.value)

        self.app_skin_name = utils.profile_get(
            globalkeys.APP_SKIN_KEY, AppSkin.DEFAULT_APP_SKIN.value)
        # 不使用任何美化皮肤,使用pyqt5原生程序样式
        if self.app_style_name in [
            AppStyle.WINDOWS_QT_NATIVE_APP_STYLE.value,
            AppStyle.WINDOWS_NATIVE.value
        ]:
            self.skin = NativeSkin()
            self.setStyleSheet(QT_NATIVE_APP_CSSS)
            App.setStyle(self.app_style_name)
            return
        # 设置程序样式,使程序更美观
        App.setStyle(self.app_style_name)
        self.skin = Skin()
        self.skin.loadByName(self.app_skin_name)
        app_css = ''
        if self.skin['dark']:
            # 加载Old fashion green-black样式的深色配置方案
            import qdarkstyle
            from qdarkstyle.dark.palette import DarkPalette
            from qdarkstyle.light.palette import LightPalette
            # 加载程序使用的dark色css样式表,为字符串类型
            if self.app_skin_name == AppSkin.OLD_FASHION_GREENBLACK_SKIN.value:
                app_css = qdarkstyle.load_stylesheet(
                    qt_api='pyqt5', palette=DarkPalette)
            elif self.app_skin_name == AppSkin.OLD_FASHION_LIGHT_SKIN.value:
                app_css = qdarkstyle.load_stylesheet(
                    qt_api='pyqt5', palette=LightPalette)
        # Avoid having rectangular frames on the status bar and
        # some application wide style changes
        adjustment_css = self.skin['appCSS']
        if adjustment_css:
            app_css += constants.LF + adjustment_css
        # 如果有样式则加载css样式表,否则使用原生qt程序样式
        if app_css:
            # 设置css样式表
            self.setStyleSheet(app_css)

    def feedback(self):
        fileutils.startfile("https://gitee.com/wekay/NovalIDE/issues")

    def goto_web_site(self,):
        fileutils.startfile(ApiServer.HOST_SERVER_ADDR)

    def on_options(self):
        preference_dlg = preference.PreferenceDialog(
            self.MainFrame, selection=utils.profile_get("PrefereceOptionName", ''))
        preference_dlg.exec_()

    def hide_show_sidebars(self):
        '''
            显示隐藏侧边窗口
        '''
        views_menu = find_menu(_("&View"), self.Menubar)
        menu_item = views_menu.FindMenuItem(menuitems.ID_HIDE_SIDEBARS)
        if menu_item.action.text() == _("Hide sidebars"):
            self.MainFrame.hideall()
            menu_item.action.setText(_("Show sidebars"))
        else:
            self.MainFrame.showall()
            menu_item.action.setText(_("Hide sidebars"))

    def toogle_fullscreen(self):
        if not self.MainFrame.isFullScreen():
            # 全屏时是否隐藏菜单栏
            if utils.profile_get_int(globalkeys.HIDE_MENUBAR_KEY, False):
                self.MainFrame.show_menubar(False)
            FullscreenWidget.show_normal()
        else:
            FullscreenWidget.show_hide()

    def GetDefaultTextDocumentType(self):
        '''
            默认新建文本文档类型
        '''
        return SyntaxThemeManager.manager().GetLexer(self.GetDefaultLangId()).GetDocTypeName()

    def GetDebuggerClass(self):
        return self._debugger_class

    def GetDebugger(self):
        debugger_class = self.GetDebuggerClass()
        if debugger_class is None:
            return None
        debugger = debugger_class()
        current_project = self.get_current_project()
        debugger.SetCurrentProject(current_project)
        return debugger

    def add_backend(self, name, proxy_class, description, sort_key):
        self._backends[name] = BackendSpec(
            name,
            proxy_class,
            description,
            sort_key if sort_key is not None else description,
        )

        # assing names to related classes
        proxy_class.backend_name = name  # type: ignore

    def get_backends(self):
        return self._backends

    def new_module(self):
        lexer = SyntaxThemeManager.manager().GetLexer(self.GetDefaultLangId())
        temp = self.GetDocumentManager().FindTemplateForPath(
            "test.%s" % lexer.GetDefaultExt()
        )
        new_doc = temp.CreateDocument("", DOC_NEW)
        if new_doc:
            new_doc.SetDocumentName(temp.GetDocumentName())
            new_doc.SetDocumentTemplate(temp)
            new_doc.OnNewDocument()

    @ui_utils.update_toolbar
    @abc.abstractmethod
    def selectdebugger(self, i):
        '''
            select a application debugger
        '''

    def open_documentation(self):
        fileutils.startfile("https://wekay.gitee.io/novalide")

    def share(self):
        ShareData(self.MainFrame.GetStatusBar(), self.GetDebug()).start()

    def _init_commands(self):
        files_menu = find_menu(_("&File"), self.Menubar)
        self.AddCommand(
            menuitems.ID_NEW,
            files_menu,
            _("&New..."),
            self.on_new,
            image="toolbar/new.png",
            include_in_toolbar=True
        )
        self.AddCommand(
            menuitems.ID_OPEN,
            files_menu,
            _("&Open..."),
            self.on_open,
            image="toolbar/open.png",
            include_in_toolbar=True
        )
        self.AddDefaultEditorCommand(
            menuitems.ID_CLOSE,
            files_menu, _("&Close"),
            self.on_close,
            image="closebutton.png"
        )
        self.AddDefaultEditorCommand(
            menuitems.ID_CLOSE_ALL,
            files_menu,
            _("&Close A&ll"),
            self.on_closeall,
            add_separator=True
        )

        self.AddDefaultEditorCommand(
            menuitems.ID_SAVE,
            files_menu,
            _("&Save..."),
            self.on_filesave,
            image="toolbar/save.png",
            include_in_toolbar=True
        )
        self.AddDefaultEditorCommand(
            menuitems.ID_SAVEAS,
            files_menu,
            _("Save &As..."),
            self.on_filesave_as
        )

        self.AddDefaultCommand(
            menuitems.ID_SAVEALL,
            files_menu,
            _("Save All"),
            self.on_filesave_all,
            image="toolbar/saveall.png",
            include_in_toolbar=True,
            add_separator=True
        )

        self.AddCommand(
            menuitems.ID_EXIT,
            files_menu,
            _("E&xit"),
            self.on_exit,
            image="exit.png"
        )

        # 设置历史文件菜单为Files菜单
        docmanager = self.GetDocumentManager()
        docmanager.FileHistoryUseMenu(files_menu)
        # 加载历史文件记录到Files菜单最后
        docmanager.FileHistoryAddFilesToMenu()
        self.MainFrame.init_commands()
        views_menu = find_menu(_("&View"), self.Menubar)

        self.AddCommand(
            menuitems.ID_HIDE_SIDEBARS,
            views_menu,
            _("Hide sidebars"),
            self.hide_show_sidebars
        )
        self.AddCommand(
            menuitems.ID_SHOW_FULLSCREEN,
            views_menu,
            _("Show FullScreen"),
            self.toogle_fullscreen,
            image="monitor.png"
        )
        run_menu = find_menu(_("&Run"), self.Menubar)
        tools_menu = find_menu(_("&Tools"), self.Menubar)
        help_menu = find_menu(_("&Help"), self.Menubar)
        self.AddDefaultCommand(
            menuitems.ID_RUN,
            run_menu,
            _("&Start running"),
            self.Run,
            image="toolbar/run.png",
            include_in_toolbar=True
        )
        self.AddDefaultCommand(
            menuitems.ID_DEBUG,
            run_menu,
            _("&Start debugging"),
            self.Debug,
            image="toolbar/debug.png",
            include_in_toolbar=True,
        )
        self.AddCommand(
            menuitems.ID_OPEN_TERMINAL,
            tools_menu,
            _("&Open terminator..."),
            self.open_terminator,
            image="cmd.png"
        )
        self.AddCommand(
            menuitems.ID_OPEN_DOCUMENTATION,
            help_menu,
            _("Product documentation"),
            handler=self.open_documentation,
            image=self.GetImage("documentation.png")
        )
        self.AddCommand(
            menuitems.ID_GOTO_OFFICIAL_WEB,
            help_menu,
            _("&Visit NovalIDE website"),
            self.goto_web_site
        )
        self.AddCommand(
            menuitems.ID_FEEDBACK,
            help_menu,
            _("Feedback"),
            self.feedback
        )
        webview_template = docmanager.FindTemplateForTestPath(".com")
        self.AddCommand(
            menuitems.ID_WEB_BROWSER,
            tools_menu,
            _("&Internal web browser"),
            handler=lambda: self.goto_web_view(webview_template),
            image=webview_template.GetIcon()
        )

        self.AddCommand(
            menuitems.ID_PREFERENCES,
            tools_menu,
            _("&Options..."),
            self.on_options,
            image=self.GetImage("prefer.png"),
        )

    def _init_sidebars(self):
        from .sidebar import logview, sidebar, fileview
        from .findrep.resultview import FindResultsview

        # 首先加载日志窗口,日志窗口,其它插件才能写入日志到日志窗口中
        if self.GetDebug():
            self.MainFrame.AddView(
                "Logs",
                logview.LogView,
                _("Logs"),
                sidebar.SideBar.South,
                default_position_key=0,
                image_file="logview.png",
                active=True
            )
        self.MainFrame.AddView(
            constants.SEARCH_RESULTS_VIEW_NAME,
            FindResultsview,
            _("Search results"),
            sidebar.SideBar.South,
            image_file="search.png",
            default_position_key=1
        )
        self.MainFrame.AddView(
            constants.PROJECT_VIEW_NAME,
            self.get_project_browser_class(),
            _("Project browser"),
            sidebar.SideBar.West,
            default_position_key=0,
            image_file="project/project_view.png",
            active=True
        )
        self.MainFrame.AddView(
            constants.FILE_VIEW_NAME,
            fileview.FileFrame,
            _("File View"),
            sidebar.SideBar.West,
            default_position_key=1,
            image_file="filenav_nav.png"
        )

    def _init_main_frame(self):
        self.show_splash_message(_('Generating main window...'))
        from .mainwindow import IDEMainWindow

        IDEMainWindow(self._splash)
        self.lastWindowClosed.connect(self.quit)

    def __hook_callback_exception(self, exc, val, tb):
        '''
            捕获软件异常,并将异常信息输出到对话框中,只支持单线程异常
        '''
        sys.last_type = exc
        sys.last_value = val
        sys.last_traceback = tb

        # Keyboard interrupt is a special case
        if issubclass(exc, KeyboardInterrupt):
            self.quit()
            return
        self.report_exception(exc, val, tb)

    def get_menu(self, menu_name):
        return find_menu(menu_name, self.Menubar)

    def close_splash(self):
        super().close_splash()
        # 最大化窗口
        if utils.profile_get_int(globalkeys.FRAME_MAXIMIZED_KEY, True):
            self.frame.showMaximized()

    def register_search_provider(self, cls_obj):
        """Registers a search provider"""
        self.search_providers[cls_obj.getName()] = cls_obj

    def init_ui_theme_menu(self):
        if self._application_looks:
            view_menu = self.get_menu(_("&View"))
            theme_menu = NewQMenu(_("&Application Look"))
            view_menu.insert_menu_before(
                menuitems.ID_SHOW_FULLSCREEN,
                menuitems.ID_VIEW_APPLICAITON_LOOK,
                theme_menu
            )
            el_group = create_action_group(theme_menu)
            for name in self._application_looks:
                def apply_theme(name=name):
                    self.update_applook_config(name)
                    self.load_skin()
                ui_menu_item = self.AddCommand(
                    newid(),
                    theme_menu,
                    name,
                    apply_theme,
                    kind=constants.RADIO_MENU_ITEM_KIND
                )
                if name in [self.app_skin_name, self.app_style_name]:
                    ui_menu_item.action.setChecked(True)
                el_group.addAction(ui_menu_item.action)

    def update_applook_config(self, name):
        if name in [
            AppStyle.WINDOWS_QT_NATIVE_APP_STYLE.value,
            AppStyle.WINDOWS_NATIVE.value
        ]:
            utils.profile_set(globalkeys.APP_STYLE_KEY, name)
            utils.profile_set(globalkeys.APP_SKIN_KEY, '')
        else:
            utils.profile_set(globalkeys.APP_STYLE_KEY,
                              AppStyle.DEFAULT_APP_STYLE.value)
            utils.profile_set(globalkeys.APP_SKIN_KEY, name)
