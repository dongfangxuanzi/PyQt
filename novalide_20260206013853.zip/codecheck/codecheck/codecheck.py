import os
import re
from novalapp.util import ui_utils, utils, timeutils
from novalapp.lib.pyqt import (
    QLabel,
    QHBoxLayout,
    QCheckBox,
    Qt,
    QListWidget,
    QMessageBox,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QAbstractItemView,
    QHeaderView,
    QCursor,
    pyqtSignal,
    QRadioButton,
    QButtonGroup,
    QVBoxLayout,
    QDateTimeEdit,
    QDate,
    QDateTime
)
from novalapp.util.transfer import FiledownloadSerivce
from novalapp.project.wizard.page import BitmapTitledContainerWizardPage
from novalapp.python.project.property.runui import CommonInterpreterOptionPanel
from novalapp import _, get_app, newid
from novalapp.python.interpreter.exceptions import InterpretertoolNotExistError
from novalapp.python.interpreter.interpreterconfiguration.pipenv import InstallPackagesDialog
from novalapp.bars.menubar import NewQMenu
from novalapp.util import fileutils, pathutils
from novalapp.widgets.labels import LinkLabel
from novalapp.python.interpreter.interpreter import BuiltinPythonInterpreter, PythonInterpreter
from novalapp.python.interpreter.interpretermanager import InterpreterManager
from novalapp.preference.manager import GetOptionName
from novalapp.preference.preference import PreferenceDialog
from .codeutils import get_file_excludes_reg, check_git_plugin_installed
from .toolmanager import CodecheckToolManager
from .codeutils import get_tools_data_path, FilesregType, ScanMode
from . import configkeys
from .strings import MESSAGE_VIEW_NAME


def GetEnabledFlag(enabled):
    if enabled:
        return _("Disabled")
    return _("Enabled")


class CodecheckOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    """
    MAX_PATH_LENGTH = 40
    ID_COPY_TOOL_NAME = newid()
    ID_COPY_TOOL_VERSION = newid()
    ID_COPY_TOOL_PATH = newid()
    ID_GOTO_TOOL_PATH = newid()
    SIG_DOWNLOAD_ERROR = pyqtSignal(str)
    SIG_RELOAD_TOOLS = pyqtSignal()

    def __init__(self, parent, **kwargs):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self._plugin = kwargs.get('plugin')
        self.layout.setAlignment(Qt.AlignTop)

        self.project_repository_chkbox = QCheckBox(
            _("Codecheck project must be a git repository"))
        self.project_repository_chkbox.setChecked(utils.profile_get_int(
            configkeys.CODECHECK_PROJECT_MUSTBE_REPOSITORY_KEY, True))
        self.layout.addWidget(self.project_repository_chkbox)

        self.autorepair_chkbox = QCheckBox(
            _("Code must be committed before automatic repair is enabled"))
        self.autorepair_chkbox.setChecked(utils.profile_get_int(
            configkeys.PROJECT_FILES_MUSTBE_COMMITED_KEY, True))
        self.layout.addWidget(self.autorepair_chkbox)

        self.check_running_chkbox = QCheckBox(
            _("Check codecheck/fix process running when application exit."))
        self.check_running_chkbox.setChecked(utils.profile_get_int(
            configkeys.CHECK_CODECHECK_PROCESS_RUNNING_KEY, True))
        self.layout.addWidget(self.check_running_chkbox)

        self.close_opendoc_chkbox = QCheckBox(
            _("Close the open document after the automatic repair is complete"))
        self.close_opendoc_chkbox.setChecked(utils.profile_get_int(
            configkeys.CLOSE_OPENDOC_KEY, False))
        self.layout.addWidget(self.close_opendoc_chkbox)

        self.check_file_syntax_chkbox = QCheckBox(
            _("Check file syntax after each warning is fixed"))
        self.check_file_syntax_chkbox.setChecked(utils.profile_get_int(
            configkeys.CHECK_FILE_SYNTAX_KEY, True))
        self.layout.addWidget(self.check_file_syntax_chkbox)

        self.autofix_file_chkbox = QCheckBox(
            _("Auto fix file When file is saved"))
        self.autofix_file_chkbox.setChecked(utils.profile_get_int(
            configkeys.AUTOFIX_FILE_SAVE_KEY, False))
        self.layout.addWidget(self.autofix_file_chkbox)

        columns = [_('Name'), _('Version'), _(
            'Path'), _('Status'), _('Action')]
        self.tableview = QTableWidget(1, len(columns), self)
        self.tableview.setColumnWidth(0, 80)
        self.tableview.setColumnWidth(1, 80)
        self.tableview.setColumnWidth(2, 300)
        self.tableview.setColumnWidth(3, 50)
        self.tableview.setColumnWidth(4, 40)
        self.tableview.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableview.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableview.horizontalHeader().setSectionResizeMode(2, QHeaderView.Interactive)
        self.tableview.horizontalHeader().setStretchLastSection(True)
        self.layout.addWidget(self.tableview)
        self.tableview.verticalHeader().hide()
        self.tableview.setHorizontalHeaderLabels(columns)
        self.tableview.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tableview.customContextMenuRequested.connect(self.OnContextMenu)
        # 表格右键弹出菜单
        self.menu = None
        self.load_tools()
        self.SIG_DOWNLOAD_ERROR.connect(self.download_url_error)
        self.SIG_RELOAD_TOOLS.connect(self.load_tools)

    def OnContextMenu(self):
        row = self.tableview.currentRow()
        if row == -1:
            return
        if self.menu is None:
            self.menu = NewQMenu(self)
            self.menu.Append(
                CodecheckOptionPanel.ID_COPY_TOOL_NAME,
                _("Copy Name"),
                handler=lambda: self.ProcessEvent(
                    CodecheckOptionPanel.ID_COPY_TOOL_NAME)
            )
            self.menu.Append(
                CodecheckOptionPanel.ID_COPY_TOOL_VERSION,
                _("Copy Version"),
                handler=lambda: self.ProcessEvent(
                    CodecheckOptionPanel.ID_COPY_TOOL_VERSION)
            )
            self.menu.Append(
                CodecheckOptionPanel.ID_COPY_TOOL_PATH,
                _("Copy Path"),
                handler=lambda: self.ProcessEvent(
                    CodecheckOptionPanel.ID_COPY_TOOL_PATH)
            )
            self.menu.Append(
                CodecheckOptionPanel.ID_GOTO_TOOL_PATH,
                _("Open Path in Explorer"),
                handler=lambda: self.ProcessEvent(
                    CodecheckOptionPanel.ID_GOTO_TOOL_PATH)
            )
        self.menu.popup(QCursor.pos())

    def ProcessEvent(self, event_id):
        row = self.tableview.currentRow()
        tool = CodecheckToolManager.manager().CHECK_TOOLS[row]
        if event_id == CodecheckOptionPanel.ID_COPY_TOOL_NAME:
            ui_utils.copytoclipboard(tool.name)
            return True
        if event_id == CodecheckOptionPanel.ID_COPY_TOOL_VERSION:
            ui_utils.copytoclipboard(tool.version)
            return True
        if event_id == CodecheckOptionPanel.ID_COPY_TOOL_PATH:
            # 路径可能显示省略号,因此不能使用界面上显示的路径值
            ui_utils.copytoclipboard(tool.path)
            return True
        if event_id == CodecheckOptionPanel.ID_GOTO_TOOL_PATH:
            self.GotoPath(tool.path)
            return True

    def GotoPath(self, path):
        pathutils.safe_open_file_directory(path)

    def load_tools(self):
        self.tableview.setRowCount(
            len(CodecheckToolManager.manager().CHECK_TOOLS))
        for i, check_tool in enumerate(CodecheckToolManager.manager().CHECK_TOOLS):
            nameitem = QTableWidgetItem(check_tool.name)
            self.tableview.setItem(i, 0, nameitem)

            versionitem = QTableWidgetItem(check_tool.version)
            versionitem.setTextAlignment(Qt.AlignCenter)
            self.tableview.setItem(i, 1, versionitem)

            # 路径过长显示省略号
            path = check_tool.path
            if len(path) > CodecheckOptionPanel.MAX_PATH_LENGTH:
                path = path[0:CodecheckOptionPanel.MAX_PATH_LENGTH] + "..."
            pathitem = QTableWidgetItem(path)
            self.tableview.setItem(i, 2, pathitem)
            if not check_tool.enabled:
                utils.get_logger().warning('codecheck tool %s is disabled', check_tool.name)
            defaultButton = QPushButton(GetEnabledFlag(check_tool.enabled))
            defaultButton.setDown(True)  # 默认为按下的状态
            defaultButton.setStyleSheet('QPushButton{margin:3px};')
            defaultButton.clicked.connect(self.update_tool_status)
            self.tableview.setCellWidget(i, 3, defaultButton)

            if check_tool.path == "":
                install_update_label = LinkLabel(
                    _("Install"), self.install_update_tool, alignment=Qt.AlignCenter)
            else:
                install_update_label = LinkLabel(
                    _("Update"), self.install_update_tool, alignment=Qt.AlignCenter)
            self.tableview.setCellWidget(i, 4, install_update_label)

    def install_update_tool(self):
        label = self.sender()
        row = self.tableview.currentRow()
        tool = CodecheckToolManager.manager().CHECK_TOOLS[row]
        if tool.version == BuiltinPythonInterpreter.UNKNOWN_VERSION_NAME:
            assert (label.text().find(_("Install")) != -1)
            if get_app().MainFrame.GetView("Messages")._plugin._use_internal_interpreter:
                self.install_internal_packages()
            else:
                interpreter = InterpreterManager.manager().ShowChooseInterpreterDlg(self)
                if not interpreter or interpreter.IsBuiltIn:
                    return
                try:
                    interpreter.find_tool(tool.name)
                    CodecheckToolManager.manager().register_python_tools(interpreter)
                except InterpretertoolNotExistError as ex:
                    utils.get_logger().error(
                        'find tool %s in interpreter "%s" error:%s',
                        tool.name,
                        interpreter.name,
                        str(ex)
                    )
                    dlg = InstallPackagesDialog(
                        get_app().GetTopWindow(),
                        interpreter,
                        pkg_name=tool.name,
                        install_args='--user %s' % tool.name,
                        autorun=False
                    )
                    dlg.exec_()
                finally:
                    self.load_tools()
        else:
            assert (label.text().find(_("Update")) != -1)
            dlg = InstallPackagesDialog(
                get_app().GetTopWindow(),
                tool.interpreter,
                pkg_name=tool.name,
                install_args='-U %s' % tool.name,
                autorun=True
            )
            dlg.exec_()

    def install_internal_packages(self):
        filename = "tools.zip"
        fileurl = ""
        if utils.is_windows():
            fileurl = ""
        FiledownloadSerivce().download_file(fileurl, filename, self.end_download, self)

    def end_download(self, package_path, parent):
        tools_data_path = get_tools_data_path()
        fileutils.makedirs(tools_data_path)
        try:
            fileutils.unzip(package_path, tools_data_path)
        except Exception as ex:
            utils.get_logger().exception(
                'unzip file %s to path %s fail exception',
                package_path,
                tools_data_path
            )
        venv_cfg_path = os.path.join(
            tools_data_path, r"python\pylint\venv\pyvenv.cfg")
        if not os.path.exists(venv_cfg_path):
            return
        if utils.is_windows():
            home_path = os.path.join(tools_data_path, r"python\python3\win")
            base_executable = os.path.join(home_path, "python.exe")
        PythonInterpreter.update_venv_cfg(venv_cfg_path, "home", home_path)
        PythonInterpreter.update_venv_cfg(
            venv_cfg_path, "base-executable", base_executable)
        if self._plugin.load_internal_interpreter():
            self.SIG_RELOAD_TOOLS.emit()

    def download_url_error(self, error_msg):
        QMessageBox.critical(self, _("Error"), _(
            "Download fail:%s") % error_msg)

    def update_tool_status(self):
        button = self.sender()
        row = self.tableview.currentRow()
        tool = CodecheckToolManager.manager().CHECK_TOOLS[row]
        tool.enabled = not tool.enabled
        button.setText(GetEnabledFlag(tool.enabled))
        button.setDown(tool.enabled)

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        utils.profile_set(configkeys.CODECHECK_PROJECT_MUSTBE_REPOSITORY_KEY,
                          self.project_repository_chkbox.isChecked())
        utils.profile_set(configkeys.PROJECT_FILES_MUSTBE_COMMITED_KEY,
                          self.autorepair_chkbox.isChecked())
        utils.profile_set(configkeys.CHECK_CODECHECK_PROCESS_RUNNING_KEY,
                          self.check_running_chkbox.isChecked())

        utils.profile_set(configkeys.CHECK_FILE_SYNTAX_KEY,
                          self.check_file_syntax_chkbox.isChecked())

        utils.profile_set(configkeys.CLOSE_OPENDOC_KEY,
                          self.close_opendoc_chkbox.isChecked())

        utils.profile_set(configkeys.AUTOFIX_FILE_SAVE_KEY,
                          self.autofix_file_chkbox.isChecked())
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            utils.profile_set(
                "%s%s" % (check_tool.name, configkeys.TOOL_STATUS_KEY), check_tool.enabled)
        return True


class CodecheckPropertyPanel(CommonInterpreterOptionPanel):
    """description of class"""

    QDATE_TIME_FORMAT = "yyyy-MM-dd"

    def __init__(self, parent, item, current_project):
        super().__init__()
        self.layout.setAlignment(Qt.AlignTop)
        self.enable_codecheck_checkbox = QCheckBox(_("Use codecheck"))
        self.enable_codecheck_checkbox.setChecked(utils.profile_get_int(
            current_project.GetKey(configkeys.USE_CODECHECK_PROJECT_KEY), True))
        self.layout.addWidget(self.enable_codecheck_checkbox)
        self.enable_codecheck_checkbox.clicked.connect(self.enable_codecheck)

        self.enable_fix2to3_chkbox = QCheckBox(
            _("Enable fix python2 code to python3"))
        self.enable_fix2to3_chkbox.setChecked(utils.profile_get_int(
            current_project.GetKey(configkeys.ENABLE_FIX_2TO3_KEY), False))
        self.layout.addWidget(self.enable_fix2to3_chkbox)

        hbox_layout = QHBoxLayout()
        self.button_group = QButtonGroup()
        self.include_files_radio = QRadioButton(_('Include'))
        self.button_group.addButton(self.include_files_radio)
        self.include_files_radio.clicked.connect(self.update_files_reg)
        file_reg_type = utils.profile_get_int(
            current_project.GetKey(configkeys.FILES_REGTYPE_KEY), -1)
        if file_reg_type == FilesregType.INCLUDE_FILES.value:
            self.include_files_radio.setChecked(True)
        hbox_layout.addWidget(self.include_files_radio)

        self.exclude_files_radio = QRadioButton(_('Exclude'))
        self.button_group.addButton(self.exclude_files_radio)
        self.exclude_files_radio.clicked.connect(self.update_files_reg)
        if file_reg_type == FilesregType.EXCLUDE_FILES.value:
            self.exclude_files_radio.setChecked(True)
        hbox_layout.addWidget(self.exclude_files_radio)

        hbox_layout.addWidget(QLabel(_('these files') + ":"))
        self.files_reg_ctrl = QLineEdit()
        self.files_reg_ctrl.setPlaceholderText(
            _('Input regular expressions to filter files'))

        hbox_layout.addWidget(self.files_reg_ctrl)
        self.test_btn = QPushButton(_("Test regex"))
        self.test_btn.clicked.connect(self.test_regex)
        hbox_layout.addWidget(self.test_btn)
        self.layout.addLayout(hbox_layout)

        vbox_layout = QVBoxLayout()
        vbox_layout.addWidget(QLabel(_('Check modes') + ":"))

        hbox_layout = QHBoxLayout()
        hbox_layout.setAlignment(Qt.AlignLeft)
        self.changed_files_radio = QRadioButton(_('Changed files'))
        self.changed_files_radio.setToolTip(_("Check changed files, if no changes, Check last commit changed files"))
        self.changed_files_radio.toggled.connect(lambda: self.update_datetime_edit(self.changed_files_radio))
        scan_mode = utils.profile_get_int(
            current_project.GetKey(configkeys.SCAN_MODE_KEY),
            ScanMode.FULL_FILES_MODE.value
        )
        hbox_layout.addWidget(self.changed_files_radio)

        self.full_files_radio = QRadioButton(_('Full files'))
        self.full_files_radio.setToolTip(_("Check full files"))
        # toggled信号与槽函数绑定
        self.full_files_radio.toggled.connect(lambda: self.update_datetime_edit(self.full_files_radio))
        hbox_layout.addWidget(self.full_files_radio)

        self.time_section_files_radio = QRadioButton(_('Timespan files'))
        self.time_section_files_radio.setToolTip(_("Check time span files"))
        self.time_section_files_radio.toggled.connect(lambda: self.update_datetime_edit(self.time_section_files_radio))
        hbox_layout.addWidget(self.time_section_files_radio)

        vbox_layout.addLayout(hbox_layout)
        # 指定当前地日期为控件的日期，注意没有指定时间
        self.datetime_edit = QDateTimeEdit(QDate.currentDate(), self)
        self.datetime_edit.setDisplayFormat(self.QDATE_TIME_FORMAT)
        # 允许弹出日历控件
        self.datetime_edit.setCalendarPopup(True)
        vbox_layout.addWidget(self.datetime_edit)

        if scan_mode == ScanMode.CHANGED_FILES_MODE.value:
            self.changed_files_radio.setChecked(True)
        elif scan_mode == ScanMode.FULL_FILES_MODE.value:
            self.full_files_radio.setChecked(True)
        elif scan_mode == ScanMode.TIME_SECTION_FILES_MODE.value:
            self.time_section_files_radio.setChecked(True)
        base_timestamp = utils.profile_get_int(
            current_project.GetKey(configkeys.BASE_TIMESTAMP_KEY),
            -1
        )
        if base_timestamp != -1:
            timestr = timeutils.timestamp_to_timestr(base_timestamp)
            utils.get_logger().debug("timespan mode base datetime is %s", timestr)
            dtime = QDateTime.fromString(timestr, self.QDATE_TIME_FORMAT)
            self.time_section_files_radio.setToolTip(_("Check files after date:%s") % timestr)
            self.datetime_edit.setDateTime(dtime)
        self.layout.addLayout(vbox_layout)

        self.plugin = None
        self.current_project = current_project
        self.enable_codecheck()
        self.update_files_reg()

    def update_datetime_edit(self, radio_button):
        if radio_button == self.time_section_files_radio and self.time_section_files_radio.isChecked():
            self.datetime_edit.setVisible(True)
        else:
            self.datetime_edit.setVisible(False)

    def update_files_reg(self):
        if self.exclude_files_radio.isChecked():
            self.files_reg_ctrl.setText(utils.profile_get(
                self.current_project.GetKey(configkeys.CODECHECK_EXCLUDE_FILES_KEY), ""))
            self.test_btn.setEnabled(True)
        elif self.include_files_radio.isChecked():
            self.files_reg_ctrl.setText(utils.profile_get(
                self.current_project.GetKey(configkeys.CODECHECK_INCLUDE_FILES_KEY), ""))
            self.test_btn.setEnabled(True)
        else:
            self.test_btn.setEnabled(False)

    def enable_codecheck(self):
        if self.enable_codecheck_checkbox.isChecked():
            self.include_files_radio.setEnabled(True)
            self.exclude_files_radio.setEnabled(True)
            self.files_reg_ctrl.setEnabled(True)
            self.enable_fix2to3_chkbox.setEnabled(True)
            self.test_btn.setEnabled(True)
        else:
            self.files_reg_ctrl.setEnabled(False)
            self.enable_fix2to3_chkbox.setEnabled(False)
            self.test_btn.setEnabled(False)
            self.include_files_radio.setEnabled(False)
            self.exclude_files_radio.setEnabled(False)

    def test_regex(self):
        text = self.files_reg_ctrl.text().strip()
        if text == "":
            QMessageBox.information(self, get_app().GetAppName(), _(
                "Please input a valid reg text"))
            return
        regstr = get_file_excludes_reg(text)
        matched_files = []
        for filepath in self.current_project.GetModel().filePaths:
            if re.search(regstr, filepath, re.I):
                matched_files.append(filepath)
        matched_files_count = len(matched_files)
        if matched_files_count == 0:
            QMessageBox.information(
                self, get_app().GetAppName(), _("there is no matched files"))
        elif matched_files_count > 50:
            QMessageBox.information(self, get_app().GetAppName(), _(
                "there is total %d matched files") % matched_files_count)
        else:
            if self.include_files_radio.isChecked():
                QMessageBox.information(self, get_app().GetAppName(), _(
                    "Files below will be included:\n") + ",".join(matched_files))
            else:
                QMessageBox.information(self, get_app().GetAppName(), _(
                    "Files below will be excluded:\n") + ",".join(matched_files))

    def set_plugin(self, plugin):
        self.plugin = plugin

    def OnOK(self, optionsDialog):
        if self.get_current_interpreter() is None:
            return True
        codecheck_key = self.current_project.GetKey(
            configkeys.USE_CODECHECK_PROJECT_KEY)
        utils.profile_set(
            codecheck_key, self.enable_codecheck_checkbox.isChecked())
        if self. exclude_files_radio.isChecked():
            utils.profile_set(self.current_project.GetKey(configkeys.FILES_REGTYPE_KEY),
                              FilesregType.EXCLUDE_FILES.value)
            utils.profile_set(self.current_project.GetKey(configkeys.CODECHECK_EXCLUDE_FILES_KEY),
                              self.files_reg_ctrl.text().strip())
        elif self.include_files_radio.isChecked():
            utils.profile_set(self.current_project.GetKey(configkeys.FILES_REGTYPE_KEY),
                              FilesregType.INCLUDE_FILES.value)
            utils.profile_set(self.current_project.GetKey(configkeys.CODECHECK_INCLUDE_FILES_KEY),
                              self.files_reg_ctrl.text().strip())
        utils.profile_set(
            self.current_project.GetKey(configkeys.ENABLE_FIX_2TO3_KEY),
            self.enable_fix2to3_chkbox.isChecked()
        )

        if self.changed_files_radio.isChecked():
            try:
                # 检查gitcli插件是否安装
                check_git_plugin_installed()
            except RuntimeError as ex:
                QMessageBox.information(
                    self,
                    get_app().GetAppName(),
                    str(ex)
                )
                return False
            utils.profile_set(self.current_project.GetKey(configkeys.SCAN_MODE_KEY),
                              ScanMode.CHANGED_FILES_MODE.value
                              )
        elif self.full_files_radio.isChecked():
            utils.profile_set(self.current_project.GetKey(configkeys.SCAN_MODE_KEY),
                              ScanMode.FULL_FILES_MODE.value
                              )
        elif self.time_section_files_radio.isChecked():
            utils.profile_set(self.current_project.GetKey(configkeys.SCAN_MODE_KEY),
                              ScanMode.TIME_SECTION_FILES_MODE.value
                              )
            # 日期时间
            date_time = self.datetime_edit.dateTime()
            utils.profile_set(self.current_project.GetKey(configkeys.BASE_TIMESTAMP_KEY),
                              int(date_time.toTime_t()))
        messageviewer = get_app().MainFrame.GetView(MESSAGE_VIEW_NAME)
        messageviewer.doc = self.current_project
        messageviewer.update_state()
        return True


class CodecheckOptionPage(BitmapTitledContainerWizardPage):
    """Creates the calculators interface
    @todo: Dissable << and >> when floating values are present
    @todo: When integer values overflow display convert to scientific notation
    @todo: Keybindings to numpad and enter key

    """

    def __init__(self, parent):
        """Initialiases the calculators main interface"""
        BitmapTitledContainerWizardPage.__init__(self, parent, ("New Codecheck Project Wizard"), _(
            "Setup Options\nPlease Specify option of your Codecheck setup"), "python_logo.png")
        self.can_finish = False

    def CreateContent(self, content_frame, **kwargs):
        hbox = QHBoxLayout()
        hbox.addWidget(QLabel(_('Choose codecheck tools') + ":"))
        self.listbox = QListWidget()
        tools = ['flake8', 'pylint']
        for i, tool in enumerate(tools):
            self.listbox.addItem(tool)
            listitem = self.listbox.item(i)
            listitem.setCheckState(Qt.Unchecked)
        hbox.addWidget(self.listbox)
        content_frame.addLayout(hbox)

    def Finish(self):
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            tool = CodecheckToolManager.manager().find_tool(listitem.text())
            if listitem.checkState() == Qt.Checked:
                tool.enabled = True
            else:
                tool.enabled = False
        return True

    def Validate(self):
        prev_page = self.GetPrev()
        selections = []
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            toolname = listitem.text()
            if listitem.checkState() == Qt.Checked:
                selections.append(toolname)
        interpreter = prev_page.get_select_interpreter()
        if not selections:
            QMessageBox.information(self, get_app().GetAppName(), _(
                "Please choose at least one tool"))
            return False
        for name in selections:
            if not interpreter.GetInstallPackage(name):
                QMessageBox.information(
                    get_app().GetTopWindow(),
                    _("Tool '%s' not installed") % name,
                    _("Tool '%s' not installed, you would like to use.\nTo set this, go to Tools-->Options and use the 'Codecheck' panel to install this tool.\n" % name)
                )
                preference_dlg = PreferenceDialog(
                    get_app().MainFrame,
                    selection=GetOptionName(_("Misc"), "CodeCheck")
                )
                preference_dlg.exec_()
                return False
        return True
