import re
import astroid
from astroid import nodes
from novalapp.widgets import simpledialog
from ..pylint_fix import PylintCommonFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range, get_add_range


class PylintC0411Fixer(PylintCommonFixer):
    '''
    规则说明:模块导入顺序错误
    '''

    FIX_CHOICES = [
        'Reverse import position',
        'Insert top position',
        'Insert bottom position'
    ]

    def __init__(self):
        super().__init__('C0411', True)
        self._reduce_line = False

    @staticmethod
    def reserve_nodes_position(textview, top_node, bottom_node):
        '''
        调换2个节点的位置
        '''
        exchange_fix_range = get_node_range(bottom_node)
        exchange_fix_range.replace_with_text(
            textview, top_node.as_string())
        fix_range = get_node_range(top_node)
        fix_range.replace_with_text(
            textview, bottom_node.as_string())
        return True

    @staticmethod
    def insert_top_position(textview, top_node, bottom_node):
        '''
        将底部的节点插入顶部节点的上方
        '''
        delele_range = get_node_range(bottom_node)
        delele_range.replace_with_text(
            textview, '')
        textview.delete_line(bottom_node.lineno - 1)

        add_range = get_add_range(top_node.lineno, 0)
        add_range.add_text(
            textview, bottom_node.as_string() + "\n")
        return True

    @staticmethod
    def insert_bottom_position(textview, top_node, bottom_node):
        '''
        将上方的节点插入底部节点的下方
        '''
        delele_range = get_node_range(top_node)
        delele_range.replace_with_text(
            textview, '')
        textview.delete_line(top_node.lineno - 1)

        add_range = get_add_range(bottom_node.lineno, 0)
        add_range.add_text(
            textview, top_node.as_string() + "\n")
        return True

    @classmethod
    def fix_nodes_position(
        cls,
        textview,
        top_node,
        bottom_node,
        choices: list,
        master,
        title="Fix import position",
        is_autofix_msg=False
    ):
        '''
        修复2个节点之间错误的位置关系,3中修复方案:
        1.调换节点位置
        2.将底部节点插入顶部节点上方
        3.将顶部节点插入底部下方
        '''
        if not is_autofix_msg:
            sel = simpledialog.asklist(
                title,
                "Please choose one fixer option",
                choices,
                selection=0,
                master=master
            )
        else:
            sel = 0
        if sel == -1:
            return False
        if 0 == sel:
            return cls.reserve_nodes_position(textview, top_node, bottom_node)
        if 1 == sel:
            return cls.insert_top_position(textview, top_node, bottom_node)
        if 2 == sel:
            return cls.insert_bottom_position(textview, top_node, bottom_node)
        return False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        line = msg.line
        self.load_module(textview, msg.filepath)
        standard_import_regstr = r'standard import "(.*)" should be placed before "(.*)" \(wrong-import-order\)'
        thirdparty_import_regstr = r'third party import "(.*)" should be placed before "(.*)" \(wrong-import-order\)'
        firstparty_import_regstr = r'first party import "(.*)" should be placed before "(.*)" \(wrong-import-order\)'
        res = re.search(standard_import_regstr, msg.msg)
        if not res:
            res = re.search(thirdparty_import_regstr, msg.msg)
            if not res:
                res = re.search(firstparty_import_regstr, msg.msg)
        if res:
            import_before_str, import_str = res.groups()
            import_node_type = None
            if re.match(r'from .* import \w+', import_str):
                import_node_type = nodes.ImportFrom
            elif re.match('import .*', import_str):
                import_node_type = nodes.Import
            elif re.match(r'from .* import\s+\*', import_str):
                import_node_type = nodes.ImportFrom
            else:
                return False
            extract_import_node = astroid.extract_node(import_str)
            import_before_node = astroid.extract_node(import_before_str)
            import_node = self.get_import_node(
                textview.ModuleAnalyzer.Module, line, import_node_type, extract_import_node)
            exchange_import_node = textview.ModuleAnalyzer.find_line_node(
                line)
            if import_node and exchange_import_node:
                if exchange_import_node.as_string() == import_before_node.as_string():
                    # 为了防止结点变动或者位置变换导致修复错误,必须满足以上条件才能进行修复功能
                    # 先使用通用sarif格式修复,如果不能修复则使用自定义方法修复
                    if super().fix_message(doc, msg):
                        return True
                    return self.fix_nodes_position(
                        textview,
                        import_node,
                        exchange_import_node,
                        self.FIX_CHOICES,
                        text_ctrl,
                        is_autofix_msg=self.is_autofix_msg
                    )
        return False

    def get_import_node(self, module, endline, import_node_type, extract_import_node):
        for child in module.body:
            if child.lineno > endline:
                break
            if isinstance(child, import_node_type):
                if isinstance(child, nodes.Import) and child.names == extract_import_node.names:
                    return child
                if isinstance(child, nodes.ImportFrom) and child.modname == extract_import_node.modname and child.names == extract_import_node.names:
                    return child
        return None
