from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg


class PylintF0010Fixer(PylintFixer):
    '''
        规则说明:编码声明错误
    '''

    def __init__(self):
        super().__init__('F0010', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textview.insert_declare_encoding(prompt=False)
        return True
