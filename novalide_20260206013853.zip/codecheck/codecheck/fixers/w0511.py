import re
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg


class PylintW0511Fixer(PylintFixer):
    '''
    规则说明:fixme/todo注释
    '''

    def __init__(self):
        super().__init__('W0511', False)

    @staticmethod
    def is_todo_line(text_ctrl, line):
        line_text = text_ctrl.get_line_text(line)
        if not re.search(r'#\s*(todo|fixme|XXX)', line_text, re.I):
            return False
        return True

    @staticmethod
    def delete_comment_line(textview, text_ctrl, msg_line):
        '''
        删除注释行,如果注释在行首则删除整行,如果注释在行尾,则删除行尾注释,不影响代码
        '''
        line_text = text_ctrl.get_line_text(msg_line)
        if line_text.lstrip().startswith('#'):
            textview.delete_line(msg_line)
        else:
            comment_index = line_text.find('#')
            start_pos = text_ctrl.position_from_linecol(
                msg_line, comment_index)
            end_pos = text_ctrl.position_from_linecol(msg_line, len(line_text))
            text_ctrl.replace_target(start_pos, end_pos, '')

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        if not self.is_todo_line(text_ctrl, msg.line):
            return False
        self.delete_comment_line(textview, text_ctrl, msg.line)
        return True
