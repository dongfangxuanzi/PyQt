from novalapp import get_app
from ..pylint_fix import PylintCommonFixer
from ..basefix import fix_code_file_msg


class PylintC0327Fixer(PylintCommonFixer):
    '''
        规则说明:混合行尾
    '''

    def __init__(self):
        super().__init__('C0327', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        if super().fix_message(doc, msg):
            return True
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        eol = text_ctrl.eolMode()
        textview.replace_eol(textview.get_line_end(eol))
        text_ctrl.setEolMode(eol)
        text_ctrl.eol = eol
        get_app().MainFrame.GetNotebook().updateStatusBar()
        return True
