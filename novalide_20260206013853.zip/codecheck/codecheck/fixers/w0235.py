from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintW0235Fixer(PylintFixer):
    '''
    规则说明: 子类继承父类时__init__方法仅仅只是调用父类的__init__方法,没有其它实质内容
    此__init__方法多余
    '''

    def __init__(self):
        super().__init__('W0235', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(
            textview.ModuleAnalyzer.Module).find_scope(msg.line)
        if isinstance(scope, nodes.FunctionDef):
            fix_range = get_node_range(scope)
            fix_range.replace_with_text(textview, "")
            return True
        return False
