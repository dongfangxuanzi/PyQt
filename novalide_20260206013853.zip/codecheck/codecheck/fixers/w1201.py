from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintW1201Fixer(PylintFixer):
    '''
    规则说明:日志打印字符串使用可变参数,而不是格式化字符串的方式
    '''

    def __init__(self):
        super().__init__('W1201', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call):
            if len(node.value.args) == 1 and isinstance(node.value.args[0], nodes.BinOp) and \
                    node.value.args[0].op == '%':
                arg = node.value.args[0]
                arg_range = get_node_range(arg)
                leftstr = arg.left.as_string()
                rightstr = arg.right.as_string()
                if isinstance(arg.right, nodes.Tuple):
                    rightstr = rightstr.strip()[1:-1]
                fix_str = leftstr + "," + rightstr
                arg_range.replace_with_text(textview, fix_str)
                return True
        return False
