import re
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..pkgres import find_pylint_rule
from .w0511 import PylintW0511Fixer


class PylintI0021Fixer(PylintFixer):
    '''
    规则说明:无用的抑制规则格式语句
    '''

    def __init__(self):
        super().__init__('I0021', True)

    @staticmethod
    def is_rule_id(ruletext):
        return re.search(r'\w{1}\d{3,}', ruletext)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        line_text = text_ctrl.get_line_text(msg.line)
        if line_text is None:
            return False
        regtext = r'#\s*pylint:\s*disable=\s*(.*)'
        res = re.search(regtext, line_text)
        if res:
            ruletext = res.groups()[0]
            if self.is_rule_id(ruletext):
                rulename = find_pylint_rule(ruletext)
            else:
                rulename = ruletext
            msgres = re.search(
                r"Useless suppression of '(.*)' \(useless-suppression\)", msg.msg)
            msg_rulename = msgres.groups()[0]
            if rulename == msg_rulename:
                PylintW0511Fixer.delete_comment_line(
                    textview, text_ctrl, msg.line)
                return True
        return False
