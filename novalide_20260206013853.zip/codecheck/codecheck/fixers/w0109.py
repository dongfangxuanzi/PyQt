import re
from novalapp.widgets import simpledialog
from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ..pylint_fix import PylintCommonFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintW0109Fixer(PylintCommonFixer):
    '''
    规则说明:字典重复键
    '''

    def __init__(self):
        super().__init__('W0109', False)
        self._reduce_line = False

    def is_dict_node(self, textview, line):
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        return isinstance(node, nodes.Assign) and isinstance(node.value, nodes.Dict)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)
        line = msg.line
        if self.is_dict_node(textview, line):
            scope = ScopeFinder(
                textview.ModuleAnalyzer.Module).find_scope(line)
            node = textview.ModuleAnalyzer.find_line_node(line, scope)
            res = re.search(
                r"Duplicate key '(.*)' in dictionary \(duplicate-key\)", msg.msg)
            dup_key = res.groups()[0]
            dup_indexes = []
            items = node.value.items
            for i, (k, v) in enumerate(items):
                if isinstance(k, nodes.Const):
                    key_name = k.value
                elif isinstance(k, nodes.Attribute):
                    key_name = k.as_string()
                else:
                    continue
                if dup_key == key_name:
                    dup_indexes.append(i)
            if len(dup_indexes) >= 2:
                # 为了防止结点变动或者位置变换导致修复错误,必须满足以上条件才能进行修复功能
                # 先使用通用sarif格式修复,如果不能修复则使用自定义方法修复
                if super().fix_message(doc, msg):
                    return True
                title = "Fix duplicate key"
                choices = []
                for index in dup_indexes:
                    item = items[index]
                    choices.append("delete duplicate key-%s:%s" %
                                   (item[0].as_string(), item[1].as_string()))
                sel = simpledialog.asklist(
                    title, "Please choose one delete key option", choices, selection=0, master=text_ctrl)
                if sel == -1:
                    return False
                selindex = dup_indexes[sel]
                fix_range = get_node_range(node)
                del items[selindex]
                fix_range.replace_with_text(textview, node.as_string())
                return True
        return False
