from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintW1512Fixer(PylintFixer):
    '''
    规则说明: 过期的类
    '''
    REPLACE_DEPRECATED_CLASSES = {
        "collections.Awaitable": "collections.abc.Awaitable",
        "collections.Coroutine": "collections.abc.Coroutine",
        "collections.AsyncIterable": "collections.abc.AsyncIterable",
        "collections.AsyncIterator": "collections.abc.AsyncIterator",
        "collections.AsyncGenerator": "collections.abc.AsyncGenerator",
        "collections.Hashable": "collections.abc.Hashable",
        "collections.Iterable": "collections.abc.Iterable",
        "collections.Iterator": "collections.abc.Iterator",
        "collections.Generator": "collections.abc.Generator",
        "collections.Reversible": "collections.abc.Reversible",
        "collections.Sized": "collections.abc.Sized",
        "collections.Container": "collections.abc.Container",
        "collections.Callable": "collections.abc.Callable",
        "collections.Collection": "collections.abc.Collection",
        "collections.Set": "collections.abc.Set",
        "collections.MutableSet": "collections.abc.MutableSet",
        "collections.Mapping": "collections.abc.Mapping",
        "collections.MutableMapping": "collections.abc.MutableMapping",
        "collections.MappingView": "collections.abc.MappingView",
        "collections.KeysView": "collections.abc.KeysView",
        "collections.ItemsView": "collections.abc.ItemsView",
        "collections.ValuesView": "collections.abc.ValuesView",
        "collections.Sequence": "collections.abc.Sequence",
        "collections.MutableSequence": "collections.abc.MutableSequence",
        "collections.ByteString": "collections.abc.ByteString"
    }

    def __init__(self):
        super().__init__('W1512', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(msg.line)
        if isinstance(node, nodes.ImportFrom):
            class_name = node.modname + "." + node.names[0][0]
            if class_name in self.REPLACE_DEPRECATED_CLASSES:
                replace_class_name = self.REPLACE_DEPRECATED_CLASSES[class_name]
                strs = replace_class_name.split(".")
                fixrange = get_node_range(node)
                replace_modname = ".".join(strs[0:-1])
                fixstr = "from %s import %s" % (replace_modname, strs[-1])
                fixrange.replace_with_text(textview, fixstr)
                return True
        return False
