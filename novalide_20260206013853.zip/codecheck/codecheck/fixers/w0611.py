import re
from astroid import nodes
from novalapp.util import utils, fileutils
from novalapp.python.parser import node_utils
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range
from ..pylint_fix import PylintFixer


class PylintW0611Fixer(PylintFixer):
    '''
        规则说明:未被使用的导入模块
    '''

    def __init__(self):
        super().__init__('W0611', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(line)
        if node is None:
            return False
        if not self.can_delete_node(node):
            utils.get_logger().error("%s node could not be deleted", node.__class__.__name__)
            return False
        if isinstance(node, nodes.Import):
            # 只修复只有一个导入的情况, 如果有多个导入, flake8工具会格式化分隔成每行导入一个,
            # 待第二次修复可以修复所有未导入的模块
            if 1 == len(node.names):
                res = re.search(
                    r"Unused import (\w+(.\w+)?) \(unused-import\)", msg.msg)
                if not res:
                    res = re.search(
                        r"Unused (.*) imported as (\w+) \(unused-import\)", msg.msg)
                    if not res:
                        return False
                    import_name, import_as_name = res.groups()
                    if import_name == node.names[0][0] and import_as_name == node.names[0][1]:
                        textview.delete_line(line - 1)
                        return True
                else:
                    import_name = res.groups()[0]
                    if import_name in (node.names[0][0], node.names[0][1]):
                        textview.delete_line(line - 1)
                        return True
        elif isinstance(node, nodes.ImportFrom):
            res = re.search(
                r"Unused (\w+) imported from (.*) as (.*) \(unused-import\)", msg.msg)
            if res is not None:
                import_name, import_module = res.groups()[0:2]
                if import_module != node.modname:
                    return False
            else:
                res = re.search(
                    r"Unused (\w+) imported from (.*) \(unused-import\)", msg.msg)
                if res is None:
                    res = re.search(
                        r"Unused import (\w+) \(unused-import\)", msg.msg)
                    if not res:
                        return False
                    import_name = res.groups()[0]
                    if node.modname != '':
                        return False
                else:
                    import_name, import_module = res.groups()
                    if import_module != node.modname:
                        return False
            # 检查from xx improt xx节点是否以反斜杆结尾,如果以反斜杆结尾则需要先进行格式化
            # 去掉反斜杆
            if self.is_fromimport_node_endswith_slash(node):
                utils.get_logger().debug(
                    'from import node %s in files %s endswith slash',
                    node,
                    msg.filepath
                )
                # 如果from xx improt xx节点以反斜杆结尾,则先不要修复,而是先进行代码标准化,
                # 去掉反斜杆
                fixrange = get_node_range(node)
                names = [name for (name, asname) in node.names]
                fromimport_modname = node_utils.get_fromimport_modname(node)
                fixstr = "from %s import %s" % (fromimport_modname, ",".join(names))
                utils.get_logger().debug("fix import node text is %s", fixstr)
                fixrange.replace_with_text(textview, fixstr)
                return True
            else:
                if 1 == len(node.names):
                    fixrange = get_node_range(node)
                    fixrange.replace_with_text(textview, '')
                else:
                    return self.delete_import_name(node, import_name, textview)
        return False

    @staticmethod
    def can_delete_node(node):
        parent_node = node.parent
        if not isinstance(parent_node, nodes.Module) and (
            hasattr(parent_node, 'body') and len(parent_node.body) == 1
        ):
            return False
        return True

    def is_fromimport_node_endswith_slash(self, fromimport_node):
        '''
        检查from xx improt xx节点是否以反斜杆结尾
        '''
        root_file = fromimport_node.root().file
        content = fileutils.get_file_content(root_file, allow_exception=False)
        if content is None:
            return False
        line_text = content.splitlines()[fromimport_node.lineno - 1]
        if line_text[-1] == '\\':
            return True
        return False
