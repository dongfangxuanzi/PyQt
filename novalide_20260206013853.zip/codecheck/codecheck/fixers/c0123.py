from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintC0123Fixer(PylintFixer):
    '''
    规则说明:用isinstance代替type判断变量类型
    '''

    def __init__(self):
        super().__init__('C0123', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        type_expr = self.find_type_extr(node)
        if not type_expr:
            return False
        fixrange = get_node_range(type_expr)
        type_name = type_expr.left.args[0]
        target = type_expr.ops[0][1]
        fixstr = f"isinstance({type_name.as_string()}, {target.as_string()})"
        fixrange.replace_with_text(textview, fixstr)
        return True

    @classmethod
    def find_type_extr(cls, node):
        if cls.is_type_extr(node):
            return node
        for child in node.get_children():
            if isinstance(child, nodes.Compare):
                if cls.is_type_extr(child):
                    return child
            else:
                expr = cls.find_type_extr(child)
                if expr:
                    return expr
        return None

    @staticmethod
    def is_type_extr(node):
        if isinstance(node, nodes.Compare):
            left = node.left
            if isinstance(left, nodes.Call) and isinstance(left.func, nodes.Name) \
                    and left.func.name == 'type':
                return True
        return False
