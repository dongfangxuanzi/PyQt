import re
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintW0614Fixer(PylintFixer):
    '''
    规则说明: 使用*号导入成员未被使用
    '''

    def __init__(self):
        super().__init__('W0614', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(msg.line)
        if isinstance(node, nodes.ImportFrom):
            res = re.search(
                r'Unused import\(s\) (.*) from wildcard import of (.*) \(unused-wildcard-import\)', msg.msg)
            if not res:
                return False
            unused_name_str, modname = res.groups()
            unused_names = re.split(r',\s*| and *', unused_name_str)
            if modname == node.modname:
                used_names = []
                for name, stmts in node.root().globals.items():
                    stmt = stmts[0]
                    if isinstance(stmt, nodes.ImportFrom) and stmt.modname == modname:
                        assert stmt.names[0][0] == '*'
                        if name in unused_names:
                            continue
                        used_names.append(name)
                if 0 == len(used_names):
                    textview.delete_line(msg.line - 1)
                    return True
                fix_range = get_node_range(node)
                nodestr = 'from %s import ' % modname
                names = []
                for name in used_names:
                    names.append(name)
                fix_range.replace_with_text(
                    textview, nodestr + ', '.join(names))
                return True
        return False
