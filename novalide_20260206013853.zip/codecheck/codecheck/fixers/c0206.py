from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from novalapp import _
from novalapp.widgets import simpledialog
from ..codeutils import get_node_range
from ..basefix import fix_code_file_msg
from ..pylint_fix import PylintFixer


class PylintC0206Fixer(PylintFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('C0206', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(
            textview.ModuleAnalyzer.Module).find_scope(msg.line)
        if isinstance(scope, nodes.For):
            iter = scope.iter
            target = scope.target
            target_name = target.as_string()
            body = scope.body
            fix_range = get_node_range(iter)
            iter_name = iter.as_string()
            for node in body:
                loop_name = iter_name + "[%s]" % target_name
                if isinstance(node, nodes.Assign):
                    if node.value.as_string() == loop_name:
                        fix_range.replace_with_text(
                            textview, iter_name + ".items()")
                        target_range = get_node_range(target)
                        textview.delete_line(msg.line)
                        target_range.replace_with_text(
                            textview,
                            target_name + "," + node.targets[0].as_string()
                        )
                        return True
            ok, newname = simpledialog.askstring(
                _('Input dict value name'),
                _('Input loop name'),
                initialvalue='',
                master=text_ctrl
            )
            if ok and newname != '':
                fix_range.replace_with_text(textview, iter_name + ".items()")
                target_range = get_node_range(target)
                target_range.replace_with_text(
                    textview, target_name + "," + newname)
                self.replace_loop_name_in_scope(
                    textview, scope, loop_name, newname)
                return True
        return False

    @classmethod
    def replace_loop_name_in_scope(cls, textview, scope, loop_name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if child.as_string() == loop_name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, newname)
            else:
                cls.replace_loop_name_in_scope(
                    textview, child, loop_name, newname)
