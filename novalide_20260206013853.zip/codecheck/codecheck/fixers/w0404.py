import re
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg


class PylintW0404Fixer(PylintFixer):
    '''
    规则说明:重复导入模块
    '''

    def __init__(self):
        super().__init__('W0404', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(line)
        if node is None:
            return False
        res = re.search(
            r"Reimport '(\w+)' \(imported line (\d+)\) \(reimported\)", msg.msg)
        if res is None:
            return
        import_name, import_line = res.groups()
        if isinstance(node, nodes.Import):
            if 1 == len(node.names):
                if import_name in (node.names[0][0], node.names[0][1]):
                    textview.delete_line(line - 1)
                    return True
        elif isinstance(node, nodes.ImportFrom):
            if self.delete_import_name(node, import_name, textview):
                names_count = len(node.names)
                if 1 == names_count:
                    textview.delete_line(line - 1)
                return True
        return False
