from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg


class PylintC0303Fixer(PylintFixer):
    '''
    规则说明:代码行以空白字符串结尾
    '''

    def __init__(self):
        super().__init__('C0303', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textview.do_rstrip_line(msg.line)
        return True
