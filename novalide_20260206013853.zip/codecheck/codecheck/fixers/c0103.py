import re
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp import _
from astroid import nodes
from novalapp.widgets import simpledialog
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg


class PylintC0103Fixer(PylintFixer):
    '''
    规则说明:变量和属性命名不符合规范
    '''

    def __init__(self):
        super().__init__('C0103', False)
        self._reduce_line = False

    @staticmethod
    def get_function_scope(scope):
        parent_scope = scope
        while True:
            if isinstance(parent_scope, nodes.FunctionDef):
                return parent_scope
            if isinstance(parent_scope, nodes.Module):
                break
            parent_scope = parent_scope.parent
        return None

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(
            textview.ModuleAnalyzer.Module).find_scope(msg.line)
        res1 = re.search(
            r'Variable name "(?P<varname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg,
        )
        if res1:
            # 变量名不支持自动修复
            if self.is_autofix_msg:
                return False
            funcscope = self.get_function_scope(scope)
            # 目前仅支持函数范围内的变量名更改替换
            if funcscope is None:
                return False
            varname = res1.groupdict().get('varname')
            ok, newname = simpledialog.askstring(
                _('Rename variable name'),
                _('Input new variable name'),
                initialvalue=varname.lower(),
                master=text_ctrl
            )
            if not ok or newname == varname:
                return False
            self.replace_variable_name_in_scope(
                textview, funcscope, varname, newname)
            return True
        res2 = re.search(
            r'Attribute name "(?P<attrname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res2 and isinstance(scope, nodes.FunctionDef) and isinstance(scope.parent, nodes.ClassDef):
            # 属性名不支持自动修复
            if self.is_autofix_msg:
                return False
            attrname = res2.groupdict().get('attrname')
            ok, newname = simpledialog.askstring(
                _('Rename attribute name'),
                _('Input new attribute name'),
                initialvalue=attrname.lower(),
                master=text_ctrl
            )
            if not ok or newname == attrname:
                return False
            self.replace_attribute_name_in_scope(
                textview, scope.parent, attrname, newname)
            return True
        res3 = re.search(
            r'Argument name "(?P<argname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res3 and isinstance(scope, nodes.FunctionDef):
            # 参数名不支持自动修复
            if self.is_autofix_msg:
                return False
            argname = res3.groupdict().get('argname')
            ok, newname = simpledialog.askstring(
                _('Rename argument name'),
                _('Input new argument name'),
                initialvalue=argname.lower(),
                master=text_ctrl
            )
            if ok and newname != argname:
                self.replace_variable_name_in_scope(
                    textview, scope, argname, newname)
                return True

        res4 = re.search(
            r'Module name "(?P<modulename>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res4:
            modulename = res4.groupdict().get('modulename')
            # 模块名支持自动修复
            if self.is_autofix_msg:
                ok = True
                newname = modulename.lower()
            else:
                ok, newname = simpledialog.askstring(
                    _('Rename module name'),
                    _('Input new module name'),
                    initialvalue=modulename.lower(),
                    master=text_ctrl
                )
            if ok and newname != modulename:
                return self.replace_module_name(doc, msg.filepath, newname)
        return False
