from ..pylint_fix import PylintCommonFixer


class PylintE0213Fixer(PylintCommonFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('E0213', False)
