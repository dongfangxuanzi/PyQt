import re
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintR1714Fixer(PylintFixer):
    '''
    规则说明:or条件表达式可以使用in代替
    '''

    def __init__(self):
        super().__init__('R1714', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.BoolOp):
            res = re.search(
                r'Consider merging these comparisons with "in" to (\'.*\'|".*") \(consider-using-in\)',
                msg.msg
            )
            if not res:
                return False
            fixstr = res.groups()[0][1:-1]
            single_quote_str = "\\'"
            if fixstr.find(single_quote_str) != -1:
                fixstr = fixstr.replace(single_quote_str, "'")
            iftest = get_node_range(node)
            iftest.replace_with_text(textview, fixstr)
            return True
        return False
