from typing import NamedTuple


class Message(NamedTuple):
    """description of class"""
    line: int
    column: int
    ruleid: str
    filepath: str
    msg: str
    toolname: str
    fixers: list
