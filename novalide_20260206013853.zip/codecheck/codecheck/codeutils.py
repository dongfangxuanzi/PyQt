import re
import enum
import os
import platformdirs
from novalapp import constants, get_app, _
from astroid import nodes
from novalapp.util import fileutils
from .strings import CODECHECK_TOOL_NANE


class FilesregType(enum.Enum):
    INCLUDE_FILES = 1
    EXCLUDE_FILES = 2


class ScanMode(enum.Enum):
    CHANGED_FILES_MODE = 1
    FULL_FILES_MODE = 2
    TIME_SECTION_FILES_MODE = 3


class AfterTimeSpan(enum.Enum):
    AFTER_CREATED_TIME = 1
    AFTER_MODIFIED_TIME = 2


def get_file_excludes_reg(text):
    regs = text.split("|")
    regstrs = [re.escape(regtext) for regtext in regs]
    regstr = "|".join(regstrs)
    return regstr


def get_codecheck_data_path():
    return os.path.dirname(platformdirs.user_data_path(CODECHECK_TOOL_NANE))


def get_tools_data_path():
    return os.path.join(get_codecheck_data_path(), "tools")


class FixRange:
    def __init__(self, start_line, start_col=None, end_line=None, end_col=None):
        self.start_line = start_line or 1
        self.start_col = start_col or 0
        self.end_line = end_line or self.start_line
        self.end_col = end_col or self.start_col
        self.start_line -= 1
        self.end_line -= 1

    def replace_with_text(self, textview, text):
        head, tail, chars, lines = textview.get_region(
            self.start_line,
            self.start_col,
            self.end_line,
            self.end_col
        )
        textview.set_region(head, tail, chars, text.split("\n"), selrep=False)

    def replace_line(self, textview, text):
        linetext = textview.GetCtrl().get_line_text(self.start_line)
        end_col = len(textview.GetCtrl()._encodeString(linetext))
        head, tail, chars, lines = textview.get_region(
            self.start_line,
            0,
            self.end_line,
            end_col
        )
        textview.set_region(head, tail, chars, text.split("\n"), selrep=False)

    def add_text(self, textview, inserted_content):
        insert_pos = textview.GetCtrl().position_from_linecol(
            self.start_line, self.start_col)
        textview.GetCtrl().insert_text(insert_pos, inserted_content)


def get_node_range(node):
    return FixRange(node.lineno, node.col_offset, node.end_lineno, node.end_col_offset)


def get_add_range(line, col):
    return FixRange(line, col, line, col)


DEFAULT_TAB_BLANKS = ' ' * constants.DEFAULT_TAB_WIDTH


class ImportVisitor:
    def __init__(self, module, textview):
        self._module = module
        self._textview = textview

    def is_import_exist(self, modname):
        for child in self._module.body:
            if isinstance(child, nodes.Import):
                names = [name[0] for name in child.names]
                if modname in names:
                    return True
        return False

    def is_fromimport_exist(self, modname, import_name):
        for child in self._module.body:
            if isinstance(child, nodes.ImportFrom):
                if child.modname == modname:
                    return import_name in [name[0] for name in child.names]
        return False

    def get_lastimport_node(self):
        for i, child in enumerate(self._module.body):
            if not isinstance(child, (nodes.Import, nodes.ImportFrom)):
                if i > 0:
                    return self._module.body[i - 1]
                break
        return None

    def get_import_line(self):
        last_node = self.get_lastimport_node()
        if last_node is not None:
            return last_node.lineno
        else:
            shebang_or_encoding_line = self._textview.get_shebang_encoding_line()
            if self._module.doc_node is None:
                return shebang_or_encoding_line
            return self.get_docstring_line()

    def get_docstring_line(self):
        assert self._module.doc is not None
        return self._module.doc_node.end_lineno


def check_git_plugin_installed():
    plugin_name = 'gitcli'
    if get_app().GetPluginManager().GetPlugin(plugin_name) is None:
        raise RuntimeError(
            _('Plugin `%s` must be intalled if you use git tool') % plugin_name
        )


def get_file_linetext(filepath, lineindex):
    content = fileutils.get_file_content(filepath, allow_exception=False)
    if content is None:
        return None
    linetext = content.splitlines()[lineindex]
    return linetext


def get_file_lines(filepath, lineindex, endindex):
    content = fileutils.get_file_content(filepath, allow_exception=False)
    if content is None:
        return []

    return content.splitlines()[lineindex:lineindex]


class FixNode:
    def __init__(self, node, textview):
        self._node = node
        self._textview = textview

    def replace_node_with_text(self, reptext):
        fix_range = get_node_range(self._node)
        fix_range.replace_with_text(self._textview, reptext)
