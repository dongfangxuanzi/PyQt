import os
import shutil
import json
from pkg_resources import resource_filename
from novalapp.util import utils, fileutils
from .codeutils import get_tools_data_path


def _get_pkg_res_path():
    # 调用resource_filename会解压插件包含的所有文件,覆盖到插件目的目录下的所有文件
    pkg_dest_path = resource_filename(__name__, '')
    return os.path.join(pkg_dest_path, "res")


def get_pylint_rc_path():
    pylint_tools_path = os.path.join(get_tools_data_path(), "python", "pylint")
    dest_pylint_conf_path = os.path.join(pylint_tools_path, "pylint.conf")
    if not os.path.exists(dest_pylint_conf_path):
        fileutils.makedirs(pylint_tools_path)
        source_pylint_conf_path = os.path.join(
            _get_pkg_res_path(), "pylint.conf")
        # 将插件中包含的pylint配置文件拷贝到临时目录以免被修改后被覆盖
        shutil.copy(source_pylint_conf_path, dest_pylint_conf_path)
    return dest_pylint_conf_path


def get_flake8_config_path():
    flake8_tools_path = os.path.join(get_tools_data_path(), "python", "flake8")
    dest_flake8_conf_path = os.path.join(flake8_tools_path, "flake8.conf")
    if not os.path.exists(dest_flake8_conf_path):
        fileutils.makedirs(flake8_tools_path)
        source_flake8_conf_path = os.path.join(
            _get_pkg_res_path(), "flake8.conf")
        # 将插件中包含的flake8配置文件拷贝到临时目录以免被修改后被覆盖
        shutil.copy(source_flake8_conf_path, dest_flake8_conf_path)
    return dest_flake8_conf_path


def get_pylint_rules_path():
    rules_file_path = os.path.join(_get_pkg_res_path(), "pylint_rules.json")
    return rules_file_path


def get_message_icon_path():
    pkg_dest_res_path = _get_pkg_res_path()
    utils.get_logger().info('codecheck package resource path is %s', pkg_dest_res_path)
    message_icon_path = os.path.join(pkg_dest_res_path, "messages.ico")
    return message_icon_path


def get_start_image_path():
    return os.path.join(_get_pkg_res_path(), "start.png")


def get_stop_image_path():
    return os.path.join(_get_pkg_res_path(), "stop.png")


def get_flake8_rules_path():
    rules_file_path = os.path.join(_get_pkg_res_path(), "flake8_rules.json")
    return rules_file_path


def load_res_file(res_file):
    with open(res_file) as reader:
        return json.load(reader)


def load_pylint_resfile():
    return load_res_file(get_pylint_rules_path())


def find_pylint_rule(ruleid):
    datas = load_pylint_resfile()
    for data in datas:
        if ruleid == data[1]:
            return data[0]
    return None
