import abc
import re
import os
from novalapp.util import fileutils, timeutils
from novalapp.python.project.processor import PythonProcessor
from novalapp import _
from novalapp.python.interpreter.exceptions import InterpretertoolNotExistError
from novalapp.lib.pyqt import QMessageBox
from novalapp.util import utils
from . import configkeys
from .sarif_loader import SarifLoader
from .toolmanager import CodecheckToolManager
from .codeutils import get_file_excludes_reg, FilesregType, ScanMode, check_git_plugin_installed


class CommonProcessor(PythonProcessor):
    """description of class"""

    def __init__(self, parent, statusbar, processor_name, enabled):
        self.message_viewer = parent
        super().__init__(statusbar, processor_name, enabled)
        self.exclude_files = []
        self.scan_mode = ScanMode.FULL_FILES_MODE.value
        self.changed_files = []
        self.base_timestamp = -1

    def get_changed_files(self, doc):
        '''
        检测项目仓库修改待提交文件
        '''
        changed_files = []
        try:
            from git.repo import Repo, RepofileState
            from git.exceptions import UnmergeError
            repo = Repo(doc.GetPath())
            has_unmerged, commit_files = repo.status()
            if has_unmerged:
                raise UnmergeError(_('Repo has unmerged files!'))
            for commit_file in commit_files:
                if commit_file.file_state in [
                    RepofileState.FILE_MODIFIED_UNSTAGED,
                    RepofileState.FILE_MODIFIED_STAGED,
                    RepofileState.FILE_NEW_STAGED
                ]:
                    changed_files.append(commit_file.fullpath)
            # 如果本次文件没有变更,则获取最近一次提交的文件变更
            if not changed_files:
                current_branch = repo.branch()
                commit_ids = repo.logs(current_branch, 10)
                last_commit_id = commit_ids[0]
                changed_files = repo.list_status_files(last_commit_id, fullpath=True)
                utils.get_logger().debug(
                    'get project doc %s branch %s recent commit id is:%s,changed files count is:%d',
                    doc.GetModel().name,
                    current_branch,
                    last_commit_id,
                    len(changed_files)
                )
        except Exception as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(doc.GetFirstView().GetFrame(), _("Error"), str(ex))
        return changed_files

    def check_docrepo_branch(self, doc):
        '''
        检测项目目录是否是git仓库
        '''
        if not utils.profile_get_int(
            configkeys.CODECHECK_PROJECT_MUSTBE_REPOSITORY_KEY,
            True
        ) and self.scan_mode != ScanMode.CHANGED_FILES_MODE.value:
            return True
        try:
            check_git_plugin_installed()
            from git.repo import Repo
            repo = Repo(doc.GetPath())
            repo.branch()
        except Exception as ex:
            utils.get_logger().error(str(ex))
            self.stop(str(ex))
            return False
        return True

    @staticmethod
    def use_codecheck(doc):
        return utils.profile_get_int(doc.GetKey(configkeys.USE_CODECHECK_PROJECT_KEY), True)

    @staticmethod
    def is_filepath_excluded(doc, filepath):
        is_file_excluded = False
        file_reg_type = utils.profile_get_int(
            doc.GetKey(configkeys.FILES_REGTYPE_KEY), -1)
        if file_reg_type == FilesregType.EXCLUDE_FILES.value:
            regtext = utils.profile_get(doc.GetKey(
                configkeys.CODECHECK_EXCLUDE_FILES_KEY), "")
            if regtext:
                regstr = get_file_excludes_reg(regtext)
                if re.search(regstr, filepath, re.I):
                    is_file_excluded = True
        elif file_reg_type == FilesregType.INCLUDE_FILES.value:
            regtext = utils.profile_get(doc.GetKey(
                configkeys.CODECHECK_INCLUDE_FILES_KEY), "")
            if regtext:
                regstr = get_file_excludes_reg(regtext)
                if not re.search(regstr, filepath, re.I):
                    is_file_excluded = True
        return is_file_excluded

    def stop(self, reason):
        super().stop(reason)
        self.message_viewer.SIG_STOP_PROCESSOR.emit(reason)

    def run(self, doc, filepath):
        super().run(doc, filepath)
        is_file_excluded = self.is_filepath_excluded(doc, filepath)
        if is_file_excluded:
            utils.get_logger().info("file %s is excluded......", filepath)
            super().update_progress(filepath)
            return False
        if self.stopped:
            utils.get_logger().error('codecheck is stopped')
            return False
        if not self.use_codecheck(doc):
            utils.get_logger().error('codecheck function is disabled')
            return False
        if self.scan_mode == ScanMode.CHANGED_FILES_MODE.value:
            if filepath not in self.changed_files:
                utils.get_logger().info("file %s is not in changed files......", filepath)
                return False
            utils.get_logger().debug("file %s is in changed files......", filepath)
        elif self.scan_mode == ScanMode.TIME_SECTION_FILES_MODE.value:
            file_mktime = os.path.getmtime(filepath)
            utils.get_logger().debug(
                "file %s modify datetime is :%s, timespan mode base datetime is:%s",
                filepath,
                timeutils.timestamp_to_timestr(file_mktime),
                timeutils.timestamp_to_timestr(self.base_timestamp)
            )
            if file_mktime > self.base_timestamp:
                return True
            utils.get_logger().info(
                "file %s modify datetime less then timespan mode base datetime",
                filepath
            )
            return False
        return True

    def init_tools(self):
        if self.interpreter is not None:
            try:
                CodecheckToolManager.manager().register_python_tools(self.interpreter)
            except InterpretertoolNotExistError as ex:
                utils.get_logger().error("%s", ex)
                return False
        for checktool in CodecheckToolManager.manager().CHECK_TOOLS:
            # 工具初始化默认启用所有规则,为None既表示启用所有规则
            toolrules = utils.profile_get(
                configkeys.TOOL_RULES_KEY % checktool.name, None)
            try:
                checktool.update_enable_rules(toolrules)
            except Exception:
                utils.get_logger().error(
                    "tool %s update rules %s fail",
                    checktool.name,
                    toolrules
                )
                return False
        return True

    def init(self, doc):
        self.message_viewer.doc = doc
        if not super().init(doc):
            return False
        if not self.init_tools():
            return False
        self.enabled = True
        self.scan_mode = utils.profile_get_int(
            doc.GetKey(configkeys.SCAN_MODE_KEY),
            ScanMode.FULL_FILES_MODE.value
        )
        utils.get_logger().debug(
            'project %s codecheck mode is %d',
            doc.GetModel().name,
            self.scan_mode
        )
        if not self.check_docrepo_branch(doc):
            return False
        self.message_viewer.SIG_INIT_PROCESSOR.emit()
        if self.scan_mode == ScanMode.CHANGED_FILES_MODE.value:
            self.changed_files = self.get_changed_files(doc)
            utils.get_logger().info(
                'codecheck mode is changed files mode and collect project %s changed files count is %d',
                doc.GetModel().name,
                len(self.changed_files)
            )
        elif self.scan_mode == ScanMode.TIME_SECTION_FILES_MODE.value:
            self.base_timestamp = utils.profile_get_int(
                doc.GetKey(configkeys.BASE_TIMESTAMP_KEY),
                -1
            )
        return True

    def end(self, doc):
        super().end(doc)
        self.enabled = False
        self.message_viewer.SIG_END_PROCESSOR.emit(self.name)

    def load_message_file(self, doc, check_tool, message_file):
        messages = self.load_messages(check_tool, message_file)
        for msg in messages:
            self.handle_message(doc, check_tool, msg)

    def get_file_content(self, filepath):
        filecontent = fileutils.get_file_content(
            filepath, allow_exception=False, enc=utils.get_default_locale_encoding())
        if filecontent is None:
            filecontent = fileutils.get_file_content(
                filepath, allow_exception=False)
        return filecontent

    def load_messages(self, check_tool, message_file):
        messages = []
        if check_tool.output_format == check_tool.PLAIN_TEXT_FORMAT:
            filecontent = self.get_file_content(message_file)
            for linemsg in filecontent.splitlines():
                msg = check_tool.parse_line_msg(linemsg)
                if msg is None:
                    utils.get_logger().debug('line text %s is not a valid message line', linemsg)
                    continue
                messages.append(msg)
        elif check_tool.output_format == check_tool.JSON_OUTPUT_FORMAT:
            try:
                messages = SarifLoader(message_file, check_tool.name).load()
            except Exception as ex:
                self.stop(_("load message file %s error:%s") %
                          (message_file, str(ex)))
        return messages

    @abc.abstractmethod
    def handle_message(self, doc, check_tool, msg):
        raise NotImplementedError('You must implemented it in derived class')

    def update_progress(self, filepath):
        self.message_viewer.SIG_UPDATE_PROGRESS.emit(self.updated_file_count)
        super().update_progress(filepath)
