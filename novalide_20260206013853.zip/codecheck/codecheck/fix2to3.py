import subprocess
import shutil
import logging
import os
import functools
from novalapp.util import fileutils
from novalapp.executable import Executable
from novalapp.util import utils
from novalapp.python.interpreter.exceptions import InterpretertoolNotExistError
from novalapp import _
from novalapp.python.interpreter.exceptions import InterpreterSyntaxError
from novalapp.util import strutils
from .common_fix_processor import CommonFixProcessor
from .basetool import BasePythonCheckTool
from .strings import CODECHECK_TOOL_NANE

FIX2TO3_TOOL_NAME = "Fix2to3"
logger = logging.getLogger(__name__)


class Fix2to3Tool(BasePythonCheckTool):
    """description of class"""

    def __init__(self, interpreter):
        super().__init__(FIX2TO3_TOOL_NAME, interpreter)

    def update(self, interpreter):
        tool_script_path = None
        interpreter_path = interpreter.install_path
        if interpreter.is_venv_interpreter():
            venv_cfg = interpreter.venvcfg
            interpreter_path = os.path.dirname(venv_cfg.base_executable)
        scrip_paths = [r'Tools\scripts\2to3.py', r'scripts\2to3-script.py']
        func = functools.partial(os.path.join, interpreter_path)
        for path in map(func, scrip_paths):
            logger.debug("fix2to3 path is %s", path)
            if os.path.exists(path):
                tool_script_path = path
                break
        if tool_script_path is None:
            raise InterpretertoolNotExistError(
                "Tool %s is not exist in interpreter %s" % (
                    FIX2TO3_TOOL_NAME, interpreter.name)
            )
        exectable = Executable(interpreter.path, args=[
                               tool_script_path, "-w"])
        command = exectable.get_cmd()
        logger.info('tool %s fix2to3 command is %s',
                    FIX2TO3_TOOL_NAME, command)
        self._command = command
        self._path = tool_script_path

    def fix_file(self, processor, doc, filepath):
        exectable = Executable(self._interpreter.path, args=[self.path, "-w"])
        command = exectable.get_cmd()
        command += " "
        backup_file_path = "%s.bak" % (filepath)
        shutil.copy(filepath, backup_file_path)
        command += strutils.emphasis_path(backup_file_path)
        utils.get_logger().info('tool %s fix2to3 command is %s', FIX2TO3_TOOL_NAME, command)
        if utils.is_windows():
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
        else:
            startupinfo = None
        utils.get_logger().debug('backfile is %s', backup_file_path)
        process_obj = subprocess.Popen(
            command,
            shell=True,
            startupinfo=startupinfo,
            cwd=doc.GetPath()
        )
        process_obj.wait()
        ok = self.check_file_syntax(backup_file_path)
        if ok:
            shutil.copy(backup_file_path, filepath)
            os.remove(backup_file_path)
            backup_backup_file_path = "%s.bak" % (backup_file_path)
            if os.path.exists(backup_backup_file_path):
                shutil.copy(backup_backup_file_path, backup_file_path)
                os.remove(backup_backup_file_path)
        return True


class Fix2to3Processor(CommonFixProcessor):
    """description of class"""

    def __init__(self, parent, statusbar):
        super().__init__(parent, statusbar, FIX2TO3_TOOL_NAME)
        self.fix2to3_tool = None
        self.fix_file_list = None

    def init(self, doc):
        if not super().init(doc):
            return False
        if self.fix2to3_tool is None:
            try:
                self.fix2to3_tool = Fix2to3Tool(self.interpreter)
            except InterpretertoolNotExistError as ex:
                utils.get_logger().error("%s", ex)
                self.stop(str(ex))
        filelist_conf = self.get_fix_file_list(doc)
        self.fix_file_list = open(filelist_conf, "a")
        return True

    def run(self, doc, filepath):
        if not super().run(doc, filepath):
            utils.get_logger().error('fixer2to3 is stopped')
            return
        if self.is_file_fixed(doc, filepath):
            utils.get_logger().debug('code file %s is already fixed', filepath)
            return
        utils.get_logger().debug('fix2to3 code file %s', filepath)
        self.update_progress(filepath)
        if self.fix_single_file(doc, filepath):
            self.fix_file_list.write(filepath + "\n")

    def get_fix_file_list(self, doc):
        dock_cache_path = os.path.join(
            doc.get_doc_cache_path(), CODECHECK_TOOL_NANE)
        filelist_conf = os.path.join(
            dock_cache_path, "fixer2to3_filelist.conf")
        return filelist_conf

    def is_file_fixed(self, doc, filepath):
        file_list = self.get_fix_file_list(doc)
        filecontent = self.get_file_content(file_list)
        if filecontent is not None:
            for line in filecontent.splitlines():
                if fileutils.ComparePath(line.strip(), filepath):
                    return True
        return False

    def fix_single_file(self, doc, filepath):
        self.message_viewer.SiG_CLEAR_FILE_MESSAGE_ITEMS.emit(filepath)
        fix_suc = True
        try:
            self.fix2to3_tool.fix_file(self, doc, filepath)
        except (InterpreterSyntaxError) as ex:
            self.stop(str(ex))
            fix_suc = False
        self.message_viewer._plugin._check_processor.check_single_file(
            doc, filepath)
        self.fixed_file_count += 1
        return fix_suc

    def end(self, doc):
        super().end(doc)
        utils.get_logger().debug('end fix2to3 project %s files', doc.GetFilename())
        doc_name = doc.GetModel().name
        self.restore_configs()
        self.fix_file_list.close()
        self._statusbar.emit_statusbar_messgae(
            _('Finish fix2to3 project "%s" code files') % doc_name)

    def update_progress(self, filepath):
        self._statusbar.emit_statusbar_messgae(
            _('Fix2to3ing code file:%s') % filepath)
        super().update_progress(filepath)
