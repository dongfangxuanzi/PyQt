import re
import base64
import os
from astroid import nodes
from novalapp import get_app, _
from novalapp.widgets import simpledialog
from novalapp.lib.pyqt import QMessageBox
from novalapp.project import command as projectcommand
from novalapp.util import fileutils, strutils
from .basefix import BasePythonFixer, fix_code_file_msg
from .sarif_loader import SarifLoader
from .strings import PYLINT_TOOL_NAME
from .codeutils import get_node_range


class PylintFixer(BasePythonFixer):
    def __init__(self, ruleid, autofix=False, open_file=True):
        super().__init__(ruleid, PYLINT_TOOL_NAME, autofix, open_file)

    @staticmethod
    def delete_import_name(node, import_name, textview):
        text_ctrl = textview.GetCtrl()
        for alias in node.alias:
            if import_name in (alias.name, alias.asname):
                lineno = alias.lineno - 1
                line_text = text_ctrl.get_line_text(lineno)
                offset = 0
                target_start = text_ctrl.position_from_linecol(
                    lineno, alias.col_offset)
                for i, char in enumerate(line_text[alias.col_offset:]):
                    if char == ",":
                        offset = i + 1
                        break
                else:
                    loff = 0
                    for j, char in enumerate(line_text[0:alias.col_offset][::-1]):
                        if char == ",":
                            loff = j + 1
                            break
                    target_start -= loff
                    offstr = line_text[alias.col_offset:]
                    if offstr.find(")") != -1:
                        offstr = offstr[0:offstr.find(")")]
                    offset = len(offstr) + loff
                target_end = target_start + offset
                text_ctrl.delete_target(target_start, target_end)
                line_text = text_ctrl.get_line_text(lineno)
                if line_text.strip() == '':
                    textview.delete_line(lineno)
                return True
        return False

    @classmethod
    def replace_variable_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.Name, nodes.AssignName)) and child.name == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, newname)
            else:
                cls.replace_variable_name_in_scope(
                    textview, child, name, newname)

    @classmethod
    def replace_attribute_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.AssignAttr, nodes.Attribute)) and child.attrname == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, "self." + newname)
            else:
                cls.replace_attribute_name_in_scope(
                    textview, child, name, newname)

    @staticmethod
    def replace_module_name(doc, oldpath, new_module_name):
        ext = strutils.get_file_extension(oldpath, keepdot=True)
        newname = os.path.join(
            fileutils.get_filepath_from_path(oldpath), new_module_name)
        newfilepath = strutils.MakeNameEndInExtension(newname, ext)
        return doc.GetCommandProcessor().Submit(
            projectcommand.ProjectRenameFileCommand(doc, oldpath, newfilepath)
        )


class PylintCommonFixer(PylintFixer):
    def __init__(self, ruleid, autofix=False, open_file=True):
        PylintFixer.__init__(self, ruleid, autofix, open_file)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        if self.check_tool.output_format != self.check_tool.JSON_OUTPUT_FORMAT:
            return False
        fixes = msg.fixers
        if not fixes:
            return False
        if len(fixes) > 1 and not self.is_autofix_msg:
            choices = [fixer['description']['text'] for fixer in fixes]
            sel = simpledialog.asklist(
                "Fix code", "Please choose one fixer option", choices, selection=0, master=text_ctrl)
            if sel == -1:
                return False
        else:
            # sarif自动修复有多个修复选项时默认选第一个作为修复方案
            sel = 0
        fixer = fixes[sel]
        chan = fixer['artifactChanges'][0]
        fixuri = chan['artifactLocation']['uri']
        fixpath = SarifLoader.uri_to_path(fixuri)
        if not fileutils.ComparePath(msg.filepath, fixpath):
            textview = get_app().GotoView(
                fixpath,
                lineNum=msg.line,
                colno=msg.column,
                load_outline=False,
                trace_track=False
            )
            if not textview:
                return False
            text_ctrl = textview.GetCtrl()
        replacements = chan['replacements']
        title = fixer['description']['text']
        if not self.check_input_replacements(title, text_ctrl, replacements):
            return False
        for replacement in replacements:
            if "deletedRegion" in replacement:
                if textview.IsModified() and not self.is_autofix_msg:
                    QMessageBox.critical(text_ctrl, _('Error'), _(
                        'Please save your file before fix warnings'))
                    return False
                deleted_region = replacement["deletedRegion"]
                if 'byteOffset' in deleted_region:
                    base64_text = bytearray(
                        replacement["insertedContent"]['binary'], encoding="ascii")
                    inserted_content = base64.b64decode(base64_text)
                    byte_offset = deleted_region['byteOffset']
                    byte_len = deleted_region['byteLength']
                    newbytes = b''
                    with open(fixpath, "rb") as fp:
                        byte_content = fp.read()
                        newbytes = byte_content[0:byte_offset] + bytearray(
                            inserted_content) + byte_content[byte_offset + byte_len:]
                    with open(fixpath, "wb") as fw:
                        fw.write(newbytes)
                elif 'charOffset' in deleted_region:
                    char_offset = deleted_region['charOffset']
                    char_len = deleted_region['charLength']
                    inserted_content = replacement["insertedContent"]["text"]
                    if char_len == 0:
                        text_ctrl.insert_text(char_offset, inserted_content)
                    else:
                        content = text_ctrl._encodeString(text_ctrl.text())
                        chars = content[char_offset:char_offset + char_len]
                        textview.set_region(char_offset, char_offset + char_len, chars,
                                            inserted_content.split("\n"), selrep=False)
                else:
                    start_line = deleted_region["startLine"] - 1
                    start_column = deleted_region["startColumn"] - 1
                    end_column = deleted_region["endColumn"] - 1
                    end_line = deleted_region["endLine"] - 1
                    inserted_content = replacement["insertedContent"]["text"]
                    if start_line == end_line and start_column == end_column:
                        insert_pos = text_ctrl.position_from_linecol(
                            start_line, start_column)
                        text_ctrl.insert_text(insert_pos, inserted_content)
                    else:
                        head, tail, chars, lines = textview.get_region(
                            start_line, start_column, end_line, end_column)
                        textview.set_region(head, tail, chars,
                                            inserted_content.split("\n"), selrep=False)
            elif "newModule" in replacement:
                replacement_content = replacement["newModule"]
                new_module_name = replacement_content['text']
                oldfilepath = fixpath
                return self.replace_module_name(doc, oldfilepath, new_module_name)

        return True

    def check_input_replacements(
        self,
        title,
        text_ctrl,
        replacements,
        initialvalue=''
    ):
        def parse_arg_text(text):
            res = re.search("'(.*)'", text)
            return res.groups()[0]

        replacement = replacements[0]
        replacement_content = {}
        if "insertedContent" in replacement:
            replacement_content = replacement["insertedContent"]
        elif "newModule" in replacement:
            replacement_content = replacement["newModule"]
        else:
            assert False
        replace_txt = replacement_content.get("text", None)
        if replace_txt is None:
            return True
        res = re.search(r"\$input\((.*)\)", replace_txt)
        if res:
            args_text = res.groups()[0]
            args = re.split(r',\s*', args_text)
            input_prompt_text = parse_arg_text(args[0])
            default_ret = ''
            if len(args) == 3:
                initialvalue = parse_arg_text(args[1])
                default_ret = parse_arg_text(args[2])
            elif len(args) == 2:
                initialvalue = parse_arg_text(args[1])
            if self.is_autofix_msg:
                newname = default_ret
                ok = True if len(newname) > 0 else False
            else:
                ok, newname = simpledialog.askstring(
                    title,
                    input_prompt_text,
                    initialvalue=initialvalue,
                    master=text_ctrl
                )
            if not ok:
                return False
            for replacement in replacements:
                replacement_content = {}
                if "insertedContent" in replacement:
                    replacement_content = replacement["insertedContent"]
                elif "newModule" in replacement:
                    replacement_content = replacement["newModule"]
                else:
                    assert False
                replacement_content["text"] = newname
        return True
