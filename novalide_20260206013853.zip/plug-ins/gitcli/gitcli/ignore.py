import os
from novalapp import _
from novalapp.widgets import simpledialog
from novalapp.util import fileutils


class AddIgnoreDlg(simpledialog.SingleChoiceDialog):
    """description of class"""

    def __init__(self, project_doc, master=None):

        ignore_file_path = os.path.join(project_doc.GetPath(), ".gitignore")
        choices = []
        if os.path.exists(ignore_file_path):
            content = fileutils.get_file_content(ignore_file_path)
            choices = content.splitlines()
        super().__init__(
            _('Ignore Files'),
            _('Files or File types below will be ignored') + ":",
            choices,
            -1,
            master
        )
