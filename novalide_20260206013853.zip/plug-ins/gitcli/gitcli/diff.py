import os
from novalapp.util import ui_utils
from novalapp.util import strutils, utils
from novalapp.lib.qsci import QsciScintilla, DEFAULT_MARGIN_INDEX
from novalapp.lib.pyqt import Qt, QColor
from novalapp import _, constants
from novalapp.common.encodings import UTF8_FILE_ENCODING
from git.repo import RepofileState


class FileDiffDialog(ui_utils.BaseModalDialog):

    DEL_TEXT_STYLE = 1
    ADD_TEXT_STYLE = 2
    DIFF_POSITION_STYLE = 3
    META_TEXT_STYLE = 4
    DEFAULT_DIFF_FONTSIZE = 9

    def __init__(self, master, face_ui, filepath, filestate):
        super().__init__(_('Diff-%s') % filepath, master)
        self.ui = face_ui
        self.contents = QsciScintilla()
        self.contents.setMarginWidth(DEFAULT_MARGIN_INDEX, 0)
        self.contents.setReadOnly(True)
        # 文字和文本框背景色为白色
        paper_background_color = QColor(Qt.white)
        # 设置文本框背景色
        self.contents.setPaper(paper_background_color)
        self.set_style_spec(
            constants.DEFAULT_FONT_FAMILY,
            QColor('#FF0000'),
            paper_background_color,
            self.DEFAULT_DIFF_FONTSIZE,
            self.DEL_TEXT_STYLE
        )

        self.set_style_spec(
            constants.DEFAULT_FONT_FAMILY,
            QColor('#00FF00'),
            paper_background_color,
            self.DEFAULT_DIFF_FONTSIZE,
            self.ADD_TEXT_STYLE
        )

        self.set_style_spec(
            constants.DEFAULT_FONT_FAMILY,
            QColor(Qt.darkCyan),
            paper_background_color,
            self.DEFAULT_DIFF_FONTSIZE,
            self.DIFF_POSITION_STYLE
        )
        self.contents.SendScintilla(
            QsciScintilla.SCI_STYLESETBOLD,
            self.DIFF_POSITION_STYLE,
            True
        )

        self.set_style_spec(
            constants.DEFAULT_FONT_FAMILY,
            QColor(Qt.black),
            paper_background_color,
            self.DEFAULT_DIFF_FONTSIZE,
            self.META_TEXT_STYLE
        )

        self.contents.SendScintilla(
            QsciScintilla.SCI_STYLESETBOLD,
            self.META_TEXT_STYLE,
            True
        )

        command = "diff"
        if filestate in [
            RepofileState.FILE_MODIFIED_STAGED,
            RepofileState.FILE_DELETED_STAGED,
            RepofileState.FILE_NEW_STAGED
        ]:
            command += " --cached --"
        elif filestate == RepofileState.FILE_DELETED_UNSTAGED:
            command += " --"
        command += " %s" % (strutils.emphasis_path(filepath))
        output = self.ui.CallGitProcess(command)
        text_lines: list = []
        self.filter_output(output, filestate, text_lines)
        if output is not None:
            self.contents.setText(os.linesep.join(text_lines))

        self.layout.addWidget(self.contents)
        self.create_ok_button()
        self.setWindowFlags(Qt.Dialog | Qt.WindowMinMaxButtonsHint | Qt.WindowCloseButtonHint)
        self.color_diff_texts()

    def filter_output(self, output, filestate, text_lines: list):
        lines = output.splitlines()
        for i, line in enumerate(lines):
            if i < 10:
                if line.find('diff --git ') != -1:
                    continue
                elif line.find('index ') != -1:
                    continue
                elif line.find('--- ') != -1:
                    continue
                elif line.find('+++ ') != -1:
                    continue
                if (filestate == RepofileState.FILE_DELETED_UNSTAGED or filestate == RepofileState.FILE_DELETED_STAGED
                    ) and (
                    line.find('deleted file mode ') != -1
                ):
                    text_lines.append(line)
                    continue
                elif filestate == RepofileState.FILE_NEW_STAGED and (
                    line.find('new file mode ') != -1
                ):
                    text_lines.append(line)
                    continue
            text_lines.append(line)

    def set_style_spec(self, family, foregroud, backgroud, size, style):
        # 设置文字字体
        self.contents.SendScintilla(QsciScintilla.SCI_STYLESETFONT,
                                    style, family.encode(UTF8_FILE_ENCODING))
        # 设置文字前景色
        self.contents.SendScintilla(QsciScintilla.SCI_STYLESETFORE, style, foregroud)
        # 设置文字背景色,一般和文本框背景色保持一致
        self.contents.SendScintilla(QsciScintilla.SCI_STYLESETBACK, style, backgroud)
        # 设置文字大小
        self.contents.SendScintilla(QsciScintilla.SCI_STYLESETSIZE, style, size)

    def start_styling(self, pos):
        self.contents.SendScintilla(QsciScintilla.SCI_STARTSTYLING, pos, 1)

    def set_styling(self, textlen, style):
        self.contents.SendScintilla(QsciScintilla.SCI_SETSTYLING, textlen, style)

    def color_diff_texts(self):
        block_flag = '@@'
        for line in range(self.contents.lines()):
            line_position = self.contents.SendScintilla(
                QsciScintilla.SCI_POSITIONFROMLINE,
                line
            )
            utils.get_logger().debug('line %d postion is %d', line, line_position)
            linetext = self.contents.text(line)
            line_bytes = linetext.encode(UTF8_FILE_ENCODING)

            if linetext.startswith(block_flag):
                index = linetext.rfind(block_flag)
                self.start_styling(line_position)
                start_style_bold_index = index + len(block_flag)
                self.set_styling(start_style_bold_index, self.DIFF_POSITION_STYLE)

                start_style_bold_pos = line_position + start_style_bold_index
                self.start_styling(start_style_bold_pos)
                utils.get_logger().debug(
                    "line %d, block stying length is:%d,bold start styling pos is :%d, bold styling length:%d",
                    line,
                    start_style_bold_index,
                    start_style_bold_pos,
                    len(line_bytes) - start_style_bold_index
                )
                self.set_styling(len(line_bytes) - start_style_bold_index, self.META_TEXT_STYLE)
            elif linetext.startswith('-'):
                self.start_styling(line_position)
                self.set_styling(len(line_bytes), self.DEL_TEXT_STYLE)
            elif linetext.startswith('+'):
                self.start_styling(line_position)
                self.set_styling(len(line_bytes), self.ADD_TEXT_STYLE)
