'''
Name:        clone.py
Purpose:     克隆远程仓库到本地

Author:      wukan

Created:     2025-11-23
Copyright:   (c) HongYunVM 2025
Licence:     <your licence>
'''
from .async_cmd import AsyncCmd
import os
import logging
from novalapp.util import fileutils
from git.cmd import GitCmd
logger = logging.getLogger(__name__)


class GitClone:
    """description of class"""

    def __init__(self, repo_path, source_addr):
        self._repo_path = repo_path
        self._source_addr = source_addr
        self._branchs = []
        self._head_branch_index = -1

    def clone(self, parent):
        self.ensure_repopath_exist()
        gitcmd = AsyncCmd(self._repo_path, parent)
        gitcmd.call(f"clone --progress {self._source_addr}")

    def ensure_repopath_exist(self):
        if not os.path.exists(self._repo_path):
            fileutils.makedirs(self._repo_path)

    def remote_branchs(self):
        '''
        在没有拉去远程仓库到本地的情况下,获取仓库远程分支列表
        '''
        if self._branchs:
            return self._branchs, self._head_branch_index
        self.ensure_repopath_exist()
        command = "init"
        git_cmd = GitCmd(self._repo_path)
        git_cmd.call_output(command)
        command = "remote add origin %s" % self._source_addr
        git_cmd.call_output(command)
        command = "remote show origin"
        output = git_cmd.call_output(command)

        default_branch_flag = 'HEAD branch:'
        head_zn_flag = 'HEAD 分支：'
        default_branch = ''
        branch_flag = False

        for line in output.splitlines():
            if line.find(default_branch_flag) != -1:
                default_branch = line.replace(default_branch_flag, "").strip()
                logger.info('default branch is %s', default_branch)

            elif line.find(head_zn_flag) != -1:
                default_branch = line.replace(head_zn_flag, "").strip()
                logger.info('default branch is %s', default_branch)

            elif line.find('Remote branches:') != -1 or (
                line.find('Remote branch:') != -1 or line.find('远程分支：') != -1
            ):
                branch_flag = True
            elif branch_flag:
                if line.find('Local branches configured for ') != -1 or line.find('Local refs configured for') != -1:
                    break
                branch_name = line.split()[0].strip()
                logger.debug('branch is %s', branch_name)
                self._branchs.append(branch_name)

        assert default_branch in self._branchs
        return self._branchs, self._branchs.index(default_branch)
