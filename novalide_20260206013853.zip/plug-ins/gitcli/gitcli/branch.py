from novalapp import _, get_app
from novalapp.util import ui_utils
from novalapp.lib.pyqt import (
    QMessageBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QCheckBox,
    QComboBox
)
from git.repo import Repo


class CheckoutBranchDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, face_ui):
        super().__init__(_('Checkout branch'), master)
        self.setFixedSize(400, 150)
        self.ui = face_ui

        branchs, default_branch_index = self.get_branchs()
        current_branch_hbox = QHBoxLayout()
        current_branch_hbox.addWidget(QLabel(_('Current branch') + ":"))

        self.current_branch_edit = QLineEdit()
        if branchs:
            self.current_branch_edit.setText(branchs[default_branch_index])
        self.current_branch_edit.setReadOnly(True)
        current_branch_hbox.addWidget(self.current_branch_edit)
        self.layout.addLayout(current_branch_hbox)

        branch_name_hbox = QHBoxLayout()
        branch_name_hbox.addWidget(QLabel(_('Checkout branch name') + ":"))
        self.repo_branchs = QComboBox()

        self.repo_branchs.addItems(branchs)
        self.repo_branchs.setEditable(True)
        branch_name_hbox.addWidget(self.repo_branchs)
        self.layout.addLayout(branch_name_hbox)

        self.remote_branch_chk = QCheckBox(_('Remote branch'))
        self.layout.addWidget(self.remote_branch_chk)
        self.create_standard_buttons()

    def get_branchs(self):
        repo = Repo(self.ui.GetProjectDocument().GetPath())
        return repo.branchs()

    def _ok(self):
        branch_name = self.repo_branchs.lineEdit().text().strip()
        if branch_name == "":
            QMessageBox.information(
                self.ui.GetProjectFrame(),
                get_app().GetAppName(),
                _('Please set branch name'))
            return

        repo = Repo(self.ui.GetProjectDocument().GetPath())
        try:
            if self.remote_branch_chk.isChecked():
                repo.checkout_remote_branch(f"{branch_name}")
            else:
                repo.checkout(f"{branch_name}")
            QMessageBox.information(
                self.ui.GetProjectFrame(),
                get_app().GetAppName(),
                _('Checkout branch `%s` success') % branch_name
            )
        except Exception as ex:
            QMessageBox.critical(
                self,
                _('Error'),
                _('Checkout branch `%s`fail') % branch_name + ":" + str(ex)
            )
            return
        ui_utils.BaseModalDialog._ok(self)


class CreateBranchDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, face_ui):
        super().__init__(_('New branch'), master)
        self.setFixedSize(400, 150)
        self.ui = face_ui

        current_branch_name = self.ui.current_branch

        branch_name_hbox = QHBoxLayout()
        branch_name_hbox.addWidget(QLabel(_('New branch name') + ":"))
        self.new_branch_edit = QLineEdit()
        branch_name_hbox.addWidget(self.new_branch_edit)
        self.layout.addLayout(branch_name_hbox)

        current_branch_hbox = QHBoxLayout()
        current_branch_hbox.addWidget(QLabel(_('From current branch') + ":"))

        self.current_branch_edit = QLineEdit()
        self.current_branch_edit.setText(current_branch_name)
        self.current_branch_edit.setReadOnly(True)
        current_branch_hbox.addWidget(self.current_branch_edit)
        self.layout.addLayout(current_branch_hbox)
        self.create_standard_buttons()

    def _ok(self):
        branch_name = self.new_branch_edit.text().strip()
        if branch_name == "":
            QMessageBox.information(
                self.ui.GetProjectFrame(),
                get_app().GetAppName(),
                _('Please input new branch name'))
            return

        repo = Repo(self.ui.GetProjectDocument().GetPath())
        try:
            repo.checkout_new_branch(f"{branch_name}")
            QMessageBox.information(
                self.ui.GetProjectFrame(),
                get_app().GetAppName(),
                _('New branch `%s` success') % branch_name
            )
        except Exception as ex:
            QMessageBox.critical(
                self,
                _('Error'),
                _('New branch `%s`fail') % branch_name + ":" + str(ex)
            )
            return
        ui_utils.BaseModalDialog._ok(self)
