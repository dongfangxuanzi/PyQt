import os
from novalapp import _, get_app
from novalapp.util import utils
from novalapp.lib.pyqt import (
    QMessageBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QCheckBox,
    QPushButton,
)
from novalapp.util import ui_utils, fileutils, strutils
from git.cmd import GitCmd, GITPATH_CONFIG_KEY


class Config:
    USER_NAME_CONFIG = 'user.name'
    USER_EMAIL_CONFIG = 'user.email'
    QUOTE_PATH_CONFIG = 'core.quotepath'

    def __init__(self, workpath=None):
        self._workpath = workpath
        if self._workpath is None:
            self._workpath = os.getcwd()
        self.base_command = ['config']

    def get_configs(self, config_keys: list):
        configs = {}
        output = self.call(["-l"])
        if output is None:
            return configs
        for line in output.splitlines():
            for config_key in config_keys:
                if line.find(config_key) != -1:
                    config_val = line.replace(f'{config_key}=', "").strip()
                    configs[config_key] = config_val
                    break
        return configs

    def call(self, command: list):
        cmd_list = self.base_command + command
        utils.get_logger().debug('git config command is %s', str(cmd_list))
        try:
            git_cmd = GitCmd(self._workpath)
            return git_cmd.call_output(cmd_list)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(get_app().GetTopWindow(), _('Error'), str(ex))
        return None


class GlobalConfig(Config):
    def __init__(self, workpath=None):
        super().__init__(workpath)
        self.base_command.append('--global')


class GitConfigurationDialog(ui_utils.BaseModalDialog):

    def __init__(self, master, face_ui):
        ui_utils.BaseModalDialog.__init__(self, _('Git Global Configuration'), master)
        self.setFixedSize(400, 200)
        self.ui = face_ui
        configs = {}

        git_path_box = QHBoxLayout()
        git_path_box.addWidget(QLabel(_('Git location') + ":"))
        self.git_location_entry = QLineEdit()
        git_path_box.addWidget(self.git_location_entry)
        utils.get_logger().debug('git install path is %s', GitCmd.GIT_INSTALLED_PATH)
        self.open_exe_path_btn = QPushButton('...')
        self.open_exe_path_btn.clicked.connect(self.open_git_path)
        git_path_box.addWidget(self.open_exe_path_btn)
        self.doc_path = self.ui.GetProjectDocument().GetPath()

        if GitCmd.GIT_INSTALLED_PATH is not None:
            self.git_location_entry.setText(GitCmd.GIT_INSTALLED_PATH)
            if GitCmd.is_valid_git_tool(GitCmd.GIT_INSTALLED_PATH):
                self.git_location_entry.setEnabled(False)
                self.open_exe_path_btn.setEnabled(False)
            else:
                QMessageBox.information(
                    self,
                    get_app().GetAppName(),
                    _('Git exe path %s is not a valid git tool') % GitCmd.GIT_INSTALLED_PATH
                )
            configs = Config(self.doc_path).get_configs(
                [Config.USER_NAME_CONFIG, Config.USER_EMAIL_CONFIG, Config.QUOTE_PATH_CONFIG]
            )
            utils.get_logger().debug('git configs is %s', str(configs))
        else:
            QMessageBox.critical(
                self,
                get_app().GetAppName(),
                _('Git no installed or not config installed path')
            )

        self.layout.addLayout(git_path_box)

        user_box = QHBoxLayout()
        user_box.addWidget(QLabel(_('User name') + ":"))
        self.user_name_entry = QLineEdit()
        user_box.addWidget(self.user_name_entry)
        if Config.USER_NAME_CONFIG in configs:
            self.user_name_entry.setText(configs[Config.USER_NAME_CONFIG])
        self.layout.addLayout(user_box)

        user_email_box = QHBoxLayout()
        user_email_box.addWidget(QLabel(_('User email') + ":"))
        self.user_email_entry = QLineEdit()
        user_email_box.addWidget(self.user_email_entry)
        if Config.USER_EMAIL_CONFIG in configs:
            self.user_email_entry.setText(configs[Config.USER_EMAIL_CONFIG])
        self.layout.addLayout(user_email_box)

        self.quote_path_chkbox = QCheckBox(_("Use Quote Path"))
        self.quote_path_chkbox.setChecked(
            strutils.str_to_bool(configs.get(Config.QUOTE_PATH_CONFIG, 'false'))
        )
        self.layout.addWidget(self.quote_path_chkbox)

        self.apply_golbal_chkbox = QCheckBox(_("Apply to global domain"))
        self.apply_golbal_chkbox.setChecked(True)
        self.layout.addWidget(self.apply_golbal_chkbox)

        self.create_standard_buttons()

    def open_git_path(self):
        if utils.is_windows():
            descrs = _("All executables") + " (*.exe)"
        else:
            descrs = _("All files") + " (*.*)"
        path, _filetype = QFileDialog.getOpenFileName(
            self,
            _('Select git path'),
            None,
            descrs
        )
        if not path:
            return
        self.git_location_entry.setText(fileutils.opj(path))

    def _ok(self):
        git_install_path = self.git_location_entry.text().strip()
        if git_install_path == "":
            QMessageBox.information(self, get_app().GetAppName(), _('Please confirm git location'))
            return
        if GitCmd.GIT_INSTALLED_PATH is None:
            if not GitCmd.is_valid_git_tool(git_install_path):
                QMessageBox.information(
                    self,
                    get_app().GetAppName(),
                    _('Git exe path %s is not a valid git tool') % git_install_path
                )
                return
            GitCmd.GIT_INSTALLED_PATH = git_install_path
            utils.profile_set(GITPATH_CONFIG_KEY, git_install_path)
        else:
            if self.user_name_entry.text().strip() == "":
                QMessageBox.information(self, get_app().GetAppName(), _('Please set git user name'))
                return
            if self.user_email_entry.text().strip() == "":
                QMessageBox.information(self, get_app().GetAppName(), _('Please set git user email'))
                return
            git_config = Config(self.doc_path)
            if self.apply_golbal_chkbox.isChecked():
                git_config = GlobalConfig(self.doc_path)
            user_name = strutils.emphasis_path(self.user_name_entry.text().strip())
            command = ["user.name", "%s" % user_name]
            git_config.call(command)

            user_email = strutils.emphasis_path(self.user_email_entry.text().strip())
            command = ["user.email", "%s" % user_email]
            git_config.call(command)
            quote_path = strutils.bool_to_str(self.quote_path_chkbox.isChecked())
            git_config.call(['core.quotepath', '%s' % quote_path])
        ui_utils.BaseModalDialog._ok(self)
