from typing import NamedTuple
import os
from novalapp.lib.pyqt import (
    QListWidget,
    Qt,
    QLabel
)
from novalapp import _
from novalapp.util import ui_utils, utils
from novalapp.lib.qsci import QsciScintilla, DEFAULT_MARGIN_INDEX
from git.cmd import GitdocCmd
from git.repo import Repo
from .textctrl import StyledTextCtrl


class CommitMessage(NamedTuple):
    commit_id: str
    author: str
    date: str
    content: str


class LogsDialog(ui_utils.BaseModalDialog):
    AUTHOR_FLAG = 'Author: '
    DATE_FLAG = 'Date: '

    MAX_LOGS_COUNT = 100

    def __init__(self, master, face_ui, branch_name=None):
        super().__init__(_('Repo Logs'), master)
        self.ui = face_ui
        self._branch_name = branch_name
        self.listlogs = QListWidget()
        self.listlogs.setAlternatingRowColors(True)
        self.listlogs.itemClicked.connect(self.onItemClicked)
        self.info_label = QLabel('')
        self.layout.addWidget(self.info_label)
        self.layout.addWidget(self.listlogs)
        self.contents = StyledTextCtrl()
        self.contents.setMarginWidth(DEFAULT_MARGIN_INDEX, 0)
        self.layout.addWidget(self.contents)
        self.contents.setUtf8(True)
        self.get_logs()

    def onItemClicked(self, item):
        self.show_log_info(item)

    def show_log_info(self, item):
        self.contents.SendScintilla(QsciScintilla.SCI_CLEARALL)
        item_data = item.data(Qt.UserRole)
        self.contents.append_text(_(self.AUTHOR_FLAG))
        self.contents.append_text(item_data.author)
        self.contents.append_text(os.linesep)
        self.contents.append_text(_(self.DATE_FLAG))
        self.contents.append_text(item_data.date)
        self.contents.append_text(os.linesep)
        self.contents.append_text(_('Commit Message') + ":")
        self.contents.append_text(os.linesep)
        self.contents.append_text(item_data.content)

    def create_commit_mesage(self, commit_dct, msg_list, item):
        if not commit_dct:
            return

        commit_text = os.linesep.join(msg_list)
        commit_msg = CommitMessage(
            commit_dct['commit_id'],
            commit_dct['author'],
            commit_dct['date'],
            commit_text
        )
        utils.get_logger().debug(
            'commit_id:%s,author:%s,date:%s,commit message:%s',
            commit_dct['commit_id'],
            commit_dct['author'],
            commit_dct['date'],
            commit_text
        )
        if item is not None:
            item.setData(Qt.UserRole, commit_msg)

    def get_logs(self):
        gitcmd = GitdocCmd(self.ui.GetProjectDocument())
        log_command = 'log'
        if self._branch_name is not None:
            log_command += ' '
            log_command += f'{self._branch_name}'
        f = gitcmd.huge_output_call(log_command + f' -n {self.MAX_LOGS_COUNT}')
        d = {}
        msg_list = []
        item_index = 0
        listitem = None
        for line in f:
            linestr = gitcmd.bytes_to_str_detect_encoding(line)
            if linestr.find(Repo.COMMIT_ID_FLAG) != -1:
                if d:
                    self.create_commit_mesage(d, msg_list, listitem)
                    msg_list.clear()
                commit_id = linestr.replace(Repo.COMMIT_ID_FLAG, "").strip()
                d['commit_id'] = commit_id
                self.listlogs.addItem(commit_id)
                listitem = self.listlogs.item(item_index)
                item_index += 1
            elif linestr.find(self.AUTHOR_FLAG) != -1 and d:
                author = linestr.replace(self.AUTHOR_FLAG, "").strip()
                d['author'] = author

            elif linestr.find(self.DATE_FLAG) != -1 and d:
                date = linestr.replace(self.DATE_FLAG, "").strip()
                d['date'] = date
            else:
                msg_list.append(linestr.strip())
        self.create_commit_mesage(d, msg_list, listitem)
        logs_item_count = self.listlogs.count()
        if logs_item_count < self.MAX_LOGS_COUNT:
            if self._branch_name is None:
                self.info_label.setText(_("There is total %d commit logs") % logs_item_count)
            else:
                self.info_label.setText(
                    _("There is total %d commit logs in current branch `%s`") % (logs_item_count, self._branch_name)
                )
        else:
            if self._branch_name is None:
                self.info_label.setText(
                    _('There logs count is too large, only show top %d logs') % (self.MAX_LOGS_COUNT)
                )
            else:
                self.info_label.setText(
                    _('The logs count of current branch is too large, only show top %d logs') % (self.MAX_LOGS_COUNT)
                )
        if item_index > 0:
            self.listlogs.setCurrentRow(0)
            self.show_log_info(self.listlogs.item(0))

    def _ok(self):
        ui_utils.BaseModalDialog._ok(self)
