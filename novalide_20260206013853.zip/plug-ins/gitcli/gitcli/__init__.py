from typing import Optional
import os
import shutil
from novalapp.util import utils
from novalapp import constants
from novalapp.project.wizard.templatemanager import WizardtemplateManager
from novalapp.widgets.redlabel import QRedLabel
from novalapp.bars.menubar import NewQMenu
from novalapp.util import ui_utils, strutils, fileutils
from novalapp.lib.pyqt import (
    QMessageBox,
    QListWidgetItem,
    Qt,
    QVBoxLayout,
    QHBoxLayout,
    QListWidget,
    QLabel,
    QSizePolicy,
    QTextEdit,
    QCheckBox,
    QPushButton,
    QDialog
)
from novalapp import _, get_app, newid
from pkg_resources import resource_filename
from novalapp.plugin import plugin
from novalapp.plugin import iface
from novalapp.util.transfer import FiledownloadSerivce
from git.exceptions import GitNotInstalledError
from git.cmd import GitCmd, GitdocCmd, get_askpass_path
from gitcli import gitui
from git.repo import Repo, RepofileState, UNKWNOW_BRANCH_NAME
from .logs import LogsDialog
from .command import CommandDialog
from .tags import CreateTagDialog, PushTagDialog, DeleteTagDialog
from .merge import MergeBranchDialog, MergeConflictsDialog
from .ignore import AddIgnoreDlg
from .branch import CheckoutBranchDialog, CreateBranchDialog
from .addr import AddRemoteAddrDialog, RemoteAddrListDialog
from .async_cmd import AsyncCmd
from .config import GitConfigurationDialog
from .diff import FileDiffDialog


class CommitDialog(ui_utils.BaseModalDialog):
    def __init__(
        self,
        master,
        ui,
        commit_files: list,
        single_file,
        commit=True,
        has_unmerged=False
    ):
        branch = ui.current_branch
        if commit:
            title = _('Commit-[%s]') % branch
        else:
            title = _('Checkout-[%s]') % branch
        super().__init__(title, master)
        self.setFixedSize(700, 650)
        self.ui = ui
        self.is_commit = commit
        self._single_file = single_file
        self._commit_files = commit_files
        self._has_unmerged = has_unmerged
        self._show_all_files = False

        vbox = QVBoxLayout()

        head_box = QHBoxLayout()
        self.commit_file_label = QLabel()
        head_box.addWidget(self.commit_file_label)

        top_r_vbox = QVBoxLayout()
        self.show_fullpath_chkbox = QCheckBox(_('Show full path'))
        self.show_fullpath_chkbox.clicked.connect(self.show_commit_filepath)
        top_r_vbox.addWidget(self.show_fullpath_chkbox)

        if self.is_commit:
            self.show_all_files_chkbox = QCheckBox(_('Show all files'))
            self.show_all_files_chkbox.clicked.connect(self.show_all_files)
            top_r_vbox.addWidget(self.show_all_files_chkbox)
        head_box.addStretch(1)
        head_box.addLayout(top_r_vbox)
        vbox.addLayout(head_box)

        self.listbox = QListWidget()
        self.listbox.itemClicked.connect(self.on_item_clicked)
        self.listbox.itemChanged.connect(self.on_item_changed)
        self.listbox.itemDoubleClicked.connect(self.on_item_doubleclicked)
        vbox.addWidget(self.listbox)

        h_button_box = QHBoxLayout()
        select_all_btn = QPushButton(_("Select All"))
        select_all_btn.clicked.connect(self.select_all)
        select_all_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        if self.is_commit:
            select_unstaged_btn = QPushButton(_("Select Unstaged Files"))
            select_unstaged_btn.clicked.connect(self.select_all_unstaged_files)
            select_unstaged_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        unselect_all_btn = QPushButton(_("UnSelect All"))
        unselect_all_btn.clicked.connect(self.unselect_all)
        unselect_all_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        rescan_btn = QPushButton(_("Rescan"))
        rescan_btn.clicked.connect(self.rescan)
        rescan_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        h_button_box.addWidget(select_all_btn)
        if self.is_commit:
            h_button_box.addWidget(select_unstaged_btn)
        h_button_box.addWidget(unselect_all_btn)
        h_button_box.addWidget(rescan_btn)
        h_button_box.addStretch(1)

        self.show_state_label = QRedLabel()
        h_button_box.addWidget(self.show_state_label)
        vbox.addLayout(h_button_box)

        if self.is_commit:
            vbox.addWidget(QLabel(_('Commit message')))
            self.text = QTextEdit()
            vbox.addWidget(self.text)

            push_hbox = QHBoxLayout()
            commit_push_button = QPushButton(_("Commit and Push"))
            commit_push_button.clicked.connect(self.commit_and_push)
            push_hbox.addWidget(commit_push_button)
            self.create_standard_buttons(push_hbox)
            vbox.addLayout(push_hbox)
            self.ok_button.setText(_("Commit"))
        else:
            self.create_standard_buttons(vbox)
            self.ok_button.setText(_("Checkout"))
        self.layout.addLayout(vbox)
        self.list_status_files(commit_files)

        self.files = []
        self.msg = ''
        self.push = False
        self._disable_item_checkstate_changed = False

    def has_unmerged_file(self):
        return self._has_unmerged

    @ui_utils.call_after_with_time(3000)
    def hide_label_state(self):
        self.show_state_label.setText('')

    def on_item_doubleclicked(self, item):
        item_file_data = item.data(Qt.UserRole)
        if item_file_data.file_state == RepofileState.FILE_UNMERGE_MODIFIED:
            dlg = MergeConflictsDialog(
                self,
                self.ui,
                item_file_data
            )
            if dlg.exec_() == QDialog.Accepted:
                self.rescan()
        else:
            FileDiffDialog(
                self,
                self.ui,
                item_file_data.filepath,
                item_file_data.file_state
            ).exec_()

    def on_item_changed(self, item):
        if self._disable_item_checkstate_changed or not self.is_commit:
            return
        item_file_data = item.data(Qt.UserRole)
        if item.checkState() == Qt.Checked:
            if item_file_data.file_state == RepofileState.FILE_UNTRACKED:
                item_file_data.file_state = RepofileState.FILE_NEW_STAGED
            elif item_file_data.file_state == RepofileState.FILE_MODIFIED_UNSTAGED:
                item_file_data.file_state = RepofileState.FILE_MODIFIED_STAGED
            elif item_file_data.file_state == RepofileState.FILE_DELETED_UNSTAGED:
                item_file_data.file_state = RepofileState.FILE_DELETED_STAGED
            elif item_file_data.file_state == RepofileState.FILE_UNMERGE_MODIFIED:
                QMessageBox.information(self, get_app().GetAppName(), _('This file has merge conflicts!'))
                return
            try:
                repo = Repo(get_app().get_current_project().GetPath())
                repo.add(item_file_data.filepath)
            except Exception as ex:
                utils.get_logger().error("%s", str(ex))
        else:
            if item_file_data.file_state == RepofileState.FILE_NEW_STAGED:
                item_file_data.file_state = RepofileState.FILE_UNTRACKED
            elif item_file_data.file_state == RepofileState.FILE_MODIFIED_STAGED:
                item_file_data.file_state = RepofileState.FILE_MODIFIED_UNSTAGED
            elif item_file_data.file_state == RepofileState.FILE_DELETED_STAGED:
                item_file_data.file_state = RepofileState.FILE_DELETED_UNSTAGED

            try:
                repo = Repo(get_app().get_current_project().GetPath())
                repo.git.call_output(f"restore --staged {item_file_data.filepath}")
            except Exception as ex:
                utils.get_logger().error("%s", str(ex))

    def on_item_clicked(self, item):
        item_file_data = item.data(Qt.UserRole)
        if item_file_data.file_state == RepofileState.FILE_MODIFIED_STAGED:
            self.show_state_label.setText(_('Modified, Staged for commit'))
        elif item_file_data.file_state == RepofileState.FILE_NEW_STAGED:
            self.show_state_label.setText(_('New, Staged for commit'))
        elif item_file_data.file_state == RepofileState.FILE_MODIFIED_UNSTAGED:
            self.show_state_label.setText(_('Modified, not staged'))
        elif item_file_data.file_state == RepofileState.FILE_DELETED_STAGED:
            self.show_state_label.setText(_('Staged for remove'))
        elif item_file_data.file_state == RepofileState.FILE_DELETED_UNSTAGED:
            self.show_state_label.setText(_('Missing'))
        elif item_file_data.file_state == RepofileState.FILE_UNTRACKED:
            self.show_state_label.setText(_('Untracked file, not staged'))

        elif item_file_data.file_state == RepofileState.FILE_UNMERGE_MODIFIED:
            self.show_state_label.setText(_('Merge conflicts, Modified file'))

        elif item_file_data.file_state == RepofileState.FILE_UNMERGE_DELETED:
            self.show_state_label.setText(_('Merge conflicts, Deleted file'))
        self.hide_label_state()

    def is_project_delete_file(self, root_path, commit_file):
        if commit_file.file_state in [
            RepofileState.FILE_DELETED_STAGED,
            RepofileState.FILE_DELETED_UNSTAGED
        ] and strutils.path_startswith(commit_file.fullpath, root_path):
            return True
        return False

    def is_project_file(self, proj_doc, commit_file):
        if not self._show_all_files:
            doc_model = proj_doc.GetModel()
            # 仅显示项目文件
            return doc_model.FindFile(commit_file.fullpath)
            # 显示项目目录和子目录下的所有文件
        return strutils.path_startswith(commit_file.fullpath, proj_doc.GetPath())

    def list_status_files(self, commit_files):
        # 修改待提交的文件
        commit_files_count = 0
        # 修改但不提交的文件
        unstaged_files_count = 0
        # 未追踪文件
        untracked_files_count = 0
        self._disable_item_checkstate_changed = True
        project_doc = get_app().get_current_project()
        doc_model = project_doc.GetModel()
        root_path = project_doc.GetPath()
        for commit_file in commit_files:
            utils.get_logger().debug(
                'project root path is %s, file path is %s',
                root_path,
                commit_file.fullpath
            )
            # 处理项目包含文件
            if not self._single_file and (
                not self.is_project_file(project_doc, commit_file)
            ) and (
                # 处理项目目录
                not doc_model.find_files(commit_file.fullpath)
            ) and (
                # 处理项目被删除文件
                not self.is_project_delete_file(root_path, commit_file)
            ) and (
                # 处理项目文件本身
                not project_doc.is_project_docfile(commit_file.fullpath)
            ):
                continue
            if not self.is_commit and commit_file.file_state in [
                RepofileState.FILE_MODIFIED_STAGED,
                RepofileState.FILE_DELETED_STAGED,
                RepofileState.FILE_NEW_STAGED,
                RepofileState.FILE_UNTRACKED
            ]:
                continue
            item = QListWidgetItem(commit_file.filepath)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            self.listbox.addItem(item)
            item.setData(Qt.UserRole, commit_file)
            if commit_file.file_state in [
                RepofileState.FILE_MODIFIED_STAGED,
                RepofileState.FILE_DELETED_STAGED,
                RepofileState.FILE_NEW_STAGED
            ]:
                item.setCheckState(Qt.Checked)
                commit_files_count += 1
            else:
                item.setCheckState(Qt.Unchecked)
                if commit_file.file_state == RepofileState.FILE_UNTRACKED:
                    untracked_files_count += 1
                elif commit_file.file_state == RepofileState.FILE_MODIFIED_UNSTAGED or commit_file.file_state == RepofileState.FILE_DELETED_UNSTAGED:
                    unstaged_files_count += 1

        if self.is_commit:
            label_msg = _('Commit files %d,Unstaged files %d,Untracked files %d') % (
                commit_files_count,
                unstaged_files_count,
                untracked_files_count
            )
            self.commit_file_label.setText(label_msg)
        else:
            self.commit_file_label.setText(_('Unstaged files %d checkoutable') % (unstaged_files_count))

        self._disable_item_checkstate_changed = False

    def show_all_files(self):
        self._show_all_files = self.show_all_files_chkbox.isChecked()
        self.rescan()

    def show_commit_filepath(self):
        self._disable_item_checkstate_changed = True
        if self.show_fullpath_chkbox.isChecked():
            for i in range(self.listbox.count()):
                item = self.listbox.item(i)
                data = item.data(Qt.UserRole)
                item.setText(data.fullpath)
        else:
            for i in range(self.listbox.count()):
                item = self.listbox.item(i)
                data = item.data(Qt.UserRole)
                item.setText(data.filepath)
        self._disable_item_checkstate_changed = False

    def rescan(self):
        self.listbox.clear()
        commit_files = []
        repo = Repo(get_app().get_current_project().GetPath())
        if self._single_file:
            try:
                filepath = self._commit_files[0].fullpath
                self._has_unmerged, commit_files = repo.status(filepath)
            except Exception as ex:
                utils.get_logger().error(str(ex))
                return
        else:
            try:
                self._has_unmerged, commit_files = repo.status()
            except Exception as ex:
                utils.get_logger().error(str(ex))
                return
        self.list_status_files(commit_files)

    def select_all_unstaged_files(self):
        self._disable_item_checkstate_changed = True
        select_files = []
        for i in range(self.listbox.count()):
            item = self.listbox.item(i)
            item_data = item.data(Qt.UserRole)
            item_state = item.checkState()
            if item_state != Qt.Checked and (
                item_data.file_state == RepofileState.FILE_MODIFIED_UNSTAGED or item_data.file_state == RepofileState.FILE_DELETED_UNSTAGED
            ):
                select_files.append(item_data.filepath)
                item.setCheckState(Qt.Checked)

        utils.get_logger().debug('select all %d unstaged files', len(select_files))
        self._disable_item_checkstate_changed = False
        if not select_files:
            return
        try:
            repo = Repo(get_app().get_current_project().GetPath())
            repo.add_files(select_files)
        except Exception as ex:
            utils.get_logger().error("%s", str(ex))
            QMessageBox.critical(self, _('Error'), str(ex))
        self.rescan()

    def select_all(self):
        if self.check_unmerge_files():
            return
        add_files = []
        self.check_listbox(add_files, True)
        utils.get_logger().debug('select all add total %d files', len(add_files))
        if not add_files or not self.is_commit:
            return
        try:
            repo = Repo(get_app().get_current_project().GetPath())
            repo.add_files(add_files)
        except Exception as ex:
            utils.get_logger().error("%s", str(ex))
            QMessageBox.critical(self, _('Error'), str(ex))
        self.rescan()

    def check_listbox(self, select_files: list, check=True):
        self._disable_item_checkstate_changed = True
        for i in range(self.listbox.count()):
            item = self.listbox.item(i)
            item_state = item.checkState()
            if check:
                if item_state != Qt.Checked:
                    item_data = item.data(Qt.UserRole)
                    # 不能选择有合并冲突的文件
                    if item_data.file_state == RepofileState.FILE_UNMERGE_MODIFIED:
                        continue
                    select_files.append(item_data.filepath)
                    item.setCheckState(Qt.Checked)
            else:
                if item_state != Qt.Unchecked:
                    item_data = item.data(Qt.UserRole)
                    select_files.append(item_data.filepath)
                    item.setCheckState(Qt.Unchecked)
        self._disable_item_checkstate_changed = False

    def unselect_all(self):
        unstore_files = []
        self.check_listbox(unstore_files, False)
        utils.get_logger().debug('unselect all unstore total %d files', len(unstore_files))
        if not unstore_files or not self.is_commit:
            return
        try:
            repo = Repo(get_app().get_current_project().GetPath())
            filpath_args = repo.filelist_to_args(unstore_files)
            repo.git.call_output(f"restore --staged {filpath_args}")
        except Exception as ex:
            utils.get_logger().error("%s", str(ex))
            QMessageBox.critical(self, _('Error'), str(ex))
        self.rescan()

    def check_unmerge_files(self):
        if self.has_unmerged_file():
            QMessageBox.warning(
                self,
                get_app().GetAppName(),
                _('Current branch has unmerged files, Please resolve merge conflicts first!')
            )
            return True
        return False

    def commit_and_push(self):
        # 提交推送文件之前必须先解决冲突
        if self.check_unmerge_files():
            return
        self.push = True
        self._ok()

    def GetFiles(self):
        files = []
        for i in range(self.listbox.count()):
            item = self.listbox.item(i)
            if item.checkState() == Qt.Checked:
                files.append(item.text())
        return files

    def _ok(self):
        self.files = self.GetFiles()
        if 0 == len(self.files):
            QMessageBox.information(self, get_app().GetAppName(), _('Please select at least one file'))
            return
        if self.is_commit:
            self.msg = self.text.toPlainText()
            if self.msg.strip() == '':
                QMessageBox.information(self, get_app().GetAppName(), _('Commit message could not be empty'))
                return
            # 提交文件之前必须先解决冲突
            if self.check_unmerge_files():
                return
        super()._ok()


class GitCliPlugin(plugin.Plugin):
    """plugin description here..."""
    plugin.Implements(iface.MainWindowI)

    def PlugIt(self, parent):
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing GitCli plugin")
        self.project_browser = get_app().MainFrame.projectview
        # 必须在这里添加翻译文件路径，否则下面向导对话框翻译不生效
        get_app().add_message_catalog('gitcli', __name__)
        try:
            # 必须确保电脑上已经安装git
            GitCmd.check_git()
        except GitNotInstalledError as ex:
            utils.get_logger().error(str(ex))
            self.project_browser.SIG_PROJECTVIEW_POPUP_ROOT_MENU.connect(
                self.AppenRootMenu)
            return
        WizardtemplateManager.get_manager().AddProjectTemplate(
            _("General"),
            "common_project_from_git_server",
            _("New Common Project From Git Server"),
            [
                (gitui.GitCommonProjectNameLocationPage, {
                    'project_dir_checked': False,
                    'enable_create_project_dir': False}
                 ),
                gitui.LocationSelectionPage,
                gitui.RepositorySourcePage,
                gitui.BranchSelectionPage,
                gitui.LocalDestinationPage,
                gitui.ImportGitfilesPage
            ]
        )

        WizardtemplateManager.get_manager().AddProjectTemplate(
            "Python",
            "python_project_from_git_server",
            _("New Python Project From Git Server"),
            [
                (gitui.GitPythonProjectNameLocationPage, {
                    'project_dir_checked': False,
                    'enable_create_project_dir': False}
                 ),
                gitui.LocationSelectionPage,
                gitui.RepositorySourcePage,
                gitui.BranchSelectionPage,
                gitui.LocalDestinationPage,
                gitui.ImportGitfilesPage
            ]
        )
        # 项目文件节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_FILE_MENU.connect(
            self.AppenFileMenu)
        # 项目根节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_ROOT_MENU.connect(
            self.AppenRootMenu)
        self.current_branch = None

    def end_download(self, package_path, parent):
        dirpath = os.path.dirname(package_path)
        try:
            fileutils.unzip(package_path, dirpath)
        except Exception as ex:
            utils.get_logger().exception(
                'unzip file %s to path %s fail exception',
                package_path,
                dirpath
            )
        src_askpass_path = os.path.join(dirpath, "askpass.exe")
        dest_askpass_path = get_askpass_path()
        try:
            shutil.copy(src_askpass_path, dest_askpass_path)
            utils.get_logger().info(
                'copy askpass path:%s to dest path %s success',
                src_askpass_path,
                dest_askpass_path
            )

        except Exception as ex:
            utils.get_logger().error(
                'copy askpass path %s dest path %s fail:%s',
                src_askpass_path,
                dest_askpass_path,
                str(ex)
            )
            QMessageBox.critical(
                self.GetProjectFrame(),
                _('Error'),
                str(ex)
            )

    def copy_askpass(self):
        if utils.is_windows():
            filename = "askpass.zip"
            fileurl = "https://gitee.com/wekay/NovalIDE/raw/dev/shell/askpass.zip"
            FiledownloadSerivce(force_download=False).download_file(
                fileurl,
                filename,
                self.end_download,
                get_app().MainFrame.GetNotebook()
            )

    def remove_askpass(self):
        dest_askpass_path = get_askpass_path()
        if os.path.exists(dest_askpass_path):
            try:
                os.remove(dest_askpass_path)
                utils.get_logger().info('remove installed askpass path %s success', dest_askpass_path)
            except Exception as ex:
                utils.get_logger().error(
                    'remove installed askpass path %s fail:%s',
                    dest_askpass_path,
                    str(ex)
                )

    def InstallHook(self):
        """Override in subclasses to allow the plugin to be loaded
        dynamically.
        @return: None

        """
        self.copy_askpass()

    def UninstallHook(self):
        self.remove_askpass()

    def EnableHook(self):
        pass

    def DisableHook(self):
        pass

    def GetFree(self):
        return True

    def GetPrice(self):
        pass

    def MatchPlatform(self):
        '''
            这里插件需要区分windows版本和linux版本
            windows版本把adkpass.exe包需要打包进去
            linux版本把可执行脚本adkpass.py包需要打包进去
        '''
        return True

    def AppenRootMenu(self, menu, item):
        if self.GetProjectDocument() is None:
            return
        submenu = NewQMenu(_("Version Control"))
        menu.AppendMenu(newid(), submenu)
        if GitCmd.GIT_INSTALLED_PATH is None:
            submenu.Append(newid(), _("Configuration"), handler=self.Configuration)
            return
        self.current_branch = self.GetBranch()
        utils.get_logger().info('current branch is %s', self.current_branch)
        if self.current_branch is None:
            submenu.Append(newid(), _("Init"), handler=self.Init)
        else:
            submenu.Append(newid(), _("Checkout files"), handler=self.checkout_commit_files)
            submenu.Append(newid(), _("Ignore files"), handler=self.add_ignore_files)

            pull_menu = NewQMenu(_("Pull"))
            submenu.AppendMenu(newid(), pull_menu)
            pull_menu.Append(newid(), _("Pull branch"), handler=self.pull_branch)
            pull_menu.Append(newid(), _("Pull all"), handler=self.pull_all)

            submenu.Append(newid(), _("Commit"), handler=self.Commit)
            submenu.Append(newid(), _("Push"), handler=self.Pushall)

            branch_menu = NewQMenu(_("Branch"))
            submenu.AppendMenu(newid(), branch_menu)
            branch_menu.Append(newid(), _("Checkout branch"), handler=self.CheckoutBranch)
            branch_menu.Append(newid(), _("New branch"), handler=self.new_branch)
            branch_menu.Append(newid(), _("Delete branch"), handler=self.delete_branch)

            remote_addr_menu = NewQMenu(_("Remote Addr"))
            submenu.AppendMenu(newid(), remote_addr_menu)
            remote_addr_menu.Append(newid(), _("Add Addr"), handler=self.add_remote_addr)
            remote_addr_menu.Append(newid(), _("Addr List"), handler=self.list_remote_addrs)

            logs_menu = NewQMenu(_("Logs"))
            submenu.AppendMenu(newid(), logs_menu)
            logs_menu.Append(newid(), _("Logs of current branch"), handler=self.pull_branch_logs)
            logs_menu.Append(newid(), _("Logs of all branchs"), handler=self.pull_logs)

            tags_menu = NewQMenu(_("Tags"))
            submenu.AppendMenu(newid(), tags_menu)
            tags_menu.Append(newid(), _("New tag"), handler=self.new_tag)
            tags_menu.Append(newid(), _("Push tag"), handler=self.push_tag)
            tags_menu.Append(newid(), _("Delete tag"), handler=self.delete_tag)
            submenu.AppendMenu(newid(), tags_menu)

            submenu.Append(newid(), _("Merge"), handler=self.merge_branch)

            submenu.Append(newid(), _("Command"), handler=self.run_git_command)
            submenu.Append(newid(), _("Configuration"), handler=self.Configuration)

    def merge_branch(self):
        MergeBranchDialog(self.GetProjectFrame(), self).exec_()

    def run_git_command(self):
        CommandDialog(self.GetProjectFrame(), self).exec_()

    def pull_branch_logs(self):
        LogsDialog(self.GetProjectFrame(), self, self.current_branch).exec_()

    def pull_logs(self):
        LogsDialog(self.GetProjectFrame(), self).exec_()

    def list_remote_addrs(self):
        RemoteAddrListDialog(self.GetProjectFrame(), self).exec_()

    def add_remote_addr(self):
        AddRemoteAddrDialog(self.GetProjectFrame(), self).exec_()

    def Configuration(self):
        GitConfigurationDialog(self.GetProjectFrame(), self).exec_()

    def Init(self):
        command = "init"
        self.CallGitProcess(command)

    def CheckoutBranch(self):
        CheckoutBranchDialog(self.GetProjectFrame(), self).exec_()

    def checkout_commit_files(self):
        try:
            repo = Repo(self.GetProjectDocument().GetPath())
            has_unmerged, commit_files = repo.status()
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return

        dlg = CommitDialog(
            get_app().MainFrame,
            self,
            commit_files,
            single_file=False,
            commit=False
        )
        if dlg.exec_() == CommitDialog.Rejected:
            return
        self.Checkoutfiles(dlg.files)

    def add_ignore_files(self):
        AddIgnoreDlg(self.GetProjectDocument(), self.GetProjectFrame()).exec_()

    def new_tag(self):
        CreateTagDialog(self.GetProjectFrame(), self).exec_()

    def push_tag(self):
        PushTagDialog(self.GetProjectFrame()).exec_()

    def delete_tag(self):
        DeleteTagDialog(self.GetProjectFrame()).exec_()

    def new_branch(self):
        CreateBranchDialog(self.GetProjectFrame(), self).exec_()

    def delete_branch(self):
        ret = QMessageBox.question(
            self.GetProjectFrame(),
            _('Delete branch'),
            _('Current content will clear when branch deleted, Are you sure to delete it?')
        )
        if ret == QMessageBox.No:
            return
        master_branch_name = "master"
        if self.current_branch == master_branch_name:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('%s branch is protected and not allowed to delete') % self.current_branch
            )
            return
        repo = Repo(self.GetProjectDocument().GetPath())
        try:
            repo.checkout(master_branch_name)
        except Exception as ex:
            QMessageBox.critical(
                self.GetProjectFrame(),
                _('Delete branch fail'),
                _('Delete branch %s fail') % self.current_branch + ":" + str(ex)
            )
            return
        if self.CallGitProcess(f"branch -D {self.current_branch}") is not None:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('Delete branch %s success') % self.current_branch
            )

    def pull_branch(self):
        # 刚初始化仓库时需要先拉取master分支
        if self.current_branch == UNKWNOW_BRANCH_NAME:
            command = f"pull origin master"
        else:
            command = f"pull origin {self.current_branch} --allow-unrelated-histories"
        if self.CallGitProcess(command) is not None:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('Pull success')
            )

    def pull_all(self):
        command = "pull"
        if self.CallGitProcess(command) is not None:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('Pull all success')
            )

    def Pushall(self):
        repo = Repo(self.GetProjectDocument().GetPath())
        self.AsyncPush(repo)

    def Push(self, repo):
        try:
            repo.push(self.current_branch)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(self.GetProjectFrame(), _('Push fail'), str(ex))
            return
        QMessageBox.information(
            self.GetProjectFrame(),
            get_app().GetAppName(),
            _('Push success')
        )

    def AsyncPush(self, repo):
        gitcmd = AsyncCmd(repo.repo_path, self.GetProjectFrame())
        retcode, err = gitcmd.call(f"push origin {self.current_branch}")
        if retcode == 0:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('Push success')
            )
        else:
            QMessageBox.critical(self.GetProjectFrame(), _('Push fail'), err)

    def Commit(self):
        commit_files = []
        try:
            repo = Repo(self.GetProjectDocument().GetPath())
            has_unmerged, commit_files = repo.status()
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return
        self.commit_push_files(repo, commit_files, has_unmerged=has_unmerged)

    def commit_push_files(
        self,
        repo,
        commit_files,
        single_file=False,
        has_unmerged=False
    ):
        dlg = CommitDialog(
            get_app().MainFrame,
            self,
            commit_files,
            single_file,
            has_unmerged=has_unmerged
        )
        if dlg.exec_() == CommitDialog.Rejected:
            return
        files = dlg.files
        try:
            repo.commit_files(files, dlg.text.toPlainText())
        except Exception as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(self.GetProjectFrame(), _('Commit fail'), str(ex))
            return
        if dlg.push:
            self.AsyncPush(repo)
        else:
            QMessageBox.information(self.GetProjectFrame(), get_app().GetAppName(), _('Commit success'))

    def AppenFileMenu(self, menu, item):
        self.current_branch = self.GetBranch()
        if self.current_branch is None:
            return
        project_browser = self.GetProjectFrame()
        filePath = project_browser.GetView()._GetItemFilePath(item)
        submenu = NewQMenu(_("Version Control"))
        menu.AppendMenu(newid(), submenu)
        submenu.Append(newid(), _("Commit"), handler=lambda: self.Commitfile(filePath))
        submenu.Append(newid(), _("Checkout"), handler=lambda: self.Checkoutfile(filePath))
        submenu.Append(newid(), _("Add to ignore"), handler=self.AddIgnoreFile)
        submenu.Append(newid(), _("Add"), handler=self.AddFiles)
        submenu.Append(newid(), _("Remove"), handler=lambda: self.RemoveFile(filePath))
        submenu.Append(newid(), _("Delete"), handler=lambda: self.DeleteFile(filePath))
        submenu.Append(newid(), _("Diff"), handler=lambda: self.diff_file_content(filePath))

    def diff_file_content(self, filepath):
        commit_files = []
        proj_doc = self.GetProjectDocument()
        try:
            repo = Repo(proj_doc.GetPath())
            has_unmerged, commit_files = repo.status(filepath)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return
        if not commit_files:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('The content of this file has no change')
            )
            return
        diff_file_path = filepath
        proj_file = proj_doc.GetModel().FindFile(filepath)
        if not proj_file:
            utils.get_logger().error(
                "file %s is not in project %s",
                filepath,
                proj_doc.GetModel().name
            )
        else:
            diff_file_path = proj_doc.GetModel().GetRelativePath(proj_file)
        FileDiffDialog(self.GetProjectFrame(), self, diff_file_path, commit_files[-1].file_state).exec_()

    def Checkoutfile(self, filepath):
        self.Checkoutfiles([filepath])

    def Checkoutfiles(self, files):
        ret = QMessageBox.question(
            self.GetProjectFrame(),
            get_app().GetAppName(),
            _('Checkout file will overwrite current file content,Are you sure to checkout?')
        )
        if ret == QMessageBox.No:
            return
        repo = Repo(self.GetProjectDocument().GetPath())
        for filepath in files:
            try:
                repo.checkout(filepath)
            except Exception as ex:
                utils.get_logger().error(str(ex))
                QMessageBox.critical(
                    self.GetProjectFrame(),
                    _('Error'),
                    _('checkout fail:%s') % (str(ex))
                )
                return
        QMessageBox.information(
            self.GetProjectFrame(),
            get_app().GetAppName(),
            _('Checkout success')
        )

    def AddIgnoreFile(self):
        pass

    def AddFiles(self):
        repo = Repo(self.GetProjectDocument().GetPath())
        selected_files = self.GetProjectFrame().GetView().GetSelectedFiles()
        try:
            repo.add_files(selected_files)
            QMessageBox.information(self.GetProjectFrame(), get_app().GetAppName(), _('Add success'))
        except Exception as ex:
            QMessageBox.critical(self.GetProjectFrame(), _('Error'), _('Add fail:%s') % str(ex))

    def RemoveFile(self, filePath):
        try:
            repo = Repo(self.GetProjectDocument().GetPath())
            repo.remove(filePath)
            QMessageBox.information(self.GetProjectFrame(), get_app().GetAppName(), _('Remove success'))
        except Exception as ex:
            QMessageBox.critical(self.GetProjectFrame(), _('Error'), _('Remove fail:%s') % str(ex))
            return

    def DeleteFile(self, filepath):
        yes_no_msg = QMessageBox.question(
            self.GetProjectFrame(),
            _("Delete Files"),
            _("Are you sure to delete files from the project and file system permanently?\n\nPlease use git checkout command to restore the deleted files."),
            QMessageBox.Yes | QMessageBox.No
        )
        if yes_no_msg == QMessageBox.No:
            return
        repo = Repo(self.GetProjectDocument().GetPath())
        try:
            repo.remove(filepath, delete=True)
            QMessageBox.information(self.GetProjectFrame(), get_app().GetAppName(), _('Delete success'))
        except Exception as ex:
            QMessageBox.critical(self.GetProjectFrame(), _('Error'), _('Delete fail:%s') % str(ex))
            return
        self.GetProjectDocument().GetFirstView().RemoveFromProject()

    def Commitfile(self, filepath):
        commit_files = []
        try:
            repo = Repo(self.GetProjectDocument().GetPath())
            has_unmerged, commit_files = repo.status(filepath)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return
        self.commit_push_files(repo, commit_files, True)

    def CallGitProcess(self, command, ask_pass=False) -> Optional[str]:
        try:
            git_cmd = GitdocCmd(self.GetProjectDocument())
            return git_cmd.call_output(command)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(self.GetProjectFrame(), _('Error'), str(ex))
        return None

    def GetBranch(self):
        try:
            repo = Repo(self.GetProjectDocument().GetPath())
            return repo.branch()
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return None

    def GetProjectDocument(self):
        project_browser = self.GetProjectFrame()
        return project_browser.GetView().GetDocument()

    def GetProjectFrame(self):
        return get_app().MainFrame.GetView(constants.PROJECT_VIEW_NAME)
