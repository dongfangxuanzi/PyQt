'''
Name:        async.py
Purpose:     异步执行命令,命令输出文本或耗时过长,通过异步线程的方式获取命令输出
             超过3秒弹出进度条显示文本输出进度

Author:      wukan

Created:     2025-11-23
Copyright:   (c) HongYunVM 2025
Licence:     mulan
'''
import subprocess
import logging
from novalapp.lib.pyqt import QThread, QProgressDialog, pyqtSignal
from novalapp import constants
from novalapp import _
from git.cmd import GitCmd

log = logging.getLogger(__name__)


class CommandProgressDialog(QProgressDialog):
    '''
        不定量进度条对话框,会一直循环显示动画
    '''
    SIG_APPEND_TEXT = pyqtSignal(str)
    SIG_COMMAND_EXIT = pyqtSignal(int, str)

    def __init__(self, parent, command):
        super().__init__(
            _("Please wait a minute for exec command to exit"),
            _("Cancel"),
            0,
            0,
            parent
        )
        self._command = command
        self.setWindowTitle(command)
        self.SIG_APPEND_TEXT.connect(self.appendmsg)
        self.SIG_COMMAND_EXIT.connect(self.command_exit)

    def appendmsg(self, msg):
        self.setLabelText(msg.strip())
        if msg == constants.PROGRESS_END:
            log.info('exec git command %s end, progress exit...', self._command)
            self.close()

    def command_exit(self, exitcode, errmsg):
        log.info('exec git command exitcode is %d', exitcode)
        if exitcode != 0:
            log.error("exec git command error:%s", errmsg)


class AsyncOutputThread(QThread):
    def __init__(self, async_cmd, outfile, process, callback_exit=None, errout=False):
        super().__init__(async_cmd.parent)
        self._async_cmd = async_cmd
        self._outfile = outfile
        self._process = process
        self._is_running = True
        self._callback_exit = callback_exit
        self._errout = errout
        self._err_text = ''

    @property
    def err(self):
        return self._err_text

    def run(self):
        while self._is_running:
            out = self._outfile.readline()
            if out == b'':
                if self._process.poll() is not None:
                    self._is_running = False
                    log.debug('command process is exit.....')
                    if self._callback_exit is not None:
                        self._callback_exit(self._process.returncode, self._err_text)
                    break
            else:
                outmsg = self._async_cmd.bytes_to_str_detect_encoding(out)
                if self._errout:
                    self._err_text += outmsg
                    log.error(outmsg.strip())
                else:
                    log.debug(outmsg.strip())
                self._async_cmd.update(outmsg)


class SynchronizeOutputThread(AsyncOutputThread):
    '''
        同步实时读取进程的输出,处理换行符,一个一个字节读取
    '''

    def run(self):
        temp = b''
        while self._is_running:
            out = self._outfile.read(1)
            if out == b'':
                if self._process.poll() is not None:
                    self._is_running = False
                    self.callback(temp)
                    break
            # 换行输出
            elif out == b'\r' or out == b'\n':
                self.callback(temp)
                temp = b''
            else:
                temp += out

    def callback(self, out):
        outmsg = self._async_cmd.bytes_to_str_detect_encoding(out)
        if self._errout:
            self._err_text += outmsg
            log.error(outmsg.strip())
        else:
            log.debug(outmsg.strip())
        self._async_cmd.update(outmsg)
        if not self._is_running:
            log.debug('command process is exit.....')
            if self._callback_exit is not None:
                self._callback_exit(self._process.returncode, self._err_text)


class AsyncCmd(GitCmd):

    def __init__(self, work_path, ui):
        super().__init__(work_path)
        self._parent = ui
        self._progress_dlg = None
        self._command = None

    @property
    def parent(self):
        return self._parent

    def call(self, cmd):
        git_command = self.make_git_command(cmd)
        log.info("git command is %s", git_command)
        self._command = git_command
        env = self.make_env()
        proc = subprocess.Popen(
            git_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=self._work_path,
            env=env
        )
        stdout_thread = SynchronizeOutputThread(
            self, proc.stdout, proc)
        stdout_thread.start()
        stderr_thread = SynchronizeOutputThread(self, proc.stderr, proc, errout=True, callback_exit=self.callback_exit)
        stderr_thread.start()
        self.show_progress()
        return proc.returncode, stderr_thread.err

    def callback_exit(self, exitcode, error_msg):
        log.info("exec git command %s exitcode is %d", self._command, exitcode)
        if hasattr(self.parent, 'SIG_COMMAND_EXIT'):
            self.parent.SIG_COMMAND_EXIT.emit(exitcode, error_msg)
        if self._progress_dlg is not None:
            self._progress_dlg.SIG_COMMAND_EXIT.emit(exitcode, error_msg)
            self._progress_dlg.SIG_APPEND_TEXT.emit(constants.PROGRESS_END)

    def show_progress(self):
        self._progress_dlg = CommandProgressDialog(self._parent, self._command)
        self._progress_dlg.exec_()

    def update(self, text):
        if self._progress_dlg is not None:
            self._progress_dlg.SIG_APPEND_TEXT.emit(text)
