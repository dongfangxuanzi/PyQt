from novalapp.lib.qsci import QsciScintilla
from novalapp.common.encodings import UTF8_FILE_ENCODING
from novalapp.util import utils


class StyledTextCtrl(QsciScintilla):
    """description of class"""

    def __init__(self, parent=None):
        super().__init__(parent)

    def _encode_string(self, source_str):
        """
        Protected method to encode a string depending on the current mode.

        @param string string to be encoded (str)
        @return encoded string (bytes)
        """
        if self.isUtf8():
            return source_str.encode(UTF8_FILE_ENCODING)
        return source_str.encode(utils.get_default_locale_encoding())

    def append_text(self, chars):
        encode_chars = self._encode_string(chars)
        self.append_chars(encode_chars)

    def append_chars(self, chars):
        length = len(chars)
        self.SendScintilla(QsciScintilla.SCI_APPENDTEXT, length, chars)
