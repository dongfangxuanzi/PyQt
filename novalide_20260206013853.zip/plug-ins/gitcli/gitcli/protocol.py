import enum


class Protocol(enum.Enum):
    GIT = 'git'
    HTTP = "http"
    HTTPS = "https"
    SSH = "ssh"
    FILE = "file"


HTTPS_PREFIX = Protocol.HTTPS.value + "://"
FILE_PREFIX = Protocol.FILE.value + "://"
GIT_PREFIX = Protocol.GIT.value + "@"

PROTOCOLS = (
    Protocol.GIT.value,
    Protocol.HTTP.value,
    Protocol.HTTPS.value,
    Protocol.SSH.value,
    Protocol.FILE.value
)
