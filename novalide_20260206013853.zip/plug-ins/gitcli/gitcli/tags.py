from novalapp import _, get_app
from novalapp.util import ui_utils
from novalapp.lib.pyqt import (
    QMessageBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QCheckBox,
    QComboBox,
    QTextEdit,
    QPushButton
)
from git.repo import Repo
from .logs import LogsDialog


class CreateTagDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, face_ui):
        super().__init__(_('New tag'), master)
        self.ui = face_ui

        tagname_hbox = QHBoxLayout()
        tagname_hbox.addWidget(QLabel(_('Tag name') + ":"))
        self.tagname_edit = QLineEdit()
        tagname_hbox.addWidget(self.tagname_edit)
        self.layout.addLayout(tagname_hbox)
        self.layout.addWidget(QLabel(_('Tag description') + ":"))

        self.text = QTextEdit()
        self.layout.addWidget(self.text)

        branch_name_point_hbox = QHBoxLayout()
        branch_name_point_hbox.addWidget(QLabel(_('Tag point from branch') + ":"))
        self.repo_branchs_combox = QComboBox()

        self.branchs, default_branch_index = self.get_branchs()
        self.repo_branchs_combox.addItems(self.branchs)
        self.repo_branchs_combox.setCurrentIndex(default_branch_index)
        branch_name_point_hbox.addWidget(self.repo_branchs_combox)
        self.layout.addLayout(branch_name_point_hbox)

        self.push_tag_chk = QCheckBox(_('Push'))
        self.layout.addWidget(self.push_tag_chk)

        self.create_standard_buttons()

    def get_branchs_recent_commit(self, branch):
        repo = Repo(self.ui.GetProjectDocument().GetPath())
        # 取分支的前10条提交日志
        commit_ids = repo.logs(branch, 10)
        return commit_ids[0]

    def get_branchs(self):
        repo = Repo(self.ui.GetProjectDocument().GetPath())
        return repo.branchs()

    def _ok(self):
        tagname = self.tagname_edit.text().strip()
        if tagname == "":
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Please input tag name'))
            return

        tagmsg = self.text.toPlainText().strip()
        if tagmsg == "":
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Please input tag description'))
            return
        branch_commit_id = self.get_branchs_recent_commit(
            self.branchs[self.repo_branchs_combox.currentIndex()]
        )
        repo = Repo(self.ui.GetProjectDocument().GetPath())
        try:
            repo.new_tag(tagname, tagmsg, branch_commit_id)
            if self.push_tag_chk.isChecked():
                PushTagDialog(self, tagname).exec_()
                ui_utils.BaseModalDialog._ok(self)
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('New tag `%s` success') % tagname
            )
        except Exception as ex:
            QMessageBox.critical(
                self,
                _('Error'),
                _('New tag `%s`fail') % tagname + ":" + str(ex)
            )
            return
        ui_utils.BaseModalDialog._ok(self)


class PushTagDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, tag_name=None):
        super().__init__(_('Push tag'), master)
        self.setFixedSize(400, 150)
        self.addrs, self.tags = self.get_addrs_and_tags()

        tags_hbox = QHBoxLayout()
        tags_hbox.addWidget(QLabel(_('Tag name') + ":"))
        self.tags_combox = QComboBox()
        self.tags_combox.addItems(self.tags)
        if tag_name is not None and tag_name in self.tags:
            self.tags_combox.setCurrentIndex(self.tags.index(tag_name))
        tags_hbox.addWidget(self.tags_combox)
        self.layout.addLayout(tags_hbox)

        addrs_hbox = QHBoxLayout()
        addrs_hbox.addWidget(QLabel(_('To remote addr') + ":"))

        self.addrs_combox = QComboBox()
        self.addrs_combox.addItems(self.addrs)
        addrs_hbox.addWidget(self.addrs_combox)
        self.layout.addLayout(addrs_hbox)
        self.create_standard_buttons()

    def get_addrs_and_tags(self):
        repo = Repo(get_app().get_current_project().GetPath())
        return repo.remote_addrs(), repo.tags()

    def _ok(self):
        repo = Repo(get_app().get_current_project().GetPath())
        current_index = self.tags_combox.currentIndex()
        if current_index < 0 or not self.tags:
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Please select one tag'))
            return
        tag_name = self.tags[current_index]
        addr = list(self.addrs.keys())[self.addrs_combox.currentIndex()]
        try:
            repo.push_tag(tag_name, addr)
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Push tag `%s` success') % tag_name
            )
        except Exception as ex:
            QMessageBox.critical(
                self,
                _('Error'),
                _('Push tag `%s`fail') % tag_name + ":" + str(ex)
            )
            return
        ui_utils.BaseModalDialog._ok(self)


class DeleteTagDialog(ui_utils.BaseModalDialog):
    def __init__(self, master):
        super().__init__(_('Delete tag'), master)
        self.setFixedSize(400, 150)
        self.tags = []
        tags_hbox = QHBoxLayout()
        tags_hbox.addWidget(QLabel(_('Tag name') + ":"))
        self.tags_combox = QComboBox()
        self.load_tags()
        tags_hbox.addWidget(self.tags_combox)

        del_button = QPushButton(_('Del'))
        del_button.clicked.connect(self.delete_tag)
        tags_hbox.addWidget(del_button)
        self.layout.addLayout(tags_hbox)
        self.create_ok_button()

    def get_tags(self):
        repo = Repo(get_app().get_current_project().GetPath())
        return repo.tags()

    def delete_tag(self):
        repo = Repo(get_app().get_current_project().GetPath())
        current_index = self.tags_combox.currentIndex()
        if current_index < 0 or not self.tags:
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Please select one tag'))
            return
        try:
            tagname = self.tags[current_index]
            repo.delete_tag(tagname)
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Delete tag `%s` success') % tagname
            )
            self.reload_tags()
        except Exception as ex:
            QMessageBox.critical(
                self,
                _('Error'),
                _('Delete tag `%s`fail') % tagname + ":" + str(ex)
            )

    def load_tags(self):
        self.tags = self.get_tags()
        self.tags_combox.addItems(self.tags)

    def reload_tags(self):
        self.tags_combox.clear()
        self.load_tags()
