import os
from novalapp.project.wizard.namelocation import ProjectNameLocationPage
from novalapp.python.project.page import BasePythonProjectNameLocationPage
from novalapp.lib.pyqt import QTreeWidget, QTreeWidgetItem, pyqtSignal
from novalapp import _, get_app
from novalapp.util import utils
import novalapp.project.wizard.page as projectwizard
from pkg_resources import resource_filename
from novalapp.lib.pyqt import (
    QMessageBox,
    QFileDialog,
    Qt,
    QVBoxLayout,
    QGroupBox,
    QHBoxLayout,
    QListWidget,
    QLabel,
    QSizePolicy,
    QLineEdit,
    QPushButton,
    QCheckBox,
    QComboBox
)
from novalapp.project.wizard import importfiles
from novalapp.project.ext import COMMON_PROJECT_EXTENSION
from novalapp.python.project.ext import PYTHON_PROJECT_EXTENSION
from novalapp.util import strutils
from novalapp.util import fileutils
from git.repo import Repo
from .clone import GitClone
from . import protocol
from .config import GlobalConfig


class GitCommonProjectNameLocationPage(ProjectNameLocationPage):

    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.can_finish = False

    def SaveProject(self, path):
        return True

    def SaveGitProject(self, path):
        return ProjectNameLocationPage.SaveProject(self, path)


class GitPythonProjectNameLocationPage(BasePythonProjectNameLocationPage):

    def __init__(self, master, **kwargs):
        BasePythonProjectNameLocationPage.__init__(self, master, **kwargs)
        self.can_finish = False

    def SaveProject(self, path):
        return True

    def SaveGitProject(self, path):
        return BasePythonProjectNameLocationPage.SaveProject(self, path)


class LocationSelectionPage(projectwizard.BitmapTitledContainerWizardPage):
    def __init__(self, master):
        projectwizard.BitmapTitledContainerWizardPage.__init__(
            self,
            master,
            _("Import codes from Git Repository"),
            _("Select Repository Source\nSelect a location of the source repository."),
            "python_logo.png"
        )
        self.can_finish = False

    def CreateContent(self, content_frame, **kwargs):
        # 设置path列存储模板路径,并隐藏改列
        self.tree = QTreeWidget(self)
        self.tree.setHeaderHidden(True)
        content_frame.addWidget(self.tree)
        path = resource_filename(__name__, '')
        clone_local_img_path = os.path.join(path, "res", "repository_rep.gif")
        clone_uri_img_path = os.path.join(path, "res", "editconfig.png")
        self.clone_local_img = get_app().GetImage(clone_local_img_path)
        self.clone_uri_img = get_app().GetImage(clone_uri_img_path)
        # 鼠标双击Tree控件事件
        self.tree.itemDoubleClicked.connect(self.on_double_click)
        self.local_repo_item = QTreeWidgetItem()
        rootitem = self.tree.invisibleRootItem()
        rootitem.addChild(self.local_repo_item)
        self.local_repo_item.setText(0, _("Existing local repository"))
        self.local_repo_item.setIcon(0, self.clone_local_img)

        self.uri_repo_item = QTreeWidgetItem()
        rootitem.addChild(self.uri_repo_item)
        self.uri_repo_item.setText(0, _("Clone URI"))
        self.uri_repo_item.setIcon(0, self.clone_uri_img)

        self.tree.setCurrentItem(self.local_repo_item)

    def on_double_click(self, event):
        self.parent().parent().GotoNextPage()


class RepositorySourcePage(projectwizard.BitmapTitledContainerWizardPage):

    def __init__(self, master):
        projectwizard.BitmapTitledContainerWizardPage.__init__(
            self,
            master,
            _("Import codes from Git Repository"),
            _("Source Git Repository\nEnter the location of the source repository."),
            "python_logo.png"
        )
        self.can_finish = False

    def CreateContent(self, content_frame, **kwargs):

        addr_hbox = QHBoxLayout()
        self.repo_addr_label = QLabel('')
        addr_hbox.addWidget(self.repo_addr_label)
        self.addr_entry = QLineEdit()
        addr_hbox.addWidget(self.addr_entry)
        self.addr_entry.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.addr_entry.textChanged.connect(self.ParseURL)
        self.open_local_btn = QPushButton("...")
        self.open_local_btn.clicked.connect(self.OpenLocal)
        self.open_local_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        addr_hbox.addWidget(self.open_local_btn)
        content_frame.addLayout(addr_hbox)

        protocol_hbox = QHBoxLayout()
        protocol_hbox.addWidget(QLabel(_('Protocol') + ":"))

        self.protocol_combox = QComboBox()
        protocol_hbox.addWidget(self.protocol_combox)
        self.protocol_combox.setCurrentIndex(0)
        self.protocol_combox.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.protocol_combox.addItems(protocol.PROTOCOLS)
        content_frame.addLayout(protocol_hbox)
        self.protocol_combox.currentIndexChanged.connect(self.SelectProtocol)

        name_hbox = QHBoxLayout()
        name_hbox.addWidget(QLabel(_('Username') + ":"))
        self.username_entry = QLineEdit()
        name_hbox.addWidget(self.username_entry)
        content_frame.addLayout(name_hbox)

        password_hbox = QHBoxLayout()
        password_hbox.addWidget(QLabel(_('Password') + ":"))
        self.password_entry = QLineEdit()
        # 设置输入模式为密码模式
        self.password_entry.setEchoMode(QLineEdit.Password)
        password_hbox.addWidget(self.password_entry)
        content_frame.addLayout(password_hbox)

        self.store_secure_btn = QCheckBox(_('Store in Secure Store'))
        content_frame.addWidget(self.store_secure_btn)

        content_frame.addStretch(1)

    def ParseURL(self, *args):
        addr = self.addr_entry.text().strip()
        protocol_name = ''
        if addr.startswith(protocol.FILE_PREFIX):
            protocol_name = protocol.Protocol.FILE.value
        elif addr.startswith(protocol.HTTPS_PREFIX):
            protocol_name = protocol.Protocol.HTTPS.value
        elif addr.startswith(protocol.GIT_PREFIX):
            protocol_name = protocol.Protocol.SSH.value
        if strutils.is_none_empty(protocol_name):
            return
        self.UpdateUI(protocol_name)
        self.protocol_combox.setCurrentIndex(protocol.PROTOCOLS.index(protocol_name))

    def SelectProtocol(self, event):
        self.UpdateUI(protocol.PROTOCOLS[self.protocol_combox.currentIndex()])

    def UpdateUI(self, protocol_name):
        if protocol_name == protocol.Protocol.FILE.value:
            self.username_entry.setEnabled(False)
            self.password_entry.setEnabled(False)
            self.store_secure_btn.setEnabled(False)
            self.open_local_btn.setEnabled(True)
            self.repo_addr_label.setText(_('Local addr') + ":")
        else:
            self.username_entry.setEnabled(True)
            self.password_entry.setEnabled(True)
            self.store_secure_btn.setEnabled(True)
            self.open_local_btn.setEnabled(False)
            self.repo_addr_label.setText(_('Repository addr') + ":")

    def OpenLocal(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog | QFileDialog.ShowDirsOnly
        path = QFileDialog.getExistingDirectory(
            self, _("Select directory"), '',
            options)
        if path:
            # 必须转换一下路径为系统标准路径格式
            self.addr_entry.setText(protocol.FILE_PREFIX + fileutils.opj(path))

    def Validate(self):
        if self.addr_entry.text().strip() == "":
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _("The repository addr could not be empty!")
            )
            return False
        if self.store_secure_btn.isChecked():
            GlobalConfig(self.GetAndEnsureProjectPath()).call(['credential.helper', 'store'])
        self.GetGitBraches()
        return True

    def Init(self):
        item = self.GetPrev().tree.currentItem()
        if item:
            if item == self.GetPrev().local_repo_item:
                self.UpdateUI(protocol.Protocol.FILE.value)
                self.protocol_combox.setCurrentIndex(
                    protocol.PROTOCOLS.index(protocol.Protocol.FILE.value)
                )
            else:
                self.protocol_combox.setCurrentIndex(
                    protocol.PROTOCOLS.index(protocol.Protocol.GIT.value)
                )
                self.UpdateUI(protocol.Protocol.GIT.value)

    def GetAddr(self):
        raw_addr = self.addr_entry.text().strip()
        if self.protocol_combox.currentIndex() == (
            protocol.PROTOCOLS.index(protocol.Protocol.HTTPS.value)
        ):
            username = self.username_entry.text().strip()
            if username != "":
                r_addr = raw_addr.replace(protocol.HTTPS_PREFIX, "")
                addr = protocol.HTTPS_PREFIX + "%s:%s@" % (
                    username,
                    self.password_entry.text().strip()
                ) + r_addr
                return addr
        return raw_addr

    def GetAndEnsureProjectPath(self):
        project_path = self.GetPrev().GetPrev().GetProjectLocation()
        if not os.path.exists(project_path):
            os.makedirs(project_path)
        return project_path

    def GetGitBraches(self):
        remote_repo_addr = self.addr_entry.text().strip()
        if remote_repo_addr in BranchSelectionPage.REPOSITORYES and len(BranchSelectionPage.REPOSITORYES[remote_repo_addr]['branches']) > 0:
            return
        project_path = self.GetAndEnsureProjectPath()
        gitclone = GitClone(project_path, self.GetAddr())
        try:
            branches, defaultindex = gitclone.remote_branchs()
            utils.get_logger().info('remote branches is %s, default branch is %s', branches, branches[defaultindex])
            BranchSelectionPage.REPOSITORYES[remote_repo_addr] = {
                'branches': branches,
                'default_branch_index': defaultindex
            }
        except Exception as e:
            QMessageBox.critical(self, _("Error"), str(e))
        git_dir = os.path.join(project_path, ".git")
        fileutils.safe_remove(git_dir)


class BranchSelectionPage(projectwizard.BitmapTitledContainerWizardPage):

    REPOSITORYES = {}

    def __init__(self, master):
        projectwizard.BitmapTitledContainerWizardPage.__init__(self, master, _("Import codes from Git Server"), _(
            "Branch Selection\nSelect branches to clone from the remote repository."), "python_logo.png")
        self.can_finish = False
        self.default_branch = None

    def CreateContent(self, content_frame, **kwargs):

        self.listbox = QListWidget()
        content_frame.addWidget(self.listbox)
        path = resource_filename(__name__, '')
        branch_img_path = os.path.join(path, "res", "branches_obj.png")
        self.branch_img = get_app().GetImage(branch_img_path)

    def Init(self):
        self.listbox.clear()
        remote_repo_addr = self.GetPrev().addr_entry.text().strip()
        if remote_repo_addr in self.REPOSITORYES:
            branchs = self.REPOSITORYES[remote_repo_addr]['branches']
            default_branch_index = self.REPOSITORYES[remote_repo_addr]['default_branch_index']
            self.default_branch = branchs[default_branch_index]
            self.listbox.addItems(branchs)
            for index in range(self.listbox.count()):
                listitem = self.listbox.item(index)
                if index == default_branch_index:
                    listitem.setCheckState(Qt.Checked)
                else:
                    listitem.setCheckState(Qt.Unchecked)

    def Validate(self):
        self.branches = self.GetBranches()
        if 0 == len(self.branches):
            QMessageBox.information(self,
                                    get_app().GetAppName(),
                                    _("You must select at least one branch!")
                                    )
            return False
        return True

    def GetBranches(self):
        branches = []
        for index in range(self.listbox.count()):
            listitem = self.listbox.item(index)
            if listitem.checkState() == Qt.Checked:
                branches.append(listitem.text())
        return branches


class LocalDestinationPage(projectwizard.BitmapTitledContainerWizardPage):

    SIG_COMMAND_EXIT = pyqtSignal(int, str)

    def __init__(self, master):
        projectwizard.BitmapTitledContainerWizardPage.__init__(self, master, _("Import codes from Git Server"), _(
            "Local Destination\nConfigure the local storage location for project."), "python_logo.png")
        self.can_finish = False
        self.SIG_COMMAND_EXIT.connect(self.end_clone_project)

    def CreateContent(self, content_frame, **kwargs):
        sbox = QGroupBox(_("Destination") + ":")

        sbox_layout = QVBoxLayout()
        hbox = QHBoxLayout()
        hbox.addWidget(QLabel(_('Directory') + ":"))
        self.dest_path_entry = QLineEdit()
        hbox.addWidget(self.dest_path_entry)
        sbox_layout.addLayout(hbox)

        branch_hbox = QHBoxLayout()
        branch_hbox.addWidget(QLabel(_('Initial branch') + ":"))
        self.branch_entry = QComboBox()
        branch_hbox.addWidget(self.branch_entry)
        sbox_layout.addLayout(branch_hbox)

        self.clone_submodules_btn = QCheckBox(_('Clone submodules'))
        sbox_layout.addWidget(self.clone_submodules_btn)
        sbox_layout.addStretch(1)
        sbox.setLayout(sbox_layout)
        content_frame.addWidget(sbox)
        self.branches = []

    def Init(self):
        self.dest_path_entry.setText(self.GetPrev().GetPrev().GetAndEnsureProjectPath())
        self.dest_path_entry.setEnabled(False)
        self.branches = self.GetPrev().GetBranches()
        self.branch_entry.clear()
        self.branch_entry.addItems(self.branches)

    def CloneProject(self):
        gitclone = GitClone(self.dest_path_entry.text(), self.GetPrev().GetPrev().GetAddr())
        try:
            gitclone.clone(self)
        except Exception as ex:
            QMessageBox.critical(self, _("Clone project error"), str(ex))
            return False
        return True

    def Validate(self):
        suc = self.CloneProject()
        if suc:
            repo = Repo(self.get_dest_repo_path())
            branch = self.branches[self.branch_entry.currentIndex()]
            # 非默认分支,需要拉取新分支
            if self.GetPrev().default_branch != branch:
                try:
                    repo.checkout_remote_branch(f"{branch}")
                except Exception as ex:
                    QMessageBox.critical(self, _('Error'), str(ex))
                    return False
        return suc

    def end_clone_project(self, exitcode, errmsg):
        if exitcode != 0:
            QMessageBox.critical(self, _("Clone project error"), errmsg)

    def get_dest_repo_path(self):
        filename = strutils.get_filename_without_ext(self.GetPrev().GetPrev().addr_entry.text().strip())
        dest_repo_path = os.path.join(self.dest_path_entry.text(), filename)
        return dest_repo_path


class ImportGitfilesPage(importfiles.ImportfilesPage):
    def __init__(self, master):
        importfiles.ImportfilesPage.__init__(self, master)
        self.can_finish = True
        self.rejects += [PYTHON_PROJECT_EXTENSION, COMMON_PROJECT_EXTENSION]

    def Init(self):
        dest_repo_path = self.GetPrev().get_dest_repo_path()
        utils.get_logger().info('clone %s to dest path %s', self.GetPrev().GetPrev().GetPrev().GetAddr(), dest_repo_path)
        self.dir_entry.setText(dest_repo_path)

    def Finish(self):
        project_name_page = self.GetPrev().GetPrev().GetPrev().GetPrev().GetPrev()
        projName = project_name_page.name_entry.text().strip()
        project_path = self.GetProjectPath()

        project_name_page = self.get_namelocation_page()
        project_ext = COMMON_PROJECT_EXTENSION
        if isinstance(project_name_page, BasePythonProjectNameLocationPage):
            project_ext = PYTHON_PROJECT_EXTENSION
        fullProjectPath = os.path.join(project_path, strutils.MakeNameEndInExtension(projName, project_ext))
        if not project_name_page.SaveGitProject(fullProjectPath):
            return False
        return super().Finish()

    def get_namelocation_page(self):
        return self.GetPrev().GetPrev().GetPrev().GetPrev().GetPrev()

    def GetProjectPath(self):
        project_name_page = self.get_namelocation_page()
        project_path = project_name_page.GetProjectLocation()
        return os.path.join(project_path, strutils.get_filename_without_ext(self.GetPrev().GetPrev().GetPrev().addr_entry.text().strip()))
