from novalapp import _, get_app
from novalapp.util import ui_utils
from novalapp.lib.pyqt import (
    QMessageBox,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QLineEdit,
    QPushButton,
)


class CommandDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, face_ui):
        super().__init__(_('Run command'), master)
        self.setFixedSize(400, 150)
        self.ui = face_ui
        command_name_hbox = QHBoxLayout()
        command_name_hbox.addWidget(QLabel(_('Exec command') + ":"))

        self.command_entry = QLineEdit()
        self.command_entry.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)

        command_name_hbox.addWidget(self.command_entry)

        run_button = QPushButton(_('Run'))
        run_button.clicked.connect(self.run_command)
        command_name_hbox.addWidget(run_button)
        self.layout.addLayout(command_name_hbox)

        self.create_ok_button()

    def run_command(self):
        command_line = self.command_entry.text().strip()
        git_start_flag = 'git '
        if command_line.startswith(git_start_flag):
            command_line = command_line.replace(git_start_flag, "")

        if self.ui.CallGitProcess(command_line) is not None:
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Exec command success')
            )
