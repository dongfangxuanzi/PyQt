from novalapp import _, get_app
from novalapp.util import ui_utils
from novalapp.util import fileutils
from novalapp.lib.pyqt import (
    QMessageBox,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QLineEdit,
    QPushButton,
    QComboBox
)
from git.repo import Repo


class RemoteAddrListDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, face_ui):
        super().__init__(_('Repository remote addrs'), master)
        self.setFixedSize(400, 150)
        self.ui = face_ui
        self.addrs = self.get_repository_addrs()

        repo_name_hbox = QHBoxLayout()
        repo_name_hbox.addWidget(QLabel(_('Repository name') + ":"))
        self.repo_names = QComboBox()
        names = self.get_names()
        self.repo_names.addItems(names)
        self.repo_names.currentIndexChanged.connect(self.set_addr)
        repo_name_hbox.addWidget(self.repo_names)
        self.layout.addLayout(repo_name_hbox)

        repo_addr_hbox = QHBoxLayout()
        repo_addr_hbox.addWidget(QLabel(_('Repository addr') + ":"))
        self.addr_entry = QLineEdit()
        self.addr_entry.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.addr_entry.setReadOnly(True)
        repo_addr_hbox.addWidget(self.addr_entry)

        go_button = QPushButton(_('Go'))
        go_button.clicked.connect(self.goto_url)
        repo_addr_hbox.addWidget(go_button)
        self.layout.addLayout(repo_addr_hbox)

        if names:
            self.repo_names.setCurrentIndex(names.index('origin'))
            self.set_addr()
        self.create_ok_button()

    def goto_url(self):
        fileutils.startfile(self.addr_entry.text())

    def get_names(self):
        return list(self.addrs.keys())

    def get_repository_addrs(self):
        repo = Repo(self.ui.GetProjectDocument().GetPath())
        return repo.remote_addrs()

    def set_addr(self):
        index = self.repo_names.currentIndex()
        self.addr_entry.setText(list(self.addrs.values())[index])


class AddRemoteAddrDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, face_ui):
        super().__init__(_('Add repository remote addr'), master)
        self.setFixedSize(400, 150)
        self.ui = face_ui

        repo_name_hbox = QHBoxLayout()
        repo_name_hbox.addWidget(QLabel(_('Repository name') + ":"))
        self.repo_name_entry = QLineEdit()
        self.repo_name_entry.setText('origin')
        self.repo_name_entry.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        repo_name_hbox.addWidget(self.repo_name_entry)
        self.layout.addLayout(repo_name_hbox)

        repo_addr_hbox = QHBoxLayout()
        repo_addr_hbox.addWidget(QLabel(_('Repository addr') + ":"))
        self.addr_entry = QLineEdit()
        self.addr_entry.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        repo_addr_hbox.addWidget(self.addr_entry)
        self.layout.addLayout(repo_addr_hbox)

        self.create_standard_buttons()

    def _ok(self):
        name = self.repo_name_entry.text().strip()
        if name == "":
            QMessageBox.information(
                self.ui.GetProjectFrame(),
                get_app().GetAppName(),
                _('Please set repository name'))
            return

        addr = self.addr_entry.text().strip()
        if addr == "":
            QMessageBox.information(
                self.ui.GetProjectFrame(),
                get_app().GetAppName(),
                _('Please set repository addr'))
            return

        command = "remote add %s %s" % (name, addr)
        if self.ui.CallGitProcess(command) is None:
            return
        ui_utils.BaseModalDialog._ok(self)
