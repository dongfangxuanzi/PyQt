from novalapp import _, get_app
from novalapp.util import ui_utils, fileutils, strutils
from novalapp.lib.pyqt import (
    QMessageBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QComboBox,
    QSizePolicy
)
from novalapp.widgets.codesample import CodeSampleCtrl
from novalapp.syntax.syntax import SyntaxThemeManager
from novalapp.common.encodings import UTF8_FILE_ENCODING
from git.repo import Repo


class MergeBranchDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, face_ui):
        super().__init__(_('Merge branch'), master)
        self.setFixedSize(400, 150)
        self.ui = face_ui

        self.branchs, default_branch_index = self.get_branchs()

        branch_name_hbox = QHBoxLayout()
        branch_name_hbox.addWidget(QLabel(_('From Branch') + ":"))
        self.repo_branchs = QComboBox()

        self.repo_branchs.addItems(self.branchs)
        branch_name_hbox.addWidget(self.repo_branchs)
        self.layout.addLayout(branch_name_hbox)

        current_branch_hbox = QHBoxLayout()
        current_branch_hbox.addWidget(QLabel(_('Merge to current branch') + ":"))

        self.current_branch_edit = QLineEdit()
        self.current_branch_name = self.branchs[default_branch_index]
        if self.branchs:
            self.current_branch_edit.setText(self.current_branch_name)
        self.current_branch_edit.setReadOnly(True)
        current_branch_hbox.addWidget(self.current_branch_edit)
        self.layout.addLayout(current_branch_hbox)

        self.create_standard_buttons()

    def get_branchs(self):
        repo = Repo(self.ui.GetProjectDocument().GetPath())
        return repo.branchs()

    def _ok(self):
        merge_from_branch = self.branchs[self.repo_branchs.currentIndex()]
        if merge_from_branch == self.current_branch_name:
            QMessageBox.information(
                self.ui.GetProjectFrame(),
                get_app().GetAppName(),
                _('The source branch and the target branch for merging cannot the same')
            )
            return
        pull_command = f"pull origin {merge_from_branch} --allow-unrelated-histories"
        if self.ui.CallGitProcess(pull_command) is None:
            return

        merge_command = f"merge {merge_from_branch}"
        if self.ui.CallGitProcess(merge_command) is None:
            return
        QMessageBox.information(
            self.ui.GetProjectFrame(),
            get_app().GetAppName(),
            _('Merge branch `%s` to branch `%s` success') % (merge_from_branch, self.current_branch_name)
        )

        ui_utils.BaseModalDialog._ok(self)


class MergeConflictsDialog(ui_utils.BaseModalDialog):

    def __init__(self, master, face_ui, mergefile):
        super().__init__(_('Merge Conflict-%s') % mergefile.filepath, master)
        self.ui = face_ui
        self.contents = CodeSampleCtrl(self)
        self.contents.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.filepath = mergefile.fullpath
        self.contents.setText(fileutils.get_file_content(self.filepath))
        ext = strutils.get_file_extension(fileutils.get_filename_from_path(self.filepath))
        lang_lexer = SyntaxThemeManager.manager().GetLangLexerFromExt(ext)
        self.contents.set_lang_lexer(lang_lexer.GetLangId())
        self.layout.addWidget(self.contents)
        self.create_standard_buttons()

    def shouldAcceptFocus(self):
        return True

    def save_to_file(self):
        with open(self.filepath, "w", encoding=UTF8_FILE_ENCODING) as fw:
            fw.write(self.contents.text())

    def _ok(self):
        if self.contents.is_modified():
            ret = QMessageBox.question(
                self,
                get_app().GetAppName(),
                _('File content is changed, Are you sure resolve the merge conflict and want to commit it?')
            )
            if ret == QMessageBox.Yes:
                try:
                    self.save_to_file()
                    repo = Repo(self.ui.GetProjectDocument().GetPath())
                    repo.add(self.filepath)
                except Exception as ex:
                    QMessageBox.critical(
                        self,
                        _('Error'),
                        str(ex)
                    )
                    return
        super()._ok()

    def _cancel(self):
        if self.contents.is_modified():
            ret = QMessageBox.question(
                self,
                get_app().GetAppName(),
                _('File content is changed, Do you want to save it?')
            )
            if ret == QMessageBox.Yes:
                self._ok()
                return
        super()._cancel()
