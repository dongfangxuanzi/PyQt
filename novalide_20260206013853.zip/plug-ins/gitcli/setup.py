from distutils.core import setup
import platform
from setuptools import find_packages
data_files = {}


GIT_DIR = "gitcli"
if platform.system() == "Windows":
    data_files = {
        GIT_DIR: []
    }
else:
    data_files = {
        GIT_DIR: ['./askpass/askpass.py']
    }

data_files[GIT_DIR].append('res/*.*')
data_files[GIT_DIR].append('locale/zh_CN/LC_MESSAGES/gitcli.mo')
setup(name='GitCli',
      version='1.0',
      description='''gitcli is a graphical Git client plugin with support for Git and Pull Requests for GitHub, Gitee and so on. it runs on Windows and Linux os system''',
      author='wukan',
      author_email='kan.wu@genetalks.com',
      url='',
      license='Mulan',
      packages=find_packages(),
      install_requires=[],
      zip_safe=False,
      package_data=data_files,
      data_files=[],
      classifiers=[
      ],
      keywords='',
      entry_points="""
        [Noval.plugins]
        GitCli = gitcli:GitCliPlugin
        """
      )
