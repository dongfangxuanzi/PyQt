
class GitNotInstalledError(Exception):
    '''未安装git'''


class ProjectNotRepositoryError(Exception):
    '''项目代码未经git管理'''


class ProjectFileNotCommitError(Exception):
    '''项目代码未提交'''


class GitCommandError(RuntimeError):
    ''''''


class UnmergeError(Exception):
    ''''''
