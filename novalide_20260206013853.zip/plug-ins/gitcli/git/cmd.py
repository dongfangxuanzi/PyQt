import logging
import re
import os
from typing import Union
from .exceptions import GitNotInstalledError, GitCommandError
from novalapp import _
from novalapp.common.encodings import ASCII_FILE_ENCODING, UTF8_FILE_ENCODING
from novalapp.executable import Executable
import novalapp.project.variables as variablesutils
from novalapp.util import utils, strutils, fileutils

logger = logging.getLogger(__name__)

# 如果git安装不在系统环境路径里面,可以通过软件配置git路径
GITPATH_CONFIG_KEY = "git_installed_path"


def get_askpass_path():
    if utils.is_windows():
        project_variable_manager = variablesutils.GetProjectVariableManager()
        d = project_variable_manager.GetGlobalVariables()
        install_path = d["InstallPath"]
        ask_pass_path = os.path.join(install_path, "askpass.exe")
    else:
        ask_pass_path = os.path.join(path, "askpass/askpass.py")
    return ask_pass_path


class GitCmd:
    """description of class"""
    # 全局git安装路径
    GIT_INSTALLED_PATH = None

    # 替换所有匹配的转义字符
    PATTERN = re.compile(r'\\(\d{3})')

    def __init__(self, work_path=None, git_path=None):
        if git_path is None:
            self.check_git()
            self.git_path = self.GIT_INSTALLED_PATH
        else:
            self.git_path = git_path
        if work_path is None:
            work_path = os.getcwd()
        self._work_path = work_path
        self._text_encoding = None

    @staticmethod
    def check_installed_git():
        '''
        检查系统路径下安装的git
        '''
        git_path = Executable.get_location('git')
        if not git_path:
            raise GitNotInstalledError(_('Git not installed'))
        GitCmd.GIT_INSTALLED_PATH = git_path
        return git_path

    @classmethod
    def check_git(cls):
        '''
        优先检查系统路径下安装的git,如果未检测到则读取配置下的git路径
        '''
        # 只需全局检测一次git安装路径
        if strutils.is_none_empty(cls.GIT_INSTALLED_PATH):
            try:
                git_path = cls.check_installed_git()
            except GitNotInstalledError:
                logger.info('git not installed, load git path from application config')
                git_path = utils.profile_get(GITPATH_CONFIG_KEY)
                if strutils.is_none_empty(git_path):
                    raise GitNotInstalledError(_('Git no installed or not config installed path'))
                cls.GIT_INSTALLED_PATH = git_path

    @staticmethod
    def is_valid_git_tool(git_path):
        try:
            output = GitCmd(git_path=git_path).call_output('-v')
            if output is not None and output.find('git version ') != -1:
                return True
        except Exception as ex:
            utils.get_logger().error('get git version error:%s', str(ex))
        return False

    @property
    def work_path(self):
        return self._work_path

    def make_env(self):
        # 复制当前环境变量
        env = os.environ.copy()
        ask_pass_path = get_askpass_path()
        # 如果设置了 GIT_ASKPASS 环境变量，将调用该变量指定的程序。
        # 命令行会向程序提供适当的提示，并从其标准输出读取用户输入。
        env.update(dict(GIT_ASKPASS=ask_pass_path))
        return env

    def call(self, cmd: Union[str, list]):
        env = self.make_env()
        exectable = Executable(self.git_path, env=env)
        logger.debug('work path is %s', self._work_path)
        exitcode, output = exectable.exec_command_exit_output(cmd, cwd=self._work_path)
        return output, exitcode

    @staticmethod
    def replace_octal(match):
        # 将八进制数转换为字符
        return chr(int(match.group(1), 8))

    @staticmethod
    def bytes_to_str(content):
        default_locale_encoding = utils.get_default_locale_encoding()
        try:
            logger.debug('default locale encoding is:%s', default_locale_encoding)
            output = content.decode(default_locale_encoding)
            logger.debug('use default locale encoding %s decode bytes to str success', default_locale_encoding)
        except Exception as ex:
            logger.error("use encoding:%s decode bytes to str error:%s", default_locale_encoding, str(ex))
            output = content.decode(UTF8_FILE_ENCODING)
        return output

    def bytes_to_str_detect_encoding(self, content):
        # 命令行输出编码是一致的,只要检测出非ascii编码,无需重新检测编码
        if self._text_encoding is None or self._text_encoding == ASCII_FILE_ENCODING:
            content_encoding_result = fileutils.detect(content)
            logger.debug('detect content encoding is:%s', content_encoding_result)
            content_encoding = content_encoding_result['encoding']
            self._text_encoding = content_encoding
        if self._text_encoding is not None:
            output = content.decode(self._text_encoding)
        else:
            logger.error('could not detect content bytes encoding...')
            output = self.bytes_to_str(content)
        # git输出中文类似\345\211\257\346\234\254.py,其中\345表示八进制,其中有2个转义字符
        # 导致无法正确解码中文, 需要替换其中的一个转义字符, 然后重新解码
        if self.PATTERN.search(output):
            result = self.PATTERN.sub(self.replace_octal, output)
            raw_content = result.encode('raw_unicode_escape')
            if self._text_encoding == ASCII_FILE_ENCODING:
                raw_encoding = fileutils.detect(raw_content)['encoding']
                logger.info('find zhn character and detect encoding is %s', raw_encoding)
                self._text_encoding = raw_encoding
            output = raw_content.decode(self._text_encoding).strip().replace('"', "")
        return output

    def huge_output_call(self, command):
        exectable = Executable(self.git_path)
        file = exectable.exec_command_output_tempfile(
            command,
            cwd=self._work_path
        )
        for line in file:
            yield line
        file.close()

    def call_output(self, command):
        output, exitcode = self.call(command)
        if exitcode != 0:
            raise GitCommandError(output)
        return output

    def make_git_command(self, command):
        exectable = Executable(self.git_path)
        return exectable.combine_command(command)


class GitdocCmd(GitCmd):

    def __init__(self, doc):
        super().__init__(doc.GetPath())
        self._doc = doc
