# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

#
# The file was taken from eric 4.4.3 and adopted for codimension.
# Original copyright:
# Copyright (c) 2007 - 2010 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Collection of items which may appear in various tree views:
- project view
- filesystem view
- classes view
- functions view
"""

import os
import os.path
from ...qtimage import load_icon
from ...lib.images import empty_icon
from ...lib.pyqt import Qt

NoItemType = -1

DirectoryItemType = 1
FileItemType = 2
FolderItemType = 3
InvalidFolderItemType = 4
ProjectRootType = 5

EMPTY_ICON = empty_icon()


class TreeViewItem():
    """Common data structures for tree views items"""

    def __init__(self, parent, data):

        self.childItems = []
        self.childItemsSize = 0

        if isinstance(data, list):
            self.itemData = data
            self.itemDataSize = len(self.itemData)
        else:
            self.itemData = [data]
            self.itemDataSize = 1

        self.isLink = False
        self.parentItem = parent
        self.itemType = NoItemType
        self.icon = EMPTY_ICON
        self.populated = True
        self.lazyPopulation = False
        self.toolTip = ""
        self.path = None
        self.needVCSStatus = False

        self.vcsStatus = None   # VCSStatus instance, if present

    def isRoot(self):
        """True if it is the root item"""
        return self.parentItem is None

    def appendData(self, data):
        """Adds more data to the item"""
        if isinstance(data, list):
            self.itemData += data
            self.itemDataSize = len(self.itemData)
        else:
            self.itemData.append(data)
            self.itemDataSize += 1

    def setPath(self, path):
        """Sets the item path"""
        self.path = path

    def appendChild(self, child):
        """Adds a child to the item"""
        self.childItems.append(child)
        self.childItemsSize += 1
        self.populated = True

    def removeChild(self, child):
        """Removes the child"""
        self.childItems.remove(child)
        self.childItemsSize -= 1

    def removeChildren(self):
        """Removes all children"""
        self.childItems = []
        self.childItemsSize = 0

    def child(self, row):
        """Provides the child"""
        return self.childItems[row]

    def children(self):
        """Provides all the child items"""
        return self.childItems[:]

    def childCount(self):
        """Provides the number of child items"""
        # Optimization against len(self.childItems)
        return self.childItemsSize

    def columnCount(self):
        """Provides the number of available data items"""
        # Optimization against len(self.itemData)
        return self.itemDataSize

    def data(self, column=0):
        """Provides item data"""
        try:
            return self.itemData[column]
        except IndexError:
            return ''

    def setData(self, column, value):
        """Sets the new data"""
        try:
            self.itemData[column] = value
        except Exception:
            pass

    def parent(self):
        """Provides the reference to the parent item"""
        return self.parentItem

    def row(self):
        """Provides the row number of this item"""
        return self.parentItem.childItems.index(self)

    def type(self):
        """Provides the item type"""
        return self.itemType

    def getIcon(self):
        """Provides the items icon"""
        return self.icon

    def setIcon(self, icon):
        """Sets the icon"""
        self.icon = icon

    def lessThan(self, other, column, order):
        """Check, if the item is less than another"""
        try:
            return self.itemData[column] < other.itemData[column]
        except IndexError:
            return False

##    def getPath(self):
##        """Provides the file name or dir name depending on the item type"""
##        if self.itemType in [SysPathItemType, NoItemType]:
##            return ''
##
##        current = self
##
##        # The item could be used for G/F/C viewers where the file name is
##        # available in the second column
##        if self.path:
##            return self.path
##        if self.itemDataSize >= 2:
##            return self.itemData[1]
##
##        # Memorize if it is a directory item
##        isdir = current.itemType == DirectoryItemType
##        # skip till file or directory items
##        while True:
##            if current.itemType == NoItemType:
##                raise Exception("Internal error of getting tree view "
##                                "item path. Please inform the developers.")
##            if current.itemType in [FileItemType, DirectoryItemType,
##                                    SysPathItemType]:
##                break
##            current = current.parentItem
##
##        path = current.itemData[0]
##        while current.parentItem.itemType not in (NoItemType, SysPathItemType):
##            current = current.parentItem
##            path = os.path.sep + path
##            if current.itemData[0] != os.path.sep:    # root item
##                path = current.itemData[0] + path
##
##        path = os.path.normpath(path)
##        if isdir:
##            if not path.endswith(os.path.sep):
##                path += os.path.sep
##        return path
##
##    def getRealPath(self):
##        """
##        Provides the file name or dir name depending on the item type.
##        All the links except of the item itself are resolved.
##        """
##        if self.itemType in [SysPathItemType, NoItemType]:
##            return ''
##
##        current = self
##
##        # The item could be used for G/F/C viewers where the file name is
##        # available in the second column
##        if self.path:
##            return self.path
##        if self.itemDataSize >= 2:
##            return self.itemData[1]
##
##        # Memorize if it is a directory item
##        isdir = self.itemType == DirectoryItemType
##        # skip till file or directory items
##        while True:
##            if current.itemType == NoItemType:
##                raise Exception("Internal error of getting tree view "
##                                "item path. Please inform the developers.")
##            if current.itemType in [FileItemType, DirectoryItemType,
##                                    SysPathItemType]:
##                break
##            current = current.parentItem
##
##        haslinks = False
##        path = current.itemData[0]
##        while current.parentItem.itemType not in (NoItemType, SysPathItemType):
##            current = current.parentItem
##            if current.itemType == DirectoryItemType:
##                if current.isLink:
##                    haslinks = True
##            path = os.path.sep + path
##            if current.itemData[0] != os.path.sep:    # root item
##                path = current.itemData[0] + path
##
##        if haslinks:
##            if self.isLink:
##                path = os.path.realpath(os.path.dirname(path)) + \
##                    os.path.sep + self.itemData[0]
##            else:
##                path = os.path.realpath(path)
##
##        path = os.path.normpath(path)
##        if isdir:
##            if not path.endswith(os.path.sep):
##                path += os.path.sep
##        return path
##
##    def getQualifiedName(self):
##        """Provides the qualified item name"""
##        current = self
##        name = ""
##        while current is not None:
##            if current.itemType in [FunctionItemType, ClassItemType]:
##                namepart = current.data(0).split("(")[0]
##                if name != "":
##                    name = namepart + "." + name
##                else:
##                    name = namepart
##            current = current.parentItem
##        return name

    def getRowPath(self):
        """Provides the row path"""
        rowpath = []
        child = self
        current = self.parentItem
        while current is not None:
            for index in range(0, len(current.childItems)):
                if current.childItems[index] == child:
                    rowpath = [index] + rowpath
                    child = current
                    current = child.parentItem
                    break
            else:
                raise RuntimeError('item is already deleted or missing...')
        return rowpath

    def getDisplayDataPath(self):
        """Provides the diplayed path for the item"""
        result = []
        current = self
        while current.parentItem is not None:
            result.insert(0, (current.itemType, current.data(0)))
            current = current.parentItem
        return result


class TreeViewFolderItem(TreeViewItem):
    """Directory item"""

    def __init__(self, parent, folder):
        TreeViewItem.__init__(self, parent, folder)
        self.itemType = FolderItemType

        self.icon = None
        self.populated = False
        self.lazyPopulation = True
        self.isLink = False


class TreeViewDirectoryItem(TreeViewItem):
    """Directory item"""

    def __init__(self, parent, dinfo, full=True):

        self._dirname = os.path.abspath(str(dinfo))

        if full:
            dname = self._dirname
        else:
            dname = os.path.basename(self._dirname)

        TreeViewItem.__init__(self, parent, dname)

        self.itemType = DirectoryItemType

        self.icon = None
        self.populated = False
        self.lazyPopulation = True
        self.isLink = False
        self.updateStatus()

    def updateStatus(self):
        """Updates internal fields"""
        if os.path.exists(self._dirname):
            self.icon = load_icon('dirclosed.png')
            self.populated = False
            self.lazyPopulation = True

            if os.path.islink(self._dirname):
                self.isLink = True
                link_to = os.readlink(self._dirname)
                realpath = os.path.realpath(self._dirname)
                self.toolTip = "-> " + link_to + "  (" + realpath + ")"
                self.icon = load_icon('dirlink.png')
        else:
            self.icon = getIcon('dirbroken.png')
            self.populated = True
            self.lazyPopulation = False

            self.childItems = []
            self.childItemsSize = 0

    def lessThan(self, other, column, order):
        """Checks if the item is less than another"""
        if other.itemType == FileItemType:
            return order == Qt.AscendingOrder
        return TreeViewItem.lessThan(self, other, column, order)


class TreeViewFileItem(TreeViewItem):
    """file item"""

    def __init__(self, parent, path):
        path = str(path)
        TreeViewItem.__init__(self, parent, os.path.basename(path))
        self.itemType = FileItemType
        self.parsingErrors = False  # Used for python files only
        self.isLink = False

    @staticmethod
    def __broken_link_tooltip(path):
        """Provides the broken link tooltip"""
        link_to = os.readlink(path)
        realpath = os.path.realpath(path)
        return "Broken symlink -> " + link_to + " (" + realpath + ")"

    @staticmethod
    def __link_tooltip(path):
        """Provides the link tooltip"""
        link_to = os.readlink(path)
        realpath = os.path.realpath(path)
        return "-> " + link_to + "  (" + realpath + ")"

    def lessThan(self, other, column, order):
        """Checks if the item is less than another"""
        if other.itemType != FileItemType:
            return order == Qt.DescendingOrder

        sinit = self.data(0).startswith('__init__.py')
        oinit = other.data(0).startswith('__init__.py')
        if sinit and not oinit:
            return order == Qt.AscendingOrder
        if not sinit and oinit:
            return order == Qt.DescendingOrder
        return TreeViewItem.lessThan(self, other, column, order)

    def updateLinkStatus(self, path):
        """Called to update the status to/from broken link"""
        if not self.isLink:
            return

        self.fileType, self.icon, _ = getFileProperties(path)
        if 'broken-symlink' in self.fileType:
            self.toolTip = self.__broken_link_tooltip(path)
            return

        self.toolTip = self.__link_tooltip(path)
        self.icon = getIcon('filelink.png')
        self.fileType, _, _ = getFileProperties(os.path.realpath(path))
