from typing import cast
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintC0206Fixer(PylintFixer):
    '''
    规则说明:遍历字典使用dict.items方法来遍历字典
    '''

    def __init__(self):
        super().__init__('C0206', False)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.AssignName) and isinstance(node.parent, nodes.For):
            scope = cast(nodes.For, node.parent)
            iter_ = scope.iter
            target = scope.target
            target_name = target.as_string()
            body = scope.body
            iter_name = iter_.as_string()
            for node in body:
                loop_name = iter_name + "[%s]" % target_name
                if isinstance(node, nodes.Assign):
                    if node.value.as_string() == loop_name:
                        self.fix_node_text(iter_, iter_name + ".items()")
                        self.delete_text_line(msg.line)
                        self.fix_node_text(target, target_name + "," + node.targets[0].as_string())
                        return True
            ok, newname = self.ask_input_string(
                'Input dict value name',
                'Input loop name',
                initialvalue=''
            )
            if ok and newname != '':
                self.fix_node_text(iter_, iter_name + ".items()")
                self.fix_node_text(target, target_name + "," + newname)
                self.replace_variable_name_in_scope(scope, loop_name, newname)
                return True
        return False
