'''
Name:        c0116.py
Purpose:     补充模块/函数/类的文档字符串
Author:      wukan
Created:     2026-08-22
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import copy
from astroid import nodes
from ....pylint_fix import PylintFixer
from ....codeutils import DEFAULT_TAB_BLANKS
from ....multifixer import MultiOptionFixer


class PylintC0116Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明: 函数或方法缺少文档字符串说明
    '''

    def __init__(self):
        super().__init__('C0116', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='',
            descr="Please choose one docstring option",
            init_options=['simple docstring', 'detail docstring']
        )

    @classmethod
    def get_function_simple_string(cls, func_node):
        '''添加简短的函数文档字符串'''
        indent_blanks = DEFAULT_TAB_BLANKS + func_node.position.col_offset * ' '
        function_or_method_str = indent_blanks + cls.SINGLE_TRIPLE_QUOTE + cls.SINGLE_TRIPLE_QUOTE
        return function_or_method_str

    @classmethod
    def get_function_detail_string(cls, func_node):
        '''
        添加详细的函数/方法文档字符串,包括参数类型,返回类型等
        :param func_node:
        :type func_node: astroid.nodes
        :return: 返回文档字符串
        :rtype: str
        '''
        indent_blanks = DEFAULT_TAB_BLANKS + func_node.position.col_offset * ' '
        function_or_method_string = indent_blanks + cls.SINGLE_TRIPLE_QUOTE
        function_or_method_string += "\n"
        function_or_method_string += "\n"
        args = copy.copy(func_node.args.args)
        if isinstance(func_node.parent, nodes.ClassDef):
            if args[0].as_string() == "self" or args[0].as_string() == "cls":
                args.remove(args[0])
        for arg in args:
            arg_name_str = f":param {arg.name}:"
            function_or_method_string += indent_blanks + arg_name_str
            function_or_method_string += "\n"
            arg_type_str = f":type {arg.name}:"
            function_or_method_string += indent_blanks + arg_type_str
            function_or_method_string += "\n"
        function_or_method_string += indent_blanks + ":return:"
        function_or_method_string += "\n"
        function_or_method_string += indent_blanks + ":rtype:"
        function_or_method_string += "\n"

        function_or_method_string += indent_blanks + cls.SINGLE_TRIPLE_QUOTE
        function_or_method_string += "\n"
        return function_or_method_string

    @classmethod
    def get_function_comments_doc_string(cls, func_node, top_comments):
        '''将函数上方的注释转换为文档字符串'''
        indent_blanks = DEFAULT_TAB_BLANKS + func_node.position.col_offset * ' '
        if 1 == len(top_comments):
            function_or_method_string = indent_blanks + cls.SINGLE_TRIPLE_QUOTE + \
                top_comments[0].strip().lstrip('#') + cls.SINGLE_TRIPLE_QUOTE
        else:
            function_or_method_string = indent_blanks + cls.SINGLE_TRIPLE_QUOTE
            function_or_method_string += "\n"
            for comment_text in top_comments:
                function_or_method_string += indent_blanks + comment_text.strip().lstrip('#')
                function_or_method_string += "\n"
            function_or_method_string += indent_blanks + cls.SINGLE_TRIPLE_QUOTE
            function_or_method_string += "\n"
        return function_or_method_string

    def fix_message(self, msg):
        scope_node = self.find_msg_node(msg)
        function_or_method_string = ''
        if isinstance(scope_node, nodes.Name) and isinstance(scope_node.parent, nodes.FunctionDef):
            func_node = scope_node.parent
            if isinstance(func_node.parent, nodes.ClassDef):
                self.set_title("Fix method docstring")
            else:
                self.set_title("Fix function docstring")
            func_top_comment_lines = self.get_function_top_comment_lines(func_node)
            func_top_comments = []
            for func_top_comment_line in func_top_comment_lines[::-1]:
                func_top_comments.append(self.get_line_text(func_top_comment_line))
            extra_option_name = 'replace docstring with top comments'
            if func_top_comments and extra_option_name not in self.options:
                self.options.append(extra_option_name)
            self.get_selection()
            if 0 == self.selection:
                function_or_method_string = self.get_function_simple_string(func_node)
            if 1 == self.selection:
                function_or_method_string = self.get_function_detail_string(func_node)
            if 2 == self.selection:
                function_or_method_string = self.get_function_comments_doc_string(
                    func_node,
                    func_top_comments
                )
            self.add_range_text(func_node.position.lineno + 1, 0, function_or_method_string + "\n")
            if func_top_comments and 2 == self.selection:
                for func_top_comment_line in func_top_comment_lines:
                    self.delete_text_line(func_top_comment_line)
            return True
        return False


class PylintC0115Fixer(PylintFixer):
    '''
    规则说明: 类缺少文档字符串说明
    '''

    def __init__(self):
        super().__init__('C0115', False)

    def fix_message(self, msg):
        scope_node = self.find_msg_node(msg)
        if isinstance(scope_node, nodes.Name) and isinstance(scope_node.parent, nodes.ClassDef):
            class_node = scope_node.parent
            class_doc_string = PylintC0116Fixer.get_function_simple_string(class_node)
            self.add_range_text(class_node.position.lineno + 1, 0, class_doc_string + "\n")
            return True
        return False
