import re
from astroid import nodes
from ....pylint_fix import PylintFixer
from ....codeutils import get_node_col_offset_blanks
from ....multifixer import MultiOptionFixer


class PylintW0612Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:未使用的变量
    '''

    def __init__(self):
        super().__init__('W0612', True)
        MultiOptionFixer.__init__(self, 1, init_options=[
            "Delete left expression", "Delete total expression"
        ]
        )

    @staticmethod
    def get_node_scope(node):
        parent_node = node
        while parent_node:
            if hasattr(parent_node, 'body') and not isinstance(parent_node, nodes.Tuple):
                return parent_node
            parent_node = parent_node.parent
        return None

    def fix_unused_name_tuple(self, tuplenode, unused_name):
        for elt in tuplenode.elts:
            if elt.as_string() == unused_name:
                fixstr = "_" + unused_name
                self.fix_node_text(elt, fixstr)
                return True
        return False

    def get_fix_exception(self, node):
        fixstr = get_node_col_offset_blanks(node) + 'except %s:' % node.type.as_string()
        self.replace_line_text(node.lineno, fixstr)
        return True

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r"Unused variable '(\w+)' \(unused-variable\)", msg.msg)
        unused_name = res.groups()[0]
        parent_scope = self.get_node_scope(node)
        if isinstance(parent_scope, nodes.For) and (
            isinstance(parent_scope.iter, nodes.Call) and (
                isinstance(parent_scope.iter.func, nodes.Name) and parent_scope.iter.func.name == "enumerate"
            )
        ):
            loop_index, loop_name = parent_scope.target.elts
            if node != loop_index:
                return False
            assert unused_name == loop_index.as_string()
            arg_names = ",".join([arg.as_string() for arg in parent_scope.iter.args])
            self.fix_node_text(parent_scope.iter, arg_names)
            self.fix_node_text(parent_scope.target, loop_name.as_string())
            return True
        if isinstance(node, nodes.AssignName) and (
            isinstance(node.parent, nodes.ExceptHandler) and node.name == unused_name
        ):
            for except_body in node.parent.body:
                if isinstance(except_body, nodes.Raise):
                    return False
            return self.get_fix_exception(node.parent)
        if isinstance(node, nodes.AssignName) and isinstance(node.parent, nodes.Tuple):
            return self.fix_unused_name_tuple(node.parent, unused_name)
        # 下面的修复操作不支持自动修复
        if self.fix_only_autofix():
            return False
        if isinstance(node, nodes.AssignName) and isinstance(node.parent, nodes.Assign):
            pnode = node.parent
            left = pnode.targets[0]
            if isinstance(left, nodes.AssignName):
                if left.as_string() == unused_name:
                    self.set_title("Delete unused variable")
                    self.set_description("Please choose one delete option")
                    self.get_selection()
                    if self.selection == 0:
                        value_str = pnode.value.as_string()
                        self.fix_node_text(pnode, value_str)
                        return True
                    if self.selection == 1:
                        return self.delete_node(pnode, delete_node_line=True, check_deleteable=True)
        return False
