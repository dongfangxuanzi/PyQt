# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""Text editor tab widget"""
from ..lib.pyqt import QFrame, QVBoxLayout, pyqtSignal
from ..bars.menubar import NewQMenu
from .texteditor import TextEditor


class TextFrame(QFrame):
    """Plain text editor tab widget"""

    SIG_EDIT_TEXT_POPUP_MENU = pyqtSignal(NewQMenu, TextEditor)

    def __init__(self, parent, view, text_class):
        super().__init__(parent)
        self.__editor = text_class(self, view)
        self.__create_layout()

    def shouldAcceptFocus(self):
        """True if it can accept the focus"""
        return True

    def setFocus(self):
        """Overridden setFocus"""
        self.__editor.setFocus()

    def getEditor(self):
        """Provides the editor widget"""
        return self.__editor

    def __create_layout(self):
        """Creates the toolbar and layout"""
        vlayout = QVBoxLayout()
        vlayout.setContentsMargins(0, 0, 0, 0)
        vlayout.setSpacing(0)
        vlayout.addWidget(self.__editor)
        self.setLayout(vlayout)
