import abc
from .. import get_app, _
from .escape import EscapeView
from .. import menuitems


class NocreateView(abc.ABC, EscapeView):
    '''
       只能查看不能写入的公共视图
    '''
    # ----------------------------------------------------------------------------
    # Overridden methods
    # ----------------------------------------------------------------------------

    def set_pos(self):
        '''
            视图不在状态栏显示行列号
        '''
        get_app().MainFrame.sbPos.setText(_('Pos') + ': n/a')
        get_app().MainFrame.sbLine.setText(_('Line') + ': n/a')

    def set_encoding(self):
        get_app().MainFrame.sbEncoding.setText('   ')

    def set_eol(self):
        get_app().MainFrame.sbEol.setText(' ')

    def GotoLine(self, line):
        '''
            视图不能跳转到行,实现一个空方法
        '''

    def UpdateUI(self, command_id):
        '''
        允许关闭菜单有效
        '''
        if command_id in [
            menuitems.ID_CLOSE,
            menuitems.ID_CLOSE_ALL
        ]:
            return True
        return super().UpdateUI(command_id)

    def OnClose(self, deleteWindow=True):
        self.Activate(False)
        if deleteWindow and self.GetFrame():
            self.GetFrame().Destroy()
        return True
