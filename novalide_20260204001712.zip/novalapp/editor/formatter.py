import datetime
import os
from .. import _, get_app
from ..lib.pyqt import QFileDialog
from ..util import fileutils, exceptions, ui_utils
from ..syntax.syntax import SyntaxThemeManager
from ..project.variables import GetProjectVariableManager
from .. import constants


def classifyws(s, tabwidth):
    raw = effective = 0
    for ch in s:
        if ch == " ":
            raw = raw + 1
            effective = effective + 1
        elif ch == "\t":
            raw = raw + 1
            effective = (effective // tabwidth + 1) * tabwidth
        else:
            break
    return raw, effective


class TextFormatter:
    """纯文本操作"""

    def InsertDatatime(self):
        self.AddText(str(datetime.datetime.now().date()))

    def AddText(self, chars, pos=None):
        self.GetCtrl().addtext(chars, pos)

    @exceptions.catch_exception
    def InsertFileContent(self):
        path, _filetype = QFileDialog.getOpenFileName(
            self.GetFrame(),
            _('Open File'),
            None,
            _("All Files (*.*)")
        )
        if not path:
            return
        encoding = fileutils.detect_file_encoding(fileutils.opj(path))
        file_content = fileutils.get_file_content(path, True, encoding)
        self.AddText(file_content)

    def UpperCase(self):
        self.GetCtrl().UpperCase()

    def LowerCase(self):
        self.GetCtrl().LowerCase()

    def FirstUppercase(self):
        ctrl = self.GetCtrl()
        selected_text = ctrl.selectedText()
        if not selected_text:
            return
        lower_text = selected_text.lower()
        convert_text = lower_text[0].upper() + lower_text[1:]
        ctrl.replaceSelectedText(convert_text)

    def get_lineno(self, line):
        if line == -1:
            line = self.GetCtrl().get_current_line()
        return line

    def get_region(self, startline, startindex, endline, endindex):
        chars = self.GetCtrl().get_chars(startline, startindex, endline, endindex)
        lines = chars.split("\n")
        head = self.GetCtrl().position_from_linecol(startline, startindex)
        tail = self.GetCtrl().position_from_linecol(endline, endindex)
        return head, tail, chars, lines

    def set_region(self, head, tail, chars, lines, selrep=True):
        newchars = "\n".join(lines)
        if newchars == chars:
            # 没有实际改变区域内容,发出系统报警声音
            get_app().beep()
            return
        # 将下面2步操作作为一个整体,在执行回退时会整体回退操作
        self.GetCtrl().beginUndoAction()
        self.GetCtrl().delete_target(head, tail)
        self.GetCtrl().insert_text(head, newchars)
        self.GetCtrl().endUndoAction()
        if selrep:
            self.GetCtrl().set_sel(head, tail + len(newchars) - len(chars) - 1)

    def copy_line(self, line=-1):
        lineno = self.get_lineno(line)
        line_text = self.GetCtrl().get_line(lineno)
        ui_utils.copytoclipboard(line_text)

    def delete_line(self, line=-1):
        lineno = self.get_lineno(line)
        self.GetCtrl().delete_target(
            self.GetCtrl().position_from_linecol(lineno),
            self.GetCtrl().position_from_linecol(lineno + 1)
        )

    def replace_line(self, line, newchars):
        linestr = self.GetCtrl()._encodeString(self.GetCtrl().get_line_text(line))
        head, tail, chars, lines = self.get_region(line, 0, line, len(linestr))
        self.set_region(head, tail, chars, newchars.split("\n"), selrep=False)

    def insert_line(self, line, linetext):
        pos = self.GetCtrl().position_from_linecol(line)
        self.AddText(linetext, pos)

    def duplicate_line(self, line=-1):
        lineno = self.get_lineno(line)
        line_text = self.GetCtrl().get_line(lineno)
        self.insert_line(lineno + 1, line_text)

    def cut_line(self, line=-1):
        self.copy_line(line)
        self.delete_line()

    def replace_eol(self, line_end):
        '''
            替换换行符
        '''
        value = self.GetCtrl().text()
        replaced = False
        new_lines = []
        for line in value.splitlines(True):
            if line.endswith(constants.CRLF):
                if line_end == constants.CRLF:
                    new_lines.append(line)
                else:
                    new_line = line[0:-len(constants.CRLF)] + line_end
                    new_lines.append(new_line)
                    replaced = True
            elif line.endswith(constants.LF):
                if line_end == constants.LF:
                    new_lines.append(line)
                else:
                    new_line = line[0:-len(constants.LF)] + line_end
                    new_lines.append(new_line)
                    replaced = True
            elif line.endswith(constants.CR):
                if line_end == constants.CR:
                    new_lines.append(line)
                else:
                    new_line = line[0:-len(constants.CR)] + line_end
                    new_lines.append(new_line)
                    replaced = True
            else:
                new_lines.append(line)
        if not replaced:
            return
        # 先清空所有文本
        self.GetCtrl().beginUndoAction()
        self.GetCtrl().clearall()
        # 再插入所有新文本,是文本处于修改状态
        self.GetCtrl().insert_text(0, ''.join(new_lines))
        self.GetCtrl().endUndoAction()


class CodeFormatter:
    '''
        代码文件操作
    '''

    def InsertCommentTemplate(self, insert_line=0):
        file_name = os.path.basename(self.GetDocument().GetFilename())
        now_time = datetime.datetime.now()
        langid = self.GetLangId()
        lexer = SyntaxThemeManager().manager().GetLexer(langid)
        comment_template = lexer.GetCommentTemplate()
        if comment_template is not None:
            variable_manager = GetProjectVariableManager()
            comment_template_content = comment_template.format(
                File=file_name,
                Author=variable_manager.GetVariable('USER'),
                Date=now_time.date(),
                Year=now_time.date().year,
                Licence=variable_manager.GetVariable('Licence')
            )
            self.GetCtrl().GotoPos(insert_line, 0)
            self.AddText(comment_template_content)

    def get_selection_range(self):
        startline, startindex, endline, endindex = self.GetCtrl().get_selection()
        startindex = 0
        endindex = len(self.GetCtrl()._encodeString(
            self.GetCtrl().text(endline)))
        head, tail, chars, lines = self.get_region(
            startline, startindex, endline, endindex)
        return head, tail, chars, lines

    def comment_region(self):
        lexer = self.GetCtrl().GetLangLexer()
        comment_pattern_list = lexer.GetDefaultCommentPattern()
        if 0 == len(comment_pattern_list):
            return
        comment_block = False
        if len(comment_pattern_list) > 1:
            comment_block = True
        head, tail, chars, lines = self.get_selection_range()
        for pos in range(len(lines) - 1):
            line = lines[pos]
            if not comment_block:
                comment_start_text = comment_pattern_list[0] * 2
                if not line.startswith(comment_start_text):
                    lines[pos] = comment_start_text + line
            else:
                if pos == 0:
                    lines[pos] = comment_pattern_list[0] + line
                if pos == (len(lines) - 2):
                    lines[pos] = lines[pos] + comment_pattern_list[1]
        self.set_region(head, tail, chars, lines)

    def uncomment_region(self):
        lexer = self.GetCtrl().GetLangLexer()
        comment_pattern_list = lexer.GetDefaultCommentPattern()
        if 0 == len(comment_pattern_list):
            return
        comment_block = False
        if len(comment_pattern_list) > 1:
            comment_block = True
        head, tail, chars, lines = self.get_selection_range()
        # 注释符号的长度
        comment_char_length = len(comment_pattern_list[0])
        for pos in range(len(lines)):
            line = lines[pos]
            if not line:
                continue
            if not comment_block:
                # 起始2个注释符
                if line[:2 * comment_char_length] == comment_pattern_list[0] * 2:
                    line = line[2 * comment_char_length:]
                # 起始1个注释符
                elif line[:comment_char_length] == comment_pattern_list[0]:
                    line = line[comment_char_length:]
            lines[pos] = line
        self.set_region(head, tail, chars, lines)

    def tab(self):
        self.GetCtrl().tab()
        self.set_pos()

    def backtab(self):
        self.GetCtrl().backtab()
        self.set_pos()

    def tabify_region(self):
        '''
            空格转制表符
        '''
        head, tail, chars, lines = self.get_selection_range()
        tabwidth = constants.DEFAULT_TAB_WIDTH
        for pos in range(len(lines)):
            line = lines[pos]
            if line:
                raw, effective = classifyws(line, tabwidth)
                ntabs, nspaces = divmod(effective, tabwidth)
                lines[pos] = '\t' * ntabs + ' ' * nspaces + line[raw:]
        self.set_region(head, tail, chars, lines)

    def untabify_region(self):
        '''
           制表符转空格
        '''
        head, tail, chars, lines = self.get_selection_range()
        tabwidth = constants.DEFAULT_TAB_WIDTH
        for pos in range(len(lines)):
            lines[pos] = lines[pos].expandtabs(tabwidth)
        self.set_region(head, tail, chars, lines)

    def do_rstrip(self):
        '''
            清除选中范围内所有行尾的空白字符
        '''
        text_ctrl = self.GetCtrl()
        head, tail, _, _ = self.get_selection_range()
        start_line = text_ctrl.lineIndexFromPosition(head)[0]
        end_line = text_ctrl.lineIndexFromPosition(tail)[0]
        for cur in range(start_line, end_line):
            self.do_rstrip_line(cur)

    def do_rstrip_line(self, line):
        '''
            清除单行尾的空白字符
        '''
        text_ctrl = self.GetCtrl()
        # 获取不含换行符的行文本
        txt = text_ctrl.get_line_text(line)
        raw = len(text_ctrl._encodeString(txt))
        cut = len(text_ctrl._encodeString(txt.rstrip()))
        # Since text.delete() marks file as changed, even if not,
        # only call it when needed to actually delete something.
        if cut < raw:
            target_start = text_ctrl.position_from_linecol(line, cut)
            target_end = text_ctrl.position_from_linecol(line, raw)
            text_ctrl.delete_target(target_start, target_end)

    def expandtabs(self, chars, indent=constants.DEFAULT_TAB_INDENTATION_WIDTH):
        '''
            将字符串里面的制表符替换为几个空白字符
            indent:制表符宽度,相当于几个空白字符
        '''
        return chars.expandtabs(indent)
