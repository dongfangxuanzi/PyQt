# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

#
# The file was taken from eric 4.4.3 and adopted for codimension.
# Original copyright:
# Copyright (c) 2007 - 2010 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""The real main widget - tab bar with editors"""
import os.path
import os
import re
from .. import _, newid
from .. import get_app
from .. import constants, globalkeys
from ..lib.pyqt import (
    Qt,
    pyqtSignal,
    QTabWidget,
    QMessageBox,
    QMenu,
    QShortcut,
    QTabBar,
    QAction,
    QCursor
)
from ..lib.qsci import QsciScintilla
from ..lib.docmanager import DOC_SILENT
from ..qtimage import load_icon
from ..util import ui_utils, utils, fileutils, strutils, pathutils
from .. import menuitems
from ..bars.menubar import NewQMenu, find_menu, MenuItem, create_action_group, MenubarMixin
from ..findrep import findui, findindir
from .textview import TextView
from .texteditor import TextEditor
from ..widgets import simpledialog
from .startup.startpage import show_startup_page
from ..plugins.update import CheckAppupdateInfo
from ..plugin.pluginupdate import check_pluign_update
from . import docposition
from .codeview import CodeView


class ClickableTabBar(QTabBar):
    """Intercepts clicking on the toolbar"""
    sigCurrentTabClicked = pyqtSignal()
    sigCurrentTabDoubleClicked = pyqtSignal()

    def __init__(self, parent):
        super().__init__(parent)

    def mousePressEvent(self, event):
        """Intercepts clicking on the toolbar and emits a signal.
        It is used to transfer focus to the currently active tab editor.
        """
        tabbar_point = self.mapTo(self, event.pos())
        if self.tabAt(tabbar_point) == self.currentIndex():
            self.sigCurrentTabClicked.emit()
        QTabBar.mousePressEvent(self, event)

    def mouseDoubleClickEvent(self, event):
        tabbar_point = self.mapTo(self, event.pos())
        if self.tabAt(tabbar_point) == self.currentIndex():
            self.sigCurrentTabDoubleClicked.emit()
        QTabBar.mouseDoubleClickEvent(self, event)

    def focusInEvent(self, event):
        """Passes focus to the current tab"""
        del event   # unused argument
        self.parent().setFocus()


class EditorNotebook(QTabWidget):
    """Tab bar with editors"""
    sigTabRunChanged = pyqtSignal(bool)
    sigPluginContextMenuAdded = pyqtSignal(QMenu, int)
    sigPluginContextMenuRemoved = pyqtSignal(QMenu, int)
    sigTabClosed = pyqtSignal(str)  # Emitted right before the tab is deleted
    sigFileUpdated = pyqtSignal(str, str)
    SIG_DOWNLOAD_ERROR = pyqtSignal(str)
    SIG_DOWNLOAD_SUCCESS = pyqtSignal(str)
    sigFileTypeChanged = pyqtSignal(str, str, str)
    sigAppUpdateVersion = pyqtSignal(dict)
    sigPluginUpdateVersion = pyqtSignal(dict)

    def __init__(self, parent):
        super().__init__(parent)
        parent.em = self

        self.setTabBar(ClickableTabBar(self))
        self.setMovable(True)
        # 新建模块的快捷键
        self.new_module_shortcut = MenubarMixin.KEY_BINDER.GetBinding(
            menuitems.ID_NEW_MODULE)
        self._current_document = None
        self.__mainwindow = parent
        self._is_maximized = False
        # Auxiliary widgets - they are created in the main window
        self._tabs_menu = None
        self.update_tabs_option()
        self.__install_actions()
        self.updateStatusBar()
        self.tabCloseRequested.connect(self.__on_close_request)
        self.currentChanged.connect(self.__currentChanged)

        # 标签页右键弹出菜单
        self.tabBar().setContextMenuPolicy(Qt.CustomContextMenu)
        self.tabBar().customContextMenuRequested.connect(self.__show_tabcontext_menu)
        self.el_group = create_action_group(self)
        self.sigAppUpdateVersion.connect(self.update_app_version)
        self.sigPluginUpdateVersion.connect(self.update_plugin_version)
        self.SIG_DOWNLOAD_ERROR.connect(self.download_error)
        self.SIG_DOWNLOAD_SUCCESS.connect(self.download_succ)
        self.tabBar().sigCurrentTabDoubleClicked.connect(self.toogle_maximized_editor)

    def create_startup_page(self):
        '''
            创建起始页
        '''
        show_startup_page(self)

    def dragEnterEvent(self, e):
        filenames = e.mimeData().text().splitlines()
        for filename in filenames:
            if utils.is_windows():
                match = re.match('^file:///[a-zA-Z]:.*$', filename)
                if match:
                    filepath = filename.replace('file:///', '', 1)
                else:
                    utils.get_logger().debug('"%s" is not a valid filename', filename)
                    continue
            else:
                match = re.match('^(/[^/ ]*)+/?$', filename)
                if match:
                    filepath = filename
                else:
                    utils.get_logger().debug('"%s" is not a valid filename', filename)
                    continue
            filepath = os.path.normpath(filepath)
            try:
                get_app().GetDocumentManager().CreateDocument(filepath, DOC_SILENT)
                e.accept()
            except Exception as ex:
                msgtitle = get_app().GetAppName()
                if not msgtitle:
                    msgtitle = _("File Error")
                QMessageBox.critical(
                    self,
                    msgtitle,
                    _("Could not open '%s':  %s") % (
                        fileutils.get_filename_from_path(filepath), ex)
                )
            e.ignore()

    def create_tab_menu(self, tab_index):
        """
        Handles right clicks for the notebook, enabling users to either close
        a tab or select from the available documents if the user clicks on the
        notebook's white space.
        """
        if self._tabs_menu is not None:
            self._tabs_menu.destroy()
        self._tabs_menu = NewQMenu(self)
        if tab_index > -1:
            self._current_document = self.GetDocumentFromPageIndex(tab_index)
            view = self._current_document.GetFirstView()
            get_app().GetDocumentManager().ActivateView(view)
            file_menu = find_menu(_("&File"), get_app().Menubar)
            if isinstance(view, TextView):
                menu_item = self._tabs_menu.Append(
                    menuitems.ID_NEW_MODULE,
                    _("&New module"),
                    self.NewModule,
                    load_icon("new.png"),
                    accelerator=self.new_module_shortcut
                )
                menu_item = file_menu.FindMenuItem(menuitems.ID_SAVE)
                assert menu_item is not None
                self._tabs_menu.AppendItem(menu_item)

                menu_item = file_menu.FindMenuItem(menuitems.ID_SAVEAS)
                assert menu_item is not None
                self._tabs_menu.AppendItem(menu_item)

            menu_item = file_menu.FindMenuItem(menuitems.ID_CLOSE)
            assert menu_item is not None
            self._tabs_menu.AppendItem(menu_item)

            menu_item = file_menu.FindMenuItem(menuitems.ID_CLOSE_ALL)
            assert menu_item is not None
            self._tabs_menu.AppendItem(menu_item)

            if self.count() > 1:
                item_name = _(
                    "&Close all but \"%s\"") % self._current_document.GetPrintableName()
                menu_item = self._tabs_menu.Append(
                    menuitems.ID_CLOSE_ALL_WITHOUT,
                    item_name,
                    self.closeall_without_doc
                )
                tabs_submenu = NewQMenu(_("Select tab"))
                for tab_index in range(self.count()):
                    widget = self.widget(tab_index)
                    tab_doc = widget.GetView().GetDocument()
                    if tab_doc == self._current_document:
                        continue

                    def open_index_tab(e, index=tab_index):
                        '''
                            e为triggered信号函数的默认参数,添加一个默认参数为文档索引序号,可以保证是连续值
                        '''
                        self.activateTab(index)

                    filename = self.tabText(tab_index)
                    template = tab_doc.GetDocumentTemplate()
                    open_index_action = QAction(template.GetIcon(), filename)
                    open_index_action.triggered.connect(open_index_tab)
                    item = MenuItem(newid(), open_index_action,
                                    None, self._tabs_menu)
                    tabs_submenu.AppendItem(item)
                self._tabs_menu.AppendMenu(newid(), tabs_submenu)
            self._tabs_menu.add_separator()
            if os.path.isabs(self._current_document.GetFilename()):
                menu_item = self._tabs_menu.Append(
                    menuitems.ID_OPEN_DOCUMENT_DIRECTORY,
                    _("Open path in &explorer"),
                    lambda: self.openpathinexplorer(self._current_document)
                )
                menu_item = self._tabs_menu.Append(
                    menuitems.ID_OPEN_TERMINAL_DIRECTORY,
                    _("Open path in &terminator"),
                    lambda: self.openpathinterminator(self._current_document)
                )
                self._tabs_menu.add_separator()
            menu_item = self._tabs_menu.Append(
                menuitems.ID_COPY_DOCUMENT_PATH,
                _("Copy full &path to clipboard"),
                lambda: self.copyfilepath(self._current_document)
            )
            menu_item = self._tabs_menu.Append(
                menuitems.ID_COPY_DOCUMENT_NAME,
                _("Copy &file name to clipboard"),
                lambda: self.copyfilename(self._current_document)
            )
            if isinstance(view, TextView) and view.GetLangId() == get_app().GetDefaultLangId():
                menu_item = self._tabs_menu.Append(
                    menuitems.ID_COPY_MODULE_NAME,
                    _("Copy &module name to clipboard"),
                    lambda: self.copymodulename(self._current_document)
                )

            menu_item = self._tabs_menu.Append(
                menuitems.ID_RELOAD_DOCUMENT,
                _("Reload"),
                lambda: self.reload_document(self._current_document),
                get_app().GetImage("reload_doc.png")
            )
        if not get_app().MainFrame.isFullScreen():
            self._tabs_menu.add_separator()
            self._tabs_menu.Append(
                menuitems.ID_MAXIMIZE_EDITOR_WINDOW,
                _("Maximize Editor Window"),
                self.MaximizeEditor,
                get_app().GetImage("maximize_editor.png")
            )
            self._tabs_menu.Append(
                menuitems.ID_RESTORE_EDITOR_WINDOW,
                _("Restore Editor Window"),
                self.RestoreEditor,
                get_app().GetImage("restore_editor.png")
            )

    def MaximizeEditor(self):
        """Triggered when F11 is pressed"""
        if self._is_maximized:
            return
        get_app().MainFrame.SavePerspective()
        get_app().MainFrame.hideall()
        self._is_maximized = True

    def RestoreEditor(self):
        if not self._is_maximized:
            return
        get_app().MainFrame.LoadPerspective()
        self._is_maximized = False

    def setFocus(self):
        """Explicitly sets focus to the current widget"""
        widget = self.currentWidget()
        if widget is not None:
            widget.setFocus()

    def activateTab(self, index):
        """Activates the given tab"""
        self.setCurrentIndex(index)
        self.currentWidget().setFocus()

    def get_find_str(self):
        '''
            文本查找字符串首选用户选中的文本,其次从配置表中读取上次用户查找的文本
        '''
        editor = self.get_current_editor()
        findstr = ''
        if editor is not None and isinstance(editor, TextEditor):
            findstr = editor.selectedText()
        return findstr

    def FindIndir(self):
        findstr = self.get_find_str()
        findindir.show_findindir_dialog(self, findstr)

    def get_current_view(self):
        current_tab_widget = self.currentWidget()
        if current_tab_widget is None:
            return None
        return current_tab_widget.GetView()

    def get_current_editor(self):
        current_view = self.get_current_view()
        if current_view is None:
            return None
        return current_view.GetCtrl()

    def __on_find(self):
        """Triggered when Ctrl+F is received"""
        current_view = get_app().GetDocumentManager().GetCurrentView()
        current_view.DoFind()

    def __on_replace(self):
        """Triggered when Ctrl+R is received"""
        findui.show_findreplace_dialog(
            self,
            True,
            self.get_current_editor().selectedText()
        )

    def on_goto(self):
        """Triggered when Ctrl+G is received"""
        textview = self.get_current_view()
        if textview is None or not hasattr(textview, 'GotoLine'):
            return
        textctrl = textview.GetCtrl()
        current_line = textctrl.get_current_line()
        line_count = textctrl.get_line_count()
        ok, lineno = simpledialog.askinteger(
            _("Go to Line"),
            _("Enter line number to go to:(1-%d)") % line_count,
            default_int=current_line + 1,
            maxnum=line_count,
            master=textctrl
        )
        if ok:
            textview.GotoLine(lineno)

    def FindInfile(self):
        """triggered when Ctrl+. is received"""
        findindir.show_findinfile_dialog(self.get_current_editor())

    def FindInproject(self):
        """Triggered when Ctrl+, is received"""
        findstr = self.get_find_str()
        findindir.show_findinproject_dialog(findstr, self)

    def updateStatusBar(self):
        """Updates the status bar values"""
        currentwidget = self.currentWidget()
        if currentwidget is None:
            return
        mainwindow = self.__mainwindow
        current_view = currentwidget.GetView()
        # 设置当前视图焦点
        current_view.SetFocus()
        get_app().GetDocumentManager().ActivateView(current_view)
        document = current_view.GetDocument()
        document_template = document.GetDocumentTemplate()
        mainwindow.sbLanguage.setText(document_template.GetDescription())
        current_view.set_pos()
        current_view.set_encoding()
        fname = document.GetFilename()
        if fname:
            mainwindow.sbFile.setPath(_("File") + ": " + fname)
        else:
            mainwindow.sbFile.setPath('File: n/a')
        current_view.set_eol()
        get_app().MainFrame.UpdateToolbar()

    def get_tab_index(self, frame):
        for index in range(self.count()):
            widget = self.widget(index)
            if widget == frame:
                return index
        return -1

    def getWidgetByIndex(self, index):
        """Provides the widget for the given index on None"""
        if index >= self.count():
            return None
        return self.widget(index)

    def closeall_without_doc(self):
        self.__closeall_without_doc()

    def closeall_doc(self):
        self.__closeall_without_doc(True)

    def GetDocumentFromPageIndex(self, index):
        if index > -1:
            view_frame = self.widget(index)
            view = view_frame.GetView()
            return view.GetDocument()
        return None

    @ui_utils.update_toolbar
    def NewModule(self):
        get_app().new_module()

    def openpathinexplorer(self, document):
        pathutils.safe_open_file_directory(document.GetFilename())

    def openpathinterminator(self, document):
        get_app().open_terminator(document.GetFilename())

    def copyfilepath(self, document):
        ui_utils.copytoclipboard(document.GetFilename())

    def copyfilename(self, document):
        ui_utils.copytoclipboard(os.path.basename(document.GetFilename()))

    def reload_document(self, document):
        document.reload()

    def open_documents(self):
        docs = []
        for index in range(self.count()):
            view_frame = self.widget(index)
            view = view_frame.GetView()
            if isinstance(view, TextView):
                docs.append(view.GetDocument())
        return docs

    def open_code_documents(self):
        docs = []
        for index in range(self.count()):
            view_frame = self.widget(index)
            view = view_frame.GetView()
            if isinstance(view, CodeView):
                docs.append(view.GetDocument())
        return docs

    def copymodulename(self, document):
        ui_utils.copytoclipboard(
            strutils.get_filename_without_ext(document.GetFilename())
        )

    def init_commands(self):
        edits_menu = find_menu(_("&Edit"), get_app().Menubar)
        get_app().AddDefaultCommand(
            menuitems.ID_FIND,
            edits_menu,
            _("&Find..."),
            self.__on_find,
            image="toolbar/find.png",
            include_in_toolbar=True
        )
        get_app().AddDefaultCommand(menuitems.ID_REPLACE,
                                    edits_menu, _("R&eplace..."), self.__on_replace)
        get_app().AddDefaultCommand(menuitems.ID_GOTO_LINE, edits_menu,
                                    _("&Go to Line..."), self.on_goto, image="gotoline.png")
        get_app().AddDefaultCommand(menuitems.ID_FINDFILE,
                                    edits_menu, _("Find in File..."), self.FindInfile)
        get_app().AddCommand(
            menuitems.ID_FINDALL,
            edits_menu,
            _("Find in Project..."),
            self.FindInproject,
            tester=lambda: get_app().MainFrame.projectview.GetCurrentProject() is not None
        )
        get_app().AddCommand(
            menuitems.ID_FINDDIR,
            edits_menu,
            _("Find in Directory..."),
            self.FindIndir,
            image="findindir.png",
            add_separator=True
        )

        insert_menu = NewQMenu(_("Insert"))
        edits_menu.AppendMenu(menuitems.ID_INSERT, insert_menu)
        get_app().AddDefaultCommand(menuitems.ID_INSERT_DATETIME, insert_menu, _(
            "Insert datetime"), lambda: self.ProcessFormatterEvent(menuitems.ID_INSERT_DATETIME))
        get_app().AddDefaultCommand(menuitems.ID_INSERT_COMMENT_TEMPLATE, insert_menu, _(
            "Insert comment template"), lambda: self.ProcessFormatterEvent(menuitems.ID_INSERT_COMMENT_TEMPLATE))
        get_app().AddDefaultCommand(menuitems.ID_INSERT_FILE_CONTENT, insert_menu, _(
            "Insert file content"), lambda: self.ProcessFormatterEvent(menuitems.ID_INSERT_FILE_CONTENT))
        format_menu = find_menu(_("&Format"), get_app().Menubar)

        get_app().AddDefaultCommand(
            menuitems.ID_COMMENT_LINES,
            format_menu,
            _("Comment &Lines"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_COMMENT_LINES),
            image="comment.png",
        )
        get_app().AddDefaultCommand(
            menuitems.ID_UNCOMMENT_LINES,
            format_menu, _("&Uncomment Lines"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_UNCOMMENT_LINES),
            image="uncomment.png",
        )

        get_app().AddDefaultCommand(
            menuitems.ID_INDENT_LINES,
            format_menu,
            _("&Indent Lines"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_INDENT_LINES),
            image="indent.png"
        )
        get_app().AddDefaultCommand(
            menuitems.ID_DEDENT_LINES,
            format_menu,
            _("&Dedent Lines"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_DEDENT_LINES),
            image="dedent.png"
        )

        get_app().AddDefaultCommand(
            menuitems.ID_TAB_SPACE,
            format_menu,
            _("Tabs To Spaces"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_TAB_SPACE),
        )
        get_app().AddDefaultCommand(
            menuitems.ID_SPACE_TAB,
            format_menu,
            _("Spaces To Tabs"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_SPACE_TAB),
        )
        get_app().AddDefaultCommand(
            menuitems.ID_CLEAN_WHITESPACE,
            format_menu,
            _("Clean trailing whitespace"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_CLEAN_WHITESPACE),
        )

        eol_menu = NewQMenu(_("&EOL Mode"))
        format_menu.AppendMenu(menuitems.ID_EOL_MODE, eol_menu)

        eol_cr_item = get_app().AddDefaultCommand(
            menuitems.ID_EOL_MAC,
            eol_menu,
            _(constants.EOL_CHOICES[QsciScintilla.EolMac]),
            lambda: self.ProcessFormatterEvent(menuitems.ID_EOL_MAC),
            kind=constants.RADIO_MENU_ITEM_KIND
        )
        eol_lf_item = get_app().AddDefaultCommand(
            menuitems.ID_EOL_UNIX,
            eol_menu,
            _(constants.EOL_CHOICES[QsciScintilla.EolUnix]),
            lambda: self.ProcessFormatterEvent(menuitems.ID_EOL_UNIX),
            kind=constants.RADIO_MENU_ITEM_KIND
        )
        eol_crlf_item = get_app().AddDefaultCommand(
            menuitems.ID_EOL_WIN,
            eol_menu,
            _(constants.EOL_CHOICES[QsciScintilla.EolWindows]),
            lambda: self.ProcessFormatterEvent(menuitems.ID_EOL_WIN),
            kind=constants.RADIO_MENU_ITEM_KIND
        )
        self.el_group.addAction(eol_crlf_item.action)
        self.el_group.addAction(eol_cr_item.action)
        self.el_group.addAction(eol_lf_item.action)
        advance_menu = NewQMenu(_("&Advance"))
        edits_menu.AppendMenu(menuitems.ID_ADVANCE, advance_menu)
        get_app().AddDefaultCommand(
            menuitems.ID_UPPERCASE,
            advance_menu,
            _("Conert To UPPERCASE"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_UPPERCASE),
            image="uppercase.png"
        )
        get_app().AddDefaultCommand(
            menuitems.ID_LOWERCASE,
            advance_menu,
            _("Conert To lowercase"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_LOWERCASE),
            image="lowercase.png"
        )
        get_app().AddDefaultCommand(
            menuitems.ID_FIRST_UPPERCASE,
            advance_menu,
            _("Proper case"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_FIRST_UPPERCASE)
        )
        get_app().AddDefaultCommand(
            menuitems.ID_COPY_LINE,
            advance_menu,
            _("Copy line"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_COPY_LINE)
        )
        get_app().AddDefaultCommand(
            menuitems.ID_CUT_LINE,
            advance_menu,
            _("Cut line"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_CUT_LINE)
        )
        get_app().AddDefaultCommand(
            menuitems.ID_CLONE_LINE,
            advance_menu,
            _("Duplicate line"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_CLONE_LINE)
        )
        get_app().AddDefaultCommand(
            menuitems.ID_DELETE_LINE,
            advance_menu,
            _("Delete line"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_DELETE_LINE)
        )

        view_menu = find_menu(_("&View"), get_app().Menubar)
        zoom_menu = NewQMenu(_("&Zoom"))
        view_menu.AppendMenu(menuitems.ID_ZOOM, zoom_menu)
        get_app().AddDefaultEditorCommand(
            menuitems.ID_ZOOM_IN,
            zoom_menu,
            _("Zoom In"),
            lambda: self.ZoomView(1),
            image="toolbar/zoom_in.png",
            include_in_toolbar=True
        )
        get_app().AddDefaultEditorCommand(
            menuitems.ID_ZOOM_OUT,
            zoom_menu,
            _("Zoom Out"),
            lambda: self.ZoomView(-1),
            image="toolbar/zoom_out.png",
            include_in_toolbar=True
        )

        symbol_menu = NewQMenu(_("&Display symbols"))
        view_menu.AppendMenu(menuitems.ID_DISPLAY_SYMBOL, symbol_menu)
        get_app().AddDefaultEditorCommand(
            menuitems.ID_VIEW_WHITESPACE,
            symbol_menu,
            _("Show whitespace and TAB"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_VIEW_WHITESPACE),
            kind=constants.CHECK_MENU_ITEM_KIND
        )
        get_app().AddDefaultEditorCommand(
            menuitems.ID_VIEW_EOL,
            symbol_menu,
            _("Show end of line"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_VIEW_EOL),
            kind=constants.CHECK_MENU_ITEM_KIND
        )
        get_app().AddDefaultEditorCommand(
            menuitems.ID_VIEW_INDENTATION_GUIDES,
            symbol_menu,
            _("Show Indent guide"),
            lambda: self.ProcessFormatterEvent(
                menuitems.ID_VIEW_INDENTATION_GUIDES),
            kind=constants.CHECK_MENU_ITEM_KIND
        )
        get_app().AddDefaultEditorCommand(
            menuitems.ID_VIEW_RIGHT_EDGE,
            symbol_menu,
            _("Show Right edge"),
            lambda: self.ProcessFormatterEvent(menuitems.ID_VIEW_RIGHT_EDGE),
            kind=constants.CHECK_MENU_ITEM_KIND
        )
        get_app().AddCommand(
            menuitems.ID_PRE_POS,
            view_menu,
            _("Previous position"),
            self.__goto_pre_pos,
            image=get_app().GetImage("toolbar/go_prev.png"),
            tester=lambda: docposition.DocMgr.CanNavigatePrev(),
            include_in_toolbar=True
        )
        get_app().AddCommand(
            menuitems.ID_NEXT_POS,
            view_menu,
            _("Next position"),
            self.__goto_next_pos,
            image=get_app().GetImage("toolbar/go_next.png"),
            tester=lambda: docposition.DocMgr.CanNavigateNext(),
            include_in_toolbar=True
        )

    def ZoomView(self, delta):
        view = self.get_current_view()
        view.ZoomView(delta)

    def ProcessFormatterEvent(self, event_id):
        view = self.get_current_view()
        if event_id == menuitems.ID_COMMENT_LINES:
            view.comment_region()
        elif event_id == menuitems.ID_UNCOMMENT_LINES:
            view.uncomment_region()
        elif event_id == menuitems.ID_INDENT_LINES:
            view.tab()
        elif event_id == menuitems.ID_DEDENT_LINES:
            view.backtab()
        elif event_id == menuitems.ID_UPPERCASE:
            view.UpperCase()
        elif event_id == menuitems.ID_LOWERCASE:
            view.LowerCase()
        elif event_id == menuitems.ID_FIRST_UPPERCASE:
            view.FirstUppercase()
        elif event_id == menuitems.ID_TAB_SPACE:
            view.untabify_region()
        elif event_id == menuitems.ID_SPACE_TAB:
            view.tabify_region()
        elif event_id == menuitems.ID_CLEAN_WHITESPACE:
            if view.GetCtrl().hasSelection():
                view.do_rstrip()
            else:
                view.do_rstrip_line(view.GetCtrl().get_current_line())
        elif event_id in [menuitems.ID_EOL_MAC, menuitems.ID_EOL_WIN, menuitems.ID_EOL_UNIX]:
            view.do_eol(event_id)
        elif event_id == menuitems.ID_COPY_LINE:
            view.copy_line()
        elif event_id == menuitems.ID_CUT_LINE:
            view.cut_line()
        elif event_id == menuitems.ID_DELETE_LINE:
            view.delete_line()
        elif event_id == menuitems.ID_CLONE_LINE:
            view.duplicate_line()
        elif event_id == menuitems.ID_INSERT_DATETIME:
            view.InsertDatatime()
        elif event_id == menuitems.ID_INSERT_FILE_CONTENT:
            view.InsertFileContent()
        elif event_id == menuitems.ID_INSERT_COMMENT_TEMPLATE:
            view.InsertCommentTemplate()
        elif event_id == menuitems.ID_VIEW_RIGHT_EDGE:
            view.toogle_edge_visibility()
        elif event_id == menuitems.ID_VIEW_INDENTATION_GUIDES:
            view.toogle_indentation_guides_visibility()
        elif event_id == menuitems.ID_VIEW_EOL:
            view.toogle_eol_visibility()
        elif event_id == menuitems.ID_VIEW_WHITESPACE:
            view.toogle_whitespace_visibility()

    def update_tabs_option(self):
        '''
            更新标签页选项
        '''
        # 标签页是否显示关闭按钮
        self.setTabsClosable(utils.profile_get_int(
            globalkeys.TAB_SHOW_CLOSEBUTTON_KEY, False))
        # 是否允许拖拽打开文件
        self.setAcceptDrops(utils.profile_get_int(
            globalkeys.ALLOW_DRAP_OPENFILES_KEY, True))
        tab_position = utils.profile_get_int(
            globalkeys.TAB_POSITION_KEY, QTabWidget.North)
        if self.tabPosition() != tab_position:
            self.setTabPosition(tab_position)

    def update_editor_appearance(self):
        '''
            更新编辑区域的外观
        '''
        for index in range(self.count()):
            view_frame = self.widget(index)
            view = view_frame.GetView()
            if isinstance(view, TextView):
                view.update_appearance()

    def update_app_version(self, data):
        CheckAppupdateInfo(data)

    def download_error(self, error_msg):
        QMessageBox.critical(self, _("Error"), _(
            "Download fail:%s") % error_msg)

    def download_succ(self, msg):
        QMessageBox.information(
            self,
            get_app().GetAppName(),
            msg
        )

    def update_plugin_version(self, data):
        check_pluign_update(data, self)

    @ui_utils.update_toolbar
    def toogle_maximized_editor(self):
        if utils.profile_get_int(globalkeys.MAXIMIZE_EDITOR_KEY, True):
            if self._is_maximized:
                self.RestoreEditor()
            else:
                self.MaximizeEditor()

    def save_open_documents(self):
        open_filenames = []
        for index in range(self.count()):
            doc = self.GetDocumentFromPageIndex(index)
            open_filenames.append(doc.GetFilename() + constants.LF)
        cache_path = os.path.join(
            utils.get_user_data_path(), constants.USER_CACHE_DIR)
        open_doc_path = os.path.join(cache_path, constants.OPEN_DOCS_FILENAME)
        try:
            with open(open_doc_path, "w") as writer:
                writer.writelines(open_filenames)
        except Exception as ex:
            utils.get_logger().error(str(ex))

    def load_open_documents(self):
        if not utils.profile_get_int(globalkeys.LOAD_LAST_OPENDOCS, False):
            return
        cache_path = os.path.join(
            utils.get_user_data_path(), constants.USER_CACHE_DIR)
        open_doc_path = os.path.join(cache_path, constants.OPEN_DOCS_FILENAME)
        try:
            with open(open_doc_path) as reader:
                for line in reader:
                    filepath = line.strip()
                    if not os.path.exists(filepath):
                        continue
                    get_app().GetDocumentManager().CreateDocument(filepath, DOC_SILENT)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            utils.get_logger().exception(
                'load open docs file %s exception:',
                open_doc_path
            )

    def __show_tabcontext_menu(self, pos):
        """Shows a context menu if required"""
        clickedindex = self.tabBar().tabAt(pos)
        tabindex = self.currentIndex()
        if tabindex == clickedindex:
            self.create_tab_menu(tabindex)
            # 不能使用self.mapToGlobal(pos),没有考虑到选项卡方向问题
            self._tabs_menu.popup(QCursor.pos())

    def __install_actions(self):
        """Installs various key combinations handlers"""
        new_module_action = QShortcut(self.new_module_shortcut, self)
        new_module_action.activated.connect(self.NewModule)

    def __on_close_request(self, index, enforced=False):
        """Close tab handler"""
        get_app().MainFrame.CloseDoc()

    # 由于此消息是异步消息,创建标签页是文本控件还没有创建,故需要延迟执行
    # 以便等待文本控件创建成功
    @ui_utils.call_after_with_time(10)
    def __currentChanged(self, index):
        """Handles the currentChanged signal"""
        get_app().MainFrame.clearStatusBarMessage()
        if index == -1:
            self.sigTabRunChanged.emit(False)
            return
        self.updateStatusBar()
        widget = self.currentWidget()
        if widget is not None:
            widget.setFocus()

    def __goto_next_pos(self):
        fname, line, col = (None, None, None)
        cname, cline, ccol = (None, None, None)
        editor = self.get_current_editor()
        if editor is not None:
            text_view = editor.get_view()
            cname = text_view.GetDocument().GetFilename()
            if isinstance(text_view, TextView):
                cline = editor.get_current_line()
                ccol = editor.get_current_column()

        if docposition.DocMgr.CanNavigateNext():
            fname, line, col = docposition.DocMgr.GetNextNaviPos()
            if (fname, line, col) == (cname, cline, ccol):
                fname, line, col = (None, None, None)
                tmp = docposition.DocMgr.GetNextNaviPos()
                if tmp is not None:
                    fname, line, col = tmp
        if fname is not None:
            # 跳转到位置时不需追踪位置了
            get_app().GotoView(
                fname,
                lineNum=line,
                colno=col,
                trace_track=False,
                load_outline=False
            )
            # 跳转位置后要更新状态栏显示的行列号
            editor = self.get_current_editor()
            if editor is not None:
                text_view = editor.get_view()
                text_view.set_pos()

    @ui_utils.update_toolbar
    def __goto_pre_pos(self):
        fname, line, col = (None, None, None)
        cname, cline, ccol = (None, None, None)
        editor = self.get_current_editor()
        if editor is not None:
            text_view = editor.get_view()
            cname = text_view.GetDocument().GetFilename()
            if isinstance(text_view, TextView):
                cline = editor.get_current_line()
                ccol = editor.get_current_column()

        if docposition.DocMgr.CanNavigatePrev():
            fname, line, col = docposition.DocMgr.GetPreviousNaviPos()
            if (fname, line, col) == (cname, cline, ccol):
                fname, line, col = (None, None, None)
                tmp = docposition.DocMgr.GetPreviousNaviPos()
                if tmp is not None:
                    fname, line, col = tmp
        if fname is not None:
            # 跳转到位置时不需追踪位置了
            get_app().GotoView(
                fname,
                lineNum=line,
                colno=col,
                trace_track=False,
                load_outline=False
            )
            # 跳转位置后要更新状态栏显示的行列号
            editor = self.get_current_editor()
            if editor is not None:
                text_view = editor.get_view()
                text_view.set_pos()

    def __closeall_without_doc(self, closeall=False):
        # 倒序关闭所有文档,防止数组越界
        for i in range(self.count() - 1, -1, -1):  # Go from len-1 to 0
            doc = self.GetDocumentFromPageIndex(i)
            if doc != self._current_document or closeall:
                if not get_app().GetDocumentManager().CloseDocument(doc, False):
                    break
