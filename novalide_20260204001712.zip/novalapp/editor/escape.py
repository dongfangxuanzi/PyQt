from .. import get_app
from ..lib.docview import View
from ..widgets.fullscreen import FullscreenWidget


class EscapeView(View):

    def connect_editor_widget(self):
        """Connects the editor's signals"""
        self.GetCtrl().SIG_ESCAPE_PRESSED.connect(self._on_esc)

    def GetCtrl(self):
        return None

    def _on_esc(self):
        """The editor detected ESC pressed"""
        # 全屏显示时文本框按esc键退出全屏模式
        if get_app().MainFrame.isFullScreen():
            FullscreenWidget.show_hide()
