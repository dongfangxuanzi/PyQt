from .css_code import *
from .welcome_page_code import *

js_code = '''

document.oncontextmenu=function(e){return %s;}

function NewProject() {
    new QWebChannel(qt.webChannelTransport, function(channel) {
    channel.objects.Command.action('command:workbench.action.project.newProject');
    });
}

function OpenProject() {
    new QWebChannel(qt.webChannelTransport, function(channel) {
    channel.objects.Command.action('command:workbench.action.project.openProject');
    });
}

function LoadNews(content) {
    document.getElementById("news").innerHTML = content;
}

function SetEmptyNews() {
    document.getElementById("news").innerHTML = "No recent news";
}

function LoadLearn(content) {
    document.getElementById("learn").innerHTML = content;
}

function SetEmptyLearn() {
    document.getElementById("learn").innerHTML = "No recent learn";
}

function OpenRecentProject(path) {
    new QWebChannel(qt.webChannelTransport, function(channel) {
    channel.objects.Command.action(`command:workbench.action.project.openRecentProject:${path}`);
    });
}

function OpenFeedsUrl(url, feedid) {
    new QWebChannel(qt.webChannelTransport, function(channel) {
    channel.objects.Command.action(`command:workbench.action.feeds.openurl:${url}|${feedid}`);
    });
}

function UpdateApp(app_version) {
    new QWebChannel(qt.webChannelTransport, function(channel) {
    channel.objects.Command.action(`command:workbench.action.app.update:${app_version}`);
    });
}

function UpdatePlugin(plugin_id) {
    new QWebChannel(qt.webChannelTransport, function(channel) {
    channel.objects.Command.action(`command:workbench.action.plugin.update:${plugin_id}`);
    });
}

function OpenPluginsDlg() {
    new QWebChannel(qt.webChannelTransport, function(channel) {
        channel.objects.Command.action('command:workbench.action.help.ManagePlugins');
    });
}

function OpenCodeRepository() {
    new QWebChannel(qt.webChannelTransport, function(channel) {
        channel.objects.Command.action('command:workbench.action.help.openCodeRepositoryURL');
    });
}

function OpenDocumentation() {
    new QWebChannel(qt.webChannelTransport, function(channel) {
        channel.objects.Command.action('command:workbench.action.help.openDocumentationUrl');
    });
}

function OpenTipsAndTricksUrl() {
    new QWebChannel(qt.webChannelTransport, function(channel) {
        channel.objects.Command.action('command:workbench.action.help.openTipsAndTricksUrl');
    });
}

function OpenIntroductoryVideos() {
    new QWebChannel(qt.webChannelTransport, function(channel) {
        channel.objects.Command.action('command:workbench.action.help.openIntroductoryVideosUrl');
    });
}

function OpenKindings() {
    new QWebChannel(qt.webChannelTransport, function(channel) {
        channel.objects.Command.action('command:workbench.action.help.keybindingsReference');
    });
}

function SetEmptyProject() {
    document.getElementById("welcome").classList.add("emptyRecent");
}

function LoadProjects(content) {
    document.getElementById("recent").innerHTML = content;
}
'''

html_code = '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>welcome</title>
    <meta name="renderer" content="webkit">
    <script src='qrc:///qtwebchannel/qwebchannel.js'></script>
    {css_code}
</head>
<body>

<script type="text/javascript">
{js_code}
</script>
{content_code}
</body>
</html>
'''.format(css_code=css_code, content_code=content_code, js_code=js_code)
