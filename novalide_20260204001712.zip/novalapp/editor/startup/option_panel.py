from ... import _
from ...util import ui_utils, utils
from ... import globalkeys
from ...lib.pyqt import QHBoxLayout, QCheckBox, QLabel, QSpinBox, Qt
from ...lib.limits import DEFAULT_MRU_PROJECT_NUM, MAX_MRU_PROJECT_LIMIT
from ...lib.defaultkeys import AppDefaultKey


class StartupOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    起始页配置面板
    """

    def __init__(self, parent):
        super().__init__(parent)
        self.showWelcomePageCheckBox = QCheckBox(
            _("Show start page on startup"))
        self.showWelcomePageCheckBox.setChecked(
            utils.profile_get_int(globalkeys.SHOW_WELCOME_PAGE_KEY, True))
        self.layout.addWidget(self.showWelcomePageCheckBox)
        hlayout = QHBoxLayout()
        hlayout.setAlignment(Qt.AlignLeft)
        hlayout.addWidget(QLabel(_("Project History length on start page") +
                          "(%d-%d): " % (1, MAX_MRU_PROJECT_LIMIT)))
        self.mru_project_ctrl = QSpinBox(
            value=utils.profile_get_int(
                AppDefaultKey.RECENTPROJECT_LENGTH_KEY.value, DEFAULT_MRU_PROJECT_NUM),
            maximum=MAX_MRU_PROJECT_LIMIT,
            minimum=1,
            singleStep=1
        )
        hlayout.addWidget(self.mru_project_ctrl)
        self.layout.addLayout(hlayout)
        self.layout.addStretch(1)

    def OnOK(self, options_dialog):
        utils.profile_set(globalkeys.SHOW_WELCOME_PAGE_KEY,
                          self.showWelcomePageCheckBox.isChecked())
        utils.profile_set(AppDefaultKey.RECENTPROJECT_LENGTH_KEY.value,
                          self.mru_project_ctrl.value())
        return True
