# -*- coding: utf-8 -*-
import os
import re
import functools
import json
import logging
import requests
from .. import get_app, _
from ..analytics.userdb import UserdataDb
from . import appdirs, fileutils, ui_utils
from .. import constants
from ..lib.pyqt import QProgressDialog, QThread, pyqtSignal

log = logging.getLogger(__name__)


class DownloadProgressDialog(QProgressDialog):
    '''
        下载进度显示对话框
    '''
    update_progress_signal = pyqtSignal(int, str)

    def __init__(self, parent, file_size, file_name):
        welcome_msg = _("Please wait a minute for downloading")
        QProgressDialog.__init__(self, welcome_msg, _(
            "Cancel"), 0, file_size, parent)
        self.setWindowTitle(_("Downloading %s") % file_name)
        self.update_progress_signal.connect(self.update_progress)

    def update_progress(self, curval, msg):
        # 下载完成后关闭进度条
        if msg == constants.PROGRESS_END:
            self.setValue(self.maximum())
            self.close()
        else:
            # 当进度数等于或超过最大进度值时,将会关闭进度条对话框,故不能让进度值超过最大进度值
            if curval >= self.maximum():
                curval = self.maximum() - 1
            self.setValue(curval)
            if msg:
                self.setLabelText(msg)


class FileDownloader(QThread):
    '''
        下载文件公用类
    '''

    def __init__(self, service, parent, file_name, req, call_back=None, err_callback=None):
        super().__init__(parent)
        self._file_name = file_name
        self._download_service = service
        self._req = req
        self._call_back = call_back
        self._err_callback = err_callback

    def run(self):
        self.startdownload()

    def startdownload(self):
        # 文件下载到临时目录
        download_tmp_path = os.path.join(appdirs.get_cache_path(), "download")
        log.debug("tmp download cache path is %s", download_tmp_path)
        if not os.path.exists(download_tmp_path):
            fileutils.makedirs(download_tmp_path)
        self._download_service.is_downloading = True
        download_file_path = os.path.join(download_tmp_path, self._file_name)
        self.downloadfile(download_file_path)

    def is_canceled(self):
        if self._download_service.progress_dlg is None:
            return False
        return self._download_service.progress_dlg.wasCanceled()

    def update_download_progress(self, amount, msg):
        '''更新下载进度条值,如果没有出现进度条对话框则不更新'''
        if self._download_service.progress_dlg is None:
            return
        self._download_service.progress_dlg.update_progress_signal.emit(
            amount, msg)

    def cancel_download_progress(self):
        '''因下载文件失败,主动中断下载进度条'''
        if self._download_service.progress_dlg is None:
            return
        # 模拟点击取消键时,发出取消信号
        self._download_service.progress_dlg.canceled.emit()

    def downloadfile(self, download_file_path):
        f = open(download_file_path, "wb")
        try:
            ammount = 0
            # 分块下载
            for chunk in self._req.iter_content(chunk_size=512):
                if chunk:
                    if self.is_canceled():
                        break
                    f.write(chunk)
                    ammount += len(chunk)
                    self.update_download_progress(ammount, "")
        except Exception as e:
            # 下载失败中断进度条对话框
            self.cancel_download_progress()
            log.error(
                "download file url %s error:%s,download progress was canceled", self._req.url, e)
            # 错误回调函数
            if self._err_callback:
                self._err_callback(str(e))
            f.close()
            self._download_service.is_downloading = False
            return
        f.close()
        # 这里需要设置下载结束标致,否则会导致下载完成后弹出进度条
        self._download_service.is_downloading = False
        # 下载完成调用回调函数
        self.update_download_progress(ammount, _("Installing..."))
        if self._call_back is not None and not self.is_canceled():
            self._call_back(download_file_path, self.parent())
        self.update_download_progress(ammount, constants.PROGRESS_END)


class FiledownloadSerivce:
    def __init__(self):
        # 是否正则下载文件,用来表示是否显示进度条对话框
        self.is_downloading = False
        # 进度条对话框
        self.progress_dlg = None
        # 下载文件大小
        self._file_size = 0

    def download_file(
            self,
            download_url,
            filename=None,
            call_back=None,
            parent=None,
            err_callback=None, **payload):
        '''
            下载文件公用函数
            download_url:下载地址
            call_back:下载完成后回调函数
            payload:url参数
        '''
        user_id = UserdataDb.get_db().GetUserId()
        if not user_id:
            UserdataDb.get_db().GetUser()
            user_id = UserdataDb.get_db().GetUserId()
        if user_id:
            payload.update({'member_id': user_id})
        payload['timeout'] = 10
        kwargs = {'stream': True}
        if download_url.startswith("https:"):
            kwargs.update({'verify': False})
        if parent is None:
            parent = get_app().GetTopWindow()
        if err_callback is None:
            err_callback = functools.partial(
                self.download_error_callback, parent)
        try:
            req = requests.get(download_url, params=payload, **kwargs)
        except Exception as ex:
            log.error("download file url %s error:%s", download_url, ex)
            err_callback(str(ex))
            return
        if 'Content-Length' not in req.headers:
            reason = self.log_fail_reason(req)
            err_callback("get file remote length error:%s" % reason)
        else:
            # 字典头部是字符串类型, 转换成整数
            try:
                self._file_size = int(req.headers['Content-Length'])
                content_disposition = req.headers['Content-Disposition']
            except KeyError as ex:
                log.error("download file url %s keyerror:%s", download_url, ex)
                reason = self.log_fail_reason(req)
                err_callback("header:keyerror:%s:%s" % (ex, reason))
                return
            # 头部包含的文件名
            res = re.search("filename=\"(.*)\"", content_disposition)
            if res is None:
                log.error("fetch filename error in head content %s",
                          content_disposition)
                err_callback("fetch filename error")
                return
            content_file_name = res.groups()[0]
            self.show_downloadprogress_dialog(parent, content_file_name)
            if filename is None:
                filename = content_file_name
            # 这里的filename是下载完成后本地文件名和头部包含的文件名可能不一样
            file_downloader = FileDownloader(
                self, parent, filename, req, call_back, err_callback)
            file_downloader.start()

    @ui_utils.call_after_with_time(1000)
    def show_downloadprogress_dialog(self, parent, filename):
        # 如果下载操作已经完成,则不会显示下载进度条对话框
        if self.is_downloading:
            self.progress_dlg = DownloadProgressDialog(
                parent, self._file_size, filename)
            self.progress_dlg.exec_()

    def download_error_callback(self, parent, msg):
        parent.SIG_DOWNLOAD_ERROR.emit(msg)

    def log_fail_reason(self, req):
        reason = ''
        try:
            # api接口返回json数据
            data = req.json()
            reason = json.dumps(data)
            log.error("download file url %s error:%s", req.url, reason)
        except json.decoder.JSONDecodeError as ex:
            # api接口返回html文本数据
            log.error(
                "download file url %s decode response text error:%s", req.url, ex)
            reason = str(ex)
        return reason
