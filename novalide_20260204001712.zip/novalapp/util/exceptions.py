import logging
from .. import _, get_app
from ..lib.pyqt import QMessageBox

log = logging.getLogger(__name__)


def catch_exception(func):
    '''
    '''
    def wrapped_func(*args, **kwargs):
        try:
            func(*args, **kwargs)
        except Exception as e:
            log.exception("catch exception:")
            QMessageBox.critical(get_app().GetTopWindow(), _("Error"), str(e))
    return wrapped_func


class StartupPathNotExistError(Exception):
    def __init__(self, startup_path):
        self.msg = _("Startup path \"%s\" is not exist") % startup_path
        super().__init__(self.msg)

    def show_message(self):
        QMessageBox.critical(get_app().GetTopWindow(), _(
            "Startup path not exist"), self.msg)


class InvalidRunableProjectError(Exception):

    def __init__(self, document_path):
        super().__init__(_("Project file \"%s\" is not a valid runable project") % document_path)


def catch_run_exception(func):
    '''
        调试运行公共异常处理函数,装饰调式运行函数,做同样的异常处理
    '''
    def _wrapper(*args, **kwargs):
        try:
            func(*args, **kwargs)
        except StartupPathNotExistError as e:
            e.show_message()
        except Exception as e:
            if not isinstance(e, InvalidRunableProjectError):
                log.exception("debug/run exception:")
            QMessageBox.critical(get_app().GetTopWindow(),
                                 _("Run error"), str(e))
    return _wrapper


class UnkownEncodingError(Exception):
    def __init__(self, encoding):
        super().__init__(_("Unknown encoding \"%s\"") % encoding)


class ShortcutConflictedError(Exception):
    ''''''


class DownloadError(Exception):
    ''''''


class UploadError(Exception):
    ''''''


class ProcessordocNotmatchedErrror(Exception):
    '''项目处理器执行过程中项目文档不能发生改变'''


class CommandlineLengthExceedLimitError(Exception):
    '''
    命令行长度超过最大限制长度
    '''
