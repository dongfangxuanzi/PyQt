import datetime
from ..constants import ISO_8601_DATETIME_FORMAT


def timestamp_to_timestr(timestamp, time_format="%Y-%m-%d"):
    date_time = datetime.datetime.fromtimestamp(timestamp)
    timestr = date_time.strftime(time_format)
    return timestr


def get_locale_datetime(time_format=ISO_8601_DATETIME_FORMAT):
    datetime_str = datetime.datetime.strftime(
        datetime.datetime.now(), time_format)
    return datetime_str
