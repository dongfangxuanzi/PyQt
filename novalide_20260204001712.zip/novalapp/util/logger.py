'''
----------------------------------------------------------------------------
Name:         logger.py
Purpose:      Utilities to help with logging

Author:       Jeff Norton

Created:      01/04/05
CVS-ID:       $Id$
Copyright:    (c) 2005 novalide, Inc.
License:      wxWindows License
----------------------------------------------------------------------------
'''
import logging
import sys

LEVEL_FATAL = logging.FATAL
LEVEL_ERROR = logging.ERROR
LEVEL_WARN = logging.WARN
LEVEL_INFO = logging.INFO
LEVEL_DEBUG = logging.DEBUG

LOG_INITIALIZED = False

IDE_LOG_NAME = "ide.run"
DEBUG_IDE_LOG_NAME = "ide.debug"
DEFAULT_IDE_LOG_NAME = IDE_LOG_NAME


def init_logging(debug=False):
    global default_ide_logger, LOG_INITIALIZED, DEFAULT_IDE_LOG_NAME
    if not LOG_INITIALIZED:
        LOG_INITIALIZED = True
        log_level = logging.INFO
        default_stream = sys.stdout
        if debug:
            log_level = logging.DEBUG
            DEFAULT_IDE_LOG_NAME = DEBUG_IDE_LOG_NAME
        handler = logging.StreamHandler(default_stream)
        handler.setLevel(log_level)
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(name)s %(levelname)s: %(message)s"))
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(log_level)
        default_ide_logger = logging.getLogger(DEFAULT_IDE_LOG_NAME)
        default_ide_logger.setLevel(log_level)


default_ide_logger = logging.getLogger(DEFAULT_IDE_LOG_NAME)


def get_logger(logger_name=""):
    if logger_name in ('', 'root'):
        return default_ide_logger
    return logging.getLogger(logger_name)
