# -*- coding: utf-8 -*-
import importlib
import subprocess
from .logger import *
from .apputils import *
from .appdirs import *
from .urlutils import *
from .strutils import *
from .. import get_app
from ..lib.profile import Profile


def profile_get(key, value=""):
    return Profile.get(key, value)


def profile_get_int(key, value=-1):
    return Profile.get_int(key, value)


def profile_set(key, value):
    return Profile.set(key, value)


def update_statusbar(msg):
    get_app().MainFrame.PushStatusText(msg)


def get_child_pids(ppid):
    child_ids = []
    for pid in psutil.pids():
        try:
            p = psutil.Process(pid)
            if p.ppid() == ppid:
                child_ids.append(p.pid)
        except:
            pass
    return child_ids


def get_class_from_dynamicimport_module(full_class_path):
    '''
        从给定字符串中动态获取模块的类
    '''
    parts = full_class_path.split(".")
    full_module_path = ".".join(parts[0:-1])
    class_name = parts[-1]
    # 必须先导入模块,再获取模块里面的方法,不要直接导入类
    module_obj = importlib.import_module(full_module_path)
    get_logger().debug("module %s file path is %s",
                       full_module_path, module_obj.__file__)
    class_obj = getattr(module_obj, class_name)
    return class_obj


def compute_time(func):
    '''
        统计函数执行时间的装饰函数
    '''
    def wrapped_func(*args, **kwargs):
        start = time.perf_counter()
        ret = func(*args, **kwargs)
        end = time.perf_counter()
        elapse = end - start
        get_logger().info("function %s elapse %.3f seconds in module %s",
                          func.__qualname__, elapse, func.__module__)
        return ret
    return wrapped_func


def call_process(cmd, args):
    '''
        简单调用进程
    '''
    if is_windows():
        import win32api
        win32api.ShellExecute(0, "open", cmd, " " + args +
                              " " + extension.commandPostArgs, '', 1)
    else:
        subprocess.call(cmd + ' ' + args, shell=True)


def create_process(command, args, shell=True, env=None, universal_newlines=True, cwd=None):
    '''
        创建普通进程
    '''
    # 如果shell为False,表示命令是列表,subprocess.Popen只接受数组变量作为命令
    if not shell:
        if isinstance(args, str):
            # 将字符串参数按空格转换成参数列表,支持分割双引号参数
            args = parse_cmd_line(args)
        cmd = [command] + args
        get_logger().debug("run command is:%s", ' '.join(cmd))
    # 否则是shell命令字符串
    else:
        cmd = command + " " + args
        get_logger().debug("run command is:%s", cmd)
    if is_windows():
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP
        # 隐藏命令行黑框
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
    else:
        startupinfo = None
        creationflags = 0
    p = subprocess.Popen(
        cmd,
        shell=shell,
        env=env,
        cwd=cwd,
        universal_newlines=universal_newlines,
        startupinfo=startupinfo,
        creationflags=creationflags,
    )
    return p
