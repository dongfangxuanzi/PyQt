# -*- coding: utf-8 -*-
import os
from ... import get_app, _
from ...util import ui_utils, utils, fileutils
from .. import utility
from ... import constants
from .. import pythonenv
from ...lib.pyqt import (
    QHBoxLayout,
    QPushButton,
    QComboBox,
    QMessageBox,
    QFileDialog,
    QLabel,
    QSizePolicy,
    QLineEdit,
    QCheckBox,
    QGridLayout
)
from ...util.cmp_func import py_sorted, cmp_name
from ...syntax.syntax import SyntaxThemeManager


class CommandPropertiesDialog(ui_utils.BaseModalDialog):
    def __init__(
        self,
        parent,
        title,
        currentProj,
        okButtonName='&OK',
        debugging=False,
        is_last_config=False
    ):
        self._is_last_config = is_last_config
        self._currentproj = currentProj
        self._projectname_list, self._project_documentlist, selected_index = self.GetProjectList()
        if not self._projectname_list:
            messagebox.showerror(
                _("To run or debug you must have an open runnable file or project containing runnable files. Use File->Open to open the file you wish to run or debug."), _("Nothing to Run"))
            raise Exception("Nothing to Run or Debug.")
        super().__init__(title, parent)
        self.setFixedSize(500, 300)
        frame_grid_layout = QGridLayout()
        frame_grid_layout.addWidget(QLabel(_("Project") + ":"), 0, 0)
        frame_grid_layout.addWidget(QLabel(_("File") + ":"), 1, 0)
        frame_grid_layout.addWidget(QLabel(_("Arguments") + ":"), 2, 0)
        frame_grid_layout.addWidget(QLabel(_("Start in") + ":"), 3, 0)
        frame_grid_layout.addWidget(QLabel(_("PYTHONPATH:")))

        postpend_statictext = _("Postpend content root path")
        self._projlist = QComboBox()
        self._projlist.setEditable(False)
        self._projlist.addItems(self._projectname_list)
        frame_grid_layout.addWidget(self._projlist, 0, 1)
        self._projlist.currentIndexChanged.connect(self.EvtListBox)

        self._filelist = QComboBox()
        self._filelist.setEditable(False)
        frame_grid_layout.addWidget(self._filelist, 1, 1)
        self._filelist.currentIndexChanged.connect(self.OnFileSelected)

        self._last_arguments = utils.profile_get(
            self.GetKey("LastRunArguments"))
        arg_hbox = QHBoxLayout()
        self._args_entry = QComboBox()
        self._args_entry.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._args_entry.setEditable(True)
        arg_hbox.addWidget(self._args_entry)

        self.usearg_checkbox = QCheckBox(_("Use"))
        self.usearg_checkbox.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.usearg_checkbox.clicked.connect(self.CheckUseArgument)
        self.usearg_checkbox.setChecked(True)
        arg_hbox.addWidget(self.usearg_checkbox)
        frame_grid_layout.addLayout(arg_hbox, 2, 1)

        startin_hbox = QHBoxLayout()
        self._last_startin = utils.profile_get(
            self.GetKey("LastRunStartIn"), os.getcwd())
        self.start_entry = QLineEdit()
        self.start_entry.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        startin_hbox.addWidget(self.start_entry)

        self._finddir_btn = QPushButton(_("Browse") + "...")
        startin_hbox.addWidget(self._finddir_btn)
        self._finddir_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self._finddir_btn.clicked.connect(self.OnFindDirClick)
        frame_grid_layout.addLayout(startin_hbox, 3, 1)

        if pythonenv.PYTHON_PATH_NAME in os.environ:
            startval = os.environ[pythonenv.PYTHON_PATH_NAME]
        else:
            startval = ""
        self._last_pythonpath = utils.profile_get(
            self.GetKey("LastPythonPath"), startval)

        self.pythonpath_entry = QLineEdit()
        frame_grid_layout.addWidget(self.pythonpath_entry, 4, 1)
        self.pythonpath_entry.setToolTip(
            _('Multiple path is seperated by %s') % os.pathsep)

        self.layout.addLayout(frame_grid_layout)
        if self._currentproj is not None:
            self._postpendCheckBox = QCheckBox(postpend_statictext)
            self._postpendCheckBox.setChecked(True)
            self.layout.addWidget(self._postpendCheckBox)
        # Set up selections based on last values used.
        self._filename_list = None
        self._selected_fileindex = -1
        last_project = utils.profile_get(self.GetKey("LastRunProject"))
        lastfile = utils.profile_get(self.GetKey("LastRunFile"))
        # 点击上一次配置按钮时,如果有保存上次运行的配置,则不显示对话框,否则要显示
        self._mustshow = not lastfile
        if last_project in self._projectname_list:
            selected_index = self._projectname_list.index(last_project)
        elif selected_index < 0:
            selected_index = 0
        self._projlist.setCurrentIndex(selected_index)
        self._selected_projectindex = selected_index
        self._selectedProjectDocument = self._project_documentlist[selected_index]
        self.PopulateFileList(self._selectedProjectDocument, lastfile)
        if not self._is_last_config:
            self.SetEntryParams()

        self.create_standard_buttons()
        self.ok_button.setText(okButtonName)

    def MustShowDialog(self):
        return self._mustshow

    def GetKey(self, lastPart):
        if self._currentproj:
            return self._currentproj.GetKey(lastPart)
        return lastPart

    def GetProjectFileKey(self, filepath, lastpart):
        if not self._currentproj:
            return self.GetKey(lastpart)
        if self._currentproj.GetFilename() == constants.NOT_IN_ANY_PROJECT:
            return self._currentproj.GetUnProjectFileKey(filepath, lastpart)
        pj_file = self._currentproj.GetModel().FindFile(filepath)
        if pj_file is None:
            return self.GetKey(lastpart)
        return self._currentproj.GetFileKey(pj_file, lastpart)

    def SetEntryParams(self):
        self._args_entry.lineEdit().setText("")
        if self._selected_fileindex >= 0 and len(self._filename_list) > self._selected_fileindex:
            selected_filename = self._filename_list[self._selected_fileindex]
        else:
            selected_filename = ""
        argments = utils.profile_get(self.GetProjectFileKey(
            selected_filename, "RunArguments"), "")
        self._args_entry.lineEdit().setText(argments)
        self.pythonpath_entry.setText(utils.profile_get(
            self.GetProjectFileKey(selected_filename, "PythonPath"), ""))
        startin = utils.profile_get(self.GetProjectFileKey(
            selected_filename, "RunStartIn"), "")
        self.start_entry.setText(startin)
        saved_arguments = utils.profile_get(self.GetProjectFileKey(
            selected_filename, "FileSavedArguments"), [])
        if saved_arguments:
            self._args_entry.addItems(saved_arguments)
        self.usearg_checkbox.setChecked(utils.profile_get_int(
            self.GetProjectFileKey(selected_filename, "UseArgument"), True))
        self.CheckUseArgument()
        if hasattr(self, "_postpendCheckBox"):
            if self._projectname_list[self._projlist.currentIndex()] == constants.NOT_IN_ANY_PROJECT:
                self._postpendCheckBox.setEnabled(False)
            else:
                self._postpendCheckBox.setEnabled(True)
                checked = bool(utils.profile_get_int(
                    self.GetKey("PythonPathPostpend"), True))
                self._postpendCheckBox.setChecked(checked)

    def _ok(self):
        startin = self.start_entry.text().strip()
        if self._selected_fileindex >= 0 and len(self._filename_list) > self._selected_fileindex:
            filetorun = self._filename_list[self._selected_fileindex]
        else:
            filetorun = ""
        if not filetorun:
            messagebox.showinfo(GetApp().GetAppName(), _(
                "You must select a file to proceed. Note that not all projects have files that can be run or debugged."))
            return
        isPython = utility.is_python_file(filetorun)
        if isPython and not os.path.exists(startin) and startin != '':
            QMessageBox.information(self, get_app().GetAppName(), _(
                "Starting directory does not exist. Please change this value."))
            return
        # Don't update the arguments or starting directory unless we're runing python.
        if isPython:
            utils.profile_set(self.GetProjectFileKey(
                filetorun, "RunStartIn"), startin)
            utils.profile_set(self.GetProjectFileKey(
                filetorun, "PythonPath"), self.pythonpath_entry.text().strip())
            use_args = self.usearg_checkbox.isChecked()
            utils.profile_set(self.GetProjectFileKey(
                filetorun, "UseArgument"), use_args)
            # when use argument is checked,save argument
            if use_args:
                current_arguments_text = self._args_entry.currentText()
                utils.profile_set(self.GetProjectFileKey(
                    filetorun, "RunArguments"), current_arguments_text)
                arguments = set()
                for index in range(self._args_entry.count()):
                    arguments.add(self._args_entry.itemText(index))
                arguments.add(current_arguments_text)
                values = list(arguments)
                utils.profile_set(self.GetProjectFileKey(
                    filetorun, "FileSavedArguments"), values)
            if hasattr(self, "_postpendCheckBox"):
                utils.profile_set(self.GetKey("PythonPathPostpend"),
                                  self._postpendCheckBox.isChecked())
        super()._ok()

    def GetSettings(self):
        projectpocument = self._selectedProjectDocument
        if self._selected_fileindex >= 0 and len(self._filename_list) > self._selected_fileindex:
            file_to_run = self._filename_list[self._selected_fileindex]
        else:
            file_to_run = ""
        filename = utils.profile_get(self.GetKey("LastRunFile"), file_to_run)
        args = self._lastArgumentsVar.get()
        startin = self._lastStartInVar.get().strip()
        isPython = fileutils.is_python_file(filename)
        env = {}
        if hasattr(self, "_postpendCheckBox"):
            postpend = self._postpendCheckBoxVar.get()
        else:
            postpend = False
        if postpend:
            env[consts.PYTHON_PATH_NAME] = str(self._lastPythonPathVar.get(
            )) + os.pathsep + os.path.join(os.getcwd(), "3rdparty", "pywin32")
        else:
            # should avoid environment contain unicode string,such as u'xxx'
            env[consts.PYTHON_PATH_NAME] = str(self._lastPythonPathVar.get())
        return projectpocument, filename, args, startin, isPython, env

    def OnFileSelected(self, index):
        assert index == self._filelist.currentIndex()
        self._selected_fileindex = index
        self.SetEntryParams()

    def OnFindDirClick(self):
        path = QFileDialog.getExistingDirectory(
            self, _("Choose a starting directory"), os.getcwd())
        if not path:
            return
        self.start_entry.setText(fileutils.opj(path))

    def CheckUseArgument(self):
        use_arg = self.usearg_checkbox.isChecked()
        if use_arg:
            self._args_entry.setEnabled(True)
        else:
            self._args_entry.setEnabled(False)

    def EvtListBox(self, index):
        assert index == self._projlist.currentIndex()
        if index != -1:
            self._selectedProjectDocument = self._project_documentlist[index]
            self._currentproj = self._selectedProjectDocument
            self._selected_projectindex = index
            self.PopulateFileList(self._selectedProjectDocument)
            self.SetEntryParams()

    def FilterFileList(self, file_list):
        files = filter(lambda f: utility.is_python_file(f), file_list)
        return list(files)

    def PopulateFileList(self, project, shortname_to_select=None):
        project_startup_file = project.GetStartupFile()
        if project_startup_file is None:
            pj_files = project.GetFiles()[:]
        else:
            pj_files = [project_startup_file.filePath]
        self._filename_list = self.FilterFileList(pj_files)
        self._filelist.clear()
        if not self._filename_list:
            return
        py_sorted(self._filename_list, cmp_func=lambda a, b: cmp_name(
            os.path.basename(a), os.path.basename(b)))
        strings = list(
            map(lambda file: os.path.basename(file), self._filename_list))
        for index in range(0, len(self._filename_list)):
            if shortname_to_select == self._filename_list[index]:
                self._selected_fileindex = index
                break
        self._filelist.addItems(strings)
        if self._selected_fileindex not in range(0, len(strings)):
            # Pick first bpel file if there is one.
            for index in range(0, len(strings)):
                if strings[index].endswith('.bpel'):
                    self._selected_fileindex = index
                    break
        # Still no selected file, use first file.
        if self._selected_fileindex not in range(0, len(strings)):
            self._selected_fileindex = 0
        self._filelist.setCurrentIndex(self._selected_fileindex)

    def GetProjectList(self):
        doclist = []
        namelist = []
        index = -1
        count = 0
        for document in get_app().GetDocumentManager().GetDocuments():
            if document.GetDocumentTemplate().GetDocumentType() == self._currentproj.__class__:
                doclist.append(document)
                namelist.append(os.path.basename(document.GetFilename()))
                if document == self._currentproj:
                    found = True
                    index = count
                count += 1
        # Check for open files not in any of these projects and add them to a default project

        def AlreadyInProject(filename):
            for projectdocument in doclist:
                if projectdocument.IsFileInProject(filename):
                    return True
            return False

        unprojected_files = []
        python_document_type = SyntaxThemeManager.manager().GetLexer(
            get_app().GetDefaultLangId()).GetDocTypeClass()
        for document in get_app().GetDocumentManager().GetDocuments():
            if isinstance(document, python_document_type):
                if not AlreadyInProject(document.GetFilename()):
                    unprojected_files.append(document.GetFilename())
        # 不存在于当前项目的文件,全部归入'Not in Any Project',并且虚拟一个项目文档
        if unprojected_files:
            unprojproj = self._currentproj.__class__.GetUnProjectDocument()
            unprojproj.AddFiles(unprojected_files)
            doclist.append(unprojproj)
            namelist.append(constants.NOT_IN_ANY_PROJECT)
            if self._currentproj is None:
                self._currentproj = unprojproj
                index = count
        return namelist, doclist, index
