# -*- coding: utf-8 -*-
import subprocess
from ... import get_app, _
from ...debugger import executor
from ...util import strutils, utils
from ...lib.pyqt import QMessageBox
from ..ui import show_interpreter_configuration_page


class CommonPythonexecutorMixin:
    def __init__(self):
        self.is_windows_application = self._run_parameter.IsWindowsApplication()
        # 如果是windows应用程序则使用pythonw.exe解释器来运行程序
        if self.is_windows_application:
            self._path = self._run_parameter.Interpreter.WindowPath
        # 否则默认使用python.exe
        else:
            self._path = self._run_parameter.Interpreter.path
        self._cmd = strutils.emphasis_path(self._path)
        if self._run_parameter.InterpreterOption and self._run_parameter.InterpreterOption != ' ':
            self._cmd = self._cmd + " " + self._run_parameter.InterpreterOption


class PythonExecutor(executor.Executor, CommonPythonexecutorMixin):

    def __init__(
        self,
        run_parameter,
        wxComponent,
        finish_stopped=True,
        source=executor.SOURCE_DEBUG,
        cmd_contain_path=True
    ):
        executor.Executor.__init__(
            self, run_parameter, wxComponent, finish_stopped, source)
        assert self._run_parameter.Interpreter is not None
        CommonPythonexecutorMixin.__init__(self)
        if cmd_contain_path:
            self._cmd += self.spaceAndQuote(self._run_parameter.FilePath)

        self._stdOutReader = None
        self._stdErrReader = None
        self._process = None

    @staticmethod
    def GetPythonExecutablePath():
        current_interpreter = get_app().GetCurrentInterpreter()
        if current_interpreter:
            return current_interpreter.path
        QMessageBox.information(
            get_app().GetTopWindow(),
            _("Python executable location unknown"),
            _("To proceed we need to know the location of the python.exe you would like to use.\nTo set this, go to Tools-->Options and use the 'Python Inpterpreter' panel to configuration a interpreter.\n")
        )
        show_interpreter_configuration_page()
        return None


class PythonrunExecutor(executor.TerminalExecutor, CommonPythonexecutorMixin):
    def __init__(self, run_parameter):
        executor.TerminalExecutor.__init__(self, run_parameter)
        CommonPythonexecutorMixin.__init__(self)
        self._cmd += self.spaceAndQuote(self._run_parameter.FilePath)

    def Execute(self):
        command = self.GetExecuteCommand()
        # 点击Run按钮或菜单时,如果是windows应用程序则直接使用pythonw.exe解释器来运行程序
        if self.is_windows_application:
            utils.get_logger().debug("start run executable: %s", command)
            subprocess.Popen(
                command,
                shell=False,
                cwd=self.GetStartupPath(),
                env=self._run_parameter.Environment
            )
        # 否则在控制台终端中运行程序,并且在程序运行结束时暂停,方便用户查看运行输出结果
        else:
            executor.TerminalExecutor.Execute(self)


class PythonDebuggerExecutor(PythonExecutor):

    def __init__(self,
                 debugger_fileName,
                 run_parameter,
                 wxComponent,
                 arg1=None,
                 arg2=None,
                 arg3=None,
                 arg4=None,
                 arg5=None,
                 arg6=None,
                 arg7=None,
                 arg8=None,
                 arg9=None
                 ):
        super().__init__(run_parameter, wxComponent, cmd_contain_path=False)
        self._debugger_filename = debugger_fileName
        self._cmd += self.spaceAndQuote(self._debugger_filename)

        if arg1 is not None:
            self._cmd += self.spaceAndQuote(arg1)
        if arg2 is not None:
            self._cmd += self.spaceAndQuote(arg2)
        if arg3 is not None:
            self._cmd += self.spaceAndQuote(arg3)
        if arg4 is not None:
            self._cmd += self.spaceAndQuote(arg4)
        if arg5 is not None:
            self._cmd += self.spaceAndQuote(arg5)
        if arg6 is not None:
            self._cmd += self.spaceAndQuote(arg6)
        if arg7 is not None:
            self._cmd += self.spaceAndQuote(arg7)
        if arg8 is not None:
            self._cmd += self.spaceAndQuote(arg8)
        if arg9 is not None:
            self._cmd += self.spaceAndQuote(arg9)
