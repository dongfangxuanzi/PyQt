from .... import _
from ....util import ui_utils
from ....lib.pyqt import (
    QHBoxLayout,
    QLabel,
    QFrame,
    QVBoxLayout,
    QHeaderView,
    QTableWidget,
    QPushButton,
    QLineEdit,
    Qt,
    QTableWidgetItem,
    QMessageBox,
    QAbstractItemView
)


class EnvironmentVariableDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, title):
        super().__init__(title, parent)

        key_hbox = QHBoxLayout()
        key_hbox.addWidget(QLabel(_("Key") + ": "))
        self.key_ctrl = QLineEdit()
        key_hbox.addWidget(self.key_ctrl)
        self.layout.addLayout(key_hbox)

        value_hbox = QHBoxLayout()
        value_hbox.addWidget(QLabel(_("Value") + ":"))
        self.value_ctrl = QLineEdit()
        value_hbox.addWidget(self.value_ctrl)
        self.layout.addLayout(value_hbox)

        self.create_standard_buttons()


class BaseEnvironmentUI(QFrame):
    """description of class"""

    def __init__(self, master):
        QFrame.__init__(self, master)

        self._frame_layout = QVBoxLayout()
        self._frame_layout.setContentsMargins(0, 0, 0, 0)
        self.InitUI()
        self.setLayout(self._frame_layout)

    def InitUI(self):
        self._frame_layout.addWidget(
            QLabel(_("Set user defined environment variable") + ":"))
        hbox = QHBoxLayout()
        columns = [_('Key'), _('Value')]
        self.table = QTableWidget(0, len(columns), self)
        self.table.setHorizontalHeaderLabels(columns)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.itemSelectionChanged.connect(self.UpdateUI)
        hbox.addWidget(self.table)
        right_box = QVBoxLayout()
        right_box.setContentsMargins(0, 0, 5, 5)
        right_box.setAlignment(Qt.AlignTop)
        self.new_btn = QPushButton(_("New.."))
        self.new_btn.clicked.connect(self.NewVariable)
        right_box.addWidget(self.new_btn)

        self.edit_btn = QPushButton(_("Edit."))
        self.edit_btn.clicked.connect(self.EditVariable)
        right_box.addWidget(self.edit_btn)

        self.remove_btn = QPushButton(_("Remove"))
        self.remove_btn.clicked.connect(self.RemoveVariable)
        right_box.addWidget(self.remove_btn)
        hbox.addLayout(right_box)

        self._frame_layout.addLayout(hbox)

    def UpdateUI(self):
        selection = self.table.currentItem()
        if not selection:
            self.remove_btn.setEnabled(False)
            self.edit_btn.setEnabled(False)
        else:
            self.remove_btn.setEnabled(True)
            self.edit_btn.setEnabled(True)

    def RemoveVariable(self):
        # 获取选中单元格
        selections = self.table.selectedItems()
        if not selections:
            return
        # 获取选中单元格的行号列表,去重
        rows = set([item.row() for item in selections])
        self.RemoveRowVariable(rows)
        self.UpdateUI()

    def RemoveRowVariable(self, select_rows):
        for row in select_rows:
            self.table.removeRow(row)

    def GetVariableRow(self, key):
        count = self.dvlc.GetStore().GetCount()
        for i in range(count):
            if self.dvlc.GetTextValue(i, 0) == key:
                return i
        return -1

    def AddVariable(self, key, value):
        # 检查变量是否存在
        if self.CheckAndRemoveKeyitem(key):
            insertrow = 0
            self.table.insertRow(insertrow)
            keyitem = QTableWidgetItem(key)
            self.table.setItem(insertrow, 0, keyitem)
            valueitem = QTableWidgetItem(value)
            self.table.setItem(insertrow, 1, valueitem)

    def NewVariable(self):
        dlg = EnvironmentVariableDialog(self, _("New environ variable"))
        status = dlg.exec_()
        key = dlg.key_ctrl.text().strip()
        value = dlg.value_ctrl.text().strip()
        if status == EnvironmentVariableDialog.Accepted and key:
            self.AddVariable(key, value)
        self.UpdateUI()

    def EditVariable(self):
        row = self.table.currentRow()
        if row < 0:
            return
        dlg = EnvironmentVariableDialog(self, _("Edit environ variable"))
        keyitem = self.table.item(row, 0)
        old_key = keyitem.text()
        valueitem = self.table.item(row, 1)
        old_value = valueitem.text()
        dlg.key_ctrl.setText(old_key)
        dlg.value_ctrl.setText(old_value)
        status = dlg.exec_()
        key = dlg.key_ctrl.text().strip()
        value = dlg.value_ctrl.text().strip()
        if status == EnvironmentVariableDialog.Accepted and key and value != old_value:
            keyitem = QTableWidgetItem(key)
            self.table.setItem(row, 0, keyitem)
            valueitem = QTableWidgetItem(value)
            self.table.setItem(row, 1, valueitem)
        self.UpdateUI()

    def CheckAndRemoveKeyitem(self, key):
        row = self.CheckKeyItem(key)
        if row > -1:
            ret = QMessageBox.question(
                self,
                _("Warning"),
                _("Key name has already exist in environment variable,Do you wann't to overwrite it?"),
            )
            if ret == QMessageBox.Yes:
                self.RemoveRowVariable([row])
            else:
                return False
        return True

    def CheckKeyItem(self, key):
        '''
            检查环境变量是否已经存在,注意环境变量不区分大小写
        '''
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item is None:
                continue
            # 环境变量不区分大小写
            if item.text().lower() == key.lower():
                return row
        return -1

    def GetEnviron(self):
        dct = {}
        for row in range(self.table.rowCount()):
            keyitem = self.table.item(row, 0)
            if keyitem is None:
                continue
            valueitem = self.table.item(row, 1)
            dct[keyitem.text()] = valueitem.text()
        return dct
