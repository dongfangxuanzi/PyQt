# -*- coding: utf-8 -*-
import copy
import os
from .... import _, get_app
from ...interpreter.interpretermanager import InterpreterManager
from ....project import variables
from .. import configuration
from ....util import ui_utils, utils, fileutils
from .environment import BaseEnvironmentUI
from ....lib.pyqt import (
    QHBoxLayout,
    QLabel,
    QTextEdit,
    QGroupBox,
    QListWidgetItem,
    QFileDialog,
    Qt,
    QRadioButton,
    QTabWidget,
    QSizePolicy,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QComboBox,
    QListWidget,
    QVBoxLayout,
    QCheckBox
)
from .... import qtimage
from ... import utility
from ....widgets.separator import Separator
from .runui import SelectModuleFileDialog, ProjectFolderPathDialog
from ...interpreter.combo import InterpreterComboBox


class BasePage(ui_utils.BaseConfigurationPanel):

    def __init__(self, parent, run_configuration):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.run_configuration = run_configuration
        self._parent = parent

    def GetConfiguration(self):
        return None

    @property
    def ProjectDocument(self):
        return self.run_configuration.ProjectDocument

    @property
    def MainModuleFile(self):
        return self.run_configuration.MainModuleFile


class StartupPage(BasePage):
    def __init__(self, parent, run_configuration):
        BasePage.__init__(self, parent, run_configuration)
        sbox = QGroupBox(_("Project") + ":")
        group_box_layout = QHBoxLayout()

        group_box_layout.addWidget(QLabel(_('Project name') + ":"))
        self.__projectname_editctrl = QLineEdit()
        self.__projectname_editctrl.setText(
            self.ProjectDocument.GetModel().Name)
        self.__projectname_editctrl.setReadOnly(True)
        group_box_layout.addWidget(self.__projectname_editctrl)
        sbox.setLayout(group_box_layout)
        self.layout.addWidget(sbox)

        sbox = QGroupBox(_("Startup module") + ":")
        group_box_layout = QHBoxLayout()
        group_box_layout.addWidget(QLabel(_('Main module') + ":"))
        self.main_module_edit = QLineEdit()
        group_box_layout.addWidget(self.main_module_edit)
        sbox.setLayout(group_box_layout)
        self.layout.addWidget(sbox)

        if self.MainModuleFile is not None:
            main_module_path = self.ProjectDocument.GetModel()\
                .GetRelativePath(self.MainModuleFile)
            main_module_path = os.path.join(
                variables.create_variable_name(variables.PROJECT_DIR_VARIABLE),
                main_module_path
            )
            self.main_module_edit.setText(main_module_path)
            browser_btn = QPushButton(_("Browse..."))
            browser_btn.clicked.connect(self.BrowseMainModule)
            group_box_layout.addWidget(browser_btn)

        sbox = QGroupBox(_("Startup directory") + ":")
        group_box_layout = QVBoxLayout()
        default_startup_box = QHBoxLayout()
        self.__defaultradio_btn = QRadioButton(_("Default") + ":")
        self.__defaultradio_btn.setChecked(False)
        self.__defaultradio_btn.clicked.connect(self.CheckDefaultPath)
        default_startup_box.addWidget(self.__defaultradio_btn)

        self.__defaultdir_control = QLineEdit()
        self.__defaultdir_control.setText(
            variables.create_variable_name(variables.PROJECT_DIR_VARIABLE))
        default_startup_box.addWidget(self.__defaultdir_control)
        group_box_layout.addLayout(default_startup_box)

        other_startup_box = QHBoxLayout()
        self.__otherradio_btn = QRadioButton(_("Other") + ":")
        self.__otherradio_btn.clicked.connect(self.CheckOtherPath)
        other_startup_box.addWidget(self.__otherradio_btn)
        self.__otherdir_control = QLineEdit()
        other_startup_box.addWidget(self.__otherdir_control)
        group_box_layout.addLayout(other_startup_box)

        btn_hbox = QHBoxLayout()
        btn_hbox.setAlignment(Qt.AlignRight)
        self.project_folder_btn = QPushButton(_("Project folder"))
        self.project_folder_btn.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.project_folder_btn.clicked.connect(self.BrowseProjectFolder)
        btn_hbox.addWidget(self.project_folder_btn)

        self.file_system_btn = QPushButton(_("Local file system"))
        self.file_system_btn.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.file_system_btn.clicked.connect(self.BrowseLocalPath)
        btn_hbox.addWidget(self.file_system_btn)

        self.variables_btn = QPushButton(_("Variables"))
        self.variables_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.variables_btn.clicked.connect(self.BrowseVariables)
        btn_hbox.addWidget(self.variables_btn)
        group_box_layout.addLayout(btn_hbox)
        sbox.setLayout(group_box_layout)

        startup_configuration = run_configuration.GetChildConfiguration(
            configuration.StartupConfiguration.CONFIGURATION_NAME
        )
        self._startup_path_pattern = startup_configuration.StartupPathPattern
        if self._startup_path_pattern == configuration.StartupConfiguration.DEFAULT_PROJECT_DIR_PATH:
            self.__defaultradio_btn.setChecked(True)
        else:
            self.__otherradio_btn.setChecked(True)
            self.__otherdir_control.setText(startup_configuration.StartupPath)

        self.layout.addWidget(sbox)
        self.UpdateButtonUI()

    def CheckDefaultPath(self):
       #     self._defaultVar.set(0)
        self.UpdateButtonUI()

    def CheckOtherPath(self):
      #      self._defaultVar.set(1)
        self.UpdateButtonUI()

    def UpdateButtonUI(self):
        if self.__defaultradio_btn.isChecked():
            self.__defaultdir_control.setEnabled(True)
            self.__otherdir_control.setEnabled(False)
            self.project_folder_btn.setEnabled(False)
            self.file_system_btn.setEnabled(False)
            self.variables_btn.setEnabled(False)
            self._startup_path_pattern = configuration.StartupConfiguration.DEFAULT_PROJECT_DIR_PATH
        else:
            self.__otherdir_control.setEnabled(True)
            self.__defaultdir_control.setEnabled(False)
            self.project_folder_btn.setEnabled(True)
            self.file_system_btn.setEnabled(True)
            self.variables_btn.setEnabled(True)
            self._startup_path_pattern = configuration.StartupConfiguration.LOCAL_FILE_SYSTEM_PATH

    def BrowseLocalPath(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog | QFileDialog.ShowDirsOnly
        dirname = QFileDialog.getExistingDirectory(
            self, _("Select the startup path"), self.__otherdir_control.text(),
            options)
        if dirname:
            self._startup_path_pattern = configuration.StartupConfiguration.LOCAL_FILE_SYSTEM_PATH
            self.__otherdir_control.setText(fileutils.opj(dirname))

    def BrowseProjectFolder(self):
        dlg = ProjectFolderPathDialog(
            self, _("Select project folder"), self.ProjectDocument.GetModel())
        if dlg.exec_() == ProjectFolderPathDialog.Accepted:
            selected_path = dlg.selected_path
            if selected_path is not None:
                selected_path = os.path.join(
                    variables.create_variable_name(
                        variables.PROJECT_DIR_VARIABLE),
                    selected_path
                )
            else:
                selected_path = variablesutils.FormatVariableName(
                    variablesutils.PROJECT_DIR_VARIABLE)
            self.__otherdir_control.setText(selected_path)
            self._startup_path_pattern = configuration.StartupConfiguration.PROJECT_CHILD_FOLDER_PATH

    def BrowseVariables(self):
        variable_dlg = variables.VariablesDialog(
            self, _("Select variable"), self.ProjectDocument)
        if variable_dlg.exec_() == variable_dlg.Accepted:
            self.__otherdir_control.setText(
                variable_dlg.selected_variable_name)
            self._startup_path_pattern = configuration.StartupConfiguration.EXPRESSION_VALIABLE_PATH

    def BrowseMainModule(self):
        dlg = SelectModuleFileDialog(
            self, _("Select main module"), self.ProjectDocument.GetModel())
        if dlg.exec_() == SelectModuleFileDialog.Accepted:
            main_module_path = os.path.join(
                variables.create_variable_name(variables.PROJECT_DIR_VARIABLE),
                self.ProjectDocument.GetModel().GetRelativePath(dlg.module_file)
            )
            self.main_module_var.set(main_module_path)
            self.run_configuration.MainModuleFile = dlg.module_file

    def OnOK(self):
        try:
            main_module_path = self.main_module_edit.text().strip()
            python_variable_manager = variables.GetProjectVariableManager(
                self.ProjectDocument)
            main_module_path = python_variable_manager.EvalulateValue(
                main_module_path)

            other_startup_path = self.__otherdir_control.text().strip()
            other_startup_path = python_variable_manager.EvalulateValue(
                other_startup_path)

        except RuntimeError as e:
            messagebox.showerror(_("Error"), str(e), parent=self)
            return False

        main_module_file = self.ProjectDocument.GetModel().FindFile(main_module_path)
        if not main_module_file:
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _("Module file \"%s\" is not in project") % main_module_path
            )
            return False
        return True

    def GetConfiguration(self):
        return configuration.StartupConfiguration(
            self.ProjectDocument,
            self.MainModuleFile,
            self._startup_path_pattern,
            self.__otherdir_control.text().strip()
        )


class ArgumentsPage(BasePage):
    def __init__(self, parent, run_configuration):
        BasePage.__init__(self, parent, run_configuration)
        arguments_configuration = run_configuration.GetChildConfiguration(
            configuration.AugumentsConfiguration.CONFIGURATION_NAME)

        sbox = QGroupBox(_("Program Arguments") + ":")
        group_box_layout = QVBoxLayout()
        self.program_argument_textctrl = QTextEdit()
        self.program_argument_textctrl.setText(
            arguments_configuration.ProgramArgs)
        group_box_layout.addWidget(self.program_argument_textctrl)

        variables_btn = QPushButton(_("Variables"))
        variables_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        variables_btn.clicked.connect(self.BrowseVariables)
        group_box_layout.addWidget(variables_btn)
        sbox.setLayout(group_box_layout)
        self.layout.addWidget(sbox)

        sbox = QGroupBox(_("Interpreter Options") + ":")
        group_box_layout = QVBoxLayout()
        self.interpreter_option_textctrl = QTextEdit()
        self.interpreter_option_textctrl.setText(
            arguments_configuration.InterpreterOption)
        group_box_layout.addWidget(self.interpreter_option_textctrl)
        sbox.setLayout(group_box_layout)
        self.layout.addWidget(sbox)

    def BrowseVariables(self):
        variable_dlg = variables.VariablesDialog(
            self, _("Select variable"), self.ProjectDocument)
        if variable_dlg.exec_() == variable_dlg.Accepted:
            self.program_argument_textctrl.insertPlainText(
                variable_dlg.selected_variable_name + " ")

    def OnOK(self):
        try:
            self.GetArgumentsText()
        except RuntimeError as e:
            messagebox.showerror(_("Error"), str(e), parent=self)
            return False
        return True

    def GetArgumentsText(self):
        python_variable_manager = variables.GetProjectVariableManager(
            self.ProjectDocument)
        arguments_text = python_variable_manager.EvalulateValue(
            self.program_argument_textctrl.toPlainText()
        )
        return arguments_text

    def GetConfiguration(self):
        main_module_file = self.parent().parent().parent().GetMainModuleFile()
        return configuration.AugumentsConfiguration(
            self.ProjectDocument,
            main_module_file,
            self.interpreter_option_textctrl.toPlainText(),
            self.program_argument_textctrl.toPlainText()
        )


class InterpreterConfigurationPage(BasePage):
    def __init__(self, parent, run_configuration):
        BasePage.__init__(self, parent, run_configuration)
        interpreter_configuration = run_configuration.GetChildConfiguration(
            configuration.InterpreterConfiguration.CONFIGURATION_NAME)
        self.layout.addWidget(QLabel(_("Interpreter") + ":"))
        self.__interpreterscombo = InterpreterComboBox()
        self.layout.addWidget(self.__interpreterscombo)
        self.layout.addWidget(
            QLabel(_("PYTHONPATH that will be used in the run") + ":"))
        self.listbox = QListWidget()
        self.layout.addWidget(self.listbox)
        self.__interpreterscombo.currentIndexChanged.connect(
            self.GetInterpreterPythonPath)
        # 这里会触发上面的事件
        self.SetCurrentInterpreterName(interpreter_configuration)

    def SetCurrentInterpreterName(self, interpreter_configuration):
        interpreter_name = interpreter_configuration.InterpreterName
        if interpreter_name:
            nameindex = self.__interpreterscombo.find_interpreter_index(
                interpreter_name)
            self.__interpreterscombo.setCurrentIndex(nameindex)

    def GetInterpreterPythonPath(self, i):
        self.listbox.clear()
        interpreter = self.__interpreterscombo.get_interpreter(i)
        interpreter_name = interpreter.name
        self.AppendInterpreterPythonPath(interpreter_name)

    def AppendInterpreterPythonPath(self, interpreter_name):
        interpreter = InterpreterManager.manager().GetInterpreterByName(interpreter_name)
        if interpreter is None:
            return
        # 拷贝一份列表否则会修改原列表
        values = copy.copy(interpreter.python_path_list)
        proprty_dlg = self._parent.parent().property_dlg
        if proprty_dlg.HasPanel(_("Project References")):
            project_reference_panel = proprty_dlg.GetOptionPanel(
                _("Project References"))
            for project_filename in project_reference_panel.GetReferenceProjects():
                values.append(os.path.dirname(project_filename))
            python_path_panel = proprty_dlg.GetOptionPanel('PythonPath')
            values.extend(python_path_panel.GetPythonPathList())
            self.listbox.addItems(values)
        else:
            project_configuration = configuration.ProjectConfiguration(
                self.ProjectDocument)
            self.listbox.addItems(project_configuration.LoadPythonPath())

    def GetConfiguration(self):
        main_module_file = self._parent.parent().GetMainModuleFile()
        return configuration.InterpreterConfiguration(
            self.ProjectDocument,
            main_module_file,
            self.__interpreterscombo.GetChooseInterpreter().name
        )

    def CheckInterpreterExist(self):
        interpreter_name_index = self.__interpreterscombo.currentIndex()
        if interpreter_name_index < 0:
            return False
        interpreter_name = self.__interpreterscombo[interpreter_name_index]
        interpreter = InterpreterManager().GetInterpreterByName(interpreter_name)
        if interpreter is None:
            raise InterpreterNotExistError(interpreter_name)
        return True

    def OnOK(self):
        return True


class InputOutputPage(ui_utils.BaseConfigurationPanel):
    def __init__(self, parent, dlg_id, size):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)


class EnvironmentPage(BasePage):
    def __init__(self, parent, run_configuration):
        BasePage.__init__(self, parent, run_configuration)
        self.mainframe = BaseEnvironmentUI(self)
        self.layout.addWidget(self.mainframe)
        self.LoadEnvironments()
        self.mainframe.UpdateUI()

    def LoadEnvironments(self,):
        environs = self.run_configuration.GetChildConfiguration(
            configuration.EnvironmentConfiguration.CONFIGURATION_NAME
        ).Environ
       # self.mainframe.RemoveRowVariable(self.listview.tree.get_children())
        for env in environs:
            self.mainframe.AddVariable(env, environs[env])
        self.mainframe.UpdateUI()

    def GetConfiguration(self):
        environ = self.mainframe.GetEnviron()
        main_module_file = self.parent().parent().parent().GetMainModuleFile()
        return configuration.EnvironmentConfiguration(
            self.ProjectDocument,
            main_module_file,
            environ
        )

    def OnOK(self):
        return True


class RunConfigurationDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, title, run_configuration):
        super().__init__(title, parent)
        self.property_dlg = parent.property_dlg
        self.current_project_document = run_configuration.ProjectDocument
        self.selected_project_file = run_configuration.MainModuleFile
        sizer_layout = QHBoxLayout()
        if run_configuration.IsNewConfiguration:
            st_text = QLabel(_("New Debug/Run Configuration"))
        else:
            st_text = QLabel(_("Edit Debug/Run Configuration"))
        st_text.setStyleSheet("font-size:13px;font-weight:bold;")
        sizer_layout.addWidget(st_text)
        show_img = qtimage.load_image("project/run_wizard.png")
        show_label = QLabel()
        show_label.setPixmap(show_img)
        show_label.adjustSize()
        show_label.setSizePolicy(QSizePolicy.Fixed,
                                 QSizePolicy.Fixed)

        sizer_layout.addWidget(show_label)
        self.layout.addLayout(sizer_layout)
        separator = Separator()
        self.layout.addWidget(separator)

        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel(_('Name') + ":"))

        self.name_edit = QLineEdit()
        self.name_edit.setText(run_configuration.Name)
        name_layout.addWidget(self.name_edit)
        self.layout.addLayout(name_layout)

        self.nb = QTabWidget(self)
        self.startup_icon = qtimage.load_icon("project/python/startup.png")
        self.arguments_icon = qtimage.load_icon("project/python/parameter.png")
        self.interpreter_icon = qtimage.load_icon("python/interpreter.ico")
        self.environment_icon = qtimage.load_icon("environment.png")

        self.startup_panel = StartupPage(self.nb, run_configuration)
        index = self.nb.addTab(self.startup_panel, _("Startup"))
        self.nb.setTabIcon(index, self.startup_icon)

        self.arguments_panel = ArgumentsPage(self.nb, run_configuration)
        index = self.nb.addTab(self.arguments_panel, _("Arguments"))
        self.nb.setTabIcon(index, self.arguments_icon)

        self.interpreter_panel = InterpreterConfigurationPage(
            self.nb, run_configuration)
        index = self.nb.addTab(self.interpreter_panel, _("Interpreter"))
        self.nb.setTabIcon(index, self.interpreter_icon)

        self.environment_panel = EnvironmentPage(self.nb, run_configuration)
        index = self.nb.addTab(self.environment_panel, _("Environment"))
        self.nb.setTabIcon(index, self.environment_icon)
        self.layout.addWidget(self.nb)

        self.create_standard_buttons()

    def _ok(self):
        run_configuration_name = self.name_edit.text().strip()
        if run_configuration_name == "":
            QMessageBox.critical(self, get_app().GetAppName(), _(
                "A name is required for the configuration"))
            return
        for tab_index in range(self.nb.count()):
            panel = self.nb.widget(tab_index)
            if hasattr(panel, "OnOK") and not panel.OnOK():
                return
        args = {
            configuration.StartupConfiguration.CONFIGURATION_NAME: self.startup_panel.GetConfiguration(),
            configuration.AugumentsConfiguration.CONFIGURATION_NAME: self.arguments_panel.GetConfiguration(),
            configuration.InterpreterConfiguration.CONFIGURATION_NAME: self.interpreter_panel.GetConfiguration(),
            configuration.EnvironmentConfiguration.CONFIGURATION_NAME: self.environment_panel.GetConfiguration(),
        }
        self.run_configuration = configuration.RunConfiguration(
            run_configuration_name, **args)
        super()._ok()

    def GetMainModuleFile(self):
        return self.startup_panel.MainModuleFile


class DebugRunPanel(ui_utils.BaseConfigurationPanel):
    """description of class"""

    def __init__(self, parent, item, current_project):
        super().__init__()
        self.property_dlg = parent
        self._configuration_list = []
        self.current_project_document = current_project
        project_view = self.current_project_document.GetFirstView()
        self.select_project_file = None
        self.is_folder = False
        if item == project_view._treeCtrl.GetRootItem():
            self.layout.addWidget(
                QLabel(_("Set the default startup file when run project.")))
            startup_file_path = ''
            startup_file = self.current_project_document.GetModel().StartupFile
            if startup_file is not None:
                startup_file_path = self.current_project_document.GetModel().GetRelativePath(startup_file)
                startup_file_path = os.path.join(
                    variables.create_variable_name(
                        variables.PROJECT_DIR_VARIABLE),
                    startup_file_path
                )
            startupbox = QHBoxLayout()
            self.startup_path_combox = QComboBox()
            self.startup_path_combox.setEditable(True)
            if startup_file_path:
                self.startup_path_combox.addItem(startup_file_path)
            startupbox.addWidget(self.startup_path_combox)
            startupbutn = QPushButton(_("Select the startup file"))
            startupbutn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            startupbutn.clicked.connect(self.SetStartupFile)
            startupbox.addWidget(startupbutn)
            self.layout.addLayout(startupbox)
        elif project_view._IsItemFile(item):
            self.select_project_file = project_view._GetItemFile(item)
        else:
            self.is_folder = True
        self.layout.addWidget(QLabel(
            _("You can manage launch run configurations and set default configuration as belows.\n")))
        self.layout.addWidget(
            QLabel(_("Set run configurations for project '%s':") % self.GetProjectName()))

        configbox = QHBoxLayout()
        self.configuration_listctrl = QListWidget()
        self.configuration_listctrl.itemSelectionChanged.connect(self.UpdateUI)
        self.configuration_listctrl.doubleClicked.connect(
            self.EditRunConfiguration)
        configbox.addWidget(self.configuration_listctrl)
        rightbox = QVBoxLayout()
        rightbox.setAlignment(Qt.AlignTop)
        self.run_config_img = qtimage.load_icon("project/python/runconfig.png")

        self.new_configuration_btn = QPushButton(_("New"))
        self.new_configuration_btn.clicked.connect(self.NewRunConfiguration)
        rightbox.addWidget(self.new_configuration_btn)
        self.edit_configuration_btn = QPushButton(_("Edit"))
        self.edit_configuration_btn.clicked.connect(self.EditRunConfiguration)
        rightbox.addWidget(self.edit_configuration_btn)
        self.remove_configuration_btn = QPushButton(_("Remove"))
        self.remove_configuration_btn.clicked.connect(self.RemoveConfiguration)
        rightbox.addWidget(self.remove_configuration_btn)
        self.copy_configuration_btn = QPushButton(_("Copy"))
        self.copy_configuration_btn.clicked.connect(self.CopyConfiguration)
        rightbox.addWidget(self.copy_configuration_btn)
        configbox.addLayout(rightbox)
        self.layout.addLayout(configbox)
        # windows系统添加一个选项,如果是windows程序,则调用解释器可执行程序pythonw.exe
        if utils.is_windows():
            self.isWindowsApplicationCheckBox = QCheckBox(
                _("Windows application"))
            is_windows_application = utils.profile_get_int(
                self.current_project_document.GetKey('IsWindowsApplication'), False)
            self.isWindowsApplicationCheckBox.setChecked(
                is_windows_application)
            self.layout.addWidget(self.isWindowsApplicationCheckBox)
        # should use Layout ,could not use Fit method
        # disable all buttons when file is not python file or is folder
        if not self.IsPythonFile() or self.is_folder or InterpreterManager.manager().GetCurrentInterpreter() is None:
            self.edit_configuration_btn.setEnabled(False)
            self.remove_configuration_btn.setEnabled(False)
            self.new_configuration_btn.setEnabled(False)
            self.copy_configuration_btn.setEnabled(False)
        self.UpdateUI()
        # folder or package folder has no run configurations
        if not self.is_folder:
            self.LoadConfigurations()

    def GetProjectName(self):
        return os.path.basename(self.current_project_document.GetFilename())

    def IsPythonFile(self):
        if self.select_project_file is not None and \
                not utility.is_python_file(self.select_project_file.filePath):
            return False
        return True

    def GetStartupFile(self, prompt_error=True):
        try:
            startup_file_path = self.startup_path_combox.lineEdit().text()
            python_variable_manager = variables.GetProjectVariableManager(
                self.current_project_document)
            startup_file_path = python_variable_manager.EvalulateValue(
                startup_file_path)
        except RuntimeError as e:
            if prompt_error:
                wx.MessageBox(e.msg, _("Error"), wx.OK | wx.ICON_ERROR, self)
            return None
        startup_file = self.current_project_document.GetModel().FindFile(startup_file_path)
        if not startup_file:
            if prompt_error:
                QMessageBox.critical(
                    self,
                    get_app().GetAppName(),
                    _("File \"%s\" is not in project") % startup_file_path
                )
            return None
        return startup_file

    def RemoveFileConfigurations(self, project_file):
        if project_file is None:
            key_path = self.current_project_document.GetKey()
            utils.profile_set(key_path + "/ConfigurationList", [].__repr__())
            utils.profile_set(key_path + "/RunConfigurationName", "")
            return
        config = get_app().GetConfig()
        key_path = self.current_project_document.GetFileKey(project_file)
        names = []
        config.GetGroups(key_path, names)
        for name in names:
            group_path = key_path + "/" + name
            config.DeleteGroup(group_path)
        utils.profile_set(key_path + "/ConfigurationList", [].__repr__())
        utils.profile_set(key_path + "/RunConfigurationName", "")

    def OnOK(self, options_dialog):
        # when is the property of project,check the startup file
        # folder item will not get startup file
        if self.select_project_file is None and not self.is_folder:
            startup_file = self.GetStartupFile()
            if not startup_file:
                return False
            if not startup_file.IsStartup:
                item = self.current_project_document.GetFirstView(
                )._treeCtrl.FindItem(startup_file.filePath)
                self.current_project_document.GetFirstView().SetProjectStartupFileItem(item)
        # remove all configurations first
        self.RemoveFileConfigurations(self.select_project_file)
        for run_configuration in self._configuration_list:
            run_configuration.SaveConfiguration()

        selected_item_index = self.GetSelectIndex()
        if -1 == selected_item_index:
            return True
        selected_configuration_name = ""
        selected_configuration_name = self._configuration_list[selected_item_index].Name
        if self.select_project_file is None:
            pj_key = self._configuration_list[0].ProjectDocument.GetKey()
            new_configuration_names = []
            for i, run_configuration in enumerate(self._configuration_list):
                last_part = run_configuration.GetRootKeyPath().split("/")[-1]
                new_configuration_names.append(
                    last_part + "/" + self._configuration_list[i].Name)

                file_configuration = configuration.FileConfiguration(
                    self.current_project_document, run_configuration.MainModuleFile)
                file_configuration_sets = set(
                    file_configuration.LoadConfigurationNames())
                # use sets to avoid repeat add configuration_name
                file_configuration_sets.add(self._configuration_list[i].Name)
                file_configuration_list = list(file_configuration_sets)
                pj_file_key = run_configuration.GetRootKeyPath()
                # update file configuration list
                utils.profile_set(
                    pj_file_key + "/ConfigurationList", file_configuration_list)
                if selected_configuration_name == self._configuration_list[i].Name:
                    selected_configuration_name = last_part + "/" + selected_configuration_name
            utils.profile_set(pj_key + "/ConfigurationList",
                              new_configuration_names)
            utils.profile_set(pj_key + "/RunConfigurationName",
                              selected_configuration_name)
        else:
            pj_file_key = self._configuration_list[0].GetRootKeyPath()
            configuration_names = [
                run_configuration.Name for run_configuration in self._configuration_list]
            utils.profile_set(
                pj_file_key + "/ConfigurationList", configuration_names)
            utils.profile_set(
                pj_file_key + "/RunConfigurationName", selected_configuration_name)
        if utils.is_windows():
            utils.profile_set(
                self.current_project_document.GetKey('IsWindowsApplication'),
                self.isWindowsApplicationCheckBox.isChecked()
            )
        return True

    def SetStartupFile(self):
        dlg = SelectModuleFileDialog(
            self,
            _("Select the startup file"),
            self.current_project_document.GetModel(),
            True
        )
        if SelectModuleFileDialog.Accepted == dlg.exec_():
            startup_path = os.path.join(
                variables.create_variable_name(variables.PROJECT_DIR_VARIABLE),
                self.current_project_document.GetModel().GetRelativePath(dlg.module_file)
            )
            self.startup_path_combox.lineEdit().setText(startup_path)

    def GetConfigurationName(self, default_configuration_name=None):
        if default_configuration_name is None:
            default_configuration_name = configuration.RunConfiguration.DEFAULT_CONFIGURATION_NAME
        configuration_name = default_configuration_name
        i = 2
        while True:
            for run_configuration in self._configuration_list:
                if run_configuration.Name == configuration_name:
                    configuration_name = default_configuration_name + \
                        "(" + str(i) + ")"
                    i += 1
            break
        return configuration_name

    def IsConfigurationNameExist(self, configuration_name, prompt_msg=True):
        for run_configuration in self._configuration_list:
            if run_configuration.Name == configuration_name:
                if prompt_msg:
                    QMessageBox.information(self, get_app().GetAppName(), _(
                        "configuration name is already in used!"))
                return True
        return False

    def NewRunConfiguration(self):
        run_file = self.select_project_file
        if not run_file:
            run_file = self.GetStartupFile(False)
        current_interpreter = InterpreterManager.manager().GetCurrentInterpreter()
        if self.property_dlg.HasPanel(_("Interpreter")):
            interpreter_panel = self.property_dlg.GetOptionPanel(
                _("Interpreter"))
            current_interpreter = interpreter_panel.GetInterpreter()
        run_configuration = configuration.RunConfiguration.CreateNewConfiguration(
            self.current_project_document, current_interpreter, run_file, self.GetConfigurationName())
        init_configuration_name = run_configuration.Name
        if self.select_project_file is None:
            run_configuration.Name = "%s %s" % (
                self.GetProjectName(), init_configuration_name)
            if run_file is not None:
                run_configuration.Name = "%s %s" % (
                    self.GetProjectName(), os.path.basename(run_file.filePath))
            run_configuration.Name = self.GetConfigurationName(
                run_configuration.Name)

        dlg = RunConfigurationDialog(
            self, _("New configuration"), run_configuration)
        status = dlg.exec_()
        if RunConfigurationDialog.Accepted == status:
            if not self.IsConfigurationNameExist(dlg.run_configuration.Name):
                self.add_configuration_item(dlg.run_configuration.Name)
                self._configuration_list.append(dlg.run_configuration)

    def add_configuration_item(self, name):
        configurationitem = QListWidgetItem(name)
        configurationitem.setIcon(self.run_config_img)
        self.configuration_listctrl.addItem(configurationitem)
        self.configuration_listctrl.setCurrentItem(configurationitem)
        return configurationitem

    def EditRunConfiguration(self):
        index = self.configuration_listctrl.currentRow()
        if index == -1:
            return
        run_configuration = self._configuration_list[index]
        run_configuration.IsNewConfiguration = False
        dlg = RunConfigurationDialog(
            self, _("Edit configuration"), run_configuration)
        if RunConfigurationDialog.Accepted == dlg.exec_():
            select_item = self.configuration_listctrl.currentItem()
            self._configuration_list[index] = dlg.run_configuration
            # 如果配置名称修改,更改节点名称
            if select_item.text() != dlg.run_configuration.Name:
                self.configuration_listctrl.item(
                    select_item, text=dlg.run_configuration.Name)

    def RemoveConfiguration(self):
        select_index = self.configuration_listctrl.currentRow()
        if select_index == -1:
            return
        self._configuration_list.remove(self._configuration_list[select_index])
        self.configuration_listctrl.takeItem(select_index)
        self.UpdateUI()

    def GetSelectIndex(self, item=None):
        if item is None:
            item = self.configuration_listctrl.currentItem()
            if not item:
                return -1
        for i in range(self.configuration_listctrl.count()):
            child = self.configuration_listctrl.item(i)
            if item == child:
                return i
        return -1

    def CopyConfiguration(self):
        index = self.configuration_listctrl.currentRow()
        if -1 == index:
            return
        run_configuration = self._configuration_list[index]
        copy_run_configuration = run_configuration.Clone()
        copy_run_configuration_name = copy_run_configuration.Name + "(copy)"
        i = 2
        while self.IsConfigurationNameExist(copy_run_configuration_name, prompt_msg=False):
            copy_run_configuration_name = copy_run_configuration.Name + \
                "(copy%d)" % (i,)
            i += 1
        copy_run_configuration.Name = copy_run_configuration_name
        self.add_configuration_item(copy_run_configuration.Name)
        self._configuration_list.append(copy_run_configuration)

    def UpdateUI(self):
        current_index = self.configuration_listctrl.currentRow()
        if current_index == -1:
            self.remove_configuration_btn.setEnabled(False)
            self.edit_configuration_btn.setEnabled(False)
            self.copy_configuration_btn.setEnabled(False)
        else:
            self.remove_configuration_btn.setEnabled(True)
            self.edit_configuration_btn.setEnabled(True)
            self.copy_configuration_btn.setEnabled(True)

    def LoadConfigurations(self):
        if self.select_project_file is not None:
            file_configuration = configuration.FileConfiguration(
                self.current_project_document, self.select_project_file)
            self._configuration_list = file_configuration.LoadConfigurations()
            selected_configuration_name = self.current_project_document.GetRunConfiguration(
                self.select_project_file)
        else:
            project_configuration = configuration.ProjectConfiguration(
                self.current_project_document)
            self._configuration_list = project_configuration.LoadConfigurations()
            selected_configuration_name = project_configuration.GetRunConfigurationName()

        for runconfiguration in self._configuration_list:
            configurationitem = QListWidgetItem(runconfiguration.Name)
            configurationitem.setIcon(self.run_config_img)
            self.configuration_listctrl.addItem(configurationitem)
            if selected_configuration_name == runconfiguration.Name:
                self.configuration_listctrl.setCurrentItem(configurationitem)
