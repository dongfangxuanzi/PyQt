import os
from .... import _, newid
from .environment import BaseEnvironmentUI
from .runui import ProjectFolderPathDialog, SelectModuleFileDialog
from ....project import variables
from ....util import ui_utils, fileutils, utils
from ....lib.pyqt import (
    QHBoxLayout,
    QLabel,
    QTabWidget,
    QMessageBox,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    Qt,
    QCheckBox,
    QPushButton
)
from ...interpreter import pythonpathmixin
from ..configuration import ProjectConfiguration
from .... import qtimage


class InternalPathPage(ui_utils.BaseConfigurationPanel):

    ID_NEW_INTERNAL_ZIP = newid()
    ID_NEW_INTERNAL_EGG = newid()
    ID_NEW_INTERNAL_WHEEL = newid()

    def __init__(self, parent, project_document):
        super().__init__(parent)
        self.current_project_document = project_document
        h_box = QHBoxLayout()
        self.treeview = QTreeWidget(self)
        self.treeview.setHeaderHidden(True)
        self.rootitem = self.treeview.invisibleRootItem()
        h_box.addWidget(self.treeview)
        self.folder_bmp = qtimage.load_icon("packagefolder_obj.gif")
     #   self.treeview.tree.bind("<3>", self.OnRightClick, True)
        right_box = QVBoxLayout()
        right_box.setContentsMargins(0, 5, 5, 5)
        right_box.setAlignment(Qt.AlignTop)

        self.add_path_btn = QPushButton(_("Add path..."))
        self.add_path_btn.clicked.connect(self.AddNewPath)
        right_box.addWidget(self.add_path_btn)

        self.remove_path_btn = QPushButton(_("Remove path"))
        self.remove_path_btn.clicked.connect(self.RemovePath)
        right_box.addWidget(self.remove_path_btn)

        self.add_file_btn = QPushButton(_("Add file..."))
        self.add_file_btn.clicked.connect(self.AddNewFilePath)
        right_box.addWidget(self.add_file_btn)
        h_box.addLayout(right_box)
        self.layout.addLayout(h_box)

        self._useProjectPathCheck = QCheckBox(
            _("Append project root path to PYTHONPATH"))
        self._useProjectPathCheck.setChecked(True)
        self.layout.addWidget(self._useProjectPathCheck)
        self._useProjectPathCheck.setChecked(ProjectConfiguration.IsAppendProjectPath(
            self.current_project_document.GetKey()))
        self.AppendPathPath()

    def AppendPathPath(self):
        python_path_list = ProjectConfiguration.LoadProjectInternalPath(
            self.current_project_document.GetKey())
        for path in python_path_list:
            pathitem = QTreeWidgetItem()
            self.rootitem.addChild(pathitem)
            pathitem.setText(0, path)
            pathitem.setIcon(0, self.folder_bmp)

    def AddNewFilePath(self):
        dlg = SelectModuleFileDialog(self, _("Select Zip/Egg/Wheel File"),
                                     self.current_project_document.GetModel(), False, ['egg', 'zip', 'whl'])
        if dlg.exec_() == SelectModuleFileDialog.Accepted:
            main_module_path = os.path.join(variablesutils.FormatVariableName(variablesutils.PROJECT_DIR_VARIABLE), self.current_project_document.
                                            GetModel().GetRelativePath(dlg.module_file))
            if self.CheckPathExist(main_module_path):
                messagebox.showinfo(_("Add Path"), _(
                    "Path already exist"), parent=self)
            else:
                self.treeview.tree.insert(
                    '', "end", text=main_module_path, image=self.folder_bmp)

    def RemovePath(self):
        selections = self.treeview.selectedItems()
        if not selections:
            return
        for item in selections:
            self.rootitem.removeChild(item)

    def AddNewPath(self):
        dlg = ProjectFolderPathDialog(
            self, _("Select internal path"), self.current_project_document.GetModel())
        if dlg.exec_() == ProjectFolderPathDialog.Accepted:
            selected_path = dlg.selected_path
            if selected_path is not None:
                selected_path = os.path.join(
                    variables.create_variable_name(
                        variables.PROJECT_DIR_VARIABLE),
                    selected_path
                )
            else:
                selected_path = variables.create_variable_name(
                    variables.PROJECT_DIR_VARIABLE)
            if self.CheckPathExist(selected_path):
                QMessageBox.information(
                    self, _("Add path"), _("Path already exist"))
            else:
                pathitem = QTreeWidgetItem()
                self.rootitem.addChild(pathitem)
                pathitem.setText(0, selected_path)
                pathitem.setIcon(0, self.folder_bmp)

    def CheckPathExist(self, path):
        child_count = self.rootitem.childCount()
        for index in range(child_count):
            item = self.rootitem.child(index)
            if fileutils.ComparePath(item.text(0), path):
                return True
        return False

    def GetPythonPathList(self, use_raw_path=False):
        python_path_list = []
        items_count = self.rootitem.childCount()
        for i in range(items_count):
            item = self.rootitem.child(i)
            path = item.text(0)
            if use_raw_path:
                python_path_list.append(path)
            else:
                python_variable_manager = variablesutils.GetProjectVariableManager(
                    self.current_project_document)
                path = python_variable_manager.EvalulateValue(path)
                python_path_list.append(str(path))
        return python_path_list


class ExternalPathPage(ui_utils.BaseConfigurationPanel, pythonpathmixin.PythonpathMixin):
    def __init__(self, parent, project_document):
        super().__init__(parent)
        self.project_document = project_document
        self.InitUI(True)
        self.AppendPathPath()

    def AppendPathPath(self):
        python_path_list = ProjectConfiguration.LoadProjectExternalPath(
            self.project_document.GetKey())
        for path in python_path_list:
            self.add_path_item(path)

    def GetPythonPathList(self):
        python_path_list = self.GetPathList()
        return python_path_list

    def destroy(self):
        if self.menu is not None:
            self.menu.destroy()
        self.button_menu.destroy()
        ttk.Frame.destroy(self)


class EnvironmentPage(BaseEnvironmentUI):
    def __init__(self, parent, project_document):
        BaseEnvironmentUI.__init__(self, parent)
        self.project_document = project_document
        self.LoadEnviron()
        self.UpdateUI()

    def LoadEnviron(self):
        environ = ProjectConfiguration.LoadProjectEnviron(
            self.project_document.GetKey())
        for key in environ:
            self.listview.tree.insert("", "end", values=(key, environ[key]))


class PythonPathPanel(ui_utils.BaseConfigurationPanel):
    def __init__(self, parent, item, current_project):
        super().__init__()
        self.current_project_document = current_project
        nb = QTabWidget(self)

        self.internal_path_icon = qtimage.load_icon(
            "project/python/openpath.gif")
        self.external_path_icon = qtimage.load_icon("python/jar_l_obj.gif")
        self.environment_icon = qtimage.load_icon("environment.png")

        pythonpath_statictext_label = QLabel(
            _("The final PYTHONPATH used for a launch is composed of paths defined here,joined with the paths defined by the selected interpreter.\n"))
        # 如果文字超出了边框大小自动换行
        pythonpath_statictext_label.setWordWrap(True)
        self.layout.addWidget(pythonpath_statictext_label)

        self.internal_path_panel = InternalPathPage(
            nb, self.current_project_document)
        index = nb.addTab(self.internal_path_panel, _("Internal path"))
        nb.setTabIcon(index, self.internal_path_icon)

        self.external_path_panel = ExternalPathPage(
            nb, self.current_project_document)
        index = nb.addTab(self.external_path_panel, _("External path"))
        nb.setTabIcon(index, self.external_path_icon)

        self.environment_panel = EnvironmentPage(
            nb, self.current_project_document)
        index = nb.addTab(self.environment_panel, _("Environment"))
        nb.setTabIcon(index, self.environment_icon)
        self.layout.addWidget(nb)

    def OnOK(self, options_dialog):
        internal_path_list = self.internal_path_panel.GetPythonPathList(True)
        utils.profile_set(self.current_project_document.GetKey(
        ) + "/InternalPath", internal_path_list)
        utils.profile_set(
            self.current_project_document.GetKey() + "/AppendProjectPath",
            self.internal_path_panel._useProjectPathCheck.isChecked()
        )

        external_path_list = self.external_path_panel.GetPythonPathList()
        utils.profile_set(self.current_project_document.GetKey(
        ) + "/ExternalPath", external_path_list.__repr__())

        environment_list = self.environment_panel.GetEnviron()
        utils.profile_set(self.current_project_document.GetKey(
        ) + "/Environment", environment_list.__repr__())
        return True

    def GetPythonPathList(self):
        python_path_list = self.internal_path_panel.GetPythonPathList()
        python_path_list.extend(self.external_path_panel.GetPythonPathList())
        return python_path_list
