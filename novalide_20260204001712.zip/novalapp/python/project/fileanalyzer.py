from ...lib.pyqt import QThread


class FileAnalyzer(QThread):
    """description of class"""

    def __init__(self, parent, processor, doc, filepath):
        super().__init__(parent)
        self._processor = processor
        self._doc = doc
        self._filepath = filepath

    def run(self):
        self.analysis_file()

    def analysis_file(self):
        if self._processor.doc is None or self._processor.doc != self._doc:
            self._processor.init(self._doc)
        self._processor.doc = self._doc
        self._processor.run(self._doc, self._filepath)
