from enum import Enum
from ...findrep.option import FindOpt
from .symbols import Symbol


class FindSymbolIn(Enum):
    IN_FILE = 0
    IN_PROJECT = 1
    IN_DIRECTORY = 2
    IN_OPEN_FILES = 3


class FindSymbolParameter(FindOpt):
    """符号搜索选项参数"""

    def __init__(
        self,
        findstr: str,
        find_where: FindSymbolIn,
        symbol_type: Symbol,
        match_case: bool = False,
        match_whole_word: bool = False,
        path: str = ''
    ):
        super().__init__(
            findstr,
            match_case=match_case,
            match_whole_word=match_whole_word
        )
        self.find_in = find_where
        self._path = path
        self._symbol_type = symbol_type

    @property
    def path(self):
        return self._path

    @property
    def symbol(self):
        return self._symbol_type


class OccurrencesParameter(FindSymbolParameter):
    def __init__(
        self,
        findstr: str,
        filename: str,
        line: int,
        col: int
    ):
        super().__init__(
            findstr,
            FindSymbolIn.IN_FILE,
            Symbol.ALL,
            True,
            True
        )
        self._filename = filename
        self._line = line
        self._col = col

    @property
    def filename(self):
        return self._filename

    @property
    def line(self):
        return self._line

    @property
    def col(self):
        return self._col
