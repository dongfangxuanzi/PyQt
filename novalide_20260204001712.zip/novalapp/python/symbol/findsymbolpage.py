from ...findrep.optionpage import SearchTextOptionPanel
from ...lib.pyqt import QCheckBox
from ... import _
from ...util import utils
from ... import globalkeys


class SearchSymbolOptionPanel(SearchTextOptionPanel):

    def __init__(self, master):
        """
        Initializes the panel by adding an "Options" folder tab to the parent notebook and
        populating the panel with the generic properties of a pydocview application.
        """
        super().__init__(master)
        self.contains_function_args_checkbox = QCheckBox(
            _("Contains function or call args When Search all symbols"))
        self.layout.addWidget(self.contains_function_args_checkbox)
        self.contains_function_args_checkbox.setChecked(
            utils.profile_get_int(globalkeys.CONTAINS_FUNCTION_ARGS_KEY, False))

        self.contains_base_classes_checkbox = QCheckBox(
            _("Contains class bases When Search all symbols"))
        self.layout.addWidget(self.contains_base_classes_checkbox)
        self.contains_base_classes_checkbox.setChecked(
            utils.profile_get_int(globalkeys.CONTAINS_CLASS_BASES_KEY, False))

        self.match_case_occurrences_checkbox = QCheckBox(
            _("Word match case When find occurrences"))
        self.layout.addWidget(self.match_case_occurrences_checkbox)
        self.match_case_occurrences_checkbox.setChecked(
            utils.profile_get_int(globalkeys.MATCH_CASE_OCCURRENCES_KEY, True))

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        super().OnOK(options_dialog)
        utils.profile_set(globalkeys.MATCH_CASE_OCCURRENCES_KEY,
                          self.match_case_occurrences_checkbox.isChecked())
        utils.profile_set(globalkeys.CONTAINS_CLASS_BASES_KEY,
                          self.contains_base_classes_checkbox.isChecked())
        utils.profile_set(globalkeys.CONTAINS_FUNCTION_ARGS_KEY,
                          self.contains_function_args_checkbox.isChecked())
        return True
