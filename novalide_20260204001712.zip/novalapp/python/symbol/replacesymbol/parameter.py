from ..parameter import FindSymbolParameter, FindSymbolIn
from ..symbols import Symbol


class ReplaceSymbolParameter(FindSymbolParameter):
    """符号替换选项参数"""

    def __init__(
        self,
        findstr: str,
        repstr: str,
        find_where: FindSymbolIn,
        symbol_type: Symbol,
        match_case: bool = False,
        match_whole_word: bool = False,
        path: str = ''
    ):
        super().__init__(
            findstr,
            find_where,
            match_case=match_case,
            match_whole_word=match_whole_word,
            path=path
        )
        self.__repstr = repstr

    @property
    def repstr(self):
        return self.__repstr
