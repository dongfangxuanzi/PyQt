# -*- coding: utf-8 -*-
'''
Name:        findsymbol.py
Purpose:

Author:      wukan

Created:     2026-01-11
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
import os
import types
from ...util import utils, fileutils, ui_utils
from ...lib.pyqt import (
    QDialog,
    QLabel,
    QGridLayout,
    QHBoxLayout,
    QCheckBox,
    Qt,
    QPushButton,
    QFileDialog,
    QMessageBox,
    QComboBox,
    QSizePolicy,
    QGroupBox,
    QRadioButton,
    QApplication,
    QCursor,
    QProgressBar,
    QTimer
)
from ...findrep import findui
from ...findrep.mixin import FindMixin
from ..editor import PythonView
from .searchsupport import ItemToSearchIn
from .. import utility
from ...widgets.labels import FitPathLabel
from ... import constants
from ... import _, get_app
from .parameter import FindSymbolParameter, FindSymbolIn


class FindSymbolLabel(QLabel):
    def __init__(self):
        super().__init__(_("Symbol Name") + ":")


class FindSymbolDialog(ui_utils.BaseModalDialog):

    SYMBOL_NAME_LIST = [
        _('Classes'),
        _('Functions'),
        _('Imports'),
        _('Calls'),
        _('Variables'),
        _('All Types')
    ]

    def __init__(self, master, results_view, findString="", parameter=None):
        super().__init__("", master)
        self.setWindowTitle(_("Find Symbol"))
        self.resize(600, 300)
        self.setSizeGripEnabled(True)

        self.__cancelRequest = False
        self.__inProgress = False
        self.__newSearch = True
        # 初始化参数,重新搜索功能时有用
        self._parameter = parameter
        self.file_label = None
        self.pb = None
        self.searchResults = []
        findui.init_find_option()
        self._results_view = results_view
        # Find text label
        find_box_layout = QHBoxLayout()
        find_label = FindSymbolLabel()
        find_box_layout.addWidget(find_label)
        # Find text field
        self.find_entry_combo = findui.FindtextCombo(None, findString)
        self._tune_combo(self.find_entry_combo)
        self.find_entry_combo.editTextChanged.connect(self.__sometext_changed)
        find_box_layout.addWidget(self.find_entry_combo, 1)
        self.layout.addLayout(find_box_layout)

        symbol_types_box_layout = QHBoxLayout()
        symbol_types_box_layout.addWidget(QLabel(_('Symbol Types') + ":"))
        self.find_symbol_range_combox = QComboBox()
        self.find_symbol_range_combox.addItems(self.SYMBOL_NAME_LIST)
        self.find_symbol_range_combox.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        symbol_types_box_layout.addWidget(self.find_symbol_range_combox)
        self.layout.addLayout(symbol_types_box_layout)

        horizontalcb_layout = QHBoxLayout()
        # Case checkbox
        self.case_checkbutton = QCheckBox(_("Case sensitive"))
        self.case_checkbutton.setChecked(findui.CURERNT_FIND_OPTION.match_case)
        horizontalcb_layout.addWidget(self.case_checkbutton)

        self.wholeword_checkbutton = QCheckBox(_("Match whole symbol"))
        self.wholeword_checkbutton.setChecked(
            findui.CURERNT_FIND_OPTION.match_whole_word)
        horizontalcb_layout.addWidget(self.wholeword_checkbutton)

        self.layout.addLayout(horizontalcb_layout)

        files_groupbox = QGroupBox(self)
        files_groupbox.setTitle(_("Find in"))
        size_policy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        size_policy.setHorizontalStretch(0)
        size_policy.setVerticalStretch(0)
        size_policy.setHeightForWidth(
            files_groupbox.sizePolicy().hasHeightForWidth())
        files_groupbox.setSizePolicy(size_policy)

        gridlayout_fg = QGridLayout(files_groupbox)

        self.file_rbutton = QRadioButton(files_groupbox)
        self.file_rbutton.setText(_("&Current file"))
        gridlayout_fg.addWidget(self.file_rbutton, 0, 0)
        self.file_rbutton.clicked.connect(self.__file_clicked)

        self.project_rbutton = QRadioButton(files_groupbox)
        self.project_rbutton.setText(_("&Current project"))
        gridlayout_fg.addWidget(self.project_rbutton, 1, 0)
        self.project_rbutton.clicked.connect(self.__project_clicked)

        self.openfiles_rbutton = QRadioButton(files_groupbox)
        self.openfiles_rbutton.setText(_("&Opened files only"))
        gridlayout_fg.addWidget(self.openfiles_rbutton, 2, 0)
        self.openfiles_rbutton.clicked.connect(self.__openfilesonly_clicked)

        self.dir_rbutton = QRadioButton(files_groupbox)
        self.dir_rbutton.setText(_("&Directory tree"))
        gridlayout_fg.addWidget(self.dir_rbutton, 3, 0)
        self.dir_rbutton.clicked.connect(self.__dir_clicked)

        self.dir_edit_combo = QComboBox(files_groupbox)
        self._tune_combo(self.dir_edit_combo)
        self.dir_edit_combo.lineEdit().setToolTip(_("Directory to search in"))
        gridlayout_fg.addWidget(self.dir_edit_combo, 3, 1)
        self.dir_edit_combo.editTextChanged.connect(self.__sometext_changed)

        self.dir_select_button = QPushButton(files_groupbox)
        self.dir_select_button.setText("...")
        gridlayout_fg.addWidget(self.dir_select_button, 3, 2)
        self.dir_select_button.clicked.connect(self.__selectdir_clicked)

        self.layout.addWidget(files_groupbox)
        self.create_progress()
        self.button_box = self.create_standard_buttons()
        self.find_button = self.ok_button
        self.find_button.setText(_("Find"))
        self.button_box.accepted.disconnect(self._ok)
        self.find_button.clicked.connect(self.__process)
        self.__test_searchability()
        if self.file_rbutton.isEnabled():
            self.file_rbutton.setChecked(True)
            self.__file_clicked()
        elif self.project_rbutton.isEnabled():
            self.project_rbutton.setChecked(True)
        elif self.openfiles_rbutton.isEnabled():
            self.openfiles_rbutton.setChecked(True)
        else:
            self.dir_rbutton.setChecked(True)

        if self._parameter is not None:
            self.__newSearch = False
            self.setWindowTitle(_("Find Symbol") + ": " + _("Search again"))
            self.__populate_searchagain(self._parameter)

    def __populate_searchagain(self, parameter):
        """Populates the search parameters to do the same search"""
        self.find_entry_combo.setEditText(parameter.findstr)
        self.find_entry_combo.setEnabled(False)
        self.find_symbol_range_combox.setCurrentIndex(parameter.symbol)
        self.case_checkbutton.setChecked(parameter.match_case)
        self.case_checkbutton.setEnabled(False)
        self.wholeword_checkbutton.setChecked(parameter.match_whole_word)
        self.wholeword_checkbutton.setEnabled(False)

        if parameter.find_in == FindSymbolIn.IN_PROJECT:
            self.project_rbutton.setChecked(True)
        elif parameter.find_in == FindSymbolIn.IN_OPEN_FILES:
            self.openfiles_rbutton.setChecked(True)
        elif parameter.find_in == FindSymbolIn.IN_FILE:
            self.file_rbutton.setChecked(True)
        else:
            self.dir_rbutton.setChecked(True)

        self.file_rbutton.setEnabled(False)
        self.project_rbutton.setEnabled(False)
        self.openfiles_rbutton.setEnabled(False)
        self.dir_rbutton.setEnabled(False)

        self.dir_edit_combo.setEditText(parameter.path)
        self.dir_edit_combo.setEnabled(False)
        self.dir_select_button.setEnabled(False)

    def get_parameter(self):
        findwhere = -1
        path = ''
        if self.file_rbutton.isChecked():
            findwhere = FindSymbolIn.IN_FILE
        elif self.openfiles_rbutton.isChecked():
            findwhere = FindSymbolIn.IN_OPEN_FILES
        elif self.project_rbutton.isChecked():
            findwhere = FindSymbolIn.IN_PROJECT
        elif self.dir_rbutton.isChecked():
            findwhere = FindSymbolIn.IN_DIRECTORY
            path = self.dir_edit_combo.currentText()

        return FindSymbolParameter(
            findui.CURERNT_FIND_OPTION.findstr,
            findwhere,
            self.find_symbol_range_combox.currentIndex(),
            findui.CURERNT_FIND_OPTION.match_case,
            findui.CURERNT_FIND_OPTION.match_whole_word,
            path
        )

    def __sometext_changed(self, text):
        """Text to search, filter or dir name has been changed"""
        del text    # unused argument
        self.__test_searchability()

    def __file_clicked(self):
        """project radio button clicked"""
        self.dir_edit_combo.setEnabled(False)
        self.dir_select_button.setEnabled(False)
        self.__test_searchability()

    def __project_clicked(self):
        """project radio button clicked"""
        self.dir_edit_combo.setEnabled(False)
        self.dir_select_button.setEnabled(False)
        self.__test_searchability()

    def __openfilesonly_clicked(self):
        """open files only radio button clicked"""
        self.dir_edit_combo.setEnabled(False)
        self.dir_select_button.setEnabled(False)
        self.__test_searchability()

    def __dir_clicked(self):
        """dir radio button clicked"""
        self.dir_edit_combo.setEnabled(True)
        self.dir_select_button.setEnabled(True)
        self.dir_edit_combo.setFocus()
        self.__test_searchability()

    def exec_(self):
        """Execute the dialog"""
        if not self.__newSearch:
            QTimer.singleShot(1, self.__process)
        QDialog.exec_(self)

    def __selectdir_clicked(self):
        """The user selects a directory"""
        options = QFileDialog.Options()
        options |= QFileDialog.ShowDirsOnly | QFileDialog.DontUseNativeDialog
        dirname = QFileDialog.getExistingDirectory(
            self,
            _('Select directory to search in'),
            self.dir_edit_combo.currentText(),
            options
        )
        if dirname:
            self.dir_edit_combo.setEditText(os.path.normpath(dirname))
        self.__test_searchability()

    def __test_searchability(self):
        """Tests the searchability and sets the Find button status"""
        if self.find_entry_combo.currentText().strip() == "":
            self.find_button.setEnabled(False)
            self.find_button.setToolTip(_("No text to search"))
            return

        self.find_button.setEnabled(True)
        if self.dir_rbutton.isChecked():
            dirname = self.dir_edit_combo.currentText().strip()
            if dirname == "":
                self.find_button.setEnabled(False)
                self.find_button.setToolTip(_("No directory path"))
                return
            if not os.path.isdir(dirname):
                self.find_button.setEnabled(False)
                self.find_button.setToolTip(_("Path is not a directory"))
                return
        open_code_documents = self.__opened_files()
        if open_code_documents:
            self.openfiles_rbutton.setEnabled(True)
        else:
            self.openfiles_rbutton.setEnabled(False)

        cur_open_doc = self.__opened_files(curr_file_only=True)
        if cur_open_doc:
            self.file_rbutton.setEnabled(True)
        else:
            self.file_rbutton.setEnabled(False)
        in_project = get_app().get_current_project() is not None
        self.project_rbutton.setEnabled(in_project)

    def __opened_files(self, curr_file_only=False):
        if curr_file_only:
            current_docview = get_app().MainFrame.GetNotebook().get_current_view()
            if isinstance(current_docview, PythonView):
                return [ItemToSearchIn(
                    current_docview.GetDocument().GetFilename(),
                    current_docview
                )]
            return []
        open_docs = get_app().MainFrame.GetNotebook().open_code_documents()
        open_python_docs = []
        for open_doc in open_docs:
            if isinstance(open_doc.GetFirstView(), PythonView):
                open_python_docs.append(
                    ItemToSearchIn(open_doc.GetFilename(), open_doc.GetFirstView())
                )
            QApplication.processEvents()
            if self.__cancelRequest:
                raise Exception("Cancel request")
        return open_python_docs

    @staticmethod
    def _tune_combo(comboBox):
        """Sets the common settings for a combo box"""
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(
            comboBox.sizePolicy().hasHeightForWidth())
        comboBox.setSizePolicy(sizePolicy)
        comboBox.setEditable(True)
        comboBox.setInsertPolicy(QComboBox.InsertAtTop)
        comboBox.setCompleter(None)
        comboBox.setDuplicatesEnabled(False)

    @staticmethod
    def get_find_prog(parent):
        findmixin = FindMixin()
        findmixin.SetOption(findui.CURERNT_FIND_OPTION)
        try:
            return findmixin.getprog()
        except re.error as what:
            msgtitle = _('Regular Expression')
            QMessageBox.critical(
                parent,
                msgtitle,
                _("Invalid regular expression:\"%s\"") % str(what),
            )
            return None

    def is_find_available(self):
        '''
            按回车键执行查找时检测按钮是否可用
        '''
        return self.find_button.isEnabled() and self.find_entry_combo.get_text() != ''

    def _cancel(self):
        """Triggered when the close button is clicked"""
        self.__cancelRequest = True
        if not self.__inProgress:
            self.close()

    def __process(self):
        """Search process"""
       # self.__updateHistory()
        if not self.is_find_available():
            return
        self.GetFindTextOption()
        findprog = self.get_find_prog(self)
        if not findprog:
            return

        self.__inProgress = True
        self.find_button.setEnabled(False)
        numberOfMatches = 0
        self.searchResults = []
        QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        self.file_label.setPath(_('Building list of files to search in...'))
        QApplication.processEvents()
        try:
            files = self.__build_files_list()
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            if 'Cancel request' not in str(exc):
                utils.get_logger().error(str(exc))
            self.close()
            return
        QApplication.restoreOverrideCursor()
        QApplication.processEvents()
        if not files:
            self.file_label.setPath(_('No files to search in'))
            self.find_button.setEnabled(True)
            return
        if isinstance(files, types.GeneratorType):
            # 计算生成器的长度
            files_num = sum(1 for _ in files)
            # 上面计算长度时耗尽了生成器,需要重新生成生成器
            files = self.__build_files_list()
        else:
            files_num = len(files)
        utils.get_logger().info('search symbol in total %d files', files_num)
        self.pb.setRange(0, files_num)
        utils.get_logger().debug('total progress value is %d', files_num)
        self.show_progress()

        index = 1
        for item in files:
            if self.__cancelRequest:
                self.__inProgress = False
                self.close()
                return
            self.update_progress(
                index,
                _('Matches') + ": " + str(numberOfMatches) + ' ' + _('Processing') + ": " + item.fileName
            )
            item.search(
                findprog, self.find_symbol_range_combox.currentIndex()
            )
            found = len(item.matches)
            if found > 0:
                numberOfMatches += found
                self.searchResults.append(item)
            index += 1
            QApplication.processEvents()

        self.__inProgress = False
        self.save_config()
        utils.get_logger().debug('search total %d results in %d files', numberOfMatches, files_num)
        if numberOfMatches > 0 or self.__newSearch == False:
            # If it is redo then close the dialog anyway
            self.close()
        else:
            msg = _('No matches in') + ' ' + str(files_num) + ' '
            if len(files) > 1:
                msg += _('files')
            else:
                msg += _('file')
            self.file_label.setPath(msg)
            self.find_button.setEnabled(True)

    def create_progress(self):
        self.file_label = FitPathLabel(parent=self)
        self.file_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        self.layout.addWidget(self.file_label)
        self.pb = QProgressBar(self)
        self.pb.setValue(0)
        self.pb.setOrientation(Qt.Horizontal)
        self.pb.setVisible(False)
        self.layout.addWidget(self.pb)

    @ui_utils.call_after_with_time(3000)
    def show_progress(self):
        # 如果搜索文本操作已经完成,则不会显示进度条对话框
        if self.__inProgress:
            self.pb.setVisible(True)

    def update_progress(self, curval, label_msg):
        utils.get_logger().debug('cur progress value is %d', curval)
        self.pb.setValue(curval)
        self.file_label.setPath(label_msg)

    def __project_files(self):
        project_browser = get_app().MainFrame.projectview
        project_filenames = project_browser.GetFilesFromCurrentProject()
        # 先查找在编辑器中打开的文本,因为这些文本内容可能已经和实际存储的文件不一致了
        open_docs = get_app().GetDocumentManager().GetDocuments()
        # python3 filter不返回列表,返回filter对象,需要手动转换成list
        opendocs_in_project = list(
            filter(lambda opendoc: opendoc.GetFilename() in project_filenames, open_docs))
        project_open_docs = []
        for project_file_name in project_filenames:
            if not utility.is_python_file(project_file_name):
                continue
            found_open_doc = None
            for open_doc_project in opendocs_in_project:
                if fileutils.ComparePath(project_file_name, open_doc_project.GetFilename()):
                    found_open_doc = open_doc_project
                    break
            if found_open_doc is None:
                project_open_docs.append(ItemToSearchIn(project_file_name))
            else:
                project_open_docs.append(
                    ItemToSearchIn(project_file_name, found_open_doc.GetFirstView())
                )
            QApplication.processEvents()
            if self.__cancelRequest:
                raise Exception("Cancel request")
        return project_open_docs

    def __build_files_list(self):
        """Builds the list of files to search in"""
        if self.file_rbutton.isChecked():
            return self.__opened_files(curr_file_only=True)

        if self.project_rbutton.isChecked():
            return self.__project_files()

        if self.openfiles_rbutton.isChecked():
            return self.__opened_files()
        dirname = os.path.realpath(self.dir_edit_combo.currentText().strip())
        return self.__dir_files(dirname)

    def __dir_files(self, path):
        '''
        遍历目录,返回文件生成器,减少内存消耗
        '''
        open_docs = get_app().GetDocumentManager().GetDocuments()
        for root, dirs, files in os.walk(path):
            QApplication.processEvents()
            if self.__cancelRequest:
                raise Exception("Cancel request")
            # 忽略版本控制生成的目录
            for r_dir in constants.REVISION_CONTROL_DIRS:
                if r_dir in dirs:
                    dirs.remove(r_dir)
                    utils.get_logger().debug(
                        'revision control dir %s is ignored...',
                        r_dir
                    )
                    break
            for file in files:
                if not utility.is_python_file(file):
                    continue
                filepath = os.path.join(root, file)
                open_edit_view = None
                for opendoc in open_docs:
                    if fileutils.ComparePath(opendoc.GetFilename(), filepath):
                        open_edit_view = opendoc.GetFirstView()
                        break
                if open_edit_view is not None:
                    yield ItemToSearchIn(filepath, open_edit_view)
                else:
                    yield ItemToSearchIn(filepath)

    def GetFindTextOption(self):
        findui.CURERNT_FIND_OPTION.findstr = self.find_entry_combo.currentText()
        findui.CURERNT_FIND_OPTION.match_case = self.case_checkbutton.isChecked()
        findui.CURERNT_FIND_OPTION.match_whole_word = self.wholeword_checkbutton.isChecked()

    def closeEvent(self, event):
        """Called when the window is closed. responsible for handling all cleanup."""
        self.reject()

    def save_config(self):
        """ Save find/replace patterns and search flags to registry. """
        utils.profile_set(findui.FIND_MATCHPATTERN,
                          findui.CURERNT_FIND_OPTION.findstr)
        utils.profile_set(findui.FIND_MATCHCASE,
                          findui.CURERNT_FIND_OPTION.match_case)
        utils.profile_set(findui.FIND_MATCHWHOLEWORD,
                          findui.CURERNT_FIND_OPTION.match_whole_word)
        self.find_entry_combo.update_item(findui.CURERNT_FIND_OPTION.findstr)
        self.find_entry_combo.save_match_patters()
