import os
from .python_path_analyzer import PythonPathAnalyzer
from .builtin_analyzer import BuiltinAnalyzer
from ..parser.exceptions import OutofPythonPathError

CODEPARSE_RPROCESSOR_NAME = 'codeparser'


class ProjectAnalyzer(PythonPathAnalyzer):

    def __init__(
        self,
        dbver,
        data_outpath,
        interpreter,
        pathlist,
        python_path_analyzer
    ):
        super().__init__(
            dbver,
            data_outpath,
            interpreter,
            pathlist,
            python_path_analyzer.builtin_analyzer,
            check_file_updated=True
        )
        self._python_path_analyzer = python_path_analyzer
        # 在基类中数据文件存放路径做了修改,路径加了解释器版本号,这里需要恢复原来的路径
        self.data_out_path = data_outpath
        # 恢复正确的版本文件存放路径
        self._out_version_path = data_outpath
        # 恢复正确的更新时间的存放路径
        self._timestamp_outpath = data_outpath

    @staticmethod
    def get_cache_path(doc, interpreter):
        '''
        项目智能提示数据文件存放路径,所有解释器具体相同的数据存放路径,故路径中不包含任何解释器版本号等信息
        '''
        dock_cache_path = doc.get_doc_cache_path()
        return os.path.join(dock_cache_path, CODEPARSE_RPROCESSOR_NAME)

    @classmethod
    def make_analyzer(cls, interpreter, dbver, interpreter_datapath, doc):
        builtin_analyzer = BuiltinAnalyzer(
            dbver,
            interpreter_datapath,
            interpreter
        )
        pythonpath_analyzer = PythonPathAnalyzer(
            dbver,
            interpreter_datapath,
            interpreter,
            interpreter.sys_path_list,
            builtin_analyzer
        )
        if doc is None:
            return pythonpath_analyzer
        projectpath_list = [doc.GetPath()]
        projectpath_analyzer = ProjectAnalyzer(
            dbver,
            cls.get_cache_path(doc, interpreter),
            interpreter,
            projectpath_list,
            pythonpath_analyzer
        )
        return projectpath_analyzer

    def get_refmod_apifiles(self, modname):
        # 先从项目智能数据库下面查找模块信息
        prj_membersfile, prj_memberlistfile = self.get_api_files(modname)
        membersfile, memberlistfile = self._python_path_analyzer.get_api_files(
            modname)
        # 再从解释器智能数据库下面查找
        return [[prj_membersfile, prj_memberlistfile], [membersfile, memberlistfile]]

    def get_refmod_apilist(self, modname):
        apifile_list = self._python_path_analyzer.get_refmod_apilist(modname)
        apifile_list.append(self.get_api_file(modname))
        return apifile_list

    def get_relative_path(self, file_path):
        path = None
        try:
            path = super().get_relative_path(file_path)
        except OutofPythonPathError as e:
            try:
                path = self._python_path_analyzer.get_relative_path(
                    file_path)
            except OutofPythonPathError as ex:
                pass
        return path
