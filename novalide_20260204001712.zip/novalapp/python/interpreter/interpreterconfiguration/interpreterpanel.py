import abc
from ....util import ui_utils


class BaseInterpreterPanel(ui_utils.BaseConfigurationPanel):
    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self._interpreter = None

    def set_interpreter(self, interpreter):
        self._interpreter = interpreter

    @abc.abstractmethod
    def update_ui(self):
        pass
