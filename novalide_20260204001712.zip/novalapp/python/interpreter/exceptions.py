

class NotsupportInterpreterError(Exception):
    '''不支持的python的解释器'''


class UnknownVersionInterpreterError(Exception):
    '''未知版本的解释器'''


class InvalidInterpreterError(Exception):
    '''不是有效的解释器'''


class InterpreternameExistError(Exception):
    '''解释器名称已经存在'''


class InterpreterpathExistError(Exception):
    '''解释器路径已经存在'''


class InterpretertoolNotExistError(Exception):
    '''解释器安装路径下不存在某个工具'''


class InterpreterSyntaxError(Exception):
    '''解释器语法错误'''


class InterpreterNotExistError(Exception):
    '''解释器不存在'''


class UnParseableSyntaxMessage(Exception):
    '''
        无法解析语法错误信息
    '''


class BaseinterpreterNotExistError(Exception):
    '''虚拟解释器的基础解释器路径不存在'''


class InterpreterPathNotExistError(Exception):
    '''解释器路径不存在'''
    ERROR_MSG = "Interpreter path not exist"


class InterpreterPipNotFoundError(Exception):
    '''解释器pip工具未安装或已损坏'''
    ERROR_MSG = "No module named pip"


class InterpreterLaunchError(Exception):
    '''解释器启动失败'''
    ERROR_MSG = "Interpreter launch error"
