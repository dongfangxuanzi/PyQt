from typing import NamedTuple


class PyvenvCfg(NamedTuple):
    """description of class"""
    path: str
    home: str
    base_executable: str


class PythonPackage(NamedTuple):
    name: str
    version: str


class PythonpackageLocation(NamedTuple):
    name: str
    version: str
    location: str
