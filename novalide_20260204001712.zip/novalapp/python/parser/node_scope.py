import logging
import astroid
from astroid import nodes
from ... import get_app
from .definition import Definition
from ..analysis.module_analyzer import _code_parser
from . import node_utils
from .define import SUPER_CALL_METHOD_NAME, CLASS_INIT_METHOD, SELF_ARG_NAME
from .exceptions import OutofPythonPathError

log = logging.getLogger(__name__)


class ScopeFinder:
    def __init__(self, scope):
        self._scope = scope
        self._module = self._scope.root()

    @staticmethod
    def get_class_scope(node):
        parent = node
        while parent:
            if isinstance(parent, nodes.Module):
                break
            if isinstance(parent, nodes.ClassDef):
                break
            parent = parent.parent
        return parent

    @staticmethod
    def locate_in_scope(scope, line):
        if isinstance(scope, nodes.Module):
            return True
        if scope.lineno <= line <= scope.end_lineno:
            return True
        return False

    @staticmethod
    def is_scope(scope):
        '''
        常量节点有body属性,但是不是scope
        '''
        return hasattr(scope, 'body') and not isinstance(scope, nodes.Const)

    def get_definitions(self, node):
        definitions = []
        try:
            for infered in node.infer():
                # 找到节点定义,但是未能推断出类型
                if infered == astroid.Uninferable:
                    datas = self.find_definitions(node)
                    definitions.extend(datas)
                elif isinstance(infered, astroid.UnboundMethod) and infered.name == CLASS_INIT_METHOD:
                    datas = self.find_definitions(node)
                    definitions.extend(datas)
                # 推断的节点类型非法
                elif isinstance(infered, nodes.Module) and infered.file == '<?>':
                    raise astroid.InferenceError(
                        "unknown infered module %s file %s" % (infered.name, infered.file))
                else:
                    # 成功推断出节点类型
                    infered_module = infered.root()
                    if isinstance(infered_module, nodes.Module):
                        codepath = infered_module.file
                        lineno, col_offset = node_utils.get_node_line_col(
                            infered)
                        definitions.append(
                            Definition(
                                lineno,
                                col_offset,
                                codepath,
                                infered.__class__.__name__.lower(),
                                node.as_string(),
                                infered_module.name
                            )
                        )
        # 推断节点类型过程中发生错误,比如节点名称定义不存在等
        except astroid.InferenceError as ex:
            log.error(str(ex))
            log.info(
                'find definitions of node:%s of file %s in intellisence data files',
                node,
                self._module.file
            )
            datas = self.find_definitions(node)
            definitions.extend(datas)
        return definitions

    def find_definitions(self, node):
        if (
            isinstance(node, nodes.Attribute) and isinstance(
                node.expr, nodes.Call)
        ) and (
            isinstance(
                node.expr.func, nodes.Name) and node.expr.func.name == SUPER_CALL_METHOD_NAME
        ):
            node_scope = self.get_class_scope(node)
            if isinstance(node_scope, nodes.ClassDef):
                return self.find_base_definitions(node_scope, node.attrname)
        elif (
            isinstance(node, nodes.Attribute) and isinstance(
                node.expr, nodes.Name)
        ) and node.expr.name == SELF_ARG_NAME:
            definitions = self.find_import_definitions(node)
            if not definitions:
                node_scope = self.get_class_scope(node)
                if isinstance(node_scope, nodes.ClassDef):
                    definitions = self.find_base_definitions(
                        node_scope, node.attrname)
            return definitions
        else:
            return self.find_import_definitions(node)

    def find_base_definitions(self, class_node, atrrname):
        class_file = class_node.root().file
        try:
            class_mod_path = _code_parser.analyzer.get_relative_path(
                class_file)
        except OutofPythonPathError as ex:
            return []
        if class_mod_path is None:
            return []
        class_mod_name = _code_parser.modname_to_path(
            class_mod_path, class_node.name)
        base_mod_names = get_app().intellisence_mananger.load_module_class_bases(class_mod_name)
        definitions = []
        for base_mod_name in base_mod_names:
            get_app().intellisence_mananger.fin_class_member_definitions(
                base_mod_name, atrrname, definitions)
        return definitions

    def get_import_definitions(self, importnode, alias):
        attrname = None
        if isinstance(importnode, nodes.ImportFrom):
            importname = importnode.modname
            attrname = alias.name
        else:
            importname = alias.name
        import_modname = importname
        if import_modname is not None:
            if attrname:
                defname = import_modname + "." + attrname
            else:
                defname = import_modname
            log.info('find defname %s of module %s definitions', defname, import_modname)
            definitions = get_app().intellisence_mananger.get_definitions(defname)
        else:
            definitions = get_app().intellisence_mananger.get_definitions(nodestr)
        return definitions

    def find_import_definitions(self, node, attrname=None):
        nodestr = node.as_string()
        nodenames = nodestr.split('.')
        importname = nodenames[0]
        if attrname is None:
            attrname = nodenames[1:]
        import_modname = _code_parser.find_import_modname(
            self._module, importname)
        if import_modname is not None:
            if attrname:
                defname = import_modname + "." + ".".join(attrname)
            else:
                defname = import_modname
            definitions = get_app().intellisence_mananger.get_definitions(defname)
        else:
            definitions = get_app().intellisence_mananger.get_definitions(nodestr)
        return definitions

    def find_scope(self, line):
        if not self.locate_in_scope(self._scope, line):
            return None
        for child in self._scope.get_children():
            if isinstance(child, nodes.Arguments):
                continue
            if self.locate_in_scope(child, line):
                if self.is_scope(child):
                    found_scope = ScopeFinder(child).find_scope(line)
                    return found_scope
                break
        return self._scope
