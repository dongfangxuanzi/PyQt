# -*- coding: utf-8 -*-
import copy
import datetime
import logging
import os
from ... import get_app
from ...util import appdirs, utils
from ...enums import InterpreterUpdateInterval
from ..interpreter.interpretermanager import InterpreterManager
from ..parser.parser_checker import FileupdateTimeChecker
from .dataload import IntellisencedataLoader
from .datagen import IntellisencedataGen
from . import objtypes
from ..analysis.moduleloader import ModuleLoader
from ..apis import iconid, memberkeys
from ..project.processor import CODEPARSE_RPROCESSOR_NAME
from .definition import Definition
from . import define

log = logging.getLogger(__name__)


class IntellisenceManager:
    def __init__(self):
        self.data_root_path = os.path.join(
            appdirs.get_user_data_path(), "intellisence")
        self.module_dicts = {}
        self.statubar = get_app().MainFrame.GetStatusBar()
        self._loader = IntellisencedataLoader(
            self.data_root_path, self, self.statubar)
        self._running = False
        self._process_obj = None
        self._is_stopped = False
        self.unfinish_files = {}

    @property
    def dataloader(self):
        return self._loader

    @property
    def datapath(self):
        return self.data_root_path

    @property
    def stopped(self):
        return self._is_stopped

    def Stop(self):
        self._is_stopped = True

    @property
    def running(self):
        return self._running

    @running.setter
    def running(self, value: bool):
        self._running = value

    def GetInterpreterDatabasePath(self, interpreter):
        return os.path.join(self.data_root_path, str(interpreter.Id))

    def GetInterpreterIntellisenceDataPath(self, interpreter):
        if interpreter.IsBuiltIn:
            return self.GetInterpreterBuiltinIntellisenceDataPath(interpreter)
        return os.path.join(self.GetInterpreterDatabasePath(interpreter), interpreter.MinorVersion)

    def GetInterpreterBuiltinIntellisenceDataPath(self, interpreter):
        return os.path.join(self.GetInterpreterDatabasePath(interpreter), define.BUILTINS_DATA_FOLDER)

    def get_last_updatetime(self, database_location):
        return FileupdateTimeChecker(database_location).load_last_timestamp()

    def IsInterpreterNeedUpdateDatabase(self, interpreter):
        update_interval_option = utils.profile_get_int(
            "DatabaseUpdateInterval", InterpreterUpdateInterval.UPDATE_ONCE_STARTUP.value)
        if update_interval_option == InterpreterUpdateInterval.UPDATE_ONCE_STARTUP.value:
            return True
        try:
            # if could not find last update time,update database force
            intellisence_data_path = self.GetInterpreterIntellisenceDataPath(
                interpreter)
            last_update_time = self.get_last_updatetime(intellisence_data_path)
            last_datetime = datetime.datetime.fromtimestamp(last_update_time)
            log.info('interpreter %s last update time %s',
                     interpreter.name, last_datetime)
        except:
            log.exception('load intellisence last update time exception:')
            return True
        now_datetime = datetime.datetime.now()
        if update_interval_option == InterpreterUpdateInterval.UPDATE_ONCE_DAY.value:
            return now_datetime > last_datetime + datetime.timedelta(hours=24)
        if update_interval_option == InterpreterUpdateInterval.UPDATE_ONCE_WEEK.value:
            return now_datetime > last_datetime + datetime.timedelta(days=7)
        if update_interval_option == InterpreterUpdateInterval.UPDATE_ONCE_MONTH.value:
            return now_datetime > last_datetime + datetime.timedelta(days=30)
        if update_interval_option == InterpreterUpdateInterval.NEVER_UPDATE_ONCE.value:
            return False

    def generate_default_intellisence_data(self):
        current_interpreter = InterpreterManager.manager().GetCurrentInterpreter()
        if current_interpreter is None:
            return
        self.load_intellisence_data(current_interpreter)
        if not self.IsInterpreterNeedUpdateDatabase(current_interpreter):
            log.info('interpreter %s is no need to update database',
                     current_interpreter.name)
            return
        log.info('interpreter %s is need to update database',
                 current_interpreter.name)
        log.info('start generate interpreter %s intellisence data',
                 current_interpreter.name)
        IntellisencedataGen(self, current_interpreter, self.statubar).start()

    def generate_intellisence_data(self, interpreter, progress_dlg):
        IntellisencedataGen(self, interpreter,
                            self.statubar, progress_dlg).start()

    def load_intellisence_data(self, interpreter, async_load=True):
        self._loader.Load(interpreter, async_load)

    def GetImportList(self):
        def _add_icon_id(name):
            return name + "?%d" % iconid.MODULE_ID
        # 全局加载的导入模块列表
        import_list = self._loader.ImportList
        current_project = get_app().get_current_project()
        if current_project is not None:
            # 当前项目里面的导入模块列表
            processor = self.get_codeparser_processor()
            l = copy.copy(processor.importlist)
            l.extend(import_list)
            import_list = l
            import_list.sort()
        icon_import_list = list(map(_add_icon_id, import_list))
        return icon_import_list

    def GetBuiltinModule(self):
        return self._loader.BuiltinModule

    def GetModule(self, name):
        d = self.GetModules()
        if name in d:
            return ModuleLoader(name, d[name]['members'], d[name]['apis'], self)
        return None

    def load_modules(self):
        modules = self.GetModules()
        for modname in modules:
            d = modules[modname]
            yield ModuleLoader(modname, d['members'], d['apis'], self)

    def get_codeparser_processor(self):
        return get_app().MainFrame.projectview.get_processor(CODEPARSE_RPROCESSOR_NAME)

    def get_members(self, modname):
        mdloader = self.GetModule(modname)
        if not mdloader:
            return []
        mdloader.load()
        members = []
        temp = set()
        modlen = len(modname.split("."))
        for child in mdloader.data.get(memberkeys.CHILD_KEY_NAME):
            child_modname = child[memberkeys.MODNAME_KEY_NAME]
            assert child_modname.startswith(modname + ".")
            name = child[memberkeys.NAME_KEY_NAME]
            # 只获取模块顶层的成员信息
            if len(child_modname.split(".")) == modlen + 1:
                icon_id = iconid.get_icon_id(
                    child[memberkeys.OBJTYPE_KEY_NAME],
                    name
                )
                # 防止重复添加相同的子成员名称
                if name not in temp:
                    if icon_id is None:
                        members.append(name)
                    else:
                        members.append(name + "?%d" % icon_id)
                    temp.add(name)
        return members

    def GetModules(self):
        # 所有模块为当前项目的所有模块加上全局模块
        current_project = get_app().get_current_project()
        if current_project is None:
            return self._loader.module_dicts
        processor = self.get_codeparser_processor()
        d = copy.copy(self._loader.module_dicts)
        d.update(processor.module_dicts)
        return d

    def get_definitions(self, defname):
        names = defname.split(".")
        namelen = len(names)
        mdloader = None
        for i in range(1, namelen + 1):
            modnames = names[0:i]
            module_name = ".".join(modnames)
            module = self.GetModule(module_name)
            if module is None:
                break
            mdloader = module
        if mdloader is None:
            return []
        mdloader.load()
        definitions = []
        data = mdloader.data
        codepath = data.get(memberkeys.PATH_KEY_NAME, None)
        modname = data[memberkeys.MODNAME_KEY_NAME]
        # 定位到模块
        if defname == modname:
            definitions.append(
                Definition(
                    0, 0,
                    codepath,
                    objtypes.MODULE,
                    defname,
                    modname
                ))
        else:
            # 定义到模块中的子成员
            for child in data.get(memberkeys.CHILD_KEY_NAME):
                mod_name = child[memberkeys.MODNAME_KEY_NAME]
                if defname == mod_name:
                    ref_codepath = child.get(memberkeys.PATH_KEY_NAME, None)
                    if ref_codepath is not None:
                        codepath = ref_codepath
                    definitions.append(
                        Definition(
                            child.get(memberkeys.LINE_KEY_NAME, None),
                            child.get(memberkeys.COL_KEY_NAME, None),
                            codepath,
                            child[memberkeys.OBJTYPE_KEY_NAME],
                            defname,
                            mod_name
                        ))
        return definitions

    def load_module_class_bases(self, class_mod_name):
        names = class_mod_name.split(".")
        namelen = len(names)
        mdloader = None
        for i in range(1, namelen + 1):
            modnames = names[0:i]
            module_name = ".".join(modnames)
            module = self.GetModule(module_name)
            if module is None:
                break
            mdloader = module
        if mdloader is None:
            return []
        mdloader.load()
        data = mdloader.data
        for child in data.get(memberkeys.CHILD_KEY_NAME):
            mod_name = child[memberkeys.MODNAME_KEY_NAME]
            if class_mod_name == mod_name:
                assert (child[memberkeys.OBJTYPE_KEY_NAME]
                        == objtypes.CLASS_DEF)
                bases = child['bases']
                base_mod_names = [base[memberkeys.MODNAME_KEY_NAME]
                                  for base in bases]
                return base_mod_names
        return []

    def fin_class_member_definitions(self, class_mod_name, membername, definitions: list):
        names = class_mod_name.split(".")
        module_name = ".".join(names[0:-1])
        mdloader = self.GetModule(module_name)
        if mdloader is None:
            return
        mdloader.load()
        log.debug("module %s members file is %s",
                  mdloader.Name, mdloader.membersfile)
        data = mdloader.data
        codepath = data.get(memberkeys.PATH_KEY_NAME, None)
        member_mod_name = class_mod_name + "." + membername
        for child in data.get(memberkeys.CHILD_KEY_NAME):
            mod_name = child[memberkeys.MODNAME_KEY_NAME]
            if mod_name == class_mod_name:
                for base in child[memberkeys.BASES_KEY_NAME]:
                    base_mod_name = base[memberkeys.MODNAME_KEY_NAME]
                    self.fin_class_member_definitions(
                        base_mod_name, membername, definitions)
            elif mod_name == member_mod_name:
                if codepath is not None:
                    definitions.append(
                        Definition(
                            child.get(memberkeys.LINE_KEY_NAME, None),
                            child.get(memberkeys.COL_KEY_NAME, None),
                            codepath,
                            child[memberkeys.OBJTYPE_KEY_NAME],
                            member_mod_name,
                            mod_name
                        ))
                break
