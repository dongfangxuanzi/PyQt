import logging
from .define import BUILTMODULE_NAME

log = logging.getLogger(__name__)


class BuiltinModule:
    def __init__(self, apifile=None):
        self.members = []
        self.modname = BUILTMODULE_NAME
        self.doc = None
        self._apifile = apifile

    @property
    def apifile(self):
        return self._apifile

    def load(self, data):
        if not data:
            return
        self.doc = data['doc']
        assert data['name'] == self.modname
        for data in data['childs']:
            self.members.append(data)

    def get_member(self, name):
        for member in self.members:
            if member['name'] == name:
                return member
        return None
