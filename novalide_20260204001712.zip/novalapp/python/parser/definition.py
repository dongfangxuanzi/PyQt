from typing import NamedTuple
from ...util import strutils
from .. import prog_lang_ext


class Definition(NamedTuple):
    """description of class"""
    # 定义所在行
    line: int
    # 定义所在列
    col: int
    # 定义所在模块路径
    path: str
    # 定义类型
    typname: str
    # 定义名称
    defname: str
    # 节点模块名称,如果节点path为None,显示节点所属模块名称
    module: str

    def locatable(self):
        '''
            是否可以转到定义所在行或文件
            如果定义的行,列,路径信息其中一个为None,表示无法转到定义
            最新的astroid版本对内建模块内的节点信息line和col_offset均为0值,模块路径值为None
        '''
        if self.line is None or self.col is None or self.path is None:
            return False
        ext = strutils.get_file_extension(self.path)
        # pyd/so/pyc文件亦无法定位文件行列
        if ext in [
            prog_lang_ext.PYTHON_PYD_FILE_EXT,
            prog_lang_ext.PYTHON_SO_FILE_EXT
        ] or ext in prog_lang_ext.PYTHON_COMPILE_FILE_EXT:
            return False
        return True
