# Autocompletion icon definitions
from ..parser import objtypes
CLASS_ID = 1
CLASS_PROTECTED_ID = 2
CLASS_PRIVATE_ID = 3
METHOD_ID = 4
METHOD_PROTECTED_ID = 5
METHOD_PRIVATE_ID = 6
ATTRIBUTE_ID = 7
ATTRIBUTE_PROTECTED_ID = 8
ATTRIBUTE_PRIVATE_ID = 9
ENUM_ID = 10
KEYWORDS_ID = 11
MODULE_ID = 12


def get_icon_id(nodetype, name):
    if nodetype == objtypes.MODULE:
        return MODULE_ID
    if nodetype == objtypes.FUNCTION_DEF:
        if name.startswith("__"):
            return METHOD_PRIVATE_ID
        if name.startswith("_"):
            return METHOD_PROTECTED_ID
        return METHOD_ID
    if nodetype == objtypes.CLASS_DEF:
        if name.startswith("__"):
            return CLASS_PRIVATE_ID
        if name.startswith("_"):
            return CLASS_PROTECTED_ID
        return CLASS_ID
    if nodetype in [objtypes.CLASS_ATTRIBUTE, objtypes.MODULE_ATTRIBUTE]:
        if name.startswith("__"):
            return ATTRIBUTE_PRIVATE_ID
        if name.startswith("_"):
            return ATTRIBUTE_PROTECTED_ID
        return ATTRIBUTE_ID
    return None
