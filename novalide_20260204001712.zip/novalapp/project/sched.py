# -*- coding: utf-8 -*-
import os
import copy
from typing import Optional, List
from ..util import utils, strutils
from ..syntax import lang
from ..syntax.syntax import SyntaxThemeManager
from ..lib.pyqt import QThread
from ..util.exceptions import ProcessordocNotmatchedErrror
from .. import _


class SchedulerRun(QThread):
    '''
        扫描项目所有文件,每隔一段时间执行
        并发送文件路径作为信号发送给接收者,以便其做相应的处理
    '''
    INTERVAL_TIME_SECONDS = 3000
    SYNTAX_EXTS = []
    SCHED_PROCESSORS = []

    def __init__(
        self,
        parent,
        proj,
        processors: Optional[List]=None,
        files: Optional[List]=None
    ):
        super().__init__(parent)
        self._running = False
        self._stopped = False
        self._proj = proj
        # 如果没有指定处理器,默认使用所有处理器
        if processors is None:
            # 所有的处理器
            self._processors = copy.copy(SchedulerRun.SCHED_PROCESSORS)
        else:
            self._processors = processors
        self._files = files
        # 可运行的有效处理器
        self._run_processors = []
        if len(SchedulerRun.SYNTAX_EXTS) == 0:
            syntax_manager = SyntaxThemeManager.manager()
            lexers = syntax_manager.Lexers
            for lexer in lexers:
                if lexer.LangId == lang.ID_LANG_TXT:
                    continue
                SchedulerRun.SYNTAX_EXTS.extend(lexer.Exts)

    @property
    def processors(self):
        return self._processors

    def stop(self):
        self._stopped = True

    @property
    def running(self):
        return self._running

    @property
    def project(self):
        return self._proj

    def set_project(self, proj):
        self._proj = proj

    def run(self):
        self.watch_project()

    def watch_project(self):
        doc = self._proj
        if doc is not None:
            self.scan_files(doc)

    def collect_files(self, doc, files: list):
        docmodel = doc.GetModel()
        for filepath in docmodel.filePaths:
            if not os.path.exists(filepath):
                continue
            ext = strutils.get_file_extension(filepath)
            if ext in SchedulerRun.SYNTAX_EXTS:
                files.append(filepath)

    def scan_files(self, doc):
        assert doc is not None
        project = doc.GetModel()
        self._running = True
        utils.get_logger().info('start scan project `%s` files', project.name)
        syntax_files = []
        self.init(doc, syntax_files)
        utils.get_logger().info('scan project files count is %d', len(syntax_files))
        for filepath in syntax_files:
            if self._stopped:
                continue
            utils.get_logger().debug('scan project file %s', filepath)
            if not os.path.exists(filepath):
                utils.get_logger().error('project file %s is not exist when scan files', filepath)
                continue
            for processor in self._run_processors:
                if processor.enabled and not self._stopped:
                    try:
                        processor.run(doc, filepath)
                    # 处理项目文件过程中项目文档发送改变,原因是因为启动了多个线程,只允许同时一个线程执行
                    # 其它线程必须停止
                    except (ProcessordocNotmatchedErrror, RuntimeError) as ex:
                        utils.get_logger().error(str(ex))
                        self.stop()
        utils.get_logger().info('end scan project %s files', project.name)
        self.end(doc, syntax_files)
        self._running = False

    def init(self, doc, files):
        # 如果没有指定文件,默认处理项目的所有文件
        if self._files is None:
            self.collect_files(doc, files)
        else:
            for filename in self._files:
                if doc.GetModel().FindFile(filename) and os.path.exists(filename):
                    files.append(filename)
                else:
                    utils.get_logger().error(
                        "file %s is not exist or not in project `%s`",
                        filename,
                        doc.GetModel().name
                    )
        for processor in self._processors:
            if processor.enabled:
                processor.init_progress(len(files))
                if processor.init(doc):
                    utils.get_logger().info('init sched processor `%s` success', processor.name)
                else:
                    processor.stop(_('Processor `%s` init error') % processor.name)
                    utils.get_logger().error('init sched processor `%s` error....', processor.name)
                self._run_processors.append(processor)

    def end(self, doc, files: list):
        for processor in self._run_processors:
            if processor.enabled and not self._stopped:
                try:
                    processor.end(doc)
                    utils.get_logger().info('processor `%s` end...', processor.name)
                except ProcessordocNotmatchedErrror as ex:
                    utils.get_logger().error(str(ex))
                    break
        if self._stopped:
            utils.get_logger().info("user stop scan project files")
            self.parent().event.set()
        files.clear()
        self._processors.clear()
