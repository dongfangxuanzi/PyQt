# -*- coding: utf-8 -*-
import time
import os
from ... import get_app, _
from ...util import ui_utils, fileutils, pathutils
from ...lib.pyqt import QHBoxLayout, QLabel, QMessageBox, QImageReader, Qt
from ...widgets.imagebutton import ImageButton
from ...editor.imageview import ImageDocument

# set the max width of location label,to avoid too long
MAX_LOCATION_LABEL_WIDTH = 400


class ResourcePanel(ui_utils.BaseConfigurationPanel):
    """description of class"""

    def __init__(self, parent, item, current_project):
        super().__init__()
        relative_path = ""
        path = ""
        type_name = ""
        project_path = os.path.dirname(current_project.GetFilename())
        is_file = False
        project_view = current_project.GetFirstView()
        template = None
        if item == project_view._treeCtrl.GetRootItem():
            path = current_project.GetFilename()
            type_name = _("Project")
            relative_path = os.path.basename(path)
        elif project_view._IsItemFile(item):
            path = project_view._GetItemFilePath(item)
            template = get_app().GetDocumentManager().FindTemplateForPath(path)
            type_name = _("File") + "(%s)" % _(template.GetDescription())
            relative_path = path.replace(project_path, "").lstrip(os.sep)
            is_file = True
        else:
            relative_path = project_view._GetItemFolderPath(item)
            type_name = _("Folder")
            path = os.path.join(project_path, relative_path)

        pathbox = QHBoxLayout()
        pathbox.setAlignment(Qt.AlignLeft)
        pathbox.addWidget(QLabel(_("Path") + ":"))
        pathbox.addWidget(QLabel(fileutils.opj(relative_path)))
        self.layout.addLayout(pathbox)

        typebox = QHBoxLayout()
        typebox.setAlignment(Qt.AlignLeft)
        typebox.addWidget(QLabel(_("Type") + ":"))
        typebox.addWidget(QLabel(type_name))
        self.layout.addLayout(typebox)

        locationbox = QHBoxLayout()
        locationbox.setAlignment(Qt.AlignLeft)
        locationbox.addWidget(QLabel(_("Location") + ":"))
        self.dest_path = fileutils.opj(path)
        self.location_label_ctrl = QLabel(self.dest_path)
        locationbox.addWidget(self.location_label_ctrl)
        self.layout.addLayout(locationbox)

        into_btn = ImageButton(_("Into file explorer"))
        into_btn.clicked.connect(self.IntoExplorer)
        into_btn.setIcon(get_app().GetImage("project/into.png"))
        locationbox.addWidget(into_btn)

        copy_btn = ImageButton(_("Copy path"))
        copy_btn.clicked.connect(self.CopyPath)
        copy_btn.setIcon(get_app().GetImage("project/copy.png"))
        locationbox.addWidget(copy_btn)

        is_path_exist = os.path.exists(path)
        show_label_text = ""
        if not is_path_exist:
            show_label_text = _("Resource does not exist")
        if is_file:
            size_hbox = QHBoxLayout()
            size_hbox.setAlignment(Qt.AlignLeft)
            size_hbox.addWidget(QLabel(_("Size") + ":"))
            if is_path_exist:
                show_label_text = str(os.path.getsize(path)) + _(" Bytes")
            size_label_ctrl = QLabel(show_label_text)
            if not is_path_exist:
                size_label_ctrl.setStyleSheet("color:red")
            size_hbox.addWidget(size_label_ctrl)
            self.layout.addLayout(size_hbox)
            # 图片显示分辨率大小
            if issubclass(template.GetDocumentType(), ImageDocument):
                img = QImageReader(path)
                img_size = img.size()
                width = img_size.width()
                height = img_size.height()
                resolution_hbox = QHBoxLayout()
                resolution_hbox.setAlignment(Qt.AlignLeft)
                resolution_hbox.addWidget(QLabel(_("Resolution") + ":"))
                if is_path_exist:
                    if width > 0:
                        show_label_text = '%d x %d' % (width, height)
                    else:
                        show_label_text = _('Unknown image format')
                resolution_label_ctrl = QLabel(show_label_text)
                if not is_path_exist or width < 0:
                    resolution_label_ctrl.setStyleSheet("color:red")
                resolution_hbox.addWidget(resolution_label_ctrl)
                self.layout.addLayout(resolution_hbox)
        created_hbox = QHBoxLayout()
        created_hbox.setAlignment(Qt.AlignLeft)
        created_hbox.addWidget(QLabel(_("Created") + ":"))
        if is_path_exist:
            show_label_text = time.ctime(os.path.getctime(path))
        ctime_lable_ctrl = QLabel(show_label_text)
        if not is_path_exist:
            ctime_lable_ctrl.setStyleSheet("color:red")
        created_hbox.addWidget(ctime_lable_ctrl)
        self.layout.addLayout(created_hbox)

        modified_hbox = QHBoxLayout()
        modified_hbox.setAlignment(Qt.AlignLeft)
        if is_path_exist:
            show_label_text = time.ctime(os.path.getmtime(path))
        modified_hbox.addWidget(QLabel(_("Modified") + ":"))
        mtime_label_ctrl = QLabel(show_label_text)
        if not is_path_exist:
            mtime_label_ctrl.setStyleSheet("color:red")
        modified_hbox.addWidget(mtime_label_ctrl)
        self.layout.addLayout(modified_hbox)

        accessed_hbox = QHBoxLayout()
        accessed_hbox.setAlignment(Qt.AlignLeft)
        accessed_hbox.addWidget(QLabel(_("Accessed") + ":"))
        if is_path_exist:
            show_label_text = time.ctime(os.path.getatime(path))
        atime_label_ctrl = QLabel(show_label_text)
        if not is_path_exist:
            atime_label_ctrl.setStyleSheet("color:red")
        accessed_hbox.addWidget(atime_label_ctrl)
        self.layout.addLayout(accessed_hbox)
        self.layout.addStretch(1)

    def IntoExplorer(self):
        location = self.dest_path
        pathutils.safe_open_file_directory(location)

    def CopyPath(self):
        path = self.dest_path
        ui_utils.copytoclipboard(path)
        QMessageBox.information(
            self, get_app().GetAppName(), _("Copied to clipboard"))

    def OnOK(self, optionsDialog):
        return True
