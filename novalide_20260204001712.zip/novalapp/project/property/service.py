from ... import get_app, _
from ...util import utils
from .property import PropertyDialog, PROJECT_PROPERTY, FILE_PROPERTY, FOLDER_PROPERTY


class PropertiesService:
    """
    Service that installs under the File menu to show the properties of the file associated
    with the current document.
    """

    def __init__(self):
        """
        Initializes the PropertyService.
        """
        self._options_panel_classes = []
        self.current_project_document = get_app().MainFrame.projectview.GetCurrentProject()
        pages = self.current_project_document.GetDocumentTemplate().GetPropertiPages()
        for item, name, objclass in pages:
            self.AddOptionsPanelClass(item, name, objclass)

    def AddOptionsPanelClass(self, item, name, options_panel_class):
        if isinstance(options_panel_class, str):
            try:
                options_panel_class = utils.get_class_from_dynamicimport_module(
                    options_panel_class)
            except Exception as e:
                utils.get_logger().exception('load property page %s error', options_panel_class)
                return
        self._options_panel_classes.append((item, name, options_panel_class),)

    def GetOptionPanelClasses(self):
        return self._optionsPanels

    def GetItemOptionsPanelClasses(self, name):
        option_panel_classes = []
        for options_panel_class in self._options_panel_classes:
            if options_panel_class[1] == name:
                option_panel_classes.append(options_panel_class)
        return option_panel_classes

    def ShowPropertyDialog(self, item, option_name=None):
        """
        Shows the PropertiesDialog for the specified file.
        """
        project_view = self.current_project_document.GetFirstView()
        option_pages = {}
        if item == project_view._treeCtrl.GetRootItem():
            title = _("Project Property")
            option_pages = self.GetItemOptionsPanelClasses(PROJECT_PROPERTY)
        elif project_view._IsItemFile(item):
            title = _("File Property")
            option_pages = self.GetItemOptionsPanelClasses(FILE_PROPERTY)
        else:
            title = _("Folder Property")
            option_pages = self.GetItemOptionsPanelClasses(FOLDER_PROPERTY)

        property_dialog = PropertyDialog(
            get_app().GetTopWindow(), title, item, option_pages, option_name)
        property_dialog.exec_()
