# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------------
# Name:        baseviewer.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-02-15
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
# -------------------------------------------------------------------------------
import sys
import stat
import shutil
import datetime
import os.path
import os
from .. import get_app, _
from ..lib.template import DocTemplate
from ..lib.docview import View
from ..lib.docmanager import DOC_SILENT, DOC_OPEN_ONCE
from .treeview import treeitems
from ..util import ui_utils, utils, strutils, fileutils, filewatcher, apputils, pathutils
from .. import constants, menuitems
from .. import globalkeys
from .wizard import wizard as projectwizard
from .wizard import page as wizardpage
from .wizard.templatemanager import WizardtemplateManager
from .wizard.namelocation import ProjectNameLocationPage
from .wizard.importfiles import ImportfilesPage
from ..lib.pyqt import (
    QMessageBox,
    QCheckBox,
    QLabel,
    QSizePolicy,
    pyqtSignal,
    QFileDialog,
    QPushButton,
    QHBoxLayout,
    QLineEdit,
    QComboBox
)
from . import command as projectcommand
from .ui.importfiles import ImportfilesDialog
from .ui.newfile import NewFileDialog
from .wizard.filters import FileFilterDialog
from . import ext
from .clipboard import JsonDataobject
from .property.property import PROJECT_PROPERTY, FILE_PROPERTY, FOLDER_PROPERTY, RESOURCE_ITEM_NAME
from . import typedefines
# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------


def getProjectKeyName(project_document):
    return project_document.GetKey("OpenFolders")
# ----------------------------------------------------------------------------
# Classes
# ----------------------------------------------------------------------------


def AddProjectMapping(doc, projectdoc=None, hint=None):
    project_view = get_app().MainFrame.projectview
    if not projectdoc:
        if not hint:
            hint = doc.GetFilename()
        projectdocs = project_view.FindProjectByFile(hint)
        if projectdocs:
            projectdoc = projectdocs[0]
    project_view.AddProjectMapping(doc, projectdoc)
    if hasattr(doc, "GetModel"):
        project_view.AddProjectMapping(doc.GetModel(), projectdoc)


class NewProjectWizard(projectwizard.BaseWizard):
    sig_import_files = pyqtSignal()

    def __init__(self, parent):
        self._parent = parent
        projectwizard.BaseWizard.__init__(self, parent)
        self.setFixedSize(550, 550)
        self._project_template_page = self.CreateProjectTemplatePage()
        self.project_template_icon = get_app().GetImage("project/wizard_folder.gif")
        self.project_templates = WizardtemplateManager.get_manager().ProjectTemplates
        self.LoadProjectTemplates()
        self.sig_import_files.connect(self.set_importfiles_state)

    def set_importfiles_state(self):
        self.ok_button.setEnabled(False)
        self.prev_button.setEnabled(False)

    def CreateProjectTemplatePage(self):
        page = wizardpage.BitmapTitledWizardPage(
            self,
            _("New Project Wizard"),
            _("Welcom to new project wizard"),
            get_app().MainFrame.projectview.get_titled_bitmap()
        )
        self.content.layout().insertWidget(0, page)
        WizardtemplateManager.get_manager().create_tree_view(self, page)
        return page

    @staticmethod
    def LoadDefaultProjectTemplates():
        WizardtemplateManager.get_manager().AddProjectTemplate(
            _("General"),
            WizardtemplateManager.EMPTY_PROJECT,
            _("Empty Project"),
            [ProjectNameLocationPage, ]
        )
        WizardtemplateManager.get_manager().AddProjectTemplate(
            _("General"),
            WizardtemplateManager.PROJECT_FROM_EXIST_CODE,
            _("New Project From Existing Code"),
            [
                ("novalapp.project.wizard.namelocation.ProjectNameLocationPage", {
                 'can_finish': False}),
                "novalapp.project.wizard.importfiles.ImportfilesPage"
            ]
        )

    def LoadProjectTemplates(self):
        WizardtemplateManager.get_manager().LoadProjectTemplates(self)


class ProjectTemplate(DocTemplate):
    def CreateDocument(self, path, flags):
        if path:
            doc = DocTemplate.CreateDocument(self, path, flags)
            if path:
                doc.GetModel()._projectDir = os.path.dirname(path)
            return doc
        wiz = ProjectView.WIZARD_CLS(get_app().GetTopWindow())
        wiz.RunWizard(wiz._project_template_page)
        return None  # never return the doc, otherwise docview will think it is a new file and rename it

    def GetPropertiPages(self):
        return [
            (RESOURCE_ITEM_NAME, PROJECT_PROPERTY,
             "novalapp.project.property.resource.ResourcePanel"),
            (RESOURCE_ITEM_NAME, FILE_PROPERTY,
             "novalapp.project.property.resource.ResourcePanel"),
            (RESOURCE_ITEM_NAME, FOLDER_PROPERTY,
             "novalapp.project.property.resource.ResourcePanel"),
        ]

    @staticmethod
    def CreateProjectTemplate():
        project_template = ProjectTemplate(GetApp().GetDocumentManager(),
                                           _("Project File"),
                                           "*%s" % consts.PROJECT_EXTENSION,
                                           os.getcwd(),
                                           consts.PROJECT_EXTENSION,
                                           "Project Document",
                                           _("Project Viewer"),
                                           projectdocument.ProjectDocument,
                                           ProjectView,
                                           icon=imageutils.getProjectIcon())
        GetApp().GetDocumentManager().AssociateTemplate(project_template)
        return project_template


class ProjectView(View, ui_utils.AlarmEventMixin):
    WIZARD_CLS = NewProjectWizard
    # ----------------------------------------------------------------------------
    # Overridden methods
    # ----------------------------------------------------------------------------

    def __init__(self, frame):
        super().__init__()
        ui_utils.AlarmEventMixin.__init__(self)
        self._prject_browser = frame  # not used, but kept to match other Services
        self._treeCtrl = self._prject_browser.project_treeview
        self._loading = False  # flag to not to try to saving state of folders while it is loading
        self._documents = []
        self._document = None
        self._bold_item = None
        ProjectView.WIZARD_CLS.LoadDefaultProjectTemplates()

    # Overshadow this since the superclass uses the view._viewDocument attribute directly, which the project editor doesn't use since it hosts multiple docs
    def GetDocumentManager(self):
        return get_app().GetDocumentManager()

    @property
    def IsImportStop(self):
        return self._prject_browser.stop_import

    @property
    def Documents(self):
        return self._documents

    def GetDocument(self):
        return self._document

    def GetFrame(self):
        return self._prject_browser

    def SetDocument(self, doc):
        self._document = doc

    def Activate(self, activate=True):
        View.Activate(self, activate=activate)
        if activate and self._treeCtrl:
            self._treeCtrl.setFocus()
        self.Show()

    def OnCreate(self, doc, flags):
        return True

    def OnChangeFilename(self):
        pass

    def ProjectSelect(self):
        selitem = self._prject_browser.project_combox.currentIndex()
        if selitem == -1:
            self._prject_browser.project_combox.setToolTip('')
            self._prject_browser.properties_button.setEnabled(False)
            self._prject_browser.unload_button.setEnabled(False)
            return
        document = self._documents[selitem]
        self.SetDocument(document)
        self.LoadProject(self.GetDocument())
        if self.GetDocument():
            filename = self.GetDocument().GetFilename()
        else:
            filename = ''
        self._prject_browser.project_combox.setToolTip(filename)
        self._prject_browser.properties_button.setEnabled(True)
        self._prject_browser.unload_button.setEnabled(True)

    def WriteProjectConfig(self):
        config = get_app().GetConfig()
        project_filenames = []
        for i in range(self._prject_browser.project_combox.count()):
            project_document = self._documents[i]
            if not project_document.OnSaveModified():
                return False
            if project_document.GetDocumentSaved():  # Might be a new document and "No" selected to save it
                project_filenames.append(project_document.GetFilename())
        config.Write(globalkeys.PROJECT_SAVE_DOCS_KEY,
                     project_filenames.__repr__())
        document = None
        i = self._prject_browser.project_combox.currentIndex()
        if i != -1:
            document = self._documents[i]
        if document:
            config.Write(globalkeys.CURRENT_PROJECT_KEY,
                         document.GetFilename())
        else:
            config.DeleteEntry(globalkeys.CURRENT_PROJECT_KEY)
        return True

    def OnClose(self, deleteWindow=True):
        '''
            所有项目文档共用同一个视图,如果这里实关闭项目文档,会导致文档重复关闭
            重复弹出文档保存提示框
        '''
        return True

    def AddProgressFiles(self, new_filepaths, range_value, project_doc, progress_ui, progress_que):
        project = project_doc.GetModel()
        project_dir = project.homeDir
        # add new folders and new items
        for filepath in new_filepaths:
            file = project.FindFile(filepath)
            if file:
                folderpath = file.logicalFolder
                if folderpath is None:
                    folderpath = ""
                # 路径有可能不符合规范,规范路径格式
                dest_path = fileutils.opj(os.path.join(
                    project_dir, folderpath, os.path.basename(filepath)))
                utils.get_logger().debug('copy file %s to dest path %s', filepath, dest_path)
                # 如果源文件和目的文件地址一样,则不用覆盖
                if not fileutils.ComparePath(filepath, dest_path):
                    # 判断目的文件是否存在
                    is_dest_exist = os.path.exists(dest_path)
                    if is_dest_exist:
                        # 如果文件已经存在于项目中,需要先移除
                        if project.FindFile(dest_path):
                            project.RemoveFile(file)
                        # 选择yes和no将显示覆盖确认对话框
                        if progress_ui.DEFAULT_PROMPT_MESSAGE_ID in (QMessageBox.Yes, QMessageBox.No):
                            # 不支持多线程中弹出对话框,使用信号槽的方式弹出提示对话框
                            progress_ui.sig_show_messagebox.emit(filepath)
                            # 由于发送信号是异步的,必须设置等待event
                            progress_ui.wait_event.wait()
                            # 下一次等待
                            progress_ui.wait_event.clear()
                        # 选择No时不要覆盖文件
                        if progress_ui.DEFAULT_PROMPT_MESSAGE_ID in [QMessageBox.NoToAll, QMessageBox.No]:
                            range_value += 1
                            continue
                    else:
                        dest_dir_path = os.path.dirname(dest_path)
                        if not os.path.exists(dest_dir_path):
                            fileutils.makedirs(dest_dir_path)
                    # 选择yestoall和notoall将不再显示覆盖确认对话框
                    if not is_dest_exist or progress_ui.DEFAULT_PROMPT_MESSAGE_ID in [QMessageBox.YesToAll, QMessageBox.Yes]:
                        try:
                            shutil.copyfile(filepath, dest_path)
                        except Exception as e:
                            utils.get_logger().exception('copy import file error:')
                            progress_ui.update_progress_signal.emit(
                                range_value, "error:%s" % str(e))
                            return
                    file.filePath = dest_path
                # 使用发送信号的方式向treeview中添加节点,以便支持多线程插入节点
                self._treeCtrl.sigAddFileItem.emit(file, project_doc)
            range_value += 1
            progress_que.put((range_value, filepath))
            # progress_ui.update_progress_signal.emit(range_value,filePath)
            assert (isinstance(range_value, int) and range_value > 0)
            if progress_ui.is_cancel:
                utils.get_logger().info("user stop import code files")
                break

    def OnUpdate(self, sender=None, hint=None):
        if View.OnUpdate(self, sender, hint):
            return
        if hint:
            if hint[0] == constants.PROJECT_ADD_COMMAND_NAME:
                projectdoc = hint[1]
                if self.GetDocument() != projectdoc:  # project being updated isn't currently viewed project
                    return
                # need to be added and selected, and sorted
                new_filepaths = hint[2]
                project = projectdoc.GetModel()
                projectdir = project.homeDir
                root_item = self._treeCtrl.GetRootItem()
                # add new folders and new items
                add_list = []
                for filepath in new_filepaths:
                    file = project.FindFile(filepath)
                    if file:
                        folderpath = file.logicalFolder
                        if folderpath:
                            self.AddFolderItem(projectdoc, folderpath)
                            folder = self._treeCtrl.FindFolder(folderpath)
                        else:
                            folder = root_item
                        if folderpath is None:
                            folderpath = ""
                        dest_path = os.path.join(
                            projectdir, folderpath, os.path.basename(filepath))
                        if not fileutils.ComparePath(filepath, dest_path):
                            if os.path.exists(dest_path):
                                # the dest file is already in the project
                                if project.FindFile(dest_path):
                                    project.RemoveFile(file)
                                if ImportfilesPage.DEFAULT_PROMPT_MESSAGE_ID in (QMessageBox.Yes, QMessageBox.No):
                                    ret = QMessageBox.question(
                                        get_app().GetTopWindow(),
                                        _("Project File Exists"),
                                        ("The file %s is already exist in project ,Do You Want to overwrite it?") % filepath,
                                        QMessageBox.Yes | QMessageBox.No | QMessageBox.YesToAll | QMessageBox.NoToAll
                                    )
                                    ImportfilesPage.DEFAULT_PROMPT_MESSAGE_ID = ret
                            if ImportfilesPage.DEFAULT_PROMPT_MESSAGE_ID in (QMessageBox.YesToAll, QMessageBox.Yes):
                                shutil.copyfile(filepath, dest_path)
                            file.filePath = dest_path
                        if not self._treeCtrl.FindItem(file.filePath, folder):
                            item = self._treeCtrl.AppendItem(
                                folder, os.path.basename(file.filePath), file)
                            if item is not None:
                                add_list.append(item)
                        self._treeCtrl.expandItem(folder)
                # select last item of user wanted to add items
                lastitem = None
                if add_list:
                    lastitem = add_list[-1]
                    self._treeCtrl.SelectItem(lastitem)
                return
            if hint[0] == constants.PROJECT_ADD_PROGRESS_COMMAND_NAME:
                projectdoc = hint[1]
                if self.GetDocument() != projectdoc:  # project being updated isn't currently viewed project
                    return
                # need to be added and selected, and sorted
                new_filepaths = hint[2]
                range_value = hint[3]  # need to be selected
                progress_ui = hint[4]
                progress_que = hint[5]
                self.AddProgressFiles(
                    new_filepaths, range_value, projectdoc, progress_ui, progress_que)
                return
            if hint[0] == constants.PROJECT_REMOVE_COMMAND_NAME:
                projectdoc = hint[1]
                if self.GetDocument() != projectdoc:  # project being updated isn't currently viewed project
                    return
                filepaths = hint[2]
                for filepath in filepaths:
                    item = self._treeCtrl.FindItem(filepath)
                    if item:
                        parent_item = item.parent()
                        self._treeCtrl.delete_node(item)
                        if 0 == self._treeCtrl.GetChildrenCount(parent_item):
                            self._treeCtrl.delete_node(parent_item)
                return
            if hint[0] == "rename":
                projectdoc = hint[1]
                if self.GetDocument() != projectdoc:  # project being updated isn't currently viewed project
                    return
                self._treeCtrl.Freeze()
                try:
                    item = self._treeCtrl.FindItem(hint[2])
                    self._treeCtrl.SetItemText(item, os.path.basename(hint[3]))
                    self._treeCtrl.EnsureVisible(item)
                finally:
                    self._treeCtrl.Thaw()
                return
            if hint[0] == "rename folder":
                projectdoc = hint[1]
                if self.GetDocument() != projectdoc:  # project being updated isn't currently viewed project
                    return
                item = self._treeCtrl.FindFolder(hint[2])
                if item:
                    item.setData(0, os.path.basename(hint[3]))
                    self._treeCtrl.setCurrentItem(item)
                return

    def RemoveProjectUpdate(self, projectDoc):
        """ Called by service after deleting a project, need to remove from project choices """
        i = self._projectChoice.FindString(self._MakeProjectName(projectDoc))
        self._projectChoice.Delete(i)

        numProj = self._projectChoice.GetCount()
        if i >= numProj:
            i = numProj - 1
        if i >= 0:
            self._projectChoice.SetSelection(i)
        self._documents.remove(self._document)
        wx.GetApp().GetDocumentManager().CloseDocument(projectDoc, False)
        self._document = None
        self.OnProjectSelect()

    def ReloadDocuments(self):
        names = []
        for document in self._documents:
            names.append(self._MakeProjectName(document))
        self._prject_browser.project_combox.clear()
        self._prject_browser.project_combox.addItems(names)

    def RemoveCurrentDocumentUpdate(self):
        self.RemoveDocumentUpdate(self._document)

    def RemoveDocumentUpdate(self, doc):
        """ Called by service after deleting a project, need to remove from project choices """
        i = self._prject_browser.project_combox.currentIndex()
        self._documents.remove(doc)
        self.ReloadDocuments()
        numproj = len(self._documents)
        if i >= numproj:
            i = numproj - 1
        if i >= 0:
            self._prject_browser.project_combox.setCurrentIndex(i)
        self._document = None
        self.ProjectSelect()

    def CloseProject(self):
        projectdoc = self.GetDocument()
        if projectdoc:
            if self.close_doc(projectdoc):
                self._prject_browser.SIG_CLOSE_PROJECT_DOC.emit(projectdoc)
                if not self.GetDocument():
                    self.AddProjectRoot(_("Projects"))

    def close_doc(self, projectdoc, force=False):
        '''
            关闭项目文档
            force:是否强制关闭项目文档,如果强制关闭,不会弹出任何询问保存文件的对话框
        '''
        opendocs = self.GetDocumentManager().GetDocuments()
        # 先关闭所有项目打开文档
        # need to make a copy, as each file closes we're off by one
        for opendoc in opendocs[:]:
            if projectdoc == opendoc:  # close project last
                continue

            if projectdoc == self._prject_browser.FindProjectFromMapping(opendoc):
                if not self.GetDocumentManager().CloseDocument(opendoc, force):
                    return False

                self._prject_browser.RemoveProjectMapping(opendoc)
                if hasattr(opendoc, "GetModel"):
                    self._prject_browser.RemoveProjectMapping(
                        opendoc.GetModel())
        # delete project regkey config
        if self.GetDocumentManager().CloseDocument(projectdoc, force):
            projectdoc.document_watcher.RemoveFileDoc(projectdoc)
            # 从项目浏览器中移除项目文档
            self.RemoveDocumentUpdate(projectdoc)
            return True
        return False

    def OnResourceViewToolClicked(self, event):
        id = event.GetId()
        if id in (ResourceView.REFRESH_PATH_ID, ResourceView.ADD_FOLDER_ID):
            return self.dir_ctrl.ProcessEvent(event)

    def SetProjectStartupFile(self):
        item = self._treeCtrl.GetSingleSelectItem()
        self.SetProjectStartupFileItem(item)

    def SetProjectStartupFileItem(self, item, modify=True):
        if item == self._bold_item:
            return
        pjfile = self._GetItemFile(item)
        self._bold_item = item
        self.GetDocument().GetModel().StartupFile = pjfile
        self.GetDocument().Modify(modify)

    def OpenProject(self, project_path):
        docs = get_app().GetDocumentManager().CreateDocument(
            project_path, DOC_SILENT | DOC_OPEN_ONCE)
        if not docs:  # project already open
            self.SetProject(project_path)
        elif docs:
            if docs[0] not in self.GetDocumentManager().GetDocuments():
                utils.get_logger().error('open project %s error', project_path)
                return
            AddProjectMapping(docs[0])

    @ui_utils.wait_cursor
    def SaveProject(self):
        doc = self.GetDocument()
        if doc.IsModified():
            get_app().GetTopWindow().PushStatusText(_("Project is saving..."))
            if doc.OnSaveDocument(doc.GetFilename()):
                get_app().GetTopWindow().PushStatusText(_("Project save success."))
            else:
                get_app().GetTopWindow().PushStatusText(_("Project save failed."))

    @ui_utils.wait_cursor
    def CleanProject(self):
        project_doc = self.GetDocument()
        project_doc.CleanProject()
        get_app().GetTopWindow().PushStatusText(_("Clean Completed."))

    @ui_utils.wait_cursor
    def ArchiveProject(self):
        doc = self.GetDocument()
        path = os.path.dirname(doc.GetFilename())
        try:
            get_app().GetTopWindow().PushStatusText(_("Archiving..."))
            datetime_str = datetime.datetime.strftime(
                datetime.datetime.now(), '%Y%m%d%H%M%S')
            zip_name = doc.GetModel().Name + "_" + datetime_str + ".zip"
            zip_path = doc.ArchiveProject(os.path.join(path, zip_name))
            QMessageBox.information(self.GetFrame(), _(
                "Archive Success"), _("Success archived to %s") % zip_path)
            get_app().GetTopWindow().PushStatusText(_("Success archived to %s") % zip_path)
        except Exception as e:
            utils.get_logger().exception("")
            QMessageBox.critical(self.GetFrame(), _("Archive Error"), str(e))
            get_app().GetTopWindow().PushStatusText(_("Archive Error"))

    def ImportFilesToProject(self, item):
        if item is None:
            item = self._treeCtrl.GetRootItem()
        folderPath = self._GetItemFolderPath(item)
        dlg = ImportfilesDialog(get_app().GetTopWindow(), folderPath)
        if dlg.exec_() == ImportfilesDialog.Accepted:
            if not self._treeCtrl.isItemExpanded(item):
                self._treeCtrl.expandItem(item, True)
    # ----------------------------------------------------------------------------
    # Display Methods
    # ----------------------------------------------------------------------------

    def Hide(self):
        self.Show(False)

    def Show(self, show=True):
        get_app().MainFrame.activateProjectTab()
       # if wx.GetApp().IsMDI():
        #    mdiParentFrame = wx.GetApp().GetTopWindow()
        #    mdiParentFrame.ShowEmbeddedWindow(self.GetFrame(), show)

    # ----------------------------------------------------------------------------
    # Methods for ProjectDocument and ProjectService to call
    # ----------------------------------------------------------------------------

    def SetProject(self, projectPath):
        if self._prject_browser.is_loading:
            utils.get_logger().info(
                "app is loading projects at startup ,do not load project document %s at this time", projectPath)
            return

        curSel = self._prject_browser.project_combox.currentIndex()
        for i in range(self._prject_browser.project_combox.count()):
            document = self._documents[i]
            if document.GetFilename() == projectPath:
                if curSel != i:  # don't reload if already loaded
                    utils.get_logger().info("switch to and load project document %s", projectPath)
                    self._prject_browser.project_combox.setCurrentIndex(i)
                    self.SetDocument(document)
                    self.LoadProject(document)
                break

    def GetSelectedFile(self):
        for item in self._treeCtrl.selection():
            filePath = self._GetItemFilePath(item)
            if filePath:
                return filePath
        return None

    def GetSelectedFiles(self):
        filePaths = []
        for item in self._treeCtrl.selection():
            filePath = self._GetItemFilePath(item)
            if filePath and filePath not in filePaths:
                filePaths.append(filePath)
        return filePaths

    def GetSelectedPhysicalFolder(self):
        if self.GetMode() == ProjectView.PROJECT_VIEW:
            return None
        else:
            for item in self._treeCtrl.GetSelections():
                if not self._IsItemFile(item):
                    filePath = self._GetItemFolderPath(item)
                    if filePath:
                        return filePath
            return None

    def GetSelectedProject(self):
        document = self.GetDocument()
        if document:
            return document.GetFilename()
        return None

    def GetProjectSelection(self, document):
        for i in range(self._prject_browser.project_combox.count()):
            project = self._documents[i]
            if document == project:
                return i
        return -1

    def AddProjectToView(self, document):
        # check the project is already exist or not
        index = self.GetProjectSelection(document)
        # if proejct not exist,add the new document
        if index == -1:
            self._documents.append(document)
            index = self._prject_browser.AddProject(
                self._MakeProjectName(document))
        self._prject_browser.project_combox.setCurrentIndex(index)
        self.ProjectSelect()

    def LoadDocuments(self):
        self._projectChoice.Clear()
        for document in self._documents:
            i = self._projectChoice.Append(self._MakeProjectName(
                document), getProjectBitmap(), document)
            if document == self.GetDocument():
                self._projectChoice.SetSelection(i)

    def AddProjectRoot(self, document_or_name):
        self._treeCtrl.source_model().clear()
        project_icon = None
        if isinstance(document_or_name, str):
            name = document_or_name
            text = name
        else:
            document = document_or_name
            text = document.GetModel().Name
            project_icon = document.GetDocumentTemplate().GetIcon()
        return self._treeCtrl.AddProjectRoot(text, project_icon)

    def AddFolderItem(self, document, folderPath):
        return self._treeCtrl.AddFolder(folderPath)

    @ui_utils.wait_cursor
    def LoadProject(self, document):
        # 切换项目时加粗的节点重置为空,如果项目设置有启动文件,则将该启动文件节点加粗
        self._bold_item = None
        rootitem = self.AddProjectRoot(document)
        if document:
            folders = document.GetModel().logicalFolders
            folders.sort()
            folder_items = []
            for folderpath in folders:
                folder_items = folder_items + \
                    self.AddFolderItem(document, folderpath)

            for file in document.GetModel()._files:
                folder = file.logicalFolder
                if folder:
                    foldertree = folder.split('/')
                    item = rootitem
                    for foldername in foldertree:
                        found = False
                        for child in item.children():
                            if child.data() == foldername:
                                item = child
                                found = True
                                break

                        if not found:
                            # print "error folder '%s' not found for %s" % (folder, file.filePath)
                            break
                else:
                    item = rootitem

                fileItem = self._treeCtrl.AppendItem(
                    item, os.path.basename(file.filePath), file)
                startupFile = document.GetModel().runinfo.StartupFile
                # 设置项目启动文件
                if startupFile and document.GetModel().fullPath(startupFile) == file.filePath:
                    # 加载项目文件并设置启动文件时不应设置项目文件修改状态
                    self.SetProjectStartupFileItem(fileItem, modify=False)
            if utils.profile_get_int(globalkeys.LOAD_FOLDERSTATE_KEY, True):
                self.LoadFolderState()
            self._treeCtrl.setFocus()

    def ProjectHasFocus(self):
        """ Does Project Choice have focus """
        return wx.Window.FindFocus() == self._projectChoice

    def ClearFolderState(self):
        config = get_app().GetConfig()
        config.DeleteGroup(getProjectKeyName(self.GetDocument()))

    def SaveFolderState(self):
        """ 保存项目文件夹打开或关闭状态 """
        if self._loading:
            return
        folderlist = []
        rootitem = self._treeCtrl.GetRootItem()
        # 项目根节点是否展开,如果展开保存节点状态
        if self._treeCtrl.isItemExpanded(rootitem):
            folderlist.append(self._GetItemFolderPath(rootitem))
        folder_item_list = self._GetFolderItems(rootitem)
        for item in folder_item_list:
            # 判断节点是否处于展开状态,如果是,则保存展开状态
            if self._treeCtrl.isItemExpanded(item):
                folderlist.append(self._GetItemFolderPath(item))
        utils.profile_set(getProjectKeyName(
            self.GetDocument()), repr(folderlist))

    def LoadFolderState(self):
        """ 加载项目文件夹打开或关闭状态"""
        self._loading = True
        config = get_app().GetConfig()
        open_folder_data = config.Read(
            getProjectKeyName(self.GetDocument()), "")
        if open_folder_data:
            folderlist = eval(open_folder_data)
            rootitem = self._treeCtrl.GetRootItem()
            root_folder_path = self._GetItemFolderPath(rootitem)
            # 加载展开/关闭根节点状态
            self._treeCtrl.expandItem(rootitem, root_folder_path in folderlist)
            folder_item_list = self._GetFolderItems(rootitem)
            for item in folder_item_list:
                folderpath = self._GetItemFolderPath(item)
                # 加载展开/关闭子节点状态
                self._treeCtrl.expandItem(item, folderpath in folderlist)
        self._loading = False
    # ----------------------------------------------------------------------------
    # Control events
    # ----------------------------------------------------------------------------

    def OnAddNewFile(self):
        items = self._treeCtrl.selection()
        if items:
            item = items[0]
            folderpath = self._GetItemFolderPath(item)
        else:
            folderpath = ""
        dlg = NewFileDialog(self.GetFrame(), _("New FileType"), folderpath)
        if dlg.exec_() == NewFileDialog.Accepted:
            if self.GetDocument().GetCommandProcessor().Submit(
                projectcommand.ProjectAddFilesCommand(self.GetDocument(),
                                                      [dlg.file_path], folderPath=folderpath)
            ):
                item = self._treeCtrl.FindItem(dlg.file_path)
                self._treeCtrl.setCurrentItem(item)
                self._prject_browser.OpenSelection(item)

    def OnAddFolder(self):
        if self.GetDocument():
            items = self._treeCtrl.selection()
            if items:
                item = items[0]
                if self._IsItemFile(item):
                    item = self._treeCtrl.parent(item)
                folder_dir = self._GetItemFolderPath(item)
            else:
                folder_dir = ""
            if folder_dir:
                folder_dir += "/"
            folderpath = "%sUntitled" % folder_dir
            i = 1
            while self._treeCtrl.FindFolder(folderpath):
                i += 1
                folderpath = "%sUntitled%s" % (folder_dir, i)
            projectdir = self.GetDocument().GetModel().homeDir
            dest_folder_path = os.path.join(projectdir, folderpath)
            try:
                os.mkdir(dest_folder_path)
            except Exception as e:
                QMessageBox.critical(
                    self.GetFrame(), get_app().GetAppName(), str(e))
                return
            self.GetDocument().GetCommandProcessor().Submit(
                projectcommand.ProjectAddFolderCommand(self, self.GetDocument(), folderpath))
            item = self._treeCtrl.FindFolder(folderpath)
            self._treeCtrl.setCurrentItem(item)
            self.OnRename(item)

    def DeleteFolder(self, folderpath, delete_folder_files=True):
        projectdir = self.GetDocument().GetModel().homeDir
        folder_local_path = os.path.join(projectdir, folderpath)
        if delete_folder_files:
            if os.path.exists(folder_local_path):
                try:
                    fileutils.RemoveDir(folder_local_path)
                except Exception as e:
                    messagebox.showerror(_("Delete Folder"), "Could not delete '%s'.  %s" % (os.path.basename(folder_local_path), e),
                                         parent=self.GetFrame())
                    return
        item = self._treeCtrl.FindFolder(folderpath)
        self.DeleteFolderItems(item)
        try:
            self._treeCtrl.delete_node(item)
        except RuntimeError as ex:
            utils.get_logger().warning(str(ex))
        return True

    def DeleteFolderItems(self, folder_item):
        files = []
        items = folder_item.children()
        for item in items:
            if not self._IsItemFile(item):
                self.DeleteFolderItems(item)
            else:
                files.append(item.path)
        if files:
            self.GetDocument().GetCommandProcessor().Submit(
                projectcommand.ProjectRemoveFilesCommand(self.GetDocument(), files))

    def OnAddFileToProject(self):
        project_template = self.GetDocumentManager(
        ).FindTemplateForTestPath(ext.COMMON_PROJECT_EXTENSION)
        # 注意这里最好不要设置initialdir,会自动选择上一次打开的目录
        descrs = self.GetDocumentManager().get_filters(
            project_template.GetDocumentType())
        paths, filetype = QFileDialog.getOpenFileNames(
            self._prject_browser,
            _('Add file to project'),
            None,  # 记住上次选择的路径
            descrs  # 设置文件扩展名过滤,用双分号间隔
        )
        if not paths:
            return
        newpaths = []
        # 必须先格式化所有路径
        for path in paths:
            newpaths.append(fileutils.opj(path))
        item = self._treeCtrl.GetSingleSelectItem()
        if item:
            folderpath = self._GetItemFolderPath(item)
            self.GetDocument().GetCommandProcessor().Submit(
                projectcommand.ProjectAddFilesCommand(
                    self.GetDocument(),
                    newpaths,
                    folderPath=folderpath
                )
            )
            self.Activate()  # after add, should put focus on project editor

    def OnAddDirToProject(self):
        class AddDirProjectDialog(ui_utils.BaseModalDialog):
            def __init__(self, parent, view):
                self._view = view
                super().__init__(_("Add Directory Files to Project"), parent)
                hbox = QHBoxLayout()
                hbox.addWidget(QLabel(_("Directory:")))
                self.dirctrl = QLineEdit()
                self.dirctrl.setText(os.path.dirname(
                    self._view.GetDocument().GetFilename()))
                hbox.addWidget(self.dirctrl)
                finddir_button = QPushButton(_("Browse..."))
                finddir_button.clicked.connect(self.OnBrowseButton)
                hbox.addWidget(finddir_button)
                self.layout.addLayout(hbox)

                self.visible_templates = []
                for template in self._view.GetDocumentManager()._templates:
                    if template.IsVisible() and not isinstance(template, ProjectTemplate):
                        self.visible_templates.append(template)
                choices = []
                descr = ''
                for template in self.visible_templates:
                    if len(descr) > 0:
                        descr = descr + _('|')
                    descr = _(template.GetDescription()) + \
                        " (" + template.GetFileFilter() + ")"
                    choices.append(descr)
                choices.insert(0, _("All Files") + "(*.*)")  # first item
                filetypes_box = QHBoxLayout()
                filetypes_box.addWidget(QLabel(_("Files of type:")))
                self.filterChoice = QComboBox()
                filetypes_box.addWidget(self.filterChoice)
                self.filterChoice.addItems(choices)
                self.filterChoice.setCurrentIndex(0)
                self.filterChoice.setEditable(False)
                self.filterChoice.setToolTip(_("Select file type filter."))
                self.layout.addLayout(filetypes_box)

                self.subfolderCtrl = QCheckBox(
                    _("Add files from subdirectories"))
                self.subfolderCtrl.setChecked(True)
                self.layout.addWidget(self.subfolderCtrl)

                self.create_standard_buttons()

            def OnBrowseButton(self):
                options = QFileDialog.Options()
                options |= QFileDialog.DontUseNativeDialog | QFileDialog.ShowDirsOnly
                dirname = QFileDialog.getExistingDirectory(
                    self,
                    _("Choose a directory:"),
                    self.dirctrl.text(),
                    options
                )
                if dirname:
                    self.dirctrl.setText(fileutils.opj(dirname))

            def _ok(self):
                index = self.filterChoice.currentIndex()
                self.template = None
                last_index = self.filterChoice.count() - 1
                if index and index != last_index:  # if not All or Any
                    self.template = self.visible_templates[index - 1]
                super()._ok()

        dlg = AddDirProjectDialog(get_app().GetTopWindow(), self)
        status = dlg.exec_()
        if status == AddDirProjectDialog.Accepted:
            source_dir_path = dlg.dirctrl.text().strip()
            if not os.path.exists(source_dir_path):
                QMessageBox.information(
                    self.GetFrame(),
                    get_app().GetAppName(),
                    _("directory '%s' does not exist.") % source_dir_path,
                )
                return
            search_subfolders = dlg.subfolderCtrl.isChecked()
            dir_string = source_dir_path
            template = dlg.template
            self.DoAddDirFilesToProject(
                dir_string, search_subfolders, template)

    @ui_utils.wait_cursor
    def DoAddDirFilesToProject(self, dir_string, search_subfolders, template):
        try:
            doc = self.GetDocument()
            if os.path.isfile(dir_string):
                # If they pick a file explicitly, we won't prevent them from adding it even if it doesn't match the filter.
                # We'll assume they know what they're doing.
                paths = [dir_string]
            else:
                paths = []
                # do search in files on disk
                for root, dirs, files in os.walk(dir_string):
                    if not search_subfolders and root != dir_string:
                        break
                    for name in files:
                        if template is None:  # All
                            filename = os.path.join(root, name)
                            # if already in project, don't add it, otherwise undo will remove it from project even though it was already in it.
                            if not doc.IsFileInProject(filename):
                                paths.append(filename)
                        else:  # use selected filter
                            if template.FileMatchesTemplate(name):
                                filename = os.path.join(root, name)
                                # if already in project, don't add it, otherwise undo will remove it from project even though it was already in it.
                                if not doc.IsFileInProject(filename):
                                    paths.append(filename)
            folderpath = None
            selections = self._treeCtrl.selection()
            if selections:
                item = selections[0]
                if not self._IsItemFile(item):
                    folderpath = self._GetItemFolderPath(item)
            doc.GetCommandProcessor().Submit(
                projectcommand.ProjectAddFilesCommand(doc, paths, folderPath=folderpath))
            self.Activate()  # after add, should put focus on project editor
        except Exception as e:
            QMessageBox.critical(self.GetFrame(), get_app().GetAppName(), _(
                'Add dir %s files to project error.') % dir_string)

    def DoAddFilesToProject(self, filepaths, folderpath):
        # method used by Drag-n-Drop to add files to current Project
        self.GetDocument().GetCommandProcessor().Submit(
            projectcommand.ProjectAddFilesCommand(self.GetDocument(), filepaths, folderpath))

    def OnRename(self, item):
        if utils.is_linux():
            text = tkSimpleDialog.askstring(
                _("Enter New Name"),
                _("Enter New Name"),
                initialvalue=self._treeCtrl.item(item, "text"),
                parent=self.GetFrame()
            )
            if not text:
                return
            self.ChangeLabel(item, text)
        else:
            self._treeCtrl.EditLabel()

    def OnEndLabelEdit(self, item, newname):
        project_doc = self.GetDocument()
        if project_doc is None:
            return False
        if item == self._treeCtrl.GetRootItem():
            if not newname:
                QMessageBox.information(self.GetFrame(), get_app(
                ).GetAppName(), _("project name could not be empty"))
                return False
            else:
                # 检查项目名称是否改变
                project = project_doc.GetModel()
                if project.Name != newname:
                    project.Name = newname
                    project_doc.Modify(True)
                    # 修改节点文本
                    item.setData(0, newname)
                    return True
            return False
        return self.ChangeLabel(item, newname)

    def ChangeLabel(self, item, newname):
        if not newname:
            return False
        if self._IsItemFile(item):
            oldfile_path = item.path
            newfile_path = os.path.join(os.path.dirname(oldfile_path), newname)
            doc = self.GetDocument()
            if not doc.GetCommandProcessor().Submit(projectcommand.ProjectRenameFileCommand(doc, oldfile_path, newfile_path)):
                return False
        else:
            has_child = True if self._treeCtrl.GetChildrenCount(
                item) > 0 else False
            oldFolderPath = self._GetItemFolderPath(item)
            new_folder_path = os.path.dirname(oldFolderPath)
            if new_folder_path:
                new_folder_path += "/"
            new_folder_path += newname
            if new_folder_path == oldFolderPath:
                return True
            if self._treeCtrl.FindFolder(new_folder_path):
                QMessageBox.warning(
                    self.GetFrame(),
                    _("Rename Folder"),
                    _("Folder '%s' already exists.") % newname
                )
                return False
            doc = self.GetDocument()
            if not doc.GetCommandProcessor().Submit(projectcommand.ProjectRenameFolderCommand(doc, oldFolderPath, new_folder_path)):
                return False
            # should delete the folder item ,other it will have double folder item
            if has_child:
                self._treeCtrl.delete_node(item)
        return True

    def CanPaste(self):
        hasfiles_in_clipboard = False
        if not self._prject_browser.TheClipboard.IsOpened():
            return hasfiles_in_clipboard

        file_data_object = JsonDataobject()
        hasfiles_in_clipboard = self._prject_browser.TheClipboard.GetData(
            file_data_object)
        return hasfiles_in_clipboard

    def CopyFileItem(self, action):
        filedata_object = JsonDataobject()
        indexes = self._treeCtrl.selectionModel().selectedIndexes()
        file_items = []
        for index in indexes:
            item = self._treeCtrl.model().item(index)
            if self._IsItemFile(item):
                filepath = self._GetItemFilePath(item)
                if filepath:
                    d = {
                        typedefines.JSON_DATA_FILEPATH_KEY: filepath,
                        typedefines.JSON_DATA_FILE_ACTION_KEY: action.value,
                        typedefines.JSON_DATA_FILE_TYPE_KEY: typedefines.PrjItemType.FILE_TYPE.value
                    }
                    file_items.append(d)
            else:
                folderpath = self._GetItemFolderPath(item)
                source_folder_path = os.path.join(self.GetDocument().GetPath(), folderpath)
                folder_file_items = self._GetFolderFileItems(item)
                filepaths = []
                for child_item in folder_file_items:
                    filepaths.append(self._GetItemFilePath(child_item))
                utils.get_logger().debug(
                    "copy path %s files:%s",
                    source_folder_path,
                    str(filepaths)
                )
                d = {
                    typedefines.JSON_DATA_FILEPATH_KEY: source_folder_path,
                    typedefines.JSON_DATA_FILE_ACTION_KEY: action.value,
                    typedefines.JSON_DATA_FILE_TYPE_KEY: typedefines.PrjItemType.DIR_TYPE.value,
                    typedefines.JSON_DATA_FILEPATHS_KEY: filepaths
                }
                file_items.append(d)
        filedata_object.SetData(file_items)
        if filedata_object.GetDataSize() > 0 and self._prject_browser.TheClipboard.Open():
            self._prject_browser.TheClipboard.SetData(filedata_object)

    def OnCut(self):
        self.CopyFileItem(typedefines.PrjItemAction.CUT)

    def OnCopy(self):
        self.CopyFileItem(typedefines.PrjItemAction.COPY)

    def copy_dir_to_test(self, src_path, dirname, dest_path, filelist, action_type):
        '''
        拷贝/剪切目录及目录下的项目文件到其它目录
        '''
        dest_base_dir_path = os.path.join(dest_path, dirname)
        fileutils.makedirs(dest_base_dir_path)
        copy_file_list = []
        for filepath in filelist:
            filename = fileutils.get_filename_from_path(filepath)
            if not os.path.exists(filepath):
                utils.get_logger().info('copy source file path %s is not exist', filepath)
                continue
            utils.get_logger().debug(
                '%s dir path:%s, file:%s, to dest root path:%s',
                action_type,
                src_path,
                filepath,
                dest_base_dir_path
            )
            dest_filepath = self.CopyToDest(filepath, filename, dest_base_dir_path, action_type)
            copy_file_list.append(dest_filepath)
            utils.get_logger().info(
                '%s file path %s to dest file path:%s success',
                action_type,
                filepath,
                dest_filepath
            )
        return copy_file_list

    def CopyToDest(self, src_path, file_name, dest_path, action_type):
        '''
        拷贝/剪切项目文件到其它目录
        '''
        dest_file_path = os.path.join(dest_path, file_name)
        if not os.path.exists(dest_file_path):
            if action_type == typedefines.PrjItemAction.COPY.value:
                shutil.copy(src_path, dest_file_path)
            elif action_type == typedefines.PrjItemAction.CUT.value:
                shutil.move(src_path, dest_file_path)
            return dest_file_path
        src_dir_path = os.path.dirname(src_path)
        if not fileutils.ComparePath(src_dir_path, dest_path):
            if action_type == typedefines.PrjItemAction.COPY.value:
                ret = QMessageBox.question(
                    self.GetFrame(),
                    _("Copy file"),
                    _("Dest file is already exist,Do you want to overwrite it?"),
                    QMessageBox.Yes | QMessageBox.No
                )
                if ret == QMessageBox.Yes:
                    shutil.copy(src_path, dest_file_path)
            elif action_type == typedefines.PrjItemAction.CUT.value:
                ret = QMessageBox.question(
                    self.GetFrame(),
                    _("Move file"),
                    _("Dest file is already exist,Do you want to overwrite it?"),
                    QMessageBox.Yes | QMessageBox.No
                )
                if ret == QMessageBox.Yes:
                    shutil.move(src_path, dest_file_path)
            return dest_file_path
        if action_type == typedefines.PrjItemAction.CUT.value:
            QMessageBox.information(
                self.GetFrame(),
                _("Move File"),
                _('The source file name is the same as the destination file name')
            )
            return dest_file_path
        file_ext = strutils.get_file_extension(file_name)
        filename_without_ext = strutils.get_filename_without_ext(file_name)
        if apputils.is_windows():
            dest_file_name = _(
                "%s - Copy.%s") % (filename_without_ext, file_ext)
            dest_file_path = os.path.join(dest_path, dest_file_name)
            if os.path.exists(dest_file_path):
                i = 2
                while os.path.exists(dest_file_path):
                    dest_file_name = _(
                        "%s - Copy (%d).%s") % (filename_without_ext, i, file_ext)
                    dest_file_path = os.path.join(dest_path, dest_file_name)
                    i += 1
        else:
            dest_file_name = _("%s (copy).%s") % (
                filename_without_ext, file_ext)
            dest_file_path = os.path.join(dest_path, dest_file_name)
            if os.path.exists(dest_file_path):
                i = 2
                while os.path.exists(dest_file_path):
                    if i == 2:
                        dest_file_name = _("%s (another copy).%s") % (
                            filename_without_ext, file_ext)
                    elif i == 3:
                        dest_file_name = _("%s (%drd copy).%s") % (
                            filename_without_ext, i, file_ext)
                    else:
                        dest_file_name = _("%s (%dth copy).%s") % (
                            filename_without_ext, i, file_ext)
                    dest_file_path = os.path.join(dest_path, dest_file_name)
                    i += 1
        shutil.copy(src_path, dest_file_path)
        return dest_file_path

    def OnPaste(self):
        if self._prject_browser.TheClipboard.Open():
            paste_items = []
            filedata_object = JsonDataobject()
            if self._prject_browser.TheClipboard.GetData(filedata_object):
                folderpath = None
                dest_files = []
                item = self._treeCtrl.GetSingleSelectItem()
                if item:
                    folderpath = self._GetItemFolderPath(item)
                dest_folder_path = os.path.join(self.GetDocument().GetPath(), folderpath)
                for src_file in filedata_object.GetData():
                    filepath = src_file[typedefines.JSON_DATA_FILEPATH_KEY]
                    action = src_file[typedefines.JSON_DATA_FILE_ACTION_KEY]
                    file_item_type = src_file[typedefines.JSON_DATA_FILE_TYPE_KEY]
                    filename = fileutils.get_filename_from_path(filepath)
                    utils.get_logger().debug(
                        'paste item path:%s,filename is:%s,action is:%s,type is %s',
                        filepath,
                        filename,
                        action,
                        file_item_type
                    )
                    if not os.path.exists(filepath):
                        QMessageBox.critical(
                            self.GetFrame(),
                            get_app().GetAppName(),
                            _("The item '%s' does not exist in the project directory.It may have been moved,renamed or deleted.") % filename,
                        )
                        return
                    try:
                        if file_item_type == typedefines.PrjItemType.FILE_TYPE.value:
                            if action == typedefines.PrjItemAction.COPY.value:
                                dest_file_path = self.CopyToDest(
                                    filepath, filename, dest_folder_path, action)
                                dest_files.append(dest_file_path)
                                self.GetDocument().GetCommandProcessor().Submit(
                                    projectcommand.ProjectAddFilesCommand(
                                        self.GetDocument(),
                                        dest_files,
                                        folderpath
                                    )
                                )
                            elif action == typedefines.PrjItemAction.CUT.value:
                                pjfile = self.GetDocument().GetModel().FindFile(filepath)
                                self.GetDocument().GetCommandProcessor().Submit(
                                    projectcommand.ProjectMoveFilesCommand(
                                        self.GetDocument(),
                                        [pjfile],
                                        folderpath
                                    )
                                )
                        elif file_item_type == typedefines.PrjItemType.DIR_TYPE.value:
                            file_list = src_file[typedefines.JSON_DATA_FILEPATHS_KEY]
                            folderpath = self._GetItemFolderPath(item, hasroot=True)
                            build_files = self.GetFrame().build_file_list(
                                file_list,
                                os.path.dirname(filepath),
                                folderpath
                            )
                            if action == typedefines.PrjItemAction.COPY.value:
                                for folder_path, file_path_list in build_files:
                                    dest_folder_path = os.path.join(self.GetDocument().GetPath(), folder_path)
                                    dest_filepath_list = self.copy_dir_to_test(
                                        filepath,
                                        filename,
                                        dest_folder_path,
                                        file_path_list,
                                        typedefines.PrjItemAction.COPY.value
                                    )
                                    self.GetDocument().AddFiles(dest_filepath_list, folder_path)

                            elif action == typedefines.PrjItemAction.CUT.value:
                                for folder_path, file_path_list in build_files:
                                    pjfiles = []
                                    for filepath in file_path_list:
                                        pjfile = self.GetDocument().GetModel().FindFile(filepath)
                                        pjfiles.append(pjfile)
                                    self.GetDocument().MoveFiles(pjfiles, folder_path)
                            return
                    except Exception as e:
                        utils.get_logger().exception('paste file items error:')
                        QMessageBox.critical(
                            self.GetFrame(),
                            get_app().GetAppName(),
                            str(e)
                        )
                        return

                paste_item = self._treeCtrl.GetSingleSelectItem()
                paste_items.append(paste_item)
            self._prject_browser.TheClipboard.Close()

    def RemoveFromProject(self):
        indexes = self._treeCtrl.selectedIndexes()
        files = []
        for index in indexes:
            item = self._treeCtrl.model().item(index)
            if not self._IsItemFile(item):
                folderpath = self._GetItemFolderPath(item)
                self.GetDocument().GetCommandProcessor().Submit(
                    projectcommand.ProjectRemoveFolderCommand(self, self.GetDocument(), folderpath))
            else:
                file = item.path
                if file:
                    files.append(file)
        if files:
            self.GetDocument().GetCommandProcessor().Submit(
                projectcommand.ProjectRemoveFilesCommand(self.GetDocument(), files))

    def GetOpenDocument(self, filepath):
        # need copy or docs shift when closed
        opendocs = self.GetDocumentManager().GetDocuments()[:]
        for d in opendocs:
            if fileutils.ComparePath(d.GetFilename(), filepath):
                return d
        return None

    def DeleteFromProject(self):
        is_file_selected = False
        is_folder_selected = False
        if self._HasFilesSelected():
            is_file_selected = True
        if self._HasFoldersSelected():
            is_folder_selected = True
        if is_file_selected and not is_folder_selected:
            yes_no_msg = QMessageBox.question(
                self.GetFrame(),
                _("Delete Files"),
                _("Delete cannot be reversed.\n\nRemove the selected files from the\nproject and file system permanently?"),
                QMessageBox.Yes | QMessageBox.No
            )
        elif is_folder_selected and not is_file_selected:
            yes_no_msg = QMessageBox.question(
                self.GetFrame(),
                _("Delete Folder"),
                _("Delete cannot be reversed.\n\nRemove the selected folder and its files from the\nproject and file system permanently?"),
                QMessageBox.Yes | QMessageBox.No
            )
        elif is_folder_selected and is_file_selected:
            yes_no_msg = QMessageBox.question(
                self.GetFrame(),
                _("Delete Folder And Files"),
                _("Delete cannot be reversed.\n\nRemove the selected folder and files from the\nproject and file system permanently?"),
                QMessageBox.Yes | QMessageBox.No
            )
        if yes_no_msg == QMessageBox.No:
            return
        items = self._treeCtrl.selection()
        del_files = []
        for item in items:
            if self._IsItemFile(item):
                filepath = self._GetItemFilePath(item)
                if filepath and filepath not in del_files:
                    # remove selected files from file system
                    if os.path.exists(filepath):
                        try:
                            # close the open document first if file opened
                            open_doc = self.GetOpenDocument(filepath)
                            if open_doc:
                                # make sure it doesn't ask to save the file
                                open_doc.Modify(False)
                                self.GetDocumentManager().CloseDocument(open_doc, True)
                            os.remove(filepath)
                        except:
                            wx.MessageBox("Could not delete '%s'.  %s" % (os.path.basename(filepath), sys.exc_value),
                                          _("Delete File"),
                                          wx.OK | wx.ICON_ERROR,
                                          self.GetFrame())
                            return
                    # remove selected files from project
                    self.GetDocument().RemoveFiles([filepath])
                    del_files.append(filepath)
            else:
                file_items = self._GetFolderFileItems(item)
                for fileitem in file_items:
                    filepath = self._GetItemFilePath(fileitem)
                    open_doc = self.GetOpenDocument(filepath)
                    if open_doc:
                        # make sure it doesn't ask to save the file
                        open_doc.Modify(False)
                        self.GetDocumentManager().CloseDocument(open_doc, True)
                folderpath = self._GetItemFolderPath(item)
                self.GetDocument().GetCommandProcessor().Submit(
                    projectcommand.ProjectRemoveFolderCommand(self, self.GetDocument(), folderpath, True))

    def DeleteProject(self, noPrompt=False, close_files=True, del_files=True):

        def delete_file(filepath):
            try:
                # 删除只读文件之前需要设置文件可写
                os.chmod(filepath, stat.S_IWRITE)
                os.remove(filepath)
                utils.get_logger().debug('Delete file %s in project', filepath)
            except Exception as e:
                QMessageBox.critical(
                    self.GetFrame(),
                    _("Delete Project"),
                    _("Could not delete file '%s'.\n%s") % (filepath, e),
                )

        class DeleteProjectDialog(ui_utils.BaseModalDialog):
            def __init__(self, parent, doc):
                super().__init__(_("Delete Project"), parent)
                filename = os.path.basename(doc.GetFilename())
                self.layout.addWidget(
                    QLabel(_("Delete cannot be reversed.\nDeleted files are removed from the file system permanently.\n\nThe project file '%s' will be closed and deleted.") % filename)
                )
                self.delfiles_ctrl = QCheckBox(
                    _("Delete all files in project"))
                self.delfiles_ctrl.setChecked(True)
                self.delfiles_ctrl.setToolTip(
                    _("Deletes files from disk, whether open or closed"))
                self.layout.addWidget(self.delfiles_ctrl)
                self.close_deleted_ctrl = QCheckBox(
                    _("Close open files belonging to project"))
                self.close_deleted_ctrl.setChecked(True)
                self.close_deleted_ctrl.setToolTip(
                    _("Closes open editors for files belonging to project"))
                self.layout.addWidget(self.close_deleted_ctrl)
                self.delall_filesctrl = QCheckBox(
                    _("Delete all files in project directory"))
                self.delall_filesctrl.setChecked(False)
                self.delall_filesctrl.setToolTip(
                    _("Deletes files from disk not belonging to project"))
                self.layout.addWidget(self.delall_filesctrl)
                self.create_standard_buttons()

        doc = self.GetDocument()
        if not noPrompt:
            dlg = DeleteProjectDialog(self.GetFrame(), doc)
            status = dlg.exec_()
            if status == DeleteProjectDialog.Rejected:
                return
            del_files = dlg.delfiles_ctrl.isChecked()
            delall_files = dlg.delall_filesctrl.isChecked()
            close_files = dlg.close_deleted_ctrl.isChecked()

        if close_files or del_files:
            files_in_project = doc.GetFiles()
            # don't remove self prematurely
            filepath = doc.GetFilename()
            if filepath in files_in_project:
                files_in_project.remove(filepath)
            # don't close/delete files outside of project's directory
            homedir = doc.GetModel().homeDir + os.sep
            for filepath in files_in_project[:]:
                filedir = os.path.dirname(filepath) + os.sep
                if not filedir.startswith(homedir):
                    files_in_project.remove(filepath)
        if close_files:
            # close any open views of documents in the project
            # need copy or docs shift when closed
            opendocs = self.GetDocumentManager().GetDocuments()[:]
            for d in opendocs:
                if d.GetFilename() in files_in_project:
                    # make sure it doesn't ask to save the file
                    d.Modify(False)
                    # if project, remove from project list drop down
                    if isinstance(d.GetDocumentTemplate(), ProjectTemplate):
                        if self.GetDocumentManager().CloseDocument(d, True):
                            self.RemoveProjectUpdate(d)
                    else:  # regular file
                        self.GetDocumentManager().CloseDocument(d, True)

        # remove files in project from file system
        if del_files:
            dirpaths = []
            for filepath in files_in_project:
                if os.path.isfile(filepath):
                    dirpath = os.path.dirname(filepath)
                    if dirpath not in dirpaths:
                        dirpaths.append(dirpath)
                    delete_file(filepath)

        filepath = doc.GetFilename()
        self.ClearFolderState()  # remove from registry folder settings
        # delete project regkey config
        get_app().GetConfig().DeleteGroup(getProjectKeyName(doc))
        # close project
        if doc:
            doc.Modify(False)  # make sure it doesn't ask to save the project
            if self.GetDocumentManager().CloseDocument(doc, True):
                self.RemoveCurrentDocumentUpdate()
            doc.document_watcher.RemoveFileDoc(doc)

        # remove project file
        if del_files:
            dirpath = os.path.dirname(filepath)
            if dirpath not in dirpaths:
                dirpaths.append(dirpath)
        if os.path.isfile(filepath):
            try:
                os.remove(filepath)
                utils.get_logger().debug('Delete project file %s', filepath)
            except Exception as e:
                QMessageBox.critical(
                    self.GetFrame(),
                    _("Delete Project"),
                    _("Could not delete project file '%s'.\n%s") % (filepath, e),
                )

        # remove empty directories from file system
        if del_files:
            dirpaths.sort()     # sorting puts parent directories ahead of child directories
            dirpaths.reverse()  # remove child directories first

            for dirpath in dirpaths:
                if os.path.isdir(dirpath):
                    files = os.listdir(dirpath)
                    if not files:
                        pathutils.delete_dir(dirpath)
        if delall_files:
            for root, dirs, files in os.walk(doc.GetPath()):
                for filename in files:
                    filepath = os.path.join(root, filename)
                    delete_file(filepath)
                for dir_name in dirs:
                    dirpath = os.path.join(root, dir_name)
                    pathutils.delete_dir(dirpath)
                pathutils.delete_dir(root)
        if not self.GetDocument():
            self.AddProjectRoot(_("Projects"))
            get_app().MainFrame.PushStatusText(
                _("Delete project '%s' success.") % doc.GetModel().name)

    def OnKeyPressed(self, event):
        key = event.GetKeyCode()
        if key == wx.WXK_DELETE:
            self.RemoveFromProject(event)
        else:
            event.Skip()

    def OnSelectAll(self, event):
        project = self.GetDocument()
        if project:
            self.DoSelectAll(self._treeCtrl.GetRootItem())

    def DoSelectAll(self, parent_item):
        (child, cookie) = self._treeCtrl.GetFirstChild(parent_item)
        while child.IsOk():
            if self._IsItemFile(child):
                self._treeCtrl.SelectItem(child)
            else:
                self.DoSelectAll(child)
            (child, cookie) = self._treeCtrl.GetNextChild(parent_item, cookie)

    def GetOpenDocumentTemplate(self, project_file):
        '''
            获取项目文件的打开方式模板
        '''
        template = None
        document_template_name = utils.profile_get(
            self.GetDocument().GetFileKey(project_file, "Open"), "")
        filename = os.path.basename(project_file.filePath)
        if not document_template_name:
            # 是否存在以文件名方式打开的模板
            document_template_name = utils.profile_get(
                "Open/filenames/%s" % filename, "")
            if not document_template_name:
                # 是否存在以扩展名方式打开的模板
                document_template_name = utils.profile_get(
                    "Open/extensions/%s" % strutils.get_file_extension(filename), "")
        if document_template_name:
            template = get_app().GetDocumentManager(
            ).FindTemplateForDocumentType(document_template_name)
        return template

    # ----------------------------------------------------------------------------
    # Convenience methods
    # ----------------------------------------------------------------------------

    def _HasFiles(self):
        if not self._treeCtrl:
            return False
        # 1 item = root item, don't count as having files
        return self._treeCtrl.GetCount() > 1

    def _HasFilesSelected(self):
        if not self._treeCtrl:
            return False
        items = self._treeCtrl.selection()
        if not items:
            return False
        for item in items:
            if self._IsItemFile(item):
                return True
        return False

    def _HasFoldersSelected(self):
        if not self._treeCtrl:
            return False
        items = self._treeCtrl.selection()
        if not items:
            return False
        for item in items:
            if not self._IsItemFile(item):
                return True
        return False

    def _MakeProjectName(self, project):
        return project.GetPrintableName()

    def _GetItemFilePath(self, item):
        if self._IsItemFile(item):
            return item.path
        return None

    def _GetItemFolderPath(self, item, hasroot=False):
        rootitem = self._treeCtrl.GetRootItem()
        if hasroot:
            rootitem = self._treeCtrl.invisibleRootItem()
        if item == rootitem:
            return ""
        if self._IsItemFile(item):
            item = item.parent()
        folderpath = ""
        while item != rootitem:
            if folderpath:
                folderpath = item.data() + "/" + folderpath
            else:
                folderpath = item.data()
            # 获取父节点
            item = item.parent()
        return folderpath

    def _GetItemFile(self, item):
        return self.GetDocument().GetModel().FindFile(item.path)

    def _IsItemFile(self, item):
        return item.itemType == treeitems.FileItemType

    def _IsItemProcessModelFile(self, item):
        if ACTIVEGRID_BASE_IDE:
            return False

        if self._IsItemFile(item):
            filepath = self._GetItemFilePath(item)
            ext = None
            for template in self.GetDocumentManager().GetTemplates():
                if template.GetDocumentType() == ProcessModelEditor.ProcessModelDocument:
                    ext = template.GetDefaultExtension()
                    break
            if not ext:
                return False

            if filepath.endswith(ext):
                return True

        return False

    def _GetFolderItems(self, parentitem):
        folder_items = []
        children_items = parentitem.children()
        for childitem in children_items:
            if not self._IsItemFile(childitem):
                folder_items.append(childitem)
                folder_items += self._GetFolderItems(childitem)
        return folder_items

    def _GetFolderFileItems(self, parentitem):
        file_items = []
        children_items = parentitem.children()
        for childitem in children_items:
            if self._IsItemFile(childitem):
                file_items.append(childitem)
            else:
                file_items.extend(self._GetFolderFileItems(childitem))
        return file_items

    def check_for_external_changes(self):
        if self._asking_about_external_change:
            return
        self._asking_about_external_change = True
        document = self.GetDocument()
        project_filename = document.GetFilename()
        if self._alarm_event == filewatcher.FileEventHandler.FILE_MODIFY_EVENT:
            ret = QMessageBox.question(
                self.GetFrame(),
                _("Reload Project.."),
                _("Project File \"%s\" has already been modified outside,Do you want to reload It?") % project_filename,
                QMessageBox.Yes | QMessageBox.No
            )
            if ret == QMessageBox.Yes:
                document.OnOpenDocument(project_filename)

        elif self._alarm_event in (filewatcher.FileEventHandler.FILE_MOVED_EVENT, filewatcher.FileEventHandler.FILE_DELETED_EVENT):
            ret = QMessageBox.question(
                self.GetFrame(),
                _("Project not exist.."),
                _("Project File \"%s\" has already been moved or deleted outside,Do you want to close this Project?") % project_filename,
                QMessageBox.Yes | QMessageBox.No
            )
            if ret == QMessageBox.Yes:
                self.CloseProject()
            else:
                document.Modify(True)

        self._asking_about_external_change = False
        ui_utils.AlarmEventMixin.check_for_external_changes(self)

    def OnAddCurrentFileToProject(self):
        text_view = get_app().MainFrame.GetNotebook().get_current_view()
        doc = text_view.GetDocument()
        filepath = doc.GetFilename()
        projectdoc = self.GetDocument()
        if projectdoc.IsFileInProject(filepath):
            QMessageBox.warning(get_app().MainFrame, get_app().GetAppName(), _(
                "Current document is already in the project"))
            return
        folderpath = None
        item = self._treeCtrl.GetSingleSelectItem()
        if item:
            folderpath = self._GetItemFolderPath(item)
        if projectdoc.GetCommandProcessor().Submit(projectcommand.ProjectAddFilesCommand(projectdoc, [filepath], folderPath=folderpath)):
            AddProjectMapping(doc, projectdoc)
            self.Activate()  # after add, should put focus on project editor
            if folderpath is None:
                folderpath = ""
            new_filepath = os.path.join(projectdoc.GetModel(
            ).homeDir, folderpath, os.path.basename(filepath))
            if not os.path.exists(new_filepath):
                return
            if not fileutils.ComparePath(new_filepath, filepath):
                opendoc = doc.GetOpenDocument(new_filepath)
                if opendoc:
                    QMessageBox.warning(
                        self.GetFrame(),
                        get_app().GetAppName(),
                        _("Project file is already opened")
                    )
                    opendoc.GetFirstView().GetFrame().SetFocus()
                    return
                doc.FileWatcher.StopWatchFile(doc)
                # 文本文件名更改时,通知文本视图更改文件,比如文本标签显示的文件名tooltip信息
                doc.SetFilename(new_filepath, notify_views=True)
                doc.FileWatcher.StartWatchFile(doc)
                get_app().MainFrame.GetNotebook().updateStatusBar()
            doc.SetDocumentModificationDate()

    def ProcessEvent(self, command_id):
        if command_id == menuitems.ID_ADD_FILES_TO_PROJECT:
            self.OnAddFileToProject()
        elif command_id == menuitems.ID_ADD_DIR_FILES_TO_PROJECT:
            self.OnAddDirToProject()
        elif command_id == menuitems.ID_ADD_CURRENT_FILE_TO_PROJECT:
            self.OnAddCurrentFileToProject()
        elif command_id == menuitems.ID_ADD_NEW_FILE:
            self.OnAddNewFile()
        elif command_id == menuitems.ID_ADD_FOLDER:
            self.OnAddFolder()
        elif command_id == menuitems.ID_RENAME:
            self.OnRename(self._prject_browser.prjContextItem)
        elif command_id == menuitems.ID_CLEAR:
            if self.get_current_tree_item() == self.get_root_tree_item():
                # 删除整个项目
                self.DeleteProject()
            else:
                # 删除项目文件和目录
                self.DeleteFromProject()
        elif command_id == menuitems.ID_CUT:
            self.OnCut()
        elif command_id == menuitems.ID_COPY:
            self.OnCopy()
        elif command_id == menuitems.ID_PASTE:
            self.OnPaste()
        elif command_id == menuitems.ID_REMOVE_FROM_PROJECT:
            self.RemoveFromProject()
        elif command_id == menuitems.ID_IMPORT_FILES:
            self.ImportFilesToProject(self._treeCtrl.GetSingleSelectItem())
        else:
            return False
        return True

    def get_current_tree_item(self):
        return self._treeCtrl.GetSingleSelectItem()

    def get_root_tree_item(self):
        return self._treeCtrl.GetRootItem()

    def UpdateUI(self, command_id):
        if self.GetDocument() is None:
            return False
        if command_id in [menuitems.ID_RUN, menuitems.ID_DEBUG]:
            return True
        if command_id in [menuitems.ID_CUT, menuitems.ID_COPY, menuitems.ID_CLEAR]:
            current_item = self.get_current_tree_item()
            return current_item is not None
        if command_id == menuitems.ID_PASTE:
            return self.CanPaste()
        if command_id in [
            menuitems.ID_CLOSE_PROJECT,
            menuitems.ID_SAVE_PROJECT,
            menuitems.ID_DELETE_PROJECT,
            menuitems.ID_CLEAN_PROJECT,
            menuitems.ID_ARCHIVE_PROJECT,
            menuitems.ID_IMPORT_FILES,
            menuitems.ID_ADD_FILES_TO_PROJECT,
            menuitems.ID_ADD_DIR_FILES_TO_PROJECT,
            menuitems.ID_PROPERTIES,
            menuitems.ID_OPEN_FOLDER_PATH,
            menuitems.ID_ADD_FOLDER,
            menuitems.ID_ADD_NEW_FILE
        ]:
            return True
        if command_id == menuitems.ID_ADD_CURRENT_FILE_TO_PROJECT:
            return get_app().MainFrame.GetNotebook().get_current_editor() is not None
        return super().UpdateUI(command_id)

    def GetCtrl(self):
        '''
            项目视图屏蔽查找功能
        '''
        return None


class ProjectOptionsPanel(ui_utils.BaseConfigurationPanel):
    def __init__(self, master, **kwargs):
        super().__init__()

        self.projsavedocs_checkbox = QCheckBox(
            _("Remember and load open projects"))
        self.projsavedocs_checkbox.setChecked(
            utils.profile_get_int(globalkeys.LOAD_LAST_SAVEDOCS_KEY, True))
        self.layout.addWidget(self.projsavedocs_checkbox)

        self.promptsave_checkbox = QCheckBox(
            _("Warn when run and save modify project files"))
        self.promptsave_checkbox.setChecked(
            utils.profile_get_int(globalkeys.SAVEPROJECT_PROMPT_KEY, True))
        self.layout.addWidget(self.promptsave_checkbox)

        self.loadfolderstate_checkbox = QCheckBox(
            _("Load folder state when open project"))
        self.loadfolderstate_checkbox.setChecked(
            utils.profile_get_int(globalkeys.LOAD_FOLDERSTATE_KEY, True))
        self.layout.addWidget(self.loadfolderstate_checkbox)

        self.promptdeprecated_checkbox = QCheckBox(
            _("Prompt warning when project analyzer version is deprecated"))
        self.promptdeprecated_checkbox.setChecked(
            utils.profile_get_int("PromptProjectAnalyzerDeprecated", True))
        self.layout.addWidget(self.promptdeprecated_checkbox)

        self.enable_project_scanner_checkbox = QCheckBox(
            _("Enable project file scanner"))
        self.enable_project_scanner_checkbox.setChecked(
            utils.profile_get_int(globalkeys.ENABLE_PROJECT_SCANNER_KEY, True))
        self.layout.addWidget(self.enable_project_scanner_checkbox)

        self.chkmodify_checkbox = QCheckBox(
            _("Check if on disk project file has been modified outside"))
        self.chkmodify_checkbox.setChecked(utils.profile_get_int(
            globalkeys.CHECK_PROJECT_FILE_MODIFY_KEY, True))
        self.layout.addWidget(self.chkmodify_checkbox)

        self.expandall_checkbox = QCheckBox(
            _("Whether to expand all after importing files"))
        self.expandall_checkbox.setChecked(utils.profile_get_int(
            globalkeys.EXPAND_ALL_PROJECT_FILES_KEY, True))
        self.layout.addWidget(self.expandall_checkbox)

        self.createproject_intellisensedatabase_checkbox = QCheckBox(
            _("Generate and load intellisense database of project automaticlly"))
        self.createproject_intellisensedatabase_checkbox.setChecked(
            utils.profile_get_int("CreateProjectIntellisenseDatabase", True))
        self.layout.addWidget(self.createproject_intellisensedatabase_checkbox)

        self.__detectinterpreter_checkbox = QCheckBox(
            _("Detects the presence of the interpreter when the project file is loaded"))
        self.__detectinterpreter_checkbox.setChecked(utils.profile_get_int(
            globalkeys.DETECT_PROJECT_INTERPRETER_KEY, False))
        self.layout.addWidget(self.__detectinterpreter_checkbox)

        btn = QPushButton(_("File Filters"))
        btn.clicked.connect(self.Filter)
        btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        btn.setToolTip(
            _("set filter file extentions when refresh project folder"))
        self.layout.addWidget(btn)
        self.layout.addStretch(1)
        self.filters = get_app().MainFrame.projectview.filters

    def Filter(self):
        filter_dlg = FileFilterDialog(self, self.filters)
        if filter_dlg.exec_() == FileFilterDialog.Accepted:
            dlg_filters = filter_dlg.filters
            dlg_filters.extend(self.filters)
            # 过滤掉重复数据
            self.filters = list(set(dlg_filters))

    def OnOK(self, options_dialog):
        utils.profile_set(globalkeys.CHECK_PROJECT_FILE_MODIFY_KEY,
                          self.chkmodify_checkbox.isChecked())
        utils.profile_set(globalkeys.EXPAND_ALL_PROJECT_FILES_KEY,
                          self.expandall_checkbox.isChecked())

        utils.profile_set(globalkeys.LOAD_LAST_SAVEDOCS_KEY,
                          self.projsavedocs_checkbox.isChecked())
        utils.profile_set(globalkeys.SAVEPROJECT_PROMPT_KEY,
                          self.promptsave_checkbox.isChecked())
        utils.profile_set(globalkeys.LOAD_FOLDERSTATE_KEY,
                          self.loadfolderstate_checkbox.isChecked())
        utils.profile_set("PromptProjectAnalyzerDeprecated",
                          self.promptdeprecated_checkbox.isChecked())
        utils.profile_set(globalkeys.DETECT_PROJECT_INTERPRETER_KEY,
                          self.__detectinterpreter_checkbox.isChecked())
        utils.profile_set(globalkeys.ENABLE_PROJECT_SCANNER_KEY,
                          self.enable_project_scanner_checkbox.isChecked())
        utils.profile_set("CreateProjectIntellisenseDatabase",
                          self.createproject_intellisensedatabase_checkbox.isChecked())
        get_app().MainFrame.projectview.filters = self.filters
        utils.profile_set(globalkeys.PROJECT_FILE_FILTERS, self.filters)
        return True

    def GetIcon(self):
        return getProjectIcon()
