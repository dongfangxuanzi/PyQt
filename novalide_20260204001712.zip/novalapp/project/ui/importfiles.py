import os
from ... import _, get_app
from ...util.ui_utils import BaseModalDialog
from ..wizard.importfiles import ImportfilesPage
from ...lib.pyqt import (
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QVBoxLayout,
    QCheckBox,
    QMessageBox,
    QLineEdit,
    pyqtSignal
)


class ImportfilesDialog(BaseModalDialog):
    sig_import_files = pyqtSignal()

    def __init__(self, master, folderPath):
        super().__init__(_("Import Files"), master)
        # rejects为项目禁止导入的文件类型列表
        self.import_page = ImportfilesPage(self, folderPath=folderPath)
        layout = self.import_page.layout()
        # 导入对话框页面添加一行控件
        dest_layout = QHBoxLayout()
        dest_layout.addWidget(QLabel(_('Dest Directory:')))
        self.destdir_ctrl = QLineEdit()
        self.destdir_ctrl.setText(self.import_page.dest_path)
        self.destdir_ctrl.setEnabled(False)
        dest_layout.addWidget(self.destdir_ctrl)
        layout.addLayout(dest_layout)
        self.layout.addWidget(self.import_page)
        # 初始化目的地址
        self.InitDestpath()
        opttion_frame = QGroupBox(_("Option"))
        option_box = QVBoxLayout()
        self.overwrite_chkbox = QCheckBox(
            _("Overwrite existing files without warning"))
        self.overwrite_chkbox.setChecked(False)
        option_box.addWidget(self.overwrite_chkbox)
        self.root_folder_chkbox = QCheckBox(_("Create top-level folder"))
        self.root_folder_chkbox.setChecked(False)
        option_box.addWidget(self.root_folder_chkbox)
        opttion_frame.setLayout(option_box)
        self.layout.addWidget(opttion_frame)
        self.create_standard_buttons()
        self.ok_button.setText(_("&Import"))
        self.sig_import_files.connect(self.set_importfiles_state)

    def set_importfiles_state(self):
        self.ok_button.setEnabled(False)

    def _ok(self):
        if not self.import_page.Validate():
            return
        # 导入文件时强制显示项目视图
        get_app().MainFrame.activateProjectTab()
        if self.overwrite_chkbox.isChecked():
            self.import_page.DEFAULT_PROMPT_MESSAGE_ID = QMessageBox.YesToAll
        if self.root_folder_chkbox.isChecked():
            self.import_page.folder_path = os.path.join(
                self.import_page.folder_path,
                self.import_page.root_item.text(0)
            )
        if not self.import_page.Finish():
            return
        super().ok()

    def _cancel(self):
        self.import_page.Cancel()
        super()._cancel()

    def InitDestpath(self):
        self.import_page.GetDestpath()
        self.destdir_ctrl.setText(self.import_page.dest_path)
