import copy
from ... import (
    get_app,
    _
)
from ...lib.pyqt import (
    QListWidget,
    Qt,
    QLabel,
    QLineEdit
)
from ...util.ui_utils import BaseModalDialog
from ..document import ProjectDocument


def get_filters(hasstar=True):
    filters = []
    for temp in get_app().GetDocumentManager().GetTemplates():
        if temp.IsVisible() and not issubclass(temp.GetDocumentType(), ProjectDocument):
            exts = temp.exts(hasstar)
            filters.extend(exts)
    return filters


class FileFilterDialog(BaseModalDialog):
    def __init__(self, parent, filters, rejects=[]):
        BaseModalDialog.__init__(self, _("File Filters"), parent)
        self.filters = filters
        self.layout.addWidget(
            QLabel(_("Please select file types to to allow added to project:")))
        self.listbox = QListWidget()
        self.layout.addWidget(self.listbox)
        self.layout.addWidget(
            QLabel(_("Other File Extensions:(seperated by ';')")))
        self.other_extensions_ctrl = QLineEdit()
        self.layout.addWidget(self.other_extensions_ctrl)
        self.InitFilters()
        self.create_standard_buttons()

    def _ok(self):
        filters = []
        for i in range(self.listbox.count()):
            item = self.listbox.item(i)
            if item.checkState() == Qt.Checked:
                filters.append(item.text())
        extension_value = self.other_extensions_ctrl.text().strip()
        if extension_value != "":
            extensions = extension_value.split(";")
            filters.extend(extensions)
        self.filters = [fitler.replace("*", "").replace(".", "")
                        for fitler in filters]
        super()._ok()

    def InitFilters(self):
        exts = get_filters()
        initfilters = copy.copy(self.filters)
        for ext in exts:
            self.listbox.addItem(ext)
            i = self.listbox.count() - 1
            item = self.listbox.item(i)
            filter = ext.replace("*", "").replace(".", "")
            if filter in self.filters:
                item.setCheckState(Qt.Checked)
                initfilters.remove(filter)
            else:
                item.setCheckState(Qt.Unchecked)
        # 未知扩展名显示在文本控件中
        if initfilters:
            filters = ";".join(["*." + filter for filter in initfilters])
            self.other_extensions_ctrl.setText(filters)
