import enum


class PrjItemType(enum.Enum):
    DIR_TYPE: str = "dir_item_type"
    FILE_TYPE: str = "file_item_type"


class PrjItemAction(enum.Enum):
    CUT: str = "cut_item"
    COPY: str = "copy_item"


JSON_DATA_FILEPATH_KEY = 'filePath'
JSON_DATA_FILE_ACTION_KEY = 'action'
JSON_DATA_FILE_TYPE_KEY = 'fileType'
JSON_DATA_FILEPATHS_KEY = 'filePaths'
