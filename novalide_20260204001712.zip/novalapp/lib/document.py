# -*- coding: utf-8 -*-
'''
Name:        document.py
Purpose:     应用程序文档类实现

Author:      wukan

Created:     2024-01-23
Copyright:   (c) wukan 2024
Licence:     <your licence>
'''
import os
import shutil
import traceback
from . import _, get_app
from ..lib.pyqt import QMessageBox
from .docview import DOC_NO_VIEW
from .path import filename_from_path, find_extension


class Document:
    """
    The document class can be used to model an application's file-based data. It
    is part of the document/view framework supported by wxWindows, and cooperates
    with the wxView, wxDocTemplate and wxDocManager classes.

    Note this wxPython version also keeps track of the modification date of the
    document and if it changes on disk outside of the application, we will warn the
    user before saving to avoid clobbering the file.
    """

    def __init__(self, parent=None):
        """
        Constructor.  Define your own default constructor to initialize
        application-specific data.
        """
        self._documentParent = parent
        self._document_template = None
        self._command_processor = None
        self._saved_yet = False
        self._writeable = True

        self._document_title = None
        self._document_file = None
        self._document_typename = None
        self._documentModified = False
        self._documentModificationDate = None
        self._document_views = []

    def GetFilename(self):
        """
        Gets the filename associated with this document, or "" if none is
        associated.
        """
        return self._document_file

    def GetTitle(self):
        """
        Gets the title for this document. The document title is used for an
        associated frame (if any), and is usually constructed by the framework
        from the filename.
        """
        return self._document_title

    def SetTitle(self, title):
        """
        Sets the title for this document. The document title is used for an
        associated frame (if any), and is usually constructed by the framework
        from the filename.
        """
        self._document_title = title

    def GetDocumentName(self):
        """
        The document type name given to the wxDocTemplate constructor,
        copied to this document when the document is created. If several
        document templates are created that use the same document type, this
        variable is used in wxDocManager::CreateView to collate a list of
        alternative view types that can be used on this kind of document.
        """
        return self._document_typename

    def SetDocumentName(self, name):
        """
        Sets he document type name given to the wxDocTemplate constructor,
        copied to this document when the document is created. If several
        document templates are created that use the same document type, this
        variable is used in wxDocManager::CreateView to collate a list of
        alternative view types that can be used on this kind of document. Do
        not change the value of this variable.
        """
        self._document_typename = name

    def GetDocumentSaved(self):
        """
        Returns True if the document has been saved.  This method has been
        added to wxPython and is not in wxWindows.
        """
        return self._saved_yet

    def SetDocumentSaved(self, saved=True):
        """
        Sets whether the document has been saved.  This method has been
        added to wxPython and is not in wxWindows.
        """
        self._saved_yet = saved

    def IsModified(self):
        """
        Returns true if the document has been modified since the last save,
        false otherwise. You may need to override this if your document view
        maintains its own record of being modified (for example if using
        wxTextWindow to view and edit the document).
        """
        return self._documentModified

    def Modify(self, modify):
        """
        Call with true to mark the document as modified since the last save,
        false otherwise. You may need to override this if your document view
        maintains its own record of being modified (for example if using
        xTextWindow to view and edit the document).
        This method has been extended to notify its views that the dirty flag has changed.
        """
        self._documentModified = modify
        self.UpdateAllViews(hint=("modify", self, self._documentModified))

    def SetDocumentModificationDate(self):
        """
        Saves the file's last modification date.
        This is used to check if the file has been modified outside of the application.
        This method has been added to wxPython and is not in wxWindows.
        """
        self._documentModificationDate = os.path.getmtime(self.GetFilename())

    def GetDocumentModificationDate(self):
        """
        Returns the file's modification date when it was loaded from disk.
        This is used to check if the file has been modified outside of the application.
        This method has been added to wxPython and is not in wxWindows.
        """
        return self._documentModificationDate

    def reload(self):
        return True

    def IsDocumentModificationDateCorrect(self):
        """
        Returns False if the file has been modified outside of the application.
        This method has been added to wxPython and is not in wxWindows.
        """
        # document must be in memory only and can't be out of date
        if not os.path.exists(self.GetFilename()):
            return True
        return self._documentModificationDate == os.path.getmtime(self.GetFilename())

    def GetViews(self):
        """
        Returns the list whose elements are the views on the document.
        """
        return self._document_views

    def GetDocumentTemplate(self):
        """
        Returns the template that created the document.
        """
        return self._document_template

    def SetDocumentTemplate(self, template):
        """
        Sets the template that created the document. Should only be called by
        the framework.
        """
        self._document_template = template

    def DeleteContents(self):
        """
        Deletes the contents of the document.  Override this method as
        necessary.
        """
        return True

    def Destroy(self):
        """
        Destructor. Removes itself from the document manager.
        """
        self.DeleteContents()
        self._documentModificationDate = None
        if self.GetDocumentManager():
            self.GetDocumentManager().RemoveDocument(self)

    def Close(self):
        """
        Closes the document, by calling OnSaveModified and then (if this true)
        OnCloseDocument. This does not normally delete the document object:
        use DeleteAllViews to do this implicitly.
        """
        if self.OnSaveModified():
            if self.OnCloseDocument():
                return True
            return False
        return False

    def OnCloseDocument(self):
        """
        The default implementation calls DeleteContents (an empty
        implementation) sets the modified flag to false. Override this to
        supply additional behaviour when the document is closed with Close.
        """
        self.NotifyClosing()
        self.DeleteContents()
        self.Modify(False)
        return True

    def DeleteAllViews(self):
        """
        Calls wxView.Close and deletes each view. Deleting the final view will
        implicitly delete the document itself, because the wxView destructor
        calls RemoveView. This in turns calls wxDocument::OnChangedViewList,
        whose default implemention is to save and delete the document if no
        views exist.
        """
        manager = self.GetDocumentManager()
        for view in self._document_views:
            if not view.Close():
                return False
        if self in manager.GetDocuments():
            self.Destroy()
        return True

    def GetFirstView(self):
        """
        A convenience function to get the first view for a document, because
        in many cases a document will only have a single view.
        """
        if len(self._document_views) == 0:
            return None
        return self._document_views[0]

    def GetDocumentManager(self):
        """
        Returns the associated document manager.
        """
        if self._document_template:
            return self._document_template.GetDocumentManager()
        return None

    def OnNewDocument(self):
        """
        The default implementation calls OnSaveModified and DeleteContents,
        makes a default title for the document, and notifies the views that
        the filename (in fact, the title) has changed.
        """
        if not self.OnSaveModified() or not self.OnCloseDocument():
            return False
        self.DeleteContents()
        self.Modify(False)
        self.SetDocumentSaved(False)
        name = self.GetDocumentManager().MakeDefaultName()
        self.SetTitle(name)
        self.SetFilename(name, notify_views=True)

    def Save(self):
        """
        Saves the document by calling OnSaveDocument if there is an associated
        filename, or SaveAs if there is no filename.
        """
        if not self.IsModified():  # and self._savedYet:  This was here, but if it is not modified who cares if it hasn't been saved yet?
            return True

        """ 保存文件之前检测文件是否在外部改变 """
        if not self.IsDocumentModificationDateCorrect():
            msg_title = get_app().GetAppName()
            if not msg_title:
                msg_title = _("Application")
            # 如果文件在外部改变,询问用户是否覆盖文件
            res = QMessageBox.question(
                self.GetFirstView().GetFrame(),
                msg_title,
                _("'%s' has been modified outside of %s.  Overwrite '%s' with current changes?") %
                (self.GetPrintableName(), msg_title, self.GetPrintableName()),
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
            )
            # 选择否返回False
            if res == QMessageBox.No:
                return True
            # 选择是返回True
            if res == QMessageBox.Yes:
                pass
            # 选择取消返回None
            else:
                return False

        if not self._document_file or not self._saved_yet:
            return self.SaveAs()
        return self.OnSaveDocument(self._document_file)

    def SaveAs(self):
        """
        Prompts the user for a file to save to, and then calls OnSaveDocument.
        """
        doc_template = self.GetDocumentTemplate()
        if not doc_template:
            return False
        filename = filedialog.asksaveasfilename(
            master=GetApp(),
            filetypes=[get_app().GetDocumentManager().get_filter(doc_template), ],
            defaultextension=doc_template.GetDefaultExtension(),
            initialdir=doc_template.GetDirectory(),
            initialfile=os.path.basename(self.GetFilename())
        )
        if filename == "":
            return False

        ext = find_extension(filename)
        if ext == "":
            filename += '.' + doc_template.GetDefaultExtension()

        self.SetFilename(filename)
        self.SetTitle(FileNameFromPath(filename))

        for view in self._document_views:
            view.OnChangeFilename()

        if not self.OnSaveDocument(filename):
            return False

        if doc_template.FileMatchesTemplate(filename):
            self.GetDocumentManager().AddFileToHistory(filename)

        return True

    def OnSaveDocument(self, filename):
        """
        Constructs an output file for the given filename (which must
        not be empty), and calls SaveObject. If SaveObject returns true, the
        document is set to unmodified; otherwise, an error message box is
        displayed.
        """
        if not filename:
            return False

        msg_title = get_app().GetAppName()
        if not msg_title:
            msg_title = _("File Error")

        backup_filename = None
        file_object = None
        copied = False
        try:
            # if current file exists, move it to a safe place temporarily
            if os.path.exists(filename):

                # Check if read-only.
                if not os.access(filename, os.W_OK):
                    messagebox.showerror(msg_title, "Could not save '%s'.  No write permission to overwrite existing file." %
                                         filename_from_path(filename))
                    return False

                i = 1
                backup_filename = "%s.bak%s" % (filename, i)
                while os.path.exists(backup_filename):
                    i += 1
                    backup_filename = "%s.bak%s" % (filename, i)
                shutil.copy(filename, backup_filename)
                copied = True

            file_object = open(filename, 'w')
            self.SaveObject(file_object)
            file_object.close()
            file_object = None
            # 如果保存成功则删除备份文件
            if backup_filename:
                os.remove(backup_filename)
        except Exception as e:
            # for debugging purposes
            traceback.print_exc()

            if file_object:
                file_object.close()  # file is still open, close it, need to do this before removal

            # 如果文件保存失败,则从备份文件恢复原文件,并将备份文件删除,防止生成过多的备份文件
            if backup_filename and copied:
                shutil.copy(backup_filename, filename)
                os.remove(backup_filename)
            QMessageBox.critical(self.GetDocumentWindow(), msg_title, _(
                "Could not save '%s'.  %s") % (filename_from_path(filename), str(e)))
            return False

        self.SetDocumentModificationDate()
        self.SetFilename(filename, True)
        self.Modify(False)
        self.SetDocumentSaved(True)
        return True

    def OnOpenDocument(self, filename):
        """
        Constructs an input file for the given filename (which must not
        be empty), and calls LoadObject. If LoadObject returns true, the
        document is set to unmodified; otherwise, an error message box is
        displayed. The document's views are notified that the filename has
        changed, to give windows an opportunity to update their titles. All of
        the document's views are then updated.
        """
        if not self.OnSaveModified():
            return False

        msg_title = get_app().GetAppName()
        if not msg_title:
            msg_title = _("File Error")

        file_object = open(filename)
        try:
            self.LoadObject(file_object)
            file_object.close()
            file_object = None
        except:
            # for debugging purposes
            traceback.print_exc()

            if file_object:
                file_object.close()  # file is still open, close it

            wx.MessageBox("Could not open '%s'.  %s" % (FileNameFromPath(filename), sys.exc_value),
                          msg_title,
                          wx.OK | wx.ICON_EXCLAMATION,
                          self.GetDocumentWindow())
            return False

        self.SetDocumentModificationDate()
        self.SetFilename(filename, True)
        self.Modify(False)
        self.SetDocumentSaved(True)
        self.UpdateAllViews()
        return True

    def LoadObject(self, file):
        """
        Override this function and call it from your own LoadObject before
        loading your own data. LoadObject is called by the framework
        automatically when the document contents need to be loaded.

        Note that the wxPython version simply sends you a Python file object,
        so you can use pickle.
        """
        return True

    def SaveObject(self, file):
        """
        Override this function and call it from your own SaveObject before
        saving your own data. SaveObject is called by the framework
        automatically when the document contents need to be saved.

        Note that the wxPython version simply sends you a Python file object,
        so you can use pickle.
        """
        return True

    def Revert(self):
        """
        Override this function to revert the document to its last saved state.
        """
        return False

    def GetPrintableName(self):
        """
        Copies a suitable document name into the supplied name buffer.
        The default function uses the title, or if there is no title, uses the
        filename; or if no filename, the string 'Untitled'.
        """
        if self._document_title:
            return self._document_title
        if self._document_file:
            return filename_from_path(self._document_file)
        return _("Untitled")

    def GetDocumentWindow(self):
        """
        Intended to return a suitable window for using as a parent for
        document-related dialog boxes. By default, uses the frame associated
        with the first view.
        """
        if len(self._document_views) > 0:
            return self._document_views[0].GetFrame()
        return get_app().GetTopWindow()

    def OnSaveModified(self):
        """
        If the document has been modified, prompts the user to ask if the
        changes should be changed. If the user replies Yes, the Save function
        is called. If No, the document is marked as unmodified and the
        function succeeds. If Cancel, the function fails.
        """
        if not self.IsModified():
            return True

        """ check for file modification outside of application """
        if not self.IsDocumentModificationDateCorrect():
            msg_title = get_app().GetAppName()
            if not msg_title:
                msg_title = _("Warning")
            # 如果文件在外部改变,询问用户是否覆盖文件
            res = QMessageBox.question(
                self.GetDocumentWindow(),
                msg_title,
                _("'%s' has been modified outside of %s.  Overwrite '%s' with current changes?") % (
                    self.GetPrintableName(), msg_title, self.GetPrintableName()),
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
            )
            if res == QMessageBox.No:
                self.Modify(False)
                return True
            if res == QMessageBox.Yes:
                return Document.Save(self)
            return False

        msg_title = get_app().GetAppName()
        if not msg_title:
            msg_title = _("Warning")
        # 关闭文档之前询问用户是否保存修改
        answer = QMessageBox.question(
            self.GetDocumentWindow(),
            msg_title,
            _("Save changes to '%s'?") % self.GetPrintableName(),
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
        )
        save_suc = False
        if answer == QMessageBox.No:
            self.Modify(False)
            save_suc = True
        elif answer == QMessageBox.Yes:
            save_suc = self.Save()
        return save_suc

    def AddView(self, view):
        """
        If the view is not already in the list of views, adds the view and
        calls OnChangedViewList.
        """
        if not view in self._document_views:
            self._document_views.append(view)
            self.OnChangedViewList()
        return True

    def RemoveView(self, view):
        """
        Removes the view from the document's list of views, and calls
        OnChangedViewList.
        """
        if view in self._document_views:
            self._document_views.remove(view)
            self.OnChangedViewList()
        return True

    def OnCreate(self, path, flags):
        """
        The default implementation calls DeleteContents (an empty
        implementation) sets the modified flag to false. Override this to
        supply additional behaviour when the document is opened with Open.
        """
        if flags & DOC_NO_VIEW:
            return True
        return self.GetDocumentTemplate().CreateView(self, flags)

    def OnChangedViewList(self):
        """
        Called when a view is added to or deleted from this document. The
        default implementation saves and deletes the document if no views
        exist (the last one has just been removed).
        """
        if len(self._document_views) == 0:
            if self.OnSaveModified():
                pass  # C version does a delete but Python will garbage collect

    def UpdateAllViews(self, sender=None, hint=None):
        """
        Updates all views. If sender is non-NULL, does not update this view.
        hint represents optional information to allow a view to optimize its
        update.
        """
        for view in self._document_views:
            if view != sender:
                view.OnUpdate(sender, hint)

    def NotifyClosing(self):
        """
        Notifies the views that the document is going to close.
        """
        for view in self._document_views:
            view.OnClosingDocument()

    def SetFilename(self, filename, notify_views=False):
        """
        Sets the filename for this document. Usually called by the framework.
        If notifyViews is true, wxView.OnChangeFilename is called for all
        views.
        """
        self._document_file = filename
        if notify_views:
            for view in self._document_views:
                view.OnChangeFilename()

    def GetWriteable(self):
        """
        Returns true if the document can be written to its accociated file path.
        This method has been added to wxPython and is not in wxWindows.
        """
        if not self._writeable:
            return False
        if not self._document_file:  # Doesn't exist, do a save as
            return True
        return os.access(self._document_file, os.W_OK)

    def SetWriteable(self, writeable):
        """
        Set to False if the document can not be saved.  This will disable the ID_SAVE_AS
        event and is useful for custom documents that should not be saveable.  The ID_SAVE
        event can be disabled by never Modifying the document.  This method has been added
        to wxPython and is not in wxWindows.
        """
        self._writeable = writeable
