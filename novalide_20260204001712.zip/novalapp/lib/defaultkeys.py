from enum import Enum


class AppDefaultKey(Enum):
    """description of class"""
    MRU_LENGTH_KEY = "MRULength"
    ENABLE_MRU_KEY = "EnableMRU"
    RECENTPROJECT_LENGTH_KEY = "RecentProjectLength"
    DEFAULT_DOCUMENT_TYPE_KEY = "DefaultNewDocumentType"
    RECENT_FILES_KEY = "RecentFiles"
    RECENT_PROJECTS_KEY = "RecentProjects"
