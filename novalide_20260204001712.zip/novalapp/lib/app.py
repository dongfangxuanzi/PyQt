# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        app.py
Purpose:     应用程序基础类实现

Author:      wukan

Created:     2019-01-08
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import os
import time
import pickle
import sys
import mmap
import tempfile
import logging
import novalapp.lib
from .pyqt import QApplication, Qt, QMessageBox
from .images import empty_icon
from .docmanager import DOC_SILENT
from ..util import appdirs
from . import checker
from .docframe import DocTabbedChildFrame
from . import splashscreen
from . import ui_lang
from .locale import Locale
from . import _
logger = logging.getLogger(__name__)


class App(QApplication):

    def __init__(self, debug=False, argv=[]):
        super().__init__(argv)
        novalapp.lib._AppInstance = self
        self._app_name = None
        self._debug = debug
        self._single_instance = True
        self._splash = None
        self.locale = Locale(ui_lang.LANGUAGE_DEFAULT)
        self.frame = None
        self.initializing = False
        self._defaulticon = empty_icon()
        # 高分辨率DPI屏幕自动缩放和去除弹窗的?按钮
        QApplication.setAttribute(
            Qt.AA_EnableHighDpiScaling | Qt.AA_DisableWindowContextHelpButton)
        self._bootstrap_app()

    def GetLocale(self):
        return self.locale

    def GetDocumentManager(self):
        """
        Returns the document manager associated to the DocApp.
        """
        return self._docmanager

    def set_document_manager(self, docmanager):
        """
        Sets the document manager associated with the DocApp and loads the
        DocApp's file history into the document manager.
        """
        self._docmanager = docmanager
        config = self.GetConfig()
        # 加载历史文件记录
        self.GetDocumentManager().FileHistoryLoad(config)

    def ShowTip(self, frame, tipProvider):
        """
        Shows the tip window, generally this is called when an application starts.
        A wx.TipProvider must be passed.
        """
        config = wx.ConfigBase_Get()
        showTip = config.ReadInt("ShowTipAtStartup", 1)
        if showTip:
            index = config.ReadInt("TipIndex", 0)
            showTipResult = wx.ShowTip(
                wx.GetApp().GetTopWindow(), tipProvider, showAtStartup=showTip)
            if showTipResult != showTip:
                config.WriteInt("ShowTipAtStartup", showTipResult)

    def GetDebug(self):
        """
        Returns True if the application is in debug mode.
        """
        return self._debug

    def SetDebug(self, debug):
        """
        Sets the application's debug mode.
        """
        self._debug = debug

    def SetAppName(self, app_name):
        self._app_name = app_name
        if not self.objectName():
            self.setObjectName(self._app_name)

    def GetAppName(self):
        return self._app_name

    def GetSingleInstance(self):
        """
        Returns True if the application is in single instance mode.  Used to determine if multiple instances of the application is allowed to launch.
        """
        return self._single_instance

    def SetSingleInstance(self, singleinstance):
        """
        Sets application's single instance mode.
        """
        self._single_instance = singleinstance

    def on_init(self):
        """
        Initializes the App.
        """
        if not hasattr(self, "_debug"):  # only set if not already initialized
            self._debug = False
        if not hasattr(self, "_single_instance"):  # only set if not already initialized
            self._single_instance = True
        # if _singleInstance is TRUE only allow one single instance of app to run.
        # When user tries to run a second instance of the app, abort startup,
        # But if user also specifies files to open in command line, send message to running app to open those files
        self.initializing = True
        if self._single_instance:
            # create shared memory temporary file
            if sys.platform.startswith("win"):
                tfile = tempfile.TemporaryFile(prefix="ag", suffix="tmp")
                fno = tfile.fileno()
                self._shared_mem = mmap.mmap(fno, 1024, "shared_memory")
            else:
                tfile = open(os.path.join(tempfile.gettempdir(), tempfile.gettempprefix(
                ) + self.GetAppName() + "NovalSharedMemory"), 'w+b')
                tfile.write(bytes("*", 'ascii'))
                tfile.seek(1024)
                tfile.write(bytes(" ", 'ascii'))
                tfile.flush()
                fno = tfile.fileno()
                self._shared_mem = mmap.mmap(fno, 1024)

            self._singleinstance_checker = checker.SingleInstanceChecker(
                self.GetAppName(),
                appdirs.get_user_data_path()
            )
            # 仅允许一个实例运行
            if self._singleinstance_checker.is_another_running():
                args = sys.argv
                # 如果有参数传递过来,表示打开已有项目文件,不要弹出提示只能运行一个实例对话框
                if 1 == len(args):
                    logger.info('another instance is running,exit now....')
                    QMessageBox.warning(
                        None,
                        self.GetAppName(),
                        _('Only one instance is allowed running, Another instance is runnging!')
                    )
                # have running single instance open file arguments
                data = pickle.dumps(args[1:])
                while 1:
                    self._shared_mem.seek(0)
                    marker = self._shared_mem.read_byte()
                    # ord是将asc字符转换成数字,chr是将数字转换成asc字符
                    # available buffer
                    if marker == '\0' or marker == ord('\0') or marker == '*' or marker == ord('*'):
                        self._shared_mem.seek(0)
                        if isinstance(marker, int):
                            self._shared_mem.write_byte(
                                ord('-'))     # set writing marker
                            # write files we tried to open to shared memory
                            self._shared_mem.write(data)
                            self._shared_mem.seek(0)
                            # set finished writing marker
                            self._shared_mem.write_byte(ord('+'))
                        elif isinstance(marker, str):
                            self._shared_mem.write_byte(
                                '-')     # set writing marker
                            # write files we tried to open to shared memory
                            self._shared_mem.write(data)
                            self._shared_mem.seek(0)
                            # set finished writing marker
                            self._shared_mem.write_byte('+')
                        self._shared_mem.flush()
                        break
                    # give enough time for buffer to be available
                    time.sleep(1)
                return False
        return True

    def background_listen_load(self):
        """
        Open any files specified in the given command line argument passed in via shared memory
        """
        if not hasattr(self, "_singleinstance_checker"):
            logger.warning(
                'application has been quit,stop background listen and load'
            )
            return
        self._shared_mem.seek(0)
        byte = self._shared_mem.read_byte()
        if byte == '+' or byte == ord('+'):  # available data
            data = self._shared_mem.read(1024 - 1)
            self._shared_mem.seek(0)
            # finished reading, set buffer free marker
            self._shared_mem.write_byte(ord("*"))
            self._shared_mem.flush()
            args = pickle.loads(data)
            self.__open_file_with_args(args)
            # force display of running app
            self.__raise_window()

    def GetConfig(self):
        return self._config

    def SetDefaultIcon(self, img):
        """
        Sets the application's default icon.
        """
        QApplication.setWindowIcon(img)

    def quit(self):
        self._docmanager.FileHistorySave(self.GetConfig())
        if hasattr(self, "_singleinstance_checker"):
            self._shared_mem.close()
            del self._singleinstance_checker
        super().quit()

    def CreateDocumentFrame(self, view, doc, flags, id=-1, title=""):
        """
        Called by the DocManager to create and return a new Frame for a Document.
        Chooses whether to create an MDIChildFrame or SDI Frame based on the
        DocManager's flags.
        """
        frame = self.__create_tabbed_document_frame(doc, view, id, title)
        if not frame.GetIcon() and self._defaulticon is not None:
            frame.SetIcon(self.GetDefaultIcon())
        view.SetFrame(frame)
        return frame

    def GetDefaultIcon(self):
        return self._defaulticon

    def GetTopWindow(self):
        return self.frame

    def show_splash(self, image_path):
        """
        Shows a splash window with the given image.  Input parameter 'image' can either be a wx.Bitmap or a filename.
        """
        self._splash = splashscreen.SplashScreen(image_path)
        self._splash.show()

    def show_splash_message(self, message):
        if self._splash is not None:
            self._splash.show_message(message)

    def close_splash(self):
        """
        Closes the splash window.
        """
        if self._splash:
            self._splash.finish(self.MainFrame)
            self._splash = None
            # 启动图片关闭后显示主窗口并且恢复窗口透明度
            self.frame.show()
            self.frame.setWindowOpacity(1.0)

    def get_ide_splash_bitmap(self):
        return None

    def get_default_hsplitter_width(self):
        screen_size = self.desktop().screenGeometry()
        return screen_size.width() // 6

    def get_default_vsplitter_height(self):
        screen_size = self.desktop().screenGeometry()
        return screen_size.height() // 6

    def _bootstrap_app(self):
        if not self.on_init():
            self.exit()
            sys.exit(0)

    def _open_commandline_args(self):
        """
        Called to open files that have been passed to the application from the
        command line.
        """
        args = sys.argv[1:]
        self.__open_file_with_args(args)

    def __raise_window(self, force=True):
        '''
            将程序窗口置于桌面前台
        '''
        # Looks like at least on Windows all following is required
        # for ensuring the window gets focus
        # (deiconify, ..., iconify, deiconify)
        # 先最小化窗口
        self.MainFrame.setWindowState(Qt.WindowMinimized)
        # 再最大化窗口
        self.MainFrame.setWindowState(Qt.WindowActive | Qt.WindowMaximized)
        self.MainFrame.raise_()
        self.MainFrame.activateWindow()
        self.MainFrame.setFocus()

    def __open_file_with_args(self, args):
        for arg in args:
            if (not sys.platform.startswith("win") or arg[0] != "/") and arg[0] != '-' and os.path.exists(arg):
                self.GetDocumentManager().CreateDocument(os.path.normpath(arg), DOC_SILENT)

    def __create_tabbed_document_frame(self, doc, view, id=-1, title=""):
        """
        Creates and returns an MDI Document Frame for a Tabbed MDI view
        """
        frame = DocTabbedChildFrame(doc, view, self.MainFrame, id, title)
        return frame
