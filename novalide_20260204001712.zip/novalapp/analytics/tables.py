
USER_TABLE = 'user'
DATA_TABLE = 'data'
