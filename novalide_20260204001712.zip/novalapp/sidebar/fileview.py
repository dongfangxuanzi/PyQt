# -*- coding: utf-8 -*-
'''
Name:        fileview.py
Purpose:     文件浏览器视图的实现

Author:      wukan

Created:     2024-01-23
Copyright:   (c) wukan 2024
Licence:     <your licence>
'''
import os
from .. import get_app, _
from .. import menuitems
from ..bars.menubar import NewQMenu
from ..lib.pyqt import (
    QTreeWidget,
    QWidget,
    Qt,
    QSize,
    QVBoxLayout,
    QToolBar,
    QAction,
    QTreeWidgetItem,
    QCursor,
    QMessageBox,
    QDialog,
    QCheckBox,
    pyqtSignal
)
from ..util import utils, fileutils, strutils, ui_utils, pathutils
from ..syntax.syntax import SyntaxThemeManager
from ..widgets import simpledialog
from ..qtimage import load_icon
from ..widgets.spacers import ToolBarExpandingSpacer
from ..findrep.findindir import FindIndirDialog
from .. import constants
from ..backend.running import construct_cd_command
from .. import globalkeys

if utils.is_windows():
    from win32com.shell import shell, shellcon

    def GetDriveDisplayName(path):
        return shell.SHGetFileInfo(path, 0, shellcon.SHGFI_DISPLAYNAME)[1][3]

    def GetRoots():
        roots = []
        for i in range(65, 91):
            vol = chr(i) + ':'
            if os.path.isdir(vol):
                roots.append([GetDriveDisplayName(vol), vol])
        return roots
else:
    def GetRoots():
        roots = []
        home_dir = wx.GetHomeDir()
        roots.append([_("Home directory"), home_dir])
        desktop_dir = home_dir + "/Desktop"
        roots.append([_("Desktop"), desktop_dir])
        roots.append(["/", "/"])
        return roots


def get_win_drives():
    # http://stackoverflow.com/a/2288225/261181
    # http://msdn.microsoft.com/en-us/library/windows/desktop/aa364939%28v=vs.85%29.aspx
    roots = []
    for i in range(65, 91):
        vol = chr(i) + ':'
        if os.path.isdir(vol):
            roots.append(vol)
    return roots


SAVE_OPEN_FOLDER_KEY = "FileViewSaveFolder"
OPEN_FOLDER_KEY = "FileViewLastFolder"


class FileBrowser(QTreeWidget):
    def __init__(self, master=None, show_hidden_files=False):
        super().__init__(master)
        lexer = SyntaxThemeManager.manager().GetLexer(get_app().GetDefaultLangId())
        self.default_extentsion = "." + lexer.GetDefaultExt()
        self.show_hidden_files = show_hidden_files

        wb = get_app()
        self.folder_icon = wb.GetImage("files/folder.gif")
        self.default_file_icon = lexer.GetFileViewIcon()
        self.text_file_icon = wb.GetImage("files/text-file.gif")
        self.generic_file_icon = wb.GetImage("files/generic-file.gif")
        self.hard_drive_icon = wb.GetImage("files/hard-drive.gif")
        # 不显示表头
        self.setHeaderHidden(True)
        self.root = self.invisibleRootItem()

        self.refresh_tree(self.root)
        self.itemExpanded.connect(self.on_open_node)

        # 加载上次打开的文件夹
        self.open_initial_folder()

    def open_initial_folder(self):
        if utils.profile_get_int(SAVE_OPEN_FOLDER_KEY, True):
            path = utils.profile_get(OPEN_FOLDER_KEY)
            if path:
                self.open_path_in_browser(path, True)

    def save_current_folder(self, filepath):
        if not filepath:
            return
        if os.path.isfile(filepath):
            path = os.path.dirname(filepath)
        else:
            path = filepath
        utils.profile_set(OPEN_FOLDER_KEY, path)

    def on_open_node(self, item):
        if item:
            self.refresh_tree(item, True)

    def get_selected_node(self):
        nodes = self.selectedItems()
        if len(nodes) >= 1:
            return nodes[0]
        return None

    def get_selected_path(self, node=None):
        if not node:
            nodes = self.selectedItems()
            if nodes:
                node = nodes[0]
        if node:
            return node.data(0, Qt.UserRole)
        return None

    def open_path_in_browser(self, path, see=True):
        # unfortunately os.path.split splits from the wrong end (for this case)
        def split(path):
            head, tail = os.path.split(path)
            if head == "" and tail == "":
                return []
            if path in (head, tail):
                return [path]
            if head == "":
                return [tail]
            if tail == "":
                return split(head)
            return split(head) + [tail]

        parts = split(path)
        current_node = self.root
        current_path = ""
        while parts != []:
            current_path = os.path.join(current_path, parts.pop(0))
            for i in range(current_node.childCount()):
                childnode = current_node.child(i)
                child_path = childnode.data(0, Qt.UserRole)
                if child_path == current_path:
                    childnode.setExpanded(True)
                    self.refresh_tree(childnode)
                    current_node = childnode
                    break
        if see and current_node:
            # 选中节点
            current_node.setSelected(True)

    def refresh_tree(self, parent, opening=None):
        if parent == self.root:
            path = ""
        else:
            path = parent.data(0, Qt.UserRole)
        if os.path.isfile(path):
            parent.setExpanded(False)
        else:
            # either root or directory
            if parent == self.root or parent.isExpanded() or opening == True:
                # 在windows下如果path为根硬盘路径,例如c:,d:需要将根路径后面添加路径分割符
                # 因为调用os.path.join连接路径时不会自动添加路径分割符
                if path != "" and not path.endswith(os.sep):
                    path += os.sep
                fs_children_names = self.listdir(path, self.show_hidden_files)
                tree_child_nodes = []
                for i in range(parent.childCount()):
                    tree_child_nodes.append(parent.child(i))

                # recollect children
                children = {}
                # first the ones, which are present already in tree
                for child_node in tree_child_nodes:
                    name = child_node.text(0)
                    if name in fs_children_names:
                        children[name] = child_id

                # add missing children
                for name in fs_children_names:
                    if name not in children:
                        tree_item = QTreeWidgetItem()
                        parent.addChild(tree_item)
                        tree_item.setData(
                            0, Qt.UserRole, os.path.join(path, name))
                        children[name] = tree_item

                def file_order(name):
                    # items in a folder should be ordered so that
                    # folders come first and names are ordered case insensitively
                    return (os.path.isfile(os.path.join(path, name)), name.upper())

                # update tree
                ids_sorted_by_name = list(
                    map(
                        lambda key: children[key],
                        sorted(children.keys(), key=file_order),
                    )
                )
                parent.takeChildren()
                parent.addChildren(ids_sorted_by_name)
                for child_node in ids_sorted_by_name:
                    # 更新节点文本
                    self.update_node_format(child_node)
                    self.refresh_tree(child_node)

            else:
                # closed dir
                # Don't fetch children yet, but ensure that expand button is visible
                child_count = parent.childCount()
                if child_count == 0:
                    parent.addChild(QTreeWidgetItem())

    def update_node_format(self, node):
        path = node.data(0, Qt.UserRole)
        if os.path.isdir(path) or path.endswith(":") or path.endswith(":\\"):
            if path.endswith(":") or path.endswith(":\\"):
                img = self.hard_drive_icon
            else:
                img = self.folder_icon
        else:
            if path.lower().endswith(self.default_extentsion):
                img = self.default_file_icon
            elif path.lower().endswith(".txt") or path.lower().endswith(".csv"):
                img = self.text_file_icon
            else:
                img = self.generic_file_icon
        # compute caption
        text = os.path.basename(path)
        # 此处是根节点,即硬盘符号节点
        if text == "":  # in case of drive roots
            # text = path.strip(os.sep)
            if utils.is_windows():
                name = GetDriveDisplayName(path)
                text = name
            else:
                # 去掉最后的路径分隔符
                text = path.strip(os.sep)

        node.setText(0, " " + text)
        node.setIcon(0, img)
        node.setData(0, Qt.UserRole, path)

    def listdir(self, path="", include_hidden_files=False):
        key = str.upper
        if path == "" and utils.is_windows():
            drives = get_win_drives()
            # 将所有硬盘符号后面加上路径分隔符
            result = [drive + "\\" for drive in drives]
        else:
            if path == "":
                first_level = True
                path = "/"
            else:
                first_level = False
            result = [
                x
                for x in self.ListDir(path)
                if include_hidden_files
                or not fileutils.is_file_path_hidden(os.path.join(path, x))
            ]

            if first_level:
                result = ["/" + x for x in result]
        return sorted(result, key=key)

    def ListDir(self, path):
        for x in os.listdir(path):
            yield x


class FileFrame(QWidget):

    SIG_DOUBLECLICK_FOLDER = pyqtSignal(str)

    def __init__(self, master, show_hidden_files=False):
        super().__init__(master)
        self.__fsContextItem = None
        self.__create_layout()
        self._fscontextmenu = None

        # 鼠标双击Tree控件事件
        self.filesystemview.itemDoubleClicked.connect(self.on_double_click)
        self.filesystemview.setContextMenuPolicy(Qt.CustomContextMenu)
        self.filesystemview.customContextMenuRequested.connect(
            self.__fs_contextmenu_requested)
        self.SIG_DOUBLECLICK_FOLDER.connect(self.change_shell_dir)

    def change_shell_dir(self, path):
        '''
           双击文件视图文件夹时同时在解释器shell中切换路径
        '''
        if not os.path.isdir(path) or not utils.profile_get_int(globalkeys.FILEVIEW_DOUBLE_CLICK_KEY, True):
            return
        get_app().MainFrame.activateBottomTab(constants.PYTHON_INTERPRETER_VIEW_NAME)
        shell = get_app().MainFrame.GetView(constants.PYTHON_INTERPRETER_VIEW_NAME)
        proxy = shell.Runner.get_backend_proxy()
        if (
            proxy
            and proxy.uses_local_filesystem()
            and proxy.get_cwd() != path
            and shell.Runner.is_waiting_toplevel_command()
        ):
            shell.submit_magic_command(construct_cd_command(path))

    def RefreshPath(self, node_id=None):
        selected_path = self.filesystemview.get_selected_path()
        node = self.filesystemview.get_selected_node()
        if not os.path.exists(selected_path):
            node = node.parent()
        node.takeChildren()
        try:
            self.filesystemview.refresh_tree(node, True)
        except Exception as e:
            QMessageBox.critical(self, _("Error"), str(e))
        node.setExpanded(True)

    def OpenPathInexplower(self):
        selected_path = self.filesystemview.get_selected_path()
        pathutils.safe_open_file_directory(selected_path)

    def OpenPathInterminal(self):
        selected_path = self.filesystemview.get_selected_path()
        if os.path.isfile(selected_path):
            selected_path = os.path.dirname(selected_path)
        try:
            fileutils.open_path_in_terminator(selected_path)
        except RuntimeError as e:
            QMessageBox.critical(self, _("Error"), str(e))

    def create_new_file(self):
        selected_path = self.filesystemview.get_selected_path()

        if not selected_path:
            return

        if os.path.isdir(selected_path):
            parent_path = selected_path
        else:
            parent_path = os.path.dirname(selected_path)

        initial_name = self.get_proposed_new_file_name(
            parent_path, self.filesystemview.default_extentsion)
        ok, name = simpledialog.askstring(
            "File name",
            "Provide filename",
            initialvalue=initial_name
        )
        if not ok:
            return
        path = os.path.join(parent_path, name)
        if os.path.exists(path):
            QMessageBox.critical(
                self, "Error", "The file '" + path + "' already exists")
            return
        open(path, "w").close()

        self.filesystemview.open_path_in_browser(path, True)
        get_app().GotoView(path)

    def create_new_folder(self):
        selected_path = self.filesystemview.get_selected_path()
        if not selected_path:
            return
        if os.path.isdir(selected_path):
            parent_path = selected_path
        else:
            parent_path = os.path.dirname(selected_path)

        initial_name = self.get_proposed_new_file_name(
            parent_path, "", "newfoler")
        ok, name = simpledialog.askstring(
            _("New folder"),
            "Provide folder name",
            initialvalue=initial_name,
        )

        if not ok:
            return

        path = os.path.join(parent_path, name)
        try:
            os.mkdir(path)
        except Exception as e:
            QMessageBox.critical(self, _("Error"), str(e))
            return

        self.filesystemview.open_path_in_browser(path, True)

    def get_proposed_new_file_name(self, folder, extension, base="new_file"):
        if os.path.exists(os.path.join(folder, base + extension)):
            i = 2
            while True:
                name = base + "_" + str(i) + extension
                path = os.path.join(folder, name)
                if os.path.exists(path):
                    i += 1
                else:
                    return name
        else:
            return base + extension

    def on_double_click(self, item):
        path = self.filesystemview.get_selected_path(item)
        if os.path.isfile(path):
            ext = strutils.get_file_extension(path)
            if utils.is_ext_supportable(ext):
                get_app().GotoView(path, lineNum=0, load_outline=False)
            else:
                try:
                    fileutils.startfile(path)
                    # 检查文件扩展名是否有对应的文件扩展插件
                   # ui_utils.CheckFileExtension(path,True)
                except:
                    utils.get_logger().exception("")
            # 双击文件时,记住并保存文件夹的状态
            self.filesystemview.save_current_folder(path)
        elif os.path.isdir(path):
            self.filesystemview.refresh_tree(item, True)
            # 发送双击文件夹信号,在shell解释器中切换当前路径
            self.SIG_DOUBLECLICK_FOLDER.emit(path)

    def __create_layout(self):
        """Helper to create the viewer layout"""
        self.lower = self.__create_filesystem_part_layout()

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.lower)

        self.setLayout(layout)
        self.__update_fstoolbar_buttons()

    def __create_filesystem_part_layout(self):
        """Creates the lower part of the project viewer"""
        # Header part: label + show/hide button
        # Tree view part
        self.filesystemview = FileBrowser()

        # Toolbar part - buttons
        self.fs_findindir_button = QAction(
            load_icon('findindir.png'), _('Find in highlighted directory'), self)
        self.fs_findindir_button.triggered.connect(
            self.__findin_directory)
        self.fs_addtoplevel_dir_button = QAction(
            load_icon('addtopleveldir.png'),
            _('Add as a top level directory'), self)
        self.fs_addtoplevel_dir_button.triggered.connect(
            self.__add_toplevel_dir)

        self.fs_copytoclipboard_button = QAction(
            load_icon('copymenu.png'), _('Copy path to clipboard'), self)
        self.fs_copytoclipboard_button.triggered.connect(
            self.__copyto_clipboard)
        self.__fsreloadbutton = QAction(load_icon('reload.png'),
                                        _('Re-read the file system tree'), self)
        self.__fsreloadbutton.triggered.connect(self.__reload)

        self.__lowertoolbar = QToolBar()
        self.__lowertoolbar.setMovable(False)
        self.__lowertoolbar.setAllowedAreas(Qt.TopToolBarArea)
        self.__lowertoolbar.setIconSize(QSize(16, 16))
        self.__lowertoolbar.setContentsMargins(0, 0, 0, 0)
        self.__lowertoolbar.addAction(self.fs_findindir_button)
        self.__lowertoolbar.addAction(self.fs_addtoplevel_dir_button)
        self.__lowertoolbar.addAction(self.fs_copytoclipboard_button)
        # 工具栏拉伸控件,可以挤压其他控件
        # 将刷新按钮挤压到最右边
        self.__lowertoolbar.addWidget(ToolBarExpandingSpacer(self))
        self.__lowertoolbar.addAction(self.__fsreloadbutton)

        fslayout = QVBoxLayout()
        fslayout.setContentsMargins(0, 0, 0, 0)
        fslayout.setSpacing(0)
        fslayout.addWidget(self.__lowertoolbar)
        fslayout.addWidget(self.filesystemview)

        lowercontainer = QWidget()
        lowercontainer.setContentsMargins(0, 0, 0, 0)
        lowercontainer.setLayout(fslayout)
        return lowercontainer

    def __update_fstoolbar_buttons(self):
        """Updates the toolbar buttons depending on the __fsContextItem"""
        if self.filesystemview.selectedItems:
            self.fs_findindir_button.setEnabled(True)
            self.fs_addtoplevel_dir_button.setEnabled(True)
            self.fs_copytoclipboard_button.setEnabled(True)
        else:
            self.fs_findindir_button.setEnabled(False)
            self.fs_addtoplevel_dir_button.setEnabled(False)
            self.fs_copytoclipboard_button.setEnabled(False)

    def __fs_contextmenu_requested(self):
        if self._fscontextmenu is None:
            self._fscontextmenu = NewQMenu(self)
            self._fscontextmenu.Append(menuitems.ID_REFRESH_PATH, _(
                "&Refresh"), handler=self.RefreshPath)
            self._fscontextmenu.Append(menuitems.ID_OPEN_CMD_PATH, _(
                "Open Command Prompt here..."), handler=self.OpenPathInterminal)
            self._fscontextmenu.Append(menuitems.ID_COPY_FULLPATH, _(
                "Open Path in Explorer"), handler=self.OpenPathInexplower)
            self._fscontextmenu.Append(menuitems.ID_ADD_FOLDER, _(
                "&Create new folder"), handler=self.create_new_folder)
            self._fscontextmenu.Append(menuitems.ID_CREATE_NEW_FILE, _(
                "&Create new file"), handler=self.create_new_file)
        self._fscontextmenu.popup(QCursor.pos())

    def __findin_directory(self):
        findstring = get_app().MainFrame.GetNotebook().get_find_str()
        dlg = FindIndirDialog(self, findstring)
        dlg.path_entry.setText(self.filesystemview.get_selected_path())
        if dlg.exec_() == QDialog.Accepted:
            get_app().MainFrame.activateSearchResultsTab()

    def __add_toplevel_dir(self):
        self.create_new_folder()

    def __copyto_clipboard(self):
        """Copies the path to the file where the element is to the clipboard"""
        ui_utils.copytoclipboard(self.filesystemview.get_selected_path())

    def __reload(self):
        self.RefreshPath()


class FileviewOptionPanel(ui_utils.BaseConfigurationPanel):
    """
        文件视图面板
    """

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.layout.setAlignment(Qt.AlignTop)
        # 记住上次打开文件夹状态,只有双击文件时才能记住文件夹打开状态
        self.__savefolde_checkbox = QCheckBox(
            _("Load last open folder state When program startup"))
        self.__savefolde_checkbox.setChecked(
            utils.profile_get_int(SAVE_OPEN_FOLDER_KEY, True))
        self.layout.addWidget(self.__savefolde_checkbox)

        self.__execute_cd_checkbox = QCheckBox(
            _("Execute 'cd' command in python shell when double click folder"))
        self.__execute_cd_checkbox.setChecked(utils.profile_get_int(
            globalkeys.FILEVIEW_DOUBLE_CLICK_KEY, True))
        self.layout.addWidget(self.__execute_cd_checkbox)

    def OnOK(self, options_dialog):
        utils.profile_set(SAVE_OPEN_FOLDER_KEY,
                          self.__savefolde_checkbox.isChecked())
        utils.profile_set(globalkeys.FILEVIEW_DOUBLE_CLICK_KEY,
                          self.__execute_cd_checkbox.isChecked())
        return True
