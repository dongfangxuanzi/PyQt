# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        launcher.py
Purpose:     python语言应用程序启动文件

Author:      wukan

Created:     2019-01-08
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import os
import sys
from .prog_lang import LANGUAGE_PYTHON, LANGUAGE_NOTSET


def run(language):
    # 启动时,添加解释器或者程序(pyinstaller转换后的程序)的安装路径到系统路径列表中,
    # 以便项目引用内部模块都能找到
    # 如果安装路径已经存在于系统路径列表中,亦无影响
    exec_dir = os.path.dirname(sys.executable)
    try:
        sys.path.index(exec_dir)
    except ValueError:
        sys.path.append(exec_dir)

    if language == LANGUAGE_PYTHON:
        from .python import pyide
        app = pyide.PyIDEApplication()
    elif language == LANGUAGE_NOTSET:
        from . import ide
        app = ide.IDEApplication()
    ret = app.exec_()
    return ret
