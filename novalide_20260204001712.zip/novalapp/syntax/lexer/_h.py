# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _h.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
import _cpp
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.qtimage import load_icon


class SyntaxLexer(_cpp.SyntaxLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_H")
        syndata.CodeBaseLexer.__init__(self, lang_id)
        self._maximum_keywordset = 2

    def GetDescription(self):
        return _('C/C++ Header File')

    def GetExt(self):
        return "h"

    def GetShowName(self):
        return "C/C++"

    def GetDefaultExt(self):
        return "h"

    def GetDocTypeName(self):
        return "C/C++ Header Document"

    def GetViewTypeName(self):
        return _("C/C++ Header Editor")

    def GetDocIcon(self):
        return load_icon("file/h_file.gif")

    def IsVisible(self):
        return False
