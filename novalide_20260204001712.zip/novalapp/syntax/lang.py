
def new_lang_id():
    global _idCounter
    _idCounter += 1
    return _idCounter


_idCounter = 32100


ID_LANG_TXT = new_lang_id()


def register_new_langid(id_name: str):
    """Register a new language identifier
    @param id_name: "ID_LANG_FOO"
    @return: int

    """
    gdict = globals()
    if id_name not in gdict:
        gdict[id_name] = new_lang_id()
    return gdict[id_name]
