# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""Codimension main window status bar"""
import os
from .. import get_app
from ..lib.pyqt import Qt, QMenu, QApplication, QStatusBar, pyqtSignal
from ..widgets.labels import (StatusBarPixmapLabel, StatusBarPathLabel,
                              StatusBarFramedLabel)


class StatusBar(QStatusBar):
    sig_update_statusbar_msg = pyqtSignal(str, int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.sig_update_statusbar_msg.connect(self.showStatusBarMessage)

    def emit_statusbar_messgae(self, msg):
        # 默认状态栏消息停留10秒
        self.sig_update_statusbar_msg.emit(msg, 10000)

    def emit_statusbar_permanent_messgae(self, msg):
        # 永久停留状态栏消息,直到被下一条消息覆盖
        self.sig_update_statusbar_msg.emit(msg, 0)

    def showStatusBarMessage(self, msg, timeout=10000):
        """Shows a temporary status bar message, default 10sec"""
        self.showMessage(msg, timeout)


class StatusBarMixin:
    """Main window status bar mixin"""

    def __init__(self):
        self._statusbar = None
        self.sbLanguage = None
        self.sbFile = None
        self.sbEol = None
        self.sbPos = None
        self.sbLine = None
        self.sbEncoding = None
        self.sbPyflakes = None
        self.sbCC = None
        self.sbVCSStatus = None
        self.sbDebugState = None
        self.__create_statusbar()

    def __create_statusbar(self):
        """Creates status bar"""
        self._statusbar = StatusBar()
        self._statusbar.setSizeGripEnabled(True)

        self.sbLanguage = StatusBarFramedLabel(parent=self._statusbar)
        self._statusbar.addPermanentWidget(self.sbLanguage)

        self.sbEncoding = StatusBarFramedLabel(parent=self._statusbar)
        self._statusbar.addPermanentWidget(self.sbEncoding)

        self.sbEol = StatusBarFramedLabel(parent=self._statusbar)
        self._statusbar.addPermanentWidget(self.sbEol)

        self.sbPyflakes = StatusBarPixmapLabel('signal', self._statusbar)
        self._statusbar.addPermanentWidget(self.sbPyflakes)

        self.sbCC = StatusBarPixmapLabel('signal', self._statusbar)
        self._statusbar.addPermanentWidget(self.sbCC)

        self.sbFile = StatusBarPathLabel(
            callback=self._onPathLabelDoubleClick,
            parent=self._statusbar)
        self.sbFile.setMaximumWidth(512)
        self.sbFile.setMinimumWidth(128)
        self._statusbar.addPermanentWidget(self.sbFile, True)
# self.sbFile.setContextMenuPolicy(Qt.CustomContextMenu)
# self.sbFile.customContextMenuRequested.connect(
# self._showPathLabelContextMenu)

        self.sbLine = StatusBarFramedLabel(callback=self.gotoline,
                                           parent=self._statusbar)
        self.sbLine.setMinimumWidth(72)
        self.sbLine.setAlignment(Qt.AlignCenter)
        self._statusbar.addPermanentWidget(self.sbLine)

        self.sbPos = StatusBarFramedLabel(callback=self.gotoline,
                                          parent=self._statusbar)
        self.sbPos.setMinimumWidth(72)
        self.sbPos.setAlignment(Qt.AlignCenter)
        self._statusbar.addPermanentWidget(self.sbPos)
        self.setStatusBar(self._statusbar)

    def gotoline(self):
        """Copies the line number to the buffer"""
        get_app().MainFrame.GetNotebook().on_goto()

    def copyPos(self):
        """Copies the pos number to the buffer"""
        self.__copyLinePos(self.sbPos)

    @staticmethod
    def __copyLinePos(label):
        """Copies the line/pos label content to the buffer"""
        txt = label.text().strip().lower()
        if not txt.endswith('n/a'):
            txt = txt[txt.find(':') + 1:].strip()
            QApplication.clipboard().setText(txt)

    def showStatusBarMessage(self, msg, timeout=10000):
        """Shows a temporary status bar message, default 10sec"""
        self._statusbar.showMessage(msg, timeout)

    def clearStatusBarMessage(self):
        """Clears the status bar message in the given slot"""
        self._statusbar.clearMessage()
        self.sbLanguage.setText('')
        self.sbEncoding.setText('')
        self.sbFile.setPath('')
        self.sbEol.setText('')
        self.sbLine.setText('')
        self.sbPos.setText('')

    def getCurrentStatusBarMessage(self):
        """Provides the current status bar message"""
        return self._statusbar.currentMessage()

    def _showPathLabelContextMenu(self, pos):
        """Triggered when a context menu is requested for the path label"""
        contextmenu = QMenu(self)
        contextmenu.addAction(getIcon('copymenu.png'),
                              'Copy full path to clipboard (double click)',
                              self._onPathLabelDoubleClick)
        contextmenu.addSeparator()
        contextmenu.addAction(getIcon(''), 'Copy directory path to clipboard',
                              self._onCopyDirToClipboard)
        contextmenu.addAction(getIcon(''), 'Copy file name to clipboard',
                              self._onCopyFileNameToClipboard)
        contextmenu.popup(self.sbFile.mapToGlobal(pos))

    def _onPathLabelDoubleClick(self):
        """Double click on the status bar path label"""
        txt = self.__getPathLabelFilePath()
        if txt.lower() not in ['', 'n/a']:
            QApplication.clipboard().setText(txt)

    def _onCopyDirToClipboard(self):
        """Copies the dir path of the current file into the clipboard"""
        txt = self.__getPathLabelFilePath()
        if txt.lower() not in ['', 'n/a']:
            try:
                QApplication.clipboard().setText(os.path.dirname(txt) +
                                                 os.path.sep)
            except:
                pass

    def _onCopyFileNameToClipboard(self):
        """Copies the file name of the current file into the clipboard"""
        txt = self.__getPathLabelFilePath()
        if txt.lower() not in ['', 'n/a']:
            try:
                QApplication.clipboard().setText(os.path.basename(txt))
            except:
                pass

    def __getPathLabelFilePath(self):
        """Provides undecorated path label content"""
        txt = str(self.sbFile.getPath())
        if txt.startswith('File: '):
            txt = txt.replace('File: ', '')
        return txt
