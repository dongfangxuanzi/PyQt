# -*- coding: utf-8 -*-
from ..lib.pyqt import QLabel, QListWidget, QInputDialog
from ..util import ui_utils


class SingleChoiceDialog(ui_utils.BaseModalDialog):
    def __init__(self, title, label, choices, selection=-1, master=None):
        super().__init__(title, master)
        # 禁止对话框改变大小
        label = QLabel(label)
        self.layout.addWidget(label)

        self.listbox = QListWidget()
        for item in choices:
            self.listbox.addItem(item)
        if selection != -1:
            self.listbox.setCurrentRow(selection)
        self.listbox.itemDoubleClicked.connect(self.selectionitem)
        self.layout.addWidget(self.listbox)
        self.create_standard_buttons()
        self.selection = -1

    def _ok(self):
        self.selection = self.listbox.currentRow()
        super()._ok()

    def selectionitem(self):
        self._ok()


def asklist(title, label, choices, selection=-1, master=None):
    dlg = SingleChoiceDialog(title, label, choices, selection, master)
    dlg.exec_()
    return dlg.selection


def askinteger(title, label, *, default_int=1, minnum=1, maxnum=-1, master=None):
    num, ok = QInputDialog.getInt(
        master, title, label, default_int, minnum, maxnum)
    return ok, num


def askstring(title, label, *, initialvalue=None, master=None):
    name, ok = QInputDialog.getText(master, title, label, text=initialvalue)
    return ok, name


def askitem(title, label, choices, selection=-1, master=None):
    name, ok = QInputDialog.getItem(
        master, title, label, choices, selection, editable=False)
    return name, ok
