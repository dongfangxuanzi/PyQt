from .. import get_app, _
from ..lib.pyqt import QDialog, QVBoxLayout, Qt, QPushButton
from .event import EscapeEvent
from .. import qtimage


class FullscreenWidget(QDialog, EscapeEvent):

    _FULLSCREEN_DLG = None

    def __init__(self, parent):
        """Initialize the navigator window
        @param parent: parent window
        @param auiMgr: wx.aui.AuiManager
        @keyword icon: wx.Bitmap or None
        @keyword title: string (dialog title)

        """
        super().__init__(parent)
        self.setWindowTitle(_('FullScreen display'))
        self.__do_layout()
        # 双击列表框,回车,Esc键关闭窗口
        self._close_button.clicked.connect(self.close_widget)
        self.SIG_ESCAPE_PRESSED.connect(self.close_widget)

    @classmethod
    def show_normal(cls):
        if cls._FULLSCREEN_DLG is None:
            cls._FULLSCREEN_DLG = FullscreenWidget(get_app().MainFrame)
        cls._FULLSCREEN_DLG.show()

    @classmethod
    def show_hide(cls):
        cls._FULLSCREEN_DLG.close_widget()

    def closeEvent(self, event):
        self.close_widget()

    def keyPressEvent(self, event):
        """Handles wx.EVT_KEY_UP"""
        if not self.is_escape_pressed(event):
            if event.key() in [Qt.Key_Enter, Qt.Key_Return]:
                self.close_widget()
                event.accept()
            else:
                super().keyPressEvent(event)

    def show_fullscreen(self):
        """Populates the L{AuiPaneNavigator} with the panes in the AuiMgr"""
        get_app().MainFrame.SavePerspective()
        get_app().MainFrame.hideall(hide=True)
        get_app().MainFrame.GetToolBar().setVisible(False)
        get_app().MainFrame.GetStatusBar().setVisible(False)
        get_app().MainFrame.showFullScreen()

    def close_widget(self):
        """Closes the dialog"""
        # 全屏时是否隐藏菜单栏
        get_app().MainFrame.show_menubar()
        get_app().MainFrame.showNormal()
        get_app().MainFrame.load_fullscreen_perspective()
        self.close()

    def show(self):
        # Set focus on the list box to avoid having to click on it to change
        # the tab selection under GTK.
        self.show_fullscreen()
        self._close_button.setFocus()
        super().show()

    def __do_layout(self):
        """Layout the dialog controls
        @param icon: wx.Bitmap or None
        @param title: string

        """
        layout = QVBoxLayout()
        self._close_button = QPushButton(_("Close show fullscreen"))
        self._close_button.setIcon(qtimage.load_icon("exitfullscreen.png"))
        layout.addWidget(self._close_button)
        self.setLayout(layout)
