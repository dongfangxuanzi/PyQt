from ..lib.pyqt import Qt, pyqtSignal


class EscapeEvent:
    SIG_ESCAPE_PRESSED = pyqtSignal()

    def is_escape_pressed(self, event):
        """Handles the key press events"""
        if event.key() == Qt.Key_Escape:
            self.SIG_ESCAPE_PRESSED.emit()
            event.accept()
            return True
        return False
