import re
import os.path
from .. import get_app
from ..lib.pyqt import QPlainTextEdit


class JumpoCodeFile:

    def jumpto(self, regres):
        filepath = os.path.abspath(regres.group('filepath'))
        line = int(regres.group('line'))
        get_app().GotoView(filepath, lineNum=line, load_outline=False)


class JumpoPythoncodeFile(JumpoCodeFile):
    def jumpto_line(self, linetext):
        res = re.match(
            r"^\s+File\s+\"(?P<filepath>.*)\",\s+line\s+(?P<line>\d+),\s+in\s+\w+", linetext)
        if res is not None:
            self.jumpto(res)
            return True
        # syntax error
        res = re.match(
            r"^\s+File\s+\"(?P<filepath>.*)\",\s+line\s+(?P<line>\d+)", linetext)
        if res is not None:
            self.jumpto(res)
            return True
        return False


class DoubleClickTextEdit(QPlainTextEdit, JumpoPythoncodeFile):
    def __init__(self, parent):
        super().__init__(parent)

    def mouseDoubleClickEvent(self, event):
        cursor = self.textCursor()
        line = cursor.block().blockNumber()
        doc = self.document()
        line_text = doc.findBlockByNumber(line).text()
        if not self.jumpto_line(line_text):
            last_line_text = doc.findBlockByNumber(line - 1).text()
            self.jumpto_line(last_line_text)
        # 继续执行原有的双击事件
        super().mouseDoubleClickEvent(event)
