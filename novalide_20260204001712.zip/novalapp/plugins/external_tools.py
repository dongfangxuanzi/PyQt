# -*- coding: utf-8 -*-
'''
Name:        external_tools.py
Purpose:     调用外部工具命令

Author:      wukan

Created:     2025-11-29
Copyright:   (c) HongYunVM 2025
Licence:     <your licence>
'''
import pickle
from dataclasses import dataclass
from novalapp.lib.pyqt import (
    QLabel,
    QMessageBox,
    QFileDialog,
    QHBoxLayout,
    QListWidget,
    Qt,
    QVBoxLayout,
    QPushButton,
    QLineEdit,
    QGridLayout,
    QListWidgetItem,
    QCheckBox
)
from ..plugin import iface, plugin
from .. import menuitems
from ..executable import Executable
from ..util import ui_utils, strutils, fileutils, utils
from .. import get_app, _, newid

from ..project import variables as variablesutils

EXTERNAL_TOOLS_KEY = "external_tools"
REDIRECT_EXTERNAL_TOOLS_KEY = "external_tools_to_output"


@dataclass
class ExternaltoolItem:
    title: str
    path: str
    init_dir: str
    arguments: list

    def dump(self):
        return {
            'title': self.title,
            'path': self.path,
            'init_dir': self.init_dir,
            'arguments': self.arguments
        }

    @staticmethod
    def load(data):
        return ExternaltoolItem(
            data['title'],
            data['path'],
            data['init_dir'],
            data['arguments']
        )


class ExternaltoolsDialog(ui_utils.BaseModalDialog):
    '''
    外部工具管理对话框
    '''

    EXTERNAL_TOOLS = []
    EXTERNAL_TOOLS_MENU_ID = None
    MAX_EXTERNAL_TOOLS_MENU_ITEM_COUNT = 100
    EXTERNAL_TOOLS_MENU_ITEM_ID1 = -1

    def __init__(self, parent):
        """
        """
        title = _("External Tools")
        super().__init__(title, parent)
        self.setFixedSize(700, 650)

        self.layout.addWidget(QLabel(_('Menu Content') + ":"))
        top_hbox = QHBoxLayout()
        self.contents = QListWidget()
        self.contents.itemClicked.connect(self.on_item_clicked)
        top_hbox.addWidget(self.contents)

        button_vbox = QVBoxLayout()
        button_vbox.setAlignment(Qt.AlignTop)
        add_button = QPushButton(_('Add'))
        add_button.clicked.connect(self.add_tool_item)
        button_vbox.addWidget(add_button)

        self.del_button = QPushButton(_('Delete'))
        button_vbox.addWidget(self.del_button)
        self.del_button.clicked.connect(self.delete_tool_item)

        self.move_up_button = QPushButton(_('Move up'))
        button_vbox.addWidget(self.move_up_button)
        self.move_up_button.clicked.connect(self.move_up_tool_item)

        self.move_down_button = QPushButton(_('Move down'))
        button_vbox.addWidget(self.move_down_button)
        self.move_down_button.clicked.connect(self.move_down_tool_item)

        top_hbox.addLayout(button_vbox)
        self.layout.addLayout(top_hbox)

        grid_layout = QGridLayout()
        grid_layout.addWidget(QLabel(_('Title') + ":"), 0, 0)

        self.title_edit = QLineEdit()
        self.title_edit.textChanged.connect(self.update_item_title)
        grid_layout.addWidget(self.title_edit, 0, 1)

        grid_layout.addWidget(QLabel(_('Command') + ":"), 1, 0)
        self.command_edit = QLineEdit()
        grid_layout.addWidget(self.command_edit, 1, 1)

        self.open_exe_path_btn = QPushButton('...')
        self.open_exe_path_btn.clicked.connect(self.open_executable_path)
        grid_layout.addWidget(self.open_exe_path_btn, 1, 2)

        grid_layout.addWidget(QLabel(_('Arguments') + ":"), 2, 0)
        self.arguments_edit = QLineEdit()
        grid_layout.addWidget(self.arguments_edit, 2, 1)

        grid_layout.addWidget(QLabel(_('Initial Directory') + ":"), 3, 0)
        self.initial_dir_edit = QLineEdit()

        grid_layout.addWidget(self.initial_dir_edit, 3, 1)

        self.open_init_path_btn = QPushButton(_('Browse') + "...")
        self.open_init_path_btn.clicked.connect(self.open_folder_path)
        grid_layout.addWidget(self.open_init_path_btn, 3, 2)

        self.use_output_chkbox = QCheckBox(_('Use output view'))
        grid_layout.addWidget(self.use_output_chkbox, 4, 0)
        try:
            get_app().MainFrame.GetView("Output")
            self.use_output_chkbox.setEnabled(True)
            self.use_output_chkbox.setChecked(
                utils.profile_get_int(REDIRECT_EXTERNAL_TOOLS_KEY, False)
            )
        except KeyError:
            self.use_output_chkbox.setEnabled(False)
        self.layout.addLayout(grid_layout)
        self.create_standard_buttons()
        self.update_ui_states()
        self.init_tools_info()

        self._previous_item = None

    @classmethod
    def load_tools(cls, tools_menu):
        external_tools_menu_item = tools_menu.FindMenuItem(ExternaltoolsDialog.EXTERNAL_TOOLS_MENU_ID)
        for i, toolitem in enumerate(cls.EXTERNAL_TOOLS):
            # 触发了triggered(bool)函数
            def load(checked, n=i):
                cls.exec_tool_command(n)
            toolitem_menu_id = external_tools_menu_item.id + i + 1

            get_app().InsertCommand(
                external_tools_menu_item.id,
                toolitem_menu_id,
                tools_menu,
                toolitem.title,
                handler=load
            )
            tool_item_index = tools_menu.find_pos(toolitem_menu_id)
            utils.get_logger().debug(
                'load external tool menu id %d,item index %d, tool index %d,data %s',
                toolitem_menu_id,
                tool_item_index,
                i,
                toolitem.dump()
            )

    @classmethod
    def reload_tools(cls, tools_menu, tool_items_count):
        cls.rebuild_external_tools_menu(tools_menu, tool_items_count)
        # 重新生成外部工具菜单项
        cls.load_tools(tools_menu)

    @classmethod
    def rebuild_external_tools_menu(cls, tools_menu, tool_items_count):
        first_file_index = tools_menu.find_pos(cls.EXTERNAL_TOOLS_MENU_ITEM_ID1)
        if first_file_index != tools_menu.INVALID_ITEM_POS:
            # 先要删除原先的所有历史菜单项
            first_file_index = first_file_index
            tools_menu.delete(first_file_index, first_file_index + tool_items_count - 1)

    @classmethod
    def exec_tool_command(cls, n_index):
        toolitem = cls.EXTERNAL_TOOLS[n_index]
        utils.get_logger().debug("clicked tool item index is %d, titile %s", n_index, toolitem.title)
        args = []
        workdir = None
        try:
            workdir = variablesutils.VariablesManager(
                get_app().get_current_project()).EvalulateValue(toolitem.init_dir)
            for arg in toolitem.arguments:
                arg_value = variablesutils.VariablesManager(
                    get_app().get_current_project()).EvalulateValue(arg)
                args.append(arg_value)
        except RuntimeError as ex:
            QMessageBox.critical(
                get_app().GetTopWindow(),
                get_app().GetAppName(),
                str(ex)
            )
            return
        executable = Executable(toolitem.path, workdir, args=args)
        # 是否将工具输出重定向到输出窗口
        if not utils.profile_get_int(REDIRECT_EXTERNAL_TOOLS_KEY, False):
            try:
                cmd = executable.get_cmd()
                utils.get_logger().info(
                    'clicked tool item command is %s, work dir is %s',
                    cmd,
                    workdir
                )
                executable.run()
            except Exception as ex:
                QMessageBox.critical(get_app().MainFrame, _('Error'), str(ex))
                utils.get_logger().error(
                    "exec command %s workdir %s, error:%s",
                    executable.get_cmd(),
                    executable.workdir,
                    str(ex)
                )
        else:
            output_view_name = "Output"
            output_view = get_app().MainFrame.GetView(output_view_name)
            get_app().MainFrame.activateBottomTab(
                output_view_name
            )
            output_view.run(
                executable.path,
                executable.args,
                executable.workdir)

    @staticmethod
    def output_callback_exit(exitcode):
        output_view = get_app().MainFrame.GetView("Output")
        output_view.callback_exit(exitcode)

    def open_executable_path(self):
        if utils.is_windows():
            descrs = _("All executables") + " (*.exe;*.bat;*.cmd;*.com)"
        else:
            descrs = _("All files") + " (*.*)"
        path, _filetype = QFileDialog.getOpenFileName(
            self,
            _('Select executable path'),
            None,
            descrs
        )
        if not path:
            return
        self.command_edit.setText(fileutils.opj(path))

    def open_folder_path(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog | QFileDialog.ShowDirsOnly
        path = QFileDialog.getExistingDirectory(
            self, _("Select directory"), self.initial_dir_edit.text(),
            options)
        if path:
            # 必须转换一下路径为系统标准路径格式
            self.initial_dir_edit.setText(fileutils.opj(path))

    def on_item_clicked(self, item):
        if self._previous_item is not None:
            self.update_tool_item(self._previous_item)
            if not self.check_valid_tool_item(self._previous_item):
                self.contents.setCurrentItem(self._previous_item)
                return
        self.update_ui_states()
        self.show_tool_info(item)

    def update_ui_states(self, item=None):
        if item is None:
            current_item = self.contents.currentItem()
        else:
            current_item = item
        if current_item is None:
            self.arguments_edit.setEnabled(False)
            self.command_edit.setEnabled(False)
            self.initial_dir_edit.setEnabled(False)
            self.title_edit.setEnabled(False)
            self.del_button.setEnabled(False)
            self.open_init_path_btn.setEnabled(False)
            self.open_exe_path_btn.setEnabled(False)
        else:
            self.arguments_edit.setEnabled(True)
            self.command_edit.setEnabled(True)
            self.initial_dir_edit.setEnabled(True)
            self.del_button.setEnabled(True)
            self.title_edit.setEnabled(True)
            self.open_init_path_btn.setEnabled(True)
            self.open_exe_path_btn.setEnabled(True)

        current_row = self.contents.currentRow()
        if 0 < current_row < self.contents.count() - 1:
            self.move_up_button.setEnabled(True)
            self.move_down_button.setEnabled(True)
        elif current_row < 0:
            self.move_up_button.setEnabled(False)
            self.move_down_button.setEnabled(False)
        elif current_row == self.contents.count() - 1:
            self.move_down_button.setEnabled(False)
            self.move_up_button.setEnabled(True)
        elif current_row == 0:
            self.move_up_button.setEnabled(False)
            self.move_down_button.setEnabled(True)
        else:
            raise RuntimeError(_('Invalid list item index'))

    def show_tool_info(self, current_item):
        if current_item is not None:
            current_toolitem = current_item.data(Qt.UserRole)
            self.arguments_edit.setText(' '.join(current_toolitem.arguments))
            self.command_edit.setText(current_toolitem.path)
            self.initial_dir_edit.setText(current_toolitem.init_dir)
            self.title_edit.setText(current_toolitem.title)
        else:
            self.arguments_edit.setText('')
            self.command_edit.setText('')
            self.initial_dir_edit.setText('')
            self.title_edit.setText('')

    def init_tools_info(self):
        for toolitem in self.EXTERNAL_TOOLS:
            listitem = QListWidgetItem(toolitem.title)
            listitem.setData(Qt.UserRole, toolitem)
            self.contents.addItem(listitem)
            self.title_edit.setText(toolitem.title)

    def update_item_title(self, *args):
        current_item = self.contents.currentItem()
        if current_item is not None:
            current_item.setText(args[0])

    def add_tool_item(self):
        toolitem = ExternaltoolItem(_('[New Tool]'), '', '', [])
        listitem = QListWidgetItem('')
        listitem.setData(Qt.UserRole, toolitem)
        self.contents.addItem(listitem)
        self.contents.setCurrentItem(listitem)
        self.title_edit.setText(toolitem.title)
        self._previous_item = listitem
        self.update_ui_states(listitem)

    def move_up_tool_item(self):
        current_index = self.contents.currentRow()
        if current_index > 0:
            current_item = self.contents.item(current_index)
            self.contents.takeItem(current_index)
            self.contents.insertItem(current_index - 1, current_item)
            self.contents.setCurrentItem(current_item)
            self.show_tool_info(self.contents.currentItem())
        self.update_tool_item(self.contents.currentItem())
        self.update_ui_states()

    def delete_tool_item(self):
        current_index = self.contents.currentRow()
        utils.get_logger().debug('current row is %d', current_index)
        if current_index >= 0:
            self.contents.takeItem(current_index)
            self.show_tool_info(self.contents.currentItem())
        self.update_ui_states()

    def move_down_tool_item(self):
        current_index = self.contents.currentRow()
        if current_index < len(self.EXTERNAL_TOOLS) - 1:
            current_item = self.contents.item(current_index)
            next_item_index = current_index + 1
            next_item = self.contents.item(next_item_index)
            self.contents.takeItem(next_item_index)
            self.contents.insertItem(current_index, next_item)
            self.contents.setCurrentItem(current_item)
            self.show_tool_info(self.contents.currentItem())
        self.update_tool_item(self.contents.currentItem())
        self.update_ui_states()

    def check_valid_tool_item(self, current_item=None):
        if current_item is None:
            current_item = self.contents.currentItem()
        if current_item is None:
            return True
        current_toolitem = current_item.data(Qt.UserRole)
        if current_toolitem in self.EXTERNAL_TOOLS:
            return True
        if strutils.is_none_empty(current_toolitem.path):
            QMessageBox.information(self, get_app().GetAppName(), _(
                'The executable file path of this tool must be entered'))
            return False

        if strutils.is_none_empty(current_toolitem.title):
            QMessageBox.information(self, get_app().GetAppName(), _('The title of this tool must be entered'))
            return False

        for toolitem in self.EXTERNAL_TOOLS:
            if 0 == strutils.case_insensitive_compare(toolitem.title, current_item.text()):
                QMessageBox.information(self, get_app().GetAppName(), _(
                    'Tool titile %s has been used' % toolitem.title))
                return False
        return True

    def update_tool_item(self, current_item=None):
        if current_item is None:
            current_item = self.contents.currentItem()
        if current_item is not None:
            toolitem = current_item.data(Qt.UserRole)
            toolitem.title = self.title_edit.text().strip()
            toolitem.path = self.command_edit.text().strip()
            toolitem.init_dir = self.initial_dir_edit.text().strip()
            toolitem.arguments = strutils.parse_cmd_args(self.arguments_edit.text(), stripQuotes=True)

    def _ok(self):
        self.update_tool_item()
        if not self.check_valid_tool_item():
            return

        tool_items_count = len(self.EXTERNAL_TOOLS)
        self.EXTERNAL_TOOLS.clear()
        for i in range(self.contents.count()):
            listitem = self.contents.item(i)
            toolitem = listitem.data(Qt.UserRole)
            assert toolitem is not None
            if len(self.EXTERNAL_TOOLS) <= self.MAX_EXTERNAL_TOOLS_MENU_ITEM_COUNT:
                self.EXTERNAL_TOOLS.append(toolitem)

        tools_menu = get_app().get_menu(_("&Tools"))
        utils.get_logger().debug(
            'rebuild tool items count %d, new items count %d',
            tool_items_count,
            len(self.EXTERNAL_TOOLS)
        )
        self.reload_tools(tools_menu, tool_items_count)
        utils.profile_set(
            REDIRECT_EXTERNAL_TOOLS_KEY,
            self.use_output_chkbox.isChecked()
        )
        super()._ok()


class ExternalToolsLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)

    def Load(self):
        ExternaltoolsDialog.EXTERNAL_TOOLS_MENU_ID = newid()
        get_app().InsertCommand(
            menuitems.ID_PREFERENCES,
            ExternaltoolsDialog.EXTERNAL_TOOLS_MENU_ID,
            _("&Tools"),
            _("&External Tools"),
            self.open_external_tools,
            add_separator=True
        )
        menu = get_app().get_menu(_("&Tools"))
        menu_index = menu.GetMenuIndex(ExternaltoolsDialog.EXTERNAL_TOOLS_MENU_ID)
        next_menu_item = menu.GetItemByIndex(menu_index + 1)
        menu.insert_separator(next_menu_item)
        self.init_external_tools_menuitem_ids()
        self.load_external_tools()

    def open_external_tools(self):
        external_dlg = ExternaltoolsDialog(get_app().GetTopWindow())
        external_dlg.exec_()

    def load_external_tools(self):
        tools_data = utils.profile_get(EXTERNAL_TOOLS_KEY, [])
        if isinstance(tools_data, bytes):
            tools_data = pickle.loads(tools_data)
        utils.get_logger().info('find total %d external tools', len(tools_data))
        for tooldata in tools_data:
            utils.get_logger().debug('load external tool info %s', str(tooldata))
            tool_item = ExternaltoolItem.load(tooldata)
            ExternaltoolsDialog.EXTERNAL_TOOLS.append(tool_item)
        menu = get_app().get_menu(_("&Tools"))
        ExternaltoolsDialog.load_tools(menu)

    def HookExit(self, query_exit):
        ''''''
        # 插件退出
        tools_data = []
        for tool in ExternaltoolsDialog.EXTERNAL_TOOLS:
            data_dict = tool.dump()
            utils.get_logger().debug('save external tool info %s', str(data_dict))
            tools_data.append(data_dict)
        utils.get_logger().debug('save total %d external tools', len(tools_data))
        utils.profile_set(EXTERNAL_TOOLS_KEY, pickle.dumps(tools_data))
        return True

    def init_external_tools_menuitem_ids(self):
        '''
        为防止id冲撞,预留MAX_EXTERNAL_TOOLS_MENU_ITEM_COUNT个id数值
        '''
        for i in range(ExternaltoolsDialog.MAX_EXTERNAL_TOOLS_MENU_ITEM_COUNT):
            if i == 0:
                ExternaltoolsDialog.EXTERNAL_TOOLS_MENU_ITEM_ID1 = newid()
                utils.get_logger().debug(
                    'external menu id %d, first tool menu item id is %d',
                    ExternaltoolsDialog.EXTERNAL_TOOLS_MENU_ID,
                    ExternaltoolsDialog.EXTERNAL_TOOLS_MENU_ITEM_ID1
                )
            else:
                newid()
        return ExternaltoolsDialog.EXTERNAL_TOOLS_MENU_ITEM_ID1
