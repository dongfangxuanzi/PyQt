# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _md.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.lib.qsci import QsciLexerMarkdown
from .docview import MarkdownDocument


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_MARKDOWN")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('Markdown File')

    def GetExt(self):
        return "md"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['<!--', '-->']

    def GetShowName(self):
        return "Markdown"

    def GetDefaultExt(self):
        return "md"

    def GetDocTypeName(self):
        return "Markdown Document"

    def GetViewTypeName(self):
        return _("Markdown Editor")

    def GetDocTypeClass(self):
        return MarkdownDocument

    def get_lexer(self, parent):
        return QsciLexerMarkdown(parent)
