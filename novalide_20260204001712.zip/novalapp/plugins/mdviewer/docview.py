from ...editor.textview import TextDocument
from ...lib.docview import View
from .mdwidget import MDWidget
from ...lib.pyqt import QSplitter, Qt


class MarkdownView(View):

    def __init__(self, editview):
        super().__init__()
        self._editview = editview
        editor = self._editview.GetCtrl()
        textframe = editor.parent()
        frame = textframe.parent()
        self.__mdviewer = MDWidget(self._editview, frame)
        frame.layout().removeWidget(textframe)
        self.__splitter = QSplitter(Qt.Horizontal, frame)
        self.__splitter.addWidget(textframe)
        self.__splitter.addWidget(self.__mdviewer)
        frame.layout().addWidget(self.__splitter)
        self.__mdviewer.process()

    @property
    def mdviewer(self):
        return self.__mdviewer


class MarkdownDocument(TextDocument):

    def OnOpenDocument(self, filename):
        '''
        '''
        ret = super().OnOpenDocument(filename)
        self.AddView(MarkdownView(self.GetFirstView()))
        return ret

    def reload(self):
        super().reload()
        self._document_views[1].mdviewer.process()
