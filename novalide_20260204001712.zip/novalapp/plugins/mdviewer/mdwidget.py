# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2018  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""MD rendering widget"""
import os
from ...qtimage import load_image, load_icon
from .markdown import render_markdown
from ...widgets.spacers import ToolBarVSpacer
from ... import _, get_app
from ...common.encodings import UTF8_FILE_ENCODING
from ...lib.pyqt import (
    Qt,
    QSize,
    QToolBar,
    QWidget,
    QHBoxLayout,
    QLabel,
    QVBoxLayout,
    QSizePolicy,
    QFrame,
    pyqtSignal,
    QPrintDialog,
    QDialog,
    QAction,
    QWebEngineView,
    QUrl,
    QFileDialog,
    QPageLayout,
    QPageSize,
    QMarginsF,
    QMessageBox,
    QEventLoop
)

IDLE_TIMEOUT = 1500


class MDViewer(QWebEngineView):
    """Markdown rendered content viewer"""

    def __init__(self, parent):
        super().__init__(parent)


class MDTopBar(QFrame):
    """MD widget top bar at the top"""
    STATE_OK_UTD = 0        # Parsed OK, MD up to date
    STATE_OK_CHN = 1        # Parsed OK, MD changed
    STATE_BROKEN_UTD = 2    # Parsed with errors, MD up to date
    STATE_BROKEN_CHN = 3    # Parsed with errors, MD changed
    STATE_UNKNOWN = 4

    def __init__(self, parent):
        QFrame.__init__(self, parent)
        self.__info_icon = None
        self.__warningsIcon = None
        self.__layout = None
        self.__create_layout()
        self.__current_iconstate = self.STATE_UNKNOWN

    def __create_layout(self):
        """Creates the layout"""
        self.setFixedHeight(24)
        self.__layout = QHBoxLayout(self)
        self.__layout.setContentsMargins(0, 0, 0, 0)

        # Create info icon
        self.__info_icon = QLabel(self)
        self.__info_icon.setPixmap(self.load_markdown_image('cfokchn.png'))
        self.__layout.addWidget(self.__info_icon)

        self.__spacer = QWidget(self)
        self.__spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.__spacer.setMinimumWidth(0)
        self.__layout.addWidget(self.__spacer)

    @staticmethod
    def load_markdown_image(imagefile):
        return load_image("mdviewer/" + imagefile)

    def clearWarnings(self):
        """Clears the warnings"""
        self.__warningsIcon.setVisible(False)
        self.__warningsIcon.setToolTip("")

    def setWarnings(self, warnings):
        """Sets the warnings"""
        self.__warningsIcon.setToolTip(
            'Markdown parser warnings:\n' + '\n'.join(warnings))
        self.__warningsIcon.setVisible(True)

    def clearErrors(self):
        """Clears all the errors"""
        self.__info_icon.setToolTip('')

    def setErrors(self, errors):
        """Sets the errors"""
        self.__info_icon.setToolTip(
            'Markdown parser errors:\n' + '\n'.join(errors))

    def update_info_icon(self, state):
        """Updates the information icon"""
        if state == self.__current_iconstate:
            return
        if state == self.STATE_OK_UTD:
            self.__info_icon.setPixmap(self.load_markdown_image('cfokutd.png'))
            self.__info_icon.setToolTip(_("Markdown render is up to date"))
            self.__current_iconstate = self.STATE_OK_UTD
        elif state == self.STATE_OK_CHN:
            self.__info_icon.setPixmap(self.load_markdown_image('cfokchn.png'))
            self.__info_icon.setToolTip("Markdown render is not up to date; "
                                        "will be updated on idle")
            self.__current_iconstate = self.STATE_OK_CHN
        elif state == self.STATE_BROKEN_UTD:
            self.__info_icon.setPixmap(
                self.load_markdown_image('cfbrokenutd.png'))
            self.__info_icon.setToolTip(_("Markdown render might be invalid "
                                        "due to invalid python code"))
            self.__current_iconstate = self.STATE_BROKEN_UTD
        elif state == self.STATE_BROKEN_CHN:
            self.__info_icon.setPixmap(getPixmap('cfbrokenchn.png'))
            self.__info_icon.setToolTip("Markdown render might be invalid; "
                                        "will be updated on idle")
            self.__current_iconstate = self.STATE_BROKEN_CHN
        else:
            # STATE_UNKNOWN
            self.__info_icon.setPixmap(getPixmap('cfunknown.png'))
            self.__info_icon.setToolTip("Markdown render state is unknown")
            self.__current_iconstate = self.STATE_UNKNOWN

    def getCurrentState(self):
        """Provides the current state"""
        return self.__current_iconstate

    def resizeEvent(self, event):
        """Editor has resized"""
        QFrame.resizeEvent(self, event)


class MDWidget(QWidget):
    """The MD rendered content widget which goes along with the text editor"""
    sigEscapePressed = pyqtSignal()

    def __init__(self, editor, parent):
        QWidget.__init__(self, parent)
        self.__editor = editor
        self.__parentwidget = parent
        self.__connected = False

        hlayout = QHBoxLayout()
        hlayout.setContentsMargins(0, 0, 0, 0)
        hlayout.setSpacing(0)

        vlayout = QVBoxLayout()
        vlayout.setContentsMargins(0, 0, 0, 0)
        vlayout.setSpacing(0)

        # Make pylint happy
        self.__toolbar = None
        self.__topbar = None

        vlayout.addWidget(self.__create_topbar())
        vlayout.addWidget(self.__create_mdview())

        hlayout.addWidget(self.__create_toolbar())
        hlayout.addLayout(vlayout)
        self.setLayout(hlayout)

    @staticmethod
    def load_markdown_image(imagefile):
        return load_icon("mdviewer/" + imagefile)

    def get_save_filename(self, title, descr):
        filename, filetype = QFileDialog.getSaveFileName(
            self,
            _('Export to %s') % title,
            os.getcwd(),
            descr
        )
        return filename

    def process(self):
        """Parses the content and displays the results"""
        self.__topbar.update_info_icon(self.__topbar.STATE_OK_CHN)
        filename = self.__editor.GetDocument().GetFilename()
        renderedtext, errors = render_markdown(
            self.__editor.GetValue(),
            filename
        )
        if errors:
            self.__topbar.update_info_icon(self.__topbar.STATE_BROKEN_UTD)
            self.__topbar.setErrors(errors)
            return
        if renderedtext is None:
            self.__topbar.update_info_icon(self.__topbar.STATE_BROKEN_UTD)
            self.__topbar.setErrors(['Unknown markdown rendering error'])
            return
        self.mdview.setHtml(renderedtext, QUrl('file:///'))
        self.mdview.loadFinished.connect(
            lambda: self.__topbar.update_info_icon(self.__topbar.STATE_OK_UTD))

    def __create_toolbar(self):
        """Creates the toolbar"""
        self.__toolbar = QToolBar(self)
        self.__toolbar.setOrientation(Qt.Vertical)
        self.__toolbar.setMovable(False)
        self.__toolbar.setAllowedAreas(Qt.RightToolBarArea)
        self.__toolbar.setIconSize(QSize(16, 16))
        self.__toolbar.setFixedWidth(30)
        self.__toolbar.setContentsMargins(0, 0, 0, 0)

        # Some control buttons could be added later
        self.printbutton = QAction(
            self.load_markdown_image('printer.png'), _('Print'), self)
        self.printbutton.triggered.connect(self.__on_print)
        self.__toolbar.addAction(self.printbutton)

        print_spacer = ToolBarVSpacer(self.__toolbar, 8)
        print_spacer.setObjectName('printSpacer')
        self.__toolbar.addWidget(print_spacer)

        self.__render_button = QAction(
            self.load_markdown_image('run.png'), _('Render'), self)
        self.__render_button.triggered.connect(self.process)
        self.__toolbar.addAction(self.__render_button)

        self.__switch_edit_button = QAction(
            self.load_markdown_image('lock_edit.png'), _('Switch to editing'), self)
        self.__switch_edit_button.triggered.connect(self.__switch_to_edit)
        self.__toolbar.addAction(self.__switch_edit_button)
        self.__editor.GetCtrl().setReadOnly(True)

        self.__export_html_button = QAction(
            self.load_markdown_image('html_go.png'), _('Export to html'), self)
        self.__export_html_button.triggered.connect(self.__export_to_html)
        self.__toolbar.addAction(self.__export_html_button)

        self.__export_pdf_button = QAction(
            self.load_markdown_image('save_as_pdf.ico'), _('Export to pdf'), self)
        self.__export_pdf_button.triggered.connect(self.__export_to_pdf)
        self.__toolbar.addAction(self.__export_pdf_button)
        return self.__toolbar

    def __create_topbar(self):
        """Creates the top bar"""
        self.__topbar = MDTopBar(self)
        return self.__topbar

    def __create_mdview(self):
        """Creates the graphics view"""
        self.mdview = MDViewer(self)
        return self.mdview

    def __on_print(self):
        """Print the markdown page"""
        def print_finished(success):
            if success:
                QMessageBox.information(
                    self, get_app().GetAppName(), _("Printing success!"))
            else:
                QMessageBox.critical(
                    self, _('Error'), _("Printing failed!"))
            loop.quit()
        loop = QEventLoop()
        dialog = QPrintDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            printer = dialog.printer()
            self.mdview.page().print(printer, print_finished)
            loop.exec_()

    def __switch_to_edit(self):
        editor = self.__editor.GetCtrl()
        if editor.isReadOnly():
            editor.setReadOnly(False)
            self.__switch_edit_button.setIcon(
                self.load_markdown_image('lock.png'))
            self.__switch_edit_button.setToolTip(_('Switch to locked'))
        else:
            editor.setReadOnly(True)
            self.__switch_edit_button.setIcon(
                self.load_markdown_image('lock_edit.png'))
            self.__switch_edit_button.setToolTip(_('Switch to editing'))

    def __export_to_html(self):
        self.mdview.page().toHtml(self.__save_to_html)

    def __save_to_html(self, content):
        html_file_path = self.get_save_filename(
            "html", _('HTML File') + " (*.html)"
        )
        if not html_file_path:
            return
        with open(html_file_path, "w", encoding=UTF8_FILE_ENCODING) as f:
            f.write(content)

    def __export_to_pdf(self):
        pdf_file_path = self.get_save_filename(
            "pdf", _('PDF File') + " (*.pdf)"
        )
        if not pdf_file_path:
            return
        self.mdview.page().pdfPrintingFinished.connect(self.__print_pdf_finished)
        layout = QPageLayout(
            QPageSize(QPageSize.A4),
            QPageLayout.Portrait, QMarginsF(0, 0, 0, 0)
        )
        page = self.mdview.page()
        page.printToPdf(pdf_file_path, layout)

    def __print_pdf_finished(self):
        QMessageBox.information(
            self, get_app().GetAppName(), _("Printing PDF Finished!"))
