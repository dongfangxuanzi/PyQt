import os
import logging

log = logging.getLogger(__name__)


def calc_version_value(ver_str="0.0.0"):
    """Calculates a version value from the provided dot-formated string

    1) SPECIFICATION: Version value calculation AA.BBB.CCC
         - major values: < 1     (i.e 0.0.85 = 0.850)
         - minor values: 1 - 999 (i.e 0.1.85 = 1.850)
         - micro values: >= 1000 (i.e 1.1.85 = 1001.850)

    @keyword ver_str: Version string to calculate value of

    """
    ver_str = ''.join([char for char in ver_str
                       if char.isdigit() or char == '.'])
    ver_lvl = ver_str.split('.')
    if len(ver_lvl) < 3:
        return 0

    major = int(ver_lvl[0]) * 1000
    minor = int(ver_lvl[1])
    if len(ver_lvl[2]) <= 2:
        ver_lvl[2] += '0'
    micro = float(ver_lvl[2]) / 1000
    return float(major) + float(minor) + micro


def compare_common_version(new_version, old_version):
    '''
        比较通用版本号大小,如果新版本号大于旧版本号返回1,否则返回0,返回0才正常,返回1需要更新
    '''
    def format_version_str(version_str):
        '''
            标准化版本字符串,至少包含3个点.如果是类似x.x的版本则转换为x.x.0之类的
        '''
        if len(version_str.split('.')) == 2:
            version_str += ".0"
        return version_str

    new_version = format_version_str(new_version)
    old_version = format_version_str(old_version)
    if calc_version_value(new_version) <= calc_version_value(old_version):
        return 0
    return 1


class UpdateVersion:
    '''
        数据目录下生成文件,写入数据版本信息,
        数据更新之后比对数据版本,如果版本升级,则写入新版本
    '''
    VERSION_FILE = "version"

    def __init__(self, version_out_path):
        self._out_version_path = version_out_path
        self._version_file = self.VERSION_FILE

    def get_version_file(self):
        return os.path.join(self._out_version_path, self._version_file)

    def update_new_version(self, new_version):
        '''
        更新版本文件信息,如果版本文件存在并且和最新版本号一致,则不用更新
        '''
        if self.need_update_version(new_version):
            self.save_new_version(new_version)

    def save_new_version(self, new_version):
        with open(self.get_version_file(), "w") as f:
            return f.write(str(new_version))

    def need_update_version(self, new_version):
        '''
            比对新老版本是否一致,是否需要更新
        '''
        # 不存在版本文件,需要更新
        ver_file_path = self.get_version_file()
        if not os.path.exists(ver_file_path):
            return True
        old_version = self.get_old_version()
        log.debug('version file %s old version is %s, new version is %s',
                  ver_file_path, old_version, new_version)
        if old_version is None:
            return True
        return compare_common_version(new_version, old_version)

    def get_old_version(self):
        try:
            with open(self.get_version_file()) as f:
                return f.read()
        except:
            return None
