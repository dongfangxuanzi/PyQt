# -*- coding: utf-8 -*-
'''
Name:        singleton.py
Purpose:     通用单例模式的几种实现方式

Author:      wukan

Created:     2024-01-26
Copyright:   (c) wukan 2024
Licence:     <your licence>
'''
from functools import wraps


def Singleton(cls):
    '''
    使用装饰圈函数实现单例,缺点:
    装饰函数修饰的类在linux系统上python3.8无法调用staticmethod方法
    TypeError: 'staticmethod' object is not callable
    '''
    instances = {}

    @wraps(cls)
    def getinstance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return getinstance


class SingletonMeta(type, object):
    '''
    通过元类（metaclass）实现单例
    '''

    def __init__(self, *args, **kwargs):
        self._instance = None
        super().__init__(*args, **kwargs)

    def __call__(self, *args, **kwargs):
        if self._instance is None:
            self._instance = super().__call__(*args, **kwargs)
        return self._instance
