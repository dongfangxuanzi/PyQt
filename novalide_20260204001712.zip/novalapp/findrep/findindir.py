# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        findindir.py
Purpose:

Author:      wukan

Created:     2019-03-14
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
from typing import NamedTuple
import enum
import re
import os
from .. import _, get_app
from ..util import utils, fileutils, ui_utils, strutils
from ..lib.pyqt import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QGridLayout,
    QHBoxLayout,
    QCheckBox,
    Qt,
    QLineEdit,
    QPushButton,
    QLocale,
    QFileDialog,
    QThread,
    QMessageBox
)
from . import findui
from .option import FindindirOpt
from ..syntax.syntax import SyntaxThemeManager
from ..project.document import ProjectDocument
from .progress import FindTextQProgressDialog
from .mixin import FindMixin
from .. import constants, globalkeys
from ..widgets.separator import Separator
from ..common.encodings import UTF8_FILE_ENCODING
# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------
FILENAME_MARKER = "Found in file: "
PROJECT_MARKER = "Searching project: "
FILE_MARKER = "Searching file: "
FIND_MATCHDIR = "FindMatchDir"
FIND_MATCHDIRSUBFOLDERS = "FindMatchDirSubfolders"
FIND_MATCHFILETYPES = "FindMatchFileTypes"


class FindWhere(enum.Enum):
    FIND_IN_DIR = 0
    FIND_IN_FILE = 1
    FIND_IN_PROJECT = 2


class FindResult(NamedTuple):
    findstr: str
    findnum: int


class FindtoPath(NamedTuple):
    findpath: str
    findwhere: FindWhere


def _open(filename, is_detect_encoding=True):
    # 默认以utf-8打开文件编码
    encoding = UTF8_FILE_ENCODING
    if is_detect_encoding:
        try:
            encoding = fileutils.detect_file_encoding(filename)
            utils.get_logger().debug("detect file %s encoding is %s", filename, encoding)
        except Exception as e:
            utils.get_logger().error("get file %s encoding error", filename)
    f = open(filename, 'r', encoding=encoding, errors='replace')
    return f


class FindText(QThread):
    def __init__(self, findstr, findreg, resultsview, findservice):
        parent = resultsview
        super().__init__(parent)
        self._findstr = findstr
        self._findreg = findreg
        self.resultsview = resultsview
        self.findservice = findservice

    def run(self):
        raise NotImplementedError("you must implemented it in derived class")

    def findtext_in_files(self, list_files, cur_pos):
        '''
            在文件列表中查找文本,将查找结果插入到队列当中,进度条界面会读取队列当中的内容
            并设置查找进度
        '''
        assert cur_pos >= 0
        found_line = 0
        for list_file in list_files:
            # 只有进度条显示,并且点击取消按钮时才退出
            if self.findservice.IsProgressStopped():
                break
            found_line += self.findservice.FindTextInFile(
                list_file, self._findstr, self._findreg, self.resultsview)
            utils.get_logger().debug('find %s in file %s %d results',
                                     self._findstr, list_file, found_line)
            msg = _("Searching file %s") % list_file
            self.findservice.update_progress(cur_pos, msg)
            cur_pos += 1
        return found_line, cur_pos


class FindIndir(FindText):
    def __init__(self, find_dir_option, findstr, findreg, resultsview, findservice):
        super().__init__(findstr, findreg, resultsview, findservice)
        self._find_dir_option = find_dir_option

    def run(self):
        self.find_text_indir()

    def find_text_indir(self):
        # 设置正在搜索文本
        self.findservice._is_searching_text = True
        total_found_line = 0
        list_files = []
        cur_pos = 0
        # do search in files on disk
        for root, dirs, files in os.walk(self._find_dir_option.path):
            # 搜索版本控制工具生成的目录没有意义,故忽略这些目录
            for r_control_dir in constants.REVISION_CONTROL_DIRS:
                if r_control_dir in dirs:
                    dirs.remove(r_control_dir)
                    utils.get_logger().debug(
                        'revision control dir %s is ignored...',
                        r_control_dir
                    )
                    break
            if self.findservice.IsProgressStopped():
                break
            # 是否搜索子目录
            if not self._find_dir_option.recursive and root != self._find_dir_option.path:
                break
            # 是否搜索隐藏目录
            if not self._find_dir_option.hiddendir and fileutils.is_file_path_hidden(root):
                utils.get_logger().info('search path %s is hidden state', root)
                continue
            for name in files:
                # 后缀文件名列表为空表示搜索所有后缀的文件
                if self._find_dir_option.filetypes != []:
                    file_ext = strutils.get_file_extension(name, keepdot=True)
                    # 查找时过滤文件后缀名
                    if file_ext not in self._find_dir_option.filetypes:
                        continue
                filename = os.path.join(root, name)
                # 是否搜索隐藏文件
                if not self._find_dir_option.hiddendir and fileutils.is_file_path_hidden(filename):
                    break
                list_files.append(filename)
                self.findservice.total_find_filecount += 1
                if len(list_files) >= self.findservice.MAX_LIMIT_LIST_FILE_LENGTH:
                    if self.findservice.IsProgressRunning():
                        self.findservice.progress_dlg.setMaximum(
                            self.findservice.total_find_filecount)
                    found_line, cur_pos = self.findtext_in_files(
                        list_files, cur_pos)
                    total_found_line += found_line
                    list_files = []
        # 处理一些队列末尾的文件查找
        if self.findservice.total_find_filecount > 0 and len(list_files) > 0:
            if self.findservice.IsProgressRunning():
                self.findservice.progress_dlg.setMaximum(
                    self.findservice.total_find_filecount)
            found_line, cur_pos = self.findtext_in_files(list_files, cur_pos)
            total_found_line += found_line
        self.findservice._is_searching_text = False
        # 结束进度条的标志
        self.findservice.update_progress(None, constants.PROGRESS_END)
        utils.get_logger().info('find %d results in %d files', total_found_line,
                                self.findservice.total_find_filecount)
        self.resultsview.SIG_END_FIND_RESULT.emit(
            _("Search completed,Find total %d results.") % total_found_line,
            self._findstr,
            total_found_line
        )


class FindInfiles(FindText):
    def __init__(self, findfiles, findstr, findreg, resultsview, findservice, find_results):
        super().__init__(findstr, findreg, resultsview, findservice)
        self._findfiles = findfiles
        # 初始化搜索结果数量
        self._find_results = find_results

    def run(self):
        self.findservice._is_searching_text = True
        self.findservice.total_find_filecount = len(self._findfiles)
        foundline, curpos = self.findtext_in_files(self._findfiles, 0)
        assert curpos <= self.findservice.total_find_filecount
        # 累加搜索结果数量
        self._find_results += foundline
        self.findservice.update_progress(None, constants.PROGRESS_END)
        self.findservice._is_searching_text = False
        self.findservice.finish_search_textfiles(
            self._findstr, self._find_results, self.resultsview, emitmsg=True)


class FindService:

    LINE_PREFIX = "Line "
    # 设置文件查找队列最大长度
    MAX_LIMIT_LIST_FILE_LENGTH = 1000

    def __init__(self):
        self.progress_dlg = None
        self._is_searching_text = False
        # 总的文件查找个数,用来设置进度条的最大值
        self.total_find_filecount = 0
        self._is_detect_encoding = utils.profile_get_int(
            globalkeys.INSPECT_FILEENCODING_KEY,
            True
        )

    def findin_dir(self, find_dir_option, findstr, findreg, results_view):
        # 3秒后才显示进度条对话框,如果在此时间内搜索文本操作已经完成,则不会显示进度条对话框
        self.ShowProgressDialog(_("Find Text In Directory"))
        FindIndir(find_dir_option, findstr, findreg,
                  results_view, self).start()

    @ui_utils.call_after_with_time(3000)
    def ShowProgressDialog(self, title):
        # 如果搜索文本操作已经完成,则不会显示进度条对话框
        if self._is_searching_text:
            self.progress_dlg = FindTextQProgressDialog(
                _("Please wait a minute for end find text"),
                _("Cancel"),
                0,
                self.total_find_filecount,
                get_app().MainFrame
            )
            self.progress_dlg.setWindowTitle(title)
            self.progress_dlg.exec_()

    def update_progress(self, curval, msg):
        if self.IsProgressStopped():
            return
        if not self.IsProgressRunning():
            return
        self.progress_dlg.update_progress_signal.emit(curval, msg)

    def IsProgressStopped(self):
        if self.progress_dlg is not None and self.progress_dlg.wasCanceled():
            return True
        return False

    def IsProgressRunning(self):
        if self.progress_dlg is not None and not self.progress_dlg.wasCanceled():
            return True
        return False

    def FindTextInFile(self, filename, findstr, findreg, view):
        '''
            在单个文件中查找文本
        '''
        found_line = 0
        docfile = None
        try:
            docfile = _open(filename, self._is_detect_encoding)
        except IOError as e:
            utils.get_logger().debug("Warning, unable to read file: '%s'.  %s", filename, str(e))
            return found_line
        needto_display_filename = True
        # 遍历列表序号从1开始
        for linenum, line in enumerate(docfile, 1):
            count, foundStart, foundEnd, newText = self.DoFind(
                findstr, None, line, 0, 0, True, findreg)
            if count != -1:
                if needto_display_filename:
                    view.emit_result_signal(FILENAME_MARKER + filename + "\n")
                    needto_display_filename = False
                line = self.LINE_PREFIX + str(linenum) + ":" + line
                # 限制一行文本的长度
                if len(line) > self.MAX_LIMIT_LIST_FILE_LENGTH:
                    line = line[0:self.MAX_LIMIT_LIST_FILE_LENGTH]
                view.emit_result_signal(line)
                found_line += 1
        if not needto_display_filename:
            view.emit_result_signal("\n")
        if docfile is not None:
            docfile.close()
        return found_line

    def DoFind(
        self,
        findstring,
        replacestring,
        text,
        startloc,
        endloc,
        down,
        reg,
        replace=False,
        replaceall=False,
        wrap=False
    ):
        """
            在一行文本中查找要找的文本
            Do the actual work of the find/replace.

            Returns the tuple (count, start, end, newText).
            count = number of string replacements
            start = start position of found string
            end = end position of found string
            newText = new replaced text
        """
        if replaceall:
            newtext, count = reg.subn(replacestring, text)
            if count == 0:
                return -1, None, None, None
            return count, None, None, newtext

        start = -1
        if down:
            match = reg.search(text, endloc)
            if match is None:
                if wrap:  # try again, but this time from top of file
                    match = reg.search(text, 0)
                    if match is None:
                        return -1, None, None, None
                else:
                    return -1, None, None, None
            start = match.start()
            end = match.end()
        else:
            match = reg.search(text)
            if match is None:
                return -1, None, None, None
            found = None
            i, j = match.span()
            while i < startloc and j <= startloc:
                found = match
                if i == j:
                    j = j + 1
                match = reg.search(text, j)
                if match is None:
                    break
                i, j = match.span()
            if found is None:
                if wrap:  # try again, but this time from bottom of file
                    match = reg.search(text, startloc)
                    if match is None:
                        return -1, None, None, None
                    found = None
                    i, j = match.span()
                    end = len(text)
                    while i < end and j <= end:
                        found = match
                        if i == j:
                            j = j + 1
                        match = reg.search(text, j)
                        if match is None:
                            break
                        i, j = match.span()
                    if found is None:
                        return -1, None, None, None
                else:
                    return -1, None, None, None
            start = found.start()
            end = found.end()
        if replace and start != -1:
            newtext, count = reg.subn(replacestring, text, 1)
            return count, start, end, newtext
        return 0, start, end, None

    def DoFindIn(self, findstring, findreg, result_view, curr_file_only=False):
        '''
            在当前文档中或所有项目文档中查找文本
        '''
        result_view.ClearLines()
        current_docview = get_app().MainFrame.GetNotebook().get_current_view()
        if current_docview:
            currdoc = current_docview.GetDocument()
        else:
            currdoc = None
        # 仅查找当前文件
        if curr_file_only:
            if currdoc:
                project_filenames = [currdoc.GetFilename()]
                result_view.add_head_text(
                    FILE_MARKER + currdoc.GetFilename() + "\n",
                    FindWhere.FIND_IN_FILE,
                    currdoc.GetFilename()
                )
            else:
                project_filenames = []
        else:
            # 查找当前项目的所有文件
            project_browser = get_app().MainFrame.projectview
            project_filenames = project_browser.GetFilesFromCurrentProject()
            projview = project_browser.GetView()
            if projview and projview.GetDocument():
                projname = fileutils.get_filename_from_path(
                    projview.GetDocument().GetFilename())
                result_view.add_head_text(
                    PROJECT_MARKER + projname + "\n\n",
                    FindWhere.FIND_IN_PROJECT,
                    projview.GetDocument().GetFilename()
                )
            else:
                return

        # 搜索结果包含编辑器打开文件的搜索结果和磁盘存储的项目文件的搜索结果之和
        found_line = 0
        # 先查找在编辑器中打开的文本,因为这些文本内容可能已经和实际存储的文件不一致了
        open_docs = get_app().GetDocumentManager().GetDocuments()
        # python3 filter不返回列表,返回filter对象,需要手动转换成list
        opendocs_in_project = list(
            filter(lambda opendoc: opendoc.GetFilename() in project_filenames, open_docs))
        if currdoc and currdoc in opendocs_in_project:
            # make sure current document is searched first.
            opendocs_in_project.remove(currdoc)
            opendocs_in_project.insert(0, currdoc)

        utils.get_logger().debug("start to search text for open project docs")
        for opendoc in opendocs_in_project:
            if isinstance(opendoc, ProjectDocument):  # don't search project model
                continue
            opendoc_view = opendoc.GetFirstView()
            # some views don't have a in memory text object to search through such as the PM and the DM
            # even if they do have a non-text searchable object, how do we display it in the message window?
            if not hasattr(opendoc_view, "GetValue"):
                continue
            line_count = opendoc_view.GetCtrl().lines()
            needto_display_filename = True
            for line_num in range(line_count):
                line_text = opendoc_view.GetCtrl().text(line_num)
                count, foundStart, foundEnd, newtext = self.DoFind(
                    findstring,
                    None,
                    line_text,
                    0,
                    0,
                    True,
                    findreg
                )
                if count != -1:
                    if needto_display_filename:
                        result_view.AddLine(
                            FILENAME_MARKER + opendoc.GetFilename())
                        needto_display_filename = False
                    line = self.LINE_PREFIX + \
                        str(line_num + 1) + ":" + line_text
                    result_view.AddLine(line)
                    found_line += 1
        utils.get_logger().debug("end to search text for open project docs")
        open_docnames = list(
            map(lambda opendoc: opendoc.GetFilename(), open_docs))
        # 再查找所有项目中未打开的文件,按照查找文件的方式查找文本
        filenames = filter(
            lambda filename: filename not in open_docnames, project_filenames)
        filenames = list(filenames)
        filecount = len(filenames)
        utils.get_logger().debug("start to search text for closed %d project docs", filecount)
        if filecount > 0:
            # 搜索磁盘上的项目文件时的初始化结果数量是编辑器打开文件的搜索结果
            FindInfiles(filenames, findstring, findreg,
                        result_view, self, found_line).start()
            return
        self.finish_search_textfiles(findstring, found_line, result_view)

    def finish_search_textfiles(self, findstr, found_line, result_view, emitmsg=False):
        utils.get_logger().debug("end to search text for closed project docs")
        end_msg = _("Search for '%s' completed, Find total %d results.") % (
            findstr, found_line)
        if emitmsg:
            result_view.SIG_END_FIND_RESULT.emit(end_msg, findstr, found_line)
        else:
            result_view.add_find_result(end_msg, findstr, found_line, )

    def FindInfile(self, findstr, findreg, result_view):
        '''
            在当前文件中查找
        '''
        self.DoFindIn(findstr, findreg, curr_file_only=True,
                      result_view=result_view)

    def FindInproject(self, findstr, findreg, result_view):
        '''
            在当前项目中查找
        '''
        self.ShowProgressDialog(_("Find text in project"))
        self.DoFindIn(findstr, findreg, result_view=result_view)


class FindIndirDialog(ui_utils.BaseModalDialog):

    def __init__(self, master, findString=''):
        super().__init__(_("Find in Directory"), master, Qt.Vertical)
        findui.init_find_option()
        init_finddir_option()
        self.setLocale(QLocale(QLocale.English, QLocale.UnitedKingdom))
        left_layout = QVBoxLayout()
        find_hbox = QHBoxLayout()

        self.find_indir_label = QLabel(_("Directory:"))
        find_hbox.addWidget(self.find_indir_label)

        # Find text field
        self.path_entry = QLineEdit()
        self.path_entry.setText(FIND_DIR_OPTION.path)
        find_hbox.addWidget(self.path_entry)

        self.browser_button = QPushButton(_("Browse..."))
        self.browser_button.clicked.connect(self.BrowsePath)
        find_hbox.addWidget(self.browser_button)
        left_layout.addLayout(find_hbox)

        option_hbox = QHBoxLayout()
        option_hbox.setAlignment(Qt.AlignLeft)
        self.search_child_checkbutton = QCheckBox(
            _("Search in subdirectories"))
        self.search_child_checkbutton.setChecked(FIND_DIR_OPTION.recursive)
        option_hbox.addWidget(self.search_child_checkbutton)

        self.search_hidden_checkbutton = QCheckBox(_("Search hidden files"))
        self.search_hidden_checkbutton.setChecked(FIND_DIR_OPTION.hiddendir)
        option_hbox.addWidget(self.search_hidden_checkbutton)
        left_layout.addLayout(option_hbox)

        sizer_sep = Separator()
        left_layout.addWidget(sizer_sep)

        path_hbox = QHBoxLayout()
        self.find_label = findui.FindtextLabel()
        path_hbox.addWidget(self.find_label)
        self.find_entry = findui.FindtextCombo(None, findString)
        path_hbox.addWidget(self.find_entry)
        self.find_entry.setMaximumWidth(200)
        self.find_entry.setMinimumWidth(100)
        self.find_entry.editTextChanged.connect(self._update_button_statuses)

        self.filetypes_label = QLabel(_("File types:"))
        path_hbox.addWidget(self.filetypes_label)

        self.filetypes_entry = QLineEdit()
        self.filetypes_entry.setText(
            os.pathsep.join(FIND_DIR_OPTION.filetypes))
        path_hbox.addWidget(self.filetypes_entry)

        self.filetypes_entry.setMaximumWidth(100)
        self.filetypes_entry.setMinimumWidth(50)
        self.filetypes_entry.setToolTip(
            _("Multiple file types seperated by semicolon"))

        left_layout.addLayout(path_hbox)

        bottom_grid_layout = QGridLayout()
        # Case checkbox
        self.case_checkbutton = QCheckBox(_("Case sensitive"))
        self.case_checkbutton.setChecked(findui.CURERNT_FIND_OPTION.match_case)
        bottom_grid_layout.addWidget(self.case_checkbutton, 0, 0)

        self.wholeword_checkbutton = QCheckBox(_("Match whole word"))
        self.wholeword_checkbutton.setChecked(
            findui.CURERNT_FIND_OPTION.match_whole_word)
        bottom_grid_layout.addWidget(self.wholeword_checkbutton, 1, 0)

        self.regular_checkbutton = QCheckBox(_("Regular expression"))
        self.regular_checkbutton.setChecked(findui.CURERNT_FIND_OPTION.regex)
        bottom_grid_layout.addWidget(self.regular_checkbutton, 2, 0)
        left_layout.addLayout(bottom_grid_layout)
        self.layout.addLayout(left_layout)

        self.create_standard_buttons()
        self.search_button = self.ok_button
        self.search_button.setText(_("Find"))
        self._update_button_statuses()

    def SaveConfig(self):
        """ Save find/replace patterns and search flags to registry. """
        utils.profile_set(findui.FIND_MATCHPATTERN,
                          findui.CURERNT_FIND_OPTION.findstr)
        utils.profile_set(findui.FIND_MATCHCASE,
                          findui.CURERNT_FIND_OPTION.match_case)
        utils.profile_set(findui.FIND_MATCHWHOLEWORD,
                          findui.CURERNT_FIND_OPTION.match_whole_word)
        utils.profile_set(findui.FIND_MATCHREGEXPR,
                          findui.CURERNT_FIND_OPTION.regex)
        utils.profile_set(FIND_MATCHDIR, FIND_DIR_OPTION.path)
        utils.profile_set(FIND_MATCHDIRSUBFOLDERS, FIND_DIR_OPTION.recursive)
        utils.profile_set(FIND_MATCHFILETYPES,
                          os.pathsep.join(FIND_DIR_OPTION.filetypes))
        self.find_entry.update_item(findui.CURERNT_FIND_OPTION.findstr)
        self.find_entry.save_match_patters()

    def BrowsePath(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog | QFileDialog.ShowDirsOnly
        path = QFileDialog.getExistingDirectory(
            self, _("Select directory"), self.path_entry.text(),
            options)
        if path:
            # 必须转换一下路径为系统标准路径格式
            self.path_entry.setText(fileutils.opj(path))

    @staticmethod
    def GetFileTypeList(file_type_str):
        if file_type_str in ["", "*.*", "*", '.*']:
            return []
        type_parts = file_type_str.split(";")
        return [part.replace("*.", ".") for part in type_parts]

    def _ok(self):
        findstr = self.find_entry.get_text()
        if findstr == "" or not self.search_button.isEnabled():
            return
        self.GetFindDirOption()
        findprog = FindInfileDialog.get_find_prog(self)
        if not findprog:
            return

        path = FIND_DIR_OPTION.path
        result_view = get_app().MainFrame.resultsview
        result_view.ClearLines()
        result_view.add_head_text(
            _("Searching for '%s' in '%s'\n\n") % (findstr, path),
            FindWhere.FIND_IN_DIR,
            path
        )
        findserivice = FindService()
        if os.path.isfile(path):
            found_line = findserivice.FindTextInFile(
                path, findui.CURERNT_FIND_OPTION.findstr, findprog, result_view)
            result_view.add_find_result(
                _("Search completed,Find total %d results.") % found_line,
                findui.CURERNT_FIND_OPTION.findstr,
                found_line
            )
        else:
            findserivice.findin_dir(
                FIND_DIR_OPTION, findui.CURERNT_FIND_OPTION.findstr, findprog, result_view)
        self.SaveConfig()
        super()._ok()

    def GetFindDirOption(self):
        global FIND_DIR_OPTION
        findui.CURERNT_FIND_OPTION.findstr = self.find_entry.get_text()
        findui.CURERNT_FIND_OPTION.match_case = self.case_checkbutton.isChecked()
        findui.CURERNT_FIND_OPTION.match_whole_word = self.wholeword_checkbutton.isChecked()
        findui.CURERNT_FIND_OPTION.regex = self.regular_checkbutton.isChecked()

        FIND_DIR_OPTION.path = os.path.abspath(self.path_entry.text())
        FIND_DIR_OPTION.recursive = self.search_child_checkbutton.isChecked()
        FIND_DIR_OPTION.hiddendir = self.search_hidden_checkbutton.isChecked()
        FIND_DIR_OPTION.filetypes = self.GetFileTypeList(
            self.filetypes_entry.text().strip())

    def _update_button_statuses(self):
        find_text = self.find_entry.get_text()
        if len(find_text) == 0:
            self.search_button.setEnabled(False)
        else:
            self.search_button.setEnabled(True)


class FindInfileDialog(ui_utils.BaseModalDialog):
    def __init__(self, master, findString=""):
        super().__init__("", master, Qt.Vertical)
        self.UpdateTitle()
        findui.init_find_option()

        left_layout = QVBoxLayout()
        # Find text label
        find_box_layout = QHBoxLayout()
        find_label = findui.FindtextLabel()
        find_box_layout.addWidget(find_label)
        # Find text field
        self.find_entry_combo = findui.FindtextCombo(None, findString)
        self.find_entry_combo.setMaximumWidth(400)
        self.find_entry_combo.setMinimumWidth(200)
        find_box_layout.addWidget(self.find_entry_combo, 1)
        left_layout.addLayout(find_box_layout)

        bottom_grid_layout = QGridLayout()
        # Case checkbox
        self.case_checkbutton = QCheckBox(_("Case sensitive"))
        self.case_checkbutton.setChecked(findui.CURERNT_FIND_OPTION.match_case)
        bottom_grid_layout.addWidget(self.case_checkbutton, 0, 0)

        self.wholeword_checkbutton = QCheckBox(_("Match whole word"))
        self.wholeword_checkbutton.setChecked(
            findui.CURERNT_FIND_OPTION.match_whole_word)
        bottom_grid_layout.addWidget(self.wholeword_checkbutton, 1, 0)

        self.regular_checkbutton = QCheckBox(_("Regular expression"))
        self.regular_checkbutton.setChecked(findui.CURERNT_FIND_OPTION.regex)
        bottom_grid_layout.addWidget(self.regular_checkbutton, 2, 0)

        left_layout.addLayout(bottom_grid_layout)
        self.layout.addLayout(left_layout)

        self.create_standard_buttons()
        self.find_button = self.ok_button
        self.find_button.setText(_("Find"))

        self.find_entry_combo.editTextChanged.connect(
            self._update_button_statuses)
        self._update_button_statuses()

    @staticmethod
    def get_find_prog(parent):
        findmixin = FindMixin()
        findmixin.SetOption(findui.CURERNT_FIND_OPTION)
        try:
            return findmixin.getprog()
        except re.error as what:
            msgtitle = _('Regular Expression')
            QMessageBox.critical(
                parent,
                msgtitle,
                _("Invalid regular expression:\"%s\"") % str(what),
            )
            return None

    def is_find_available(self):
        '''
            按回车键执行查找时检测按钮是否可用
        '''
        return self.find_button.isEnabled() and self.find_entry_combo.get_text() != ''

    def UpdateTitle(self):
        self.dlg_title = _("Find in File")
        self.setWindowTitle(self.dlg_title)

    def _ok(self):
        if not self.is_find_available():
            return
        self.GetFindTextOption()
        findprog = self.get_find_prog(self)
        if not findprog:
            return
        FindService().FindInfile(findui.CURERNT_FIND_OPTION.findstr,
                                 findprog, get_app().MainFrame.resultsview)
        self.SaveConfig()
        super()._ok()

    def GetFindTextOption(self):
        findui.CURERNT_FIND_OPTION.findstr = self.find_entry_combo.get_text()
        findui.CURERNT_FIND_OPTION.match_case = self.case_checkbutton.isChecked()
        findui.CURERNT_FIND_OPTION.match_whole_word = self.wholeword_checkbutton.isChecked()
        findui.CURERNT_FIND_OPTION.regex = self.regular_checkbutton.isChecked()

    def _update_button_statuses(self):
        find_text = self.find_entry_combo.get_text()
        if len(find_text) == 0:
            self.find_button.setEnabled(False)
        else:
            self.find_button.setEnabled(True)

    def closeEvent(self, event):
        """Called when the window is closed. responsible for handling all cleanup."""
        self.reject()

    def SaveConfig(self):
        """ Save find/replace patterns and search flags to registry. """
        utils.profile_set(findui.FIND_MATCHPATTERN,
                          findui.CURERNT_FIND_OPTION.findstr)
        utils.profile_set(findui.FIND_MATCHCASE,
                          findui.CURERNT_FIND_OPTION.match_case)
        utils.profile_set(findui.FIND_MATCHWHOLEWORD,
                          findui.CURERNT_FIND_OPTION.match_whole_word)
        utils.profile_set(findui.FIND_MATCHREGEXPR,
                          findui.CURERNT_FIND_OPTION.regex)
        self.find_entry_combo.update_item(findui.CURERNT_FIND_OPTION.findstr)
        self.find_entry_combo.save_match_patters()


class FindInprojectDialog(FindInfileDialog):

    def __init__(self, master, findstring):
        super().__init__(master, findstring)

    def UpdateTitle(self):
        self.dlg_title = _("Find in Project")
        self.setWindowTitle(self.dlg_title)

    def _ok(self):
        if not self.is_find_available():
            return
        self.GetFindTextOption()
        findprog = self.get_find_prog(self)
        if not findprog:
            return
        FindService().FindInproject(findui.CURERNT_FIND_OPTION.findstr,
                                    findprog, get_app().MainFrame.resultsview)
        self.SaveConfig()
        ui_utils.BaseModalDialog._ok(self)


def show_findindir_dialog(master, findstring):
    dlg = FindIndirDialog(master, findstring)
    if dlg.exec_() == QDialog.Accepted:
        get_app().MainFrame.activateSearchResultsTab()


def show_findinfile_dialog(editor):
    findstring = editor.selectedText()
    dlg = FindInfileDialog(editor, findstring)
    if dlg.exec_() == QDialog.Accepted:
        get_app().MainFrame.activateSearchResultsTab()


def show_findinproject_dialog(findstring, master):
    dlg = FindInprojectDialog(master, findstring)
    if dlg.exec_() == QDialog.Accepted:
        get_app().MainFrame.activateSearchResultsTab()
        get_app().MainFrame.activateProjectTab()


FIND_DIR_OPTION = None


def init_finddir_option():
    global FIND_DIR_OPTION
    if FIND_DIR_OPTION is None:
        FIND_DIR_OPTION = FindindirOpt('', True, False, [])
        FIND_DIR_OPTION.path = utils.profile_get(
            FIND_MATCHDIR, FIND_DIR_OPTION.path)
        default_extentsion = "." + SyntaxThemeManager.manager().GetLexer(
            get_app().GetDefaultLangId()
        ).GetDefaultExt()
        FIND_DIR_OPTION.filetypes = FindIndirDialog.GetFileTypeList(
            utils.profile_get(FIND_MATCHFILETYPES, default_extentsion))
        FIND_DIR_OPTION.recursive = utils.profile_get_int(
            FIND_MATCHDIRSUBFOLDERS, FIND_DIR_OPTION.recursive)
