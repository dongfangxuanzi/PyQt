import json
import time
from novalapp.util import utils
from novalapp.util import fileutils
from .message import Message


class SarifLoader:
    """description of class"""

    MAX_TRY_TIMES = 5

    def __init__(self, filepath, toolname):
        self.message_file_path = filepath
        self.tool = toolname

    @staticmethod
    def uri_to_path(uri):
        filepath = uri.replace('file:///', '', 1)
        path = fileutils.opj(filepath)
        return path

    def loadfile(self):
        return self.__load()

    def get_results(self):
        data = self.loadfile()
        if not data:
            return []
        runs = data['runs']
        run_data = runs[0]
        tool_data = run_data['tool']
        utils.get_logger().debug('sarif tool name is %s',
                                 tool_data['driver']['name'])
        results = run_data['results']
        return results

    def load(self):
        messages = []
        results = self.get_results()
        for result in results:
            rule_id = result['ruleId']
            message = result['message']['text']
            location = result['locations'][0]['physicalLocation']
            line = location['region']['startLine']
            col = location['region']['startColumn']
            uri = location['artifactLocation']['uri']
            # fixme url路径有中文时会出现解析乱码,需要将url路径解码
            path = self.uri_to_path(uri)
            fixes = result.get('fixes', [])
            msg = Message(line, col, rule_id, path, message, self.tool, fixes)
            messages.append(msg)
        return messages

    def __load(self):
        '''
            解析sarfi输出的json格式的信息文件,有可能第一次会解析失败,需要多重试几次直到成功
        '''
        for i in range(self.MAX_TRY_TIMES):
            try:
                with open(self.message_file_path) as f:
                    data = json.load(f)
                    return data
            except Exception as ex:
                utils.get_logger().error(
                    "tool %s load json message file %s error:%s in %d times,wait 1s try again",
                    self.tool,
                    self.message_file_path,
                    str(ex),
                    i + 1
                )
                utils.get_logger().exception(
                    'load sarif json message file %s exception:',
                    self.message_file_path
                )
                time.sleep(1)
        raise RuntimeError('load json message file %s error' %
                           self.message_file_path)
