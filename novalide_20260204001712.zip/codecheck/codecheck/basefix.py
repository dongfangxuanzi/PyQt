import abc
from novalapp import get_app
from novalapp.util import utils, strutils
from novalapp.python.parser.node_scope import ScopeFinder
from .configkeys import TOOL_RULES_AUTOFIX_KEY
from .exceptions import FixfileError


class BaseFixer(abc.ABC):
    """description of class"""

    def __init__(self, ruleid, toolname, autofix=False, open_file=True):
        self._ruleid = ruleid
        self._toolname = toolname
        autofix_key = TOOL_RULES_AUTOFIX_KEY % (toolname, ruleid)
        self._autofix = bool(utils.profile_get_int(autofix_key, autofix))
        self._openfile = open_file
        # 是否行号减1
        self._reduce_line = True
        self.fix_tool = None
        self.is_autofix_msg = False

    @property
    def reduce_line(self):
        return self._reduce_line

    @property
    def ruleid(self):
        return self._ruleid

    @property
    def toolname(self):
        return self._toolname

    @property
    def openfile(self):
        return self._openfile

    @openfile.setter
    def openfile(self, isopen):
        self._openfile = isopen

    @property
    def autofix(self):
        return self._autofix

    @autofix.setter
    def autofix(self, value):
        self._autofix = value

    def open_doc_file(self, doc, msg, is_auto_fix=False):
        if self._openfile:
            filepath = msg.filepath
            if is_auto_fix:
                filedoc = get_app().GetDocumentManager().GetDocument(filepath)
                if filedoc is None:
                    fileview = get_app().GotoView(
                        filepath,
                        lineNum=msg.line,
                        colno=msg.column,
                        load_outline=False,
                        trace_track=False
                    )
                else:
                    fileview = filedoc.GetFirstView()
                    filedoc.OnOpenDocument(filepath)
            else:
                fileview = get_app().GotoView(
                    filepath,
                    lineNum=msg.line,
                    colno=msg.column,
                    load_outline=False,
                    trace_track=False
                )
            if fileview is None:
                return None, None
            textctrl = fileview.GetCtrl()
            return fileview, textctrl
        return None, None

    @abc.abstractmethod
    def fix_message(self, doc, msg, **kwargs):
        raise NotImplementedError('You must implemented it in derived class')

    def auto_fix_msg(self, doc, msg):
        textview = self.open_doc_file(doc, msg, is_auto_fix=True)[0]
        if not self.autofix:
            utils.get_logger().warning(
                "rule %s in tool %s could not autofix code message", msg.ruleid, self.toolname)
            return
        if textview is None:
            utils.get_logger().error("open document file %s error", msg.filepath)
            return
        self.is_autofix_msg = True
        result: bool = self.fix_message(doc, msg)
        utils.get_logger().info(
            'fix msgid:%s of tool %s in filename %s,result:%s',
            msg.ruleid,
            msg.toolname,
            msg.filepath,
            strutils.bool_to_str(result)
        )
        assert isinstance(result, bool)
        textdoc = textview.GetDocument()
        textdoc.Save()
        self.is_autofix_msg = False
        # 告警修复成功,表示文件内容有变动, 需要重新解析并加载语法树
        if result:
            # 重新解析并加载语法树
            utils.get_logger().info(
                "file %s parse and reload ast tree again",
                msg.filepath
            )
            textview.ModuleAnalyzer.parse_module(msg.filepath)
            if textview.ModuleAnalyzer.Module is None:
                utils.get_logger().error(
                    "fix message file %s may occur syntax eror:%s on rule %s of tool %s",
                    msg.filepath,
                    textview.ModuleAnalyzer.SyntaxError,
                    msg.ruleid,
                    msg.toolname
                )
                raise FixfileError(f"Fix file {msg.filepath} Error:{textview.ModuleAnalyzer.SyntaxError}")


def fix_code_file_msg(func):
    def wrapper(self, *args):
        textview, textctrl = self.open_doc_file(*args)
        if textview is None:
            utils.get_logger().error(
                "open document file %s error", args[1].filepath)
            return False
        return func(self, *args, **{'textview': textview, 'textctrl': textctrl})
    return wrapper


class BasePythonFixer(BaseFixer):
    ''''''

    def load_module(self, textview, filepath):
        if textview.ModuleAnalyzer.Module is None:
            textview.ModuleAnalyzer.parse_module(filepath)
            assert textview.ModuleAnalyzer.Module is not None

    def find_msg_node(self, textview, msg, use_column=False):
        self.load_module(textview, msg.filepath)
        line = msg.line
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        if use_column:
            node = textview.ModuleAnalyzer.find_line_col_node(line, msg.column, scope)
        else:
            node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if node is None and scope.lineno == line:
            return scope
        return node
