from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ..pylint_fix import PylintCommonFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintC0121Fixer(PylintCommonFixer):
    '''
    规则说明: 使用is和None比较,而不是使用==
    '''

    def __init__(self):
        # 支持自动修复
        super().__init__('C0121', True)

    @staticmethod
    def fix_compare_node(node, textview):
        ops = node.ops
        if ops and ops[0][0] in ['==', '!='] and (
            isinstance(ops[0][1], nodes.Const) and ops[0][1].value is None
        ):
            fix_range = get_node_range(node)
            if ops[0][0] == "==":
                fixtext = f"{node.left.as_string()} is None"
            else:
                fixtext = f"{node.left.as_string()} is not None"
            fix_range.replace_with_text(textview, fixtext)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
        line = msg.line
        scope = ScopeFinder(
            textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if isinstance(node, nodes.Compare):
            # 先使用通用sarif格式修复,如果不能修复则使用自定义方法修复
            if super().fix_message(doc, msg):
                return True
            self.fix_compare_node(node, textview)
            return True
        if isinstance(node, nodes.Assert) and isinstance(node.test, nodes.Compare):
            # 先使用通用sarif格式修复,如果不能修复则使用自定义方法修复
            if super().fix_message(doc, msg):
                return True
            self.fix_compare_node(node.test, textview)
            return True
        return False
