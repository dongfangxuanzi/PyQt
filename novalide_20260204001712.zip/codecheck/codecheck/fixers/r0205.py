import re
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import FixRange


class PylintR0205Fixer(PylintFixer):
    '''
    规则说明:类显式继承object多余
    '''

    def __init__(self):
        super().__init__('R0205', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        line = msg.line
        self.load_module(textview, msg.filepath)
        line_text = text_ctrl.get_line_text(line)
        regstr = r'\(\s*object\s*\)'
        if re.search(regstr, line_text):
            fix_range = FixRange(line + 1)
            replace_text = re.sub(regstr, '', line_text)
            fix_range.replace_line(textview, replace_text)
            return True
        return False
