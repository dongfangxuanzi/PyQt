import os
from astroid import nodes
from novalapp import constants, _
from novalapp.lib.pyqt import QMessageBox
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import ImportVisitor, get_add_range, FixNode


class PylintW0123Fixer(PylintFixer):
    '''
    规则说明:使用eval
    '''

    def __init__(self):
        super().__init__('W0123', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg, use_column=True)
        if isinstance(node.parent, nodes.Call) and (
            isinstance(node, nodes.Name) and node.name == "eval"
        ):
            QMessageBox.warning(
                textview.GetFrame(),
                _('Warning'),
                _('Please ensure the string only contains double quote `"`, otherwise please use json.dumps to format the str')
            )
            fix_func_node = FixNode(node, textview)
            fix_func_node.replace_node_with_text('json.loads')
            visitor = ImportVisitor(
                textview.ModuleAnalyzer.Module, textview)
            if isinstance(node.parent.parent, nodes.Assign):
                assign_node = node.parent.parent
                add_range = get_add_range(node.lineno + 1, 0)
                target_name = assign_node.targets[0].as_string()
                last_line_chars = text_ctrl.get_line(node.lineno - 1, last_append_linend=False)
                if last_line_chars.endswith((constants.CR, constants.LF, constants.CRLF)):
                    add_char = ''
                else:
                    add_char = os.linesep
                replacestr = f"assert(isinstance({target_name}, (list, dict)))"
                add_range.add_text(
                    textview,
                    add_char + assign_node.col_offset * ' ' + replacestr + os.linesep
                )
            if not visitor.is_import_exist('json'):
                insert_line = visitor.get_import_line()
                add_range = get_add_range(insert_line + 1, 0)
                add_range.add_text(textview, "import json" + os.linesep)
            return True
        return False
