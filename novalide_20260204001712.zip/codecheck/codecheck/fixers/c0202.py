from ..pylint_fix import PylintCommonFixer


class PylintC0202Fixer(PylintCommonFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('C0202', False)
