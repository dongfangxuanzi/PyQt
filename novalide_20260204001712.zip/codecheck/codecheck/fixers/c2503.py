from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg


class PylintC2503Fixer(PylintFixer):
    '''
    规则说明:编码不是utf8编码
    '''

    def __init__(self):
        super().__init__('C2503', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textview.insert_declare_encoding(prompt=False)
        return True
