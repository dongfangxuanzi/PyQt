import re
from astroid import nodes
from ..basefix import fix_code_file_msg
from ..pylint_fix import PylintFixer
from .c0411 import PylintC0411Fixer


class PylintC0413Fixer(PylintFixer):
    '''
    规则说明:导入语句必须位于文件顶部
    '''

    def __init__(self):
        super().__init__('C0413', False)
        self._reduce_line = False

    @staticmethod
    def get_first_nonimport_node(import_node):
        module = import_node.parent
        for childnode in module.body:
            if not isinstance(childnode, (nodes.Import, nodes.ImportFrom)):
                return childnode
            if childnode == import_node:
                break
        return None

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg)
        res = re.search(
            r'Import "(.*)" should be placed at the top of the module \(wrong-import-position\)',
            msg.msg
        )
        if not isinstance(node, (nodes.Import, nodes.ImportFrom)) or not res:
            return False
        if res.groups()[0] == node.as_string():
            nonimport_node = self.get_first_nonimport_node(node)
            return PylintC0411Fixer.fix_nodes_position(
                textview,
                nonimport_node,
                node,
                PylintC0411Fixer.FIX_CHOICES,
                text_ctrl
            )
        return False
