from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range, DEFAULT_TAB_BLANKS


class PylintR1735Fixer(PylintFixer):
    '''
    规则说明: 赋值空字典不要使用dict(),应使用{}
    '''

    def __init__(self):
        super().__init__('R1735', True)
        self._reduce_line = False

    @staticmethod
    def _dict_literal_suggestion(node: nodes.Call) -> str:
        """Return a suggestion of reasonable length."""
        elements: list[str] = []
        for keyword in node.keywords:
            if keyword not in node.kwargs:
                elements.append(
                    f'"{keyword.arg}": {keyword.value.as_string()}')
        for keyword in node.kwargs:
            if len(", ".join(elements)) >= 64:
                break
            elements.append(f"**{keyword.value.as_string()}")
        suggestion = ", ".join(elements)
        return suggestion

    @staticmethod
    def _get_dict_literal_fixes(node: nodes.Call) -> str:
        """Return a suggestion of reasonable length."""
        target = node.parent.targets[0]
        blanks = DEFAULT_TAB_BLANKS + target.col_offset * ' '
        elements: list[str] = ["{"]
        for keyword in node.keywords:
            if keyword not in node.kwargs:
                elements.append(
                    blanks + f'"{keyword.arg}": {keyword.value.as_string()},')
        elements[-1] = elements[-1].rstrip(',')
        elements.append(target.col_offset * ' ' + "}")
        suggestion = "\n".join(elements)
        return suggestion

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if not node:
            return False
        if isinstance(node, nodes.Assign):
            fix_range = get_node_range(node.value)
            if node.value.as_string() == "dict()":
                nodestr = '{}'
                fix_range.replace_with_text(textview, nodestr)
                return True
            if isinstance(node.value, nodes.Call) and (
                isinstance(node.value.func,
                           nodes.Name) and node.value.func.name == "dict"
            ):
                fixstr = "{%s}" % self._dict_literal_suggestion(node.value)
                if len(fixstr) > 80:
                    fixstr = self._get_dict_literal_fixes(node.value)
                fix_range.replace_with_text(textview, fixstr)
                return True
        return False
