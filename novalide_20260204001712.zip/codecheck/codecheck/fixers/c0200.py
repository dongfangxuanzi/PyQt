from ..pylint_fix import PylintCommonFixer


class PylintC0200Fixer(PylintCommonFixer):
    '''
    规则说明:不用使用range,使用for xx in enumerate代替
    '''

    def __init__(self):
        super().__init__('C0200', False)
