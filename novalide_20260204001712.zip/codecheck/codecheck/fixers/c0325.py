import re
from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range, FixRange


class PylintC0325Fixer(PylintFixer):
    '''
    规则说明: assert/if表达式无需用括号包裹起来
    '''

    def __init__(self):
        super().__init__('C0325', True)
        self._reduce_line = False

    @staticmethod
    def cannot_fix(node):
        symbols = ['&', '|']
        nodestr = node.as_string()
        for char in symbols:
            if char in nodestr:
                return True
        return False

    @staticmethod
    def get_msg_keyword(msg):
        res = re.search(r"Unnecessary parens after '(\w+)' keyword", msg.msg)
        if not res:
            return None
        keyword_name = res.groups()[0]
        return keyword_name

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        line = msg.line
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if not node:
            return False
        keyword_name = self.get_msg_keyword(msg)
        if isinstance(node, nodes.Assert) or (
            isinstance(node, nodes.UnaryOp) and keyword_name == "not"
        ):
            if self.cannot_fix(node):
                return False
            fix_range = get_node_range(node)
            nodestr = node.as_string()
            fix_range.replace_with_text(textview, nodestr)
            return True
        if isinstance(node.parent, (nodes.If, nodes.While)):
            pnode = node.parent
            if self.cannot_fix(pnode):
                return False
            linestr = text_ctrl.get_line_text(line - 1)
            result = re.search(r'\(.*\)', linestr)
            if not result:
                return False
            start, end = result.span()
            if start >= pnode.test.col_offset:
                return False
            fix_range = FixRange(
                pnode.lineno,
                pnode.col_offset,
                pnode.test.lineno,
                end
            )
            teststr = pnode.test.as_string()
            is_ifnode = isinstance(node.parent, nodes.If)
            if is_ifnode:
                if keyword_name not in ['if', 'elif']:
                    return False
                nodestr = f"{keyword_name} {teststr}"
            else:
                nodestr = f"while {teststr}"
            fix_range.replace_with_text(textview, nodestr)
            return True
        if isinstance(node, nodes.Return):
            fix_range = get_node_range(node)
            nodestr = node.as_string()
            fix_range.replace_with_text(textview, nodestr)
            return True
        return False
