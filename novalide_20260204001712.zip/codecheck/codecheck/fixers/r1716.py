from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintR1716Fixer(PylintFixer):
    '''
    规则说明: 使用1个连等比较表达式代替2个比较表达式
    '''

    def __init__(self):
        super().__init__('R1716', True)
        self._reduce_line = False

    @staticmethod
    def fix_boolop_node(node, textview):

        left_compare, right_compare = node.values
        fix_range = get_node_range(node)
        left_compare_ops = left_compare.ops[0]

        chain_compare_str = left_compare_ops[1].as_string()
        chain_compare_str += left_compare_ops[0].replace('>', '<')
        chain_compare_str += left_compare.left.as_string()
        assert (left_compare.left.as_string() ==
                right_compare.left.as_string())
        right_compare_ops = right_compare.ops[0]
        chain_compare_str += right_compare_ops[0]
        chain_compare_str += right_compare_ops[1].as_string()
        fix_range.replace_with_text(textview, chain_compare_str)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if not node:
            return False
        if isinstance(node.parent, nodes.If) and (
            isinstance(node, nodes.BoolOp) and node.op == "and"
        ):
            self.fix_boolop_node(node, textview)
            return True
        if isinstance(node, nodes.Assert) and (
            isinstance(node.test, nodes.BoolOp) and node.test.op == "and"
        ):
            self.fix_boolop_node(node.test, textview)
            return True

        return False
