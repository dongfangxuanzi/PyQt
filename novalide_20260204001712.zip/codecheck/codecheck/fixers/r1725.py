import re
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import FixRange


class PylintR1725Fixer(PylintFixer):
    '''
    规则说明:使用super关键字来调用父类构造函数
    '''

    def __init__(self):
        super().__init__('R1725', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        line = msg.line
        self.load_module(textview, msg.filepath)
        line_text = text_ctrl.get_line_text(line)
        regstr = r'super\s*\(.*\)\.'
        if re.search(regstr, line_text):
            fix_range = FixRange(line + 1)
            replace_text = re.sub(regstr, "super().", line_text)
            fix_range.replace_line(textview, replace_text)
            return True
        return False
