import re
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintC0410Fixer(PylintFixer):
    '''
    规则说明: 一行导入多个模块
    '''

    def __init__(self):
        super().__init__('C0410', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(msg.line)
        if isinstance(node, nodes.Import):
            res = re.search(
                r'Multiple imports on one line \((.*)\) \(multiple-imports\)', msg.msg)
            if not res:
                return False
            matched_names = [name.strip()
                             for name in res.groups()[0].strip().split(',')]
            names = [name[0] for name in node.names]
            if len(names) >= 2 and matched_names == names:
                fix_range = get_node_range(node)
                imports = []
                for name in names:
                    imports.append("import %s" % name)
                fix_range.replace_with_text(textview, '\n'.join(imports))
                return True
        return False
