import re
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintR0402Fixer(PylintFixer):
    '''
    规则说明:使用from import语句代替import as语句
    '''

    def __init__(self):
        super().__init__('R0402', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.Import):
            res = re.search(
                r"Use '(.*)' instead \(consider-using-from-import\)", msg.msg)
            if res is not None:
                fixstr = res.groups()[0]
                module_name, import_name = re.search(
                    r"from (.*) import (\w+)", fixstr).groups()
                full_import_name = "%s.%s" % (module_name, import_name)
                if full_import_name == node.names[0][0]:
                    fix_range = get_node_range(node)
                    fix_range.replace_with_text(textview, fixstr)
                    return True
        return False
