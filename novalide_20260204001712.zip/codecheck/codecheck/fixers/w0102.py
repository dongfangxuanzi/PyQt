import os
from astroid import nodes
from novalapp.python.parser.node_utils import get_builtin_type
from ..codeutils import ImportVisitor, get_add_range, FixNode
from ..basefix import fix_code_file_msg
from ..pylint_fix import PylintCommonFixer


class PylintW0102Fixer(PylintCommonFixer):
    '''
    规则说明:参数默认值不能使用字典列表作为默认值
    '''

    def __init__(self):
        super().__init__('W0102', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        if super().fix_message(doc, msg):
            return True
        node = self.find_msg_node(textview, msg)
        print(msg.line, node, "==============================")
        if isinstance(node, nodes.FunctionDef):
            return self.fix_dangerous_default_value(node, textview)
        if isinstance(node, nodes.AssignName) and (
            isinstance(node.parent, nodes.Arguments) and isinstance(node.parent.parent, nodes.FunctionDef)
        ):
            return self.fix_dangerous_default_value(node.parent.parent, textview)
        return False

    def fix_dangerous_default_value(self, node, textview):
        print(node.args)
        for arg in node.args.args:
            print(arg, "_++++++++++++++++++++++++++")
        danger_index = -1
        default_args = node.args.defaults or node.args.kw_defaults
        defaults_num = len(default_args)
        for i, default_val in enumerate(default_args):
            print(default_val, "-----------------------")
            if isinstance(default_val, (nodes.List, nodes.Dict)):
                danger_index = (i - defaults_num)
                break
        if node.args.defaults:
            default_arg = node.args.args[danger_index]
        elif node.args.kw_defaults:
            default_arg = node.args.kwonlyargs[danger_index]
        default_val = default_args[danger_index]
        print(danger_index, default_arg, default_val)

        fixvalue = FixNode(default_val, textview)
        fixvalue.replace_node_with_text("None")

        fixarg = FixNode(default_arg, textview)
        optional_name = 'Optional'
        builtin_type_name = get_builtin_type(default_val)
        reptext = default_arg.name + f": {optional_name}[{builtin_type_name}]"
        fixarg.replace_node_with_text(reptext)

        first_body = node.body[0]
        insert_line = first_body.lineno
        blanks = first_body.col_offset * ' '
        add_range = get_add_range(insert_line, 0)
        add_range.add_text(
            textview,
            blanks + f"{default_arg.name}={default_arg.name} or {default_val.elts}" + os.linesep
        )

        visitor = ImportVisitor(
            textview.ModuleAnalyzer.Module, textview)
        if not visitor.is_fromimport_exist('typing', optional_name):
            insert_line = visitor.get_import_line()
            add_range = get_add_range(insert_line + 1, 0)
            add_range.add_text(textview, f"from typing import {optional_name}" + os.linesep)
        return True
