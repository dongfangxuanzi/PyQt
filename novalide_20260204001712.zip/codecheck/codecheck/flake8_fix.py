import logging
from novalapp import get_app
from novalapp.editor.textview import TextView
from novalapp.executable import Executable
from novalapp.lib.pyqt import QMessageBox
from .basefix import BasePythonFixer
from .strings import FLAKE8_TOOL_NAME, FIX_PROCESSER_NAME, AUTOPEP8_TOOL_NAME
from .basefix import fix_code_file_msg

log = logging.getLogger(__name__)


class Flake8Fixer(BasePythonFixer):
    '''
    格式类告警修复,可支持批量修复几十条格式告警规则
    '''

    def __init__(self, fixtool, open_file=True):
        super().__init__('', FLAKE8_TOOL_NAME, True, open_file)
        self.fix_tool = fixtool
        # 默认可自动修复格式规则列表
        # E402规则会调整导入语句中类似sys.path.append这类有效语句的顺序,从而导致运行异常
        # 如果文件中有类似的导入语句需要禁止使用规则E402的自动修复功能
        self._fix_rules = [
            'E111',
            'E114',
            'E115',
            'E116',
            'E121',
            'E122',
            'E123',
            'E124',
            'E125',
            'E126',
            'E127',
            'E128',
            'E129',
            'E201',
            'E202',
            'E203',
            'E211',
            'E221',
            'E222',
            'E223',
            'E224',
            'E225',
            'E231',
            'E251',
            'E252',
            'E261',
            'E262',
            'E271',
            'E272',
            'E273',
            'E274',
            'E275',
            'E301',
            'E302',
            'E303',
            'E304',
            'E305',
            'E306',
            'E401',
            'E402',
            'E502',
            'E701',
            'E702',
            'E703',
            'E704',
            'E711',
            'E712',
            'E713',
            'E714',
            'E722',
            'E731',
            'W291',
            'W503',
            'W504'
        ]

    @property
    def fix_rules(self):
        return self._fix_rules

    def update_fix_rules(self):
        exec_tool = Executable(self.fix_tool.interpreter.path)
        # 通过命令行获取最新的修复规则列表,以便代替默认列表
        exitcode, output = exec_tool.exec_command_exit_output(
            ["-m", AUTOPEP8_TOOL_NAME, "--list-fixes"])
        if exitcode != 0:
            log.error('%s', output)
            return
        output_lines = output.splitlines()
        rules_list = []
        for output_line in output_lines:
            output_line = output_line.strip()
            strs = output_line.split()
            ruleid = strs[0]
            rules_list.append(ruleid)
        log.debug(
            "default fix rule ids count is %d, update fixer list count is %d",
            len(self._fix_rules),
            len(rules_list)
        )
        if rules_list:
            # 代替默认修复规则列表
            self._fix_rules = rules_list

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        TextView.FILE_MODIFY_ANSWER = QMessageBox.YesToAll
        get_app().MainFrame.reset_filechanged_answer = False
        fix_processor = get_app().MainFrame.projectview.get_processor(FIX_PROCESSER_NAME)
        textview = kwargs.get('textview')
        filedoc = textview.GetDocument()
        if msg is not None:
            filepath = msg.filepath
        else:
            filepath = filedoc.GetFilename()
        self.fix_tool.fix_file(fix_processor, doc, filepath)
        filedoc.reload()
        get_app().MainFrame.reset_filechanged_answer = True
        return True

    def fix_code_file(self, doc, filepath, textview=None):
        TextView.FILE_MODIFY_ANSWER = QMessageBox.YesToAll
        get_app().MainFrame.reset_filechanged_answer = False
        fix_processor = get_app().MainFrame.projectview.get_processor(FIX_PROCESSER_NAME)
        self.fix_tool.fix_file(fix_processor, doc, filepath)
        if textview is not None:
            filedoc = textview.GetDocument()
            filedoc.reload()
        get_app().MainFrame.reset_filechanged_answer = True
        return True
