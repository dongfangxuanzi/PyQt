import abc
from typing import NamedTuple
from novalapp.util import ui_utils, utils
from novalapp import _
from novalapp.lib.pyqt import (
    QTableWidget,
    QAbstractItemView,
    QLineEdit,
    QThread,
    pyqtSignal,
    QHBoxLayout,
    Qt,
    QPushButton,
    QSizePolicy,
    QToolButton
)
from ..toolmanager import CodecheckToolManager
from .. import configkeys
from ..pkgres import load_res_file


class MessageCounter(NamedTuple):
    total_num: int
    fix_num: int
    autofix_num: int


class RulesSearcher(QThread):
    """description of class"""

    def __init__(self, parent, res_file, toolname, name=None):
        super().__init__(parent)
        self._parent = parent
        self._res_file = res_file
        self._name = name
        self._toolname = toolname

    @staticmethod
    def is_rule_enabled(toolrules, ruleid):
        # toolrules是列表类型,如果值为None,表示启用所有规则
        if toolrules is None:
            return True
        return ruleid in toolrules

    def load_data(self):
        if not self._parent.datas:
            self._parent.datas = load_res_file(self._res_file)
        # 工具初始化默认启用所有规则,为None既表示启用所有规则
        toolrules = utils.profile_get(
            configkeys.TOOL_RULES_KEY % self._toolname, None)
        return toolrules


class ToolRulesLoader:

    def load_message_counter(self):
        datas = self._parent.datas
        total_num = len(datas)
        fix_num = 0
        autofix_num = 0
        for data in datas:
            ruleid = self.get_ruleid(data)
            fix, autofix = self._parent.find_fixer(ruleid)
            if fix:
                fix_num += 1
            if autofix:
                autofix_num += 1
        self._parent.SIG_LOAD_MESSAGE_COUNTER.emit(
            MessageCounter(total_num, fix_num, autofix_num)
        )

    @abc.abstractclassmethod
    def get_ruleid(self, data):
        pass


class CommonPythonOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    """
    SIG_CLEAR_RULES_MSG = pyqtSignal()
    SIG_LOAD_MESSAGE_COUNTER = pyqtSignal(MessageCounter)

    def __init__(self, parent, columns, toolname):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)

        self.datas = []
        self.rules_file_path = None
        search_hbox = QHBoxLayout()
        self.search_rules_ctrl = QLineEdit()
        self.search_rules_ctrl.returnPressed.connect(self.search_rules)
        search_hbox.addWidget(self.search_rules_ctrl)
        self.seach_ruls_btn = QPushButton(_("Search"))
        search_hbox.addWidget(self.seach_ruls_btn)
        self.seach_ruls_btn.clicked.connect(self.search_rules)
        self.layout.addLayout(search_hbox)

        button_hbox = QHBoxLayout()
        button_hbox.setAlignment(Qt.AlignLeft)
        self.select_all_btn = QPushButton(_("Select all"))
        self.select_all_btn.clicked.connect(self.select_all)
        self.select_all_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        button_hbox.addWidget(self.select_all_btn)

        self.unselect_all_btn = QPushButton(_("UnSelect all"))
        self.unselect_all_btn.clicked.connect(self.unselect_all)
        self.unselect_all_btn.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed)
        button_hbox.addWidget(self.unselect_all_btn)

        self.enabled_button = self.create_tool_button(
            _("Enabled"), button_hbox)
        self.enabled_button.toggled.connect(self.show_enable_rules)

        self.not_enabled_button = self.create_tool_button(
            _("Not enabled"), button_hbox)
        self.not_enabled_button.toggled.connect(self.show_not_enable_rules)

        self.create_fix_buttons(button_hbox)
        self.layout.addLayout(button_hbox)
        self.table = QTableWidget(0, len(columns), self)
        self.layout.addWidget(self.table)
        self.init_table()

        self.table.setHorizontalHeaderLabels(columns)
        # 最后一列自动伸缩扩展
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().hide()
        self.fix_tool = CodecheckToolManager.manager().find_tool(toolname)
        if self.fix_tool is None:
            utils.get_logger().error('could not find fix tool %s', toolname)
            return
        self.SIG_CLEAR_RULES_MSG.connect(self.clear_rules)
        self.SIG_LOAD_MESSAGE_COUNTER.connect(self.load_message_counter)
        self.get_resfile_path()
        self.load_rules()

    @abc.abstractmethod
    def init_table(self):
        pass

    @abc.abstractmethod
    def load_rules(self):
        pass

    def load_message_counter(self, message_counter: MessageCounter):
        self.select_all_btn.setText(
            _("Select all") + "(%d)" % message_counter.total_num)
        self.enable_autofix_button.setText(
            _("Autofix") + "(%d)" % message_counter.autofix_num)

    def create_fix_buttons(self, button_hbox):
        self.enable_autofix_button = self.create_tool_button(
            _("Autofix"), button_hbox)
        self.enable_autofix_button.toggled.connect(self.show_autofix_rules)

    def create_tool_button(self, label, hbox):
        toolbutton = QToolButton()
        toolbutton.setText(label)
        toolbutton.setToolButtonStyle(Qt.ToolButtonTextOnly)
        toolbutton.setAutoRaise(True)
        toolbutton.setCheckable(True)
        toolbutton.setChecked(False)
        hbox.addWidget(toolbutton)
        return toolbutton

    def select_all(self):
        for row in range(self.table.rowCount()):
            chkbox = self.table.cellWidget(row, 0)
            if not chkbox.isChecked():
                chkbox.setChecked(True)

    def unselect_all(self):
        for row in range(self.table.rowCount()):
            chkbox = self.table.cellWidget(row, 0)
            if chkbox.isChecked():
                chkbox.setChecked(False)

    def find_fixer(self, ruleid):
        fixer = self.fix_tool.find_fixer(ruleid)
        if fixer is None:
            return False, False
        return True, fixer.autofix

    def clear_rules(self):
        # 清空表格所有内容
        self.table.clearContents()
        while self.table.rowCount():
            self.table.removeRow(0)

    def OnCancel(self, optionsDialog):
        self.datas.clear()
        return True

    def get_selected_rules(self):
        rule_names = []
        for row in range(self.table.rowCount()):
            chkbox = self.table.cellWidget(row, 0)
            if chkbox.isChecked():
                item = self.table.item(row, 1)
                rule_names.append(item.text())
        return rule_names

    def show_enable_rules(self):
        if self.enabled_button.isChecked():
            self.not_enabled_button.setChecked(False)
            self.enable_autofix_button.setChecked(False)

    def show_not_enable_rules(self):
        if self.not_enabled_button.isChecked():
            self.enabled_button.setChecked(False)
            self.enable_autofix_button.setChecked(False)

    def show_autofix_rules(self):
        if self.enable_autofix_button.isChecked():
            self.enabled_button.setChecked(False)
            self.not_enabled_button.setChecked(False)

    def OnOK(self, optionsDialog):
        select_rules = self.get_selected_rules()
        utils.profile_set(configkeys.TOOL_RULES_KEY %
                          self.fix_tool.name, select_rules)
        self.datas.clear()
        return True

    def is_rule_load(self, ruleid, checked):
        autofix = self.find_fixer(ruleid)[1]
        if self.enabled_button.isChecked() and not checked:
            return False
        if self.not_enabled_button.isChecked() and checked:
            return False
        if self.enable_autofix_button.isChecked() and not autofix:
            return False
        return True

    def insert_table_row(self):
        row = 0
        self.table.insertRow(row)
        return row
