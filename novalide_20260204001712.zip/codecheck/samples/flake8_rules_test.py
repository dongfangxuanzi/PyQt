class User(object):
  def __init__(self, name):
    self.name = name
	
if True:
     print('Hi there')


# The space after open is unnecessary
with open( 'file.dat') as f:
    contents = f.read()
	
if age>15:
    print('Can drive')
	
	
age=67

# There are two spaces before the multiplication operator
num = 10
doubled = num  * 2

## Prints hello
print('hello')

#This comment needs a space
def print_name(self):
    print(self.name)
	
def print_name(self):
    print(self.name)  #This comment needs a space

age = 10+15
remainder = 10%2
my_tuple = 1,  2

def  func():
    pass
	
from collections import(namedtuple, defaultdict)
class MyClass(object):
    def func1():
        pass
    def func2():
        pass
		
def func1():
    pass
def func2():
    pass
	
import collections, os, sys


list1=[11111,333,344555,66666,2333333,9999,'aaaaaa','bbbbbbbb',"gggggggggggggggggggg","x","y","zzzzz"]

class User(object):
    pass
user = User()

def f(): pass