

def ensure_bytes(s, encoding='utf-8', errors='strict'):
    if isinstance(s, str):
        return bytes(s, encoding=encoding)
    if isinstance(s, bytes):
        return s
    if isinstance(s, bytearray):
        return bytes(s)
    raise ValueError(
        "Expected str or bytes or bytearray, received %s." %
        type(s))


def ensure_string(s, encoding='utf-8', errors='strict'):
    if isinstance(s, str):
        return s
    if isinstance(s, (bytes, bytearray)):
        return str(s, encoding=encoding)
    raise ValueError(
        "Expected str or bytes or bytearray, received %s." %
        type(s))
