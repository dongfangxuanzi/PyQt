# -*- coding: utf-8 -*-
from .... import get_app, _, newid
from ....util import ui_utils
from ....bars.menubar import NewQMenu
from .... import menuitems
from ..watchs import CommonWatcher, Watch, getAddWatchBitmap, getClearWatchBitmap, WatchDialog
from ....lib.pyqt import QFrame, QTreeWidget, QTreeWidgetItem, Qt, QVBoxLayout, QCursor, QMessageBox
from .. import debugcfg

ERROR_NAME_VALUE = "<errors:could not evaluate the value>"


class WatchsPanel(QFrame, CommonWatcher):
    """description of class"""
    ID_ClEAR_WATCH = newid()
    ID_ClEAR_ALL_WATCH = newid()
    ID_EDIT_WATCH = newid()
    ID_COPY_WATCH_EXPRESSION = newid()
    WATCH_NAME_COLUMN_WIDTH = 150
    ID_VIEW_WATCH = newid()

    def __init__(self, parent):
        super().__init__(parent)
        framebox = QVBoxLayout()
        framebox.setContentsMargins(0, 0, 0, 0)
        framebox.setSpacing(0)
        self.setLayout(framebox)
        self.tree = QTreeWidget()
        framebox.addWidget(self.tree)
        self.__headeritem = QTreeWidgetItem([_("Name"), _("Value"), _("Type")])
        self.tree.setHeaderItem(self.__headeritem)
        self.error_bmp = get_app().GetImage("python/debugger/error.png")
        self.watch_expr_bmp = get_app().GetImage("python/debugger/watch_exp.png")

        self._root = None
        self.ShowRoot()
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self.OnRightClick)
        self.watchs = Watch.Load()
        self.LoadWatches()
        self.menu = None
        self.tree.itemExpanded.connect(self.IntrospectCallback)

    def IntrospectCallback(self, item):
        '''
            展开节点时实时获取节点的所有子节点的值
        '''
        CommonWatcher.IntrospectCallback(self, item, True)

    def ShowRoot(self, show=True):
        self._root = self.tree.invisibleRootItem()
        if show:
            sampleitem = QTreeWidgetItem()
            sampleitem.setText(0, "Expression")
            self._root.addChild(sampleitem)
        else:
            if len(self.watchs) == 0:
                self._clear_tree()

    def SaveWatchs(self):
        Watch.Dump(self.watchs)

    def OnRightClick(self):
        sel_items = self.tree.selectedItems()
        if not sel_items:
            return
        # Refactor this...
        self._introspectItem = None
        if sel_items:
            self._introspectItem = sel_items[0]
        self._parentChain = self.GetItemChain(self._introspectItem)
        watch_only = len(self._parentChain) < 1
        if self.menu is None:
            self.menu = NewQMenu(self)
            self.menu.Append(menuitems.ID_ADD_WATCH, _(
                "Add a watch"), img=getAddWatchBitmap(), handler=self.OnAddWatch)
            if not watch_only:
                self.menu.Append(self.ID_VIEW_WATCH, _(
                    "View in dialog"), handler=self.on_view)
            self.menu.Append(self.ID_EDIT_WATCH, _(
                "Edit watch"), handler=self.edit_watch)
            self.menu.Append(self.ID_COPY_WATCH_EXPRESSION, _(
                "Copy watch expression"), handler=self.copy_watch_expression)

            self.menu.Append(self.ID_ClEAR_WATCH, _(
                "Clear"), img=getClearWatchBitmap(), handler=self.clear_watch)
            self.menu.Append(self.ID_ClEAR_ALL_WATCH, _(
                "Clear all"), handler=self.ClearAllWatch)
        self.menu.popup(QCursor.pos())

    def OnAddWatch(self):
        if get_app().GetDebugger()._debugger_ui is None:
            QMessageBox.information(
                self, _('Error'), _("Debugger has been stopped."))
            return
        get_app().GetDebugger()._debugger_ui.OnAddWatch()

    def clear_watch(self):
        watch_obj = self.GetItemWatchData(self._introspectItem)
        self.watchs.remove(watch_obj)
        self._root.removeChild(self._introspectItem)

    def _clear_tree(self):
        self.tree.clear()

    def on_view(self):
        self.view_expression(self._introspectItem)

    def ClearAllWatch(self):
        self._clear_tree()
        get_app().GetDebugger()._debugger_ui.watchs = []
        self.ShowRoot(True)

    def edit_watch(self):
        watch_data = self.GetItemWatchData(self._introspectItem)
        index = self.GetWatchItemIndex(self._introspectItem)
        wd = WatchDialog(get_app().GetTopWindow(), _(
            "Edit a watch"), None, watch_obj=watch_data)
        if wd.exec_() == WatchDialog.Accepted:
            watch_obj = wd.GetSettings()
            self._introspectItem.setText(0, watch_data.Name)
            get_app().GetDebugger()._debugger_ui.UpdateWatch(watch_obj, self._introspectItem)
            self.watchs[index] = watch_obj

    def copy_watch_expression(self):
        title = self._introspectItem.text(0)
        value = self._introspectItem.text(1)
        ui_utils.copytoclipboard(title + "\t" + value)

    def LoadWatches(self):
        '''
            初始化监视点时调试器关闭,值是不可预测的
        '''
        if len(self.watchs) > 0:
            self._clear_tree()
        for watch_data in self.watchs:
            treenode = QTreeWidgetItem()
            treenode.setText(0, watch_data.Name)
            treenode.setText(1, ERROR_NAME_VALUE)
            treenode.setText(2, _(debugcfg.DEBUG_UNKNOWN_VALUE_TYPE))
            treenode.setIcon(0, self.error_bmp)
            self._root.addChild(treenode)

    def UpdateWatchs(self):
        root_item = self.GetRootItem()
        if root_item is None:
            return
        self.ShowRoot(False)
        childcount = root_item.childCount()
        for i in range(childcount):
            item = root_item.child(i)
            watch_data = self.GetItemWatchData(item)
            get_app().GetDebugger()._debugger_ui.UpdateWatch(watch_data, item)

    def UpdateSubTreeFromNode(self, node, name, item):
        self.DeleteItemChild(item)
        item.setIcon(0, self.watch_expr_bmp)
        return CommonWatcher.UpdateSubTreeFromNode(self, node, name, item, True)

    def GetRootItem(self):
        return self._root

    def ResetWatchs(self):
        root_item = self.GetRootItem()
        if root_item is None:
            return
        childcount = root_item.childCount()
        for i in range(childcount):
            item = root_item.child(i)
            self.DeleteItemChild(item)
            child_item = QTreeWidgetItem()
            child_item.setText(1, ERROR_NAME_VALUE)
            child_item.setText(2, _(debugcfg.DEBUG_UNKNOWN_VALUE_TYPE))
            child_item.setIcon(0, self.error_bmp)

    def DeleteItemChild(self, item):
        item.takeChildren()

    def AppendErrorWatch(self, watch_obj, parent):
        treenode = self._treeCtrl.AppendItem(parent, watch_obj.Name)
        self._treeCtrl.SetItemImage(treenode, self.ErrorIndex)
        self._treeCtrl.SetItemText(treenode, ERROR_NAME_VALUE, 1)
        self._treeCtrl.SetItemText(treenode, _(
            consts.DEBUG_UNKNOWN_VALUE_TYPE), 2)
        self._debugger_service.AppendWatch(watch_obj)
        self.SetItemPyData(treenode, watch_obj)

    def UpdateWatch(self, node, watch_obj, treenode):
        self.UpdateSubTreeFromNode(node, watch_obj.Name, treenode)

    def AddWatch(self, node, watch_obj, parent, insert_before=None):
        self.ShowRoot(False)
        self.AppendSubTreeFromNode(node, watch_obj.Name, parent, insert_before)
        self.watchs.append(watch_obj)

    def GetItemWatchData(self, treeitem):
        index = self.GetWatchItemIndex(treeitem)
        watch_data = self.watchs[index]
        return watch_data

    def GetWatchItemIndex(self, item):
        childcount = self._root.childCount()
        for i in range(childcount):
            child = self._root.child(i)
            if child == item:
                return i
        assert False

    def GetFrameNode(self):
        return GetApp().GetDebugger()._debugger_ui.framestab.stackFrameTab.GetFrameNode()
