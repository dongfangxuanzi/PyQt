# -*- coding: utf-8 -*-
from .... import get_app, _
from ..commandui import BaseDebuggerUI
from ....lib.pyqt import (
    QFrame,
    QVBoxLayout,
    QMessageBox,
    Qt,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSizePolicy,
    QPlainTextEdit,
    QColor,
    QBrush,
    QTextCursor
)


class InspectConsoleTab(QFrame):
    """description of class"""

    def __init__(self, parent):
        super().__init__(parent)
        framebox = QVBoxLayout()
        framebox.setContentsMargins(0, 5, 0, 0)
        framebox.setSpacing(0)
        self.setLayout(framebox)
        rowbox = QHBoxLayout()
        rowbox.addWidget(QLabel(text=_("Cmd") + ":"))
        self._input_textctrl = QLineEdit()
        rowbox.addWidget(self._input_textctrl)
        self._input_textctrl.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        # 文本框回车键处理事件
        self._input_textctrl.returnPressed.connect(self.OnCmdButtonPressed)
        cmdbutton = QPushButton(text=_("Execute"))
        cmdbutton.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        cmdbutton.clicked.connect(self.OnCmdButtonPressed)
        rowbox.addWidget(cmdbutton)
        clrbutton = QPushButton(_("Clear"))
        clrbutton.clicked.connect(self.OnClrButtonPressed)
        clrbutton.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        rowbox.addWidget(clrbutton)
        framebox.addLayout(rowbox)

        self._output_textctrl = QPlainTextEdit(self)
        self._output_textctrl.setReadOnly(True)
        self._output_textctrl.setHorizontalScrollBarPolicy(
            Qt.ScrollBarAlwaysOff)
        framebox.addWidget(self._output_textctrl)
        self._input_textctrl.setFocus()

        self._normal_format = self._output_textctrl.currentCharFormat()
        self._error_format = self._output_textctrl.currentCharFormat()
        self._error_format.setForeground(QBrush(QColor(Qt.red)))
        self._cmdlist = []
        self._cmdindex = 0

    @property
    def inputctrl(self):
        return self._input_textctrl

    @property
    def outputctrl(self):
        return self._output_textctrl

    def handleCommand(self, event=None):
        cmdstr = self._input_textctrl.text()
        if not cmdstr:
            return
        self._cmdlist.append(cmdstr)
        self._cmdindex = len(self._cmdlist)
        self._input_textctrl.clear()
        self.execute_command(cmdstr)

    def execute_command(self, command):
        get_app().GetDebugger()._debugger_ui.framestab.ExecuteCommand(command)

    def OnCmdButtonPressed(self):
        if not BaseDebuggerUI.DebuggerRunning():
            QMessageBox.information(
                self, get_app().GetAppName(), _("Debugger has been stopped."))
            return
        self.handleCommand()

    def append_command(self, text):
        self._output_textctrl.setReadOnly(False)
        self.__appendText(text)
        self._output_textctrl.setReadOnly(True)

    def append_output(self, text):
        self._output_textctrl.setReadOnly(False)
        self.__appendText(text, True)
        self._output_textctrl.setReadOnly(True)

    def OnKeyPressed(self, event):
        key = event.GetKeyCode()
        if key == wx.WXK_RETURN:
            handleCommand()
        elif key == wx.WXK_UP:
            if len(self._cmdlist) < 1 or self._cmdindex < 1:
                return
            self._input_textctrl.Clear()
            self._input_textctrl.AppendText(self._cmdlist[self._cmdindex - 1])
            self._cmdindex = self._cmdindex - 1
        elif key == wx.WXK_DOWN:
            if len(self._cmdlist) < 1 or self._cmdindex >= len(self._cmdlist):
                return
            self._input_textctrl.Clear()
            self._input_textctrl.AppendText(self._cmdlist[self._cmdindex - 1])
            self._cmdindex = self._cmdindex + 1
        else:
            event.Skip()
        return

    def OnClrButtonPressed(self):
        self.Clear()

    def Clear(self):
        self._output_textctrl.setReadOnly(False)
        self._output_textctrl.clear()
        self._output_textctrl.setReadOnly(True)

    def __appendText(self, txt, is_error=False):
        """Append the text"""
        if txt:
            cursor = self._output_textctrl.textCursor()
            cursor.movePosition(QTextCursor.End)
            self._output_textctrl.setTextCursor(cursor)
            if is_error:
                self._output_textctrl.setCurrentCharFormat(self._error_format)
            else:
                self._output_textctrl.setCurrentCharFormat(self._normal_format)
            self._output_textctrl.insertPlainText(txt)
            self._output_textctrl.insertPlainText('\n')
            self._output_textctrl.ensureCursorVisible()
