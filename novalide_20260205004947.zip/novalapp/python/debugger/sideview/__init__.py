from .... import get_app, _
from ....plugin import iface
from ....plugin import plugin
from .... import constants
from .breakpoints import BreakpointsUI
from .inspectconsole import InspectConsoleTab
from .watchspanel import WatchsPanel
from .stacksframe import StackFrameTab
from ....sidebar.sidebar import SideBar


class BreakdebugviewLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)

    def Load(self):
        get_app().MainFrame.AddView(
            constants.BREAKPOINTS_TAB_NAME,
            BreakpointsUI,
            _("Breakpoints"),
            SideBar.East,
            create=True,
            image_file="python/debugger/breakpoints.png"
        )
        get_app().MainFrame.AddView(
            constants.INTERACTCONSOLE_TAB_NAME,
            InspectConsoleTab,
            _("Interact"),
            SideBar.East,
            create=True,
            image_file="python/debugger/interact.png"
        )

        get_app().MainFrame.AddView(
            constants.WATCH_TAB_NAME,
            WatchsPanel,
            _("Watchs"),
            SideBar.East,
            create=True,
            image_file="python/debugger/watches.png"
        )

        get_app().MainFrame.AddView(
            constants.STACKFRAME_TAB_NAME,
            StackFrameTab,
            _("Stackframe"),
            SideBar.East,
            create=True,
            image_file="python/debugger/flag.ico"
        )
