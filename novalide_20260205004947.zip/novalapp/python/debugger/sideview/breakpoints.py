# -*- coding: utf-8 -*-
import os
import builtins
from .... import get_app, _, newid
from ....util import ui_utils, utils, fileutils
from .... import qtimage
from ....bars.menubar import NewQMenu
from .... import menuitems
from ....lib.pyqt import (
    QFrame,
    QTableWidget,
    QVBoxLayout,
    QCursor,
    Qt,
    QTableWidgetItem,
    QAbstractItemView,
    QListWidget,
    QLabel,
    QPushButton,
    QHBoxLayout,
    QLineEdit,
    QListWidgetItem,
    QSizePolicy
)


class BreakpointExceptionDialog(ui_utils.BaseModalDialog):
    ALL_EXCEPTIONS = []

    def __init__(self, parent):
        self.filters = []
        super().__init__(_("Add python exception breakpoint"), parent)

        self.layout.addWidget(QLabel(_("Break when exception is") + ":"))
        self.listbox = QListWidget()
        self.layout.addWidget(self.listbox)

        row = QHBoxLayout()
        self.unselect_all_btn = QPushButton(_("Unselect all"))
        self.unselect_all_btn.clicked.connect(self.unselect_all)
        self.unselect_all_btn.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed)
        row.addWidget(self.unselect_all_btn)

        self.select_all_btn = QPushButton(_("Select all"))
        self.select_all_btn.clicked.connect(self.select_all)
        self.select_all_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        row.addWidget(self.select_all_btn)
        self.layout.addLayout(row)

        self.layout.addWidget(QLabel(_("User defined exceptions") + ":"))
        self.user_exception_textctrl = QLineEdit()
        self.layout.addWidget(self.user_exception_textctrl)
        self.add_exception_btn = QPushButton(_("Add exception"))
        self.add_exception_btn.clicked.connect(self.AddException)
        self.layout.addWidget(self.add_exception_btn)

        self.create_standard_buttons()
        self.init_exceptions()
        self.exceptions = []

    def _ok(self):
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            if listitem.checkState() == Qt.Checked:
                exception = listitem.text()
                self.exceptions.append(exception)
        super()._ok()

    def init_exceptions(self):
        if not self.ALL_EXCEPTIONS:
            for name in dir(builtins):
                builtinobj = getattr(builtins, name)
                if isinstance(builtinobj, type) and issubclass(builtinobj, Exception):
                    self.ALL_EXCEPTIONS.append(name)

        for exception in self.ALL_EXCEPTIONS:
            listitem = QListWidgetItem(exception)
            self.listbox.addItem(listitem)
            listitem.setCheckState(Qt.Unchecked)

    def select_all(self):
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            if listitem.checkState() == Qt.Unchecked:
                listitem.setCheckState(Qt.Checked)

    def unselect_all(self):
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            if listitem.checkState() == Qt.Checked:
                listitem.setCheckState(Qt.Unchecked)

    def AddException(self):
        other_exception = self.user_exception.get().strip()
        if other_exception == "":
            return
        self.listbox.Append(other_exception)


class BreakpointsUI(QFrame):
    FILE_NAME_COLUMN_WIDTH = 150
    FILE_LINE_COLUMN_WIDTH = 50
    clearBPID = newid()
    syncLineID = newid()

    def __init__(self, parent):
        super().__init__(parent)
        columns = [_("File"), _("Line"), _("Path")]
        self.currentitem = None
        self.table = QTableWidget(0, len(columns), self)
        framebox = QVBoxLayout()
        framebox.setContentsMargins(0, 0, 0, 0)
        framebox.setSpacing(0)
        framebox.addWidget(self.table)
        self.setLayout(framebox)
        self.table.setColumnWidth(0, 100)
        self.table.setColumnWidth(1, 60)

        self.table.setHorizontalHeaderLabels(columns)
        # 最后一列自动伸缩扩展
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().hide()

        self.breakpoint_bmp = qtimage.load_image(
            "python/debugger/breakpoint.png")
        self.table.doubleClicked.connect(self.OnDoubleClick)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.OnListRightClick)

        self._menu = None
        self._master_bp_dict = {}
        self.PopulateBPList()

    def PopulateBPList(self):
        breakpoints = utils.profile_get("MasterBreakpointDict", [])
        for dct in breakpoints:
            self.table.insertRow(0)
            fileitem = QTableWidgetItem(dct['filename'])
            self.table.setItem(0, 0, fileitem)

            lineitem = QTableWidgetItem(str(dct['lineno']))
            self.table.setItem(0, 1, lineitem)

            pathitem = QTableWidgetItem(dct['path'])
            self.table.setItem(0, 2, pathitem)
            self.AddBreakpoint(dct['path'], dct['lineno'])

    def OnDoubleClick(self, index):
        self.SyncBPLine()

    def OnListRightClick(self):
        if 0 == self.table.rowCount():
            return
        select_row = self.table.currentRow()
        if self._menu is not None:
            self._menu.destroy()
            self._menu = None
        self._menu = NewQMenu(self)
        if select_row != -1:
            self._menu.Append(self.clearBPID, _(
                "Clear breakpoint"), handler=self.ClearBreakPoint)
            self._menu.Append(self.syncLineID, _(
                "Goto source line"), handler=self.SyncBPLine)
        self._menu.Append(
            menuitems.ID_CLEAR_ALL_BREAKPOINTS,
            _("&Clear all breakpoints"),
            handler=self.ClearAllBreakPoints
        )
        self._menu.popup(QCursor.pos())

    def SyncBPLine(self):
        select_row = self.table.currentRow()
        if select_row == -1:
            return
        filename = self.table.item(select_row, 2).text()
        line_number = int(self.table.item(select_row, 1).text())
        get_app().GotoView(filename, lineNum=line_number, load_outline=False)

    def ClearBreakPoint(self):
        self.DeleteBreakPoint(self.table.currentRow())

    def DeleteBreakPoint(self, row, notify=True):
        filename = self.table.item(row, 2).text()
        line_number = int(self.table.item(row, 1).text())
        doc = get_app().GetDocumentManager().GetDocument(filename)
        # 如果断点所在的文件打开了,同时要删除文件中的断点标记
        if doc:
            # 控件实际行号减少1
            doc.GetFirstView().DeleteBpMark(line_number - 1, notify=notify)
        # 否则直接删除节点即可
        else:
            self.table.removeRow(row)
            self.RemoveBreakpoint(filename, line_number, notify)

    def ListItemSelected(self, event):
        self.currentitem = event.m_itemIndex

    def ListItemDeselected(self, event):
        self.currentitem = -1

    def ToogleBreakpoint(self, lineno, filename, delete=False, notify=True):
        if not delete:
            self.table.insertRow(0)
            fileitem = QTableWidgetItem(os.path.basename(filename))
            self.table.setItem(0, 0, fileitem)

            lineitem = QTableWidgetItem(str(lineno))
            self.table.setItem(0, 1, lineitem)

            pathitem = QTableWidgetItem(filename)
            self.table.setItem(0, 2, pathitem)
            self.AddBreakpoint(filename, lineno)
            # 通知断点服务器增加断点
            if get_app().GetDebugger()._debugger_ui:
                get_app().GetDebugger()._debugger_ui.NotifyDebuggersOfBreakpointChange()
        else:
            for i in range(self.table.rowCount()):
                bp_filename = self.table.item(i, 2).text()
                bp_linenum = int(self.table.item(i, 1).text())
                if bp_linenum == lineno and fileutils.ComparePath(bp_filename, filename):
                    self.table.removeRow(i)
                    self.RemoveBreakpoint(filename, lineno, notify)
                    break

    def ClearAllBreakPoints(self):
        for i in range(self.table.rowCount()):
            # 删除所有断点时,不要反复通知断点服务器删除断点,断点删除后统一一次性通知
            self.DeleteBreakPoint(i, notify=False)
        if get_app().GetDebugger()._debugger_ui is not None:
            get_app().GetDebugger()._debugger_ui.NotifyDebuggersOfBreakpointChange()

    def SaveBreakpoints(self):
        breakpoints = []
        for i in range(self.table.rowCount()):
            fitem = self.table.item(i, 0)
            pathitem = self.table.item(i, 2)
            lineno = self.table.item(i, 1)
            dct = {
                "filename": fitem.text(),
                "lineno": int(lineno.text()),
                "path": pathitem.text()
            }
            breakpoints.append(dct)
        utils.profile_set("MasterBreakpointDict", breakpoints)

    def GetMasterBreakpointDict(self):
        return self._master_bp_dict

    def AddBreakpoint(self, filename, lineno):
        '''
            通知断点服务器添加断点
        '''
        lineno = int(lineno)
        if not filename in self._master_bp_dict:
            self._master_bp_dict[filename] = [lineno]
        else:
            self._master_bp_dict[filename] += [lineno]

    def RemoveBreakpoint(self, filename, lineno, notify=True):
        '''
            通知断点服务器删除断点
        '''
        lineno = int(lineno)
        if not filename in self._master_bp_dict:
            utils.get_logger().error("In ClearBreak: no filename %s", filename)
            return
        if lineno in self._master_bp_dict[filename]:
            self._master_bp_dict[filename].remove(lineno)
            if self._master_bp_dict[filename] == []:
                del self._master_bp_dict[filename]
        # 删除断点后通知断点服务器删除断点
        if notify and get_app().GetDebugger()._debugger_ui:
            get_app().GetDebugger()._debugger_ui.NotifyDebuggersOfBreakpointChange()
        else:
            utils.get_logger().error("In ClearBreak: no filename %s line %d", filename, lineno)

    def set_exception_breakpoint(self):
        exception_dlg = BreakpointExceptionDialog(get_app().GetTopWindow())
        if exception_dlg.exec_() == BreakpointExceptionDialog.Accepted:
            get_app().GetDebugger().SetExceptions(exception_dlg.exceptions)
