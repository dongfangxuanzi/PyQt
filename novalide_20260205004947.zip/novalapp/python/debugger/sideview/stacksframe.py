# -*- coding: utf-8 -*-
import threading
from xml.dom.minidom import parseString
import bz2
from .... import get_app, _, newid
from .. import watchs
from .... import constants
from ....util import utils
from ..commandui import BaseDebuggerUI
from ....lib.pyqt import (
    QFrame,
    QHBoxLayout,
    QVBoxLayout,
    QLabel,
    QComboBox,
    QSizePolicy,
    QTreeWidget,
    QTreeWidgetItem
)


class StackFrameTab(QFrame, watchs.CommonWatcher):
    """description of class"""
    AddWatchId = newid()
    toInteractID = newid()

    def __init__(self, parent):
        super().__init__(parent)

        framebox = QVBoxLayout()
        framebox.setContentsMargins(0, 5, 0, 0)
        framebox.setSpacing(0)
        self.setLayout(framebox)

        row = QHBoxLayout()
        row.addWidget(QLabel(_("Stack frame") + ":"))
        self._frames_choice_ctrl = QComboBox()
        self._frames_choice_ctrl.setSizePolicy(QSizePolicy.Expanding,
                                               QSizePolicy.Fixed)
        row.addWidget(self._frames_choice_ctrl)
        self._frames_choice_ctrl.currentIndexChanged.connect(
            self.frameitem_index_changed)
        framebox.addLayout(row)
        self.tree = QTreeWidget()
        framebox.addWidget(self.tree)
        self.__headeritem = QTreeWidgetItem([_("Thing"), _("Value")])
        self.tree.setHeaderItem(self.__headeritem)

        rootitem = QTreeWidgetItem()
        rootitem.setText(0, "Frame")
        self.tree.invisibleRootItem().addChild(rootitem)
        self._root = rootitem
        self.tree.itemExpanded.connect(self.IntrospectCallback)
        self.menu = None
        self.lock = threading.Lock()
        self.is_watching = False

    @property
    def frames_choice_ctrl(self):
        return self._frames_choice_ctrl

    def frameitem_index_changed(self, index):
        self.PopulateTreeFromFrameMessage(
            self._frames_choice_ctrl.itemText(index))
        self.OnSyncFrame()

    def get_frame_value(self):
        current_index = self._frames_choice_ctrl.currentIndex()
        return self._frames_choice_ctrl.itemText(current_index)

    def OnRightClick(self, event):
        if not self.tree.selection() or not BaseDebuggerUI.DebuggerRunning():
            return
        # Refactor this...
        self._introspectItem = self.tree.selection()[0]
        if self._introspectItem == self._root:
            return
        self._parentChain = self.GetItemChain(self._introspectItem)
        if self.menu is None:
            self.menu = tkmenu.PopupMenu()
            item = tkmenu.MenuItem(constants.ID_ADD_WATCH, _(
                "Add a Watch"), None, watchs.getAddWatchBitmap(), None)
            self.menu.AppendMenuItem(item, handler=self.OnAddWatch)
            item = tkmenu.MenuItem(self.AddWatchId, _(
                "Add to Watch"), None, watchs.getAddtoWatchBitmap(), None)
            self.menu.AppendMenuItem(item, handler=self.OnAddToWatch)
            item = tkmenu.MenuItem(watchs.WatchsPanel.ID_VIEW_WATCH, _(
                "View in Dialog"), None, None, None)
            self.menu.AppendMenuItem(item, handler=self.OnView)

            item = tkmenu.MenuItem(self.toInteractID, _(
                "Send to Interact"), None, None, None)
            self.menu.AppendMenuItem(item, handler=self.OnSendToInteract)
        self.menu.tk_popup(event.x_root, event.y_root)

    def OnAddWatch(self):
        GetApp().GetDebugger()._debugger_ui.OnAddWatch()

    def OnAddToWatch(self):
        name = self.tree.item(self._introspectItem, "text")
        GetApp().GetDebugger()._debugger_ui.framestab.AddtoWatchExpression(name, name)

    def OnSendToInteract(self):
        '''
            执行右键菜单发送到交互命令
        '''
        value = ""
        previtem = ""
        for item in self._parentChain:
            if item.find(previtem + '[') != -1:
                value += item[item.find('['):]
                continue
            if value != "":
                value = value + '.'
            if item == 'globals':
                item = 'globals()'
            if item != 'locals':
                value += item
                previtem = item
        utils.get_logger().debug('send command is:%s', value)
        GetApp().GetDebugger()._debugger_ui.framestab.ExecuteCommand(value)

    def OnView(self):
        self.ViewExpression(self._introspectItem)

    def DeleteChildren(self, item):
        item.takeChildren()

    def IntrospectCallback(self, item):
        '''
            展开节点时实时获取节点的所有子节点的值
        '''
        # 根节点无法监视
        if item == self._root:
            return
        watchs.CommonWatcher.IntrospectCallback(self, item)

    def GetFrameNode(self):
        return self._stack[int(self.current_item)]

    def PopulateTreeFromFrameNode(self, framenode):
        self._frames_choice_ctrl.setEnabled(True)
        root = self._root
        self.DeleteChildren(root)
        children = framenode.childNodes
        firstchild = None
        for index in range(0, children.length):
            subnode = children.item(index)
            treenode = self.AppendSubTreeFromNode(
                subnode, subnode.getAttribute('name'), root)
            if not firstchild:
                firstchild = treenode
        root.setExpanded(True)
        if firstchild:
            firstchild.setExpanded(True)

    def LoadFrame(self, domdoc):
        nodelist = domdoc.getElementsByTagName('frame')
        frame_count = -1
        frame_values = []
        self._stack = []
        for index in range(0, nodelist.length):
            framenode = nodelist.item(index)
            message = framenode.getAttribute("message")
            frame_values.append(message)
            self._stack.append(framenode)
            frame_count += 1
        index = len(self._stack) - 1
        self._frames_choice_ctrl.addItems(frame_values)
        self._frames_choice_ctrl.setCurrentIndex(index)

        node = self._stack[index]
        self.current_item = index
        self.PopulateTreeFromFrameNode(node)
        self.OnSyncFrame()

        framenode = nodelist.item(index)
        file = framenode.getAttribute("file")
        line = framenode.getAttribute("line")
        get_app().GetDebugger()._debugger_ui.framestab.SynchCurrentLine(file, line)

    def OnSyncFrame(self):
        '''
            定位到当前断点调试所在的文件行
        '''
        framenode = self._stack[int(self.current_item)]
        file = framenode.getAttribute("file")
        line = framenode.getAttribute("line")
        get_app().GetDebugger()._debugger_ui.framestab.SynchCurrentLine(file, line)

    def PopulateTreeFromFrameMessage(self, message):
        index = 0
        for node in self._stack:
            if node.getAttribute("message") == message:
                bintype = get_app().GetDebugger()._debugger_ui.framestab.request_frame_document(message)
                xmldoc = bz2.decompress(bintype.data)
                domdoc = parseString(xmldoc)
                nodelist = domdoc.getElementsByTagName('frame')
                self.current_item = index
                if nodelist:
                    self.PopulateTreeFromFrameNode(nodelist[0])
                return
            index = index + 1

    def HasStack(self):
        return hasattr(self, "_stack")

    def GetWatchList(self, watch_obj):
        '''
            从断点调试服务器中获取监视的值
        '''
        with self.lock:
            if self.is_watching:
                return []
            framenode = self._stack[int(self.current_item)]
            message = framenode.getAttribute("message")
            try:
                self.is_watching = True
                bintype = get_app().GetDebugger()._debugger_ui.framestab.add_watch(message, watch_obj)
            except Exception as e:
                utils.get_logger().exception('watch exception:')
                return []
            xmldoc = bz2.decompress(bintype.data)
            domdoc = parseString(xmldoc)
            nodelist = domdoc.getElementsByTagName('watch')
            self.is_watching = False
            return nodelist
