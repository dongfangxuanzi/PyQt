class ReferenceModuleNotAnalyzedError(Exception):
    '''引用模块还没有解析生成智能提示数据'''


class CodefileNotExistError(Exception):
    '''代码文件被删除或移走'''


class BuiltinModuleNotExistError(Exception):
    '''内建模块数据库文件不存在'''


class OutofPythonPathError(Exception):
    '''解析文件路径不在解释器搜索路径中'''


class AnalyzeCodefileError(Exception):
    '''解析代码文件错误'''


class CodeSyntaxError(Exception):
    '''代码语法错误'''
