import os
import logging
import types
import sys
import pickle
import importlib
from . import objtypes, define
from ..apis import iconid, memberkeys

log = logging.getLogger(__name__)


class BuiltinTypes:
    """内建模块包含扩展pyd,so模块的子成员解析"""

    @classmethod
    def make_types(cls, objname, builtin_type, childs, recursive=True):
        '''
            递归解析内建模块或类的子成员,但是递归深度有限制
        '''
        for name in dir(builtin_type):
            try:
                builtin_intance = getattr(builtin_type, name, None)
                if builtin_intance is None:
                    log.debug("type %s has no attr %s",
                              builtin_type.__name__, name)
                    continue
                builtin_attr_type = type(builtin_intance)
            except ModuleNotFoundError as ex:
                log.error("get type %s attr %s error:%s",
                          builtin_type.__name__, name, str(ex))
                continue
            typename = objname + "." + name
            if isinstance(builtin_intance, type):
                if not recursive:
                    continue
                childs.append([typename, objtypes.CLASS_DEF, builtin_intance])
                cls.make_types(typename, builtin_intance, childs, False)
            elif isinstance(builtin_intance, (
                types.BuiltinFunctionType,
                types.BuiltinMethodType,
                types.FunctionType
            )
            ) or str(builtin_attr_type).find("method_descriptor") != -1:
                childs.append(
                    [typename, objtypes.FUNCTION_DEF, builtin_intance])
            elif isinstance(builtin_intance, types.ModuleType):
                childs.append([typename, objtypes.MODULE, builtin_intance])
            else:
                if isinstance(builtin_type, types.ModuleType):
                    childs.append(
                        [typename, objtypes.MODULE_ATTRIBUTE, builtin_intance])
                else:
                    childs.append(
                        [typename, objtypes.CLASS_ATTRIBUTE, builtin_intance])

    @staticmethod
    def get_builtin_doc(builtin_intance):
        doc = builtin_intance.__doc__
        if isinstance(doc, str):
            return doc
        return None

    @staticmethod
    def get_builtin_module_file(builtin_module):
        if hasattr(builtin_module, '__file__'):
            filepath = builtin_module.__file__
            return filepath
        return None

    @staticmethod
    def import_builtin_module(module_name):
        try:
            mod = importlib.import_module(module_name)
            return mod
        except (ModuleNotFoundError, ImportError) as ex:
            log.warning(str(ex))
        except Exception as e:
            log.error("load pyd module %s error:%s", module_name, str(e))
        return None

    @classmethod
    def get_sub_modules(cls, mod, sub_module_names):
        '''
            扫描包下面的所有子包和子模块
        '''
        for child_attr_name in dir(mod):
            try:
                builtin_intance = getattr(mod, child_attr_name)
            except (ModuleNotFoundError, RuntimeError) as ex:
                log.error("import %s.%s error:%s", mod.__name__,
                          child_attr_name, str(ex))
                continue
            if isinstance(builtin_intance, types.ModuleType):
                child_typename = builtin_intance.__name__
                parent_typename = mod.__name__
                # 区分子模块和导入模块,子模块路径包父模块路径,导入模块是其模块路径
                if child_typename.startswith(parent_typename + "."):
                    sub_module_names.append(builtin_intance.__name__)
                    cls.get_sub_modules(builtin_intance, sub_module_names)


class BuiltintypesApiGen:
    def __init__(self, modname, data_path):
        self._builtin_module_name = modname
        self._data_path = data_path
        self._api_file = os.path.join(
            self._data_path,
            self._builtin_module_name + define.MEMBERLIST_FILE_EXTENSION
        )
        self._members_file = os.path.join(
            self._data_path,
            self._builtin_module_name + define.MEMBERS_FILE_EXTENSION
        )

    def gen(self):
        mod = BuiltinTypes.import_builtin_module(self._builtin_module_name)
        if mod is None:
            return
        childs = []
        BuiltinTypes.make_types(self._builtin_module_name, mod, childs)
        self.make_members_file(mod, self._builtin_module_name, childs)

    def make_members_file(self, module, modname, childs):
        self.gen_api(childs)
        self.gen_members(module, childs)

    def gen_members(self, module, childs):
        childs.sort(key=lambda k: k[0])
        with open(self._members_file, 'wb') as j:
            # Pickle dictionary.
            datas = []
            for name, objtype, obj in childs:
                data = {
                    memberkeys.MODNAME_KEY_NAME: name,
                    memberkeys.NAME_KEY_NAME: name.split(".")[-1],
                    memberkeys.OBJTYPE_KEY_NAME: objtype
                }
                doc = BuiltinTypes.get_builtin_doc(obj)
                if doc is not None:
                    data.update({memberkeys.DOC_KEY_NAME: doc})
                if objtype == objtypes.CLASS_DEF:
                    data[memberkeys.BASES_KEY_NAME] = []
                elif objtype == objtypes.MODULE:
                    modpath = BuiltinTypes.get_builtin_module_file(obj)
                    if modpath is not None:
                        data.update({memberkeys.PATH_KEY_NAME: modpath})
                datas.append(data)
            module_doc = BuiltinTypes.get_builtin_doc(module)
            module_dct = {
                "name": self._builtin_module_name.split('.')[-1],
                "childs": datas,
                "modname": self._builtin_module_name,
                "objtype": objtypes.MODULE,
                "finished": True
            }
            if module_doc is not None:
                module_dct.update(dict(doc=module_doc))
            # 保存pyd文件的路径
            module_path = BuiltinTypes.get_builtin_module_file(module)
            if module_path is not None:
                module_dct.update({memberkeys.PATH_KEY_NAME: module_path})
            pickle.dump(module_dct, j)

    def gen_api(self, childs):
        with open(self._api_file, 'w') as f:
            for name, objtype, _ in childs:
                names = name.split('.')
                objname = names[-1]
                icon_id = iconid.get_icon_id(objtype, objname)
                if icon_id is not None:
                    api_name = "%s?%d" % (name, icon_id)
                else:
                    api_name = name
                self.write_api(f, api_name)

    def write_api(self, fp, api_name):
        fp.write(api_name)
        fp.write('\n')
        log.debug('gen module %s apiname is %s',
                  self._builtin_module_name, api_name)


class BuiltinmoduleGen(BuiltintypesApiGen):
    def write_api(self, fp, api_name):
        super().write_api(fp, api_name)
        if self._builtin_module_name == define.BUILTMODULE_NAME:
            builtinmodule_api_name = api_name.replace(
                self._builtin_module_name + ".", "")
            fp.write(builtinmodule_api_name)
            fp.write('\n')


class BuiltinModulesAnalyzer:

    def __init__(
        self,
        dbver,
        outpath
    ):
        self._dbver = dbver
        self._datapath = outpath

    def analyze(self):
        for builtin_module_name in sys.builtin_module_names:
            log.info('analyze builtin module name %s', builtin_module_name)
            BuiltinmoduleGen(builtin_module_name, self._datapath).gen()
