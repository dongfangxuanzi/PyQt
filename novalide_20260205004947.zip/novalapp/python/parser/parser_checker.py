import os
import time
import pickle
import datetime
import logging

log = logging.getLogger(__name__)


class FileupdateTimeChecker:
    """检查文件的时间是否大于上次的更新时间,解析完成后保存更新时间"""
    UPDATE_FILE = 'update.time'

    def __init__(self, outpath):
        self.last_update_timestamp = -1
        self._timestamp_outpath = outpath
        self.check_last_timestamp()

    def get_last_timestamp(self):
        update_file_path = os.path.join(
            self._timestamp_outpath, self.UPDATE_FILE)
        if not os.path.exists(update_file_path):
            return 0
        return self.load_last_timestamp()

    def load_last_timestamp(self):
        '''
        从更新文件加载上次更新的时间,如果更新文件不存在,则时间为0
        '''
        time_stamp = 0
        timestamp_filepath = self.get_update_timefile()
        try:
            with open(timestamp_filepath, "rb") as f:
                date_list = pickle.load(f)
                time_stamp = date_list[0]
        except Exception as ex:
            log.error('load timestamp file %s error:%s',
                      timestamp_filepath, str(ex))
        return time_stamp

    def update_last_timestamp(self):
        '''
            保存此次的更新时间
        '''
        update_datetime = datetime.datetime.now()
        time_stamp = time.mktime(update_datetime.timetuple())
        tm = [time_stamp]
        timestamp_filepath = self.get_update_timefile()
        try:
            with open(timestamp_filepath, "wb") as f:
                pickle.dump(tm, f)
        except Exception as ex:
            log.error('write timestamp file %s error:%s',
                      timestamp_filepath, str(ex))

    def check_last_timestamp(self):
        self.last_update_timestamp = self.get_last_timestamp()

    def get_update_timefile(self):
        return os.path.join(self._timestamp_outpath, self.UPDATE_FILE)

    def is_filetime_updated(self, filepath):
        if not os.path.exists(filepath):
            return True
        mk_time = os.path.getmtime(filepath)
        log.debug(
            'last time timestamp is %d, file %s timestamp is %d',
            self.last_update_timestamp,
            filepath,
            mk_time
        )
        if mk_time < self.last_update_timestamp:
            return False
        return True
