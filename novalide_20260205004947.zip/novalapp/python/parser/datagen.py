import logging
import os
import sys
from ... import get_app, _
from ... import constants
from ...util import apputils, utils, fileutils
from ...analytics.share import ShareData
from . import define
from ..interpreter.interpretermanager import InterpreterManager
from ...executable import Executable
from ..analysis.builtininterpreter_modules_analyzer import BuiltiInterpreterModulesAnalyzer

logger = logging.getLogger(__name__)

MAX_INTERPRETER_NAME_LENGTH = 30


class IntellisencedataGen(ShareData):
    """description of class"""

    def __init__(self, intellisencemanager, interpreter, statusbar, progress_dlg=None):
        super().__init__(statusbar, get_app().GetDebug())
        self.statusbar = statusbar
        self.intellisencemanager = intellisencemanager
        self._interpreter = interpreter
        self._progress_dlg = progress_dlg

    def run(self):
        try:
            self.generate_intellisence_data()
        except Exception as e:
            logger.error(
                'generate interpreter name %s path %s version %s intellisence data path %s error: %s',
                self._interpreter.name,
                self._interpreter.path,
                self._interpreter.Version,
                os.path.join(self.intellisencemanager.datapath,
                             str(self._interpreter.Id)),
                e
            )
            logger.exception("")
        finally:
            self.share()

    def generate_intellisence_data(self):
        data_out_path = self.intellisencemanager.GetInterpreterDatabasePath(
            self._interpreter)
        if self._interpreter.IsBuiltIn:
            # 内建解释器的数据版本号使用程序版本号,在每次版本更新时重新刷新数据
            BuiltiInterpreterModulesAnalyzer(
                apputils.get_app_version(),
                data_out_path,
                self._interpreter,
                self._progress_dlg
            ).run()
            return
        database_version = define.DATABASE_VERSION
        cmd_list = [
            '-i',
            self._interpreter.path,
            '-o',
            data_out_path,
            '-v',
            database_version,
            '--multiprocess'
        ]
        if get_app().GetDebug():
            cmd_list.append('--debug')
        if getattr(sys, "frozen", False):
            analyzer_path = os.path.join(utils.get_app_path(), "analyzer.exe")
        else:
            script_path = os.path.join(utils.get_app_path(), "analyzer.py")
            cmd_list.insert(0, script_path)
            analyzer_path = sys.executable
        work_dir = utils.get_app_path()
        fileutils.makedirs(data_out_path)
        executable = Executable(analyzer_path, work_dir, args=cmd_list)
        stdout_log = open(os.path.join(data_out_path, "backend.log"), "w")
        stderr_log = open(os.path.join(
            data_out_path, "backend_faults.log"), "w")
        process_obj = executable.exc_proc(stdout=stdout_log, stderr=stderr_log)
        logger.info('update intellisence data cmd is %s', executable.get_cmd())
        interpreter_name_msg = self._interpreter.name
        if len(interpreter_name_msg) > MAX_INTERPRETER_NAME_LENGTH:
            interpreter_name_msg = interpreter_name_msg[0:
                                                        MAX_INTERPRETER_NAME_LENGTH] + "..."
        update_msg = _(
            "Updating interpreter '%s' intellisence database") % interpreter_name_msg
        self.statusbar.emit_statusbar_permanent_messgae(update_msg)
        if self._progress_dlg is not None:
            self._progress_dlg.SIG_APPEND_MSG.emit(update_msg)
        logger.info('updating interpreter %s intellisence database',
                    self._interpreter.name)
        # if current interpreter is analysing,load data at end
        self.wait_for_end(process_obj)
        if not self.intellisencemanager.stopped:
            current_interpreter = InterpreterManager.manager().GetCurrentInterpreter()
            if current_interpreter is not None:
                self.intellisencemanager.load_intellisence_data(
                    current_interpreter, async_load=False)
                self.statusbar.emit_statusbar_messgae(
                    _("Intellisence database has been updated"))
        else:
            logger.warning(
                "smart intellisence analyse has been stopped by user")
        logger.info("generate interpreter %s intellisence data end...",
                    self._interpreter.name)

    def wait_for_end(self, process_obj):
        process_obj.wait()
        logger.info('finished update interpreter intellisence database')
        self.intellisencemanager.running = False
        if self._progress_dlg is not None:
            self._progress_dlg.SIG_APPEND_MSG.emit(constants.PROGRESS_END)
