# -*- coding: utf-8 -*-
import astroid
from .codebase import CodebaseParser
from ...util import strutils


class CodeParser(CodebaseParser):
    """description of class"""

    def __init__(self):
        super().__init__(None)
        self.filepath = None
        self._module_node = None

    def parse_file(self, filepath, encoding="utf-8"):
        with open(filepath, encoding=encoding) as f:
            content = f.read()
            return self.parse_content(filepath, content)

    def parse_content(self, filepath, content, encoding=None):
        module_name = strutils.get_filename_without_ext(filepath)
        self._module_node = astroid.parse(
            content, path=filepath, module_name=module_name)
        return self._module_node

    def prepare_visitors(self, outlineView):
        self._visitors.append(outlineView.visit_functiondef)
        self._visitors.append(outlineView.visit_classdef)
        self._visitors.append(outlineView.leave_classdef)
        self._visitors.append(outlineView.visit_assign)
        self._visitors.append(outlineView.visit_annassign)
        self._visitors.append(outlineView.visit_import)
        self._visitors.append(outlineView.visit_importfrom)
        self._visitors.append(outlineView.visit_if)
        self._visitors.append(outlineView.visit_asyncfunctiondef)
        self._visitors.append(outlineView.visit_try)
        return self._visitors

    def add_module_visitor(self, outlineview):
        """Context manager for checking ASTs.

        The value in the context is callable accepting AST as its only argument.
        """
        _visitors = self.prepare_visitors(outlineview)
        if len(_visitors) == 0:
            raise RuntimeError('empty node visitors')
        # notify global begin
        for visitor in _visitors:
            self.walker.add_visitor(visitor)
