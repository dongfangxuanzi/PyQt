# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        pyeditor.py
Purpose:     python语言编辑器窗口

Author:      wukan

Created:     2019-03-24
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import os
import re
import codecs
from astroid import nodes
from .. import _, get_app, newid
from ..editor import codeview
from ..lib.pyqt import QMessageBox, Qt, QCheckBox
from ..lib.qsci import QsciScintilla, QsciLexerPython, DEFAULT_MARGIN_INDEX
from ..bars.menubar import find_menu, NewQMenu
from .. import menuitems, constants, qtimage
from ..util.exceptions import UnkownEncodingError
from ..util import utils, strutils, fileutils, ui_utils
from .analysis.module_analyzer import PythonModuleAnalyzer, _code_parser
from .analysis.python_path_analyzer import PythonPathAnalyzer
from ..syntax import lang
from .. import globalkeys
from .project.document import PythonProjectDocument
from .project.config import PythonRunconfig
from .parser.node_scope import ScopeFinder
from .parser import objtypes
from .parser import node_utils
from .parser.define import PACKAGE_INIT_FILE
from .ui import (
    ParserErrorsDialog,
    show_definitions_dialog,
    unable_locate_definition,
    definition_not_found
)
from .debugger.debugger import BaseDebuggerUI
from .debugger import debugcfg
from .debugger import watchs
from .formatter import PythoncodeFormatter
from . import utility, pythonenv
from ..common.encodings import get_doc_encoding
from .apis import iconid
from .parser.exceptions import CodeSyntaxError


class PythonDocument(codeview.CodeDocument):

    def reload(self):
        '''
        重载python文档时,重新解析并加载语法树
        '''
        result = super().load(self.GetFilename())
        utils.get_logger().info(
            'reload and reparse document %s ast tree in outline view',
            self.GetFilename()
        )
        get_app().MainFrame.outlineview.LoadOutLine(
            self.GetFirstView(),
            force_reload=True
        )
        return result

    def GetRunParameter(self):
        fileto_run = self.GetFilename()
        unproj_proj = PythonProjectDocument.GetUnProjectDocument()
        # 获取通过运行菜单->配置参数和环境变量显示的对话框里面设置的运行文件参数
        use_argument = utils.profile_get_int(
            unproj_proj.GetUnProjectFileKey(fileto_run, "UseArgument"), True)
        if use_argument:
            initial_args = utils.profile_get(
                unproj_proj.GetUnProjectFileKey(fileto_run, "RunArguments"), "")
        else:
            initial_args = ''
        python_path = utils.profile_get(
            unproj_proj.GetUnProjectFileKey(fileto_run, "PythonPath"), "")
        startin = utils.profile_get(
            unproj_proj.GetUnProjectFileKey(fileto_run, "RunStartIn"), "")
        if startin == '':
            startin = os.path.dirname(fileto_run)
        env = {}
        if python_path != '':
            env[pythonenv.PYTHON_PATH_NAME] = python_path
        return PythonRunconfig(get_app().GetCurrentInterpreter(), fileto_run, initial_args, env, startin)

    def DoSave(self):
        super().DoSave()
        view = self.GetFirstView()
        declare_encoding = view.get_coding_spec()
        if declare_encoding is None:
            return
        if self.IsDocEncodingChanged(declare_encoding):
            self.file_encoding = declare_encoding
            # 在状态栏现实变化后的文件编码
            get_app().MainFrame.sbEncoding.setText(self.file_encoding)

    def IsUtf8Doc(self, encoding):
        if encoding.lower().find("utf-8"):
            return True
        return False

    def IsDocEncodingChanged(self, encoding):
        if get_doc_encoding(encoding) != get_doc_encoding(self.file_encoding):
            return True
        return False


class PythonView(codeview.CodeView, PythoncodeFormatter):
    # 断点标记符合值
    BP_MARKER_NUM = 8

    def __init__(self):
        super().__init__()
        self._module_analyzer = None
        # document checksum to check document is updated
        self._checksum = -1

    def OnCreate(self, doc, flags):
        if not super().OnCreate(doc, flags):
            return False
        curproject = get_app().get_current_project()
        if curproject is not None:
            if not curproject.GetModel().FindFile(doc.GetFilename()):
                curproject = None
        self._module_analyzer = PythonModuleAnalyzer(self, curproject)
        # todo后面待实现此功能
        # self.__navigationBar = NavigationBar(self, self._text_frame)
        # layout.insertWidget(0, self.__navigationBar)
        self.bp_bmp = qtimage.load_image("python/debugger/breakmark.png")
        # 设置标号为1的页边用于显示断点标记
        self.GetCtrl().setMarginType(DEFAULT_MARGIN_INDEX, QsciScintilla.SymbolMargin)
        # 断点标记占用的宽度
        self.GetCtrl().setMarginWidth(DEFAULT_MARGIN_INDEX, "00")
        self.GetCtrl().setMarginSensitivity(DEFAULT_MARGIN_INDEX, True)
        # 单击左边空白框添加断点
        self.GetCtrl().marginClicked.connect(self.on_bp_click)
        self.GetCtrl().markerDefine(self.bp_bmp, self.BP_MARKER_NUM)
        return True

    def update_bar(self):
        self.__navigationBar.updateBar()

    def OnUpdate(self, sender=None, hint=None):
        if super().OnUpdate(sender, hint):
            return True
        # 加载文档断点信息
        self.SetCurrentBreakpointMarkers()
        return True

    @property
    def ModuleAnalyzer(self):
        return self._module_analyzer

    @property
    def Module(self):
        return self._module_analyzer.Module

    def GetCtrlClass(self):
        """ Used in split window to instantiate new instances """
        return PythonCtrl

    def GetLangId(self):
        return lang.ID_LANG_PYTHON

    def OnClose(self, deleteWindow=True):
        status = super().OnClose(deleteWindow)
       # wx.CallAfter(self.ClearOutline)  # need CallAfter because when closing the document, it is Activated and then Close, so need to match OnActivateView's CallAfter
        return status

    def LoadOutLine(self, outlineView, force=False, lineNum=-1):
        callback_view = outlineView.GetCallbackView()
        new_checksum = self.GenCheckSum()
        if not force:
            # 文件长度改变,重新解析并生成语法树
            force = self._checksum != new_checksum
            if callback_view and callback_view is self:
                if self._checksum == new_checksum:
                    utils.get_logger().info("document %s check sum is same not will not analyze again",
                                            self.GetDocument().GetFilename())
                    if lineNum > -1:
                        outlineView.SyncToPosition(self, lineNum)
                    return False
        self._checksum = new_checksum
        document = self.GetDocument()
        if not document:
            return True
        self._module_analyzer.AnalyzeModuleSynchronizeTree(
            callback_view, outlineView, force, lineNum)
        return True

    def UpdateUI(self, command_id):
        if command_id in [
            menuitems.ID_UNITTEST,
            menuitems.ID_RUN,
            menuitems.ID_DEBUG,
            menuitems.ID_SET_EXCEPTION_BREAKPOINT,
            menuitems.ID_STEP_INTO,
            menuitems.ID_STEP_NEXT,
            menuitems.ID_RUN_LAST,
            menuitems.ID_CHECK_SYNTAX,
            menuitems.ID_SET_PARAMETER_ENVIRONMENT,
            menuitems.ID_DEBUG_LAST,
            menuitems.ID_START_WITHOUT_DEBUG,
            menuitems.ID_TOGGLE_BREAKPOINT
        ]:
            return True
        if command_id in [
            menuitems.ID_INSERT_DECLARE_ENCODING,
            menuitems.ID_INSERT_MAIN_STATEMENT
        ]:
            return not self.GetCtrl().isReadOnly()
        if command_id in [
            menuitems.ID_GOTO_DEFINITION,
            menuitems.ID_FIND_OCCURRENCES
        ]:
            return self.GetCtrl().is_word_range()
        return super().UpdateUI(command_id)

    def GotoDefinition(self):
        self.GetCtrl().GotoDefinition()

    def on_bp_click(self, nmargin, nline, modifiers):
        self.ToogleBreakpoint(nline)

    def DeleteBpMark(self, lineno, delete_master_bp=True, notify=True):
        # 0表示不存在断点标记,非0表示存在断点标记
        if self.GetCtrl().markersAtLine(lineno) != 0:
            self.GetCtrl().markerDelete(lineno, self.BP_MARKER_NUM)
            # 删除断点视图中断点数据
            if delete_master_bp:
                get_app().MainFrame.GetView(constants.BREAKPOINTS_TAB_NAME).ToogleBreakpoint(
                    lineno + 1,
                    self.GetDocument().GetFilename(),
                    delete=True,
                    notify=notify
                )
            return True
        return False

    def SetCurrentBreakpointMarkers(self):
        breakpoints = get_app().MainFrame.GetView(
            constants.BREAKPOINTS_TAB_NAME).GetMasterBreakpointDict()
        for linenum in breakpoints.get(self.GetDocument().GetFilename(), []):
            linenum -= 1
            self.DeleteBpMark(linenum, delete_master_bp=False)
            self.GetCtrl().markerAdd(linenum, self.BP_MARKER_NUM)

    def ToogleBreakpoint(self, lineno):
        '''
            设置断点,断点存在时删除断点,否则添加断点
        '''
        line_text = self.GetCtrl().get_line_text(lineno).strip()
        # 判断行开头是否在字符串内,如果是则禁止添加断点
        line_start_pos = self.GetCtrl().position_from_linecol(lineno, 0)
        style = self.GetCtrl().styleAt(line_start_pos)
        is_in_string_range = style in [
            QsciLexerPython.DoubleQuotedString,
            QsciLexerPython.SingleQuotedString,
            QsciLexerPython.TripleSingleQuotedString,
            QsciLexerPython.TripleDoubleQuotedString
        ]
        utils.get_logger().debug(
            'line %d in file %s is in string range:%s',
            lineno,
            self.GetDocument().GetFilename(),
            strutils.bool_to_str(is_in_string_range)
        )
        # 空行或者注释行不能添加断点
        if not self.DeleteBpMark(lineno) and line_text and (
            not line_text.startswith('#') and not is_in_string_range
        ):
            self.GetCtrl().markerAdd(lineno, self.BP_MARKER_NUM)
            # 往断点视图中添加断点数据
            get_app().MainFrame.GetView(constants.BREAKPOINTS_TAB_NAME).ToogleBreakpoint(
                lineno + 1,
                self.GetDocument().GetFilename()
            )

    def GetAutoCompleteKeywordList(self, context, hint, line):
        line, col = self.GetCtrl().GetCurrentPos()
        last_char = self.GetCtrl().GetCharAt(line, col - 1)
        word = self.GetCtrl().GetTypeWord(line, col - 1)
        if (not word and not last_char) or (word and word == context):
            return codeeditor.CodeView.GetAutoCompleteKeywordList(self, context, hint, line)
        return self.GetCtrl().GetAutoCompletions(context, hint, last_char)

    def SetValue(self, value):
        '''
            检查python代码文件申明编码
        '''
        super().SetValue(value)
        try:
            self.get_coding_spec()
        except UnkownEncodingError as ex:
            QMessageBox.critical(self.GetFrame(), _(
                "Unknown encoding"), str(ex))

    def get_coding_spec(self):
        """Return the encoding declaration according to PEP 263.
        Raise LookupError if the encoding is declared but unknown.
        """
        lines = self.GetCtrl().GetTopLines(constants.ENCODING_DECLARE_LINE_NUM)
        name, _ = utility.get_python_coding_declare(lines)
        if name is None:
            return None
        # Check whether the encoding is known
        try:
            codec = codecs.lookup(name)
            return codec.name
        except LookupError:
            # The standard encoding error does not indicate the encoding
            raise UnkownEncodingError(name)

    def contentChanged(self):
        """Triggered when the file is changed"""
        super().contentChanged()
        get_app().MainFrame.outlineview.LoadOutLine(self)

    def InsertCommentTemplate(self, insert_line=0):
        insert_line = self.get_shebang_encoding_line()
        codeview.CodeView.InsertCommentTemplate(self, insert_line)

    def get_shebang_encoding_line(self):
        lines = self.GetCtrl().GetTopLines(constants.ENCODING_DECLARE_LINE_NUM)
        encoding_line = utility.get_python_coding_declare(lines)[1]
        shebang_line = -1
        for i, line in enumerate(lines):
            match = re.match(
                r'#!\s*(/usr/bin/python|/usr/env/bin\s*python)', line.strip())
            if match is not None:
                shebang_line = i + 1
                break
        if shebang_line > encoding_line:
            return shebang_line
        return 0 if encoding_line < 0 else encoding_line


class PythonCtrl(codeview.CodeCtrl):
    TYPE_POINT_WORD = "."
    IMPORT_KEYWORD = "import"
    FROM_KEYWORD = "from"
    IMPORT_COMPLETION_LISTID = 1

    def __init__(self, master, view):
        super().__init__(master, view)
        # 设置触发鼠标移动的时间, 设置为500毫秒
        self.call(QsciScintilla.SCI_SETMOUSEDWELLTIME, 500)
        # 鼠标放在文本上方移动,显示文本的提示文档信息
        self.SCN_DWELLSTART.connect(self.on_dwell_start)
        self.userListActivated.connect(self.__completionlist_selected)
        self.SCN_CHARADDED.connect(self.__on_char_added)
        # 注册代码提示文本框图标id
        self.__registerimages()

    def __registerimages(self):
        """
        Private method to register images for autocompletion lists.
        """
        # finale size of the completion images
        self.registerImage(iconid.CLASS_ID, qtimage.load_image(
            "python/autocmp/class.png"))
        self.registerImage(
            iconid.CLASS_PROTECTED_ID,
            qtimage.load_image("python/autocmp/class_protected.png"),
        )
        self.registerImage(
            iconid.CLASS_PRIVATE_ID, qtimage.load_image(
                "python/autocmp/class_private.png")
        )
        self.registerImage(
            iconid.METHOD_ID, qtimage.load_image("python/autocmp/method.png")
        )
        self.registerImage(
            iconid.METHOD_PROTECTED_ID,
            qtimage.load_image("python/autocmp/method_protected.png"),
        )
        self.registerImage(
            iconid.METHOD_PRIVATE_ID, qtimage.load_image(
                "python/autocmp/method_private.png")
        )
        self.registerImage(
            iconid.ATTRIBUTE_ID, qtimage.load_image(
                "python/autocmp/attribute.png")
        )
        self.registerImage(
            iconid.ATTRIBUTE_PROTECTED_ID,
            qtimage.load_image("python/autocmp/attribute_protected.png"),
        )
        self.registerImage(
            iconid.ATTRIBUTE_PRIVATE_ID,
            qtimage.load_image("python/autocmp/attribute_private.png"),
        )
        self.registerImage(iconid.ENUM_ID, qtimage.load_image(
            "python/autocmp/enum.png"))
        self.registerImage(
            iconid.KEYWORDS_ID, qtimage.load_image(
                "python/autocmp/keywords.png")
        )
        self.registerImage(
            iconid.MODULE_ID, qtimage.load_image("python/autocmp/module.png")
        )

    def on_dwell_start(self, position, x, y):
        '''
        鼠标悬停在python文档上方时的触发函数
        '''
        utils.get_logger().debug(
            "dwell start position is %d, x is %d, y is %d",
            position,
            x,
            y
        )
        if self.is_word_range():
            # 调试器运行时是否鼠标悬停时显示内存变量值
            show_tips = utils.profile_get_int(
                globalkeys.SHOW_TIPVALUE_WHEN_DEBUGGING_KEY, True)
            if BaseDebuggerUI.DebuggerRunning() and show_tips:
                dwellword = self.get_current_word()
                utils.get_logger().debug('current dwell word is %s', dwellword)
                if not dwellword:
                    return
                if not get_app().GetDebugger()._debugger_ui._toolEnabled:
                    return
                watch_obj = watchs.Watch.CreateWatch(dwellword, dwellword)
                nodelist = get_app().GetDebugger(
                )._debugger_ui.framestab.stackFrameTab.GetWatchList(watch_obj)
                if len(nodelist) == 1:
                    watch_value = nodelist[0].childNodes[0].getAttribute(
                        "value")
                    watch_type = nodelist[0].childNodes[0].getAttribute("type")
                    utils.get_logger().debug(
                        'dwell word %s, mem value is %s, mem type is %s',
                        dwellword,
                        watch_value,
                        watch_type
                    )
                    pos = self.get_current_pos()
                    # 不显示未知类型的值
                    if watch_type != debugcfg.DEBUG_UNKNOWN_VALUE_TYPE:
                        show_text = dwellword + ":" + watch_value
                        self.call(
                            QsciScintilla.SCI_CALLTIPSHOW,
                            pos,
                            self._encodeString(show_text)
                        )

    def CreatePopupMenu(self):
        super().CreatePopupMenu()
        menubar = get_app().Menubar
        self._menu.add_separator()
        run_menu = find_menu(_("&Run"), menubar)
        self._menu.AppendItem(run_menu.FindMenuItem(
            menuitems.ID_TOGGLE_BREAKPOINT))
        edits_menu = find_menu(_("&Edit"), menubar)
        self._menu.Append(menuitems.ID_OUTLINE_SYNCTREE, _(
            "Find in Outline view"), handler=self.SyncOutline)
        menu_item = edits_menu.FindMenuItem(menuitems.ID_GOTO_DEFINITION)
        self._menu.AppendItem(menu_item)
        occurrences_menu_item = edits_menu.FindMenuItem(
            menuitems.ID_FIND_OCCURRENCES
        )
        self._menu.AppendItem(occurrences_menu_item)
        self._menu.Append(
            menuitems.ID_EXECUTE_CODE,
            _("&Execute Code in interpreter"),
            handler=self.exec_code,
            tester=self.hasSelection
        )

        self._menu.AppendItem(run_menu.FindMenuItem(
            menuitems.ID_RUN), handler=self.RunScript)

        debug_menu = NewQMenu(_("Debug"))
        self._menu.AppendMenu(newid(), debug_menu)
        debug_menu.AppendItem(run_menu.FindMenuItem(
            menuitems.ID_DEBUG), handler=self.DebugRunScript)
        debug_menu.Append(
            menuitems.ID_BREAK_INTO_DEBUGGER,
            _("&Break into debugger"),
            handler=self.BreakintoDebugger
        )
        if BaseDebuggerUI.DebuggerRunning():
            self._menu.Append(
                menuitems.ID_QUICK_ADD_WATCH,
                _("&Quick add watch"),
                img=watchs.getQuickAddWatchBitmap(),
                handler=self.QuickAddWatch
            )
            self._menu.Append(
                menuitems.ID_ADD_WATCH,
                _("&Add watch"),
                img=watchs.getAddWatchBitmap(),
                handler=self.AddWatch
            )
            self._menu.Append(
                menuitems.ID_ADD_TO_WATCH,
                _("&Add to watch"),
                img=watchs.getAddtoWatchBitmap(),
                handler=self.AddtoWatch
            )

    def exec_code(self):
        first, last = self.get_selection()
        code = self.get(first, last)
        get_app().MainFrame.activateBottomTab(
            constants.PYTHON_INTERPRETER_VIEW_NAME
        )
        python_interpreter_view = get_app().MainFrame.GetView(
            constants.PYTHON_INTERPRETER_VIEW_NAME
        )
        python_interpreter_view.Runner.send_command(
            ToplevelCommand("execute_source", source=code))

    def ToogleBreakpoint(self):
        line_no = self.get_current_line()
        get_app().GetDocumentManager().GetCurrentView().ToogleBreakpoint(line_no)

    def SyncOutline(self):
        line_no = self.get_current_line()
        get_app().MainFrame.outlineview.SyncToPosition(
            get_app().GetDocumentManager().GetCurrentView(),
            line_no
        )
        get_app().MainFrame.activateOutlineTab()

    def DebugRunScript(self):
        view = get_app().GetDocumentManager().GetCurrentView()
        if view is None or view.GetDocument() is None:
            QMessageBox.warning(self, _('Warning'), _(
                'There is not active run file'))
            return
        get_app().GetDebugger().RunWithoutDebug(view.GetDocument().GetFilename())

    def QuickAddWatch(self):
        '''
            快速添加监视,弹出监视对话框,监视的名称和表达式初始一样
        '''
        self.AddWatchText(quick_add=True)

    def AddWatch(self):
        '''
            添加监视,弹出监视对话框,监视的名称和表达式初始不一样
        '''
        self.AddWatchText()

    def AddtoWatch(self):
        '''
            直接添加监视,不弹出监视对话框
        '''
        self.AddWatchText(add_to=True)
        get_app().MainFrame.activateTab(constants.WATCH_TAB_NAME)

    def AddWatchText(self, quick_add=False, add_to=False):
        text = ""
        if self.hasSelection():
            text = self.selectedText()
        else:
            if self.is_word_range():
                line, col = self.get_current_line_column()
                text = self.wordAtLineIndex(line, col)
        if not add_to:
            get_app().GetDebugger().AddWatchText(text, quick_add)
        elif add_to and text:
            get_app().GetDebugger().AddtoWatchText(text)

    def BreakintoDebugger(self):
        view = get_app().GetDocumentManager().GetCurrentView()
        get_app().GetDebugger().GetCurrentProject().BreakintoDebugger(
            view.GetDocument().GetFilename())

    def RunScript(self):
        view = get_app().GetDocumentManager().GetCurrentView()
        get_app().GetDebugger().Runfile(view.GetDocument().GetFilename())

    def GetFontAndColorFromConfig(self):
        return CodeEditor.CodeCtrl.GetFontAndColorFromConfig(self, configPrefix="Python")

    def getWordBoundaries(self, line, index, use_wordchars=True):
        """
        Public method to get the word boundaries at a position.

        @param line number of line to look at (int)
        @param index position to look at (int)
        @param useWordChars flag indicating to use the wordCharacters
            method (boolean)
        @return tuple with start and end indexes of the word at the position
            (integer, integer)
        """
        wc = self.wordCharacters()
        if wc is None or not use_wordchars:
            pattern = r"\b[\w_]+\b"
        else:
            wc = re.sub(r"\w", "", wc)
            pattern = r"\b[\w{0}]+\b".format(re.escape(wc))
        rx = (
            re.compile(pattern)
            if self.caseSensitive()
            else re.compile(pattern, re.IGNORECASE)
        )

        text = self.text(line)
        for match in rx.finditer(text):
            start, end = match.span()
            if start <= index <= end:
                return (start, end)

        return (index, index)

    def getWord(self, line, index, direction=0, use_wordchars=True):
        """
        Public method to get the word at a position.

        @param line number of line to look at (int)
        @param index position to look at (int)
        @param direction direction to look in (0 = whole word, 1 = left,
            2 = right)
        @param useWordChars flag indicating to use the wordCharacters
            method (boolean)
        @return the word at that position (string)
        """
        start, end = self.getWordBoundaries(line, index, use_wordchars)
        if direction == 1:
            end = index
        elif direction == 2:
            start = index
        if end > start:
            text = self.text(line)
            word = text[start:end]
        else:
            word = ""
        return word

    def getWordLeft(self, line, index):
        """
        Public method to get the word to the left of a position.

        @param line number of line to look at (int)
        @param index position to look at (int)
        @return the word to the left of that position (string)
        """
        return self.getWord(line, index, 1)

    def __completionlist_selected(self, listid, txt):
        """
        Private slot to handle the selection from the completion list.

        @param listId the ID of the user list (should be 1 or 2) (integer)
        @param txt the selected text (string)
        """
        # custom completions via plug-ins
        if listid == self.IMPORT_COMPLETION_LISTID:
            lst = txt.split()
            if len(lst) > 1:
                txt = lst[0]

            self.beginUndoAction()
            if False:  # Preferences.getEditor("AutoCompletionReplaceWord"):
                self.selectCurrentWord()
                self.removeSelectedText()
                line, col = self.getCursorPosition()
            else:
                line, col = self.getCursorPosition()
                wleft = self.getWordLeft(line, col)
                if not txt.startswith(wleft):
                    self.selectCurrentWord()
                    self.removeSelectedText()
                    line, col = self.getCursorPosition()
                elif wleft:
                    txt = txt[len(wleft):]

                if txt and txt[0] in "'\"":
                    # New in jedi 0.16: AC of dict keys
                    txt = txt[1:]
            self.insert(txt)
            self.endUndoAction()
            self.setCursorPosition(line, col + len(txt))
            self.setAutoCompletionSource(QsciScintilla.AcsAll)

    def enable_autocompletion_source(self):
        if not self.isListActive() and self.autoCompletionSource() == QsciScintilla.AcsNone:
            self.setAutoCompletionSource(QsciScintilla.AcsAll)

    def __on_char_added(self, char_number):
        """
        Private slot called to handle the user entering a character.

        @param char value of the character entered (integer)
        """
        self.enable_autocompletion_source()
        if char_number == Qt.Key_Space:
            line, col = self.get_current_line_column()
            line_text = self.get_line_text(line)
            char = line_text[col - 1]
            while char == chr(Qt.Key_Space):
                col -= 1
                try:
                    char = line_text[col]
                except IndexError:
                    break
            word = self.wordAtLineIndex(line, col)
            if word == self.IMPORT_KEYWORD:
                res = re.search(r"^\s*from\s+([\w\.]+)\s+import", line_text)
                if res is None:
                    self.show_import_list()
                else:
                    modename = res.groups()[0]
                    self.show_fromimport_list(modename)
            elif word == self.FROM_KEYWORD:
                self.show_import_list(is_from_import=True)
            else:
                res = re.match(r"^\s*from\s+.*\s+", line_text)
                res2 = re.match(r"^\s*from\s+.*\s+import", line_text)
                if res and not res2:
                    self.addtext(self.IMPORT_KEYWORD)

    def relative_path_to_abs(self, modname):
        level = 0
        for i, ch in enumerate(modname):
            if ch != '.':
                level = i
                break
        else:
            level = i + 1
        document = self.get_view().GetDocument()
        filepath = document.GetFilename()
        if len(modname) == level:
            modname = None
        else:
            modname = modname[level:]
        modpath = _code_parser.relative_path_to_abs(filepath, modname, level)
        return modpath

    def show_fromimport_list(self, modname):
        # 相对导入
        if modname[0] == ".":
            modname = self.relative_path_to_abs(modname)
            if modname is None:
                return
        fromimport_list = get_app().intellisence_mananger.get_members(modname)
        if not fromimport_list:
            return
         # 星号成员按排序顺序永远放在第一位
        fromimport_list.insert(0, '*')
        self.setAutoCompletionSource(QsciScintilla.AcsNone)
        self.showUserList(self.IMPORT_COMPLETION_LISTID, fromimport_list)

    def show_import_list(self, is_from_import=False):
        import_list = self.get_import_list()
        if not import_list:
            return
        if is_from_import:
            current_view = self.get_view()
            module_scope = current_view.Module
            if module_scope and (
                module_scope.body and not node_utils.is_main_statement(module_scope.body[-1])
            ):
                self.add_curdir_imports()

        self.setAutoCompletionSource(QsciScintilla.AcsNone)
        self.showUserList(self.IMPORT_COMPLETION_LISTID, import_list)

    def get_import_list(self):
        return get_app().intellisence_mananger.GetImportList()

    def add_curdir_imports(self):
        curproject = get_app().get_current_project()
        if curproject is None:
            return
        document = self.get_view().GetDocument()
        if document.IsNewDocument:
            return []
        filepath = document.GetFilename()
        if not os.path.exists(filepath):
            return
        filedir = os.path.dirname(filepath)
        self.add_path_imports(filepath, filedir, ".")

    def add_path_imports(self, filepath, filedir, level):
        for filename in os.listdir(filedir):
            curfilepath = os.path.join(filedir, filename)
            if os.path.isfile(curfilepath):
                if fileutils.ComparePath(curfilepath, filepath) or not utility.is_python_file(filename) \
                        or filename.find(" ") != -1 or strutils.find_chinese_character(filename):
                    continue
                elif filename == PACKAGE_INIT_FILE:
                    continue
            elif os.path.isdir(curfilepath) and not PythonPathAnalyzer.is_package_dir(curfilepath):
                continue
            import_name = level + strutils.get_filename_without_ext(filename)
            self.api.add(import_name)

    def get_current_word(self):
        line, col = self.get_current_line_column()
        word = self.wordAtLineIndex(line, col)
        return word

    def is_word_range(self, pos=None):
        if pos is None:
            pos = self.get_current_pos()
            line, col = self.get_current_line_column()
        else:
            line, col = self.lineIndexFromPosition(pos)
        word = self.wordAtLineIndex(line, col)
        if not word or word in self._lang_lexer.GetKeywords():
            return False
        style = self.styleAt(pos)
        if style in [
            # 单#号开头的注释
            QsciLexerPython.Comment,
            # 双#号开头的注释
            QsciLexerPython.CommentBlock,
            QsciLexerPython.DoubleQuotedString,
            QsciLexerPython.SingleQuotedString,
            QsciLexerPython.TripleSingleQuotedString,
            QsciLexerPython.TripleDoubleQuotedString
        ]:
            return False
        # 判断是否在注释内需要循环退格直到行列开头
        while col >= 0:
            style = self.styleAt(pos)
            utils.get_logger().debug(
                "col is %d pos is %d in func %s module %s",
                col,
                pos,
                self.is_word_range.__qualname__,
                self.is_word_range.__module__
            )
            if style in [
                # 单#号开头的注释
                QsciLexerPython.Comment,
                # 双#号开头的注释
                QsciLexerPython.CommentBlock
            ]:
                return False
            col -= 1
            pos -= 1
        return True

    def get_import_alias_node(self, importnode, line, col):
        for alias in importnode.alias:
            if alias.lineno == line and (
                alias.col_offset <= col < alias.end_col_offset
            ):
                return alias
        return importnode

    def get_def_word(self, def_node=None):
        '''
        当前鼠标所在的单词
        '''
        if def_node is None:
            def_node = self.get_def_node()
        if def_node is None:
            return self.get_current_word()
        return def_node.as_string()

    def get_def_node(self, def_scope=None):
        '''
        当前鼠标所在的语法节点
        '''
        line, col = self.get_current_line_column(plus_line=True)
        if def_scope is None:
            def_scope = self.get_def_scope(line)
        linenodes = []
        current_view = self.get_view()
        filepath = current_view.GetDocument().GetFilename()
        module_scope = current_view.Module
        module_analyzer = current_view.ModuleAnalyzer
        module_analyzer.find_line_nodes(line, linenodes, def_scope)
        if not linenodes:
            raise RuntimeError(
                f'Could not find nodes on line {line} in file {filepath}'
            )
        line_col_node = module_analyzer.find_col_node(line, col, linenodes)
        return line_col_node

    def get_def_scope(self, line=None, col=None):
        '''
        当前鼠标所在的语法范围
        '''
        if line is None:
            line = self.get_current_line(plus=True)
        if col is None:
            col = self.get_current_column()
        current_view = self.get_view()
        module_file_name = current_view.GetDocument().GetFilename()
        module_scope = current_view.Module
        module_analyzer = current_view.ModuleAnalyzer
        if module_scope is None:
            if strutils.is_none_empty(module_analyzer.SyntaxError):
                module_analyzer.parse_module(module_file_name)
                module_scope = current_view.Module
            if module_scope is None:
                ParserErrorsDialog(
                    module_file_name,
                    module_analyzer.SyntaxError,
                    self
                ).exec_()
                raise CodeSyntaxError(module_analyzer.SyntaxError)
        scope = ScopeFinder(module_scope).find_scope(line)
        utils.get_logger().debug(
            'find scope is %s in line:%d,col:%d',
            scope,
            line,
            col
        )
        return scope

    def GotoDefinition(self):
        if not self.is_word_range():
            return
        current_view = self.get_view()
        module_file_name = current_view.GetDocument().GetFilename()
        try:
            scope = self.get_def_scope()
        except CodeSyntaxError as ex:
            utils.get_logger().error(
                'parse code file %s syntax error:%s in func:%s with defword:%s',
                self.get_view().GetDocument().GetFilename(),
                str(ex),
                self.GotoDefinition.__qualname__,
                self.get_current_word()
            )
            return
        def_node = self.get_def_node(scope)
        # 行号+1
        def_line = self.get_current_line(plus=True)
        def_col = self.get_current_column()
        if def_node is None:
            utils.get_logger().error(
                "find def node error in current pos,line:%d,col:%d of file:%s",
                def_line,
                def_col,
                module_file_name
            )
            ParserErrorsDialog(
                module_file_name,
                f"Could not find node on line:{def_line},col:{def_col} in scope:{str(scope)}",
                self
            ).exec_()
            return
        utils.get_logger().debug(
            "find def node is %s in current pos,line:%d,col:%d",
            def_node,
            def_line,
            def_col
        )
        if isinstance(def_node, (nodes.Import, nodes.ImportFrom)):
            alias_node = self.get_import_alias_node(def_node, def_line, def_col)
            def_word = node_utils.get_alias_name(alias_node)
            definitions = ScopeFinder(scope).get_import_definitions(def_node, alias_node)
        else:
            def_word = self.get_def_word(def_node)
            definitions = ScopeFinder(scope).get_definitions(def_node)
        utils.get_logger().debug(
            "find def word is %s in current pos,line:%d,col:%d",
            def_word,
            self.get_current_line(),
            self.get_current_column()
        )

        if not definitions:
            definition_not_found(def_word, self)
        else:
            if len(definitions) == 1:
                definition = definitions[0]
                # 无法定位到行
                if not definition.locatable():
                    unable_locate_definition(definition.defname, self)
                    return
                if definition.typname == objtypes.MODULE:
                    get_app().GotoView(definition.path, lineNum=0, colno=0, load_outline=False)
                else:
                    if definition.path is not None and fileutils.ComparePath(definition.path, module_file_name):
                        if definition.line is not None:
                            current_view.GotoPos(
                                definition.line - 1, definition.col)
                        else:
                            utils.get_logger().debug("definition name %s cannot goto line in path %s",
                                                     def_word, definition.path)
                            unable_locate_definition(def_word, self)
                    else:
                        get_app().GotoView(
                            definition.path,
                            lineNum=definition.line - 1,
                            colno=definition.col,
                            load_outline=False
                        )
            else:
                show_definitions_dialog(definitions, current_view)

    def is_edit_disabled(self):
        '''
            调试器运行时是否允许编辑代码文件,新建文件除外
        '''
        if utils.profile_get_int(globalkeys.DISABLE_EDIT_WHEN_DEBUGGERING_KEY, True) and BaseDebuggerUI.DebuggerRunning():
            return True
        return False

    def GetTopLines(self, line_num):
        lines = []
        for index in range(line_num):
            linetext = self.get_line(index)
            if linetext is not None:
                lines.append(linetext)
        return lines

    def load_api(self):
        super().load_api()
        builtin_module = get_app().intellisence_mananger.dataloader.BuiltinModule
        if builtin_module is not None:
            builtin_api_file = builtin_module.apifile
            self._api.load(builtin_api_file)

    def update_lexer_configs(self):
        super().update_lexer_configs()
        # 是否启用函数参数提示功能
        calltip_enabled = utils.profile_get_int(
            globalkeys.CALLTIP_ENABLED_KEY, True)
        if calltip_enabled:
            self.setCallTipsStyle(QsciScintilla.CallTipsNoContext)
            self.setCallTipsVisible(0)
            self.setCallTipsPosition(QsciScintilla.CallTipsBelowText)
        else:
            self.setCallTipsStyle(QsciScintilla.CallTipsNone)

    def get_margins_width(self):
        '''
            python代码文件,包含行号标签栏和断点标记页边,代码折叠页边的宽度
        '''
        margin_width = super().get_margins_width()
        # python代码文件多包行断点标记页边的宽度
        return margin_width + self.get_margin_width(DEFAULT_MARGIN_INDEX)

    def MarkerAdd(self, line):
        super().MarkerAdd(line)
        self.setReadOnly(self.is_edit_disabled())


class IntelliSenseOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    A general options panel that is used in the OptionDialog to configure the
    generic properties of a pydocview application, such as "show tips at startup"
    and whether to use SDI or MDI for the application.
    """

    def __init__(self, master):
        """
        Initializes the panel by adding an "Options" folder tab to the parent notebook and
        populating the panel with the generic properties of a pydocview application.
        """
        super().__init__()
        self.layout.setAlignment(Qt.AlignTop)

        self.autocompletion_checkbox = QCheckBox(
            _("Automatic completion enabled"))
        self.layout.addWidget(self.autocompletion_checkbox)
        self.autocompletion_checkbox.setChecked(
            utils.profile_get_int(globalkeys.AUTO_COMPLETION_ENABLED_KEY, True))

        self.calltip_checkbox = QCheckBox(_("Calltip enabled"))
        self.layout.addWidget(self.calltip_checkbox)
        self.calltip_checkbox.setChecked(
            utils.profile_get_int(globalkeys.CALLTIP_ENABLED_KEY, True))

        self.tooltips_checkbox = QCheckBox(
            _("Tips for document info when mouse hover over the tabs"))
        self.layout.addWidget(self.tooltips_checkbox)
        self.tooltips_checkbox.setChecked(
            utils.profile_get_int(globalkeys.DOCINFO_TIPS_ENABLED_KEY, True))

    def OnOK(self, options_dialog):
        utils.profile_set(globalkeys.CALLTIP_ENABLED_KEY,
                          self.calltip_checkbox.isChecked())
        utils.profile_set(globalkeys.AUTO_COMPLETION_ENABLED_KEY,
                          self.autocompletion_checkbox.isChecked())
        utils.profile_set(globalkeys.DOCINFO_TIPS_ENABLED_KEY,
                          self.tooltips_checkbox.isChecked())
        notebook = get_app().MainFrame.GetNotebook()
        for index in range(notebook.count()):
            view_frame = notebook.widget(index)
            view = view_frame.GetView()
            if isinstance(view, codeview.CodeView):
                view.update_lexer_configs()
        return True
