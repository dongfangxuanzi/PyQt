from ...project.resolver import model as projectmodel
from ...project.resolver import xmlutils
from ...project.resolver.const import PROJECT_NAMESPACE_URL


class PythonProject(projectmodel.Project):

    __xmlexclude__ = getattr(projectmodel.Project,
                             '__xmlexclude__') + ('interpreter', )

    def __init__(self):
        super().__init__()
        self._interpreter = ProjectInterpreter(self)
        self.interpreter = None
        self._runinfo.DocumentTemplate = "novalapp.python.project.view.PythonProjectTemplate"

    def update_interpreter_info(self, interpreter):
        # self.interpreter = InterpreterManager.manager().GetInterpreterByName(name)
        self._interpreter = ProjectInterpreter(
            self, interpreter.name, interpreter.Version, interpreter.path)


class ProjectInterpreter:
    __xmlexclude__ = ('_parentProj', 'interpreter')
    __xmlname__ = "_interpreter"
    __xmlattributes__ = ["name", 'version', 'path']
    __xmldefaultnamespace__ = xmlutils.AG_NS_URL

    def __init__(self, parent=None, name='', version=None, path=None):
        self._parentProj = parent
        # name, version, path属性名称必须和项目xml文件里面节点的interpreter属性名称一致
        # 在保存文件时会将这些属性转换为相应的xml属性
        self.name = name
        self.version = version
        self.path = path


# Python项目文件的已知节点类型列表，增加了interpreter和_runinfo2个节点类型
projectmodel.KNOWNTYPES = {
    "%s:project" % PROJECT_NAMESPACE_URL: PythonProject,
    "%s:file" % PROJECT_NAMESPACE_URL: projectmodel.ProjectFile,
    "%s:_interpreter" % PROJECT_NAMESPACE_URL: ProjectInterpreter,
    "%s:_runinfo" % PROJECT_NAMESPACE_URL: projectmodel.RunInfo
}
