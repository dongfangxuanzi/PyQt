# -*- coding: utf-8 -*-
import os
from .... import get_app, _
from ...interpreter.interpretermanager import InterpreterManager
from ....util import ui_utils, strutils, fileutils
from ....syntax.syntax import SyntaxThemeManager
from ....syntax import lang
from ....lib.pyqt import QTreeWidget, QTreeWidgetItem, Qt, QMessageBox
from .... import qtimage
from ... import utility


class ProjectFolderPathDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, title, project_model):
        super().__init__(title, parent)
        self._current_project = project_model
        rootPath = project_model.homeDir
        self.treeview = QTreeWidget(self)
        self.treeview.setHeaderHidden(True)
        self.layout.addWidget(self.treeview)

        self.folder_bmp = qtimage.load_icon("project/python/packagefolder_obj.gif")

        root_item = QTreeWidgetItem()
        root_item.setText(0, os.path.basename(rootPath))
        root_item.setIcon(0, self.folder_bmp)
        root_item.setData(0, Qt.UserRole, rootPath)
        self.treeview.invisibleRootItem().addChild(root_item)
        self.ListDirItem(root_item, rootPath)
        root_item.setExpanded(True)
        self.treeview.setCurrentItem(root_item)
        self.create_standard_buttons()

    def ListDirItem(self, parent_item, path):
        if not os.path.exists(path):
            return
        files = os.listdir(path)
        for f in files:
            file_path = os.path.join(path, f)
            if os.path.isdir(file_path) and not fileutils.is_path_hidden(file_path):
                diritem = QTreeWidgetItem()
                diritem.setText(0, f)
                diritem.setIcon(0, self.folder_bmp)
                diritem.setData(0, Qt.UserRole, file_path)
                parent_item.addChild(diritem)
                self.ListDirItem(diritem, file_path)

    def _ok(self):
        path = fileutils.getRelativePath(
            self.treeview.currentItem().data(0, Qt.UserRole),
            self._current_project.homeDir
        )
        self.selected_path = path
        super()._ok()


class SelectModuleFileDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, title, project_model, is_startup=False, filters=[]):
        super().__init__(title, parent)
        self.module_file = None
        if filters == []:
            filters = SyntaxThemeManager.manager().GetLexer(lang.ID_LANG_PYTHON).Exts
        self.filters = filters
        self.is_startup = is_startup
        self._current_project = project_model
        rootPath = project_model.homeDir
        self.treeview = QTreeWidget(self)
        self.treeview.setHeaderHidden(True)
        self.layout.addWidget(self.treeview)

        self.folder_bmp = qtimage.load_icon("project/python/packagefolder_obj.gif")
        self.python_file_bmp = qtimage.python_icon()

        self.zip_file_bmp = qtimage.load_image("project/zip.png")

        root_item = QTreeWidgetItem()
        root_item.setText(0, os.path.basename(rootPath))
        root_item.setIcon(0, self.folder_bmp)
#        rootitem.setData(0, Qt.UserRole,path)
        self.treeview.invisibleRootItem().addChild(root_item)

       # root_item = self.treeview.tree.insert("","end",text=os.path.basename(rootPath),image=self.folder_bmp)
        self.ListDirItem(root_item, rootPath)
        root_item.setExpanded(True)
        self.create_standard_buttons()

    def ListDirItem(self, parent_item, path):
        if not os.path.exists(path):
            return
        files = os.listdir(path)
        for f in files:
            file_path = os.path.join(path, f)
            if os.path.isfile(file_path) and self.IsFileFiltered(file_path):
                pj_file = self._current_project.FindFile(file_path)
                if pj_file:
                    if utility.is_python_file(file_path):
                        fileitem = QTreeWidgetItem()
                        fileitem.setText(0, f)
                        fileitem.setIcon(0, self.python_file_bmp)
                        fileitem.setData(0, Qt.UserRole, file_path)
                        parent_item.addChild(fileitem)
                    else:
                        item = self.treeview.tree.insert(parent_item, "end", text=f,
                                                         image=self.zip_file_bmp, values=(file_path,))
                    # 加粗项目启动文件的字体
                    if pj_file.IsStartup and self.is_startup:
                        font = fileitem.font(0)
                        font.setBold(True)
                        fileitem.setFont(0, font)
            elif os.path.isdir(file_path) and not fileutils.is_path_hidden(file_path):
                diritem = QTreeWidgetItem()
                diritem.setText(0, f)
                diritem.setIcon(0, self.folder_bmp)
                parent_item.addChild(diritem)
                self.ListDirItem(diritem, file_path)

    def _ok(self):
        pj_file = self.treeview.currentItem().data(0, Qt.UserRole)
        if pj_file is None:
            QMessageBox.information(self, get_app().GetAppName(), _("Please select a file"))
            return
        self.module_file = pj_file
        super()._ok()

    def IsFileFiltered(self, file_path):
        file_ext = strutils.get_file_extension(file_path)
        return file_ext in self.filters


class DefinitionsDialog(ui_utils.BaseModalDialog):

    def __init__(self, parent, current_view, definitions):
        super().__init__(_('Multiple Definitions'), parent)
        # ,width=400
        self.current_view = current_view
        v = tk.StringVar()
        self.definitions = definitions
        strings = self.GetStrings(definitions)
        self.listbox = ui_utils.ThemedListbox(self.main_frame, listvariable=v, height=max(len(strings), 5))
        self.listbox.bind('<Double-Button-1>', self._ok)
        v.set(tuple(strings))
        self.listbox.selection_set(0)
        self.listbox.pack(expand=1, fill="both", padx=consts.DEFAUT_CONTRL_PAD_X)
        self.AddokcancelButton()

    def GetStrings(self, definitions):
        lines = []
        for definition in definitions:
            if self.current_view.GetDocument().GetFilename() == definition.Root.Module.Path:
                path = os.path.basename(self.current_view.GetDocument().GetFilename())
            else:
                path = definition.Root.Module.Path
            line = "%s- (%d,%d) %s" % (path, definition.Node.Line, definition.Node.Col, "")
            lines.append(line)
        return lines

    def _ok(self, event=None):
        i = self.listbox.curselection()[0]
        if i < 0:
            return
        definition = self.definitions[i]
        GetApp().GotoView(definition.Root.Module.Path, definition.Node.Line, load_outline=False)
        ui_base.CommonModaldialog._ok(self, event)


class CommonInterpreterOptionPanel(ui_utils.BaseConfigurationPanel):

    def get_current_interpreter(self):
        return InterpreterManager.manager().GetCurrentInterpreter()


class PythonBaseConfigurationPanel(CommonInterpreterOptionPanel):

    def __init__(self, master, current_project, **kw):
        self.current_project_document = current_project
        super().__init__(master)

    def DisableNoPythonfile(self, item):
        '''
            非python文件时某些配置面板是不可选的
        '''
        if item is None:
            return
        else:
            project_view = self.current_project_document.GetFirstView()
            if project_view._treeCtrl.GetRootItem() == item:
                return
            self.select_project_file = project_view._GetItemFile(item)
            if not utility.is_python_file(self.select_project_file.filePath):
                self.DisableUI(self)

    def GetItemFile(self, item):
        return self.current_project_document.GetFirstView()._GetItemFile(item)
