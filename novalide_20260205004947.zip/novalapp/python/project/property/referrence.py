import os
from .... import _, get_app
from ....util import ui_utils, utils
from ....lib.pyqt import QHBoxLayout, QLabel, QListWidget, QPushButton, QVBoxLayout, Qt
from ..document import PythonProjectDocument


class ProjectReferrencePanel(ui_utils.BaseConfigurationPanel):
    def __init__(self, parent, item, current_project):
        super().__init__()
        self._current_project = current_project
        project_statictext_label = QLabel(
            _("Project may refer to other projects.The reference project path will append to the PYTHONPATH of current project.\n"))
        # 如果文字超出了边框大小自动换行
        project_statictext_label.setWordWrap(True)
        self.layout.addWidget(project_statictext_label)
        self.layout.addWidget(
            QLabel(_("The reference projects for '%s':") % self.GetProjectName()))

        hbox = QHBoxLayout()
        self.listbox = QListWidget()
        hbox.addWidget(self.listbox)
        rightbox = QVBoxLayout()
        rightbox.setAlignment(Qt.AlignTop)
        select_all_btn = QPushButton(_("Select All"))
        rightbox.addWidget(select_all_btn)
        select_all_btn.clicked.connect(self.select_all)
        unselect_all_btn = QPushButton(_("UnSelect All"))
        rightbox.addWidget(unselect_all_btn)
        unselect_all_btn.clicked.connect(self.unselect_all)
        hbox.addLayout(rightbox)
        self.layout.addLayout(hbox)
        # 所有项目列表
        self.documets = []
        self.LoadProjects()

    def GetProjectName(self):
        return os.path.basename(self._current_project.GetFilename())

    def OnOK(self, options_dialog):
        ref_project_files = self.GetReferenceProjects()
        # 存储引用的项目文件路径,将项目路径添加到引用项目的PYTHONPATH列表中去
        utils.profile_set(self._current_project.GetKey() +
                          "/ReferenceProjects", ref_project_files)
        return True

    def select_all(self):
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            if listitem.checkState() == Qt.Unchecked:
                listitem.setCheckState(Qt.Checked)

    def unselect_all(self):
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            if listitem.checkState() == Qt.Checked:
                listitem.setCheckState(Qt.Unchecked)

    def LoadProjects(self):
        ref_project_names = utils.profile_get(
            self._current_project.GetKey() + "/ReferenceProjects", [])
        current_project_document = get_app().MainFrame.projectview.GetCurrentProject()
        for document in get_app().MainFrame.projectview.GetOpenProjects():
            # 必须是python项目才能引用
            if document == current_project_document or not isinstance(document, PythonProjectDocument):
                continue
            project_name = document.GetModel().Name
            self.listbox.addItem(project_name)
            i = self.listbox.count()
            listitem = self.listbox.item(i - 1)
            if document.GetFilename() in ref_project_names:
                listitem.setCheckState(Qt.Checked)
            else:
                listitem.setCheckState(Qt.Unchecked)
            self.documets.append(document)

    def GetReferenceProjects(self):
        projects = []
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            if listitem.checkState() == Qt.Checked:
                projects.append(self.documets[i].GetFilename())
        return projects
