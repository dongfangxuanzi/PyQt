from .... import _
from ....lib.pyqt import QHBoxLayout, QLabel, Qt
from ...interpreter.interpretermanager import InterpreterManager
from .. import configuration
from ....util import utils
from ....widgets.labels import LinkLabel
from ...interpreter.combo import InterpreterComboBox
from ....preference.manager import GetOptionName
from ....preference.preference import PreferenceDialog
from .runui import CommonInterpreterOptionPanel


class PythonInterpreterPanel(CommonInterpreterOptionPanel):
    def __init__(self, parent, item, current_project):
        super().__init__()
        self._current_project = current_project
        interpreter_hbox = QHBoxLayout()
        interpreter_hbox.setAlignment(Qt.AlignLeft)
        interpreter_hbox.addWidget(QLabel(_("Interpreter") + ":"))
        self.interpreter_combo = InterpreterComboBox()
        interpreter_hbox.addWidget(self.interpreter_combo)
        self.layout.addLayout(interpreter_hbox)
        hyperlink_ctrl = LinkLabel(
            _("Click to configure interpreter"), self.GotoInterpreterConfiguration)
        self.layout.addWidget(hyperlink_ctrl)
        self.layout.addStretch(1)
        project_interpreter_name = configuration.ProjectConfiguration.LoadProjectInterpreter(
            self._current_project.GetKey())
        interpreter_name_index = self.interpreter_combo.find_interpreter_index(
            project_interpreter_name)
        if interpreter_name_index != -1:
            self.interpreter_combo.setCurrentIndex(interpreter_name_index)

    def OnOK(self, options_dialog):
        if self.get_current_interpreter() is None:
            return True
        current_interpreter = self.GetInterpreter()
        utils.profile_set(self._current_project.GetKey() +
                          "/Interpreter", current_interpreter.name)
        if self._current_project.GetModel().interpreter != current_interpreter:
            self._current_project.GetModel().update_interpreter_info(current_interpreter)
            self._current_project.GetModel().interpreter = current_interpreter
            self._current_project.Modify(True)
        return True

    def GotoInterpreterConfiguration(self, event):
        preference_dlg = PreferenceDialog(
            self,
            selection=GetOptionName(
                _("Interpreter"), "InterpreterConfiguration")
        )
        if preference_dlg.exec_() == PreferenceDialog.Accepted:
            self.interpreter_combo.reload()

    def GetInterpreter(self):
        index = self.interpreter_combo.currentIndex()
        if -1 == index:
            return None
        return InterpreterManager.manager().interpreters[index]
