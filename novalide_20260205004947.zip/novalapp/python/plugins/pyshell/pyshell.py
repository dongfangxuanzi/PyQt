# -*- coding: utf-8 -*-
import sys
import os
from .... import get_app, _
from ....plugin import iface, plugin
from .... import constants, globalkeys
from ....editor.codeview import CodeCtrl
from ....syntax import lang
from ....syntax.syntax import SyntaxThemeManager
from ....util import utils, strutils
from .naming import BACKEND_BULITIN_INTERPRETER_NAME, BACKEND_CUSTOM_INTERPRETER_NAME
from . import running_py as running
from ....backend.command import ToplevelCommand
from ....backend.shell import BaseShellText, BaseShell
from ....sidebar import sidebar

runner = None


def get_runner():
    return runner


class PythonText(BaseShellText):
    def __init__(self, master=None):
        # if "indent_with_tabs" not in kw:
        # kw["indent_with_tabs"] = False
        super().__init__(master=master, shell_name="pyshell")
        self._should_tag_current_line = False

    def GetLangLexer(self):
        if self._lang_lexer is None:
            self._lang_lexer = SyntaxThemeManager().GetLexer(lang.ID_LANG_PYTHON)

    def _reload_theme_options(self, force=False):
        texteditor.TextCtrl._reload_theme_options(self, force)

    def update_appearance(self):
        '''
            shell窗口的python着色类和普通python文本的着色类稍微有点差别
        '''
        lexer = self.lexer()
        if lexer is None:
            self.GetLangLexer()
            lexer = self._lang_lexer.get_shell_lexer(self)
            # 设置渲染语言的字体
            lexer.setFont(self.font())
            lexer.setDefaultFont(self.font())
            self.setLexer(lexer)
        syntax_options = self._lang_lexer.style_items.get(
            get_app().skin['shellSyntaxTheme'], {})
        self.set_syntax(syntax_options)


class ShellText(PythonText):

    def __init__(self, master):
        super().__init__(master)
        running.PythonInteractiveInterpreter.init_prompt()

    def _init_menu(self):
        self._menu = tk.Menu(self, tearoff=False, **
                             get_style_configuration("Menu"))
        clear_seq = get_workbench().get_option(
            "shortcuts.clear_shell", _CLEAR_SHELL_DEFAULT_SEQ
        )
        self._menu.add_command(
            label="Clear shell",
            command=self._clear_shell,
            accelerator=sequence_to_accelerator(clear_seq),
        )

    def submit_command(self, cmd_line, tags):
        if not cmd_line.endswith(constants.LF):
            cmd_line += constants.LF
        assert get_runner().is_waiting_toplevel_command()
        linenum = self.lineIndexFromPosition(self.input_start)[0]
        line_end_pos = self.line_end_position(linenum)
        if line_end_pos > self.input_start:
            self.delete_target(self.input_start, line_end_pos)
        self.insert_text(self.input_start, cmd_line)
        self.move_cursor_to_end()
      #  self.mark_set("insert", "end")
        self._try_submit_input()

    def _insert_prompt(self, prompt=None, new_line=False):
        if prompt is None:
            prompt = sys.ps1
        # if previous output didn't put a newline, then do it now
        super()._insert_prompt(prompt, new_line)

    def __isCursorOnLastLine(self):
        """
        Private method to check, if the cursor is on the last line.

        @return flag indicating that the cursor is on the last line (boolean)
        """
        cline, ccol = self.getCursorPosition()
        return cline == self.lines() - 1

    def perform_return(self, event=None):
        if get_runner().is_running():
            # if we are fixing the middle of the input string and pressing ENTER
            # then we expect the whole line to be submitted not linebreak to be inserted
            # (at least that's how IDLE works)
            self.mark_set("insert", "end")  # move cursor to the end
            # Do the return without auto indent
            CodeCtrl.perform_return(self, event)
            self._try_submit_input()

        elif get_runner().is_waiting_toplevel_command():
            # Same with editin middle of command, but only if it's a single line command
            if self.__isCursorOnLastLine():
                # 按回车键时需要将光标移至行尾
                self.move_cursor_to_end()
                if event is not None:
                    CodeCtrl.keyPressEvent(self, event)
                else:
                    self.insert_new_line()
                self._try_submit_input()

    def get_submit_text(self):

        input_text = self.get("input_start", "insert")
        tail = self.get("insert", "end")

        # user may have pasted more text than necessary for this request
        submittable_text = self._extract_submittable_input(input_text, tail)

        # leftover text will be kept in widget, waiting for next request.
        start_index = self.index("input_start")
        end_index = self.index(
            "input_start+{0}c".format(len(submittable_text)))

        # apply correct tags (if it's leftover then it doesn't have them yet)

        self.tag_add("io", start_index, end_index)
        self.tag_add("stdin", start_index, end_index)

        # update start mark for next input range
        self.mark_set("input_start", end_index)

        # Move output_insert mark after the requested_text
        # Leftover input, if any, will stay after output_insert,
        # so that any output that will come in before
        # next input request will go before leftover text
        self.mark_set("output_insert", end_index)

        # remove tags from leftover text
        for tag in ("io", "stdin", "toplevel", "command"):
            # don't remove magic, because otherwise I can't know it's auto
            self.tag_remove(tag, end_index, "end")

        return submittable_text

    def _try_submit_input(self):
        # see if there is already enough inputted text to submit
        line = self.get_current_line()
        # 提交命令文本不能包含换行符
        buf = self.get_line_text(line - 1)
        if buf.startswith(sys.ps1):
            buf = buf.replace(sys.ps1, "")
        if buf.startswith(sys.ps2):
            buf = buf.replace(sys.ps2, "")
        self._submit_input(buf)

    def _extract_submittable_input(self, input_text, tail):
        if get_runner().is_waiting_toplevel_command():
            if input_text.endswith("\n"):
                if input_text.strip().startswith("%") or input_text.strip().startswith("!"):
                    # if several magic command are submitted, then take only first
                    return input_text[: input_text.index("\n") + 1]
                if self._code_is_ready_for_submission(input_text, tail):
                    return input_text
                return None
            return None
        if get_runner().is_running():
            i = 0
            while True:
                if i >= len(input_text):
                    return None
                if input_text[i] == "\n":
                    return input_text[: i + 1]
                i += 1
        return None

    def _code_is_ready_for_submission(self, source, tail=""):
        # Ready to submit if ends with empty line
        # or is complete single-line code

        if tail.strip() != "":
            return False

        # First check if it has unclosed parens, unclosed string or ending with : or \
        parser = roughparse.RoughParser(self.indent_width, self.tabwidth)
        parser.set_str(source.rstrip() + "\n")
        if (
            parser.get_continuation_type() != roughparse.C_NONE
            or parser.is_block_opener()
        ):
            return False

        # Multiline compound statements need to end with empty line to be considered
        # complete.
        lines = source.splitlines()
        # strip starting empty and comment lines
        while len(lines) > 0 and (
            lines[0].strip().startswith("#") or lines[0].strip() == ""
        ):
            lines.pop(0)

        compound_keywords = [
            "if",
            "while",
            "for",
            "with",
            "try",
            "def",
            "class",
            "async",
            "await",
        ]
        if len(lines) > 0:
            first_word = lines[0].strip().split()[0]
            if first_word in compound_keywords and not source.replace(" ", "").replace(
                "\t", ""
            ).endswith("\n\n"):
                # last line is not empty
                return False

        return True

    def process_cmd_line(self, text_to_be_submitted):
        cmd_line = text_to_be_submitted.strip()
        if cmd_line.startswith("%"):
            parts = cmd_line.split(" ", maxsplit=1)
            if len(parts) == 2:
                args_str = parts[1].strip()
            else:
                args_str = ""
            argv = strutils.parse_cmd_line(cmd_line[1:], posix=True)
            command_name = argv[0]
            cmd_args = argv[1:]

            if len(cmd_args) >= 2 and cmd_args[0] == "-c":
                # move source argument to source attribute
                source = cmd_args[1]
                cmd_args = [cmd_args[0]] + cmd_args[2:]
                if source == EDITOR_CONTENT_TOKEN:
                    source = (
                        get_workbench().get_editor_notebook().get_current_editor_content()
                    )
            else:
                source = None
        #    GetApp().event_generate("MagicCommand", cmd_line=text_to_be_submitted)
            self.get_runner().send_command(
                ToplevelCommand(
                    command_name,
                    args=cmd_args,
                    args_str=args_str,
                    cmd_line=cmd_line,
                    tty_mode=self.tty_mode,
                    source=source,
                )
            )
        elif cmd_line.startswith("!"):
            argv = strutils.parse_cmd_line(cmd_line[1:])
           # GetApp().event_generate("SystemCommand", cmd_line=text_to_be_submitted)
            self.get_runner().send_command(
                ToplevelCommand(
                    "execute_system_command",
                    argv=argv,
                    cmd_line=cmd_line,
                    tty_mode=self.tty_mode,
                    source=None
                )
            )
        else:
            self.get_runner().send_command(
                ToplevelCommand(
                    "execute_source", source=text_to_be_submitted, tty_mode=self.tty_mode
                )
            )

    def compute_smart_home_destination_index(self):
        """Is used by EnhancedText"""

        if self._in_current_input_range("insert"):
            # on input line, go to just after prompt
            return "input_start"
        return super().compute_smart_home_destination_index()

    def _hyperlink_enter(self, event):
        self.config(cursor="hand2")

    def _hyperlink_leave(self, event):
        self.config(cursor="")

    def _handle_hyperlink(self, event):
        try:
            line = self.get("insert linestart", "insert lineend")
            matches = re.findall(r'File "([^"]+)", line (\d+)', line)
            if len(matches) == 1 and len(matches[0]) == 2:
                filename, lineno = matches[0]
                lineno = int(lineno)
                if os.path.exists(filename) and os.path.isfile(filename):
                    GetApp().GotoView(filename, lineno, load_outline=False)
        except Exception:
            traceback.print_exc()

    def get_runner(self):
        return get_runner()

    def can_backend_aborted(self):
        return not (utils.profile_get(globalkeys.BACKEND_NAME_KEY, BACKEND_BULITIN_INTERPRETER_NAME) == BACKEND_BULITIN_INTERPRETER_NAME or get_runner().get_backend_proxy() is None)


class PyShell(BaseShell):
    def __init__(self, mater):
        global runner
        super().__init__(mater)
        self._builtin_exit_func = sys.exit
        self._add_main_backends()
        runner = self._runner

    def close_window(self):
        sys.exit = self._builtin_exit_func
        return True

    def GetTextCtrl(self):
        return self.text

    def focus_set(self):
        BaseShell.focus_set(self)
        if GetApp().focus_get() != self.GetTextCtrl():
            self.GetTextCtrl().focus_force()

    def UpdateShell(self):
        current_interpreter = get_app().GetCurrentInterpreter()
        backend = None
        if current_interpreter.IsBuiltIn:
            backend = BACKEND_BULITIN_INTERPRETER_NAME
        else:
            backend = BACKEND_CUSTOM_INTERPRETER_NAME
        utils.profile_set("run.backend_name", backend)
        self._runner.restart_backend(clean=True, first=False)

    def _start_runner(self):
        try:
          #  GetApp().update_idletasks()  # allow UI to complete
            self._runner.start()
        except Exception:
            utils.get_logger().exception("Error when initializing backend")

    def GetShelltextClass(self):
        return ShellText

    def GetFontName(self):
        return 'PyShellEditorFont'

    def GetRunner(self):
        return running.PythonRunner(self)

    def fixLineEndings(self, text):
        """Return text with line endings replaced by OS-specific endings."""
        lines = text.split('\r\n')
        for l in range(len(lines)):
            chunks = lines[l].split('\r')
            for c in range(len(chunks)):
                chunks[c] = os.linesep.join(chunks[c].split('\n'))
            lines[l] = os.linesep.join(chunks)
        text = os.linesep.join(lines)
        return text

    def _add_main_backends(self):
        get_app().add_backend(
            BACKEND_BULITIN_INTERPRETER_NAME,
            running.BuiltinCPythonProxy,
            _("The same interpreter which runs Thonny (default)"),
            "1",
        )
        get_app().add_backend(
            BACKEND_CUSTOM_INTERPRETER_NAME,
            running.CustomCPythonProxy,
            _("Alternative Python 3 interpreter or virtual environment"),
            "2",
        )


class PyshellViewLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)

    def Load(self):
        get_app().MainFrame.AddView(
            constants.PYTHON_INTERPRETER_VIEW_NAME,
            PyShell,
            _("Interpreter"),
            sidebar.SideBar.South,
            image_file="python/interpreter.ico",
            active=True
        )
