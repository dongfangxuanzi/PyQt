from astroid import nodes


class FixRange:
    def __init__(self, start_line, start_col=None, end_line=None, end_col=None):
        self.start_line = start_line or 1
        self.start_col = start_col or 0
        self.end_line = end_line or self.start_line
        self.end_col = end_col or self.start_col
        self.start_line -= 1
        self.end_line -= 1

    def replace_with_text(self, textview, text):
        head, tail, chars, lines = textview.get_region(
            self.start_line,
            self.start_col,
            self.end_line,
            self.end_col
        )
        textview.set_region(head, tail, chars, text.split("\n"), selrep=False)

    def replace_line(self, textview, text):
        linetext = textview.GetCtrl().get_line_text(self.start_line)
        end_col = len(textview.GetCtrl()._encodeString(linetext))
        head, tail, chars, lines = textview.get_region(
            self.start_line,
            0,
            self.end_line,
            end_col
        )
        textview.set_region(head, tail, chars, text.split("\n"), selrep=False)

    def add_text(self, textview, inserted_content):
        insert_pos = textview.GetCtrl().position_from_linecol(
            self.start_line, self.start_col)
        textview.GetCtrl().insert_text(insert_pos, inserted_content)


def get_node_range(node):
    return FixRange(node.lineno, node.col_offset, node.end_lineno, node.end_col_offset)


def get_add_range(line, col):
    return FixRange(line, col, line, col)


class ImportVisitor:
    def __init__(self, module, textview):
        self._module = module
        self._textview = textview

    def is_import_exist(self, modname):
        for child in self._module.body:
            if isinstance(child, nodes.Import):
                names = [name[0] for name in child.names]
                if modname in names:
                    return True
        return False

    def is_fromimport_exist(self, modname, import_name):
        for child in self._module.body:
            if isinstance(child, nodes.ImportFrom):
                if child.modname == modname:
                    return import_name in [name[0] for name in child.names]
        return False

    def get_lastimport_node(self):
        for i, child in enumerate(self._module.body):
            if not isinstance(child, (nodes.Import, nodes.ImportFrom)):
                if i > 0:
                    return self._module.body[i - 1]
                break
        return None

    def get_import_line(self):
        last_node = self.get_lastimport_node()
        if last_node is not None:
            return last_node.lineno
        else:
            shebang_or_encoding_line = self._textview.get_shebang_encoding_line()
            if self._module.doc_node is None:
                return shebang_or_encoding_line
            return self.get_docstring_line()

    def get_docstring_line(self):
        assert self._module.doc is not None
        return self._module.doc_node.end_lineno


class FixNode:
    def __init__(self, node, textview):
        self._node = node
        self._textview = textview

    def replace_node_with_text(self, reptext):
        fix_range = get_node_range(self._node)
        fix_range.replace_with_text(self._textview, reptext)
