import enum


class Symbol(enum.Enum):
    CLASSES = 0
    FUNCTIONS = 1
    IMPORTS = 2
    CALLS = 3
    VARS = 4
    ALL = 5
