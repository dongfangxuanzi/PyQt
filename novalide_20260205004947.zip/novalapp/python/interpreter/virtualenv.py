import os
from ... import _, get_app
from ...lib.pyqt import (
    QProgressDialog,
    QGridLayout,
    pyqtSignal,
    QLineEdit,
    QLabel,
    QPushButton,
    QCheckBox,
    Qt,
    QSizePolicy,
    QFileDialog,
    QThread,
    QMessageBox
)
from ...util import ui_utils, fileutils, utils, strutils
from .combo import InterpreterComboBox
from .interpreterconfiguration.pipenv import url_parse_host, InstallPackagesDialog
from ...async_cmd.process import AsyncProcess
from ... import constants


class NewvirtualEnv(QThread):
    VIRTUALENV_PKG_NAME = 'virtualenv'

    def __init__(self, parent, name, location, include_site_packages, interpreter):
        super().__init__(parent)
        self._name = name
        self._location = location
        self._interpreter = interpreter
        self.include_site_packages = include_site_packages
        self._progress_dlg = parent

    def run(self):
        self.CreatePythonVirtualEnv()

    def CreatePythonVirtualEnv(self):
        # 如果没有安装virtualenv工具,需要先安装后,安装后需要使用这个工具来创建python虚拟环境
        if not self._interpreter.GetInstallPackage(self.VIRTUALENV_PKG_NAME):
            utils.get_logger().info('could not find package %s in interpter %s',
                                    self.VIRTUALENV_PKG_NAME, self._interpreter.name)
            # 从配置文件获取pip源配置路径
            pip_source_path = InstallPackagesDialog.get_default_pip_source()
            utils.get_logger().info('use pip source is %s', pip_source_path)
            self._progress_dlg.SIG_APPEND_TEXT.emit(
                _("Install %s package...") % self.VIRTUALENV_PKG_NAME)
            exectable = self._interpreter.get_pip_exectable()
            exectable.args.extend(
                [
                    "install",
                    '--user',
                    self.VIRTUALENV_PKG_NAME,
                    '-i',
                    pip_source_path,
                    '--trusted-host',
                    url_parse_host(pip_source_path)
                ]
            )

            command = exectable.get_cmd()
            utils.get_logger().info('install virtualenv tool command is %s', command)
            if self._progress_dlg.wasCanceled():
                msg = 'user stop install virtualenv tool'
                utils.get_logger().warning(msg)
                self._progress_dlg.SIG_APPEND_TEXT.emit(msg)
                return
            self.run_command(command)
            if not self._interpreter.GetInstallPackage(self.VIRTUALENV_PKG_NAME):
                self._progress_dlg.SIG_APPEND_TEXT.emit(
                    self._progress_dlg.INSTALL_VIRTUALENV_FAIL_MSG)
                utils.get_logger().error(
                    'install virtualenv package in interpreter %s fail', self._interpreter.name)
                return
            utils.get_logger().info(
                'install virtualenv package in interpreter %s success', self._interpreter.name)
        else:
            utils.get_logger().info('find package %s in interpter %s',
                                    self.VIRTUALENV_PKG_NAME, self._interpreter.name)
        # 开始使用virtualenv工具创建虚拟解释器环境
        command = "%s -m virtualenv %s" % (self._interpreter.path,
                                           strutils.emphasis_path(self._location))
        if not utils.is_windows():
            root = not self.IsLocationWritable(self._location)
            if root:
                command = "pkexec " + command
        if self.include_site_packages:
            command += " --system-site-packages"
        utils.get_logger().info('install virtual interpreter command is %s', command)
        if self._progress_dlg.wasCanceled():
            msg = 'User stop install python virtual environment'
            utils.get_logger().warning(msg)
            self._progress_dlg.SIG_APPEND_TEXT.emit()
            return
        retcode = self.run_command(command)
        utils.get_logger().info('install virtual interpreter command retcode is %d', retcode)
        # 执行完成后发送进度完成消息,关闭进度条对话框
        self._progress_dlg.SIG_APPEND_TEXT.emit(constants.PROGRESS_END)

    def run_command(self, command):
        '''
            在线程中启动另外一个线程,会出现一点差异
        '''
        async_proc = AsyncProcess(self.parent())
        p = async_proc.create_process(
            command,
            self._interpreter.install_path
        )
        p.wait()
        return p.returncode


class NewVirtualEnvProgressDialog(QProgressDialog):
    '''
        不定量进度条对话框,会一直循环显示动画
    '''
    SIG_APPEND_TEXT = pyqtSignal(str)
    INSTALL_VIRTUALENV_FAIL_MSG = 'install virtualenv package fail'

    def __init__(self, parent):
        super().__init__(
            _("Please wait a minute for end new virtual env"),
            _("Cancel"),
            0,
            0,
            parent
        )
        self.setWindowTitle(_("New virtual env"))
        self.SIG_APPEND_TEXT.connect(self.appendmsg)

    def appendmsg(self, msg):
        self.setLabelText(msg.strip())
        if msg == constants.PROGRESS_END:
            utils.get_logger().info('new virtualenv progress end...')
            self.accept()
        elif msg == self.INSTALL_VIRTUALENV_FAIL_MSG:
            utils.get_logger().info(self.INSTALL_VIRTUALENV_FAIL_MSG)
            self.close()


class NewVirtualEnvDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, interpreter, interpreters, title):
        super().__init__(title, parent)
        self.layout.setAlignment(Qt.AlignTop)
        self._interpreter = interpreter
        self._interpreters = interpreters
        grid_layout = QGridLayout()
        grid_layout.addWidget(QLabel(_("Name") + ":"), 0, 0)
        self.name_ctrl = QLineEdit()
        grid_layout.addWidget(self.name_ctrl, 0, 1)

        grid_layout.addWidget(QLabel(_("Location") + ":"), 1, 0)
        self.path_ctrl = QLineEdit()
        self.path_ctrl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        grid_layout.addWidget(self.path_ctrl, 1, 1)
        self.path_ctrl.setToolTip(_("Set the location of virtual env"))
        browser_btn = QPushButton("...")
        browser_btn.clicked.connect(self.ChooseVirtualEnvPath)
        grid_layout.addWidget(browser_btn, 1, 2)

        self._interprter_choice_combo = InterpreterComboBox(
            self, self._interpreters)
        flags = self._interprter_choice_combo.flags | InterpreterComboBox.DISPLAY_INTERPRETER_PATH
        self._interprter_choice_combo.set_flags(flags)
        self._interprter_choice_combo.reload()
        self._interprter_choice_combo.set_current_interpreter(
            self._interpreter)
        self._interprter_choice_combo.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        grid_layout.addWidget(QLabel(_("Base Interpreter") + ":"), 2, 0)
        grid_layout.addWidget(self._interprter_choice_combo)
        self.layout.addLayout(grid_layout)

        self.include_sitepackges_chkbox = QCheckBox(
            _("Inherited system site-packages from base interpreter"))
        self.include_sitepackges_chkbox.setChecked(False)
        self.layout.addWidget(self.include_sitepackges_chkbox)

        self.appendto_interpreters = QCheckBox(
            _("Append to system interpreters"))
        self.appendto_interpreters.setChecked(True)
        self.layout.addWidget(self.appendto_interpreters)
        self.create_standard_buttons()

    def ChooseVirtualEnvPath(self):
        path = QFileDialog.getExistingDirectory(
            self, _("Choose the location of virtual env"), os.getcwd())
        if not path:
            return
        self.path_ctrl.setText(fileutils.opj(path))

    def _ok(self):
        name = self.name_ctrl.text().strip()
        location = self.path_ctrl.text().strip()
        if name == "":
            QMessageBox.information(
                self, get_app().GetAppName(), _("Name cann't be empty"))
            return
        if location == "":
            QMessageBox.information(
                self, get_app().GetAppName(), _("Location cann't be empty"))
            return
        interpreter = self._interprter_choice_combo.GetChooseInterpreter()
        if interpreter.IsBuiltIn:
            QMessageBox.information(self, get_app().GetAppName(), _(
                "Builin interpreter could not create virtual env"))
            return
        if interpreter.is_venv_interpreter():
            QMessageBox.information(self, get_app().GetAppName(), _(
                "Current interpreter is already virtual interpreter"))
            return

        super()._ok()
