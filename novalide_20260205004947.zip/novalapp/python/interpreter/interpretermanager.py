# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------------
# Name:        InterpreterManager.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-10
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
# -------------------------------------------------------------------------------
import sys
import os
from shutil import which
import json
import pickle
from ... import get_app, _, newid
from ...util import apputils, utils, fileutils
from . import interpreter as pythoninterpreter
from ...lib.pyqt import QMessageBox
from .exceptions import (
    NotsupportInterpreterError,
    InvalidInterpreterError,
    UnknownVersionInterpreterError,
    InterpreternameExistError,
    InterpreterpathExistError
)
from ...widgets import simpledialog
from ...common.singleton import SingletonMeta
from .interpreteradmin import InterpreterAdmin


class InterpreterManager(object, metaclass=SingletonMeta):

    KEY_PREFIX = "interpreters"

    def __init__(self):
        self.interpreters = []
        self.DefaultInterpreter = None
        self.CurrentInterpreter = None

    @staticmethod
    def manager():
        return InterpreterManager()

    @staticmethod
    def make_builtin_interpreter():
        builtin_interpreter = pythoninterpreter.BuiltinPythonInterpreter()
        builtin_interpreter.gen_id()
        builtin_interpreter.detect_help_path()
        return builtin_interpreter

    @staticmethod
    def load_interpreters_from_env(interpreters: list):
        if apputils.is_windows():
            from ...lib import registry
            INSTALL_PATH_KEY = "InstallPath"
            for root_key_name, root_key in registry.REG_ROOT_KEYS.items():
                try:
                    core_key_path = r"SOFTWARE\Python\Pythoncore"
                    pythoncore_key = registry.Registry(root_key).Open(core_key_path)
                    if pythoncore_key is None:
                        utils.get_logger().warning(
                            'open python core key %s in root key %s fail.',
                            core_key_path,
                            root_key_name
                        )
                        continue
                    with pythoncore_key:
                        for name in pythoncore_key.EnumChildKeyNames(tolower=False):
                            try:
                                child_key = pythoncore_key.Open(name)
                                install_path = child_key.Read(INSTALL_PATH_KEY)
                                interpreter_path = os.path.join(
                                    install_path, pythoninterpreter.PythonInterpreter.CONSOLE_EXECUTABLE_NAME)
                                if not os.path.exists(interpreter_path):
                                    utils.get_logger().error(
                                        "interpreter name %s path %s from reg config is not exist", name, interpreter_path)
                                    continue
                                try:
                                    interpreter = pythoninterpreter.PythonInterpreter(
                                        name, interpreter_path)
                                    interpreter.gen_id()
                                except NotsupportInterpreterError as e:
                                    utils.get_logger().warning(str(e))
                                    continue
                                assert interpreter.Id is not None
                                interpreters.insert(0, interpreter)
                                help_key = child_key.Open("Help")
                                help_path = help_key.Read(
                                    "Main Python Documentation")
                                interpreter.HelpPath = help_path
                                help_key.close_key()
                                child_key.close_key()
                                utils.get_logger().debug(
                                    "load python interpreter name:%s path:%s version:%s help path:%s",
                                    interpreter.name,
                                    interpreter.path,
                                    interpreter.Version,
                                    interpreter.HelpPath
                                )
                            except Exception as e:
                                utils.get_logger().warning(
                                    "read python child regkey %s\\%s\\%s error:%s",
                                    root_key_name,
                                    core_key_path,
                                    name,
                                    e
                                )
                                utils.get_logger().exception("read registry key error:")
                                continue
                except Exception as ex:
                    utils.get_logger().warning(
                        "load python interpreter from regkey `%s` error:%s",
                        root_key_name,
                        ex
                    )
                    utils.get_logger().exception('open enum registry keys error:')
                    continue
            # 还要到系统环境变量中去找解释器
            name = "python"
            python_path = which(name)
            if python_path is not None and os.path.exists(python_path):
                try:
                    admin = InterpreterAdmin(interpreters)
                    interpreter = admin.add_python_interpreter(
                        python_path, name)
                    interpreter.gen_id()
                    utils.get_logger().info("find interpreter path %s from system environment", python_path)
                    # 使用解释器版本号作为解释器名称
                    interpreter.name = name + interpreter.Version
                    interpreter.detect_help_path()
                except (InvalidInterpreterError, InterpreternameExistError, InterpreterpathExistError, UnknownVersionInterpreterError, NotsupportInterpreterError) as ex:
                    utils.get_logger().warning(str(ex))
        else:
            from .. import explain as explain_environment
            targets = explain_environment.get_targets("python")
            target_executables = [target[1] for target in targets]
            executable_path = sys.executable
            if executable_path not in target_executables:
                targets.append(("default", executable_path))

            for cmd, target in targets:
                interpreter = pythoninterpreter.PythonInterpreter(cmd, target)
                interpreter.gen_id()
                interpreters.append(interpreter)

    def LoadDefaultInterpreter(self):
        if self.LoadPythonInterpretersFromConfig():
            self.SetCurrentInterpreter(self.DefaultInterpreter)
            return
        self.LoadPythonInterpreters()
        if 0 == len(self.interpreters):
            if apputils.is_windows():
                QMessageBox.warning(
                    None,
                    _("Python interpreter not found"),
                    _("No python interpreter found in your computer,will use the builtin interpreter instead")
                )
            else:
                QMessageBox.warning(
                    None,
                    _("No Interpreter"),
                    _("Python interpreter not found!")
                )

        if apputils.is_windows() and None == self.GetInterpreterByName(
            pythoninterpreter.BuiltinPythonInterpreter.BUILTIN_INTERPRETER_NAME
        ):
            self.LoadBuiltinInterpreter()
        if 1 == len(self.interpreters):
            self.MakeDefaultInterpreter()
        elif 1 < len(self.interpreters):
            self.ChooseDefaultInterpreter()
        self.SetCurrentInterpreter(self.DefaultInterpreter)
        # when load interpreter first,save the interpreter info to config
        self.SavePythonInterpretersConfig()

    def ShowChooseInterpreterDlg(self, parent=None):
        choices = []
        for interpreter in self.interpreters:
            choices.append(interpreter.name)
        # 弹出解释器选择对话框时关闭启动图片
        get_app().close_splash()
        result = simpledialog.asklist(_("Choose interpreter"), _(
            "Please choose default interpreter") + ":", choices, 0)
        if result != -1:
            name = choices[result]
            interpreter = self.GetInterpreterByName(name)
            return interpreter
        return None

    def ChooseDefaultInterpreter(self):
        interpreter = self.ShowChooseInterpreterDlg()
        if interpreter:
            self.SetDefaultInterpreter(interpreter)
        else:
            QMessageBox.warning(None, _("Choose interpreter"), _(
                "No default interpreter selected, application may not run normal!"))
            del self.interpreters[:]
            self.SetDefaultInterpreter(None)

    def GetInterpreterByName(self, name):
        for interpreter in self.interpreters:
            if name == interpreter.name:
                return interpreter
        return None

    def check_interpreter_exist(self, interpreter):
        if self.GetInterpreterByName(interpreter.name):
            return True
        return False

    def GetInterpreterByPath(self, path):
        for interpreter in self.interpreters:
            if fileutils.ComparePath(path, interpreter.path):
                return interpreter
        return None

    def LoadPythonInterpreters(self):
        self.load_interpreters_from_env(self.interpreters)

    def LoadPythonInterpretersFromConfig(self):
        '''
            从配置文件或者注册表中读取python解释器信息
        '''
        config = get_app().GetConfig()
        # windows从注册吧中读取
        if apputils.is_windows():
            data = config.Read(self.KEY_PREFIX)
            if not data:
                return False
            # python3存储的是binary类型
            if isinstance(data, bytes):
                lst = pickle.loads(data)
            else:
                # 不再兼容python2存储类型
                utils.get_logger().error('load python2 interpreter config data:%s error', data)
                return False
            for l in lst:
                is_builtin = l.get('is_builtin', False)
                if is_builtin:
                    interpreter = pythoninterpreter.BuiltinPythonInterpreter(
                        l['id'],
                        init_build=False
                    )
                else:
                    interpreter = pythoninterpreter.PythonInterpreter(
                        l['name'],
                        l['path'],
                        l['id'],
                        init_build=False
                    )
                interpreter.Default = l['default']
                if interpreter.Default:
                    self.SetDefaultInterpreter(interpreter)
                data = {
                    'version': l['version'],
                    'minor_version': l.get('minor_version', ''),
                    # should convert tuple type to list
                    'builtins': list(l['builtins']),
                    # 'path_list' is the old key name of sys_path_list,we should make compatible of old version
                    'sys_path_list': l.get('sys_path_list', l.get('path_list')),
                    'python_path_list': l.get('python_path_list', []),
                    'is_builtin': is_builtin
                }
                interpreter.build_from_data(**data)
                if interpreter.IsV2():
                    utils.get_logger().warning(
                        f"python2 interpreter {l['path']} is no supported yet.")
                    continue
                interpreter.HelpPath = l.get('help_path', '')
                interpreter.Environ.SetEnviron(l.get('environ', {}))
                interpreter.Packages = interpreter.LoaPackagesFromDict(
                    l.get('packages', {}))
                self.interpreters.append(interpreter)
                path = interpreter.path
                utils.get_logger().debug('load python interpreter from app config name:%s path:%s,version:%s,builtin:%s',
                                         interpreter.name, path, interpreter.Version, interpreter.IsBuiltIn)
            if len(self.interpreters) > 1:
                return True
        else:
            # Linux从配置文件中读取
            prefix = self.KEY_PREFIX
            data = config.Read(prefix)
            if not data:
                return False
            ids = data.split(os.pathsep)
            for id in ids:
                name = config.Read("%s/%s/Name" % (prefix, id))
                path = config.Read("%s/%s/Path" % (prefix, id))
                is_default = config.ReadInt("%s/%s/Default" % (prefix, id))
                version = config.Read("%s/%s/Version" % (prefix, id))
                minor_version = config.Read(
                    "%s/%s/MinorVersion" % (prefix, id), "")
                sys_paths = config.Read("%s/%s/SysPathList" % (prefix, id))
                python_path_list = config.Read(
                    "%s/%s/PythonPathList" % (prefix, id), "")
                builtins = config.Read("%s/%s/Builtins" % (prefix, id))
                environ = json.loads(config.Read(
                    "%s/%s/Environ" % (prefix, id), "{}"))
                packages = json.loads(config.Read(
                    "%s/%s/Packages" % (prefix, id), "{}"))
                interpreter = pythoninterpreter.PythonInterpreter(
                    name, path, id, True)
                interpreter.Default = is_default
                interpreter.Environ.SetEnviron(environ)
                interpreter.Packages = interpreter.LoaPackagesFromDict(
                    packages)
                if interpreter.Default:
                    self.SetDefaultInterpreter(interpreter)
                data = {
                    'version': version,
                    'minor_version': minor_version,
                    'builtins': builtins.split(os.pathsep),
                    'sys_path_list': sys_paths.split(os.pathsep),
                    'python_path_list': python_path_list.split(os.pathsep)
                }
                interpreter.build_from_data(**data)
                self.interpreters.append(interpreter)
            if len(self.interpreters) > 0:
                return True

        return False

    def ConvertInterpretersToDictList(self):
        lst = []
        for interpreter in self.interpreters:
            assert interpreter.Id is not None
            d = {
                "id": interpreter.Id,
                "name": interpreter.name,
                "version": interpreter.Version,
                "path": interpreter.path,
                "default": interpreter.Default,
                "sys_path_list": interpreter.sys_path_list,
                "python_path_list": interpreter.python_path_list,
                "builtins": interpreter.Builtins,
                "help_path": interpreter.HelpPath,
                "environ": interpreter.Environ.environ,
                "packages": interpreter.DumpPackages(),
                "is_builtin": interpreter.IsBuiltIn,
                "minor_version": interpreter.MinorVersion
            }
            lst.append(d)
        return lst

    def SavePythonInterpretersConfig(self):
        '''
            保存解释器配置信息
        '''
        config = get_app().GetConfig()
        # windows写入注册表
        if apputils.is_windows():
            dct = self.ConvertInterpretersToDictList()
            if dct == []:
                return
            config.Write(self.KEY_PREFIX, pickle.dumps(dct))
        # Linux写入配置文件
        else:
            prefix = self.KEY_PREFIX
            id_list = [str(kl.Id) for kl in self.interpreters]
            config.Write(prefix, os.pathsep.join(id_list))
            for kl in self.interpreters:
                assert kl.Id is not None
                config.WriteInt("%s/%d/Id" % (prefix, kl.Id), kl.Id)
                config.Write("%s/%d/Name" % (prefix, kl.Id), kl.name)
                config.Write("%s/%d/Version" % (prefix, kl.Id), kl.Version)
                config.Write("%s/%d/MinorVersion" %
                             (prefix, kl.Id), kl.MinorVersion)
                config.Write("%s/%d/Path" % (prefix, kl.Id), kl.path)
                config.WriteInt("%s/%d/Default" % (prefix, kl.Id), kl.Default)
                config.Write("%s/%d/SysPathList" % (prefix, kl.Id),
                             os.pathsep.join(kl.sys_path_list))
                config.Write("%s/%d/PythonPathList" % (prefix, kl.Id),
                             os.pathsep.join(kl.python_path_list))
                config.Write("%s/%d/Builtins" % (prefix, kl.Id),
                             os.pathsep.join(kl.Builtins))
                config.Write("%s/%d/Environ" % (prefix, kl.Id),
                             json.dumps(kl.Environ.environ))
                config.Write("%s/%d/Packages" % (prefix, kl.Id),
                             json.dumps(kl.DumpPackages()))

    def RemovePythonInterpreter(self, interpreter):
        # if current interpreter has been removed,choose default interpreter as current interpreter
        if interpreter == self.CurrentInterpreter:
            self.SetCurrentInterpreter(self.GetDefaultInterpreter())
        self.interpreters.remove(interpreter)

    def SetDefaultInterpreter(self, interpreter):
        '''
            设置默认解释器
        '''
        self.DefaultInterpreter = interpreter
        for kl in self.interpreters:
            if kl.Id == interpreter.Id:
                interpreter.Default = True
            else:
                kl.Default = False

    def MakeDefaultInterpreter(self):
        self.DefaultInterpreter = self.interpreters[0]
        self.DefaultInterpreter.Default = True

    def GetDefaultInterpreter(self):
        return self.DefaultInterpreter

    def GetChoices(self):
        choices = []
        default_index = -1
        for i, interpreter in enumerate(self.interpreters):
            # set current interpreter index as default index
            if interpreter == self.CurrentInterpreter:
                default_index = i
            choices.append(interpreter.name)
        return choices, default_index

    def CheckIdExist(self, interpreter_id):
        for kb in self.interpreters:
            if kb.Id == interpreter_id:
                return True
        return False

    def GenerateId(self):
        interpreter_id = newid()
        while self.CheckIdExist(interpreter_id):
            interpreter_id = newid()
        return interpreter_id

    def IsInterpreterAnalysing(self):
        for kb in self.interpreters:
            if kb.Analysing:
                return True
        return False

    def SetCurrentInterpreter(self, interpreter):
        '''
            设置当前正在使用的解释器
        '''
        self.CurrentInterpreter = interpreter
        if interpreter is None:
            return

    def GetCurrentInterpreter(self):
        return self.CurrentInterpreter

    def LoadBuiltinInterpreter(self):
        builtin_interpreter = self.make_builtin_interpreter()
        self.interpreters.append(builtin_interpreter)

    def GetInterpreterNames(self):
        names = []
        for interpreter in self.interpreters:
            names.append(interpreter.name)
        return names
