# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        Interpreter.py
Purpose:     python解释器定义模块

Author:      wukan

Created:     2019-01-10
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import py_compile
import re
import sys
from shutil import which
import logging
import os
import io
import json
from ...util import apputils, utils, fileutils, strutils
from ...executable import Executable
from ..analysis.builtin_analyzer import BuiltinAnalyzer
from ..analysis.python_path_analyzer import PythonPathAnalyzer
from .base import Interpreter
from .exceptions import (
    BaseinterpreterNotExistError,
    NotsupportInterpreterError,
    UnknownVersionInterpreterError,
    InvalidInterpreterError,
    InterpretertoolNotExistError,
    InterpreterPathNotExistError,
    InterpreterPipNotFoundError,
    InterpreterLaunchError
)
from .intertypes import PyvenvCfg, PythonPackage, PythonpackageLocation
from ... import _

logger = logging.getLogger('ide.interpreter')


class BuiltinPythonInterpreter(Interpreter):
    BUILTIN_INTERPRETER_NAME = "Builtin_Interpreter"

    def __init__(self, interpreter_id=None, init_build=True):
        super().__init__(self.BUILTIN_INTERPRETER_NAME,
                         sys.executable, interpreter_id, init_build)
        self._is_builtin = True

    def LoadPackageList(self):
        '''
            内建解释器通过加载requirements.txt包描述文件来获取包列表
        '''
        # clear all packages first
        self._packages = {}
        self._is_loading_package = True
        app_path = utils.get_app_path()
        requirements_name = "requirements.txt"
        requirements_filepath = os.path.join(app_path, requirements_name)
        if not os.path.exists(requirements_filepath):
            name = _('Please place %s in applicaton path') % requirements_name
            self._packages[name] = PythonPackage(name, '')
            return
        filecontent = fileutils.get_file_content(requirements_filepath)
        for line in filecontent.splitlines():
            p = re.match(r"(.*)\s*==\s*(.*)", line)
            if p:
                name, version = p.groups()
                python_package = PythonPackage(name, version)
                self._packages[name] = python_package

    def IsV3(self):
        return True

    def check_syntax(self, script_path):
        origin_stderr = sys.stderr
        sys.stderr = io.StringIO()
        py_compile.compile(script_path)
        output = sys.stderr.getvalue().strip()
        sys.stderr = origin_stderr
        if 0 == len(output):
            return True, '', -1, ''
        filename, lineno, errormsg = self.parse_syntax_message(output)
        # 有语法错误,分别返回文件路径,告警行号, 告警信息
        return False, filename, lineno, errormsg

    def IsPackageExist(self, package_name):
        if package_name in self.Packages:
            return True
        return False

    def DumpPackages(self):
        return {}

    def _build_version(self):
        # python完整版本号
        self._version = ".".join([str(sys.version_info.major), str(
            sys.version_info.minor), str(sys.version_info.micro)])
        # python精简版本号,只包含major和minor
        self._minor_version = ".".join(
            [str(sys.version_info.major), str(sys.version_info.minor)])

    def _build_syspath_list(self):
        self._sys_path_list = sys.path

    def _build_builtins(self):
        self._builtins = list(sys.builtin_module_names)


class PythonInterpreter(Interpreter):

    CONSOLE_EXECUTABLE_NAME = "python.exe"
    WINDOW_EXECUTABLE_NAME = "pythonw.exe"
    PYTHON_VERSION_FLAG = "python "

    def __init__(self, name, executable_path, interpreter_id=None, init_build=True):
        if apputils.is_windows():
            self._window_path = None
            self._console_path = None
            base_executable_name = fileutils.get_filename_from_path(
                executable_path).lower()
            if base_executable_name == PythonInterpreter.WINDOW_EXECUTABLE_NAME:
                self._window_path = executable_path
                console_path = os.path.join(os.path.dirname(
                    executable_path), PythonInterpreter.CONSOLE_EXECUTABLE_NAME)
                self._console_path = console_path
                executable_path = self._console_path
            elif base_executable_name == PythonInterpreter.CONSOLE_EXECUTABLE_NAME:
                self._console_path = executable_path
                window_path = os.path.join(os.path.dirname(
                    executable_path), PythonInterpreter.WINDOW_EXECUTABLE_NAME)
                self._window_path = window_path
            if self._window_path is None and self._console_path is None:
                raise InvalidInterpreterError(
                    _("Path \"%s\" is not a valid interpreter") % executable_path)
        # 虚拟解释器配置信息,虚拟解释器时才有
        self._venvcfg = None
        super().__init__(name, executable_path, interpreter_id, init_build)
        self._is_builtin = False

    @property
    def venvcfg(self):
        return self._venvcfg

    @property
    def ConsolePath(self):
        return self._console_path

    @property
    def WindowPath(self):
        return self._window_path

    @classmethod
    def is_valid_version(cls, version_str):
        '''
            检查是否正确的python版本号
        '''
        return version_str.startswith(cls.PYTHON_VERSION_FLAG)

    @staticmethod
    def update_venv_cfg(venv_cfg_path, key, value):
        '''更新虚拟解释器配置文件信息'''
        content = fileutils.get_file_content(
            venv_cfg_path, allow_exception=False)
        if content is None:
            return
        lines = content.splitlines(keepends=True)
        for i, line in enumerate(lines):
            if line.replace(" ", "").startswith("%s=" % key):
                # 键值之间必须在等于号前后用空格隔开
                lines[i] = "%s = %s\n" % (key, value)
                break
        with open(venv_cfg_path, "w") as f:
            f.writelines(lines)

    def check_venv_cfg(self):
        base_interpreter_path = os.path.join(
            self._venvcfg.home, self.CONSOLE_EXECUTABLE_NAME)
        # 虚拟解释器的基础解释器路径不存在
        if not os.path.exists(base_interpreter_path):
            raise BaseinterpreterNotExistError(
                _("Base interpreter path \"%s\" is not exist") % base_interpreter_path)

    def is_activate_exist(self, pdir):
        '''
            是否存在解释器目录下存在activate或者activate.bat
        '''
        return (
            os.path.exists(os.path.join(pdir, "activate"))
            or os.path.exists(os.path.join(pdir, "activate.bat"))
        )

    def is_venv_interpreter(self):
        '''
            是否虚拟解释器,存在pyvenv.cfg以及activate脚本既是
        '''
        path = self.install_path
        venv_cfg_file_exist = False
        activate_exist = False
        venv_cfg_path = None
        for dirname in [".", ".."]:
            location = os.path.normpath(
                os.path.abspath(os.path.join(path, dirname)))
            cfg_path = os.path.join(location, "pyvenv.cfg")
            if os.path.isfile(cfg_path):
                venv_cfg_file_exist = True
                venv_cfg_path = cfg_path
            if self.is_activate_exist(location):
                activate_exist = True
        if venv_cfg_file_exist and activate_exist:
            self.load_venv_cfg(venv_cfg_path)
            return True
        return False

    def load_venv_cfg(self, venv_cfg_path):
        def parse_cfg_line(line):
            key, val = line.split("=", maxsplit=1)
            val = val.strip()
            return key, val
        vhome = ""
        base_executable = ""
        content = fileutils.get_file_content(
            venv_cfg_path, allow_exception=False)
        if content is None:
            return False
        for line in content.splitlines():
            if line.replace(" ", "").startswith("home="):
                vhome = parse_cfg_line(line)[1]
            elif line.replace(" ", "").startswith("base-executable="):
                base_executable = parse_cfg_line(line)[1]
        self._venvcfg = PyvenvCfg(venv_cfg_path, vhome, base_executable)

    def update_interpreter_venv_cfg(self, key, value):
        assert self._venvcfg is not None
        self.update_venv_cfg(self._venvcfg.path, key, value)

    def getminorversion(self):
        # python精简版本号,只包含major和minor
        cmd = "-c \"import sys;print(str(sys.version_info.major) + '.' +  str(sys.version_info.minor))\""
        output = self.exec_command_output(cmd)
        logger.debug('get minioversion output is %s', output)
        self._minor_version = output.strip()

    def IsV2(self):
        versions = self.Version.split('.')
        if not versions[0].isdigit():
            return False
        if int(versions[0]) == 2:
            return True
        return False

    def IsV3(self):
        versions = self.Version.split('.')
        if not versions[0].isdigit():
            return False
        if int(versions[0]) >= 3:
            return True
        return False

    def check_syntax(self, script_path):
        check_cmd = "-c \"import py_compile;py_compile.compile(r'%s')\"" % (
            script_path)
        check_syntax_cmd = self.combine_command(check_cmd)
        exitcode, stdout_str, stderr_str = self.exec_std_err_out_encoding(check_syntax_cmd)
        logger.info('check syntax cmd is %s exitcode is %d', check_syntax_cmd, exitcode)
        # 不能通过退出状态码判断语法检测是否成功, 因为即使语法检测失败退出状态码也为0
        if 0 == len(stdout_str) and 0 == len(stderr_str):
            # 语法检查通过
            return True, '', -1, ''
        output = stdout_str
        if strutils.is_none_empty(output):
            output = stderr_str
        filename, lineno, errormsg = self.parse_syntax_message(output)
        # 有语法错误,分别返回文件路径,告警行号, 告警信息
        return False, filename, lineno, errormsg

    def GetPythonLibPath(self):
        '''
            获取解释器全局安装安装时的路径
        '''
        cmd = "%s  -c \"from distutils.sysconfig import get_python_lib; print (get_python_lib())\"" % \
            (strutils.emphasis_path(self.Path),)
        python_lib_path = self.exec_command_output(cmd)
        return python_lib_path

    def GetUserLibPath(self):
        '''
            获取解释器安装包时--user参数时的HOME路径
        '''
        command = "-c \"import site;print(site.getusersitepackages())\""
        user_lib_path = self.exec_command_output(command)
        logger.debug('interpreter %s use lib path is %s',
                     self.name, user_lib_path)
        return user_lib_path

    def GetPipPath(self):
        if apputils.is_windows():
            pip_name = "pip.exe"
            pip3_name = "pip3.exe"
        else:
            pip_name = "pip"
            pip3_name = "pip3"
        python_location = os.path.dirname(self.path)
        pip_path_list = []
        # linux python3 pip tool name is pip3
        if apputils.is_windows():
            pip_path_list = [os.path.join(
                python_location, "Scripts", pip_name), os.path.join(python_location, pip_name)]
        # py3 may get pip3 as the pip tool
        pip_path_list.extend([os.path.join(
            python_location, "Scripts", pip3_name), os.path.join(python_location, pip3_name)])
        for pip_path in pip_path_list:
            if os.path.exists(pip_path):
                return pip_path
        return None

    def detect_help_path(self):
        '''
        如果是虚拟解释器,则帮助文档为基础解释器的帮助文档路径
        '''
        if self._venvcfg is not None:
            base_interpreter_path = os.path.join(
                self._venvcfg.home, self.CONSOLE_EXECUTABLE_NAME)
            self.HelpPath = Interpreter.get_help_path(
                os.path.dirname(base_interpreter_path))
        else:
            super().detect_help_path()

    def LoadPackageList(self):
        # clear all packages first
        if not os.path.exists(self.path):
            logger.error('interpreter path `%s` not exist', self.path)
            raise InterpreterPathNotExistError
        self._packages = {}
        self._is_loading_package = True
        pip_path = self.GetPipPath()
        utils.get_logger().info('pip path is %s', pip_path)
        if pip_path is not None:
            try:
                output = self.exec_pip_command("list", check_exitcode=True)
                self.load_packages_from_output(output)
            except RuntimeError as ex:
                utils.get_logger().error(
                    'interpreter `%s` exec pip list command error:%s',
                    self.name,
                    str(ex)
                )
                raise InterpreterLaunchError

    def load_packages_from_output(self, output):
        for line in output.split('\n'):
            if line.strip() == "":
                continue
            name, raw_version = line.split()[0:2]
            # filter output lines like
            '''
                Package                      Version
                ---------------------------- ---------
            '''
            if raw_version.startswith("-----") or raw_version.strip() == "Version":
                continue
            version = raw_version.replace("(", "").replace(")", "")
            python_package = PythonPackage(name, version)
            self._packages[name] = python_package

    def StopLoadingPackage(self):
        self._is_loading_package = False

    def GetInstallPackage(self, package_name):
        command = "show %s" % (package_name)
        # 实际包名称和用户输入包名称会有大小写之分
        real_package_name = None
        version = self.UNKNOWN_VERSION_NAME
        name_flag = 'Name:'
        ver_flag = 'Version:'
        location_flag = 'Location:'
        location = None
        output = self.exec_pip_command(command)
        for line in output.splitlines():
            if line.find(name_flag) != -1:
                real_package_name = line.replace(name_flag, "").strip()
            elif line.find(ver_flag) != -1:
                version = line.replace(ver_flag, "").strip()
            # 获取包安装路径,在linux用来判断卸载包时是否需要root权限
            elif line.find(location_flag) != -1:
                location = line.replace(location_flag, "").strip()
        if real_package_name is None and version == self.UNKNOWN_VERSION_NAME:
            return None
        python_package = PythonpackageLocation(real_package_name, version, location)
        return python_package

    def get_pip_exectable(self):
        pip_path = self.GetPipPath()
        exectable = Executable(pip_path)
        v_command = "-v"
        exitcode, output = exectable.exec_command_exit_output(
            v_command)
        if exitcode != 0:
            exectable = Executable(self.path, args=["-m", 'pip'])
        return exectable

    def exec_pip_command(self, command, check_exitcode=False):
        '''
        执行pip命令,首先通过pip.exe路径执行命令,如果执行失败则通过python.exe -m pip
        命令来执行
        '''
        if not os.path.exists(self.path):
            logger.error('interpreter path `%s` not exist', self.path)
            raise InterpreterPathNotExistError
        exectable = self.get_pip_exectable()
        pip_command = exectable.combine_command(command)
        logger.info("pip command is %s", pip_command)
        exectable_path = fileutils.get_filepath_from_path(self.GetPipPath())
        exitcode, output = exectable.exec_command_exit_output(
            command, cwd=exectable_path)
        if exitcode != 0 and output.find(InterpreterPipNotFoundError.ERROR_MSG) != -1:
            logger.error(output)
            raise InterpreterPipNotFoundError
        if check_exitcode and exitcode != 0:
            raise RuntimeError(output)
        return output

    def get_pkg_versions(self, pkgname):
        '''
        获取包的历史版本列表,python3.6版本之后才支持
        '''
        output = self.exec_pip_command("index versions %s" % pkgname)
        versions_flag = 'Available versions:'
        versions = []
        for line in output.splitlines():
            if line.find(versions_flag) != -1:
                versionstr = line.replace(versions_flag, "").strip()
                version_list = versionstr.split(',')
                versions = list(map(str.strip, version_list))
        return versions

    def DumpPackages(self):
        packages = {}
        for name in self._packages:
            package = self._packages[name]
            dct = {
                'name': package.name,
                'version': package.version
            }
            packages[name] = dct
        return packages

    def GetExedirs(self):
        result = []
        user_lib_path = os.path.dirname(self.GetUserLibPath())
        findpaths = [self.install_path, user_lib_path]
        for findpath in findpaths:
            main_scripts = os.path.join(findpath, "Scripts")
            if os.path.isdir(main_scripts) and main_scripts not in result:
                result.append(main_scripts)
        if self.install_path not in result:
            result.append(self.install_path)
        return result

    def find_tool(self, name):
        for exedir in self.GetExedirs():
            toolpath = os.path.join(exedir, Executable.get_exe_name(name))
            if os.path.exists(toolpath):
                return toolpath
        else:
            toolpath = which(name)
            if toolpath:
                return toolpath
            raise InterpretertoolNotExistError(
                "Tool %s is not exist in interpreter %s" % (name, self.name))

    def gen_intellisence_data(
        self,
        dbver,
        outpath,
        *,
        pathlist=[],
        multiprocess=False,
        check_updated=False
    ):
        pythonpath_analyzer = self.make_pythonpath_analyzer(
            dbver,
            outpath,
            pathlist,
            check_updated
        )
        pythonpath_analyzer.builtin_analyzer.run()
        if multiprocess:
            pythonpath_analyzer.pool_run()
        else:
            pythonpath_analyzer.run()

    def make_pythonpath_analyzer(self, dbver, outpath, pathlist=[], check_updated=False):
        builtin_analyzer = BuiltinAnalyzer(
            dbver,
            outpath,
            self
        )
        pythonpath_analyzer = PythonPathAnalyzer(
            dbver,
            outpath,
            self,
            pathlist + self._sys_path_list,
            builtin_analyzer,
            check_updated
        )
        return pythonpath_analyzer

    def gen_singlefile_data(
        self,
        filepath,
        outpath,
        *,
        pathlist=[],
    ):
        pythonpath_analyzer = self.make_pythonpath_analyzer(
            None,
            outpath,
            pathlist,
        )
        pythonpath_analyzer.make_singleapi_files(filepath)

    def find_module(self, modname):
        cmd = f"-c \"import importlib;print(importlib.import_module('{modname}').__file__)\""
        output = self.exec_command_output(cmd)
        logger.debug('find module %s cmd is:%s,output is %s',
                     modname, cmd, output)
        return output

    def _build_syspath_list(self):
        # 这里默认输出列表字符串中包含单引号,但单引号不被json允许,
        # 故需要使用json.dumps来将单引号字符串转换为双引号字符串
        run_cmd = "-c \"import sys,json;print(json.dumps(sys.path))\""
        output = self.exec_command_output(run_cmd)
        # 使用eval会产生告警,用json.loads可将列表字符串转换为列表类型
        lst = json.loads(output)
        assert isinstance(lst, list)
        logger.debug(f'python path list is {output}')
        self._sys_path_list = self.normalize_sys_path(lst)

    def _build_builtins(self):
        # 这里默认输出列表字符串中包含单引号,但单引号不被json允许,
        # 故需要使用json.dumps来将单引号字符串转换为双引号字符串
        run_cmd = "-c \"import sys,json;print(json.dumps(sys.builtin_module_names))\""
        output = self.exec_command_output(run_cmd)
        # 使用eval会产生告警,用json.loads可将列表字符串转换为列表类型
        lst = json.loads(output)
        assert isinstance(lst, list)
        # should convert tuple type to list
        logger.debug(f'builtin list is {output}')
        self._builtins = list(lst)

    def _build_version(self):
        # 如果是虚拟解释器,检查虚拟解释器配置文件pyvenv.cfg文件是否正确
        if self.is_venv_interpreter():
            self.check_venv_cfg()
        # 获取python的完整版本号
        output = self.exec_command_output("-V").lower()
        logger.debug('get python version is %s', output)
        is_suc = self.is_valid_version(output)
        if is_suc:
            self._version = output.replace(
                self.PYTHON_VERSION_FLAG, "").strip()
            # anaconda安装的python版本号是Python 3.6.5 :: Anaconda, Inc.需要从中获取正确的版本号
            if self._version.find(':') != -1:
                self._version = self._version[0:self._version.find(
                    ':')].strip()
            if self.IsV2():
                raise NotsupportInterpreterError(
                    _("Python2 interpreter is no supported yet."))
        else:
            logger.error(
                "could not get python version of interpreter %s ", self.path)
            logger.error(
                "exec interpreter %s python version cmd stdout is %s", self.path, output)
            raise UnknownVersionInterpreterError(
                _('Unkown version of interpreter path "%s"') % self.path
            )
        # 获取python的精简版本号
        self.getminorversion()
