# -*- coding: utf-8 -*-
import os
from ... import newid, _, get_app
from ...util import fileutils, ui_utils, pathutils
# import locale
from ... import qtimage
from ...bars.menubar import NewQMenu
from ...lib.pyqt import (
    QTreeWidget,
    QVBoxLayout,
    Qt,
    QPushButton,
    QHBoxLayout,
    QFileDialog,
    QTreeWidgetItem,
    QMessageBox,
    QCursor
)

ID_GOTO_PATH = newid()
ID_REMOVE_PATH = newid()
ID_COPY_PATH = newid()

ID_NEW_ZIP = newid()
ID_NEW_EGG = newid()
ID_NEW_WHEEL = newid()


class PythonpathMixin:
    """description of class"""

    def InitUI(self, hide_tree_root=False):
        self.has_root = not hide_tree_root

        hbox = QHBoxLayout()
        self.treeview = QTreeWidget(self)
        self.treeview.setHeaderHidden(True)
        hbox.addWidget(self.treeview)
        self.LibraryIcon = qtimage.load_icon("python/library_obj.gif")

        self.treeview.setContextMenuPolicy(Qt.CustomContextMenu)
        self.treeview.customContextMenuRequested.connect(
            self.OnRightClick)
        right_box = QVBoxLayout()
        right_box.setContentsMargins(0, 5, 5, 5)
        right_box.setAlignment(Qt.AlignTop)
        self.add_path_btn = QPushButton(_("Add path..."))
        self.add_path_btn.clicked.connect(self.AddNewPath)
        right_box.addWidget(self.add_path_btn)

        self.remove_path_btn = QPushButton(_("Remove path"))
        self.remove_path_btn.clicked.connect(self.RemovePath)
        right_box.addWidget(self.remove_path_btn)

        self.add_file_btn = QPushButton(_("Add file."))
        right_box.addWidget(self.add_file_btn)

        self.button_menu = self.CreatePopupMenu()
        self.add_file_btn.setMenu(self.button_menu)
        hbox.addLayout(right_box)
        self.layout.addLayout(hbox)
        # 右键弹出菜单
        self.menu = None

    def CreatePopupMenu(self):
        menu = NewQMenu(self)
        menu.Append(ID_NEW_ZIP, _("Add zip file"),
                    handler=lambda: self.AddNewFilePath(ID_NEW_ZIP))
        menu.Append(ID_NEW_EGG, _("Add egg file"),
                    handler=lambda: self.AddNewFilePath(ID_NEW_EGG))
        menu.Append(ID_NEW_WHEEL, _("Add wheel file"),
                    handler=lambda: self.AddNewFilePath(ID_NEW_WHEEL))
        return menu

    def AddNewFilePath(self, file_id):
        if file_id == ID_NEW_ZIP:
            filetypes = _("Zip file") + " (*.zip)"
            title = _("Choose a zip file")
        elif file_id == ID_NEW_EGG:
            filetypes = _("Egg file") + " (*.egg)"
            title = _("Choose a egg file")
        elif file_id == ID_NEW_WHEEL:
            filetypes = _("Wheel File") + " (*.whl)"
            title = _("Choose a wheel file")
        filename, _filetype = QFileDialog.getOpenFileName(
            self,
            title,
            None,
            filetypes
        )
        if not filename:
            return
        self.append_path(fileutils.opj(filename))

    def AddNewPath(self):
        path = QFileDialog.getExistingDirectory(
            self, _("Choose a directory to add"), os.getcwd())
        if not path:
            return
        self.append_path(fileutils.opj(path))

    def append_path(self, path):
        if not self.AddPath(path):
            QMessageBox.information(self, _("Add path"), _(
                "Path %s already exist") % path)

    def AddPath(self, path):
        if self.CheckPathExist(path):
            return False
        self.add_path_item(path)
        return True

    def add_path_item(self, path):
        pathitem = QTreeWidgetItem()
        self.GetRootItem().addChild(pathitem)
        pathitem.setText(0, path)
        pathitem.setIcon(0, self.LibraryIcon)

    def OnRightClick(self, event):
        if self.treeview.currentItem() == self.GetRootItem():
            return
        if self.menu is None:
            self.menu = NewQMenu(self)
            self.menu.Append(ID_GOTO_PATH, _("&Goto path"),
                             handler=lambda: self.TreeCtrlEvent(ID_GOTO_PATH))
            self.menu.Append(ID_REMOVE_PATH, _("&Remove path"),
                             handler=lambda: self.TreeCtrlEvent(ID_REMOVE_PATH))
            self.menu.Append(ID_COPY_PATH, _("&Copy path"),
                             handler=lambda: self.TreeCtrlEvent(ID_COPY_PATH))
        self.menu.popup(QCursor.pos())

    def TreeCtrlEvent(self, event_id):
        '''
            右键处理事件
        '''
        item = self.treeview.currentItem()
        if event_id == ID_GOTO_PATH:
            pathutils.safe_open_file_directory(item.text(0))
            return True
        if event_id == ID_REMOVE_PATH:
            self.RemovePath()
            return True
        if event_id == ID_COPY_PATH:
            ui_utils.copytoclipboard(item.text(0))
            QMessageBox.information(
                self, get_app().GetAppName(), _("Copied to clipboard"))
            return True
        return False

    def GetRootItem(self):
        if self.has_root:
            root_item = self.treeview.invisibleRootItem().child(0)
        else:
            root_item = self.treeview.invisibleRootItem()
        return root_item

    def CheckPathExist(self, path):
        root_item = self.GetRootItem()
        items_count = root_item.childCount()
        for index in range(items_count):
            item = root_item.child(index)
            if fileutils.ComparePath(item.text(0), path):
                return True
        return False

    def GetPathList(self):
        path_list = []
        root_item = self.GetRootItem()
        items_count = root_item.childCount()
        for i in range(items_count):
            item = root_item.child(i)
            path = item.text(0)
            path_list.append(path)
        return path_list

    def RemovePath(self):
        selections = self.treeview.selectedItems()
        if not selections:
            return
        for item in selections:
            self.GetRootItem().removeChild(item)

    def ConvertPath(self, path):
        sys_encoding = locale.getdefaultlocale()[1]
        try:
            return path.encode(sys_encoding)
        except:
            try:
                return path.decode(sys_encoding)
            except:
                return path
