from .interpreterpanel import BaseInterpreterPanel
from ....lib.pyqt import QListWidget


class PythonBuiltinsPanel(BaseInterpreterPanel):
    def __init__(self, parent):
        BaseInterpreterPanel.__init__(self, parent)
        self.listview = QListWidget()
        self.layout.addWidget(self.listview)

    def SetBuiltiins(self):
        self.listview.clear()
        if self._interpreter is not None:
            for name in self._interpreter.Builtins:
                self.listview.addItem(name)

    def update_ui(self):
        self.SetBuiltiins()
