# -*- coding: utf-8 -*-
import os
from .... import _, newid
from ....util import ui_utils, utils
from ...project.property.environment import BaseEnvironmentUI
from .interpreterpanel import BaseInterpreterPanel
from ....lib.pyqt import (
    QHBoxLayout,
    QCheckBox,
    QTableWidget,
    QTableWidgetItem,
    QAbstractItemView,
    QHeaderView,
    Qt,
    QCursor
)
from ....widgets.labels import LinkLabel
from ....bars.menubar import NewQMenu


class SystemEnvironmentVariableDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, title):
        ui_utils.BaseModalDialog.__init__(self, title, parent)
        columns = [_('Key'), _('Value')]

        self.table = QTableWidget(1, len(columns), self)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().hide()
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.OnContextMenu)
        self.layout.addWidget(self.table)
        self.table.setHorizontalHeaderLabels(columns)

        self.layout.addWidget(self.table)
        self.SetVariables()
        self.create_standard_buttons()
        # 右键弹出菜单
        self.menu = None
        self.CreatePopupMenu()

    def OnContextMenu(self, event):
        self.menu.popup(QCursor.pos())

    def CreatePopupMenu(self):
        self.menu = NewQMenu(self)
        self.menu.Append(newid(), _("Copy"), handler=self.copy_item)

    def copy_item(self):
        item = self.table.currentItem()
        name = item.text()
        ui_utils.copytoclipboard(name)

    def SetVariables(self):
        self.table.setRowCount(len(os.environ.keys()))
        for i, (env, value) in enumerate(os.environ.items()):
            nameitem = QTableWidgetItem(env)
            self.table.setItem(i, 0, nameitem)
            valueitem = QTableWidgetItem(value)
            self.table.setItem(i, 1, valueitem)


class EnvironmentPanel(BaseInterpreterPanel):
    def __init__(self, parent):
        BaseInterpreterPanel.__init__(self, parent)
        self.mainframe = BaseEnvironmentUI(self)
        self.layout.addWidget(self.mainframe)

        hbox = QHBoxLayout()
        hbox.setAlignment(Qt.AlignLeft)
        self.include_chkbox = QCheckBox(
            _("Include system environment variables"))
        self.include_chkbox.setChecked(True)
        hbox.addWidget(self.include_chkbox)
        link_label = LinkLabel(_("View"), self.OnGotoLink)
        hbox.addWidget(link_label)
        self.layout.addLayout(hbox)
        self.mainframe.UpdateUI()
# if self.interpreter is None:
# self.edit_btn["state"] = tk.DISABLED
# else:
# self.new_btn["state"] = "normal"

    def checkInclude(self, event):
        if self.interpreter is None:
            return
        include_system_environ = self._includeCheckBox.GetValue()
        self.interpreter.Environ.IncludeSystemEnviron = include_system_environ

    def clear_table_rows(self):
        # 清空表格所有内容
        self.mainframe.table.clearContents()
        while self.mainframe.table.rowCount():
            self.mainframe.table.removeRow(0)

    def SetVariables(self):
        self.clear_table_rows()
        if self._interpreter is not None:
            for env in self._interpreter.Environ:
                self.mainframe.AddVariable(env, self._interpreter.Environ[env])
        self.mainframe.UpdateUI()

    def update_ui(self):
        self.SetVariables()

    def OnGotoLink(self, event):
        dlg = SystemEnvironmentVariableDialog(
            self, _("System environment variables"))
        dlg.exec_()

    def IsEnvironChanged(self, dct):
        if self._interpreter is None:
            return False
        if len(dct) != self._interpreter.Environ.GetCount():
            return True
        for name in dct:
            if not self._interpreter.Environ.Exist(name):
                return True
            if dct[name] != self._interpreter.Environ[name]:
                return True
        return False

    def CheckEnviron(self):
        dct = self.mainframe.GetEnviron()
        is_environ_changed = self.IsEnvironChanged(dct)
        if is_environ_changed:
            self._interpreter.Environ.SetEnviron(dct)
            utils.get_logger().info("interpreter %s environ changed...", self._interpreter.name)
        return is_environ_changed

    def CheckAndRemoveKeyitem(self, key):
        if not ui_common.BaseEnvironmentUI.CheckAndRemoveKeyitem(self, key):
            return False
        # 检查系统环境变量中是否存在该变量
        if self.include_chkvar.get():
            if key.upper() in os.environ:
                ret = messagebox.askyesno(_("Warning"), _(
                    "Key name has already exist in system environment variable,Do you wann't to overwrite it?"), parent=self)
                if ret == False:
                    return False
        return True
