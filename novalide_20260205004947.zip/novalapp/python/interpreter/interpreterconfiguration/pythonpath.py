from .... import _
from .. import pythonpathmixin
from .interpreterpanel import BaseInterpreterPanel
from ....lib.pyqt import QTreeWidgetItem, QMessageBox
from ....util import fileutils, utils


class PythonPathPanel(BaseInterpreterPanel, pythonpathmixin.PythonpathMixin):
    def __init__(self, parent):
        BaseInterpreterPanel.__init__(self, parent)
        self.InitUI()
        self.update_ui()

    def update_ui(self):
        self.AppendSysPath()

    def AppendSysPath(self):
        self.treeview.clear()
        if self._interpreter is not None:
            rootitem = QTreeWidgetItem()
            self.treeview.invisibleRootItem().addChild(rootitem)
            rootitem.setText(0, _("Path list"))
            rootitem.setIcon(0, self.LibraryIcon)
            path_list = self._interpreter.sys_path_list + self._interpreter.python_path_list
            for path in path_list:
                self.AddPath(path)
            rootitem.setExpanded(True)
        self.update_buttons()

    def RemovePath(self):
        if self._interpreter is None:
            return
        selections = self.treeview.selectedItems()
        if not selections:
            return
        if selections[0] == self.GetRootItem():
            return
        for item in selections:
            path = item.text(0)
            if fileutils.PathsContainPath(self._interpreter.sys_path_list, path):
                QMessageBox.critical(self, _("Error"), _(
                    "The python system path could not be removed"))
                return
        super().RemovePath()

    def CheckPythonPathList(self):
        python_path_list = self.GetPythonPathFromPathList()
        is_pythonpath_changed = self.IsPythonPathChanged(python_path_list)
        if is_pythonpath_changed:
            self._interpreter.PythonPathList = python_path_list
        return is_pythonpath_changed

    def IsPythonPathChanged(self, python_path_list):
        if self._interpreter is None:
            return False
        if len(python_path_list) != len(self._interpreter.python_path_list):
            utils.get_logger().info(
                "interpreter %s pythonpath count changed...", self._interpreter.name)
            return True
        for pythonpath in python_path_list:
            if not fileutils.PathsContainPath(self._interpreter.python_path_list, pythonpath):
                utils.get_logger().info(
                    "interpreter %s pythonpath value changed...", self._interpreter.name)
                return True
        return False

    def CheckPythonPath(self):
        return self.IsPythonPathChanged(self.GetPythonPathFromPathList())

    def GetPythonPathFromPathList(self):
        if self._interpreter is None:
            return []
        path_list = self.GetPathList()
        python_path_list = []
        for path in path_list:
            if not fileutils.PathsContainPath(self._interpreter.sys_path_list, path):
                python_path_list.append(path)
        return python_path_list

    def update_buttons(self):
        if self._interpreter is None:
            self.add_path_btn.setEnabled(False)
            self.add_file_btn.setEnabled(False)
            self.remove_path_btn.setEnabled(False)
        else:
            self.add_path_btn.setEnabled(True)
            self.add_file_btn.setEnabled(True)
            self.remove_path_btn.setEnabled(True)

    def destroy(self):
        if self.menu is not None:
            self.menu.destroy()
        self.button_menu.destroy()
        ttk.Frame.destroy(self)
