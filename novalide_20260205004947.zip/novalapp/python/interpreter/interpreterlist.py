# -*- coding: utf-8 -*-
import os
from ... import newid, _, get_app
from .interpretermanager import InterpreterManager
from .interpreteradmin import InterpreterAdmin
from .exceptions import (
    InvalidInterpreterError,
    UnknownVersionInterpreterError,
    InterpreternameExistError,
    InterpreterpathExistError
)
from ... import constants
from ...bars.menubar import NewQMenu
from ...util import ui_utils, apputils, fileutils, utils, pathutils
from ...lib.pyqt import (
    QCursor,
    QProgressDialog,
    pyqtSignal,
    Qt,
    QHBoxLayout,
    QFileDialog,
    QSizePolicy,
    QLabel,
    QTableWidget,
    QPushButton,
    QMessageBox,
    QLineEdit,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView
)
from .virtualenv import NewVirtualEnvDialog, NewVirtualEnvProgressDialog, NewvirtualEnv
from ...preference import preference
from .interpreterconfiguration.packagesloader import PackagesLoader

ID_COPY_INTERPRETER_NAME = newid()
ID_COPY_INTERPRETER_VERSION = newid()
ID_COPY_INTERPRETER_PATH = newid()
ID_MODIFY_INTERPRETER_NAME = newid()
ID_REMOVE_INTERPRETER = newid()
ID_NEW_INTERPRETER_VIRTUALENV = newid()
ID_GOTO_INTERPRETER_PATH = newid()

YES_FLAG = "Yes"
NO_FLAG = "No"


class AddInterpreterDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, title, id_modify_dlg=False):
        super().__init__(title, parent)
        self.setFixedSize(500, 100)
        self._id_modify_dlg = id_modify_dlg

        path_hbox = QHBoxLayout()
        path_hbox.addWidget(QLabel(_("Path") + ":"))
        self.path_ctrl = QLineEdit()
        self.path_ctrl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        if apputils.is_windows():
            self.path_ctrl.setToolTip(
                _("Set the location of python.exe or pythonw.exe"))
        else:
            self.path_ctrl.setToolTip(
                _("Set the location of python interpreter"))
        path_hbox.addWidget(self.path_ctrl)
        self.browser_btn = QPushButton(_("Browse..."))
        self.browser_btn.clicked.connect(self.ChooseExecutablePath)
        path_hbox.addWidget(self.browser_btn)
        self.layout.addLayout(path_hbox)

        name_hbox = QHBoxLayout()
        name_hbox.addWidget(QLabel(_("Name") + ":"))
        self.name_ctrl = QLineEdit()
        # self.name_ctrl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        name_hbox.addWidget(self.name_ctrl)
        self.name_ctrl.setToolTip(_("Set the name of python interpreter"))
        self.layout.addLayout(name_hbox)
        self.create_standard_buttons()

    def ChooseExecutablePath(self):
        if apputils.is_windows():
            descrs = _("Executable") + " (*.exe)"
        else:
            descrs = _("All files") + " (*.*)"
        path, _filetype = QFileDialog.getOpenFileName(
            self,
            _('Select executable path'),
            None,
            descrs
        )
        if not path:
            return
        self.name_ctrl.setText(fileutils.opj(path))
        self.path_ctrl.setText(fileutils.opj(path))

    def _ok(self):
        if 0 == len(self.name_ctrl.text().strip()):
            QMessageBox.critical(self, _("Error"), _(
                "Interpreter name is empty"))
            return
        if not self._id_modify_dlg:
            path = self.path_ctrl.text().strip()
            if 0 == len(path):
                QMessageBox.critical(self, _("Error"), _(
                    "Interpreter path is empty"))
                return
            if not os.path.exists(path):
                QMessageBox.critical(self, _("Error"), _(
                    "Interpreter path is not exist"))
                return
        super()._ok()


class InterpreterListPanel(ui_utils.BaseConfigurationPanel):
    # 解释器显示完整路径的最大长度,否则添加省略号
    MAX_PATH_LENGTH = 50

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        interpreter_statictext = QLabel(
            _("Python interpreters(eg.:such as python.exe, pythonw.exe). Double or right click to rename.")
        )
        interpreter_statictext.setWordWrap(True)
        self.layout.addWidget(interpreter_statictext)

        columns = [_('Name'), _('Version'), _('Path'), _('Default')]
        self.tableview = QTableWidget(1, len(columns), self)
        self.tableview.setColumnWidth(0, 100)
        self.tableview.setColumnWidth(1, 70)
        self.tableview.setColumnWidth(2, 370)
        self.tableview.setColumnWidth(3, 30)
        self.tableview.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableview.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableview.horizontalHeader().setSectionResizeMode(2, QHeaderView.Interactive)
        self.tableview.setAlternatingRowColors(True)

        self.tableview.verticalHeader().hide()
        self.tableview.setHorizontalHeaderLabels(columns)
        self.tableview.itemSelectionChanged.connect(self.on_select)
        self.tableview.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.tableview.doubleClicked.connect(self.modify_interpreter_event)
        self.tableview.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tableview.customContextMenuRequested.connect(self.OnContextMenu)
        h_box = QHBoxLayout()

        rescan_btn = QPushButton(_("Rescan"))
        rescan_btn.clicked.connect(self.rescan_interpreters)
        h_box.addWidget(rescan_btn)

        add_btn = QPushButton(_("Add"))
        add_btn.clicked.connect(self.add_interpreter)
        h_box.addWidget(add_btn)

        self.remove_btn = QPushButton(_("Remove"))
        self.remove_btn.clicked.connect(self.remove_interpreter)
        h_box.addWidget(self.remove_btn)

        self.smart_analyse_btn = QPushButton(_("Smart analyse"))
        self.smart_analyse_btn.clicked.connect(self.SmartAnalyseIntreprter)
        h_box.addWidget(self.smart_analyse_btn)

        self.set_default_btn = QPushButton(_("Set default"))
        self.set_default_btn.clicked.connect(self.SetDefaultInterpreter)
        h_box.addWidget(self.set_default_btn)
        h_box.addStretch(1)

        self.layout.addLayout(h_box)
        self.layout.addWidget(self.tableview)
        self._interpreters = []
        self._current_interpreter = None
        self.ScanAllInterpreters()
        self.UpdateUI()
        # 表格右键弹出菜单
        self.menu = None

    def rescan_interpreters(self):
        interpreters = []
        InterpreterManager.manager().load_interpreters_from_env(interpreters)
        interpreters.append(InterpreterManager.make_builtin_interpreter())
        admin = InterpreterAdmin(self._interpreters)
        new_interpreters = []
        for interpreter in interpreters:
            try:
                admin.add_one_interpreter(interpreter)
                new_interpreters.append(interpreter)
            except Exception as ex:
                utils.get_logger().error("add new interpreter error:%s", str(ex))
        utils.get_logger().info('add %d new interpreters', len(new_interpreters))
        for new_interpreter in new_interpreters:
            utils.get_logger().debug(
                'add new interpreter name is %s, path is %s',
                new_interpreter.name,
                new_interpreter.path
            )
            self.append_interpreter(new_interpreter)

    def OnContextMenu(self):
        row = self.tableview.currentRow()
        if row == -1:
            return
        if self.menu is None:
            self.menu = NewQMenu(self)
            self.menu.Append(ID_COPY_INTERPRETER_NAME, _(
                "Copy Name"), handler=lambda: self.ProcessEvent(ID_COPY_INTERPRETER_NAME))
            self.menu.Append(ID_COPY_INTERPRETER_VERSION, _(
                "Copy Version"), handler=lambda: self.ProcessEvent(ID_COPY_INTERPRETER_VERSION))
            self.menu.Append(ID_COPY_INTERPRETER_PATH, _(
                "Copy Path"), handler=lambda: self.ProcessEvent(ID_COPY_INTERPRETER_PATH))
            self.menu.Append(ID_MODIFY_INTERPRETER_NAME, _(
                "Modify Name"), handler=lambda: self.ProcessEvent(ID_MODIFY_INTERPRETER_NAME))
            self.menu.Append(ID_REMOVE_INTERPRETER, _(
                "Remove"), handler=lambda: self.ProcessEvent(ID_REMOVE_INTERPRETER))
            self.menu.Append(ID_NEW_INTERPRETER_VIRTUALENV, _(
                "New VirtualEnv"), handler=lambda: self.ProcessEvent(ID_NEW_INTERPRETER_VIRTUALENV))
            self.menu.Append(ID_GOTO_INTERPRETER_PATH, _(
                "Open Path in Explorer"), handler=lambda: self.ProcessEvent(ID_GOTO_INTERPRETER_PATH))
        self.menu.popup(QCursor.pos())

    def destroy(self):
        if self.menu is not None:
            self.menu.destroy()
        ui_utils.BaseConfigurationPanel.destroy(self)

    def get_current_interpreter(self):
        row = self.tableview.currentRow()
        if row == -1:
            return None
        name = self.tableview.item(row, 0).text()
        interpreter = InterpreterAdmin(
            self._interpreters).GetInterpreterbyName(name)
        return interpreter

    def ProcessEvent(self, event_id):
        interpreter = self.get_current_interpreter()
        if interpreter is None:
            return
        row = self.tableview.currentRow()
        if event_id == ID_COPY_INTERPRETER_NAME:
            name = self.tableview.item(row, 0).text()
            ui_utils.copytoclipboard(name)
            return True
        if event_id == ID_COPY_INTERPRETER_VERSION:
            versionstr = self.tableview.item(row, 1).text()
            ui_utils.copytoclipboard(versionstr)
            return True
        if event_id == ID_COPY_INTERPRETER_PATH:
            # 路径可能显示省略号,因此不能使用界面上显示的路径值
            ui_utils.copytoclipboard(interpreter.path)
            return True
        if event_id == ID_MODIFY_INTERPRETER_NAME:
            self.ModifyInterpreterNameDlg(row)
            return True
        if event_id == ID_REMOVE_INTERPRETER:
            self.remove_interpreter()
            return True
        if event_id == ID_NEW_INTERPRETER_VIRTUALENV:
            dlg = NewVirtualEnvDialog(
                self, interpreter, self._interpreters, _("New virtual env"))
            status = dlg.exec_()
            if status == NewVirtualEnvDialog.Accepted:
                name = dlg.name_ctrl.text().strip()
                location = dlg.path_ctrl.text().strip()
                include_site_packages = dlg.include_sitepackges_chkbox.isChecked()
                appendto_system_interpreters = dlg.appendto_interpreters.isChecked()
                progress_dlg = NewVirtualEnvProgressDialog(self)
                self.CreateVirtualEnv(
                    name, location, include_site_packages, interpreter, progress_dlg)
                status = progress_dlg.exec_()
                if status == NewVirtualEnvProgressDialog.Accepted:
                    # 查找创建虚拟解释器的路径
                    if utils.is_windows():
                        python_path = os.path.join(
                            location, "Scripts\\python.exe")
                    else:
                        python_path = os.path.join(location, "bin/python")
                    # 如果虚拟解释器的路径不存在,则表示创建失败
                    if not os.path.exists(python_path):
                        QMessageBox.critical(
                            self, _("Error"), _("Create virtual env fail"))
                        return
                    QMessageBox.information(
                        self, get_app().GetAppName(), _("Create virtual env success"))
                    if appendto_system_interpreters:
                        utils.get_logger().info("interpreter %s virtual interpreter path is %s",
                                                interpreter.name, python_path)
                        try:
                            interpreter = InterpreterAdmin(
                                self._interpreters).add_python_interpreter(python_path, name)
                            self.AnalyseAddInterpreter(interpreter)
                        except (InvalidInterpreterError, UnknownVersionInterpreterError, InterpreternameExistError, InterpreterpathExistError) as e:
                            QMessageBox.critical(self, _("Error"), str(e))
                else:
                    QMessageBox.critical(
                        self, _("Error"), _("Create virtual env fail"))
            return True
        if event_id == ID_GOTO_INTERPRETER_PATH:
            self.GotoPath(interpreter.path)
            return True

    def GotoPath(self, path):
        pathutils.safe_open_file_directory(path)

    def CreateVirtualEnv(self, name, location, include_site_packages, interpreter, progress_dlg):
        NewvirtualEnv(progress_dlg, name, location,
                      include_site_packages, interpreter).start()

    def GetVirtualEnvPath(self, interpreter):
        if sysutils.is_windows():
            virtualenv_name = "virtualenv.exe"
        else:
            virtualenv_name = "virtualenv"
        python_location = os.path.dirname(interpreter.Path)
        # 模块有可能安装在解释器user路径下
        python_user_location = os.path.dirname(interpreter.GetUserLibPath())
        virtualenv_path_list = [os.path.join(python_location, "Scripts", virtualenv_name),
                                os.path.join(python_location, virtualenv_name), os.path.join(python_user_location, "Scripts", virtualenv_name)]
        for virtualenv_path in virtualenv_path_list:
            if os.path.exists(virtualenv_path):
                return virtualenv_path
        virtualenv_path = whichpath.GuessPath(virtualenv_name)
        return virtualenv_path

    def IsLocationWritable(self, location):
        '''
            判断虚拟解释器安装路径是否有写的权限
        '''
        path = location
        while not os.path.exists(path):
            path = os.path.dirname(path)
        return fileutils.is_writable(path)

    def modify_interpreter_event(self, index):
        self.ModifyInterpreterNameDlg(self.tableview.currentRow())

    def ModifyInterpreterNameDlg(self, row):
        if -1 == row:
            return
        name = self.tableview.item(row, 0).text()
        # 表格中路径可能有省略号,使用解释器中的真实路径
        interpreter = self._interpreters[row]
        path = interpreter.path
        dlg = AddInterpreterDialog(
            self, _("Modify interpreter"), id_modify_dlg=True)
        dlg.path_ctrl.setText(path)
        dlg.path_ctrl.setEnabled(False)
        dlg.browser_btn.setEnabled(False)
        dlg.name_ctrl.setText(name)
        status = dlg.exec_()
        if status == AddInterpreterDialog.Accepted:
            newname = dlg.name_ctrl.text()
            if newname != name:
                self.NotifyConfigurationChanged()
                nameitem = QTableWidgetItem(newname)
                self.tableview.setItem(row, 0, nameitem)

    def add_interpreter(self):
        dlg = AddInterpreterDialog(self, _("Add interpreter"))
        status = dlg.exec_()
        if status == AddInterpreterDialog.Accepted:
            try:
                interpreter = InterpreterAdmin(self._interpreters).add_python_interpreter(
                    dlg.path_ctrl.text(),
                    dlg.name_ctrl.text()
                )
                self.AnalyseAddInterpreter(interpreter)
            except Exception as ex:
                QMessageBox.critical(self, _("Error"), str(ex))
        self.UpdateUI()

    def AnalyseAddInterpreter(self, interpreter):
        self.append_interpreter(interpreter)
        auto_generate_database = self.parent().parent().GetOptionPanel(
            _("Interpreter"),
            preference.GENERAL_ITEM_NAME
        ).IsAutoGenerateDatabase()
        self.SmartAnalyse(interpreter, auto_generate_database)

    def append_interpreter(self, interpreter):
        count = self.tableview.rowCount()
        self.tableview.insertRow(count)
        self.AddOneInterpreter(count, interpreter)
        self.NotifyConfigurationChanged()

    def AddOneInterpreter(self, i, interpreter):
        def GetDefaultFlag(is_default):
            if is_default:
                return _(YES_FLAG)
            return _(NO_FLAG)
        path = interpreter.path
        # 必须插入末尾,和解释器列表顺序一致
        nameitem = QTableWidgetItem(interpreter.name)
        self.tableview.setItem(i, 0, nameitem)

        versionitem = QTableWidgetItem(interpreter.Version)
        self.tableview.setItem(i, 1, versionitem)

        # 路径过长显示省略号
        if len(path) > InterpreterListPanel.MAX_PATH_LENGTH:
            path = path[0:InterpreterListPanel.MAX_PATH_LENGTH] + "..."
        pathitem = QTableWidgetItem(path)
        self.tableview.setItem(i, 2, pathitem)

        defaultitem = QTableWidgetItem(GetDefaultFlag(interpreter.Default))
        self.tableview.setItem(i, 3, defaultitem)

    def remove_interpreter(self):
        row = self.tableview.currentRow()
        if row < 0:
            return
        if self.tableview.item(row, 3).text() == _(YES_FLAG):
            QMessageBox.warning(self, _("Warning"), _(
                "Default interpreter cannot be remove"))
            return
        ret = QMessageBox.question(
            self,
            _("Warning"),
            _("Interpreter remove action cannot be recover,Do you want to continue remove this interpreter?")
        )
        if ret == QMessageBox.Yes:
            name = self.tableview.item(row, 0).text()
            interpreter = InterpreterAdmin(
                self._interpreters).GetInterpreterbyName(name)
            self._interpreters.remove(interpreter)
            self.tableview.removeRow(row)
            self.NotifyConfigurationChanged()
        self.UpdateUI()

    def SetDefaultInterpreter(self):
        row = self.tableview.currentRow()
        if row < 0:
            return
        text = self.tableview.item(row, 3).text()
        if text == _(YES_FLAG):
            return
        for i in range(len(self._interpreters)):
            if i == row:
                defaultitem = QTableWidgetItem(_(YES_FLAG))
                self.tableview.setItem(i, 3, defaultitem)
            else:
                defaultitem = QTableWidgetItem(_(NO_FLAG))
                self.tableview.setItem(i, 3, defaultitem)
        self.NotifyConfigurationChanged()

    def SmartAnalyseIntreprter(self):
        interpreter = self.get_current_interpreter()
        if interpreter is None:
            return
        self.SmartAnalyse(interpreter)
        self.NotifyConfigurationChanged()

    def SmartAnalyse(self, interpreter, generate_database=True):
        try:
            # 版本号获取可能有问题,需要每次更新一下
            interpreter.build()
            interpreter.detect_help_path()
            if not interpreter.IsBuiltIn:
                configuration_panel = self.parent().parent().GetOptionPanel(
                    _("Interpreter"),
                    "InterpreterConfiguration"
                )
                self.packages_load_thread = PackagesLoader(
                    configuration_panel.package_panel, interpreter)
                self.packages_load_thread.start()
        except Exception as e:
            QMessageBox.critical(self, _("Error"), str(e))
            utils.get_logger().exception('')
            return
        self.smart_analyse_btn.setEnabled(False)
        if not generate_database:
            return
        progress_dlg = AnalyseProgressDialog(self)
        get_app().intellisence_mananger.generate_intellisence_data(interpreter, progress_dlg)
        progress_dlg.exec_()
        self.smart_analyse_btn.setEnabled(True)

    def ScanAllInterpreters(self):
        self.tableview.setRowCount(
            len(InterpreterManager.manager().interpreters))
        for i, interpreter in enumerate(InterpreterManager.manager().interpreters):
            self.AddOneInterpreter(i, interpreter)
            self._interpreters.append(interpreter)

    def on_select(self):
        self.UpdateUI()

    def UpdateUI(self):
        selection = self.tableview.currentItem()
        if not selection:
            self._current_interpreter = None
            self.smart_analyse_btn.setEnabled(False)
            self.remove_btn.setEnabled(False)
            self.set_default_btn.setEnabled(False)
        else:
            self.remove_btn.setEnabled(True)
            self.set_default_btn.setEnabled(True)
            if InterpreterManager.manager().IsInterpreterAnalysing():
                self.smart_analyse_btn.setEnabled(False)
            else:
                self.smart_analyse_btn.setEnabled(True)

    def OnOK(self, options_dialog):
        if self._configuration_changed:
            self.SaveInterpreterConfiguration()
            # 发送工具栏重新加载解释器列表的信号
            get_app().MainFrame.SIG_DEBUG_COMBO_RELOAD.emit()
        current_interpreter = InterpreterManager.manager().GetCurrentInterpreter()
        current_interpreter_changed = False
        if current_interpreter is not None:
            # if current interpreter has been removed,use the default interprter as current interpreter
            is_interpreter_exist = InterpreterManager.manager(
            ).check_interpreter_exist(current_interpreter)
            current_interpreter_changed = not is_interpreter_exist
        else:
            # set default interpreter as current interpreter
            current_interpreter_changed = True
        if current_interpreter_changed:
            InterpreterManager.manager().SetCurrentInterpreter(
                InterpreterManager.manager().GetDefaultInterpreter()
            )
        return True

    def SaveInterpreterConfiguration(self):
        # update latest interpreters
        InterpreterManager.manager().interpreters = self._interpreters
        for row in range(self.tableview.rowCount()):
            interpreter = self._interpreters[row]
            # 更新解释器名称,如果解释器名称修改的话
            name = self.tableview.item(row, 0).text()
            interpreter.name = name
            flag = self.tableview.item(row, 3).text()
            if flag == _(YES_FLAG) and interpreter != InterpreterManager.manager().GetDefaultInterpreter():
                InterpreterManager.manager().SetDefaultInterpreter(interpreter)
        InterpreterManager.manager().SavePythonInterpretersConfig()

    def OnCancel(self, options_dialog):
        if self._configuration_changed:
            ret = QMessageBox.question(
                self,
                _("Save configuration"),
                _("Interpreter configuration has already been modified outside,Do you want to save?")
            )
            if ret == QMessageBox.Yes:
                self.OnOK(options_dialog)
        return True


class AnalyseProgressDialog(QProgressDialog):
    SIG_APPEND_MSG = pyqtSignal(str)

    def __init__(self, parent):
        super().__init__(
            _("Please wait a minute for end analysing"),
            _("Cancel"),
            0,
            0,
            parent
        )
        self.setWindowTitle(_("Interpreter smart analyse"))
        self.SIG_APPEND_MSG.connect(self.append_msg)

    def append_msg(self, msg):
        self.setLabelText(msg.strip())
        if msg == constants.PROGRESS_END:
            utils.get_logger().info('interpreter analyse progress end...')
            self.close()
