from ... import get_app, _
from ...lib.pyqt import QComboBox
from .interpretermanager import InterpreterManager


class InterpreterComboBox(QComboBox):
    """description of class"""
    DISPLAY_INTERPRETER_NAME = 1
    DISPLAY_INTERPRETER_PATH = 2

    def __init__(self, parent=None, interpreters=None):
        super().__init__(parent)
        if interpreters is None:
            self.interpreters = InterpreterManager.manager().interpreters
        else:
            self.interpreters = interpreters
        self._flags = self.DISPLAY_INTERPRETER_NAME
        self.load()

    @property
    def flags(self):
        return self._flags

    def set_flags(self, flag):
        self._flags = flag

    def load(self):
        default_index = -1
        for i, interpreter in enumerate(self.interpreters):
            text = ''
            if self._flags & self.DISPLAY_INTERPRETER_NAME:
                text = interpreter.name
            if self._flags & self.DISPLAY_INTERPRETER_PATH:
                if text == '':
                    text += interpreter.path
                else:
                    text += " (%s)" % interpreter.path
            self.addItem(text, interpreter)
            if interpreter.Default:
                default_index = i
        if default_index >= 0:
            self.setCurrentIndex(default_index)
        else:
            self.setCurrentIndex(0)

    def reload(self):
        self.clear()
        self.load()

    def GetChooseInterpreter(self):
        return self.get_interpreter(self.currentIndex())

    def find_interpreter_index(self, name):
        for i, interpreter in enumerate(self.interpreters):
            if name == interpreter.name:
                return i
        return -1

    def get_interpreter(self, index):
        return self.interpreters[index]

    def set_current_interpreter(self, interpreter_or_name):
        if isinstance(interpreter_or_name, str):
            index = self.find_interpreter_index(interpreter_or_name)
            if index != -1:
                self.setCurrentIndex(index)
        else:
            if interpreter_or_name in self.interpreters:
                index = self.interpreters.index(interpreter_or_name)
                self.setCurrentIndex(index)


class ToolbarInterpreterComboBox(InterpreterComboBox):

    def __init__(self, parent=None):
        super().__init__(parent, InterpreterManager.manager().interpreters)
        # 首选项按下确定按钮时如果解释器列表有变动接收相应的信号, 重新加载解释器列表
        get_app().MainFrame.SIG_DEBUG_COMBO_RELOAD.connect(self.reload)

    def load(self):
        super().load()
        self.addItem(_("Configuration"))
        if 0 == len(self.interpreters):
            self.setCurrentIndex(-1)

    def reload(self):
        self.currentIndexChanged.disconnect(get_app().selectdebugger)
        # 解释器列表已经更改,需要重新加载解释器列表
        self.interpreters = InterpreterManager.manager().interpreters
        super().reload()
        self.currentIndexChanged.connect(get_app().selectdebugger)
