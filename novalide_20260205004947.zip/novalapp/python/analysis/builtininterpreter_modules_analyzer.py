from ... import constants
from .builtin_analyzer import BuiltinAnalyzer


class BuiltiInterpreterModulesAnalyzer:
    """解析内建解释器包含的所有模块"""

    def __init__(self, dbver, data_path, interpreter, progress_dlg):
        self._progress_dlg = progress_dlg
        self.builtin_analyzer = BuiltinAnalyzer(
            dbver,
            data_path,
            interpreter
        )

    def run(self):
        self.builtin_analyzer.run()
        if self._progress_dlg is None:
            return
        self._progress_dlg.SIG_APPEND_MSG.emit(constants.PROGRESS_END)
