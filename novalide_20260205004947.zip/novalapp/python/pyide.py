# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        pyide.py
Purpose:

Author:      wukan

Created:     2019-01-10
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import subprocess
from pathlib import Path
import os
from .. import _, qtimage
from ..ide import IDEApplication
from .interpreter.interpretermanager import InterpreterManager
from .interpreter.combo import ToolbarInterpreterComboBox
from ..plugin import plugin_config
from ..util import ui_utils, utils, fileutils, environments, terminal
from .. import menuitems
from ..prog_lang import LANGUAGE_PYTHON
from ..syntax import lang
from ..bars.menubar import find_menu
from ..lib.pyqt import QMessageBox
from .. import constants
from .utility import PydocManager, get_environment_overrides_for_python_subprocess
from .debugger import debugger, commandui
from .ui import show_interpreter_configuration_page


class PyIDEApplication(IDEApplication):

    # 统计程序启动时间
    @utils.compute_time
    def on_init(self):
        if not super().on_init():
            return False

        from .parser.intellisence import IntellisenceManager
        from ..plugins.about import AboutDialog
        import astroid
        # 把astroid版本信息添加到关于对话框显示的软件版本信息中
        AboutDialog.update_version(f"\nAstroid {astroid.__version__}")

        self._debugger_class = debugger.PythonDebugger
        help_menu = find_menu(_("&Help"), self.Menubar)
        if utils.is_windows():
            self.InsertCommand(
                menuitems.ID_FEEDBACK,
                menuitems.ID_OPEN_PYTHON_HELP,
                help_menu,
                _("&Python help document"),
                handler=self.open_pythonhelp_document,
                image=self.GetImage("pydoc.png")
            )

        self.InsertCommand(
            menuitems.ID_FIND_OCCURRENCES,
            menuitems.ID_GOTO_DEFINITION,
            _("&Edit"),
            _("Goto Definition"),
            self.goto_definition,
            tester=lambda: self.UpdateUI(menuitems.ID_GOTO_DEFINITION)
        )
        self.InsertCommand(
            menuitems.ID_FEEDBACK,
            menuitems.ID_GOTO_PYTHON_WEB,
            help_menu,
            _("&Python website"),
            handler=self.goto_python_website,
        )
        tools_menu = find_menu(_("&Tools"), self.Menubar)
        # 解释器菜单插入在插件管理菜单之前
        self.InsertCommand(
            menuitems.ID_PLUGIN,
            menuitems.ID_OPEN_INTERPRETER,
            tools_menu,
            _("&Interpreter"),
            self.open_interpreter,
            image=self.GetImage("python/interpreter.png"),
        )
        edit_menu = find_menu(_("&Edit"), self.Menubar)
        insert_menu = edit_menu.GetMenu(menuitems.ID_INSERT)
        self.AddDefaultCommand(
            menuitems.ID_INSERT_DECLARE_ENCODING,
            insert_menu,
            _("Insert encoding declaration"),
            self.insert_declare_encoding
        )

        self.AddDefaultCommand(
            menuitems.ID_INSERT_MAIN_STATEMENT,
            insert_menu,
            _("Insert \"__main__\" statement"),
            self.insert_main_statement
        )
        run_menu = find_menu(_("&Run"), self.Menubar)

        self.AddDefaultCommand(
            menuitems.ID_START_WITHOUT_DEBUG,
            run_menu,
            _("&Start without debugging"),
            self.RunWithoutDebug
        )

        self.AddDefaultCommand(
            menuitems.ID_SET_EXCEPTION_BREAKPOINT,
            run_menu,
            _("&Exceptions..."),
            self.set_exception_breakpoint,
            add_separator=True
        )
        self.AddDefaultCommand(
            menuitems.ID_STEP_INTO,
            run_menu, _("&Step into"),
            self.StepInto,
            image=self.GetImage('python/debugger/step_into.png')
        )
        self.AddDefaultCommand(
            menuitems.ID_STEP_NEXT,
            run_menu,
            _("&Step over"),
            self.StepNext,
            add_separator=True,
            image=self.GetImage('python/debugger/step_next.png')
        )

        self.AddDefaultCommand(
            menuitems.ID_CHECK_SYNTAX,
            run_menu,
            _("&Check syntax..."),
            self.CheckSyntax
        )
        self.AddDefaultCommand(
            menuitems.ID_SET_PARAMETER_ENVIRONMENT,
            run_menu,
            _("&Set params and environments"),
            self.SetParameterEnvironment,
            image=self.GetImage('python/debugger/runconfig.png')
        )
      #  self.AddCommand(menuitems.ID_RUN_LAST,_("&Run"),_("&Run Using Last Settings"),self.RunLast,default_tester=True,default_command=True)
       # self.AddCommand(menuitems.ID_DEBUG_LAST,_("&Run"),_("&Debug Using Last Settings"),self.DebugLast,default_tester=True,default_command=True,add_separator=True)

        self.AddDefaultCommand(
            menuitems.ID_TOGGLE_BREAKPOINT,
            run_menu,
            _("&Toggle breakpoint"),
            self.ToogleBreakPoint,
            image=self.GetImage('python/debugger/breakpoint.png')
        )
        self.AddDefaultCommand(
            menuitems.ID_CLEAR_ALL_BREAKPOINTS,
            run_menu,
            _("&Clear all breakpoints"),
            self.ClearAllBreakPoints,
        )
        # 关闭软件启动图片
        self.close_splash()
        self.intellisence_mananger = IntellisenceManager()
        self.intellisence_mananger.generate_default_intellisence_data()
        self.MainFrame.GetNotebook().load_open_documents()
        return True

    def get_project_browser_class(self):
        '''
        '''
        from .project.browser import PythonprojectBrowser
        return PythonprojectBrowser

    def GetInterpreterManager(self):
        return InterpreterManager.manager()

    def set_exception_breakpoint(self):
        self.MainFrame.GetView(
            constants.BREAKPOINTS_TAB_NAME).set_exception_breakpoint()

    def StepNext(self):
        self.GetDebugger().StepNext()

    def StepInto(self):
        self.GetDebugger().StepInto()

    def DebugLast(self):
        self.GetDebugger().DebugLast()

    def RunLast(self):
        self.GetDebugger().RunLast()

    def CheckSyntax(self):
        self.GetDebugger().CheckScript()

    def SetParameterEnvironment(self):
        self.GetDebugger().SetParameterAndEnvironment()

    def ToogleBreakPoint(self):
        current_view = self.GetDocumentManager().GetCurrentView()
        # 只有python文件才能设置断点
        if current_view is None or not hasattr(current_view, "ToogleBreakpoint"):
            return
        current_view.GetCtrl().ToogleBreakpoint()

    def ClearAllBreakPoints(self):
        self.MainFrame.GetView(
            constants.BREAKPOINTS_TAB_NAME).ClearAllBreakPoints()

    @ui_utils.update_toolbar
    def LoadDefaultInterpreter(self):
        InterpreterManager.manager().LoadDefaultInterpreter()

    def goto_definition(self):
        current_view = self.GetDocumentManager().GetCurrentView()
        # 只有python文件才能执行转到定义功能
        if current_view is None or not hasattr(current_view, "GotoDefinition"):
            return
        current_view.GotoDefinition()

    def LoadDefaultPlugins(self):
        '''
            加载python默认插件
        '''
        from ..preference.preference import PreferenceManager
        from .interpreter.gerneralconfiguration import InterpreterGeneralConfigurationPanel
        from .interpreter.interpreterlist import InterpreterListPanel
        from .interpreter.interpreterconfiguration import InterpreterConfigurationPanel
        from .editor import IntelliSenseOptionPanel
        from .symbol.findsymbolpage import SearchSymbolOptionPanel
        IDEApplication.LoadDefaultPlugins(self)
        # 添加Python语言仅有的首选项面板,在Misc面板之前
        PreferenceManager.manager().insert_option_panel_class(
            _("Misc"),
            _("Interpreter"),
            "General",
            _("General"),
            InterpreterGeneralConfigurationPanel
        )
        PreferenceManager.manager().AddOptionsPanelClass(
            _("Interpreter"),
            "InterpreterList",
            _("Interpreters list"),
            InterpreterListPanel
        )
        PreferenceManager.manager().AddOptionsPanelClass(
            _("Interpreter"),
            "InterpreterConfiguration",
            _("Configuration"),
            InterpreterConfigurationPanel
        )
        # 不能用斜杆分割,斜杆作为数据默认分割符,显示时会替换|为/
        PreferenceManager().insert_option_panel_class(
            _("Misc"),
            _("Debug|Run"),
            "Debug",
            _("Debug"),
            debugger.DebuggerOptionsPanel
        )
        PreferenceManager.manager().AddOptionsPanelClass(
            _("Debug|Run"), "Output", _("Output"), debugger.OutputOptionsPanel)
        PreferenceManager.manager().AddOptionsPanelClass(
            _("Debug|Run"), "Run", _("Run"), debugger.RunOptionsPanel)
        PreferenceManager.manager().AddOptionsPanelClass(
            _("Editor"),
            "Intellisense",
            _('Intellisense'),
            IntelliSenseOptionPanel
        )
        PreferenceManager().remove_option_panel_class(_("Misc"), "SearchText")
        PreferenceManager().AddOptionsPanelClass(
            _("Misc"),
            "SearchText",
            _("Search Symbol"),
            SearchSymbolOptionPanel
        )
        from .symbol.symbolview import SearchSymbolResultsViewer, SYMBOL_VIEW_NAME
        from ..sidebar import sidebar
        self.MainFrame.AddView(
            SYMBOL_VIEW_NAME,
            SearchSymbolResultsViewer,
            _("Symbol results"),
            sidebar.SideBar.South,
            image_file="python/symbol/symbol.png",
            default_position_key=4
        )
        plugin_config.DEFAULT_PLUGINS += (
            'novalapp.python.plugins.pyshell.pyshell.PyshellViewLoader',)
        # window面板在outline面板之前,故需在outline之前初始化
        plugin_config.DEFAULT_PLUGINS += (
            'novalapp.python.plugins.outline.PythonOutlineViewLoader',)
        plugin_config.DEFAULT_PLUGINS += (
            'novalapp.python.plugins.unittest.UnittestLoader',)
        plugin_config.DEFAULT_PLUGINS += (
            'novalapp.python.debugger.sideview.BreakdebugviewLoader',)

    def CreateLangLexer(self):
        from ..syntax.synglob import LexerFactory
        super().CreateLangLexer()
        # 添加python语言的支持
        LexerFactory.CreateLangLexer(LANGUAGE_PYTHON)

    def GetCurrentInterpreter(self):
        return InterpreterManager.manager().GetCurrentInterpreter()

    def on_exit(self):
        self.intellisence_mananger.Stop()
        super().on_exit()

    def get_ide_splash_bitmap(self):
        return os.path.join(utils.get_app_image_location(), "python/splash.png")

    def AddInterpreters(self):
        self.SetCurrentInterpreter()

    def SetCurrentInterpreter(self):
        current_interpreter = InterpreterManager.manager().GetCurrentInterpreter()
        if current_interpreter is None:
            return
        for i in range(self.interpreters_combo.count()):
            data = InterpreterManager.manager().interpreters[i]
            if data == current_interpreter:
                self.interpreters_combo.setCurrentIndex(i)
                break

    @ui_utils.update_toolbar
    def selectdebugger(self, i):
        prompt = False
        if i == self.interpreters_combo.count() - 1:
            if commandui.BaseDebuggerUI.DebuggerRunning():
                prompt = True
            else:
                show_interpreter_configuration_page()
                self.SetCurrentInterpreter()
        else:
            interpreter = InterpreterManager.manager().interpreters[i]
            if interpreter != self.GetCurrentInterpreter() and commandui.BaseDebuggerUI.DebuggerRunning():
                prompt = True
            else:
                self.SelectInterpreter(interpreter)
        if prompt:
            QMessageBox.information(
                self.GetTopWindow(),
                self.GetAppName(),
                _("Please stop the debugger first!")
            )
            self.SetCurrentInterpreter()

    def open_pythonhelp_document(self):
        interpreter = self.GetCurrentInterpreter()
        if interpreter is None:
            return
        if interpreter.HelpPath == "":
            return
        fileutils.startfile(interpreter.HelpPath)

    def goto_python_website(self):
        fileutils.startfile("http://www.python.org")

    def SelectInterpreter(self, interpreter):
        if interpreter != self.GetCurrentInterpreter():
            InterpreterManager.manager().SetCurrentInterpreter(interpreter)
            if self.intellisence_mananger.running:
                return
            self.intellisence_mananger.load_intellisence_data(interpreter)
        # 切换解释器时是否更新解释器的后端进程
        if utils.profile_get_int('UPDATE_SHELL_SWITCH_INTERPRETER', True):
            self.MainFrame.GetView(
                constants.PYTHON_INTERPRETER_VIEW_NAME).SIG_UPDATE_SHELL_BACKEND.emit()

    def GetDefaultLangId(self):
        if not hasattr(lang, "ID_LANG_PYTHON"):
            return super().GetDefaultLangId()
        return lang.ID_LANG_PYTHON

    def open_interpreter(self):
        interpreter = self.GetCurrentInterpreter()
        if interpreter is None:
            QMessageBox.information(
                self.GetTopWindow(),
                self.GetAppName(),
                _("No interpreter...")
            )
            return
        try:
            if utils.is_windows():
                fileutils.startfile(interpreter.path)
            else:
                cmd_list = ['gnome-terminal', '-x',
                            'bash', '-c', interpreter.path]
                subprocess.Popen(cmd_list, shell=False)
        except Exception as e:
            QMessageBox.critical(self.GetTopWindow(), _(
                "Open Error"), _("%s") % str(e))

    def open_terminator(self, filename=None):
        if filename:
            if os.path.isdir(filename):
                cwd = filename
            else:
                cwd = os.path.dirname(filename)
        else:
            cwd = os.getcwd()
        # 打开终端时不嵌入解释器环境
        if not utils.profile_get_int("EmbedInterpreterInterminator", True):
            IDEApplication.open_terminator(self, filename)
            return
        interpreter = self.GetCurrentInterpreter()
        if interpreter is None:
            IDEApplication.open_terminator(self, filename)
            return
        target_executable = interpreter.path
        exe_dirs = interpreter.GetExedirs()
        # 检测是否虚拟解释器
        activate = os.path.join(os.path.dirname(target_executable),
                                "activate.bat" if utils.is_windows()
                                else "activate")
        is_venv = False
        if os.path.isfile(activate):
            is_venv = True
        env_overrides = get_environment_overrides_for_python_subprocess(
            target_executable, is_venv)
        env_overrides["PATH"] = environments.get_augmented_system_path(
            exe_dirs)
        # 设置安装路径的环境变量,运行程序时需要在路径中移除此路径
        env_overrides['MAIN_MODULE_APTH'] = utils.get_app_path()
        explainer = os.path.join(
            Path(os.path.abspath(__file__)).parent, "explain.py")
        cmd = [target_executable, explainer]

        if is_venv:
            del env_overrides["PATH"]
            if utils.is_windows():
                cmd = [activate, "&"] + cmd
            else:
                cmd = ["source", activate, ";"] + cmd
        return terminal.run_in_terminal(cmd, cwd, env_overrides, True)

    def RunWithoutDebug(self):
        self.GetDebugger().RunWithoutDebug()

    def insert_declare_encoding(self):
        '''插入编码声明'''
        self.GetDocumentManager().GetCurrentView().insert_declare_encoding()

    def insert_main_statement(self):
        '''插入__main__语句'''
        self.GetDocumentManager().GetCurrentView().insert_main_statement()

    def UpdateUI(self, command_id):
        current_project = self.get_current_project()
        current_interpreter = self.GetCurrentInterpreter()
        debug_disable_item_ids = [
            menuitems.ID_RUN,
            menuitems.ID_SET_EXCEPTION_BREAKPOINT,
            menuitems.ID_STEP_INTO,
            menuitems.ID_STEP_NEXT,
            menuitems.ID_RUN_LAST,
            menuitems.ID_CLEAR_ALL_BREAKPOINTS
        ]
        debug_item_ids = debug_disable_item_ids + [
            menuitems.ID_SET_PARAMETER_ENVIRONMENT,
            menuitems.ID_DEBUG_LAST,
            menuitems.ID_START_WITHOUT_DEBUG
        ]
        if command_id in debug_item_ids and current_interpreter is None:
            return False
        # 使用内建解释器时,禁止运行按钮和菜单
        if command_id in debug_disable_item_ids and current_interpreter.IsBuiltIn:
            return False
        if current_project is not None:
            if command_id == menuitems.ID_CLEAR_ALL_BREAKPOINTS:
                return 0 != len(self.MainFrame.GetView(constants.BREAKPOINTS_TAB_NAME).GetMasterBreakpointDict())
            if command_id in debug_item_ids:
                return True
        return super().UpdateUI(command_id)

    def GotoView(self, file_path, *, lineNum=-1, colno=-1, trace_track=True, load_outline=True):
        foundview = super().GotoView(file_path, lineNum=lineNum, colno=colno,
                                     trace_track=trace_track, load_outline=load_outline)
        # 如果视图是允许在大纲显示的视图类型,则跳转到指定行并选中对应的语法行
        if load_outline and self.MainFrame.outlineview.IsValidViewType(foundview):
            self.MainFrame.outlineview.LoadOutLine(foundview, linenum=lineNum)
        return foundview

    def share(self):
        pass

    def CreateProjectTemplate(self):
        from ..lib.template import TEMPLATE_NO_CREATE
        common_project_template = super().CreateProjectTemplate()
        common_project_template.SetFlags(
            common_project_template.GetFlags() | TEMPLATE_NO_CREATE)
        from .project import view as projectview
        from .project import document as projectdocument
        from .project import ext
        self.default_project_template = projectview.PythonProjectTemplate(
            self.GetDocumentManager(),
            _("Project File"),
            "*%s" % ext.PYTHON_PROJECT_EXTENSION,
            os.getcwd(),
            ext.PYTHON_PROJECT_EXTENSION,
            "Python Project Document",
            _("Project viewer"),
            projectdocument.PythonProjectDocument,
            projectview.PythonProjectView,
            icon=qtimage.python_project_icon()
        )
        self.GetDocumentManager().AssociateTemplate(self.default_project_template)

    def create_document_manager(self):
        return PydocManager()

    def create_debug_combo(self):
        self.LoadDefaultInterpreter()
        self.create_interpreters_combo()
        self.AddInterpreters()

    def create_interpreters_combo(self):
        self.interpreters_combo = self.MainFrame.GetToolBar(
        ).AddCombox(ToolbarInterpreterComboBox())
        self.interpreters_combo.currentIndexChanged.connect(
            self.selectdebugger)
