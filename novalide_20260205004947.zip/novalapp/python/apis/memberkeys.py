CHILD_KEY_NAME = "childs"
# 节点完整名称(包含模块名)
MODNAME_KEY_NAME = "modname"
# 节点名称
NAME_KEY_NAME = "name"
# 节点类型
OBJTYPE_KEY_NAME = "objtype"
# 节点文档信息
DOC_KEY_NAME = "doc"
# 节点行号
LINE_KEY_NAME = "line"
# 节点列号
COL_KEY_NAME = "col"
# 节点文件路径,可能是本模块路径,也可能是引用模块路径
PATH_KEY_NAME = "path"
# 基类
BASES_KEY_NAME = "bases"
ARGS_KEY_NAME = "args"
