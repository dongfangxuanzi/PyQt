import pickle
from astroid import nodes
from ..parser.define import (
    CLASS_INIT_METHOD,
    BUILTMODULE_NAME,
    CLASS_METHOD_NAME,
    STATIC_METHOD_NAME,
    PROPERTY_METHOD_NAME,
    SELF_ARG_NAME
)
from ..parser import objtypes, node_utils
from . import iconid
from . import memberkeys
from ...util import fileutils


class APIGenerator:
    """description of class"""

    def __init__(self, datapath, childs, module, modname):
        self._datapath = datapath
        self._childs = childs
        self._module = module
        self._modname = modname

    def gen_api(self, analyzer):
        api_filepath = analyzer.get_api_file(self._modname)
        with open(api_filepath, 'w') as f:
            for name, nodetype, node in self._childs:
                nodename = name.split('.')[-1]
                icon_id = iconid.get_icon_id(nodetype, nodename)
                if icon_id is not None:
                    api_name = "%s?%d" % (name, icon_id)
                else:
                    api_name = name
                # 函数参数提示信息
                if nodetype == objtypes.FUNCTION_DEF and node is not None:
                    api_name = "%s(%s)" % (api_name, node.args.as_string())
                # 如果是类,找到init方法的定义,作为参数提示信息
                elif nodetype == objtypes.CLASS_DEF and node is not None and \
                        isinstance(node, nodes.ClassDef):
                    for child in node.body:
                        # 类节点用init函数节点代替,这样输入类名时会提示构造函数信息
                        if isinstance(child, nodes.FunctionDef) and child.name == CLASS_INIT_METHOD:
                            api_name = "%s(%s)" % (
                                api_name, child.args.as_string())
                            break
                f.write(api_name)
                f.write('\n')

    def gen_builtin_api(self, analyzer):
        api_filepath = analyzer.get_api_file(self._modname)
        # 这里无需对所有子成员按名称排序,因为qscintilla库在调用api接口时会自动排序
        with open(api_filepath, 'w') as f:
            for name, objtype, _ in self._childs:
                names = name.split('.')
                modname = names[0]
                objname = names[-1]
                icon_id = iconid.get_icon_id(objtype, objname)
                if icon_id is not None:
                    api_name = "%s?%d" % (name, icon_id)
                else:
                    api_name = name
                f.write(api_name)
                f.write('\n')
                if modname == BUILTMODULE_NAME:
                    builtinmodule_api_name = api_name.replace(
                        BUILTMODULE_NAME + ".", "")
                    f.write(builtinmodule_api_name)
                    f.write('\n')

    def sort_childs(self):
        # 按模块名称排序,以便正确弹出代码提示内容
        self._childs.sort(key=lambda k: k[0])

    def gen_members(self, analyzer, finished):
        # 这里需要对子成员按名称排序,按python默认的排序函数即可,无需自己写排序函数
        self.sort_childs()
        members_file_name = analyzer.get_members_file(self._modname)
        with open(members_file_name, 'wb') as j:
            # Pickle dictionary.
            datas = []
            path = self._module.file
            for name, nodetype, node in self._childs:
                data = {
                    memberkeys.MODNAME_KEY_NAME: name,
                    memberkeys.NAME_KEY_NAME: name.split(".")[-1],
                    memberkeys.OBJTYPE_KEY_NAME: nodetype
                }
                lineno, col_offset = node_utils.get_node_line_col(node)
                if lineno is not None and col_offset is not None:
                    data.update({
                        memberkeys.LINE_KEY_NAME: lineno,
                        memberkeys.COL_KEY_NAME: col_offset
                    }
                    )
                doc = node_utils.get_node_doc(node)
                if doc is not None:
                    data.update({memberkeys.DOC_KEY_NAME: doc})
                if nodetype == objtypes.MODULE:
                    assert isinstance(node, nodes.Module)
                    modpath = node.file
                    data.update({memberkeys.PATH_KEY_NAME: modpath})
                else:
                    root_path = node.root().file
                    # 节点原始定义在其它文件
                    if root_path is not None and not fileutils.ComparePath(root_path, path):
                        data.update({memberkeys.PATH_KEY_NAME: root_path})
                    if isinstance(node, nodes.FunctionDef):
                        func_member = self.gen_func_members(node)
                        data.update(func_member)
                    elif isinstance(node, nodes.ClassDef):
                        class_bases = self.gen_class_bases(node)
                        data.update({memberkeys.BASES_KEY_NAME: class_bases})
                datas.append(data)
            module_doc = node_utils.get_node_doc(self._module)
            module_dct = {
                "name": self._modname.split('.')[-1],
                "modname": self._modname,
                "path": path,
                "childs": datas,
                "objtype": objtypes.MODULE
            }
            if module_doc is not None:
                module_dct.update({memberkeys.DOC_KEY_NAME: module_doc})
            module_dct.update({'finished': finished})
            pickle.dump(module_dct, j)

    def gen_func_members(self, func_node):
        func_node_args = func_node.args.args
        args = [] if func_node_args is None else func_node_args
        func_data = {}
        func_args = []
        is_method = False
        if (
            isinstance(func_node.parent, nodes.ClassDef) and len(args) > 0
        ) and (
            isinstance(
                args[0], nodes.AssignName) and args[0].name == SELF_ARG_NAME
        ):
            is_method = True
        for arg in args:
            data = {}
            lineno, col_offset = node_utils.get_node_line_col(arg)
            data[memberkeys.LINE_KEY_NAME] = lineno
            data[memberkeys.COL_KEY_NAME] = col_offset
            data[memberkeys.NAME_KEY_NAME] = arg.as_string()
            func_args.append(data)
        func_data[memberkeys.ARGS_KEY_NAME] = func_args
        is_property_method = False
        is_class_method = False
        if func_node.decorators is not None:
            for deco in func_node.decorators.nodes:
                if isinstance(deco, nodes.Name):
                    # property装饰符
                    if deco.name == PROPERTY_METHOD_NAME:
                        is_property_method = True
                        break
                    # classmthod和staticmethod装饰符
                    if deco.name in (CLASS_METHOD_NAME, STATIC_METHOD_NAME):
                        is_class_method = True
                        break
        func_data['is_propertymethod'] = is_property_method
        func_data['is_classmethod'] = is_class_method
        func_data['is_method'] = is_method
        return func_data

    def gen_class_bases(self, node):
        bases = []
        for base in node.mros:
            bases.append({memberkeys.MODNAME_KEY_NAME: base})
        return bases

    def gen_builtin_members(self, analyzer):
        self.sort_childs()
        members_file_name = analyzer.get_members_file(self._modname)
        with open(members_file_name, 'wb') as j:
            # Pickle dictionary.
            datas = []
            for name, objtype, obj in self._childs:
                data = {
                    memberkeys.MODNAME_KEY_NAME: name,
                    memberkeys.NAME_KEY_NAME: name.split(".")[-1],
                    memberkeys.OBJTYPE_KEY_NAME: objtype
                }
                doc = self.get_builtin_doc(obj)
                if doc is not None:
                    data.update({memberkeys.DOC_KEY_NAME: doc})
                if objtype == objtypes.CLASS_DEF:
                    data[memberkeys.BASES_KEY_NAME] = []
                datas.append(data)
            module_doc = self.get_builtin_doc(self._module)
            module_dct = {
                "name": self._modname.split('.')[-1],
                "childs": datas,
                "modname": self._modname,
                "objtype": objtypes.MODULE,
                "finished": True
            }
            if module_doc is not None:
                module_dct.update(dict(doc=module_doc))
            # 保存pyd文件的路径
            if hasattr(self._module, '__file__'):
                path = self._module.__file__
                module_dct.update({memberkeys.PATH_KEY_NAME: path})
            pickle.dump(module_dct, j)
