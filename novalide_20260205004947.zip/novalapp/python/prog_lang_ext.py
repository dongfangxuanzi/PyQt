# python存根文件,仅提供接口,不提供实现代码的文件
PYTHON_PYI_FILE_EXT = "pyi"
PYTHON_CODE_FILE_EXT = ("py", "pyw", PYTHON_PYI_FILE_EXT)
PYTHON_PYD_FILE_EXT = "pyd"
PYTHON_SO_FILE_EXT = "so"
PYTHON_COMPILE_FILE_EXT = ("pyc", "pyo")
