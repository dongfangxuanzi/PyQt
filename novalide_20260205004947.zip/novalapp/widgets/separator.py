from ..lib.pyqt import QFrame


class Separator(QFrame):
    """description of class"""

    def __init__(self):
        super().__init__()
        self.setEnabled(False)
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Plain)
