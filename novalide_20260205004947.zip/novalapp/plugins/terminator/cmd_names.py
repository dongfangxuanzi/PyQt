from enum import Enum


class CmdName(Enum):
    POWERSHELLCMD = "PowerShellCmd"
    SIMULATECMD = "SimulateCmd"
    GITCMD = "GitCmd"
