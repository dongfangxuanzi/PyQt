import os
from novalapp import get_app
from novalapp.executable import Executable
from .cmd_names import CmdName
from ...util import utils
from ...backend.running import Runner, SubprocessProxy
from ...backend.command import PROGRAM_OUTPUT_EVENT_NAME, BackendEvent

RUN_TERMINAL_BACKENDKEY = "run.terminal.backend_name"


class CmdRunner(Runner):
    """description of class"""

    def __init__(self, shell_view):
        super().__init__(shell_view)

    def get_backend(self):
        backend_name = utils.profile_get(
            RUN_TERMINAL_BACKENDKEY,
            CmdName.SIMULATECMD
        )
        return backend_name


class ShellCmdProxy(SubprocessProxy):
    def __init__(self, executable_name, clean):
        self._is_welcome_text = True
        path = self.get_backend_location(executable_name)
        utils.get_logger().info("executable name %s path is %s", executable_name, path)
        super().__init__(clean, path)

    @staticmethod
    def get_backend_location(executable_name):
        path = Executable.get_location(executable_name)
        if path is None:
            raise RuntimeError("Canot locate backend path of %s" % executable_name)
        return path

    def _get_launcher_with_args(self):
        return []

    def _listen_stdout(self, stdout):
        # debug("... started listening to stdout")
        # will be called from separate thread

        message_queue = self._response_queue

        def publish_as_msg(data):
            msg = parse_message(data)
            if "cwd" in msg:
                self.cwd = msg["cwd"]
            message_queue.append(msg)

            while len(message_queue) > 100:
                # Probably backend runs an infinite/long print loop.
                # Throttle message thougput in order to keep GUI thread responsive.
                sleep(0.1)

        while not self._is_disconnected():
            data = stdout.readline()
            utils.get_logger().debug("... read some stdout data %s", repr(data))
            if data == "":
                break
            # print first part as it is
            # 第一部分输出为输入命令本身，忽略,但是开头输出的欢迎文本除外
            if self._is_welcome_text:
                message_queue.append(BackendEvent(PROGRAM_OUTPUT_EVENT_NAME,
                                                  data=data, stream_name="stdout")
                                     )
            extra_data = ''
            while True:
                char = stdout.read(1)
                extra_data += char
                if char == '>' or char == '':
                    break

            message_queue.append(
                BackendEvent(PROGRAM_OUTPUT_EVENT_NAME,
                             data=extra_data, stream_name="stdout")
            )

    def send_program_input(self, data):
        if self._proc is None:
            return
        self._proc.stdin.write(data + "\n")
        self._proc.stdin.flush()
        self._is_welcome_text = False

    def get_cwd(self):
        current_project = get_app().get_current_project()
        if current_project is None:
            return super().get_cwd()
        return current_project.GetPath()


class PowerShellProxy(ShellCmdProxy):
    def __init__(self, clean):
        super().__init__("powershell.exe", clean)


class SystemCmdProxy(ShellCmdProxy):
    def __init__(self, clean):
        super().__init__("cmd.exe", clean)


class GitBashProxy(ShellCmdProxy):
    def __init__(self, clean):
        super().__init__("git", clean)
        git_install_path = os.path.dirname(os.path.dirname(self._executable))
        self._executable = os.path.join(git_install_path, "git-bash.exe")
        utils.get_logger().info("git bash path is %s", self._executable)
