
# --------------------------------------------------------------------------#
# Dependancies
from ..project.config import RunConfig
from .. import get_app, _
from ..debugger.tracer import OutputTracer
from ..sidebar.sidebar import SideBar
from ..util import utils
from ..debugger.debug import DebugCtrl
from ..plugin import iface, plugin
from ..debugger.debugger import Debugger


class OutputView(OutputTracer):
    OUTPUT_VIEW_NAME = "Output"

    def __init__(self, master, debugger=None):
        if debugger is None:
            get_app()._debugger_class = Debugger
            debugger = get_app().GetDebugger()
        OutputTracer.__init__(self, master, debugger)
        self.project_browser = get_app().MainFrame.projectview
        self._textctrl.setReadOnly(True)

    def run(self, cmd, args: list, workdir):
        run_parameter = RunConfig(
            cmd,
            arg=' '.join(args),
            start_up=workdir,
            project=get_app().get_current_project()
        )
        self._textctrl.ClearOutput()
        self.SetRunParameter(run_parameter)
        self.CreateExecutor(source=_("Output"))
        self.Execute()
        self.EnableToolbar()

    def GetOuputctrlClass(self):
        return DebugCtrl


class OutputViewPlugin(plugin.Plugin):
    """Simple Programmer's Calculator"""
    plugin.Implements(iface.MainWindowI)

    def PlugIt(self, parent):
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing outputview plugin")
        get_app().MainFrame.AddView(
            OutputView.OUTPUT_VIEW_NAME,
            OutputView,
            _("Output"),
            SideBar.South,
            create=True,
            image_file="writeout.png",
            visible_in_menu=True
        )

    def GetMinVersion(self):
        return '1.2.8'
