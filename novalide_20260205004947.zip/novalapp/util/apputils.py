'''
-------------------------------------------------------------------------------
Name:        apputils.py
Purpose:

Author:      wukan

Created:     2019-01-08
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import locale
import time
import os
import sys
import future.utils
from .. import get_app
from .logger import get_logger
from ..lib import ui_lang
from ..common.configparser import ConfigReader, ConfigWriter

# 软件安装目录环境变量
MAINMODULE_DIR_ENV = "NOVAL_MAINMODULE_DIR"

# 是否开发版本,在正式版本发行时需要设置为False,在内测版本时需要设置为True
isDev = True


def is_dev():
    return isDev


def is_windows():
    return os.name == 'nt'


def is_linux():
    return os.name == "posix"


def is_py3():
    return future.utils.PY3


def is_py3_plus():
    return sys.version_info[0] >= 3


def get_default_locale_encoding():
    '''
        获取操作系统默认编码,不一定是utf-8
    '''
    try:
        return locale.getpreferredencoding()
    except:
        return locale.getdefaultlocale()[1]


def get_default_locale():
    return locale.getdefaultlocale()[0]


def _generateMainModuleDir():
    # 软件安装目录优先从环境变量中读取,如果存在则返回变量值
    mainModuleDir = os.getenv(MAINMODULE_DIR_ENV)
    if mainModuleDir:  # if environment variable set, return it
        return mainModuleDir

    # On Mac, the python executable sometimes has a capital "P" so we need to
    # lower the string first
    sysExecLower = sys.executable.lower()
    if sysExecLower == "/" or sysExecLower.find('python') != -1:
        utilModuleDir = os.path.dirname(__file__)
        if not os.path.isabs(utilModuleDir):
            utilModuleDir = os.path.join(os.getcwd(), utilModuleDir)
        mainModuleDir = os.path.normpath(os.path.join(
            utilModuleDir, os.path.join(os.path.pardir, os.path.pardir)))
        if mainModuleDir.endswith('.zip'):
            mainModuleDir = os.path.dirname(
                mainModuleDir)  # Get rid of library.zip
    else:
        mainModuleDir = os.path.dirname(sys.executable)

    # pythonBug: os.putenv doesn't work, set environment variable
    os.environ[MAINMODULE_DIR_ENV] = mainModuleDir
    return mainModuleDir


mainModuleDir = _generateMainModuleDir()


def getCommandNameForExecPath(exec_path):
    if isWindows():
        return '"%s"' % exec_path
    return exec_path


def getUserName():
    if isWindows():
        return os.getenv('USERNAME')
    # 06-Feb-06 stoens@activegrid.com --
    # this blows up the linux cc runs with "Inappropriate ioctl for device"
    # return os.getlogin()
    return os.getenv('USER')


def getCurrentTimeAsFloat():
    return time.time()


systemStartTime = getCurrentTimeAsFloat()


def GetSupportableExtList():
    exts = []
    for template in get_app().GetDocumentManager().GetTemplates():
        temp_filter = template.GetFileFilter()
        parts = temp_filter.split(";")
        for part in parts:
            ext = part.replace("*.", "").strip()
            exts.append(ext)
    return exts


def is_ext_supportable(ext):
    if ext == "":
        return True
    return ext.lower() in GetSupportableExtList()


def get_app_version():
    # find version number from version.txt
    version_filepath = os.path.join(mainModuleDir, "version.txt")
    if os.path.exists(version_filepath):
        versionfile = open(version_filepath, 'r')
        version_lines = versionfile.readlines()
        versionfile.close()
        version = "".join(version_lines)
    else:
        get_logger().error("version file %s not found", version_filepath)
        version = "Version Unknown"
    return version


def get_lang_config():
    return int(get_app_config('IDE', 'Language', value=ui_lang.LANGUAGE_DEFAULT))


def get_app_config_path():
    return os.path.join(mainModuleDir, "config.ini")


def get_app_config(section, key, value=None):
    '''
        读取配置文件的属性值
    '''
    app_config_path = get_app_config_path()
    if not os.path.exists(app_config_path):
        return value
    return ConfigReader(app_config_path).get_config(section, key, value)


def write_app_cofig(section, key, value):
    '''
        初始化配置文件的属性值
    '''
    config_path = get_app_config_path()
    ConfigWriter(config_path).write_cofig(section, key, value)


def get_embed_python_version():
    version_info = sys.version_info
    result = ".".join(map(str, version_info[:3]))
    if version_info[3] != "final":
        result += "-" + version_info[3]
    result += " (" + ("64" if sys.maxsize > 2 ** 32 else "32") + " bit)\n"
    return result
