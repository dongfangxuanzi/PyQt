# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        misc.py
Purpose:

Author:      wukan

Created:     2019-01-16
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import os
from .. import get_app, _
from ..lib.pyqt import (
    QDialog,
    Qt,
    QDialogButtonBox,
    QHBoxLayout,
    QMessageBox,
    QTimer,
    QApplication,
    QT_VERSION_STR,
    QCursor,
    QFrame,
    QVBoxLayout
)
from . import utils


def update_toolbar(func):
    def wrap_func(*args, **kwargs):
        func(*args, **kwargs)
        get_app().MainFrame.UpdateToolbar()
    return wrap_func


def update_statusbar(func):
    def wrap_func(*args, **kwargs):
        func(*args, **kwargs)
        get_app().MainFrame.GetNotebook().updateStatusBar()
    return wrap_func


class AlarmEventMixin:

    def __init__(self):
        self._asking_about_external_change = False
        self._alarm_event = -1
        self._is_external_changed = False

    def Alarm(self, alarm_event):
        if os.path.exists(self.GetDocument().GetFilename()) and self.GetDocument().IsDocumentModificationDateCorrect():
            utils.get_logger().warning("accept modify alarm event,but file %s modify time is not chanaged",
                                       self.GetDocument().GetFilename())
            return
        self._alarm_event = alarm_event
        self._is_external_changed = True

    def check_for_external_changes(self):
        self._is_external_changed = False


class BaseModalDialog(QDialog):
    def __init__(self, title, master=None, orient=Qt.Horizontal):
        if master is None:
            master = get_app().MainFrame
        super().__init__(master)
        if title:
            self.setWindowTitle(title)
        self._orient = orient
        if self._orient == Qt.Horizontal:
            self._frame_layout = QVBoxLayout()
        elif self._orient == Qt.Vertical:
            self._frame_layout = QHBoxLayout()
        else:
            assert False
        self.setLayout(self._frame_layout)

    @property
    def layout(self):
        return self._frame_layout

    def create_standard_buttons_box(self):
        buttonbox = QDialogButtonBox(self)
        buttonbox.setOrientation(self._orient)
        buttonbox.setStandardButtons(QDialogButtonBox.Ok |
                                     QDialogButtonBox.Cancel)
        self.ok_button = buttonbox.button(QDialogButtonBox.Ok)
        self.ok_button.setDefault(True)
        self.ok_button.setText(_("&OK"))
        buttonbox.button(QDialogButtonBox.Cancel).setText(_("Cancel"))
        buttonbox.accepted.connect(self._ok)
        buttonbox.rejected.connect(self._cancel)
        return buttonbox

    def create_standard_buttons(self, button_layout=None):
        if button_layout is None:
            button_layout = self._frame_layout
        buttonbox = self.create_standard_buttons_box()
        button_layout.addWidget(buttonbox)
        return buttonbox

    def create_ok_button(self, center=False):
        buttonbox = QDialogButtonBox(self)
        buttonbox.setOrientation(Qt.Horizontal)
        buttonbox.setStandardButtons(QDialogButtonBox.Ok)
        buttonbox.setCenterButtons(center)
        self.ok_button = buttonbox.button(QDialogButtonBox.Ok)
        self.ok_button.setText(_("&OK"))
        self.ok_button.setDefault(True)
        buttonbox.accepted.connect(self._ok)
        self.layout.addWidget(buttonbox)

    def _ok(self):
        if not self.ok_button.isEnabled():
            return
        self.accept()

    def _cancel(self):
        self.reject()


def check_debugger(func):
    '''
    '''
    def wrapped_func(*args, **kwargs):
        if get_app().GetDebuggerClass() is None:
            QMessageBox.critical(
                get_app().MainFrame,
                _("Error"),
                _("There is no debuger")
            )
            return
        ret = func(*args, **kwargs)
        return ret
    return wrapped_func


def wait_cursor(func):
    '''
       执行方法时显示等待光标,完成后恢复光标
    '''
    def wrapped_func(*args, **kwargs):
        QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        ret = func(*args, **kwargs)
        QApplication.restoreOverrideCursor()
        return ret
    return wrapped_func


def no_implemented_yet(func):
    def _wrapper(*args, **kwargs):
        QMessageBox.warning(get_app().MainFrame, get_app().GetAppName(), _(
            "This function not implemented yet!"))
    return _wrapper


def call_after(func):
    '''
        延迟调用不带参数的装饰器,使用计时器实现
    '''
    def _wrapper(*args, **kwargs):
        QTimer.singleShot(100, lambda: func(*args, **kwargs))
    return _wrapper


def call_after_with_time(*wrap_args, **wrap_kwargs):
    '''
        延迟调用不带参数延迟时间的装饰器,使用计时器实现
    '''
    def call_after(func):
        def _wrapper(*args, **kwargs):
            QTimer.singleShot(wrap_args[0], lambda: func(*args, **kwargs))
        return _wrapper
    return call_after


def copytoclipboard(text):
    QApplication.clipboard().setText(text)


def getQtVersion():
    """Provides the Qt version"""
    return QT_VERSION_STR


class BaseConfigurationPanel(QFrame):
    def __init__(self, master=None):
        super().__init__()
        self._frame_layout = QVBoxLayout()
        self._frame_layout.setContentsMargins(0, 0, 0, 0)
        # 某些情况下配置界面是禁止的
        self._is_disabled = False
        self._configuration_changed = False
        self.setLayout(self._frame_layout)

    @property
    def layout(self):
        return self._frame_layout

    def OnOK(self, options_dialog):
        if not self.Validate():
            return False
        return True

    def OnCancel(self, options_dialog):
        if self._configuration_changed:
            return False
        return True

    def NotifyConfigurationChanged(self):
        self._configuration_changed = True

    def Validate(self):
        return True

    def IsDisabled(self):
        return self._is_disabled

    def DisableUI(self, parent):
        self._is_disabled = True
        for child in parent.children():
            child.setEnabled(False)


def failed_connect_api_server():
    QMessageBox.critical(
        get_app().MainFrame,
        get_app().GetAppName(),
        _("Could not connect to server")
    )
