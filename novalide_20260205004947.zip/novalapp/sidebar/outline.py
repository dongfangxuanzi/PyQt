from ..lib.pyqt import QWidget, Qt, QLabel, QFrame, QPalette
from ..util import fileutils, utils
from .. import globalkeys, get_app


class OutlineView(QWidget):
    # 不排序
    SORT_BY_NONE = 0
    # 以行号排序
    SORT_BY_LINE = 1
    # 以名称排序
    SORT_BY_NAME = 2
    # 以类型排序
    SORT_BY_TYPE = 3

    def __init__(self, master, show_header=False):
        super().__init__(master)
        self.tree = None
        self.__nonelabel = None
        self._menu = None
        self._create_layout()
        # 不显示表头
        if not show_header:
            self.tree.setHeaderHidden(True)
        self.root = self.tree.invisibleRootItem()
        self._sortorder = utils.profile_get_int(
            globalkeys.OUTLINE_SORT_KEY, self.SORT_BY_NONE)
        # 当前在大纲中显示的文本视图
        self._callback_view = None
        # 哪些视图类型允许在大纲中显示
        self._valid_view_types = []

    def _create_layout(self):
        raise NotImplementedError

    def AddViewTypeForBackgroundHandler(self, viewtype):
        self._valid_view_types.append(viewtype)

    def GetViewTypesForBackgroundHandler(self):
        return self._valid_view_types

    def RemoveViewTypeForBackgroundHandler(self, viewtype):
        self._valid_view_types.remove(viewtype)

    def IsValidViewType(self, curr_view):
        for viewtype in self._valid_view_types:
            if isinstance(curr_view, viewtype):
                return True
        return False

    def _update_frame_contents(self, index):
        if index < 0:
            self._clear_tree()
            return
        self._clear_tree()

    # clears the tree by deleting all items
    def _clear_tree(self):
        self.tree.setHeaderHidden(True)
        self.root.takeChildren()

    def GetCallbackView(self):
        return self._callback_view

    def SetCallbackView(self, view):
        self._callback_view = view
        if self._callback_view is None:
            return
        self.tree.setHeaderHidden(False)
        self.tree.setHeaderLabels(
            [fileutils.get_filename_from_path(
                self._callback_view.GetDocument().GetFilename())]
        )

    def sort_children(self, node):
        children = []
        for child in self.get_children(node):
            children.append(child)
        ids_sorted_items = sorted(children, key=self.compare_item_key)
        node.takeChildren()
        node.addChildren(ids_sorted_items)

    def compare_item_key(self, item):
        node = item.data(0, Qt.UserRole)
        # 按行号排序
        if self._sortorder == self.SORT_BY_LINE:
            return node.lineno
        # 按名称排序
        if self._sortorder == self.SORT_BY_NAME:
            return item.text(0).upper()  # sort Z-A
        # 按类型排序
        if self._sortorder == self.SORT_BY_TYPE:
            return node.__class__.__name__.upper()
        # 未排序
        return -1

    def get_children(self, node):
        for i in range(node.childCount()):
            child = node.child(i)
            yield child

    def sort(self, sortorder, node=None):
        if self._sortorder == sortorder:
            return
        self._sortorder = sortorder
        if node is None:
            node = self.root
        self._sort(node)

    def _sort(self, node):
        childs = self.get_children(node)
        for child in childs:
            self._sort(child)
        self.sort_children(node)

    def close_window(self):
        utils.profile_set(globalkeys.OUTLINE_SORT_KEY, self._sortorder)
        return True

    @property
    def nonelabel(self):
        return self.__nonelabel

    def create_nonelabel(self, text=""):
        self.__nonelabel = QLabel(text)
        self.__nonelabel.setFrameShape(QFrame.StyledPanel)
        self.__nonelabel.setAlignment(Qt.AlignHCenter)
        # 标签文本自动换行
        self.__nonelabel.setWordWrap(True)
        headerFont = self.__nonelabel.font()
        headerFont.setPointSize(headerFont.pointSize() + 2)
        self.__nonelabel.setFont(headerFont)
        self.__nonelabel.setAutoFillBackground(True)
        nonelabel_palette = self.__nonelabel.palette()
        nonelabel_palette.setColor(QPalette.Background,
                                   get_app().skin['nolexerPaper'])
        self.__nonelabel.setPalette(nonelabel_palette)

    def show_nonelabel(self, show=True, labeltext=""):
        if show:
            if labeltext:
                self.__nonelabel.setText(labeltext)
            self.__nonelabel.show()
            self.tree.hide()
        else:
            self.__nonelabel.hide()
            self.tree.show()
