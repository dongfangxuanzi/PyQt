from .. import _
from .debug import DebugFrame, DebugCtrl
from .debugger import CommonRunCommandUI


class TracedebugCtrl(DebugCtrl):

    STDOUT_LOG = "stdout"
    STDERR_LOG = "stderr"

    def __init__(self, parent):
        super().__init__(parent)
        self.logs = {}

    def AppendStdoutText(self, source, text, last_readonly=False):
        super().AppendStdoutText(source, text, last_readonly)
        self.append_logs(source, text)

    def AppendStdErrorText(self, source, text, last_readonly=False):
        super().AppendStdErrorText(source, text, last_readonly)
        self.append_logs(source, text, stderr=True)

    def append_logs(self, source, txt, stderr=False):
        category = self.STDOUT_LOG
        if stderr:
            category = self.STDERR_LOG
        # 将日志输出按来源归类保存
        if source in self.logs:
            self.logs[source].append([category, txt])
        else:
            self.logs[source] = [[category, txt]]

    def setlogs(self, source):
        '''
            根据输出来源设置输出日志
        '''
        logs = self.logs[source]
        self.ClearOutput()
        self.setReadOnly(False)
        for category, text in logs:
            # 显示标准输出日志
            if category == self.STDOUT_LOG:
                DebugCtrl.AppendStdoutText(self, source, text)
            #  显示错误输出日志
            elif category == self.STDERR_LOG:
                DebugCtrl.AppendStdErrorText(self, source, text)
        self.setReadOnly(True)


class TracedebugFrame(DebugFrame):
    def GetOuputctrlClass(self):
        return TracedebugCtrl


class OutputTracer(CommonRunCommandUI):
    def __init__(self, master, debugger):
        CommonRunCommandUI.__init__(self, master, debugger, None)
        self._tb.AddLabel(text=" " + _("Source") + ": ", pos=2)
        self.combo = self._tb.AddCombox(pos=2)
        # 根据输出来源来显示输出的日志
        self.combo.currentIndexChanged.connect(self.selectsource)
        self._tb.EnableTool(self.CLOSE_TAB_ID, False)
        # 不允许关闭输出窗口
        self._allow_close = False

    def GetOutputviewClass(self):
        return TracedebugFrame

    def AppendStdoutText(self, value, source):
        CommonRunCommandUI.AppendStdoutText(self, value, source)
        self.addsource(source)

    def AppendStdErrorText(self, value, source):
        CommonRunCommandUI.AppendStdErrorText(self, value, source)
        self.addsource(source)

    def addsource(self, source):
        '''
            把输出来源归类
        '''
        items = []
        for index in range(self.combo.count()):
            items.append(self.combo.itemText(index))
        if source not in items:
            self.combo.addItem(source)
            items.append(source)
        self.combo.setCurrentIndex(items.index(source))

    def selectsource(self):
        current_index = self.combo.currentIndex()
        if -1 == current_index:
            return
        source = self.combo.itemText(current_index)
        self.GetOutputCtrl().setlogs(source)
# ----------------------------------------------------------------------
