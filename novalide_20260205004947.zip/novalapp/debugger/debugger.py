# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------------
# Name:         DebuggerService.py
# Purpose:      Debugger Service for Python and PHP
#
# Author:       Matt Fryer
#
# Created:      12/9/04
# CVS-ID:       $Id$
# Copyright:    (c) 2004-2005 ActiveGrid, Inc.
# License:      wxWindows License
# ----------------------------------------------------------------------------
import os
from .. import menuitems, globalkeys
from . import executor
from ..bars import toolbar
from ..lib.pyqt import QFrame, Qt, QAction, pyqtSignal, QVBoxLayout, QHBoxLayout, QSize, QMessageBox
from ..lib.docview import View
from ..sidebar.sidebar import SideBar
from ..util.exceptions import catch_run_exception
from .debug import DebugFrame
from ..util import utils
from ..bars.menubar import NewQMenu
from .. import newid, get_app, _


class CommonRunCommandUI(QFrame):
    KILL_PROCESS_ID = newid()
    CLOSE_TAB_ID = newid()
    RESTART_PROCESS_ID = newid()
    SIG_UPDATE_STDTEXT = pyqtSignal(str, str)
    SIG_UPDATE_ERRTEXT = pyqtSignal(str, str)
    SIG_EXECUTE_FINISHED = pyqtSignal(int, bool)
    runners = []

    def __init__(
        self,
        parent,
        debugger,
        run_parameter,
        append_runner=True,
        toolbar_orient=Qt.Horizontal
    ):
        QFrame.__init__(self, parent)
        self._debugger = debugger
        self._run_parameter = run_parameter
        self._restarted = False
        self._stopped = False
        # GUI Initialization follows
        self._tb = toolbar.ToolBar(self, orient=toolbar_orient)
        self._tb.setIconSize(QSize(16, 16))
        self.CreateToolbarButtons()
        self._output = self.GetOutputviewClass()(self)  # id)
        self._textctrl = self._output.GetOutputCtrl()
        if toolbar_orient == Qt.Horizontal:
            layout = QVBoxLayout()
        elif toolbar_orient == Qt.Vertical:
            layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._tb)
        layout.addWidget(self._output)
        self.setLayout(layout)
        if append_runner:
            CommonRunCommandUI.runners.append(self)
        # 是否允许关闭输出窗口,默认允许
        self._allow_close = True
        # Executor initialization
        self._executor = None
        if self._run_parameter is not None:
            self.CreateExecutor()
        self.EnableToolbar()
        # 在多线程中以信号的方式发送标准输出
        self.SIG_UPDATE_STDTEXT.connect(self.AppendStdoutText)
        # 在多线程中以信号的方式发送错误输出
        self.SIG_UPDATE_ERRTEXT.connect(self.AppendStdErrorText)
        # 在多线程中以信号的方式发送进程结束消息
        self.SIG_EXECUTE_FINISHED.connect(self.ExecutorFinished)

    @property
    def allow_close(self):
        return self._allow_close

    def GetTextCtrl(self):
        return self._textctrl

    def EnableToolbar(self):
        if self._executor is None:
            enable = False
        else:
            enable = True
        self._tb.EnableTool(self.KILL_PROCESS_ID, enable=enable)
        self._tb.EnableTool(self.RESTART_PROCESS_ID, enable=enable)

    def CreateToolbarButtons(self):
        self.restart_image = get_app().GetImage("python/debugger/restart.png")
        self.close_img = get_app().GetImage("python/debugger/close.png")
        self.stop_img = get_app().GetImage("python/debugger/stop.png")

        close_tb_button = QAction(self.close_img, _("Close window"), self)
        close_tb_button.triggered.connect(
            lambda: self.OnToolClicked(self.CLOSE_TAB_ID))
        self._tb.AddButton(self.CLOSE_TAB_ID, close_tb_button)

        stop_tb_button = QAction(self.stop_img, _("Stop the run."), self)
        stop_tb_button.triggered.connect(
            lambda: self.OnToolClicked(self.KILL_PROCESS_ID))
        self._tb.AddButton(self.KILL_PROCESS_ID, stop_tb_button)

        restart_tb_button = QAction(
            self.restart_image, _("Restart the run."), self)
        restart_tb_button.triggered.connect(
            lambda: self.OnToolClicked(self.RESTART_PROCESS_ID))
        self._tb.AddButton(self.RESTART_PROCESS_ID, restart_tb_button)

    def SetRunParameter(self, run_parameter):
        self._run_parameter = run_parameter

    def CreateExecutor(self, source=executor.SOURCE_DEBUG, finish_stopped=True):
        '''
            finish_stopped表示该执行器支持完成后,是否表示整个运行完成,大部分情况下一个进程执行完成,就表示改运行完成
            考虑到一次完整的运行可能需要连续执行几个进程,第一个进程执行完后并不表示整个执行完成,要接着执行下一个,直到最后一个进程执行完成才表示运行完成
            source表示输出日志来源,比如有的是build输出,有的是debug输出,默认是debug输出
        '''
        self._executor = self.GetExecutorClass()(
            self._run_parameter, self, finish_stopped, source=source)
        self._output.SetExecutor(self._executor)

    def GetExecutorClass(self):
        return executor.Executor

    def GetOutputview(self):
        return self._output

    def GetOutputviewClass(self):
        return DebugFrame

    def update_startup_command(self):
        if not utils.profile_get_int(globalkeys.START_UP_COMMAND_KEY, False):
            return
        self._textctrl.AppendStdoutText(
            self._executor.source,
            self._executor.process._cmd + os.linesep
        )

    @catch_run_exception
    def Execute(self):
        try:
            self._executor.Execute()
            self.update_startup_command()
        except Exception as e:
            self.StopExecution()
            self.ExecutorFinished(-1)
            raise e

    def IsProcessRunning(self):
        return not self.Stopped

    @property
    def Stopped(self):
        return self._stopped

    def update_proc_exitcode(self, exitcode):
        if not utils.profile_get_int(globalkeys.OUTPUT_EXITCODE_KEY, False):
            return
        process_exit_msg = _('Process finished with exitcode %d') % exitcode
        # 程序正常退出,标准输出
        if 0 == exitcode:
            self._textctrl.AppendStdoutText(self._executor.source, process_exit_msg, last_readonly=True)
        # 程序非正常退出,错误输出
        else:
            self._textctrl.AppendStdErrorText(self._executor.source, process_exit_msg, last_readonly=True)

    def ExecutorFinished(self, exitcode, stopped=True):
        '''
            stopped表示该执行完成后是否表示整个运行完成了,stopped为True表示是,为False表示否,意外着还有下一个执行
        '''
        self._stopped = stopped
        self._tb.EnableTool(self.KILL_PROCESS_ID, False)
        self.update_proc_exitcode(exitcode)
        self._textctrl.setReadOnly(True)
        # 如果是点了重新执行按钮,程序执行完成后,需要再运行一次
        if self._restarted:
            self.RestartRunProcess()
            self._restarted = False

    def StopExecution(self, unbind_evt=False):
        # 终止正在允许的进程
        if not self._stopped:
            if self._executor is None:
                utils.get_logger().error("executor is none on output window.....")
            else:
                self._executor.DoStopExecution()
            self._textctrl.setReadOnly(True)
        # 移除调试窗口时接触信号槽的绑定
        if unbind_evt:
            self.SIG_UPDATE_STDTEXT.disconnect(self.AppendStdoutText)
            self.SIG_UPDATE_ERRTEXT.disconnect(self.AppendStdErrorText)
            self.SIG_EXECUTE_FINISHED.disconnect(self.ExecutorFinished)

    def AppendStdoutText(self, value, source):
        # 程序终止或完成时把输出框设置为只读
        self._textctrl.AppendStdoutText(source, value, self._stopped)

    def AppendStdErrorText(self, value, source):
        # 程序终止或完成时把输出框设置为只读
        self._textctrl.AppendStdErrorText(source, value, self._stopped)

    def StopAndRemoveUI(self):
        '''
            关闭调试窗口时如果有正在允许的进程,询问用户是否关闭正在允许的进程.
            如果用户允许则关闭,否则不允许关闭.
            如果退出程序时亦然,如果用户不允许,则不能退出程序
        '''
        # 关闭窗口之前检查是否有进程在运行
        if not self._stopped and self._executor is not None:
            ret = QMessageBox.question(
                self,
                _("Process running.."),
                _("Process is still running,Do you want to kill the process and remove it?")
            )
            if ret == QMessageBox.No:
                return False
        self.StopExecution(unbind_evt=True)
        return self.remove_page()

    def remove_page(self):
        # 关闭调试窗口,移除notebook的标签页
        nb = self.bottomTab()
        nb.removeTab(self)
        return True

    def bottomTab(self):
        nb = self.parent().parent()
        return nb

    def close_window(self):
        '''
            允许关闭调试窗口,在关闭调试器时再询问用户是否关闭调试窗口
        '''
        return True

    def SaveProjectFiles(self):
        '''
            调式运行时保存文件策略,默认保存当前项目的修改文件
        '''
        self._debugger.GetCurrentProject().PromptToSaveFiles()

    def RestartProcess(self):
        self.SaveProjectFiles()
        if not self._stopped:
            self._restarted = True
            self.StopExecution()
        else:
            self.RestartRunProcess()

    def RestartRunProcess(self):
        self._textctrl.ClearOutput()
        self._tb.EnableTool(self.KILL_PROCESS_ID, True)
        self._stopped = False
        self.Execute()

    # ------------------------------------------------------------------------------
    # Event handling
    # -----------------------------------------------------------------------------

    def OnToolClicked(self, id):
        if id == self.KILL_PROCESS_ID:
            self.StopExecution()

        elif id == self.CLOSE_TAB_ID:
            self.StopAndRemoveUI()

        elif id == self.RESTART_PROCESS_ID:
            self.RestartProcess()

    def Close(self):
        self.StopAndRemoveUI()

    def GetOutputCtrl(self):
        return self._textctrl


class DebugView(View):
    '''
        调试视图,所有调式输出窗口共用这个一个视图
    '''

    def __init__(self, debugger):
        self._debugger = debugger
        super().__init__()

    def GetCtrl(self):
        '''
            获取底部标签页输出窗口的控件
        '''
        select_page = self._debugger.bottomTab.currentWidget()
        if select_page is None:
            return None
        debug_page = select_page
        if not isinstance(debug_page, CommonRunCommandUI):
            return None
        return debug_page.GetOutputview().GetOutputCtrl()

    def ProcessEvent(self, command_id):
        if self.GetCtrl() is None:
            return
        self.GetCtrl().ProcessEvent(command_id)

    def UpdateUI(self, command_id):
        if self.GetCtrl() is None:
            return False
        return self.GetCtrl().ProcessUpdateEvent(command_id)

    def DoFind(self):
        if self.GetCtrl() is None:
            return
        self.GetCtrl().DoFind()


class Debugger:

    DebugView = None
    # ----------------------------------------------------------------------------
    # Overridden methods
    # ----------------------------------------------------------------------------

    def __init__(self):
        self.current_project = None
        self.bottomTab = get_app().MainFrame._view_sidebars[SideBar.South]
        self._tabs_menu = None
        self._popup_index = -1
        if Debugger.DebugView is None:
            Debugger.DebugView = self._CreateView()
            # 绑定调试标签页右键单击事件
            self.bottomTab.tabbar.setContextMenuPolicy(Qt.CustomContextMenu)
            self.bottomTab.tabbar.customContextMenuRequested.connect(
                self._right_btn_press)

    def _CreateView(self):
        return DebugView(self)

    def GetView(self):
        return self.DebugView

    def SetCurrentProject(self, current_proj):
        self.current_project = current_proj
        if self.current_project is not None:
            self.current_project.SetDebugger(self)

    @staticmethod
    def CloseDebugger():
        return True

    # ----------------------------------------------------------------------------
    # Service specific methods
    # ----------------------------------------------------------------------------
    # ----------------------------------------------------------------------------
    # Class Methods
    # ----------------------------------------------------------------------------

    def GetKey(self, currentproj, lastpart):
        if currentproj:
            return currentproj.GetKey(lastpart)
        return lastpart

    def GetCurrentProject(self, always_have_one=True):
        if always_have_one and self.current_project is None:
            # 获取项目实际的项目文档类
            # 在运行单个文件时,默认创建一个项目文档,以此类运行单个文件,这个项目文档是一个虚拟的项目,不会到添加程序的文档列表中
            return get_app().default_project_template.GetDocumentType().GetUnProjectDocument()
        return self.current_project

    def GetActiveView(self):
        current_editor = get_app().MainFrame.GetNotebook().get_current_editor()
        if current_editor is None:
            return None
        return current_editor.get_view()

    @catch_run_exception
    def Debug(self):
        self.GetCurrentProject().Debug()

    @catch_run_exception
    def Run(self):
        self.GetCurrentProject().Run()

    def GetBottomtabInstancePage(self, index):
        tab_page = self.bottomTab.widget(index)
        return tab_page

    def _right_btn_press(self, pos):
        clicked_index = self.bottomTab.tabbar.tabAt(pos)
        tabindex = self.bottomTab.currentIndex()
        if tabindex == clicked_index:
            self._popup_index = clicked_index
            self.create_tab_menu(pos)

    def create_tab_menu(self, pos):
        """
        Handles right clicks for the notebook, enabling users to either close
        a tab or select from the available documents if the user clicks on the
        notebook's white space.
        """
        if self._popup_index < 0:
            return
        tabpage = self.GetBottomtabInstancePage(self._popup_index)
        # 只有运行调试页面才弹出菜单
        if not hasattr(tabpage, 'StopAndRemoveUI') or not tabpage.allow_close:
            return
        if self._tabs_menu is None:
            self._tabs_menu = NewQMenu(self.bottomTab.tabbar)
            self._tabs_menu.Append(menuitems.ID_CLOSE, _(
                "Close"), handler=self.close_ui)
            self._tabs_menu.Append(menuitems.ID_CLOSE_ALL, _(
                "Close all"), handler=self.close_all_ui)
        self._tabs_menu.popup(self.bottomTab.tabbar.mapToGlobal(pos))

    def close_all_ui(self):
        '''
            关闭并移除所有运行调式标签页
        '''
        close_suc = True
        for i in range(self.bottomTab.count - 1, -1, -1):  # Go from len-1 to 1
            page = self.GetBottomtabInstancePage(i)
            close_suc = self.close_ui(page)
            # 关闭其中一个调试运行标签页失败,则表示关闭整个失败,在退出程序检查是否有进程运行时表示是否退出程序
            if not close_suc:
                return False
        return close_suc

    def close_ui(self, page=None):
        '''
            关闭并移除单个运行调式标签页
        '''
        if page is None:
            page = self.GetBottomtabInstancePage(self._popup_index)
        # 运行调试标签页关闭之前先检查进程是否在运行,并询问用户是否关闭
        if hasattr(page, 'StopAndRemoveUI') and page.allow_close:
            return page.StopAndRemoveUI()
        # 非运行调式标签页直接允许关闭
        return True
