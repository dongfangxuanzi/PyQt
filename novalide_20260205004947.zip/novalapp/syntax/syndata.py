# -*- coding: utf-8 -*-
import zlib
from .syntax import SyntaxThemeManager
from ..qtimage import load_icon
from ..editor import codeview
from ..common import compat


class BaseLexer:
    """Syntax data container object base class"""

    def __init__(self, langid):
        # Attributes
        self._langid = langid
        self.exts = []
        self._style_items = {}

    @property
    def DefaultCommentPattern(self):
        return self.GetDefaultCommentPattern()

    @property
    def CommentPatterns(self):
        return self.GetCommentPatterns()

    @property
    def Keywords(self):
        return self.GetKeywords()

    @property
    def LangId(self):
        return self.GetLangId()

    @property
    def style_items(self):
        return self._style_items

    @style_items.setter
    def style_items(self, style_options):
        self._style_items = style_options

    @property
    def Exts(self):
        if 0 == len(self.exts):
            self.exts = self.GetExt().split()
        return self.exts

    # ---- Interface Methods ----#

    def GetDefaultCommentPattern(self):
        """获取默认注释方式
        返回注释符号的列表
        如果列表只有一个元素,说明是行注释
        如果是列表有2个元素,说明是块注释
        一个语言可能有多种注释方式,这里返回优先使用的注释方式
        """
        return []

    def GetCommentPatterns(self):
        """获取语言所有的注释方式嵌套列表
        如果列表只有一个元素,说明是行注释
        如果是列表有2个元素,说明是块注释
        一个语言可能有多种注释方式,这里返回所有的注释方式列表
        列表为嵌套列表
        """
        return [self.DefaultCommentPattern, ]

    def GetKeywords(self):
        """Get the Keyword List(s)
        @return: list of tuples [(1, ['kw1', kw2']),]

        """
        return []

    def GetLangId(self):
        """Get the language id
        @return: int


        """
        return self._langid

    def SetLangId(self, lid):
        """Set the language identifier
        @param lid: int

        """
        self._langid = lid

    def register(self):
        SyntaxThemeManager.manager().register(self)

    def unregister(self):
        SyntaxThemeManager.manager().unregister(self)

    def GetDescription(self):
        return ""

    def GetShowName(self):
        return ""

    def GetDefaultExt(self):
        return ""

    def GetExt(self):
        return ""

    def GetDocTypeName(self):
        return ""

    def GetViewTypeName(self):
        return ""

    def GetDocTypeClass(self):
        return None

    def GetViewTypeClass(self):
        return None

    def GetDocIcon(self):
        return None

    def GetSampleCode(self):
        return ''

    def GetCommentTemplate(self):
        return None

    def IsCommentTemplateEnable(self):
        return self.GetCommentTemplate() is not None

    def GetExtStr(self):
        if len(self.Exts) == 0:
            return ""
        strext = "*." + self.Exts[0]
        for ext in self.Exts[1:]:
            strext += ";"
            strext += "*."
            strext += ext
        return strext

    def ContainExt(self, ext):
        ext = ext.replace(".", "")
        for ext_name in self.Exts:
            if ext.lower() == ext_name:
                return True
        return False

    def GetSampleCodeFromFile(self, sample_file_path, is_zip_compress=True):
        if not is_zip_compress:
            with open(sample_file_path) as f:
                return f.read()
        else:
            content = ''
            with open(sample_file_path, 'rb') as f:
                decompress = zlib.decompressobj()
                data = f.read(1024)
                while data:
                    content += compat.ensure_string(
                        decompress.decompress(data))
                    data = f.read(1024)
                content += compat.ensure_string(decompress.flush())
            return content

    def IsVisible(self):
        return True

    def GetFileViewIcon(self):
        return load_icon('files/generic-file.gif')

    def theme_file(self):
        return "_txt.json"


class CodeBaseLexer(BaseLexer):
    def __init__(self, langid):
        super().__init__(langid)
        self._maximum_keywordset = 3

    def GetDocTypeClass(self):
        return codeview.CodeDocument

    def GetViewTypeClass(self):
        return codeview.CodeView

    def get_lexer(self, parent):
        return None

    def get_default_keywords(self, lexer):
        keywords = []
        for kwset in range(1, self._maximum_keywordset + 1):
            keystr = lexer.keywords(kwset)
            if keystr is not None:
                keywords.extend(keystr.split())
        return keywords

    def theme_file(self):
        return None
