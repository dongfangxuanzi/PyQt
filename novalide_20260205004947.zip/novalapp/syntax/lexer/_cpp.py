# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _cpp.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
import os
import _c
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.util import appdirs
from novalapp.qtimage import load_icon
from novalapp.lib.qsci import QsciLexerCPP
# -----------------------------------------------------------------------------#

# ---- Keyword Specifications ----#

kwlist = _c.kwlist + ["class", 'namespace', "public",
                      "private", "protected", "virtual", "friend"]


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_CPP")
        super().__init__(lang_id)
        self._maximum_keywordset = 2

    def GetDescription(self):
        return _('C++ Source File')

    def GetExt(self):
        return "cc c++ cpp cxx hh h++ hpp hxx"

    def GetDefaultCommentPattern(self):
        """c++有2种注释方式,这里默认使用行注释方式"""
        return ['//']

    def GetCommentPatterns(self):
        """
            c++注释有2种,行注释和块注释
        """
        return [self.DefaultCommentPattern, ['/*', '*/']]

    def GetShowName(self):
        return "C/C++"

    def GetDefaultExt(self):
        return "cpp"

    def GetDocTypeName(self):
        return "C++ Document"

    def GetViewTypeName(self):
        return _("C++ Editor")

    def GetDocIcon(self):
        return load_icon("file/cpp.png")

    def GetSampleCode(self):
        sample_file_path = os.path.join(
            appdirs.get_app_data_location(), "sample", "cpp.sample")
        return self.GetSampleCodeFromFile(sample_file_path)

    def GetCommentTemplate(self):
        return '''//******************************************************************************
// Name: {File}
// Copyright: (c) {Author} {Year}
// Author: {Author}
// Created: {Date}
// Description:
// Licence:     {Licence}
//******************************************************************************
'''

    def GetKeywords(self):
        return kwlist + _c._builtinlist

    def get_lexer(self, parent):
        return QsciLexerCPP(parent)
