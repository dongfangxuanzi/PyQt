# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _xml.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
import os
import json
from PyQt5.Qsci import QsciLexerJSON
from novalapp.util import appdirs
from novalapp.qtimage import load_icon
from novalapp import _, newid
from novalapp.syntax import syndata, lang
from novalapp.common.compat import ensure_string
from novalapp.lib.pyqt import QMessageBox
# -----------------------------------------------------------------------------#


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_JSON")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('Json File')

    def GetExt(self):
        return "json"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['<!--', '-->']

    def GetShowName(self):
        return "Json"

    def GetDefaultExt(self):
        return "json"

    def GetDocTypeName(self):
        return "Json Document"

    def GetViewTypeName(self):
        return _("Json Editor")

    def GetDocIcon(self):
        return load_icon("file/json.png")

    def GetSampleCode(self):
        sample_file_path = os.path.join(
            appdirs.get_app_data_location(), "sample", "json.sample")
        return self.GetSampleCodeFromFile(sample_file_path)

    def get_lexer(self, parent):
        parent.parent().SIG_EDIT_TEXT_POPUP_MENU.connect(self.append_edit_text_menu)
        return QsciLexerJSON(parent)

    def append_edit_text_menu(self, menu, editor):
        menu.Append(newid(), _("Json Format"), handler=lambda: self.format_json(editor))

    def format_json(self, editor):
        doc = editor.get_view().GetDocument()
        try:
            if not doc.IsNewDocument:
                filename = doc.GetFilename()
                with open(filename, encoding=doc.file_encoding) as fr:
                    data = json.load(fr)
            else:
                value = editor.text()
                data = json.loads(ensure_string(value, encoding="utf-8"))
        except Exception as ex:
            QMessageBox.critical(
                editor,
                _('Error'),
                str(ex)
            )
            return
        text = json.dumps(data, indent=4)
        editor.setText(text)
