# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _xml.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
import os
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.util import appdirs
from novalapp.qtimage import load_icon
from novalapp.lib.qsci import QsciLexerXML
# -----------------------------------------------------------------------------#


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_XML")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('XML File')

    def GetExt(self):
        return "axl dtd plist rdf svg xml xrc xsd xsl xslt xul"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['<!--', '-->']

    def GetShowName(self):
        return "XML"

    def GetDefaultExt(self):
        return "xml"

    def GetDocTypeName(self):
        return "XML Document"

    def GetViewTypeName(self):
        return _("XML Editor")

    def GetDocIcon(self):
        return load_icon("file/xml.png")

    def GetSampleCode(self):
        sample_file_path = os.path.join(
            appdirs.get_app_data_location(), "sample", "xml.sample")
        return self.GetSampleCodeFromFile(sample_file_path)

    def get_lexer(self, parent):
        return QsciLexerXML(parent)
