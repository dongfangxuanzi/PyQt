# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _html.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
import os
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.util import appdirs
from novalapp.qtimage import load_icon
from novalapp.lib.qsci import QsciLexerHTML
# -----------------------------------------------------------------------------#
# -----------------------------------------------------------------------------#

# HTML Tags (HTML4)
HTML_TAGS = "address applet area a base basefont big blockquote br caption "\
            "center cite code dd dfn dir div dl dt font form hr html img "\
            "input isindex kbd li link map menu meta ol option param pre p "\
            "samp span select small strike sub sup table td textarea th tr "\
            "script noscript tt ul var xmp b i u h1 h2 h3 h4 h5 h6 em "\
            "strong head body title "\
            "abbr acronym bdo button col label colgroup del fieldset "\
            "iframe ins legend object optgroup q s tbody tfoot thead "\
            "article aside audio canvas command datalist details dialog "\
            "embed figcaption figure footer header hgroup keygen mark "\
            "meter nav output progress rp rt ruby section source time "\
            "video "\
            "action align alink alt archive background bgcolor border "\
            "bordercolor cellpadding cellspacing checked class clear "\
            "codebase color cols colspan content coords enctype face "\
            "gutter height hspace id link lowsrc marginheight marginwidth "\
            "maxlength method name prompt rel rev rows rowspan scrolling "\
            "selected shape size src start target text type url usemap "\
            "ismap valign value vlink vspace width wrap href http-equiv "\
            "accept accesskey axis char charoff charset cite classid "\
            "codetype compact data datetime declare defer dir disabled for "\
            "frame headers hreflang lang language longdesc multiple nohref "\
            "nowrap profile readonly rules scheme scope standby style "\
            "summary tabindex valuetype version "\
            "async autocomplete contenteditable contextmenu date "\
            "datetime-local draggable email formaction formenctype "\
            "formmethod formnovalidate formtarget hidden list manifest max "\
            "media min month novalidate number pattern ping range required "\
            "reversed role sandbox scoped seamless search sizes spellcheck "\
            "srcdoc step tel week "\
            "dtml-var dtml-if dtml-unless dtml-in dtml-with dtml-let "\
            "dtml-call dtml-raise dtml-try dtml-comment dtml-tree"\

SGML_KEYWORDS = "ELEMENT DOCTYPE ATTLIST ENTITY NOTATION"

KW_LIST = HTML_TAGS.split() + SGML_KEYWORDS.split()


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_HTML")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('HTML File')

    def GetExt(self):
        return "html htm shtm shtml xhtml"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['<!--', '-->']

    def GetShowName(self):
        return "HTML"

    def GetDefaultExt(self):
        return "html"

    def GetDocTypeName(self):
        return "HTML Document"

    def GetViewTypeName(self):
        return _("HTML Editor")

    def GetDocIcon(self):
        return load_icon("file/html.png")

    def GetSampleCode(self):
        sample_file_path = os.path.join(
            appdirs.get_app_data_location(), "sample", "html.sample")
        return self.GetSampleCodeFromFile(sample_file_path)

    def GetKeywords(self):
        return KW_LIST

    def get_lexer(self, parent):
        return QsciLexerHTML(parent)
