# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _javascript.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.qtimage import load_icon
from novalapp.lib.qsci import QsciLexerJavaScript
# -----------------------------------------------------------------------------#
# -----------------------------------------------------------------------------#

KW_LIST = ['break', 'delete', 'function', 'return', 'typeof', 'case', 'do', 'if',
           'switch', 'var', 'catch', 'else', 'in', 'this', 'void', 'continue',
           'false', 'instanceof', 'throw', 'while', 'debugger', 'finally',
           'new', 'true', 'with', 'default', 'for', 'null', 'try']


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_JS")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('JavaScript File')

    def GetExt(self):
        return "js"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['//']

    def GetCommentPatterns(self):
        """
            js注释有2种,行注释和块注释
        """
        return [self.DefaultCommentPattern, ['/*', '*/']]

    def GetShowName(self):
        return "JavaScript"

    def GetDefaultExt(self):
        return "js"

    def GetDocTypeName(self):
        return "JavaScript Document"

    def GetViewTypeName(self):
        return _("JavaScript Editor")

    def GetDocIcon(self):
        return load_icon("file/javascript.png")

    def get_lexer(self, parent):
        return QsciLexerJavaScript(parent)

    def GetKeywords(self):
        return KW_LIST
