# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        _txt.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:      GPL-3.0
-------------------------------------------------------------------------------
'''
import os
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.util import appdirs
from novalapp.editor import textview
from novalapp.qtimage import text_icon, load_icon

# ------------------------------------------------------------------------------#


class SyntaxLexer(syndata.BaseLexer):
    """SyntaxData object for many C like languages"""

    def __init__(self):
        super().__init__(lang.ID_LANG_TXT)

    def GetShowName(self):
        return "Plain Text"

    def GetDefaultExt(self):
        return "txt"

    def GetExt(self):
        return "txt text"

    def GetDocTypeName(self):
        return "Text Document"

    def GetViewTypeName(self):
        return _("Text Editor")

    def GetDocTypeClass(self):
        return textview.TextDocument

    def GetViewTypeClass(self):
        return textview.TextView

    def GetDocIcon(self):
        return text_icon()

    def GetDescription(self):
        return _("Text File")

    def GetFileViewIcon(self):
        return load_icon('files/text-file.gif')

    def GetSampleCode(self):
        sample_file_path = os.path.join(
            appdirs.get_app_data_location(), "sample", "txt.sample")
        return self.GetSampleCodeFromFile(sample_file_path)
