# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _c.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.qtimage import load_icon
from novalapp.lib.qsci import QsciLexerCPP
# -----------------------------------------------------------------------------#

# ---- Keyword Specifications ----#

kwlist = [
    'auto',
    'double',
    'int',
    'struct',
    'break',
    'else',
    'long',
    'switch',
    'case',
    'enum',
    'register',
    'typedef',
    'char',
    'extern',
    'return',
    'union',
    'const',
    'float',
    'short',
    'unsigned',
    'continue',
    'for',
    'signed',
    'void',
    'default',
    'goto',
    'sizeof',
    'volatile',
    'do',
    'if',
    'while',
    'static'
]


_builtinlist = [
    'printf',
    'scanf',
    'getchar',
    'putchar',
    'time',
    'strcpy',
    'strcmp',
    'isupper',
    'memset',
    'islower',
    'isalpha',
    'isdigit',
    'toupper',
    'tolower',
    'ceil',
    'floor',
    'sqrt',
    'pow',
    'abs',
    'rand',
    'system',
    'exit',
    'srand'
]


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_C")
        super().__init__(lang_id)
        self._maximum_keywordset = 2

    def GetDescription(self):
        return _('C Source File')

    def GetExt(self):
        return "c"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['/*', '*/']

    def GetShowName(self):
        return "C"

    def GetDefaultExt(self):
        return "c"

    def GetDocTypeName(self):
        return "C Document"

    def GetViewTypeName(self):
        return _("C Editor")

    def GetDocIcon(self):
        return load_icon("file/c_file.gif")

    def GetCommentTemplate(self):
        return '''/*******************************************************************************
* Name: {File}
* Copyright: (c) {Author} {Year}
* Author: {Author}
* Created: {Date}
* Description:
* Licence:     {Licence}
********************************************************************************/
'''

    def IsVisible(self):
        return False

    def GetKeywords(self):
        return kwlist + _builtinlist

    def get_lexer(self, parent):
        return QsciLexerCPP(parent)
