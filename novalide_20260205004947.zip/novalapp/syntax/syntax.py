import os
import json
import copy
from ..util import utils
from ..common.singleton import SingletonMeta
from . import lang


class SyntaxThemeManager(object, metaclass=SingletonMeta):
    """Class Object for managing loaded syntax data. The manager
    is only created once as a singleton and shared amongst all
    editor windows

    """

    SYNTAX_THEMES = {}         # Static cache for loaded theme set(s)

    def __init__(self, config=None):
        """Initialize a syntax manager. If the optional
        value config is set the mapping of extensions to
        lexers will be loaded from a config file.
        @keyword config: path of config file to load file extension config from

        """
        self.syntax_set = []
        self.lexers = []
        self.style_set = ""
        self._syntax_themes = set()

    @property
    def Lexers(self):
        return self.lexers

    @property
    def syntax_themes(self):
        return self._syntax_themes

    @staticmethod
    def manager():
        return SyntaxThemeManager()

    @classmethod
    def update_dict(cls, key, src_dict, dest_dict):
        if key in dest_dict:
            if isinstance(dest_dict[key], dict):
                for childkey in src_dict[key]:
                    cls.update_dict(childkey, src_dict[key], dest_dict[key])
            else:
                dest_dict.update({key: src_dict[key]})
        else:
            dest_dict[key] = src_dict[key]

    @classmethod
    def SetSyntaxTheme(cls, style_set):
        cls.SYNTAX_THEMES = style_set

    def load_syntax_themes(self, lexer):
        theme_file_name = lexer.theme_file()
        if not theme_file_name:
            return
        data_path = utils.get_app_data_location()
        syntax_data_path = os.path.join(data_path, "syntax", "themes")
        datas = []
        for dirname in os.listdir(syntax_data_path):
            theme_file_path = os.path.join(
                syntax_data_path, dirname, theme_file_name)
            utils.get_logger().debug('theme file path is %s', theme_file_path)
            if os.path.exists(theme_file_path):
                with open(theme_file_path) as fp:
                    data = json.load(fp)
                    datas.append(data)
                    lexer.style_items[data['name']] = data
                    self._syntax_themes.add(data['name'])
        for data in datas:
            if 'parent' in data:
                self.apply_syntax_theme(data['name'], data['parent'], lexer)

    def register(self, lang_lexer):
        for lexer in self.lexers:
            if lang_lexer == lexer:
                return False
        self.lexers.append(lang_lexer)
        self.load_syntax_themes(lang_lexer)
        return True

    def unregister(self, lang_lexer):
        if -1 == self.lexers.index(lang_lexer):
            return False
        self.lexers.remove(lang_lexer)
        return True

    def GetLexer(self, lang_id):
        for lexer in self.lexers:
            if lexer.LangId == lang_id:
                return lexer
        return self.GetLexer(lang.ID_LANG_TXT)

    def GetLangLexerFromExt(self, ext):
        for lexer in self.lexers:
            if lexer.ContainExt(ext):
                return lexer
        return self.GetLexer(lang.ID_LANG_TXT)

    def IsExtSupported(self, ext):
        for lexer in self.lexers:
            if lexer.ContainExt(ext):
                return True
        return False

    def GetLangLexerFromShowname(self, showname):
        for lexer in self.lexers:
            if lexer.GetShowName() == showname:
                return lexer
        return self.GetLexer(lang.ID_LANG_TXT)

    def apply_syntax_theme(self, name, parent, lexer):
        def get_settings(name):
            try:
                settings = lexer.style_items[name]
                parent = settings.get('parent', None)
            except KeyError:
                utils.get_logger().exception("Can't find theme '%s'", parent)
                return {}

            if callable(settings):
                settings = settings()
            if parent is None:
                return settings
            parent_settings = get_settings(parent)
            result = copy.deepcopy(parent_settings)
            for key in settings:
                self.update_dict(key, settings, result)
            return result
        settings = get_settings(name)
        del settings['name']
        lexer.style_items[name] = settings

    def GetShowNameList(self):
        name_list = []
        for lexer in self.lexers:
            if lexer.IsVisible():
                name_list.append(lexer.GetShowName())
        return name_list
