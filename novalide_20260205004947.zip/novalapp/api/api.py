import json
import logging
from ..util import urlutils

log = logging.getLogger(__name__)


class ApiServer:
    # HOST_SERVER_ADDR = 'http://127.0.0.1:8000'
    HOST_SERVER_ADDR = 'http://www.novalide.com'
    # HOST_SERVER_ADDR = 'http://47.105.90.123:8080/'

    def __init__(self):
        self.root_addr = self.HOST_SERVER_ADDR

    @staticmethod
    def json_data(data, indent=4):
        return json.dumps(data, indent=indent)

    def api_root_addr(self):
        api_addr = f'{self.root_addr}/api/'
        return api_addr

    def get_api_addr(self, addr):
        if addr.startswith('/'):
            addr = addr.lstrip('/')
        return self.api_root_addr() + addr

    def request_addr(self, addr, arg={}, method='get'):
        '''访问老标准url接口'''
        data = urlutils.request_data(addr, arg, method)
        log.debug('request addr %s param %s data is %s', addr,
                  self.json_data(arg), self.json_data(data))
        return data

    def request_api(self, addr, arg={}, method='get'):
        '''访问新的标准api url接口'''
        api_addr = self.get_api_addr(addr)
        data = urlutils.request_data(api_addr, arg, method)
        log.debug('request api addr %s param %s data is %s',
                  api_addr, self.json_data(arg), self.json_data(data))
        return data
