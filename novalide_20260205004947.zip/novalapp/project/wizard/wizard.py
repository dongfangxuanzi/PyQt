# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        Wizard.py
Purpose:     新建项目向导模块

Author:      wukan

Created:     2019-03-11
Copyright:   (c) wukan 2019
Licence:      GPL-3.0
-------------------------------------------------------------------------------
'''
from ... import _
from ...lib.pyqt import (
    QHBoxLayout,
    QPushButton,
    Qt,
    QFrame,
    QVBoxLayout
)
from ...util import ui_utils


class BaseWizard(ui_utils.BaseModalDialog):
    def __init__(self, master):
        super().__init__('', master)
        self.current_page = None
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.content = QFrame(self)
        vbox = QVBoxLayout()

        bottom_page = QHBoxLayout()
        bottom_page.setAlignment(Qt.AlignRight)
        self.prev_button = QPushButton(_("<Previous"))
        self.prev_button.clicked.connect(self.GotoPrevPage)
        self.prev_button.setEnabled(False)
        bottom_page.addWidget(self.prev_button, 0, Qt.AlignRight)

        self.next_button = QPushButton(_("Next>"))
        self.next_button.clicked.connect(self.GotoNextPage)
        self.next_button.setEnabled(False)
        bottom_page.addWidget(self.next_button, 0, Qt.AlignRight)

        buttonbox = self.create_standard_buttons_box()
        self.ok_button.setEnabled(False)
        self.ok_button.setText(_("&Finish"))
        bottom_page.addWidget(buttonbox, 0, Qt.AlignRight)
        vbox.addLayout(bottom_page)
        self.content.setLayout(vbox)
        self.layout.addWidget(self.content)

    def SetPrevNext(self, prev, follow):
        prev.SetNext(follow)
        follow.SetPrev(prev)

    def RunWizard(self, firstpage):
        '''
            显示向导对话框并显示第一个页面
        '''
        self.firstpage = firstpage
        self.current_page = self.firstpage
        self.setWindowTitle(self.firstpage.title)
        self.exec_()

    def _ok(self, event=None):
        # ok按钮处于不可用状态时无法执行回车键操作
        if not self.ok_button.isEnabled():
            return
        if not self.current_page.Validate():
            return

        # 从第一页开始调用每个页面的Finish方法
        follow = self.firstpage.GetNext()
        while follow:
            if not follow.Finish():
                return
            follow = follow.GetNext()
        self.close()

    def _cancel(self, event=None):
        # 向每一级页面通知Cancel
        follow = self.firstpage.GetNext()
        while follow:
            follow.Cancel()
            follow = follow.GetNext()
        self.reject()

    def FitToPage(self, page):
        '''
            更换页面
        '''
        if self.current_page is not None:
            self.current_page.setVisible(False)
            self.content.layout().removeWidget(self.current_page)
        self.content.layout().insertWidget(0, page)
        page.setVisible(True)

    def GotoNextPage(self):
        '''
            显示下一页页面
        '''
        if not self.current_page.Validate():
            return
        follow = self.current_page.GetNext()
        if follow is None:
            self.UpdateNext(self.current_page)
            return
        follow.Init()
        self.FitToPage(follow)
        self.SetTitle(follow)
        self.current_page = follow
        self.UpdateNext(self.current_page)
        self.prev_button.setEnabled(True)
        self.SetFinish(self.current_page.CanFinish())

    def GotoPrevPage(self):
        '''
            显示上一页页面
        '''
        prev = self.current_page.GetPrev()
        if prev is None:
            self.UpdatePrev(self.current_page)
            return
        self.FitToPage(prev)
        self.SetTitle(prev)
        self.current_page = prev
        self.UpdatePrev(self.current_page)
        self.next_button.setEnabled(True)
        self.SetFinish(self.current_page.CanFinish())

    def SetTitle(self, page):
        '''
            设置向导对话框标题
        '''
        title = page.title
        if not title:
            title = self.firstpage.title
        self.setWindowTitle(title)

    def SetFinish(self, can_finish=True):
        '''
            该页面是否允许完成操作
        '''
        if can_finish:
            self.ok_button.setEnabled(True)
        else:
            self.ok_button.setEnabled(False)

    def UpdateNext(self, cur_page):
        '''
            该页面是否有下一个页面来更新下一个按钮状态
        '''
        follow = cur_page.GetNext()
        if follow is None:
            self.next_button.setEnabled(False)
            return
        self.next_button.setEnabled(True)

    def UpdatePrev(self, cur_page):
        '''
            该页面是否有上一个页面来更新上一个按钮状态
        '''
        prev = cur_page.GetPrev()
        if prev is None:
            self.prev_button.setEnabled(False)
            return
        self.prev_button.setEnabled(True)
