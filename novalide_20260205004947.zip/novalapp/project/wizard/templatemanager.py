# -*- coding: utf-8 -*-
from typing import NamedTuple, List
from ...common.singleton import SingletonMeta
from ...lib.pyqt import QTreeWidget, QSizePolicy, QTreeWidgetItem, Qt
from ...util import utils


class ProjectTemplate(NamedTuple):
    catlog: str
    name: str
    label: str
    path: str
    pages: List


class WizardtemplateManager(object, metaclass=SingletonMeta):
    """项目模板管理"""

    EMPTY_PROJECT = 'empty_project'
    PROJECT_FROM_EXIST_CODE = 'project_from_exist_code'

    def __init__(self):
        # 项目模板列表,存在先后顺序
        self.project_templates = []
        self.template_pages = {
        }
        # 用户选择的项目模板
        self.current_template = None
        self.wizard = None

    @staticmethod
    def get_manager():
        return WizardtemplateManager()

    def AddProjectTemplate(self, catlog, name, label, pages):
        if catlog.find(' ') != -1:
            raise RuntimeError("catlog could not contain blank character")
        path = catlog + "/" + name
        project_template = self.FindProjectTemplate(catlog)
        if not project_template:
            self.project_templates.append({
                catlog: [
                    ProjectTemplate(catlog, name, label, path, pages)
                ]
            }
            )
        else:
            project_template[catlog].append(
                ProjectTemplate(catlog, name, label, path, pages)
            )

    def FindProjectTemplate(self, template_catlog):
        for project_template in self.project_templates:
            if list(project_template.keys())[0] == template_catlog:
                return project_template
        return None

    def GetProjectTemplateNode(self, path):
        found = self.GetProjectTemplatePathNode(path, self.rootitem)
        sub_path = '/'.join(path.split('/')[0:-1])
        parent_node = self.GetProjectTemplatePathNode(sub_path, self.rootitem)
        if parent_node == '':
            parent_node = self.rootitem
        return found, parent_node

    def GetProjectTemplatePathNode(self, folder_path, item=None):
        for i in range(item.childCount()):
            child = item.child(i)
            # 获取存储的路径值
            path = child.data(0, Qt.UserRole)
            if folder_path == path:
                return child
            node_id = self.GetProjectTemplatePathNode(folder_path, child)
            if node_id:
                return node_id
        return ''

    def SetPagesChain(self, pages):
        '''
            设置各页面的链接关系
        '''
        if len(pages) == 0:
            return
        for i, page in enumerate(pages):
            if i >= len(pages) - 1:
                continue
            pages[i + 1].SetPrev(pages[i])
            pages[i].SetNext(pages[i + 1])

    def LoadProjectTemplates(self, wizard):
        for project_template in self.ProjectTemplates:
            template_catlog = list(project_template.keys())[0]
            catlogs = template_catlog.split('/')
            path = ''
            current = None
            for i, catlog_name in enumerate(catlogs):
                if i == 0:
                    path += catlog_name
                else:
                    path += "/" + catlog_name
                # found表示是否已经存在改路径的节点,node_id,表示从该节点下面插入
                found, parent = self.GetProjectTemplateNode(path)
                current = parent
                if not found:
                    node = QTreeWidgetItem()
                    parent.addChild(node)
                    node.setIcon(0, wizard.project_template_icon)
                    node.setText(0, catlog_name)
                    node.setData(0, Qt.UserRole, path)
                    current = node

            for template_info in project_template[template_catlog]:
                template_catlog = template_info.catlog
                template_name = template_info.label
                template_node = QTreeWidgetItem()
                current.addChild(template_node)
                template_node.setText(0, template_name)
                template_node.setData(0, Qt.UserRole, template_info)

                page_instances = self.InitPageInstances(template_info.pages)
                self.SetPagesChain(page_instances)
                self.template_pages[template_info.path] = page_instances
        self.treeview.setCurrentItem(self.rootitem.child(0))

    def InitPageInstances(self, pages):
        page_instances = []
        for page_info in pages:
            args = {}
            # 如果页面初始化需要参数,则使用列表或元祖的方式指定页面和参数信息
            if isinstance(page_info, list) or isinstance(page_info, tuple):
                # 列表的第一个元素为页面名称或类名
                page_class_obj = page_info[0]
                # 列表第二个元素为页面启动的参数,为字典类型
                args = page_info[1]
            else:
                page_class_obj = page_info
            try:
                # 如果类对象是字符串,则从字符串中动态获取类对象
                if isinstance(page_class_obj, str):
                    page_class_obj = utils.get_class_from_dynamicimport_module(
                        page_class_obj)
                page = page_class_obj(self.wizard, **args)
                page_instances.append(page)
            except Exception as e:
                utils.get_logger().exception('')
        return page_instances

    @property
    def ProjectTemplates(self):
        return self.project_templates

    def create_tree_view(self, wizard, page):
        self.wizard = wizard
        layout = page.layout()
        self.treeview = QTreeWidget()
        self.treeview.setSizePolicy(QSizePolicy.Expanding,
                                    QSizePolicy.Expanding)
        layout.addWidget(self.treeview)
        self.rootitem = self.treeview.invisibleRootItem()
        # 不显示表头
        self.treeview.setHeaderHidden(True)

# 鼠标双击Tree控件事件
        self.treeview.itemDoubleClicked.connect(self.on_double_click)
        # init tree events
        self.treeview.itemSelectionChanged.connect(self._on_select)
        return self.treeview

    def on_double_click(self, node):
        childcount = node.childCount()
        if childcount == 0:
            self.wizard.GotoNextPage()

    def _on_select(self):
        def update_ui(enable=False):
            if enable:
                self.wizard.next_button.setEnabled(True)
            else:
                self.wizard.next_button.setEnabled(False)
            self.wizard.prev_button.setEnabled(False)
            self.wizard.SetFinish(False)
        nodes = self.treeview.selectedItems()
        if len(nodes) == 0:
            update_ui(False)
            return
        node = nodes[0]
        childcount = node.childCount()
        if childcount > 0:
            update_ui(False)
        else:
            template = node.data(0, Qt.UserRole)
            self.current_template = template
            pages = self.template_pages[template.path]
            if not pages:
                update_ui(False)
                return
            # 单独设置起始页的下一个页面为第一个页面
            pages[0].SetPrev(self.wizard._project_template_page)
            self.wizard._project_template_page.SetNext(pages[0])
            update_ui(True)
