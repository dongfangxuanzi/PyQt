# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

#
# The file was taken from eric 4.4.3 and adopted for codimension.
# Original copyright:
# Copyright (c) 2007 - 2010 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""Common functionality of various browser models"""

import sys
import os
import logging
from ...lib.pyqt import Qt, QAbstractItemModel, QModelIndex, QApplication, QCursor
from .treeitems import TreeViewItem


class BrowserModelBase(QAbstractItemModel):

    """Class implementing the file system browser model"""

    def __init__(self, headerData, parent=None):
        QAbstractItemModel.__init__(self, parent)
        self.mainwindow = parent

        self.rootitem = TreeViewItem(None, headerData)
        self.projectTopLevelDirs = []
        self.showTooltips = True

    def setTooltips(self, switchOn):
        """Sets the tooltip mode: to show or not to show them"""
        self.showTooltips = switchOn

    def columnCount(self, parent=QModelIndex()):
        """Provides the number of columns"""
        if parent.isValid():
            return parent.internalPointer().columnCount()
        return self.rootitem.columnCount()

    def updateRootData(self, column, value):
        """Updates the root entry, i.e. header"""
        self.rootitem.setData(column, value)
        self.headerDataChanged.emit(Qt.Horizontal, column, column)

    def setData(self, index, value, role):
        if index.isValid() and role == Qt.EditRole:
            item = index.internalPointer()
            return self.mainwindow.FinishLabel(item, value)
        return False

    def data(self, index, role):
        """Provides data of an item"""
        if not index.isValid():
            return None

        column = index.column()
        if role == Qt.DisplayRole:
            item = index.internalPointer()
            if column < item.columnCount():
                return item.data(column)
            if column == item.columnCount() and \
               column < self.columnCount(self.parent(index)):
                # This is for the case when an item under a multi-column
                # parent doesn't have a value for all the columns
                return ""
        elif role == Qt.DecorationRole:
            if column == 0:
                return index.internalPointer().getIcon()
        elif role == Qt.ToolTipRole:
            item = index.internalPointer()
            if column == 1 and item.path is not None:
                return item.path
            if self.showTooltips and column == 0 and item.toolTip != "":
                return item.toolTip

        elif role == Qt.EditRole:
            item = index.internalPointer()
            # 元素打开编辑框时，显示的内容，如果没有这行，编辑框出现时默认为空白
            return item.data(column)

        return None

    def flags(self, index):
        """Provides the item flags"""
        if not index.isValid():
            return Qt.ItemIsEnabled
        return Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        """Provides the header data"""
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            if section >= self.rootitem.columnCount():
                return ""
            return self.rootitem.data(section)
        return None

    def index(self, row, column, parent=QModelIndex()):
        """Creates an index"""
        # The model/view framework considers negative values out-of-bounds,
        # however in python they work when indexing into lists. So make sure
        # we return an invalid index for out-of-bounds row/col
        if row < 0 or column < 0 or \
           row >= self.rowCount(parent) or \
           column >= self.columnCount(parent):
            return QModelIndex()

        if parent.isValid():
            parentItem = parent.internalPointer()
        else:
            parentItem = self.rootitem

        try:
            if not parentItem.populated:
                self.populateItem(parentItem)
            childItem = parentItem.child(row)
        except IndexError:
            return QModelIndex()

        if childItem:
            return self.createIndex(row, column, childItem)
        return QModelIndex()

    def buildIndex(self, rowPath):
        """Builds index for the path (path is like [1, 2, 1, 16])"""
        result = QModelIndex()
        for row in rowPath:
            result = self.index(row, 0, result)
        return result

    def parent(self, index):
        """Provides the index of the parent object"""
        if not index.isValid():
            return QModelIndex()

        childItem = index.internalPointer()
        parentItem = childItem.parent()

        if parentItem == self.rootitem:
            return QModelIndex()
        return self.createIndex(parentItem.row(), 0, parentItem)

    def totalRowCount(self):
        """Provides the total number of rows"""
        return self.rootitem.childCount()

    def rowCount(self, parent=QModelIndex()):
        """Provides the number of rows"""
        # Only the first column should have children
        if parent.column() > 0:
            return 0
        if not parent.isValid():
            return self.rootitem.childCount()
        parentitem = parent.internalPointer()
        return parentitem.childCount()

    def hasChildren(self, parent=QModelIndex()):
        """Returns True if the parent has children"""
        # Only the first column should have children
        if parent.column() > 0:
            return False
        if not parent.isValid():
            return self.rootitem.childCount() > 0

        if parent.internalPointer().lazyPopulation:
            return True
        return parent.internalPointer().childCount() > 0

    def clear(self):
        """Clears the model"""
        self.beginResetModel()
        self.rootitem.removeChildren()
        self.endResetModel()

    def item(self, index):
        """Provides a reference to an item"""
        if not index.isValid():
            return None
        return index.internalPointer()

    @staticmethod
    def _addItem(itm, parentItem):
        """Adds an item"""
        parentItem.appendChild(itm)

    def addItem(self, itm, parent=QModelIndex()):
        """Adds an item"""
        if not parent.isValid():
            parentItem = self.rootitem
        else:
            parentItem = parent.internalPointer()

        cnt = parentItem.childCount()
        self.beginInsertRows(parent, cnt, cnt)
        self._addItem(itm, parentItem)
        self.endInsertRows()

    def populateItem(self, parentItem, repopulate=False):
        """Populates an item's subtree"""
        if parentItem.itemType == DirectoryItemType:
            self.populateDirectoryItem(parentItem, repopulate)
        elif parentItem.itemType == SysPathItemType:
            self.populateSysPathItem(parentItem, repopulate)
        elif parentItem.itemType == FileItemType:
            self.populateFileItem(parentItem, repopulate)
        elif parentItem.itemType == GlobalsItemType:
            self.populateGlobalsItem(parentItem, repopulate)
        elif parentItem.itemType == ImportsItemType:
            self.populateImportsItem(parentItem, repopulate)
        elif parentItem.itemType == FunctionsItemType:
            self.populateFunctionsItem(parentItem, repopulate)
        elif parentItem.itemType == ClassesItemType:
            self.populateClassesItem(parentItem, repopulate)
        elif parentItem.itemType == ClassItemType:
            self.populateClassItem(parentItem, repopulate)
        elif parentItem.itemType == StaticAttributesItemType:
            self.populateStaticAttributesItem(parentItem, repopulate)
        elif parentItem.itemType == InstanceAttributesItemType:
            self.populateInstanceAttributesItem(parentItem, repopulate)
        elif parentItem.itemType == FunctionItemType:
            self.populateFunctionItem(parentItem, repopulate)
        elif parentItem.itemType == ImportItemType:
            self.populateImportItem(parentItem, repopulate)
        parentItem.populated = True

    def populateDirectoryItem(self, parentItem, repopulate=False):
        """Populates a directory item's subtree"""
        path = parentItem.getPath()
        if not os.path.exists(path):
            return

        QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        try:
            items = os.listdir(path)
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            logging.error("Cannot populate directory. " + str(exc))
            return

        excludes = ['.svn', '.cvs', '.hg', '.git']
        items = [itm for itm in items if itm not in excludes]
        if parentItem.needVCSStatus:
            # That's the project browser. Filter out what not needed.
            excludeFunctor = GlobalData().project.shouldExclude
            items = [itm for itm in items if not excludeFunctor(itm)]

        pathsToRequest = []
        if items:
            infoSrc = self.globalData.briefModinfoCache

            if repopulate:
                self.beginInsertRows(self.createIndex(parentItem.row(),
                                                      0, parentItem),
                                     0, len(items) - 1)
            path = os.path.realpath(path) + os.path.sep
            for item in items:
                fullpath = path + item
                if os.path.isdir(fullpath):
                    node = TreeViewDirectoryItem(parentItem, fullpath, False)
                    if parentItem.needVCSStatus:
                        pathsToRequest.append(fullpath + os.path.sep)
                else:
                    node = TreeViewFileItem(parentItem, fullpath)
                    if parentItem.needVCSStatus:
                        pathsToRequest.append(fullpath)
                    if isPythonMime(node.fileType):
                        modInfo = infoSrc.get(fullpath)
                        node.toolTip = ""
                        if modInfo.docstring is not None:
                            node.toolTip = modInfo.docstring.text

                        if modInfo.isOK == False:
                            # Substitute icon and change the tooltip
                            node.icon = getIcon('filepythonbroken.png')
                            if node.toolTip != "":
                                node.toolTip += "\n\n"
                            node.toolTip += "Parsing errors:\n" + \
                                            "\n".join(modInfo.lexerErrors +
                                                      modInfo.errors)
                            node.parsingErrors = True

                        if modInfo.encoding is None and \
                           not modInfo.imports and \
                           not modInfo.globals and \
                           not modInfo.functions and \
                           not modInfo.classes:
                            node.populated = True
                            node.lazyPopulation = False

                node.needVCSStatus = parentItem.needVCSStatus
                self._addItem(node, parentItem)

            if repopulate:
                self.endInsertRows()

        parentItem.populated = True

        # Request statuses of the populated items. The request must be sent
        # after the items are added, otherwise the status received by the model
        # before the items are populated thus not updated properly.
        for path in pathsToRequest:
            self.mainwindow.vcsManager.requestStatus(path)
        QApplication.restoreOverrideCursor()

    def populateSysPathItem(self, parentitem, repopulate=False):
        """Populates the sys.path item's subtree"""
        if sys.path:
            if repopulate:
                self.beginInsertRows(self.createIndex(parentitem.row(),
                                                      0, parentitem),
                                     0, len(sys.path) - 1)
            for path in sys.path:
                if path == '':
                    path = os.getcwd()

                if os.path.isdir(path):
                    node = TreeViewDirectoryItem(parentitem, path)
                    self._addItem(node, parentitem)
            if repopulate:
                self.endInsertRows()

        parentitem.populated = True

    def populateFileItem(self, parentItem, repopulate=False):
        """Populate a file item's subtree"""
        path = parentItem.getPath()
        if not isPythonFile(path):
            return

        parentItem.populated = True
        modInfo = self.globalData.briefModinfoCache.get(path)

        # Count the number of rows to insert
        count = 0
        if modInfo.encoding is not None:
            count += 1
        if modInfo.imports:
            count += 1
        if modInfo.globals:
            count += 1
        if modInfo.functions:
            count += 1
        if modInfo.classes:
            count += 1

        if count == 0:
            return

        # Insert rows
        if repopulate:
            self.beginInsertRows(self.createIndex(parentItem.row(),
                                                  0, parentItem),
                                 0, count - 1)
        if modInfo.encoding is not None:
            node = TreeViewCodingItem(parentItem, modInfo.encoding)
            self._addItem(node, parentItem)

        if modInfo.imports:
            node = TreeViewImportsItem(parentItem, modInfo)
            self._addItem(node, parentItem)

        if modInfo.globals:
            node = TreeViewGlobalsItem(parentItem, modInfo)
            self._addItem(node, parentItem)

        if modInfo.functions:
            node = TreeViewFunctionsItem(parentItem, modInfo)
            self._addItem(node, parentItem)

        if modInfo.classes:
            node = TreeViewClassesItem(parentItem, modInfo)
            self._addItem(node, parentItem)

        if repopulate:
            self.endInsertRows()

    def __populateList(self, parentItem, items, itemClass, repopulate=False):
        """Helper for populating lists"""
        parentItem.populated = True

        if repopulate:
            self.beginInsertRows(
                self.createIndex(parentItem.row(), 0, parentItem),
                0, len(items) - 1)
        for item in items:
            treeitem = itemClass(parentItem, item)
            if parentItem.columnCount() > 1:
                # Find out a parent with path set
                path = self.findParentPath(parentItem)
                treeitem.appendData([os.path.basename(path), item.line])
                treeitem.setPath(path)
            self._addItem(treeitem, parentItem)

        if repopulate:
            self.endInsertRows()

    @staticmethod
    def findParentPath(item):
        """Provides the nearest parent path"""
        while item.path is None:
            item = item.parentItem
        return item.path

    def populateGlobalsItem(self, parentItem, repopulate=False):
        """Populates the globals item"""
        self.__populateList(parentItem, parentItem.sourceObj.globals,
                            TreeViewGlobalItem, repopulate)

    def populateImportsItem(self, parentItem, repopulate=False):
        """Populates the imports item"""
        self.__populateList(parentItem, parentItem.sourceObj.imports,
                            TreeViewImportItem, repopulate)

    def populateFunctionsItem(self, parentItem, repopulate=False):
        """Populates functions item"""
        self.__populateList(parentItem, parentItem.sourceObj.functions,
                            TreeViewFunctionItem, repopulate)

    def populateClassesItem(self, parentItem, repopulate=False):
        """Populate classes item"""
        self.__populateList(parentItem, parentItem.sourceObj.classes,
                            TreeViewClassItem, repopulate)

    def populateClassItem(self, parentItem, repopulate):
        """Populates a class item"""
        parentItem.populated = True

        # Count the number of items
        count = len(parentItem.sourceObj.decorators) + \
            len(parentItem.sourceObj.functions)

        if parentItem.sourceObj.classes:
            count += 1
        if parentItem.sourceObj.classAttributes:
            count += 1
        if parentItem.sourceObj.instanceAttributes:
            count += 1

        if count == 0:
            return

        # Insert rows
        if repopulate:
            self.beginInsertRows(
                self.createIndex(parentItem.row(), 0, parentItem),
                0, count - 1)
        for item in parentItem.sourceObj.decorators:
            node = TreeViewDecoratorItem(parentItem, item)
            if parentItem.columnCount() > 1:
                node.appendData([parentItem.data(1), item.line])
                node.setPath(self.findParentPath(parentItem))
            self._addItem(node, parentItem)

        for item in parentItem.sourceObj.functions:
            node = TreeViewFunctionItem(parentItem, item)
            if parentItem.columnCount() > 1:
                node.appendData([parentItem.data(1), item.line])
                node.setPath(self.findParentPath(parentItem))
            self._addItem(node, parentItem)

        if parentItem.sourceObj.classes:
            node = TreeViewClassesItem(parentItem, parentItem.sourceObj)
            if parentItem.columnCount() > 1:
                node.appendData(["", ""])
            self._addItem(node, parentItem)

        if parentItem.sourceObj.classAttributes:
            node = TreeViewStaticAttributesItem(parentItem)
            if parentItem.columnCount() > 1:
                node.appendData(["", ""])
            self._addItem(node, parentItem)

        if parentItem.sourceObj.instanceAttributes:
            node = TreeViewInstanceAttributesItem(parentItem)
            if parentItem.columnCount() > 1:
                node.appendData(["", ""])
            self._addItem(node, parentItem)

        if repopulate:
            self.endInsertRows()

    def populateFunctionItem(self, parentItem, repopulate):
        """Populates a function item"""
        parentItem.populated = True

        # Count the number of items
        count = len(parentItem.sourceObj.decorators)

        if parentItem.sourceObj.functions:
            count += 1
        if parentItem.sourceObj.classes:
            count += 1

        if count == 0:
            return

        # Insert rows
        if repopulate:
            self.beginInsertRows(
                self.createIndex(parentItem.row(), 0, parentItem),
                0, count - 1)

        for item in parentItem.sourceObj.decorators:
            node = TreeViewDecoratorItem(parentItem, item)
            if parentItem.columnCount() > 1:
                node.appendData([parentItem.data(1), item.line])
                node.setPath(self.findParentPath(parentItem))
            self._addItem(node, parentItem)

        if parentItem.sourceObj.functions:
            node = TreeViewFunctionsItem(parentItem, parentItem.sourceObj)
            if parentItem.columnCount() > 1:
                node.appendData(["", ""])
            self._addItem(node, parentItem)

        if parentItem.sourceObj.classes:
            node = TreeViewClassesItem(parentItem, parentItem.sourceObj)
            if parentItem.columnCount() > 1:
                node.appendData(["", ""])
            self._addItem(node, parentItem)

        if repopulate:
            self.endInsertRows()

    def populateStaticAttributesItem(self, parentItem, repopulate):
        """Populates a static attributes item"""
        self.__populateList(parentItem,
                            parentItem.parentItem.sourceObj.classAttributes,
                            TreeViewAttributeItem, repopulate)

    def populateInstanceAttributesItem(self, parentItem, repopulate):
        """Populates an instance attributes item"""
        self.__populateList(parentItem,
                            parentItem.parentItem.sourceObj.instanceAttributes,
                            TreeViewAttributeItem, repopulate)

    def populateImportItem(self, parent_item, repopulate):
        """Populate an import item"""
        self.__populateList(parent_item, parent_item.sourceObj.what,
                            TreeViewWhatItem, repopulate)

    def signalItemUpdated(self, treeitem):
        """Emits a signal that an item is updated"""
        index = self.buildIndex(treeitem.getRowPath())
        self.dataChanged.emit(index, index)

    def removeTreeItem(self, treeitem):
        """Removes the given item"""
        index = self.buildIndex(treeitem.getRowPath())
        self.beginRemoveRows(index.parent(), index.row(), index.row())
        treeitem.parentItem.removeChild(treeitem)
        self.endRemoveRows()

    def addTreeItem(self, treeitem, newitem):
        """Adds the given item"""
        parentindex = self.buildIndex(treeitem.getRowPath())
        self.addItem(newitem, parentindex)

    def updateSingleClassItem(self, treeitem, classobj):
        """Updates single class item"""
        if not treeitem.populated:
            return

        # There might be decorators, classes, methods, static attributes and
        # instance attributes
        existingDecors = []
        existingMethods = []
        hadStaticAttributes = False
        hadInstanceAttributes = False
        hadClasses = False
        itemsToRemove = []
        for classChildItem in treeitem.childItems:
            if classChildItem.itemType == DecoratorItemType:
                name = classChildItem.sourceObj.name
                found = False
                for decor in classobj.decorators:
                    if decor.name == name:
                        found = True
                        existingDecors.append(name)
                        if cmpDecoratorDisplayName(classChildItem.sourceObj,
                                                   decor):
                            classChildItem.updateData(decor)
                            classChildItem.setData(2, decor.line)
                        else:
                            # Appearence changed
                            classChildItem.updateData(decor)
                            classChildItem.setData(2, decor.line)
                            self.signalItemUpdated(classChildItem)
                        break
                if not found:
                    itemsToRemove.append(classChildItem)
                continue
            if classChildItem.itemType == ClassesItemType:
                hadClasses = True
                if not classobj.classes:
                    itemsToRemove.append(classChildItem)
                else:
                    classChildItem.updateData(classobj)
                    self.updateClassesItem(classChildItem,
                                           classobj.classes)
                continue
            if classChildItem.itemType == FunctionItemType:
                name = classChildItem.sourceObj.name
                found = False
                for method in classobj.functions:
                    if method.name == name:
                        found = True
                        existingMethods.append(name)
                        if cmpFunctionDisplayName(classChildItem.sourceObj,
                                                  method):
                            classChildItem.updateData(method)
                            classChildItem.setData(2, method.line)
                        else:
                            # Appearence changed
                            classChildItem.updateData(method)
                            classChildItem.setData(2, method.line)
                            self.signalItemUpdated(classChildItem)
                        self.updateSingleFuncItem(classChildItem,
                                                  method)
                        break
                if not found:
                    itemsToRemove.append(classChildItem)
                continue
            if classChildItem.itemType == StaticAttributesItemType:
                hadStaticAttributes = True
                if not classobj.classAttributes:
                    itemsToRemove.append(classChildItem)
                else:
                    self.updateAttrItem(classChildItem,
                                        classobj.classAttributes)
                continue
            if classChildItem.itemType == InstanceAttributesItemType:
                hadInstanceAttributes = True
                if not classobj.instanceAttributes:
                    itemsToRemove.append(classChildItem)
                else:
                    self.updateAttrItem(classChildItem,
                                        classobj.instanceAttributes)
                continue

        for item in itemsToRemove:
            self.removeTreeItem(item)

        # Add those which have been introduced
        for decor in classobj.decorators:
            if decor.name not in existingDecors:
                newitem = TreeViewDecoratorItem(treeitem, decor)
                if treeitem.columnCount() > 1:
                    newitem.appendData([treeitem.data(1), decor.line])
                    newitem.setPath(self.findParentPath(treeitem))
                self.addTreeItem(treeitem, newitem)
        for method in classobj.functions:
            if method.name not in existingMethods:
                newitem = TreeViewFunctionItem(treeitem, method)
                if treeitem.columnCount() > 1:
                    newitem.appendData([treeitem.data(1), method.line])
                    newitem.setPath(self.findParentPath(treeitem))
                self.addTreeItem(treeitem, newitem)

        if not hadClasses and classobj.classes:
            newitem = TreeViewClassesItem(treeitem, classobj)
            if treeitem.columnCount() > 1:
                newitem.appendData(["", ""])
            self.addTreeItem(treeitem, newitem)
        if not hadStaticAttributes and \
           classobj.classAttributes:
            newitem = TreeViewStaticAttributesItem(treeitem)
            if treeitem.columnCount() > 1:
                newitem.appendData(["", ""])
            self.addTreeItem(treeitem, newitem)
        if not hadInstanceAttributes and \
           classobj.instanceAttributes:
            newitem = TreeViewInstanceAttributesItem(treeitem)
            if treeitem.columnCount() > 1:
                newitem.appendData(["", ""])
            self.addTreeItem(treeitem, newitem)

    def updateSingleFuncItem(self, treeitem, funcobj):
        """Updates single function item"""
        if not treeitem.populated:
            return
        # It may have decor, classes and other functions
        existingDecors = []
        had_functions = False
        had_classes = False
        items_toremove = []
        for func_child_item in treeitem.childItems:
            if func_child_item.itemType == DecoratorItemType:
                name = func_child_item.sourceObj.name
                found = False
                for decor in funcobj.decorators:
                    if decor.name == name:
                        found = True
                        existingDecors.append(name)
                        if cmpDecoratorDisplayName(func_child_item.sourceObj,
                                                   decor):
                            func_child_item.updateData(decor)
                            func_child_item.setData(2, decor.line)
                        else:
                            # Appearence changed
                            func_child_item.updateData(decor)
                            func_child_item.setData(2, decor.line)
                            self.signalItemUpdated(func_child_item)
                        break
                if not found:
                    items_toremove.append(func_child_item)
                continue
            if func_child_item.itemType == FunctionsItemType:
                had_functions = True
                if not funcobj.functions:
                    items_toremove.append(func_child_item)
                else:
                    func_child_item.updateData(funcobj)
                    self.updateFunctionsItem(func_child_item,
                                             funcobj.functions)
                continue
            if func_child_item.itemType == ClassesItemType:
                had_classes = True
                if not funcobj.classes:
                    items_toremove.append(func_child_item)
                else:
                    func_child_item.updateData(funcobj)
                    self.updateClassesItem(func_child_item,
                                           funcobj.classes)
                continue

        for item in items_toremove:
            self.removeTreeItem(item)

        # Add those which have been introduced
        for decor in funcobj.decorators:
            if decor.name not in existingDecors:
                newitem = TreeViewDecoratorItem(treeitem, decor)
                if treeitem.columnCount() > 1:
                    newitem.appendData([treeitem.data(1), decor.line])
                    newitem.setPath(self.findParentPath(treeitem))
                self.addTreeItem(treeitem, newitem)

        if not had_functions and funcobj.functions:
            newitem = TreeViewFunctionsItem(treeitem, funcobj)
            if treeitem.columnCount() > 1:
                newitem.appendData(["", ""])
            self.addTreeItem(treeitem, newitem)
        if not had_classes and funcobj.classes:
            newitem = TreeViewClassesItem(treeitem, funcobj)
            if treeitem.columnCount() > 1:
                newitem.appendData(["", ""])
            self.addTreeItem(treeitem, newitem)

    def updateClassesItem(self, treeitem, classesobj):
        """Updates classes item"""
        if not treeitem.populated:
            return

        existingClasses = []
        itemsToRemove = []
        for classitem in treeitem.childItems:
            name = classitem.sourceObj.name
            found = False
            for cls in classesobj:
                if cls.name == name:
                    found = True
                    existingClasses.append(name)
                    if cmpClassDisplayName(classitem.sourceObj, cls):
                        classitem.updateData(cls)
                        classitem.setData(2, cls.line)
                    else:
                        # Appearence changed
                        classitem.updateData(cls)
                        classitem.setData(2, cls.line)
                        self.signalItemUpdated(classitem)
                    self.updateSingleClassItem(classitem, cls)
                    break
            if not found:
                itemsToRemove.append(classitem)

        for item in itemsToRemove:
            self.removeTreeItem(item)

        # Add those which have been introduced
        for cls in classesobj:
            if cls.name not in existingClasses:
                newitem = TreeViewClassItem(treeitem, cls)
                if treeitem.columnCount() > 1:
                    newitem.appendData([treeitem.data(1), cls.line])
                    newitem.setPath(self.findParentPath(treeitem))
                self.addTreeItem(treeitem, newitem)

    def updateFunctionsItem(self, treeitem, functions_obj):
        """Updates functions item"""
        if not treeitem.populated:
            return

        existingFunctions = []
        itemsToRemove = []
        for functionitem in treeitem.childItems:
            name = functionitem.sourceObj.name
            found = False
            for func in functions_obj:
                if func.name == name:
                    found = True
                    existingFunctions.append(name)
                    if cmpFunctionDisplayName(functionitem.sourceObj,
                                              func):
                        functionitem.updateData(func)
                        functionitem.setData(2, func.line)
                    else:
                        # Appearence changed
                        functionitem.updateData(func)
                        functionitem.setData(2, func.line)
                        self.signalItemUpdated(functionitem)
                    self.updateSingleFuncItem(functionitem, func)
                    break
            if not found:
                itemsToRemove.append(functionitem)

        for item in itemsToRemove:
            self.removeTreeItem(item)

        # Add those which have been introduced
        for func in functions_obj:
            if func.name not in existingFunctions:
                newitem = TreeViewFunctionItem(treeitem, func)
                if treeitem.columnCount() > 1:
                    newitem.appendData([treeitem.data(1), func.line])
                    newitem.setPath(self.findParentPath(treeitem))
                self.addTreeItem(treeitem, newitem)

    def updateAttrItem(self, treeitem, attributes_obj):
        """Updates attributes item"""
        if not treeitem.populated:
            return

        existing_attributes = []
        items_to_remove = []
        for attritem in treeitem.childItems:
            name = attritem.data(0)
            found = False
            for attr in attributes_obj:
                if attr.name == name:
                    found = True
                    existing_attributes.append(name)
                    attritem.updateData(attr)
                    attritem.setData(2, attr.line)
                    # There is no need to send a signal to update the item
                    # because the only name is displayed and it's not
                    # changed.
                    # self.signalItemUpdated( attrItem )
                    break
            if not found:
                items_to_remove.append(attritem)

        for item in items_to_remove:
            self.removeTreeItem(item)

        for attr in attributes_obj:
            if attr.name not in existing_attributes:
                newitem = TreeViewAttributeItem(treeitem, attr)
                if treeitem.columnCount() > 1:
                    newitem.appendData([treeitem.data(1), attr.line])
                    newitem.setPath(self.findParentPath(treeitem))
                self.addTreeItem(treeitem, newitem)


def cmpDocstringDisplayName(lhs, rhs):
    """Returns True if the display names are the same"""
    if lhs is None and rhs is None:
        return True
    if lhs is None or rhs is None:
        return False
    return lhs.text == rhs.text


def cmpFunctionDisplayName(lhs, rhs):
    """Returns True if the functions display names are the same"""
    if lhs.name != rhs.name:
        return False
    if lhs.arguments != rhs.arguments:
        return False
    return cmpDocstringDisplayName(lhs.docstring, rhs.docstring)


def cmpDecoratorDisplayName(lhs, rhs):
    """Returns True if the decorators display names are the same"""
    if lhs.name != rhs.name:
        return False
    if lhs.arguments != rhs.arguments:
        return False
    return True


def cmpClassDisplayName(lhs, rhs):
    """Returns True if the classes display names are the same"""
    if lhs.name != rhs.name:
        return False
    if lhs.base != rhs.base:
        return False
    return cmpDocstringDisplayName(lhs.docstring, rhs.docstring)
