import os
from ...lib.pyqt import (QModelIndex, QAbstractItemView,
                         QApplication, QTreeView, pyqtSignal)
from ... import qtimage, get_app, globalkeys
from .projectbrowsermodel import ProjectBrowserModel
from . import treeitems
from .. import ext
from .sortmodel import FilesBrowserSortFilterProxyModel
from ..resolver.model import ProjectFile
from ..document import ProjectDocument
from .itemdelegates import ItemBoldFontDelegate
from ...util import utils


class ProjectTreeCtrl(QTreeView):

    # 用来设置粗体节点,粗体节点用来表示项目启动文件
    BOLD_TAG = 'BoldItem'
    NORMAL_TAG = 'NormalItem'
    sigFirstSelectedItem = pyqtSignal(QModelIndex)
    sigAddFileItem = pyqtSignal(ProjectFile, ProjectDocument)
    # 导入文件完成后发送一个信号
    sigImportFinished = pyqtSignal()
    # ----------------------------------------------------------------------------
    # Overridden Methods
    # ----------------------------------------------------------------------------

    def __init__(self, master, project_file_ext=ext.COMMON_PROJECT_EXTENSION):
        super().__init__(master)
        self.browser = master
        self._project_file_ext = project_file_ext
        self._icon_lookup = {}

        self.__model = ProjectBrowserModel(self)
        self.__sortmodel = FilesBrowserSortFilterProxyModel(False)
        self.__sortmodel.setSourceModel(self.__model)
        self.setModel(self.__sortmodel)

        self.setRootIsDecorated(True)
        # 设置行颜色间隔交替
        self.setAlternatingRowColors(True)
        self.setUniformRowHeights(True)
        self.setItemDelegate(ItemBoldFontDelegate(self))
        # 设置节点可按顺序排列
        self.setSortingEnabled(True)
        # 设置节点在2次点击时可编辑状态
        self.setEditTriggers(QAbstractItemView.SelectedClicked)

        self._blank_iconimage = qtimage.blank_icon()
        self._folderClosedImage = qtimage.folder_closed_icon()
        self.sigAddFileItem.connect(self.add_progress_file)
        self.sigImportFinished.connect(self.finish_import_files)

    def invisibleRootItem(self):
        return self.__model.rootitem

    def SelectItem(self, node):
        srcmodel = self.model().sourceModel()
        index = srcmodel.buildIndex(node.getRowPath())
        return self.setCurrentIndex(self.model().mapFromSource(index))

    def BuildLookupIcon(self):
        if 0 == len(self._icon_lookup):
            self.RebuildLookupIcon()

    def RebuildLookupIcon(self):
        templates = get_app().GetDocumentManager().GetTemplates()
        for template in templates:
            icon = template.GetIcon()
            self._icon_lookup[template] = icon

    def GetChildrenCount(self, item):
        return len(item.children())

    def DeleteChildren(self, node):
        for child_id in self.get_children(node):
            self.delete(child_id)

    def GetRootItem(self):
        return self.GetFirstChild(self.__model.rootitem)

    def GetFirstChild(self, item):
        childs = item.children()
        if 0 == len(childs):
            return None
        return childs[0]

    def FinishLabel(self, item, value):
        return self.browser.GetView().OnEndLabelEdit(item, value)

    def EditLabel(self):
        select_model = self.selectionModel()
        current_index = select_model.currentIndex()
        self.edit(current_index)

    def AppendFolder(self, parent, foldername):
        folder_item = treeitems.TreeViewFolderItem(parent, foldername)
        folder_item.icon = self._folderClosedImage
        parent_index = self.__model.buildIndex(parent.getRowPath())
        self.__model.addItem(folder_item, parent_index)
        return folder_item

    def GetIconFromName(self, filename):
        template = wx.GetApp().GetDocumentManager().FindTemplateForPath(filename)
        return self.GetTemplateIcon(template)

    def GetProjectIcon(self):
        template = get_app().GetDocumentManager(
        ).FindTemplateForTestPath(self._project_file_ext)
        project_file_image = self.GetTemplateIcon(template)
        return project_file_image

    def source_model(self):
        return self.model().sourceModel()

    def AddProjectRoot(self, project_name, icon=None):
        item = treeitems.TreeViewItem(self.__model.rootitem, project_name)
        if icon is None:
            icon = self.GetProjectIcon()
        item.icon = icon
        item.itemType = treeitems.ProjectRootType
        parent_index = self.__model.buildIndex(
            self.__model.rootitem.getRowPath())
        self.__model.addItem(item, parent_index)
        return item

    def GetTemplateIcon(self, template):
        self.BuildLookupIcon()
        if template in self._icon_lookup:
            return self._icon_lookup[template]
        return self._blank_iconimage

    def AppendItem(self, parent, filename, file):
        # 查找项目文件是否有另外的打开方式模板
        template = get_app().MainFrame.projectview.GetView().GetOpenDocumentTemplate(file)
        # 如果没有则使用项目文件扩展名对应的默认模板
        if template is None:
            template = get_app().GetDocumentManager().FindTemplateForPath(filename)
        file_image = self.GetTemplateIcon(template)
        fileitem = treeitems.TreeViewFileItem(parent, filename)
        fileitem.setPath(file.filePath)
        fileitem.icon = file_image
        parent_index = self.__model.buildIndex(parent.getRowPath())
        self.__model.addItem(fileitem, parent_index)
        return fileitem

    def AddFolder(self, folderpath):
        folder_items = []
        if folderpath is not None:
            folder_tree = folderpath.split('/')
            item = self.GetRootItem()
            for foldername in folder_tree:
                found = False
                for child in item.children():
                    if child.itemType == treeitems.FileItemType:
                        pass
                    else:  # folder
                        if child.data() == foldername:
                            item = child
                            found = True
                            break

                if not found:
                    item = self.AppendFolder(item, foldername)
                    folder_items.append(item)

        return folder_items

    def FindItem(self, filepath, parentitem=None):
        if not parentitem:
            parentitem = self.GetRootItem()
        for child in parentitem.children():
            if child.itemType == treeitems.FileItemType:
                if child.path == filepath:
                    return child
            else:  # folder
                result = self.FindItem(filepath, child)  # do recursive call
                if result:
                    return result
        return None

    def FindFolder(self, folderpath):
        if folderpath is not None:
            foldertree = folderpath.split('/')
            item = self.GetRootItem()
            for foldername in foldertree:
                found = False
                for child in item.children():
                    if child.itemType == treeitems.FileItemType:
                        pass
                    else:  # folder
                        if child.data() == foldername:
                            item = child
                            found = True
                            break
            if found:
                return item
        return None

    def FindClosestFolder(self, x, y):
        item, flags = self.HitTest((x, y))
        if item:
            file = self.GetPyData(item)
            if file:
                item = self.GetItemParent(item)
                return item
            return item
        return None

    def expandItem(self, item, expanded=True):
        """Expands the given item"""
        srcmodel = self.model().sourceModel()
        index = srcmodel.buildIndex(item.getRowPath())
        self.setExpanded(self.model().mapFromSource(index), expanded)

    def isItemExpanded(self, item):
        srcmodel = self.model().sourceModel()
        index = srcmodel.buildIndex(item.getRowPath())
        return self.isExpanded(self.model().mapFromSource(index))

    def GetSingleSelectItem(self):
        index = self.currentIndex()
        if not index.isValid():
            return None
        return self.model().item(index)

    def setCurrentItem(self, item):
        item_index = self.__model.buildIndex(item.getRowPath())
        self.setCurrentIndex(self.model().mapFromSource(item_index))
        self.setFocus()

    def copyToClipboard(self):
        """Copies the path to the file where the element is to the clipboard"""
        item = self.model().item(self.currentIndex())
        path = item.getPath()
        QApplication.clipboard().setText(path)

    def findInDirectory(self):
        """Find in directory popup menu handler"""
        index = self.currentIndex()
        searchdir = self.model().item(index).getPath()
        dlg = FindInFilesDialog(FindInFilesDialog.IN_DIRECTORY, "", searchdir)
        dlg.exec_()
        if dlg.searchResults:
            GlobalData().mainWindow.displayFindInFiles(
                FindInFilesSearchProvider().getName(),
                dlg.searchResults, dlg.getParameters())

    def add_progress_file(self, project_file, doc):
        folderpath = project_file.logicalFolder
        if folderpath:
            self.AddFolder(folderpath)
            folder = self.FindFolder(folderpath)
        else:
            folder = self.GetRootItem()
        if not self.FindItem(project_file.filePath, folder):
            item = self.append_file_item(folder, os.path.basename(
                project_file.filePath), project_file, doc)
        self.expand(self.source_model().buildIndex(folder.getRowPath()))

    def append_file_item(self, parent_item, filename, project_file, doc):
        return self.AppendItem(parent_item, filename, project_file)

    def selection(self):
        indexes = self.selectionModel().selectedIndexes()
        items = []
        for index in indexes:
            item = self.model().item(index)
            items.append(item)
        return items

    def delete_node(self, node):
        self.source_model().removeTreeItem(node)

    def collapse(self, node):
        '''
            折叠节点及其子节点
        '''
        for child in node.children():
            if self.GetChildrenCount(child) > 0:
                self.collapse(child)
        parent_index = self.source_model().buildIndex(node.getRowPath())
        self.setExpanded(self.model().mapFromSource(parent_index), False)

    def finish_import_files(self):
        # 导入文件完成后是否展开所有节点
        if utils.profile_get_int(globalkeys.EXPAND_ALL_PROJECT_FILES_KEY, True):
            self.expandAll()
