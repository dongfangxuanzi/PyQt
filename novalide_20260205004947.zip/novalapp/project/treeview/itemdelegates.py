# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2016  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""ItemDelegate which helps changing the standard row height"""


from ...lib.pyqt import (QStyledItemDelegate, QStyleOptionViewItem,
                         )


class ItemBoldFontDelegate(QStyledItemDelegate):

    """Hides the dotted line outline around tree view cells"""

    def __init__(self, tree):
        QStyledItemDelegate.__init__(self)
        self.tree = tree
        self.project_view = None

    def update_view(self):
        if self.project_view is None:
            self.project_view = self.tree.browser.GetView()

    def paint(self, painter, option, index):
        """Hides the dotted outline"""
        item_option = QStyleOptionViewItem(option)
        self.update_view()
        item = self.tree.model().item(index)
        if self.project_view._IsItemFile(item):
            pjfile = self.project_view._GetItemFile(item)
            # 项目启动文件
            if pjfile.isStartup:
                font = painter.font()
                # 将项目启动文件的字体加粗,以便高亮显示
                font.setBold(True)
                item_option.font = font
        QStyledItemDelegate.paint(self, painter, item_option, index)
