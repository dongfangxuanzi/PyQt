# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""Base and auxiliary classes for FS and project browsers"""

from ...lib.pyqt import QModelIndex, QSortFilterProxyModel
from .treeitems import FolderItemType


class FilesBrowserSortFilterProxyModel(QSortFilterProxyModel):
    """Files (filesystem and project) browser sort filter proxy model.

    It allows filtering basing on top level items.
    """

    def __init__(self, is_project_filter, parent=None):
        QSortFilterProxyModel.__init__(self, parent)
        self.__sortColumn = None    # Avoid pylint complains
        self.__sortorder = None     # Avoid pylint complains
        self.__shouldFilter = is_project_filter

    def sort(self, column, order):
        """Sorts the items"""
        self.__sortColumn = column
        self.__sortorder = order
        QSortFilterProxyModel.sort(self, column, order)

    def lessThan(self, left, right):
        """Sorts the displayed items"""
        lhs = left.model() and left.model().item(left) or None
        rhs = right.model() and right.model().item(right) or None
        if lhs and rhs:
            return self.OnCompareItems(lhs, rhs)
        return False

    def OnCompareItems(self, item1, item2):
        item1_is_folder = (item1.itemType == FolderItemType)
        item2_is_folder = (item2.itemType == FolderItemType)
        if item1_is_folder == item2_is_folder:  # if both are folders or both not
            return item1.data().lower() > item2.data().lower()
        if item1_is_folder and not item2_is_folder:  # folders sort above non-folders
            return False
        if not item1_is_folder and item2_is_folder:  # folders sort above non-folders
            return True

    def item(self, index):
        """Provides a reference to the item"""
        if not index.isValid():
            return None

        sourceindex = self.mapToSource(index)
        return self.sourceModel().item(sourceindex)

    def hasChildren(self, parent=QModelIndex()):
        """Checks the presence of the child items"""
        sourceindex = self.mapToSource(parent)
        return self.sourceModel().hasChildren(sourceindex)

    def filterAcceptsRow(self, sourcerow, sourceParent):
        """Filters rows"""
        if not self.__shouldFilter:
            return True     # Show everything

        # Filter using the loaded project filter
        if not sourceParent.isValid():
            return True

        item = sourceParent.internalPointer().child(sourcerow)
        return not GlobalData().project.shouldExclude(item.data(0))
