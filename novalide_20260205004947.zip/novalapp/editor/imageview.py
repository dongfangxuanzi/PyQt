# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        imageviewer.py
Purpose:     图片查看器,浏览所有支持图片类型

Author:      wukan

Created:     2019-01-21
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import os
from .. import get_app, _
from ..lib.document import Document
from .commonview import NocreateView
from ..widgets.event import EscapeEvent
from ..lib.pyqt import (
    QMessageBox,
    QLabel,
    QScrollArea,
    QPalette,
    QSizePolicy,
    Qt,
    QImage,
    QPixmap,
    QApplication
)
from ..util import utils
from .. import menuitems

FORMAT_STRINGS = {
    QImage.Format_Invalid: "invalid",
    QImage.Format_Mono: "1-bit per pixel",
    QImage.Format_MonoLSB: "1-bit per pixel",
    QImage.Format_Indexed8: "8-bit indexes",
    QImage.Format_RGB32: "32-bit RG",
    QImage.Format_ARGB32: "32-bit ARGB",
    QImage.Format_ARGB32_Premultiplied: "32-bit ARGB",
    QImage.Format_RGB16: "16-bit RGB",
    QImage.Format_ARGB8565_Premultiplied: "24-bit ARGB",
    QImage.Format_RGB666: "24-bit RGB",
    QImage.Format_ARGB6666_Premultiplied: "24-bit ARGB",
    QImage.Format_RGB555: "16-bit RGB",
    QImage.Format_ARGB8555_Premultiplied: "24-bit ARGB",
    QImage.Format_RGB888: "24-bit RGB",
    QImage.Format_RGB444: "16-bit RGB",
    QImage.Format_ARGB4444_Premultiplied: "16-bit ARGB"
}


class PixmapWidget(QScrollArea, EscapeEvent):
    """The pixmap widget"""

    def __init__(self, parent=None):
        super().__init__(parent)

        self.pixmaplabel = QLabel()
        self.pixmaplabel.setBackgroundRole(QPalette.Base)
        self.pixmaplabel.setSizePolicy(QSizePolicy.Ignored,
                                       QSizePolicy.Ignored)
        self.pixmaplabel.setScaledContents(True)

        self.zoom = 1.0
        self.info = ""
        self.formatinfo = ""
        # 查找文本字符串
        self.selectedText = ''
        self.filesize = 0

        self.setBackgroundRole(QPalette.Dark)
        self.setWidget(self.pixmaplabel)
        self.setAlignment(Qt.AlignCenter)

    def loadFromFile(self, filename):
        """Loads a pixmap from a file"""
        image = QImage(filename)
        if image.isNull():
            raise Exception("Unsupported pixmap format (" + filename + ")")

        self.pixmaplabel.setPixmap(QPixmap.fromImage(image))
        self.pixmaplabel.adjustSize()

        self.filesize = os.path.getsize(filename)
        if self.filesize < 1024:
            filesize_str = str(self.filesize) + "bytes"
        else:
            kilobytes = self.filesize / 1024
            if (self.filesize % 1024) >= 512:
                kilobytes += 1
            filesize_str = str(kilobytes) + "kb"
        self.info = str(image.width()) + "px/" + \
            str(image.height()) + "px/" + filesize_str
        try:
            self.formatinfo = FORMAT_STRINGS[image.format()]
        except:
            self.formatinfo = _("Unknown")

    def setPixmap(self, pixmap):
        """Shows the provided pixmap"""
        pix = QPixmap.fromImage(pixmap)
        self.pixmaplabel.setPixmap(pix)
        self.pixmaplabel.adjustSize()

        self.info = str(pix.width()) + "px/" + str(pix.height()) + "px"
        self.formatinfo = str(pix.depth()) + " bpp"

    def keyPressEvent(self, event):
        """Handles wx.EVT_KEY_UP"""
        # 处理esc键,按esc键退出全屏模式
        if not self.is_escape_pressed(event):
            super().keyPressEvent(event)

    def resetZoom(self):
        """Resets the zoom"""
        self.zoom = 1.0
        self.pixmaplabel.adjustSize()

    def doZoom(self, factor):
        """Performs zooming"""
        self.zoom *= factor
        self.pixmaplabel.resize(self.zoom * self.pixmaplabel.pixmap().size())

        self.__adjustScrollBar(self.horizontalScrollBar(), factor)
        self.__adjustScrollBar(self.verticalScrollBar(), factor)

    def wheelEvent(self, event):
        """Mouse wheel event"""
        if QApplication.keyboardModifiers() == Qt.ControlModifier:
            angle_delta = event.angleDelta()
            if not angle_delta.isNull():
                delta = angle_delta.y()
                self.zoom_pixmap(delta)
            event.accept()
        else:
            QScrollArea.wheelEvent(self, event)

    def zoom_pixmap(self, delta):
        if delta > 0:
            self.doZoom(1.25)
        else:
            self.doZoom(0.8)

    def __adjustScrollBar(self, scrollbar, factor):
        """Adjusts a scrollbar by a certain factor"""
        scrollbar.setValue(int(factor * scrollbar.value() +
                               ((factor - 1) * scrollbar.pageStep() / 2)))

    def setReadOnly(self, new_value):
        """Make it similar to a text editor"""

    def get_view(self):
        return self.parent().GetView()


class ImageDocument(Document):
    def OnOpenDocument(self, filename):
        '''
        解析图片
        '''
        try:
            self.GetFirstView().GetCtrl().loadFromFile(filename)
        except Exception as ex:
            utils.get_logger().exception(f'load image:{filename} error')
            QMessageBox.critical(
                get_app().MainFrame,
                _("Open Image File"),
                _("Error loading '%s'. %s") % (self.GetPrintableName(), ex)
            )
            return False
        self.SetDocumentModificationDate()
        self.SetFilename(filename, True)
        self.Modify(False)
        self.SetDocumentSaved(True)
        self.UpdateAllViews()
        return True


class ImageView(NocreateView):

    # ----------------------------------------------------------------------------
    # Overridden methods
    # ----------------------------------------------------------------------------

    def __init__(self):
        super().__init__()
        self._viewer = None

    def OnCreate(self, doc, flags):
        frame = get_app().CreateDocumentFrame(self, doc, flags)
        frame.attach_horizontal_layout()
        self._viewer = PixmapWidget(frame)
        self.connect_editor_widget()
        layout = frame.layout()
        layout.addWidget(self._viewer)
        self.Activate()
        return True

    def SetFocus(self):
        if self._viewer is not None:
            self._viewer.pixmaplabel.setFocus()

    def OnActivateView(self, activate, activeView, deactiveView):
        if activate and activeView:
            pass

    def UpdateUI(self, command_id):
        '''
        图片视图允许缩放
        '''
        if command_id in [
            menuitems.ID_ZOOM_IN,
            menuitems.ID_ZOOM_OUT
        ]:
            return True
        return super().UpdateUI(command_id)

    def ZoomView(self, delta=0):
        '''
            实现图片的放大缩小
        '''
        # 当前大小
        self._viewer.zoom_pixmap(delta)

    def GetCtrl(self):
        return self._viewer

    def set_encoding(self):
        '''
        状态栏编码列在图片文件时显示图片格式
        '''
        get_app().MainFrame.sbEncoding.setText(self.GetCtrl().formatinfo)
