import os
import json
import webbrowser
from bs4 import Tag
from ... import get_app, _
from ... import menuitems
from .welcome_html_code import *
from ...common.encodings import UTF8_FILE_ENCODING
from ... import globalkeys
from .color_theme import *
from ...util import ui_utils, utils, strutils, fileutils, appdirs
from ... import constants
from ...lib.docmanager import DOC_SILENT, DOC_OPEN_ONCE
from ...lib.pyqt import QThread, QWebEngineSettings, QWebChannel, QMessageBox, QObject, pyqtSlot
from ...plugin.gui import show_pluginmanager_dlg
from ...plugin.pluginupdate import pull_plugin_updateinfo, update_plugin_byid
from ...plugins.update import request_app_update_data, UpdateApp
from ...api.api import ApiServer
from ...api.errors import HAVE_APP_UPDATE
from ...bars.menubar import find_menu
from ...enums import AppSkin

APP_UPDATE_COMMAND = 'command:workbench.action.app.update'
PLUGIN_UPDATE_COMMAND = 'command:workbench.action.plugin.update'
FEEDS_OPEN_URL_COMMAND = 'command:workbench.action.feeds.openurl'


class Command(QObject):
    @pyqtSlot(str, result=str)
    def action(self, msg):
        if msg == 'command:workbench.action.project.openProject':
            get_app().MainFrame.projectview.OpenProject()
        elif msg == 'command:workbench.action.project.newProject':
            get_app().MainFrame.projectview.NewProject()
        elif msg == "command:workbench.action.help.register_or_login":
            GetApp().Registerorlogin()
        elif msg == "command:workbench.action.help.ManagePlugins":
            show_pluginmanager_dialog()
        elif msg.find(APP_UPDATE_COMMAND) != -1:
            app_version = msg.replace(APP_UPDATE_COMMAND + ":", "")
            UpdateApp(app_version)
        elif msg.find(PLUGIN_UPDATE_COMMAND) != -1:
            plugin_id = msg.replace(PLUGIN_UPDATE_COMMAND + ":", "")
            update_plugin_byid(plugin_id)
        elif msg.find(FEEDS_OPEN_URL_COMMAND) != -1:
            url, feed_id = msg.replace(
                FEEDS_OPEN_URL_COMMAND + ":", "").split('|')
            webbrowser.open(url)
            if feed_id == "...":
                return
            api_addr = '%s/api/feed/open' % (UserDataDb.HOST_SERVER_ADDR)
            urlutils.RequestData(api_addr, method="post",
                                 arg={'feed_id': feed_id})
        elif msg == "command:workbench.action.help.openCodeRepositoryURL":
            webbrowser.open("https://gitee.com/wekay/NovalIDE")
        elif msg == "command:workbench.action.help.openDocumentationUrl":
            webbrowser.open("https://wekay.gitee.io/novalide")
        elif msg == "command:workbench.action.help.keybindingsReference":
            webbrowser.open(
                "http://www.novalide.com/media/document/shortcuts.pdf")
        elif msg == "command:workbench.action.help.openIntroductoryVideosUrl":
            webbrowser.open(
                "https://wekay.gitee.io/novalide/zh/getstarted/introductory/")
        elif msg == "command:workbench.action.help.openTipsAndTricksUrl":
            webbrowser.open(
                "https://wekay.gitee.io/novalide/zh/getstarted/tips/")
        else:
            project_path = msg.split(
                ':')[-1].replace('/', os.sep).replace('|', ":")
            self.open_recent_project(project_path)

    @ui_utils.update_toolbar
    def open_recent_project(self, path):
        if not os.path.exists(path):
            get_app().GetDocumentManager().RemoveProjectFromHistory(path)
            QMessageBox.critical(
                get_app().MainFrame,
                get_app().GetAppName(),
                _("The project '%s' doesn't exist and couldn't be opened!") % path
            )
        else:
            get_app().GetDocumentManager().CreateDocument(path, DOC_SILENT)


def show_pluginmanager_dialog():
    show_pluginmanager_dlg(get_app().GetTopWindow())


def get_appupdate_data():
    utils.get_logger().info("check application update informattion")
    data = request_app_update_data()
    if data is None:
        utils.get_logger().error("fetch app update info error from server...")
        return None
    utils.get_logger().info("fetch app update info success from server...")
    return data


class AppUpdate(QThread):
    def __init__(self, parent):
        super().__init__(parent)

    def run(self):
        self.check_app_update()

    def check_app_update(self):
        data = get_appupdate_data()
        if not data:
            return
        # have update
        if data['code'] == HAVE_APP_UPDATE:
            # 线程里面使用发送信号的方式弹出更新对话框,否则会卡死
            self.parent().sigAppUpdateVersion.emit(data)


class FeedsLoader(QThread):
    def __init__(self, web_view, app_update_params):
        super().__init__(web_view.GetFrame())
        self.webview = web_view
        self.update_params = app_update_params
        self.number = {
            Startup.NEWS: 0,
            Startup.LEARN: 0
        }
        self.feeds = []

    def run(self):
        self.LoadNews()

    def has_new_app(self):
        return self.update_params['has_new']

    def init_feeds_num(self):
        if self.update_params['has_new']:
            self.number[Startup.NEWS] += 1

    def check_app_update(self):
        data = get_appupdate_data()
        if not data:
            return
        # have update
        # 从服务器获取程序升级信息,并显示在News栏中
        if data['code'] == HAVE_APP_UPDATE:
            new_version = data['new_version']
            update_msg = data['update_msg']
            msg = _(
                "this latest app version '%s' is available,click here to update it") % new_version
            self.update_params['has_new'] = True
            self.update_params['title'] = msg
            self.update_params['subcontent'] = update_msg
            self.update_params['app_version'] = new_version

    def check_plugin_update(self):
        plugin_datas = []
        pull_plugin_updateinfo(plugin_datas)
        if not plugin_datas:
            return
        # 从服务器获取插件升级信息,并显示在News栏中
        plugin_update_infos = []
        for data in plugin_datas:
            plugin_name = data['name']
            plugin_version = data['version']
           # update_msg = data['update_msg']
            msg = _("plugin '%s' latest version '%s' is available,click here to update it") % (
                plugin_name, plugin_version)
            data['title'] = msg
            data['subcontent'] = ''
            plugin_update_infos.append(data)
        self.update_params['plugin_updates'] = plugin_update_infos

    def GetFeeds(self):
        api = ApiServer()
        app_version = utils.get_app_version()
        data = api.request_api(
            'feed/items',
            {'app_version': app_version}
        )
        if data is None:
            utils.get_logger().error("get feeds from sever error....")
            return
        self.feeds = data['feeds']
        utils.get_logger().info("get feeds from sever success....")

    def CreateFeedNews(self):
        news_html_content = ''
        # 程序更新消息
        if self.update_params['has_new']:
            # 点击链接调用js的UpdateApp方法并传递1个参数.js方法关联Command对象的方法并触发调用升级程序
            click_event = "UpdateApp('%s')" % (
                self.update_params['app_version'])
            div = self.CreateUpdateNews(
                self.update_params['title'], self.update_params['subcontent'], click_event)
            news_html_content += div.prettify()
            news_html_content += "\n"
            self.number[Startup.NEWS] += 1
        # 插件更新消息
        if self.update_params['plugin_updates']:
            for plugin_update in self.update_params['plugin_updates']:
                # 点击链接调用js的UpdatePlugin方法并传递1个参数.js方法关联Command对象的方法并触发调用升级程序
                click_event = "UpdatePlugin('%s')" % (plugin_update['id'])
                div = self.CreateUpdateNews(
                    plugin_update['title'], plugin_update['subcontent'], click_event)
                news_html_content += div.prettify()
                news_html_content += "\n"
                self.number[Startup.NEWS] += 1

        learn_html_content = ''
        for feed in self.feeds:
            # 点击链接调用js的OpenFeedsUrl方法并传递2个参数,从而打开url链接
            click_event = "OpenFeedsUrl('%s','%s')" % (feed['url'], feed['id'])
            div = self.CreateNews(
                feed['title'], feed['subcontent'], click_event)
            if feed['category'] == Startup.NEWS and self.number[Startup.NEWS] <= Startup.DEFAULT_NEWS_NUM:
                news_html_content += div.prettify()
                news_html_content += "\n"
                self.number[Startup.NEWS] += 1
            elif feed['category'] == Startup.LEARN and self.number[Startup.LEARN] <= Startup.DEFAULT_LEARN_NUM:
                learn_html_content += div.prettify()
                learn_html_content += "\n"
                self.number[Startup.LEARN] += 1
        if news_html_content:
            # 调用js的LoadNews方法,并传递html文本加载资讯信息
            js_str = Startup.format_javasript_params(
                'LoadNews', news_html_content)
            self.webview.webview.page().runJavaScript(js_str)
        else:
            # 空的资讯内容
            self.webview.webview.page().runJavaScript('SetEmptyNews()')
        if learn_html_content:
            # 调用js的LoadLearn加载学习内容
            js_str = Startup.format_javasript_params(
                'LoadLearn', learn_html_content)
            self.webview.webview.page().runJavaScript(js_str)
        else:
            # 空的学习内容
            self.webview.webview.page().runJavaScript('SetEmptyLearn()')

    def CreateNews(self, title, subcontent, click_event):
        div = Tag(name='div', attrs={'class': 'item showLanguageExtensions'})
        btn = Tag(name='button', attrs={
                  'role': 'group', 'data-href': "command:workbench.extensions.action.showLanguageExtensions", 'onclick': click_event})
        h3 = Tag(name="h3", attrs={'class': 'caption'})
        h3.string = title
        span = Tag(name="span", attrs={'class': 'detail'})
        span.string = subcontent
        div.append(btn)
        btn.append(h3)
        btn.append(span)
        return div

    def CreateUpdateNews(self, title, subcontent, click_event):
        div = Tag(name='div', attrs={'class': 'item showLanguageExtensions'})
        btn = Tag(name='button_update_news', attrs={
                  'role': 'group', 'data-href': "command:workbench.extensions.action.showLanguageExtensions", 'onclick': click_event})
        h3 = Tag(name="h3", attrs={'class': 'caption'})
        h3.string = title
        span = Tag(name="span", attrs={'class': 'detail'})
        span.string = subcontent
        div.append(btn)
        btn.append(h3)
        btn.append(span)
        return div

    def LoadNews(self):
        def add_id(d):
            d.update({'id': '...'})
            return d
        if not self.has_new_app():
            self.check_app_update()
            self.check_plugin_update()
            self.init_feeds_num()
        self.GetFeeds()
        utils.get_logger().info("feeds count is %d", len(self.feeds))
        if len(self.feeds) < (Startup.DEFAULT_NEWS_NUM + Startup.DEFAULT_LEARN_NUM):
            # 如果从服务器获取资讯和学习数据失败,加载程序默认保存的数据
            data = self.LoadDefaultFeeds()
            data = list(map(add_id, data))
            self.feeds.extend(data)
            utils.get_logger().info(
                "feeds count is not enough,load embed data,now feeds number is %d", len(self.feeds))
        self.CreateFeedNews()
        # 调试模式时将起始页面的html内容保存到home路径中,以便程序调试网页
        if get_app().GetDebug():
            self.webview.webview.page().toHtml(self.save_to_path)
        utils.get_logger().info("load feeds end...")

    def save_to_path(self, content):
        homepath = appdirs.get_home_dir()
        test_page_path = os.path.join(homepath, "test_startuppage.html")
        with open(test_page_path, "w", encoding=UTF8_FILE_ENCODING) as f:
            f.write(content)

    def LoadDefaultFeeds(self):
        data_path = utils.get_app_data_location()
        feeds_file = os.path.join(data_path, "feeds.json")
        try:
            content = fileutils.get_file_content(feeds_file)
            return json.loads(content)
        except Exception as exc:
            utils.get_logger().error('Error reading feed file %s: %s', feeds_file, str(exc))
            return []


class Startup:
    # 起始页显示资讯信息
    NEWS = "news"
    # 起始页显示学习信息
    LEARN = "learn"
    # 默认显示的资讯信息个数
    DEFAULT_NEWS_NUM = 3
    # 默认显示的学习信息个数
    DEFAULT_LEARN_NUM = 3

    def __init__(self, parent=None):
        # has_new表示app是否有更新, plugin_updates表示插件更新信息,最多3条
        self.app_update_params = {'has_new': False, 'plugin_updates': []}
        self._parent = parent

    @property
    def parent(self):
        return self._parent

    @parent.setter
    def parent(self, parent):
        self._parent = parent

    @staticmethod
    def format_javasript_params(function_name, html_content):
        '''
            格式化程序执行的js字符串
        '''
        # 必须剔除html里面的换行符才能传参
        new_html_content = html_content.replace(
            '\r\n', '').replace('\n', '').replace("'", "\\'")
        return f'{function_name}(\'{new_html_content}\');'

    def load_data(self, webview):
        self.LoadRecent(webview)
        utils.get_logger().info("load startup page feeds data")
        FeedsLoader(webview, self.app_update_params).start()

    def UpdateWelcomeTheme(self, skin_name):
        # 如果显示起始页,不弹出程序升级提示框,程序升级信息显示在起始页的News中
        if utils.profile_get_int(globalkeys.SHOW_WELCOME_PAGE_KEY, True):
            self.GotoStartupPage(skin_name)
        else:
            # 否则弹出程序升级提示框
            AppUpdate(self.parent).start()

    def ShowWelcomePage(self):
        self.GotoStartupPage(utils.profile_get(
            globalkeys.APP_SKIN_KEY, AppSkin.DEFAULT_APP_SKIN.value))

    def GotoDefaultWebsite(self):
        self.GotoWebView(UserDataDb.HOST_SERVER_ADDR)

    def GotoStartupPage(self, theme):
        webview_template = get_app().GetDocumentManager().FindTemplateForTestPath(".com")
        doc = get_app().GetDocumentManager().CreateTemplateDocument(
            webview_template,
            _("Start page"),
            DOC_SILENT | DOC_OPEN_ONCE | constants.APPLICATION_STARTUP_PAGE
        )
        self.LoadStartupPage(doc, theme)

    def LoadStartupPage(self, doc, theme):
        self.OpenStartupPage(doc, theme)

    def LoadRecentProjects(self):
        recent_projects = []
        project_history = get_app().GetDocumentManager().GetProjectHistory()
        get_app().GetDocumentManager().load_project_template()
        project_extensions = get_app().GetDocumentManager().project_extensions
        file_size = project_history.GetCurrentSize()
        for i in range(file_size):
            path = project_history.GetHistoryFile(i)
            if strutils.get_file_extension(path, keepdot=True) not in project_extensions:
                continue
            recent_projects.append(path)
        return recent_projects

    def LoadRecent(self, webview):
        recent_projects = self.LoadRecentProjects()
        if recent_projects == []:
            webview.webview.page().runJavaScript('SetEmptyProject()')
        else:
            project_html_content = ''
            for recent_project in recent_projects:
                recent_project_path = recent_project.replace(
                    ":", "|").replace("\\", '/')
                li = Tag(name='li', attrs={'class': 'path'})
                a = Tag(
                    name='a',
                    attrs={
                        'href': 'javascript:void(0)',
                        'title': recent_project.replace('\\', '\\\\'),
                        'onclick': "OpenRecentProject('%s')" % recent_project_path
                    }
                )
                a.string = os.path.basename(recent_project)
                li.append(a)
                project_html_content += li.prettify()
                project_html_content += "\n"
            js_str = self.format_javasript_params(
                'LoadProjects', project_html_content)
            webview.webview.page().runJavaScript(js_str)

    def OpenStartupPage(self, doc, theme):
        # 将css代码中的部分颜色根据皮肤颜色进行格式化
        # 在调试模式时允许起始页面网页弹出右键菜单,否则禁止弹出,代表document.oncontextmenu的属性值
        welcome_html_code = html_code % (
            COLORS.get(theme, COLORS[AppSkin.DEFAULT_APP_SKIN.value]) +
            ("true" if get_app().GetDebug() else "false", )
        )
        web_view = doc.GetFirstView()
        web_view_theme = web_view.theme
        if web_view_theme is None:
            web_view.webview.settings().setAttribute(
                QWebEngineSettings.JavascriptEnabled, True)
            channel = QWebChannel(web_view.webview.page())
            web_view.webview.page().setWebChannel(channel)
            self.command = Command(None)
            channel.registerObject("Command", self.command)
            # 禁止拖拽打开文件
            web_view.webview.setAcceptDrops(False)
            web_view.webview.setHtml(welcome_html_code)
            # 页面加载完全后再调用,否则会报js: Uncaught ReferenceError: xxx is not defined等错误
            # 页面加载完成后加载历史项目,从服务器获取资讯和学习信息等数据
            web_view.webview.loadFinished.connect(
                lambda: self.load_data(web_view))  # 加上这一句
        else:
            web_view.webview.setHtml(welcome_html_code)
        web_view.theme = theme


startup = Startup()


def update_startup_ui_theme():
    '''
        根据界面主题更改起始页配置主题颜色
    '''
    startup_doc = get_app().GetDocumentManager().GetDocument(_("Start page"))
    if startup_doc:
        app_theme = utils.profile_get(
            globalkeys.APP_SKIN_KEY, AppSkin.DEFAULT_APP_SKIN.value)
        startup.LoadStartupPage(startup_doc, app_theme)


def show_startup_page(parent):
    help_menu = find_menu(_("&Help"), get_app().Menubar)
    get_app().InsertCommand(
        menuitems.ID_OPEN_DOCUMENTATION,
        menuitems.ID_SHOW_WELCOME_PAGE,
        help_menu,
        _("Start page"),
        handler=startup.ShowWelcomePage,
        image=get_app().GetImage("web/start.png")
    )
    startup.parent = parent
    startup.UpdateWelcomeTheme(utils.profile_get(
        globalkeys.APP_SKIN_KEY, AppSkin.DEFAULT_APP_SKIN.value))
    get_app().MainFrame.UI_WINDOW_THEME_CHANGED.connect(update_startup_ui_theme)
