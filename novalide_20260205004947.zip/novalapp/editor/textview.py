# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------------
# Name:        text.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-03-11
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
# -------------------------------------------------------------------------------
import shutil
import os
import codecs
from .. import get_app, _
from ..lib.document import Document
from ..lib.docview import View
from ..util import filewatcher
from ..util import utils, fileutils, ui_utils
from ..bars.menubar import find_menu_item
from ..syntax import lang, themes
from . import docposition
from .. import globalkeys, constants
from ..widgets import simpledialog
from ..syntax.syntax import SyntaxThemeManager
from .formatter import TextFormatter
from .texteditor import TextEditor
from .textframe import TextFrame
from ..lib.pyqt import (
    QMessageBox,
    QColor,
    QFileDialog,
    QSlider,
    QHBoxLayout,
    Qt,
    QLabel,
    QSizePolicy,
    QLineEdit,
    QSpinBox,
    QCheckBox
)
from ..lib.qsci import QsciScintilla
from .. import menuitems
from ..util.filewatcher import FileEventHandler
from ..common.encodings import ASCII_FILE_ENCODING, ANSI_FILE_ENCODING, UTF8_FILE_ENCODING, BINARY
from .escape import EscapeView


class TextDocument(Document):
    def __init__(self):
        super().__init__()
        self._inModify = False
        self.file_watcher = filewatcher.FileAlarmWatcher()
        self._is_watched = False
        self.file_encoding = utils.profile_get(
            globalkeys.DEFAULT_FILE_ENCODING_KEY, ASCII_FILE_ENCODING)
        self._is_new_doc = True
        self._is_loading_doc = False

    @property
    def IsNewDocument(self):
        return self._is_new_doc

    @property
    def IsWatched(self):
        return self._is_watched

    @property
    def FileWatcher(self):
        return self.file_watcher

    def GetSaveObject(self, filename):
        return codecs.open(filename, 'w', self.file_encoding)

    def DoSave(self):
        if self._is_watched:
            self.file_watcher.StopWatchFile(self)
        # 文件保存后可能会改变,需要再此检测文件编码
        self.file_encoding = self.DetectDocumentEncoding()
        # 在状态栏现实变化后的文件编码
        get_app().MainFrame.sbEncoding.setText(
            self.file_encoding
        )

    def GetOpenDocument(self, filepath, exclude_self=True):
        '''
            通过文件名查找打开文件
            exclude_self:是否排查自身

        '''
        if exclude_self and fileutils.ComparePath(
            self.GetFilename(),
            filepath
        ):
            return None
        doc = get_app().GetDocumentManager().GetDocument(filepath)
        return doc

    def SaveAs(self):
        """
        Prompts the user for a file to save to, and then calls OnSaveDocument.
        """
        doc_template = self.GetDocumentTemplate()
        if not doc_template:
            return False

        default_ext = doc_template.GetDefaultExtension()
        if doc_template.GetFileFilter() == "*.*":
            default_ext = ""
        descrs = get_app().GetDocumentManager().get_filters()
        initialfile = os.path.basename(self.GetFilename())
        if not initialfile.endswith(default_ext):
            initialfile += default_ext
        filename, filetype = QFileDialog.getSaveFileName(
            get_app().MainFrame,
            _('Save As'),
            initialfile,
            descrs  # 设置文件扩展名过滤,用双分号间隔
            # initialfile=
        )
        if filename == "":
            return False

        # 将路径转换成系统标志路径格式
        filename = fileutils.opj(filename)
        # 检查文件名是否已经被打开的文件占用,如果占用了则不能保存文件
        if self.GetOpenDocument(filename):
            QMessageBox.warning(
                get_app().MainFrame,
                get_app().GetAppName(),
                _("File has already been opened,could not overwrite it.")
            )
            return False

        if not self.OnSaveDocument(filename):
            return False

        self.SetFilename(filename)
        self.SetTitle(fileutils.get_filename_from_path(filename))
        get_app().MainFrame.sbFile.setPath(_("File") + ": " + filename)

        for view in self._document_views:
            view.OnChangeFilename()

        if doc_template.FileMatchesTemplate(filename):
            self.GetDocumentManager().AddFileToHistory(filename)

        return True

    @ui_utils.wait_cursor
    def OnSaveDocument(self, filename):
        """
        Constructs an output file for the given filename (which must
        not be empty), and calls SaveObject. If SaveObject returns true, the
        document is set to unmodified; otherwise, an error message box is
        displayed.
        """
        if not filename:
            return False

        msg_title = get_app().GetAppName()
        if not msg_title:
            msg_title = _("File Error")
        self._is_loading_doc = False
        backup_filename = None
        fileobject = None
        copied = False
        try:
            self.DoSave()
            # if current file exists, move it to a safe place temporarily
            if os.path.exists(filename):
                # Check if read-only.
                if not os.access(filename, os.W_OK):
                    QMessageBox.critical(
                        self.GetDocumentWindow(),
                        msg_title,
                        _("Could not save '%s'.  No write permission to overwrite existing file.") %
                        fileutils.get_filename_from_path(filename)
                    )
                    self.GetFirstView().GetCtrl().setReadOnly(True)
                    return False
                # 保存文件之前先备份文件,以便写入文件失败之后能恢复文件
                backup_filename = "%s.bk%s" % (filename, 1)
                shutil.copy(filename, backup_filename)
                copied = True
            fileobject = self.GetSaveObject(filename)
            self.SaveObject(fileobject)
            fileobject.close()
            fileobject = None
            # 写入文件成功,删除备份文件
            if backup_filename:
                os.remove(backup_filename)
        except Exception as e:
            utils.get_logger().exception("save file error:")
            if fileobject:
                fileobject.close()  # file is still open, close it, need to do this before removal
            # save failed, remove copied file
            # 写入文件失败, 将备份文件拷贝以便恢复文件
            # 拷贝文件时可能有异常,捕获异常
            try:
                if backup_filename and copied:
                    shutil.copy(backup_filename, filename)
                    # 恢复文件之后删除备份文件
                    os.remove(backup_filename)
                if not self._is_new_doc:
                    self.SetDocumentModificationDate()
            except Exception as ex:
                utils.get_logger().error('resume backup file %s error:%s', backup_filename, str(ex))

            QMessageBox.critical(
                self.GetDocumentWindow(),
                msg_title,
                _("Could not save '%s':  %s") % (
                    fileutils.get_filename_from_path(filename), e)
            )
            return False

        self.SetFilename(filename, True)
        self.Modify(False)
        self.SetDocumentSaved(True)
        self._is_watched = True
        self._is_new_doc = False
        self.file_watcher.StartWatchFile(self)
        self.SetDocumentModificationDate()
        current_project = get_app().get_current_project()
        if current_project is not None:
            get_app().MainFrame.projectview.sigFileUpdated.emit(current_project, filename)
        return True

    def DetectFileEncoding(self, filepath):
        file_encoding = ASCII_FILE_ENCODING
        try:
            file_encoding = fileutils.detect_file_encoding(filepath)
        except:
            utils.get_logger().exception("")
        # if detect file encoding is None,we should assume the file encoding is ansi,which cp936 encoding is instead
        if None == file_encoding or file_encoding.lower().find('iso') != -1:
            file_encoding = ANSI_FILE_ENCODING
        return file_encoding

    def DetectDocumentEncoding(self):
        view = self.GetFirstView()
        file_encoding = self.file_encoding
        # when the file encoding is accii or new document,we should check the document data contain chinese character,
        # the we should change the document encoding to utf-8 to save chinese character
        if file_encoding == ASCII_FILE_ENCODING or self.IsNewDocument:
            guess_encoding = file_encoding.lower()
            if guess_encoding == ASCII_FILE_ENCODING:
                guess_encoding = UTF8_FILE_ENCODING
            result = fileutils.detect(view.GetValue().encode(guess_encoding))
            file_encoding = result['encoding']
            if None == file_encoding:
                file_encoding = ASCII_FILE_ENCODING
        return file_encoding

    @ui_utils.wait_cursor
    def OnOpenDocument(self, filename):
        """
        Constructs an input file for the given filename (which must not
        be empty), and calls LoadObject. If LoadObject returns true, the
        document is set to unmodified; otherwise, an error message box is
        displayed. The document's views are notified that the filename has
        changed, to give windows an opportunity to update their titles. All of
        the document's views are then updated.
        """
        # 文件在外部改变重新打开时检查界面文本是否更改需要保存
        if not self.OnSaveModified():
            return False
        if self.load(filename):
            self.SetFilename(filename, True)
            self.file_watcher.AddFileDoc(self)
            self._is_watched = True
            return True
        return False

    def reload(self):
        return self.load(self.GetFilename())

    def load(self, filename):
        self._is_loading_doc = True
        msg_title = get_app().GetAppName()
        if not msg_title:
            msg_title = _("File Error")
        self.file_encoding = self.DetectFileEncoding(filename)
        file_object = None
        try:
            if self.file_encoding == BINARY:
                # 打开二进制文件
                file_object = open(filename, 'rb')
                is_bytes = True
            else:
                file_object = codecs.open(filename, 'r', self.file_encoding)
                is_bytes = False
            self.LoadObject(file_object, is_bytes)
            file_object.close()
            file_object = None
        except Exception as e:
            utils.get_logger().exception("")
            if file_object:
                file_object.close()  # file is still open, close it
            QMessageBox.critical(
                self.GetDocumentWindow(),
                msg_title,
                _("Could not open '%s':  %s") % (
                    fileutils.get_filename_from_path(filename), e)
            )
            self._is_loading_doc = False
            return False

        self.SetDocumentModificationDate()

        self.Modify(False)
        self.SetDocumentSaved(True)
        self.UpdateAllViews()

        self._is_new_doc = False
        rember_file_pos = get_app().GetConfig().ReadInt(globalkeys.REMBER_FILE_KEY, True)
        if rember_file_pos:
            pos = docposition.DocMgr.GetPos(filename)
            if pos[0] is not None:
                self.GetFirstView().GetCtrl().GotoPos(*pos)
        self._is_loading_doc = False
        return True

    def SaveObject(self, file):
        view = self.GetFirstView()
        msg = {'doc': self, 'data': view.GetValue()}
        # 保存文件事件
       # GetApp().event_generate(constants.FILE_SAVEING_EVT,msg=msg)
        file.write(msg['data'])
        view.SetModified(False)
        return True

    def LoadObject(self, file, is_bytes=False):
        view = self.GetFirstView()
        data = file.read()
        msg = {'doc': self, 'data': data}
        # 打开文件事件
#        GetApp().event_generate(constants.FILE_OPENING_EVT,msg=msg)
        if is_bytes:
            view.set_binary_value(msg['data'])
        else:
            view.SetValue(msg['data'])
        view.SetModified(False)
        return True

    def IsModified(self):
        filename = self.GetFilename()
        if filename and not os.path.exists(filename) and not self._is_new_doc:
            return True
        view = self.GetFirstView()
        if view:
            return view.IsModified()
        return False

    def Modify(self, modify):
        if self._inModify:
            return
        self._inModify = True
        view = self.GetFirstView()
        if not modify and view:
            # 设置编辑器状态为未修改
            view.SetModified(False)
        super().Modify(modify)
        self._inModify = False


class TextView(EscapeView, ui_utils.AlarmEventMixin, TextFormatter):
    FILE_MODIFY_ANSWER = None
    FILE_MOVE_DELETED_ANSWER = None

    def __init__(self):
        super().__init__()
        ui_utils.AlarmEventMixin.__init__(self)
        self._textEditor = None
        self._markerCount = 0
        self.__mainwindow = get_app().MainFrame
        # Initialize the classes position manager for the first control
        # that is created only.
        if not docposition.DocMgr.IsInitialized():
            docposition.DocMgr.InitPositionCache()

    @classmethod
    def reset_file_changed_answer(cls):
        cls.FILE_MOVE_DELETED_ANSWER = None
        cls.FILE_MODIFY_ANSWER = None

    def GetCtrlClass(self):
        """ Used in split window to instantiate new instances """
        return TextEditor

    def GetLangId(self):
        return lang.ID_LANG_TXT

    def GetCtrl(self):
        return self._textEditor

    def SetCtrl(self, ctrl):
        self._textEditor = ctrl

    def OnCreate(self, doc, flags):
        frame = get_app().CreateDocumentFrame(self, doc, flags)
        frame.attach_horizontal_layout()
        self._text_frame = TextFrame(
            frame, self, text_class=self.GetCtrlClass())
        self._textEditor = self._text_frame.getEditor()
        self._textEditor.init_editor_font()
        self._textEditor.update_margins()
        # 移到鼠标和光标实时在状态栏显示移动位置等
        self.connect_editor_widget()
        layout = frame.layout()
        layout.addWidget(self._text_frame)
        self._textEditor.setFocus()
        self.update_appearance()
        return True

    def connect_editor_widget(self):
        """Connects the editor's signals"""
        self._textEditor.modificationChanged.connect(
            self.__modificationChanged)
        self._textEditor.textChanged.connect(self.contentChanged)
        self._textEditor.cursorPositionChanged.connect(
            self.__cursorPositionChanged)
        super().connect_editor_widget()

    def contentChanged(self):
        """Triggered when a buffer content is changed"""
        get_app().MainFrame.projectview.SIG_BUFFER_MODIFIED.emit(
            get_app().get_current_project(),
            self
        )
        self.OnModify()

    def update_appearance(self):
        self.GetCtrl().update_margins()
        # 设置代码边界线长度
        view_right_edge = utils.profile_get_int(
            globalkeys.TEXT_VIEW_RIGHTEDGE_KEY, True)
        if view_right_edge:
            edge_guide_width = utils.profile_get_int(
                globalkeys.TEXT_EDGE_WIDTH_KEY,
                constants.DEFAULT_EDGE_GUIDE_WIDTH
            )
        else:
            edge_guide_width = 0
        if edge_guide_width > 0:
            self.GetCtrl().setEdgeMode(QsciScintilla.EdgeLine)
            self.GetCtrl().setEdgeColumn(edge_guide_width)
        else:
            self.GetCtrl().setEdgeMode(QsciScintilla.EdgeNone)
        # 是否高亮文本当前行
        tag_current_line = utils.profile_get_int(
            globalkeys.TEXT_HIGHLIGHT_CARETLINE_KEY, True)
        if tag_current_line:
            self.GetCtrl().setCaretLineVisible(True)
        else:
            self.GetCtrl().setCaretLineVisible(False)
        # 设置高亮行背景色
        self.GetCtrl().setCaretLineBackgroundColor(QColor("#28FFEEAA"))
        if utils.profile_get_int(globalkeys.TEXT_EDITOR_VIEWWHITESPACE_KEY, False):
            self.GetCtrl().setWhitespaceVisibility(True)
        else:
            self.GetCtrl().setWhitespaceVisibility(False)
        if utils.profile_get_int(globalkeys.TEXT_EDITOR_VIEWEOL_KEY, False):
            self.GetCtrl().call(QsciScintilla.SCI_SETVIEWEOL, QsciScintilla.SCWS_VISIBLEALWAYS)
        else:
            self.GetCtrl().call(QsciScintilla.SCI_SETVIEWEOL, QsciScintilla.SCWS_INVISIBLE)
        self.set_lexer_syntax()

    def set_lexer_syntax(self):
        theme_name = utils.profile_get(
            globalkeys.SYNTAX_THEME_KEY, themes.DEFAULT_SYNTAX_THEME)
        lexer = SyntaxThemeManager.manager().GetLexer(self.GetLangId())
        syntax_options = lexer.style_items.get(theme_name, {})
        self.set_syntax(syntax_options)

    def set_syntax(self, syntax_options):
        self.GetCtrl().set_syntax(syntax_options)

    @ui_utils.update_toolbar
    @docposition.jumpto
    def record_track(self):
        pass

    def activate_view(self):
        self.SetFocus()
        # 设置视图为活跃视图
        get_app().GetDocumentManager().ActivateView(self)
        # 设置状态栏行列号
        self.set_pos()

    def set_pos(self):
        # 获取当前行,列位置
        line, column = self._textEditor.get_current_line_column()
        if column is not None:
            self.__mainwindow.sbPos.setText(_('Pos') + ': ' + str(column + 1))
        else:
            self.__mainwindow.sbPos.setText(_('Pos') + ': n/a')
        if line is not None:
            self.__mainwindow.sbLine.setText(_('Line') + ': ' + str(line + 1))
        else:
            self.__mainwindow.sbLine.setText(_('Line') + ': n/a')

    def set_encoding(self):
        get_app().MainFrame.sbEncoding.setText(
            self.GetDocument().file_encoding
        )
        if self.GetDocument().file_encoding == BINARY:
            get_app().MainFrame.sbLanguage.setText(_('Binary File'))
        get_app().MainFrame.sbEncoding.setToolTip('')

    def set_eol(self):
        eol_label = self.GetCtrl().getEolIndicator()
        get_app().MainFrame.sbEol.setText(eol_label)

    @ui_utils.call_after
    # 这里必须延迟执行,才能根据编辑器文本的状态更新工具栏编辑按钮的状态
    @ui_utils.update_toolbar
    def OnModify(self):
        self.GetDocument().Modify(self.IsModified())

    def SetValue(self, value):
        '''
            加载文件内容
        '''
        self.GetCtrl().setText(value)
        self.GetCtrl().UpdateLineNumberWidth(utils.profile_get_int(
            globalkeys.TEXT_VIEW_LINENUMBERS_KEY, True))
        self.CheckEol(value)

    def set_binary_value(self, bytes_val):
        length = len(bytes_val)
        self.GetCtrl().call(QsciScintilla.SCI_ADDSTYLEDTEXT, length, bytes_val)
        self.GetCtrl().setReadOnly(True)

    def get_line_end(self, eol):
        if eol == QsciScintilla.EolWindows:
            return constants.CRLF
        if eol == QsciScintilla.EolUnix:
            return constants.LF
        if eol == QsciScintilla.EolMac:
            return constants.CR
        assert False

    @ui_utils.call_after
    def CheckEol(self, value):
        check_mixed_eol = utils.profile_get_int(
            globalkeys.CHECK_EOL_KEY, False)
        mixed = False
        tmp = None
        line_eol = None
        # 检查混合行尾时检查全部行,否则只检查前10行文本作为eol的判断依据
        checked_lines = 10
        i = 0
        for cur in value.splitlines(True):
            if cur.endswith(constants.CRLF):
                line_eol = QsciScintilla.EolWindows
            elif cur.endswith(constants.LF):
                line_eol = QsciScintilla.EolUnix
            elif cur.endswith(constants.CR):
                line_eol = QsciScintilla.EolMac
            i += 1
            if line_eol is not None:
                self.GetCtrl().eol = line_eol
            if check_mixed_eol:
                if line_eol and not tmp:
                    tmp = line_eol
                elif tmp:
                    if line_eol != tmp:
                        mixed = True
                        break
            elif i >= checked_lines:
                break
        if mixed:
            self.GetCtrl().eol = constants.MIXED_CRLF
            msg = _("Mixed EOL characters detected.\n\n"
                    "Would you like to format them to all be the same?")
            name, ok = simpledialog.askitem(
                _("Format EOL?"), msg, constants.EOL_CHOICES, self.GetCtrl().eolMode())
            if ok:
                self.GetCtrl().eol = constants.EOL_CHOICES.index(name)
                self.GetCtrl().setEolMode(self.GetCtrl().eol)
                self.replace_eol(self.get_line_end(self.GetCtrl().eol))
                self.SetModified(True)
                self.GetDocument().Modify(True)
        else:
            self.GetCtrl().setEolMode(self.GetCtrl().eol)
        get_app().MainFrame.GetNotebook().updateStatusBar()

    @docposition.jump
    def GotoLine(self, lineno):
        assert isinstance(lineno, int)
        if lineno <= 0:
            lineno = 1
        # scintilla控件内部实际行号从0开始,所以界面显示的行号要减1
        self.GetCtrl().setFocus()
        self.GetCtrl().gotoLine(lineno - 1)
        self.set_pos()

    @docposition.jump
    def GotoPos(self, line, col):
        self.GetCtrl().GotoPos(line, col)

    def IsModified(self):
        if self._textEditor is not None:
            return self.GetCtrl().is_modified()
        return False

    def SetModified(self, modified):
        self.GetCtrl().setModified(modified)

    def SetFocus(self):
        if self._textEditor is not None:
            self._text_frame.setFocus()

    def GetValue(self):
        return self.GetCtrl().text()

    # 关闭文档以及文档标签页
    def OnClose(self, deleteWindow=True):
        if not View.OnClose(self, deleteWindow):
            return False

        document = self.GetDocument()
        if document.IsWatched:
            document.FileWatcher.RemoveFileDoc(document)
        # 关闭文档时纪录当前光标位置,下次从新打开文件时定位到该位置
        if not document.IsNewDocument:
            docposition.DocMgr.AddRecord(
                [
                    document.GetFilename(),
                    # 行列元组
                    self.GetCtrl().get_current_line_column()
                ]
            )
        self.Activate(False)
        self.__disconnectEditorWidget()
        # 关闭窗口时销毁右键菜单
        if self.GetCtrl().menu:
            self.GetCtrl().menu.destroy()
        if deleteWindow and self.GetFrame():
            self.GetFrame().Destroy()
        return True

    def check_for_external_changes(self):
        if self._asking_about_external_change:
            return
        self._asking_about_external_change = True
        document = self.GetDocument()
        filename = document.GetFilename()
        if self._alarm_event == FileEventHandler.FILE_MODIFY_EVENT:
            # 文本提示对话框选项有Yes,No,YesToAll,NoToAll
            # 只有用户选择YesToAll,NoToAll选项时此次不再连续弹出提示对话框
            # 但是此次操作完成后还是要继续弹出提示对话框
            if TextView.FILE_MODIFY_ANSWER not in (QMessageBox.YesToAll, QMessageBox.NoToAll):
                ret = QMessageBox.question(
                    self.GetFrame(),
                    _("Reload.."),
                    _("File \"%s\" has already been modified outside,Do You Want to reload it?") % filename,
                    QMessageBox.Yes | QMessageBox.No | QMessageBox.YesToAll | QMessageBox.NoToAll
                )
                TextView.FILE_MODIFY_ANSWER = ret
            else:
                ret = TextView.FILE_MODIFY_ANSWER
            if ret in (QMessageBox.Yes, QMessageBox.YesToAll):
                document.reload()
                get_app().MainFrame.projectview.SIG_BUFFER_MODIFIED.emit(
                    get_app().get_current_project(),
                    self
                )

        elif self._alarm_event in (FileEventHandler.FILE_MOVED_EVENT, FileEventHandler.FILE_DELETED_EVENT):
            if TextView.FILE_MOVE_DELETED_ANSWER not in (QMessageBox.YesToAll, QMessageBox.NoToAll):
                ret = QMessageBox.question(
                    self.GetFrame(),
                    _("Keep Document.."),
                    _("File \"%s\" has already been moved or deleted outside,Do You Want to keep it in Editor?") % filename,
                    QMessageBox.Yes | QMessageBox.No | QMessageBox.YesToAll | QMessageBox.NoToAll
                )
                TextView.FILE_MOVE_DELETED_ANSWER = ret
            else:
                ret = TextView.FILE_MOVE_DELETED_ANSWER
            if ret in (QMessageBox.Yes, QMessageBox.YesToAll):
                document.Modify(True)
            else:
                document.DeleteAllViews()
        self._asking_about_external_change = False
        ui_utils.AlarmEventMixin.check_for_external_changes(self)

    def ZoomView(self, delta=0):
        editor = self.GetCtrl()
        if delta > 0:
            editor.zoomIn(1)
        else:
            editor.zoomOut(1)

    def AppendText(self, txt):
        self.GetCtrl().append_text(txt)

    def UpdateUI(self, command_id):
        if self.GetCtrl() is None:
            return False
        if self.GetCtrl().ProcessUpdateEvent(command_id):
            return True
        if command_id == menuitems.ID_SAVE:
            return self.GetDocument().IsModified()
        if command_id in [
            menuitems.ID_INSERT_COMMENT_TEMPLATE,
            menuitems.ID_INSERT_DECLARE_ENCODING,
            menuitems.ID_UNITTEST,
            menuitems.ID_COMMENT_LINES,
            menuitems.ID_UNCOMMENT_LINES,
            menuitems.ID_RUN,
            menuitems.ID_DEBUG,
            menuitems.ID_GOTO_DEFINITION,
            menuitems.ID_FIND_OCCURRENCES,
            menuitems.ID_SET_EXCEPTION_BREAKPOINT,
            menuitems.ID_STEP_INTO,
            menuitems.ID_STEP_NEXT,
            menuitems.ID_RUN_LAST,
            menuitems.ID_CHECK_SYNTAX,
            menuitems.ID_SET_PARAMETER_ENVIRONMENT,
            menuitems.ID_DEBUG_LAST,
            menuitems.ID_START_WITHOUT_DEBUG,
            menuitems.ID_AUTO_COMPLETE,
            menuitems.ID_TOGGLE_BREAKPOINT,
            menuitems.ID_INDENT_LINES,
            menuitems.ID_DEDENT_LINES,
            menuitems.ID_INSERT_MAIN_STATEMENT
        ]:
            return False
        if command_id == menuitems.ID_UNDO:
            return self.GetCtrl().CanUndo()
        if command_id == menuitems.ID_REDO:
            return self.GetCtrl().CanRedo()
            return self.GetCtrl().CanCut()
        if command_id in [
            menuitems.ID_UPPERCASE,
            menuitems.ID_LOWERCASE,
            menuitems.ID_TAB_SPACE,
            menuitems.ID_SPACE_TAB,
            menuitems.ID_FIRST_UPPERCASE
        ]:
            return self.GetCtrl().hasSelection() and not self.GetCtrl().isReadOnly()
        if command_id in [
            menuitems.ID_EOL_MAC,
            menuitems.ID_EOL_UNIX,
            menuitems.ID_EOL_WIN
        ]:
            get_app().MainFrame.GetNotebook().el_group.actions()[
                self.GetCtrl().eolMode()].setChecked(True)
            return True

        if command_id in [
            menuitems.ID_COPY_LINE,
            menuitems.ID_ZOOM_IN,
            menuitems.ID_ZOOM_OUT,
            menuitems.ID_REPLACE,
            menuitems.ID_GOTO_LINE,
            menuitems.ID_FINDFILE,
            menuitems.ID_CLOSE,
            menuitems.ID_CLOSE_ALL,
            menuitems.ID_SAVEAS,
            menuitems.ID_PRINT
        ]:
            return True
        if command_id in [
            menuitems.ID_FIRST_UPPERCASE,
            menuitems.ID_CUT_LINE,
            menuitems.ID_DELETE_LINE,
            menuitems.ID_CLONE_LINE,
            menuitems.ID_CLEAN_WHITESPACE,
            menuitems.ID_INSERT_DATETIME,
            menuitems.ID_INSERT_FILE_CONTENT,
        ]:
            return not self.GetCtrl().isReadOnly()
        if command_id == menuitems.ID_VIEW_WHITESPACE:
            item = find_menu_item(_("&View"), menuitems.ID_VIEW_WHITESPACE)
            item.action.setChecked(self.GetCtrl().whitespaceVisibility())
            return True
        if command_id == menuitems.ID_VIEW_EOL:
            item = find_menu_item(_("&View"), menuitems.ID_VIEW_EOL)
            item.action.setChecked(self.GetCtrl().eolVisibility())
            return True
        if command_id == menuitems.ID_VIEW_INDENTATION_GUIDES:
            item = find_menu_item(
                _("&View"), menuitems.ID_VIEW_INDENTATION_GUIDES)
            item.action.setChecked(self.GetCtrl().indentationGuides())
            return True
        if command_id == menuitems.ID_VIEW_RIGHT_EDGE:
            item = find_menu_item(_("&View"), menuitems.ID_VIEW_RIGHT_EDGE)
            item.action.setChecked(
                self.GetCtrl().edgeMode() != QsciScintilla.EdgeNone)
            return True
        return super().UpdateUI(command_id)

    def ProcessEvent(self, command_id):
        if self.GetCtrl().ProcessEvent(command_id):
            return True
        if command_id == menuitems.ID_REDO:
            self.GetCtrl().redo()
        elif command_id == menuitems.ID_UNDO:
            self.GetCtrl().undo()
        else:
            return False
        return True

    def DoFind(self):
        self.GetCtrl().DoFind()

    def do_eol(self, event_id):
        eol = -1
        if event_id == menuitems.ID_EOL_MAC:
            # EolMac(1)
            eol = QsciScintilla.EolMac
        elif event_id == menuitems.ID_EOL_WIN:
            # EolWindows(0)
            eol = QsciScintilla.EolWindows
        elif event_id == menuitems.ID_EOL_UNIX:
            # EolUnix(2)
            eol = QsciScintilla.EolUnix
        else:
            assert False
        self.replace_eol(self.get_line_end(eol))
        self.GetCtrl().eol = eol
        self.GetCtrl().setEolMode(eol)
        self.set_eol()

    def toogle_edge_visibility(self):
        if self.GetCtrl().edgeMode() == QsciScintilla.EdgeNone:
            self.GetCtrl().setEdgeMode(QsciScintilla.EdgeLine)
        else:
            self.GetCtrl().setEdgeMode(QsciScintilla.EdgeNone)

    def toogle_indentation_guides_visibility(self):
        if self.GetCtrl().indentationGuides():
            self.GetCtrl().setIndentationGuides(False)
        else:
            self.GetCtrl().setIndentationGuides(True)

    def toogle_eol_visibility(self):
        if self.GetCtrl().eolVisibility():
            self.GetCtrl().setEolVisibility(False)
        else:
            self.GetCtrl().setEolVisibility(True)

    def toogle_whitespace_visibility(self):
        if self.GetCtrl().whitespaceVisibility():
            self.GetCtrl().setWhitespaceVisibility(False)
        else:
            self.GetCtrl().setWhitespaceVisibility(True)

    def reset_text(self, newchars):
        # 先清空所有文本
        self.GetCtrl().clearall()
        # 再插入所有新文本,是文本处于修改状态
        self.GetCtrl().insert_text(0, newchars)
        self.SetModified(True)
        self.GetDocument().Modify(True)

    # Arguments: modified
    def __modificationChanged(self, _=None):
        """Triggered when the file is changed"""
        # 在文件内容未发生改变时也会触发此消息,故需要判断文件内容是否有实际变动
        # 否则在按alt+shift按键选择多行文本时会导致程序无故退出
        if self.IsModified():
            self.OnModify()

    def __disconnectEditorWidget(self):
        """Disconnects the editor's signals"""
        self._textEditor.modificationChanged.disconnect(
            self.__modificationChanged)
        self._textEditor.textChanged.disconnect(self.contentChanged)
        self._textEditor.cursorPositionChanged.disconnect(
            self.__cursorPositionChanged)
        self._textEditor.SIG_ESCAPE_PRESSED.disconnect(self._on_esc)

    def __cursorPositionChanged(self):
        """Triggered when the cursor position changed"""
        self.set_pos()
        self.GetCtrl().setFocus()
        get_app().GetDocumentManager().ActivateView(self)


class TextOptionsPanel(ui_utils.BaseConfigurationPanel):

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self._hastabs = False
        self._viewWhitespaceCheckBox = QCheckBox(_("Show whitespace"))
        self.layout.addWidget(self._viewWhitespaceCheckBox)
        self._viewWhitespaceCheckBox.setChecked(utils.profile_get_int(
            globalkeys.TEXT_EDITOR_VIEWWHITESPACE_KEY, False))

        self._viewEOLCheckBox = QCheckBox(_("Show end of line markers"))
        self.layout.addWidget(self._viewEOLCheckBox)
        self._viewEOLCheckBox.setChecked(utils.profile_get_int(
            globalkeys.TEXT_EDITOR_VIEWEOL_KEY, False))

        self._viewIndentationGuideCheckBox = QCheckBox(
            _("Show indentation guides"))
        self.layout.addWidget(self._viewIndentationGuideCheckBox)
        self._viewIndentationGuideCheckBox.setChecked(utils.profile_get_int(
            globalkeys.TEXT_EDITOR_VIEWINDENTATIONGUIDES_KEY, False))

        self.viewRightEdgeCheckBox = QCheckBox(_("Show right edge"))
        self.viewRightEdgeCheckBox.clicked.connect(self.CheckViewRightEdge)
        self.layout.addWidget(self.viewRightEdgeCheckBox)
        self.viewRightEdgeCheckBox.setChecked(
            utils.profile_get_int(globalkeys.TEXT_VIEW_RIGHTEDGE_KEY, True))

        self.viewLineNumbersCheckBox = QCheckBox(_("Show line numbers"))
        self.layout.addWidget(self.viewLineNumbersCheckBox)
        self.viewLineNumbersCheckBox.setChecked(
            utils.profile_get_int(globalkeys.TEXT_VIEW_LINENUMBERS_KEY, True))

        self.view_codefold_CheckBox = QCheckBox(_("Show code fold"))
        self.layout.addWidget(self.view_codefold_CheckBox)
        self.view_codefold_CheckBox.setChecked(
            utils.profile_get_int(globalkeys.CODE_EDITOR_VIEWFOLD_KEY, True))

        self.highlightCaretLineCheckBox = QCheckBox(_("Highlight Caret Line"))
        self.layout.addWidget(self.highlightCaretLineCheckBox)
        self.highlightCaretLineCheckBox.setChecked(
            utils.profile_get_int(globalkeys.TEXT_HIGHLIGHT_CARETLINE_KEY, True))

        self.highlightParenthesesCheckBox = QCheckBox(
            _("Highlight parentheses"))
        self.layout.addWidget(self.highlightParenthesesCheckBox)
        self.highlightParenthesesCheckBox.setChecked(
            utils.profile_get_int(globalkeys.TEXT_HIGHLIGHT_PARENTHESES_KEY, True))
        self.usetabs_checkbox = QCheckBox(_("Use spaces instead of tabs"))
        self.layout.addWidget(self.usetabs_checkbox)
        self.usetabs_checkbox.clicked.connect(self.check_use_tabs)
        self.usetabs_checkbox.setChecked(not utils.profile_get_int(
            globalkeys.TEXT_INDENTATION_USETABS_KEY, False))

        indent_hbox = QHBoxLayout()
        indent_hbox.setAlignment(Qt.AlignLeft)
        indent_hbox.addWidget(QLabel(_("Indent width") + ":"))
        self.indent_edit = QLineEdit()
        self.indent_edit.setReadOnly(True)
        self.indent_edit.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        indent_hbox.addWidget(self.indent_edit)
        indent_width = utils.profile_get_int(
            globalkeys.TEXT_EDITOR_INDENT_WIDTH_KEY, constants.DEFAULT_TAB_INDENTATION_WIDTH)
        self.indent_edit.setText(str(indent_width))
        self.indentWidthChoice = QSlider(
            Qt.Horizontal,
            value=indent_width,
            minimum=2,
            maximum=10,
            singleStep=2
        )
        # 刻度位置，刻度在右方
        self.indentWidthChoice.setTickPosition(QSlider.TicksRight)
        # 设置刻度间隔
        self.indentWidthChoice.setTickInterval(2)
        # 连接信号槽
        self.indentWidthChoice.valueChanged.connect(self.indent_value_changed)
        indent_hbox.addWidget(self.indentWidthChoice)
        self.layout.addLayout(indent_hbox)

        tabs_hbox = QHBoxLayout()
        tabs_hbox.setAlignment(Qt.AlignLeft)
        tabs_hbox.addWidget(QLabel(_("Tabs width") + ":"))
        self.tabswidth_spin_ctrl = QSpinBox(
            value=utils.profile_get_int(
                'TextEditorTabsWidth', constants.DEFAULT_TAB_WIDTH),
            minimum=2,
            maximum=10,
            singleStep=2
        )
        tabs_hbox.addWidget(self.tabswidth_spin_ctrl)
        self.layout.addLayout(tabs_hbox)

        self.chktab_box = QCheckBox(_("Warn when text contains tabs"))
        self.layout.addWidget(self.chktab_box)
        self.chktab_box.setChecked(utils.profile_get_int(
            globalkeys.CHECK_CODE_EDITOR_TABS_KEY, True))

        edge_hbox = QHBoxLayout()
        edge_hbox.setAlignment(Qt.AlignLeft)
        edge_hbox.addWidget(QLabel(_("Edge guide width") + ":"))
        self.edge_spin_ctrl = QSpinBox(
            value=utils.profile_get_int(
                globalkeys.TEXT_EDGE_WIDTH_KEY, constants.DEFAULT_EDGE_GUIDE_WIDTH),
            minimum=0,
            maximum=160,
            singleStep=1
        )
        edge_hbox.addWidget(self.edge_spin_ctrl)
        self.layout.addLayout(edge_hbox)

        self.autoindent_box = QCheckBox(_("Auto indent"))
        self.layout.addWidget(self.autoindent_box)
        self.autoindent_box.setChecked(
            utils.profile_get_int("AutoIndent", True))
        self.layout.addStretch(1)
        self.CheckViewRightEdge()
        self.check_use_tabs()

    def check_use_tabs(self):
        if self.usetabs_checkbox.isChecked():
            self.indent_edit.setEnabled(True)
            self.indentWidthChoice.setEnabled(True)
            self.tabswidth_spin_ctrl.setEnabled(False)
            self.chktab_box.setEnabled(True)
        else:
            self.indent_edit.setEnabled(False)
            self.indentWidthChoice.setEnabled(False)
            self.tabswidth_spin_ctrl.setEnabled(True)
            self.chktab_box.setEnabled(False)

    def indent_value_changed(self):
        indent = self.indentWidthChoice.value()
        # 改变标签字体大小至滑动条对应值
        self.indent_edit.setText(str(indent))

    def SetAutoCompletion(self):
        if self.use_autocompletion_var.get():
            self.enhanced_autocompletion_btn['state'] = tk.NORMAL
        else:
            self.enhanced_autocompletion_btn['state'] = tk.DISABLED

    def CheckViewRightEdge(self):
        if self.viewRightEdgeCheckBox.isChecked():
            self.edge_spin_ctrl.setEnabled(True)
        else:
            self.edge_spin_ctrl.setEnabled(False)

    def OnOK(self, options_dialog):
        doview_stuff_update = False

        view_whitespace = self._viewWhitespaceCheckBox.isChecked()
        doview_stuff_update = utils.profile_get_int(
            globalkeys.TEXT_EDITOR_VIEWWHITESPACE_KEY, False) != view_whitespace
        utils.profile_set(
            globalkeys.TEXT_EDITOR_VIEWWHITESPACE_KEY, view_whitespace)

        view_eol = self._viewEOLCheckBox.isChecked()
        doview_stuff_update = doview_stuff_update or utils.profile_get_int(
            globalkeys.TEXT_EDITOR_VIEWEOL_KEY, False) != view_eol
        utils.profile_set(globalkeys.TEXT_EDITOR_VIEWEOL_KEY, view_eol)

        view_indentationguide = self._viewIndentationGuideCheckBox.isChecked()
        doview_stuff_update = doview_stuff_update or utils.profile_get_int(
            globalkeys.TEXT_EDITOR_VIEWINDENTATIONGUIDES_KEY, False) != view_indentationguide
        utils.profile_set(
            globalkeys.TEXT_EDITOR_VIEWINDENTATIONGUIDES_KEY, view_indentationguide)

        view_rightedge_checked = self.viewRightEdgeCheckBox.isChecked()
        doview_stuff_update = doview_stuff_update or utils.profile_get_int(
            globalkeys.TEXT_VIEW_RIGHTEDGE_KEY, False) != view_rightedge_checked
        utils.profile_set(globalkeys.TEXT_VIEW_RIGHTEDGE_KEY,
                          view_rightedge_checked)

        view_linenumbers_checked = self.viewLineNumbersCheckBox.isChecked()
        doview_stuff_update = doview_stuff_update or utils.profile_get_int(
            globalkeys.TEXT_VIEW_LINENUMBERS_KEY, True) != view_linenumbers_checked
        utils.profile_set(globalkeys.TEXT_VIEW_LINENUMBERS_KEY,
                          view_linenumbers_checked)

        highlight_caretline = self.highlightCaretLineCheckBox.isChecked()
        doview_stuff_update = doview_stuff_update or utils.profile_get_int(
            globalkeys.TEXT_HIGHLIGHT_CARETLINE_KEY, True) != highlight_caretline
        utils.profile_set(
            globalkeys.TEXT_HIGHLIGHT_CARETLINE_KEY, highlight_caretline)

        highlight_parentheses = self.highlightParenthesesCheckBox.isChecked()
        doview_stuff_update = doview_stuff_update or utils.profile_get_int(
            globalkeys.TEXT_HIGHLIGHT_PARENTHESES_KEY, True) != highlight_parentheses
        utils.profile_set(
            globalkeys.TEXT_HIGHLIGHT_PARENTHESES_KEY, highlight_parentheses)

        if view_rightedge_checked:
            edge_val = self.edge_spin_ctrl.value()
            doview_stuff_update = doview_stuff_update or utils.profile_get_int(
                globalkeys.TEXT_EDGE_WIDTH_KEY, constants.DEFAULT_EDGE_GUIDE_WIDTH) != edge_val
            utils.profile_set(globalkeys.TEXT_EDGE_WIDTH_KEY, edge_val)
        view_codefold = self.view_codefold_CheckBox.isChecked()
        doview_stuff_update = doview_stuff_update or utils.profile_get_int(
            globalkeys.CODE_EDITOR_VIEWFOLD_KEY, True) != view_codefold
        utils.profile_set(globalkeys.CODE_EDITOR_VIEWFOLD_KEY, view_codefold)

        usetabs = not self.usetabs_checkbox.isChecked()
        doview_stuff_update = doview_stuff_update or utils.profile_get_int(
            globalkeys.TEXT_INDENTATION_USETABS_KEY, False) != usetabs
        utils.profile_set(globalkeys.TEXT_INDENTATION_USETABS_KEY, usetabs)
        if usetabs:
            oldtabswidth = utils.profile_get_int(
                'TextEditorTabsWidth', constants.DEFAULT_TAB_WIDTH)
            newtabswidth = self.tabswidth_spin_ctrl.value()
            if newtabswidth != oldtabswidth:
                doview_stuff_update = True
                utils.profile_set('TextEditorTabsWidth', newtabswidth)
        else:
            new_indent_width = self.indentWidthChoice.value()
            old_indent_width = utils.profile_get_int(
                globalkeys.TEXT_EDITOR_INDENT_WIDTH_KEY, constants.DEFAULT_TAB_INDENTATION_WIDTH)
            if new_indent_width != old_indent_width:
                doview_stuff_update = True
                utils.profile_set(
                    globalkeys.TEXT_EDITOR_INDENT_WIDTH_KEY, new_indent_width)
        if doview_stuff_update:
            get_app().MainFrame.GetNotebook().update_editor_appearance()
        utils.profile_set(globalkeys.CHECK_CODE_EDITOR_TABS_KEY,
                          self.chktab_box.isChecked())
        utils.profile_set(globalkeys.CODE_EDITOR_AUTOINDENT_KEY,
                          self.autoindent_box.isChecked())
        return True

    def GetIcon(self):
        return getTextIcon()
