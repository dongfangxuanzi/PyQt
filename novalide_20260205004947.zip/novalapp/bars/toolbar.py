# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        toolbar.py
Purpose:

Author:      wukan

Created:     2019-01-16
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
from typing import NamedTuple, Any
from ..lib.pyqt import QToolBar, QAction, QComboBox, QLabel, Qt


class ToolbarItem(NamedTuple):
    id: int
    action: QAction
    tester: Any


class ToolBar(QToolBar):
    def __init__(self, parent=None, orient=Qt.Horizontal):
        super().__init__(parent)
        self.setOrientation(orient)
        self._commands = []

    def AddButton(self, command_id, action, add_separator=False, tester=None, pos=-1):
        if pos == -1:
            self.addAction(action)
        if add_separator:
            self.AddSeparator()
        self.SetWidgetPos(command_id, action, pos, tester)
        shortcut = action.shortcut().toString()
        if shortcut:
            tooltip = action.toolTip()
            tooltip += " (" + shortcut + ")"
            action.setToolTip(tooltip)

    def Update(self):
        for item in self._commands:
            tester = item.tester
            if item.id == -1:
                continue
            if tester and not tester():
                item.action.setEnabled(False)
            else:
                item.action.setEnabled(True)

    def AddCombox(self, combo=None, editable=False, pos=-1):
        if combo is None:
            combo = QComboBox()
        combo.setEditable(editable)
        if pos == -1:
            self.addWidget(combo)
        else:
            action = self._commands[pos].action
            self.insertWidget(action, combo)
        return combo

    def AddLabel(self, text, pos=-1):
        label = QLabel(text)
        if pos == -1:
            self.addWidget(label)
        else:
            action = self._commands[pos].action
            self.insertWidget(action, label)
        return label

    def SetWidgetPos(self, command_id, action, pos, tester=None):
        '''
            pos为-1表示在最后添加控件,不为-1表示在某个位置插入控件
        '''
        update_layout = False
        if pos == -1:
            self._commands.append(ToolbarItem(command_id, action, tester))
        # 这里要插入控件,插入控件后需要重新排列控件
        else:
            update_layout = True
            self._commands.insert(pos, ToolbarItem(command_id, action, tester))

        if update_layout:
            # 重新调整控件的位置
            self.UpdateLayout(pos)

    def UpdateLayout(self, pos):
        before_action = self._commands[pos - 1].action
        self.insertAction(before_action, self._commands[pos].action)

    def AddSeparator(self):
        action = self.addSeparator()
        self._commands.append(ToolbarItem(-1, action, None))

    def EnableTool(self, button_id, enable=True):
        for command_button in self._commands:
            if command_button.id == button_id:
                button = command_button.action
                if enable:
                    button.setEnabled(True)
                else:
                    button.setEnabled(False)
