from enum import Enum


class AppStyle(Enum):
    # qt5程序美化后的样式
    DEFAULT_APP_STYLE = "fusion"
    # windows系统qt5程序原生样式
    WINDOWS_QT_NATIVE_APP_STYLE = "windowsvista"
    # windows系统原生样式
    WINDOWS_NATIVE = "Windows"


class AppSkin(Enum):
    '''只有在app style为fusion时才能使用皮肤'''
    # 默认皮肤样式(Windows)
    DEFAULT_APP_SKIN = "default"
    # 蓝黑色皮肤
    OLD_FASHION_GREENBLACK_SKIN = "Old fashion green-black"
    # 淡青色皮肤
    OLD_FASHION_LIGHT_SKIN = "Old fashion light"


class MenuItemPosition(Enum):
    INSERT_BEFORE = 1
    INSERT_AFTER = 2


class InterpreterUpdateInterval(Enum):
    UPDATE_ONCE_STARTUP = 0
    UPDATE_ONCE_DAY = 1
    UPDATE_ONCE_WEEK = 2
    UPDATE_ONCE_MONTH = 3
    NEVER_UPDATE_ONCE = 4
