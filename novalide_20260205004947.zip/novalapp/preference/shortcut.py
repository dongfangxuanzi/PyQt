'''
Name:        shortcut.py
Purpose:     菜单快捷键绑定处理

Author:      wukan

Created:     2026-01-30
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import json
import os
from ..util import utils, ui_utils, strutils
from ..keybinds import DEFAULT_KEY_BINDS
from .. import menuitems
from .. import _, get_app
from ..lib.limits import MAX_MRU_FILE_LIMIT
from ..bars.menubar import KeyBinder
from ..lib.pyqt import (
    QLabel,
    QComboBox,
    Qt,
    QListWidget,
    QPushButton,
    QHBoxLayout,
    QVBoxLayout,
    QSizePolicy,
    QMessageBox
)
from ..util.exceptions import ShortcutConflictedError

KEYS = ['', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
        'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '+', '/', ',',
        '.', '[', ']', '{', '}', '>', '<', ':', '|', 'Left', 'Right', 'Down',
        'Up', 'Home', 'End', 'Enter', 'Tab', 'Space', '"', "'"]
KEYS.extend(["F" + str(x) for x in range(1, 13)])  # Add function keys

if utils.is_windows():
    KEYS.remove('Tab')

MODIFIERS = ['', 'Alt', 'Shift', 'Ctrl']
MODIFIERS2 = MODIFIERS[0:-1]
MODIFIERS.sort()
MODIFIERS2.sort()

# 快捷键不允许改变(已约定俗称)的菜单id列表
DISABLE_CHANGED_MENU_ITEM_IDS = [
    menuitems.ID_PASTE,
    menuitems.ID_COPY,
    menuitems.ID_UNDO,
    menuitems.ID_REDO,
    menuitems.ID_SELECTALL,
    menuitems.ID_FIND,
    menuitems.ID_CUT
]


class KeybindOptionPanel(ui_utils.BaseConfigurationPanel):
    """description of class"""

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.layout.addWidget(QLabel(_("Menu") + ":"))
        menubar = get_app().Menubar
        menus = menubar.children()
        values = []
        self.menus = {}
        for menu in menus[1:]:
            self.scan_menu(menu, values)
        self.menu_combo = QComboBox()
        self.menu_combo.addItems(values)
        self.menu_combo.currentIndexChanged.connect(self.select_menu)
        self.layout.addWidget(self.menu_combo)
        # 在操作Combox时会使listbox选中项消失
        hbox = QHBoxLayout()
        self.menu_listbox = QListWidget()
        hbox.addWidget(self.menu_listbox)
        self.menu_listbox.itemClicked.connect(self.select_menuitem)

        rightbox = QVBoxLayout()
        rightbox.addWidget(QLabel(_("Modifier 1") + ":"))
        self.modifier1_combo = QComboBox()
        self.modifier1_combo.addItems(MODIFIERS)
        rightbox.addWidget(self.modifier1_combo)

        rightbox.addWidget(QLabel(_("Modifier 2") + ":"))
        self.modifier2_combo = QComboBox()
        self.modifier2_combo.addItems(MODIFIERS2)
        rightbox.addWidget(self.modifier2_combo)

        rightbox.addWidget(QLabel(_("Key") + ":"))

        self.key_combo = QComboBox()
        self.key_combo.addItems(KEYS)
        rightbox.addWidget(self.key_combo)
        rightbox.addWidget(QLabel(_("Binding") + ":"))
        rightbox.setAlignment(Qt.AlignTop)

        self.binding = QLabel()
        rightbox.addWidget(self.binding)
        hbox.addLayout(rightbox)
        self.layout.addLayout(hbox)

        button_hbox = QHBoxLayout()
        button_hbox.setAlignment(Qt.AlignLeft)
        self.restore_button = QPushButton(_("Restore Default"))
        self.restore_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        self.restore_button.clicked.connect(self.RestoreDefault)
        button_hbox.addWidget(self.restore_button)

        button_hbox.addStretch(1)
        self.apply_button = QPushButton(_("Apply"))
        self.apply_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.apply_button.clicked.connect(self.Apply)
        button_hbox.addWidget(self.apply_button)
        self.layout.addLayout(button_hbox)

        reopen_label = QLabel(_("NB! Restart NovalIDE after change keybinding options!"))
        reopen_label.setStyleSheet("font-weight:bold;")
        self.layout.addWidget(reopen_label)

        self.menu_combo.setCurrentIndex(0)
        self.UpdateMenu(0)

    def RestoreDefault(self):
        is_default_settings = True
        for key, shortcut in KeyBinder.key_binds.items():
            if key not in DEFAULT_KEY_BINDS:
                is_default_settings = False
                break
            else:
                if shortcut != DEFAULT_KEY_BINDS[key]:
                    is_default_settings = False
                    break
        if not is_default_settings:
            KeyBinder.LoadDefaults()
            current_list_item = self.menu_listbox.currentItem()
            if current_list_item is not None:
                self.select_menuitem(current_list_item)
            self.NotifyConfigurationChanged()

    def Apply(self):
        current_item = self.menu_listbox.currentItem()
        if current_item is None:
            return
        menu_item = current_item.data(Qt.UserRole)
        accelerator = ''
        current_key = self.key_combo.currentText()
        modifier1 = self.modifier1_combo.currentText()
        modifier2 = self.modifier2_combo.currentText()
        if not strutils.is_none_empty(current_key) and (
            strutils.is_none_empty(modifier1) and strutils.is_none_empty(modifier2)
        ):
            accelerator = current_key
        elif not strutils.is_none_empty(modifier1) and (
            strutils.is_none_empty(modifier2) and not strutils.is_none_empty(current_key)
        ):
            accelerator = modifier1 + "+" + current_key
        elif not strutils.is_none_empty(modifier1) and (
            not strutils.is_none_empty(modifier2) and not strutils.is_none_empty(current_key)
        ):
            accelerator = modifier1 + "+" + modifier2 + "+" + current_key
        else:
            QMessageBox.critical(
                self,
                _("Error"),
                _("Invalid key binding")
            )
            return
        if KeyBinder.key_binds.get(menu_item.id, '') != accelerator:
            try:
                self.CheckMenusKeybindsConflict(menu_item.id, accelerator)
                KeyBinder.key_binds[menu_item.id] = accelerator
                self.NotifyConfigurationChanged()
            except ShortcutConflictedError as ex:
                QMessageBox.critical(
                    self,
                    _("Shortcut Conflict"),
                    str(ex)
                )

    def SaveKeybindings(self):
        keybinds_setting_path = os.path.join(utils.get_cache_path(), KeyBinder.KEY_BINDS_FILE)
        with open(keybinds_setting_path, "w") as f:
            keybind_settings = {}
            menuitem_ids = dir(menuitems)
            item_id_names = {}
            for item_id_name in menuitem_ids:
                id_value = KeyBinder.get_menu_id_value(item_id_name)
                if isinstance(id_value, int) and item_id_name.startswith('ID_'):
                    item_id_names[id_value] = item_id_name
            for menu_id, shortcut in KeyBinder.key_binds.items():
                assert isinstance(menu_id, int)
                keybind_settings[item_id_names[menu_id]] = shortcut
            json.dump(keybind_settings, f)

    def CheckMenusKeybindsConflict(self, mid, accelerator):
        '''
        检查快捷键冲突
        '''
        for keyid, shortcut in KeyBinder.key_binds.items():
            if accelerator == shortcut:
                utils.get_logger().error(
                    "menu id `%s` conflicted with accelerator `%s` of menu id `%s`",
                    KeyBinder.find_menu_id(mid),
                    accelerator,
                    KeyBinder.find_menu_id(keyid)
                )
                raise ShortcutConflictedError(_("Accelerator `%s` is conflicted...") % accelerator)

    def scan_menu(self, menu, values):
        index = len(values)
        menu_title = menu.title()
        if strutils.is_none_empty(menu_title):
            return
        values.append(menu_title)
        self.menus[index] = menu

    def select_menu(self):
        index = self.menu_combo.currentIndex()
        if index == -1:
            self.update_buttons()
            return
        self.UpdateMenu(index)

    def UpdateMenu(self, index):
        self.ClearKeys()
        self.menu_listbox.clear()
        file_history = get_app().GetDocumentManager().GetFileHistory()
        id_base = file_history.IdBase
        menu = self.menus[index]
        self.add_menu_item(menu, id_base)
        self.update_buttons()

    def add_menu_item(self, menu, id_base, parent_menu=None):
        item_count = menu.GetItemCount()
        for i in range(item_count):
            item = menu.GetItemByIndex(i)
            submenu = menu.GetMenu(item.id)
            if item.id == -1 or (id_base <= item.id <= id_base + MAX_MRU_FILE_LIMIT):
                continue
            elif submenu is not None:
                self.add_menu_item(submenu, id_base, submenu)
                continue
            itemcount = self.menu_listbox.count()
            if parent_menu is None:
                self.menu_listbox.addItem(item.action.text())
            else:
                self.menu_listbox.addItem(
                    parent_menu.title() + "/" + item.action.text()
                )
            menuitem = self.menu_listbox.item(itemcount)
            menuitem.setData(Qt.UserRole, item)

    def select_menuitem(self, item):
        self.update_buttons()
        self.update_menuitem(item)

    def update_menuitem(self, item):
        menu_item = item.data(Qt.UserRole)
        accelerator = KeyBinder.key_binds.get(menu_item.id, '')
        if strutils.is_none_empty(accelerator):
            self.ClearKeys()
        else:
            keys = accelerator.split("+")
            key_count = len(keys)
            if key_count == 1:
                self.modifier1_combo.setCurrentText("")
                self.modifier2_combo.setCurrentText("")
                self.key_combo.setCurrentText(keys[0])
            elif key_count == 2:
                self.modifier2_combo.setCurrentText("")
                self.modifier1_combo.setCurrentText(keys[0])
                self.key_combo.setCurrentText(keys[1])
            elif key_count == 3:
                self.modifier1_combo.setCurrentText(keys[0])
                self.modifier2_combo.setCurrentText(keys[1])
                self.key_combo.setCurrentText(keys[2])
            self.binding.setText(accelerator)
        self.set_menuid_change_states(menu_item.id)

    def set_menuid_change_states(self, menu_item_id):
        if menu_item_id in DISABLE_CHANGED_MENU_ITEM_IDS:
            self.modifier1_combo.setEnabled(False)
            self.modifier2_combo.setEnabled(False)
            self.key_combo.setEnabled(False)
        else:
            self.modifier1_combo.setEnabled(True)
            self.modifier2_combo.setEnabled(True)
            self.key_combo.setEnabled(True)

    def ClearKeys(self):
        self.modifier1_combo.setCurrentText("")
        self.modifier2_combo.setCurrentText("")
        self.key_combo.setCurrentText("")
        self.binding.setText('')

    def update_buttons(self):
        if self.menu_listbox.currentRow() == -1:
            self.apply_button.setEnabled(False)
        else:
            self.apply_button.setEnabled(True)

    def OnOK(self, options_dialog):
        try:
            if self._configuration_changed:
                self.SaveKeybindings()
        except Exception as e:
            utils.get_logger().exception('save keybind settings fail:')
            QMessageBox.critical(
                self,
                _("Error"),
                _("Save keybinding settings fail:%s") % str(e)
            )
            return False
        return True

    def OnCancel(self, options_dialog):
        if self._configuration_changed:
            ret = QMessageBox.question(
                self,
                _("Save keybinding"),
                _("Keybinding settings has already been modified, Do you want to save?")
            )
            if ret == QMessageBox.Yes:
                self.OnOK(options_dialog)
        return True
