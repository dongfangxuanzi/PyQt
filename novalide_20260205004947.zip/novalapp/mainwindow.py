# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""Codimension main window"""


# cml 1 gb id=0 title="System imports"
from . import get_app, _, newid
from .lib.pyqt import (Qt, QSize, pyqtSignal, QWidget,
                       QVBoxLayout, QSplitter, QSizePolicy,
                       QMainWindow, QTabBar,
                       QDialog)
from .bars.menubar import MenubarMixin, find_menu
from . import menuitems
from .plugin import plugin, plugin_joint
from . import constants
from .bars.toolbar import ToolBar
from .bars.statusbar import StatusBarMixin
from . import globalkeys
from .util import utils, ui_utils
from .sidebar.sidebar import SideBar
from .lib.images import empty_icon
from .editor.notebook import EditorNotebook
from .editor.textview import TextView
from .project import document as projectdocument


class EditorsManagerWidget(QWidget):
    """Tab widget which has tabs with editors and viewers"""

    def __init__(self, parent):
        super().__init__(parent)
        self.editorsManager = EditorNotebook(parent)
        self.editorsManager.setSizePolicy(QSizePolicy.Preferred,
                                          QSizePolicy.Expanding)
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(1, 1, 1, 1)
        self.layout.addWidget(self.editorsManager)
        self.setLayout(self.layout)


class IDEMainWindow(QMainWindow, MenubarMixin, StatusBarMixin):
    """Main application window"""
    # 弹出项目属性对话框的时候发送的信号
    SIG_SHOW_PROPERTY_DIALOG = pyqtSignal(QDialog, str)
    # 工具栏重新加载程序调试器的信号
    SIG_DEBUG_COMBO_RELOAD = pyqtSignal()
    # 界面主题更改信号
    UI_WINDOW_THEME_CHANGED = pyqtSignal()

    def __init__(self, splash):
        QMainWindow.__init__(self)
        get_app().frame = self
        self.__initialisation = True
        self._checking_external_changes = False
        self.reset_filechanged_answer = True
        StatusBarMixin.__init__(self)
        MenubarMixin.__init__(self)

        self._last_perspective = {}
        self._views = {}
        self.LoadLastperspective()
        # This prevents context menu on the main window toolbar.
        # I don't really know why but it is what I need
        self.setContextMenuPolicy(Qt.NoContextMenu)

        # The size restore is done twice to avoid huge flickering
        # This one is approximate, the one in restoreWindowPosition()
        # is precise
        screen_size = get_app().desktop().screenGeometry()
        # 启动时是否强制使窗口最大化
        force_maximize_window = utils.profile_get_int(
            globalkeys.MAXIMIZE_WINDOW_KEY, False)
        # 如果上次窗口最大化,此次继续让窗口最大化
        if utils.profile_get_int(globalkeys.FRAME_MAXIMIZED_KEY, True) or force_maximize_window:
            # 窗口最大化
            self.resize(screen_size.width(), screen_size.height())
        else:
            # 恢复上次窗口的坐标位置和大小
            ypos = utils.profile_get_int(globalkeys.FRAME_TOP_LOC_KEY, 0)
            xpos = utils.profile_get_int(globalkeys.FRAME_LEFT_LOC_KEY, 0)
            width = utils.profile_get_int(
                globalkeys.FRAME_WIDTH_KEY, screen_size.width())
            height = utils.profile_get_int(
                globalkeys.FRAME_HEIGHT_KEY, screen_size.height())
            utils.get_logger().debug(
                "load last windows geometry is x:%d,y:%d,width:%d,height:%d",
                xpos,
                ypos,
                width,
                height
            )
            self.resize(width, height)
            self.move(xpos, ypos)
        get_app().show_splash_message(_("Creating toolbar..."))
        self.__create_toolbar()

        self._left_sidebar = None
        self._bottom_sidebar = None
        self._right_sidebar = None

        self.__horizontal_splitter = None
        self.__vertical_splitter = None
        get_app().show_splash_message(_("Initializing main menu bar..."))
        # 初始化应用程序主菜单
        self._init_main_menu()
        get_app().show_splash_message(_("Creating layout..."))
        # 创建代码编辑器区域
        self.__create_layout()
        self.update_window_title()

        # 是否显示工具栏
        show = utils.profile_get_int(globalkeys.TOOLBAR_VISIBLE_KEY, True)
        self._toolbar.setVisible(show)

    @property
    def projectview(self):
        return self.GetView(constants.PROJECT_VIEW_NAME)

    @property
    def outlineview(self):
        return self.GetView(constants.OUTLINE_VIEW_NAME)

    @property
    def resultsview(self):
        return self.GetView(constants.SEARCH_RESULTS_VIEW_NAME)

    @property
    def right_sidebar(self):
        return self._right_sidebar

    def init_commands(self):
        views_menu = find_menu(_("&View"), self.menuBar())
        item = get_app().AddCommand(
            menuitems.ID_VIEW_TOOLBAR,
            views_menu,
            command_label=_("&Toolbar"),
            handler=self.on_view_toolbar,
            kind=constants.CHECK_MENU_ITEM_KIND
        )
        item.action.setChecked(utils.profile_get_int(
            globalkeys.TOOLBAR_VISIBLE_KEY, True))
        item = get_app().AddCommand(
            menuitems.ID_VIEW_STATUSBAR,
            views_menu,
            command_label=_("&Statusbar"),
            handler=self.on_view_statusbar,
            kind=constants.CHECK_MENU_ITEM_KIND
        )
        item.action.setChecked(utils.profile_get_int(
            globalkeys.STATUS_VISIBLE_KEY, True))
        edits_menu = find_menu(_("&Edit"), self.menuBar())
        get_app().AddDefaultCommand(
            menuitems.ID_UNDO,
            edits_menu,
            _("&Undo"),
            handler=lambda: self.edit_command_handler(menuitems.ID_UNDO),
            image="toolbar/undo.png",
            include_in_toolbar=True
        )
        get_app().AddDefaultCommand(
            menuitems.ID_REDO,
            edits_menu,
            _("&Redo"),
            handler=lambda: self.edit_command_handler(menuitems.ID_REDO),
            image="toolbar/redo.png",
            include_in_toolbar=True,
            add_separator=True
        )
        get_app().AddDefaultCommand(
            menuitems.ID_CUT,
            edits_menu,
            _("&Cut"),
            handler=lambda: self.edit_command_handler(menuitems.ID_CUT),
            image="toolbar/cut.png",
            include_in_toolbar=True
        )
        get_app().AddDefaultCommand(
            menuitems.ID_COPY,
            edits_menu,
            _("&Copy"),
            handler=lambda: self.edit_command_handler(menuitems.ID_COPY),
            image="toolbar/copy.png",
            include_in_toolbar=True
        )
        get_app().AddDefaultCommand(
            menuitems.ID_PASTE,
            edits_menu,
            _("&Paste"),
            handler=lambda: self.edit_command_handler(menuitems.ID_PASTE),
            image="toolbar/paste.png",
            include_in_toolbar=True
        )
        self.GetToolBar().AddSeparator()
        get_app().AddDefaultCommand(
            menuitems.ID_CLEAR,
            edits_menu, _("&Delete"),
            handler=lambda: self.edit_command_handler(menuitems.ID_CLEAR),
            image="delete.png"
        )
        get_app().AddDefaultCommand(
            menuitems.ID_SELECTALL,
            edits_menu,
            _("Select A&ll"),
            handler=lambda: self.edit_command_handler(menuitems.ID_SELECTALL),
            add_separator=True
        )
        self.GetNotebook().init_commands()

    def AddToolbarButton(self, command_id, action, add_separator=False, tester=None):
        self._toolbar.AddButton(command_id, action, add_separator, tester)

    def restoreWindowPosition(self):
        """Makes sure that the window frame delta is proper"""
        screensize = GlobalData().application.desktop().screenGeometry()
        if screensize.width() != self.settings['screenwidth'] or \
           screensize.height() != self.settings['screenheight']:
            # The screen resolution has been changed, save the new values
            self.settings['screenwidth'] = screensize.width()
            self.settings['screenheight'] = screensize.height()
            self.settings['xdelta'] = self.settings['xpos'] - self.x()
            self.settings['ydelta'] = self.settings['ypos'] - self.y()
            self.settings['xpos'] = self.x()
            self.settings['ypos'] = self.y()
        else:
            # Screen resolution is the same as before
            if self.settings['xpos'] != self.x() or \
               self.settings['ypos'] != self.y():
                # The saved delta is incorrect, update it
                self.settings['xdelta'] = self.settings['xpos'] - self.x() + \
                    self.settings['xdelta']
                self.settings['ydelta'] = self.settings['ypos'] - self.y() + \
                    self.settings['ydelta']
                self.settings['xpos'] = self.x()
                self.settings['ypos'] = self.y()
        self.__initialisation = False

    def LoadLastperspective(self):
        if utils.profile_get_int(globalkeys.LOAD_LAST_PERSPECTIVE_KEY, True):
            self._last_perspective = utils.profile_get(
                globalkeys.LAST_PERSPECTIVE_KEY, value={})
            utils.get_logger().debug("last perspective is %s", self._last_perspective)

    def is_location_visible(self, location):
        for viewinfo in self._views.values():
            if viewinfo['location'] == location:
                return True
        return False

    def get_splitter_width(self, location):
        for view_name in self._last_perspective:
            position = self._last_perspective[view_name].get('position', {})
            if not position:
                continue
            if position['location'] == location and self._last_perspective[view_name]['active']:
                return position['width']
        if self.is_location_visible(location):
            return get_app().get_default_hsplitter_width()
        return 0

    def get_splitter_height(self, location):
        for view_name in self._last_perspective:
            position = self._last_perspective[view_name].get('position', {})
            if not position:
                continue
            if position['location'] == location and self._last_perspective[view_name]['active']:
                return position['height']
        if self.is_location_visible(location):
            return get_app().get_default_vsplitter_height()
        return 0

    def LoadPerspective(self, is_fullscreen=False):
        active_views = []
        if self.is_sidebar_minimized(SideBar.West, active_views):
            # 全屏时左边栏被隐藏了,需要先显示出来
            if is_fullscreen:
                self._left_sidebar.show()
            self._left_sidebar.shrink()
        if self.is_sidebar_minimized(SideBar.South, active_views):
            # 全屏时底边栏被隐藏了,需要先显示出来
            if is_fullscreen:
                self._bottom_sidebar.show()
            self._bottom_sidebar.shrink()
        if self.is_sidebar_minimized(SideBar.East, active_views):
            # 全屏时右边栏被隐藏了,需要先显示出来
            if is_fullscreen:
                self._right_sidebar.show()
            self._right_sidebar.shrink()

        utils.get_logger().debug('active views :%s', active_views)
        for viewname in active_views:
            self.activateTab(viewname)

    def load_fullscreen_perspective(self):
        self.LoadPerspective(True)
        self.show_statusbar(
            self._last_perspective[globalkeys.STATUS_VISIBLE_KEY]['visible'])
        self.show_toolbar(
            self._last_perspective[globalkeys.TOOLBAR_VISIBLE_KEY]['visible'])

    def show_menubar(self, show=True):
        self.show_docked_bar(self.menuBar(), show)

    def show_statusbar(self, show=True):
        self.show_docked_bar(self.GetStatusBar(), show)

    def show_toolbar(self, show=True):
        self.show_docked_bar(self.GetToolBar(), show)

    def show_docked_bar(self, bar, visible=True):
        if visible:
            if not bar.isVisible():
                bar.show()
        else:
            if bar.isVisible():
                bar.hide()

    def is_sidebar_minimized(self, location, activeviews):
        is_visible = False
        is_minimized = True
        for viewname in self._last_perspective:
            viewinfo = self._last_perspective[viewname]
            position = viewinfo.get('position', {})
            if not position:
                continue
            if position['location'] == location:
                is_visible = True
                if viewinfo['active']:
                    activeviews.append(viewname)
                    is_minimized = False
                    break
        if not self._last_perspective:
            for view_name, view_info in self._views.items():
                if view_info['location'] == location:
                    is_visible = True
                    if view_info['active']:
                        activeviews.append(view_name)
                        is_minimized = False
                        break

        if not is_visible:
            is_minimized = False
        return is_minimized

    def get_notebook_height(self, screen_height, south_height):
        toolbar_height = constants.TOOLBAR_ICON_HEIGHT
        statusbar_height = self.GetStatusBar().height()
        notebook_height = screen_height - south_height - \
            toolbar_height * 2 - statusbar_height
        utils.get_logger().debug(
            'screen height:%d,south height:%d, toolbar height is %d, statusbar is %d, notebook height:%d',
            screen_height,
            south_height,
            toolbar_height,
            statusbar_height,
            notebook_height
        )
        return notebook_height

    def restoreSplitterSizes(self):
        """Restore the side bar state"""
        west_width = self.get_splitter_width(SideBar.West)
        east_width = self.get_splitter_width(SideBar.East)

        screensize = get_app().desktop().screenGeometry()
        notebook_width = screensize.width() - east_width - west_width
        utils.get_logger().debug(
            'screen width:%d,east width:%d, west width:%d,notebook width:%d',
            screensize.width(),
            east_width,
            west_width,
            notebook_width
        )
        hsplitter_sizes = [west_width, notebook_width, east_width]
        self.__horizontal_splitter.setSizes(hsplitter_sizes)
        self.__horizontal_splitter_sizes = hsplitter_sizes

        south_height = self.get_splitter_height(SideBar.South)
        notebook_height = self.get_notebook_height(
            screensize.height(), south_height)
        if notebook_height < 0:
            error_notebook_height = notebook_height
            notebook_height = self.get_notebook_height(
                screensize.height(),
                get_app().get_default_vsplitter_height()
            )
            utils.get_logger().error(
                "notebook height %s is invalid, redirect to valid height %d",
                error_notebook_height,
                notebook_height
            )
        vsplitter_sizes = [notebook_height, south_height]
        self.__vertical_splitter_sizes = vsplitter_sizes
        self.__vertical_splitter.setSizes(vsplitter_sizes)
        self.LoadPerspective()
        # Setup splitters movement handlers
        self.__vertical_splitter.splitterMoved.connect(self.vSplitterMoved)
        self.__horizontal_splitter.splitterMoved.connect(self.hSplitterMoved)

    def vSplitterMoved(self, pos, index):
        """Vertical splitter moved handler"""
        del pos     # unused argument
        del index   # unused argument

        newsizes = list(self.__vertical_splitter.sizes())

        if not self._bottom_sidebar.isMinimized():
            self.__vertical_splitter_sizes[0] = newsizes[0]

        self.__vertical_splitter_sizes[1] = sum(newsizes) - \
            self.__vertical_splitter_sizes[0]

    def hSplitterMoved(self, pos, index):
        """Horizontal splitter moved handler"""
        del pos     # unused argument
        del index   # unused argument

        new_sizes = list(self.__horizontal_splitter.sizes())

        if not self._left_sidebar.isMinimized():
            self.__horizontal_splitter_sizes[0] = new_sizes[0]
        if not self._right_sidebar.isMinimized():
            self.__horizontal_splitter_sizes[2] = new_sizes[2]

        self.__horizontal_splitter_sizes[1] = sum(new_sizes) - \
            self.__horizontal_splitter_sizes[0] - \
            self.__horizontal_splitter_sizes[2]

    def GetToolBar(self):
        return self._toolbar

    def GetStatusBar(self):
        return self._statusbar

    def update_window_title(self):
        """Updates the main window title with the current so file"""
        self.setWindowTitle(get_app().GetAppName())

    def save_layout(self):
        utils.profile_set(globalkeys.TOOLBAR_VISIBLE_KEY,
                          self._toolbar.isVisible())
        utils.profile_set(globalkeys.STATUS_VISIBLE_KEY,
                          self._statusbar.isVisible())
        self.SavePerspective()
        utils.profile_set(globalkeys.LAST_PERSPECTIVE_KEY,
                          self._last_perspective)

    def GetViews(self):
        return self._views

    def SavePerspective(self):
        def get_location_width(location):
            if location in [SideBar.East, SideBar.West]:
                if len(self.__horizontal_splitter_sizes) == 2:
                    assert location == SideBar.West
                    return self.__horizontal_splitter_sizes[0]
                if len(self.__horizontal_splitter_sizes) == 3:
                    if location == SideBar.West:
                        return self.__horizontal_splitter_sizes[0]
                    if location == SideBar.East:
                        return self.__horizontal_splitter_sizes[2]
                    assert False
                else:
                    assert False
            return 0
        self._last_perspective.clear()
        for view_name, view_info in self._views.items():
            if 'instance' not in view_info:
                utils.get_logger().error(
                    'view %s is not valid view instance when save perspective', view_name)
                continue
            location = view_info["location"]
            sidebar = self._view_sidebars[location]
            d = {}
            if sidebar.isMinimized():
                d['active'] = False
            else:
                if sidebar.currentTabName() == view_name:
                    d['active'] = True
                else:
                    d['active'] = False
            position = {}
            position['location'] = location
            position['width'] = get_location_width(location)
            position['height'] = self.__vertical_splitter_sizes[-1]
            d["position"] = position
            self._last_perspective[view_name] = d
        self._last_perspective[globalkeys.STATUS_VISIBLE_KEY] = {
            "visible": self.GetStatusBar().isVisible()}
        self._last_perspective[globalkeys.TOOLBAR_VISIBLE_KEY] = {
            "visible": self.GetToolBar().isVisible()}

    def close_windows(self):
        # 退出程序之前保存项目配置
        for view_name in self._views:
            viewframe = self.GetView(view_name)
            utils.get_logger().info('start close sidebar window "%s"', view_name)
            if hasattr(viewframe, 'close_window') and not viewframe.close_window():
                utils.get_logger().warning('close sidebar window "%s" fail', view_name)
                return False
            utils.get_logger().info('close sidebar window "%s" success', view_name)
        # 保存此次打开的所有文档路径
        if utils.profile_get_int(globalkeys.LOAD_LAST_OPENDOCS, False):
            self.GetNotebook().save_open_documents()
        return True

    # 重写主窗口右上角X关闭按钮事件,等同于点击退出菜单
    def closeEvent(self, event):
        get_app().on_exit()
        event.ignore()

    def activateBottomTab(self, tabname):
        """Makes sure the bottom bar is visible and activates the required tab"""
        if self._bottom_sidebar.height() == 0:
            # It was hidden completely, so need to move the slider
            splitterSizes = self.settings['vSplitterSizes']
            splitterSizes[0] -= 200
            splitterSizes[1] += 200
            self.__vertical_splitter.setSizes(splitterSizes)

        self._bottom_sidebar.show()
        self._bottom_sidebar.setCurrentTab(tabname)
        self._bottom_sidebar.raise_()

    def activateProjectTab(self):
        """Activates the project tab"""
        self.activateTab(constants.PROJECT_VIEW_NAME)

    def activateOutlineTab(self):
        """Activates the outline tab"""
        self.activateTab(constants.OUTLINE_VIEW_NAME)

    def activateSearchResultsTab(self):
        """Activates the outline tab"""
        self.activateTab(constants.SEARCH_RESULTS_VIEW_NAME)

    def activateTab(self, tabname):
        if not tabname in self._views:
            return
        view_info = self._views[tabname]
        location = view_info['location']
        sidebar = self._view_sidebars[location]
        sidebar.show()
        sidebar.setCurrentTab(tabname)
        sidebar.raise_()

    def is_tab_active(self, tabname):
        if not tabname in self._views:
            return False
        view_info = self._views[tabname]
        location = view_info['location']
        sidebar = self._view_sidebars[location]
        if sidebar.currentTabName() == tabname:
            return True
        return False

    def setFocusToFloatingRenderer(self):
        """Raises the window up if it is shown and passes focus"""
        if not self.__detachedRenderer.isHidden():
            self.__detachedRenderer.raise_()
            self.__detachedRenderer.activateWindow()

    def GetNotebook(self):
        return self.em

    def AddNotebookPage(self, childframe, title, filename):
        """
        Adds a document page to the notebook.
        """
        template = childframe.GetView().GetDocument().GetDocumentTemplate()
        img = template.GetIcon()
        if img is None:
            img = get_app().GetDefaultIcon()
        assert img is not None
        self.GetNotebook().addTab(childframe, img, title)
        self.GetNotebook().activateTab(self.GetNotebook().count() - 1)

    def GetNotebookPageTitle(self, childframe):
        notebook = self.GetNotebook()
        index = notebook.get_tab_index(childframe)
        return notebook.tabText(index)

    def set_notebook_page_title(self, panel, title):
        notebook = self.GetNotebook()
        index = notebook.get_tab_index(panel)
        notebook.setTabText(index, title)
        # 设置标签页提示信息
        notebook.setTabToolTip(index, panel.GetDocument().GetFilename())
        panel.GetView().SetFocus()

    def ActivateNotebookPage(self, childframe):
        index = self.GetNotebook().get_tab_index(childframe)
        self.GetNotebook().activateTab(index)
        childframe.GetView().SetFocus()

    def RemoveNotebookPage(self, childframe):
        # 需要判断文档框架是否已经在notebook中不存在了
        index = self.GetNotebook().get_tab_index(childframe)
        if index == -1:
            utils.get_logger().warn("child editor is not in notebook yet when remove it....")
            return
        self.GetNotebook().removeTab(index)

    def UpdateToolbar(self):
        if not hasattr(self, "_toolbar"):
            return
        self._toolbar.Update()

    def UpdateUI(self, command_id):
        if command_id == menuitems.ID_SAVEALL:
            return self.SaveAllEnabled()
        if command_id in [menuitems.ID_DEBUG, menuitems.ID_RUN]:
            return get_app().get_current_project() is not None
        return False

    def SaveAllEnabled(self):
        for index in range(self.GetNotebook().count()):
            widget = self.GetNotebook().widget(index)
            if widget.GetView().GetDocument().IsModified():
                return True
        return False

    @ui_utils.update_toolbar
    def CloseDoc(self):
        editor = self.GetNotebook().currentWidget()
        if editor is None:
            return
        doc = editor.GetView().GetDocument()
        doc.DeleteAllViews()

    @ui_utils.update_toolbar
    def CloseAllDocs(self):
        self.GetNotebook().closeall_doc()

    def init_plugins(self):
        # Setup Plugins after locale as they may have resource that need to be loaded.
        plgmgr = plugin.PluginManager()
        get_app().set_plugin_manager(plgmgr)

        # 加载内置插件
        common_plugin_loader = plugin_joint.CommonPluginLoader(plgmgr)
        common_plugin_loader.Load()
        # 加载用户安装插件
        main_window_addon = plugin_joint.MainWindowAddOn(plgmgr)
        main_window_addon.Init(self)

    def on_view_toolbar(self):
        """
        Toggles whether the ToolBar is visible.
        """
        self.GetToolBar().setVisible(not self._toolbar.isVisible())
        # 更新工具栏菜单按钮状态
        self.UpdateToolbar()

    def on_view_statusbar(self):
        """
        Toggles whether the StatusBar is visible.
        """
        self.GetStatusBar().setVisible(not self._statusbar.isVisible())

    @ui_utils.update_toolbar
    def edit_command_handler(self, command_id):
        current_view = get_app().GetDocumentManager().GetCurrentView()
        utils.get_logger().debug('current activate view is %s',
                                 current_view.__class__.__name__)
        if current_view is None:
            return
        current_view.ProcessEvent(command_id)

    def AddView(
        self,
        view_name,
        view_class,
        label,
        default_location,
        *,
        default_position_key=None,
        create=True,
        active=False,
        image_file=None,
        visible_in_menu=True,
        **kwargs
    ):
        """Adds item to "View" menu for showing/hiding given view.
        Args:
            view_class: Class or constructor for view. Should be callable with single
                argument (the master of the view)
            label: Label of the view tab
            location: Location descriptor. Can be "nw", "sw", "s", "se", "ne"
        Returns: None
        """
        is_actived = utils.profile_get_int(
            globalkeys.FRAME_VIEW_MINIMIZED_KEY % view_name, active)
        utils.get_logger().debug("%s is actived:%s",
                                 globalkeys.FRAME_VIEW_MINIMIZED_KEY % view_name, is_actived)
        image = None
        if image_file is not None:
            image = get_app().GetImage(image_file)
        else:
            image = empty_icon()
        if view_name in self._views:
            view = self.GetView(view_name, **kwargs)
            sidebar = view.parent().parent()
            sidebar.removeTab(view)
        self._views[view_name] = {
            "class": view_class,
            "label": label,
            "location": default_location,
            "position_key": default_position_key,
            "active": is_actived,
            'image': image
        }
        # handler

        def toggle_view_activiity():
            self.activateTab(view_name)
        views_menu = find_menu(_("&View"), self.menuBar())
        if visible_in_menu:
            views_menu.InsertAfter(
                menuitems.ID_VIEW_STATUSBAR,
                newid(),
                label,
                handler=toggle_view_activiity,
                img=image
            )
        if create:
            self.ShowView(view_name, active=is_actived, **kwargs)
        return self._views[view_name]

    def ShowView(
        self,
        view_name,
        set_focus=True,
        active=False,
        **kwargs,
    ):
        """View must be already registered.

        Args:
            view_id: View class name
            without package name (eg. 'ShellView') """
        # get or create
        view = self.GetView(view_name, **kwargs)
        sidebar = view.parent()
        sidebar.addTab(
            view,
            self._views[view_name]["image"],
            self._views[view_name]['label'],
            view_name,
            self._views[view_name]['position_key']
        )
        # switch to the tab
        if self._views[view_name]['location'] == SideBar.South:
            sidebar.tabButton(view_name, QTabBar.RightSide).resize(0, 0)
        # add focus
        if set_focus:
            view.setFocus()

        if not active:
            self._views[view_name]['active'] = False
        else:
            self._views[view_name]['active'] = True
        return view

    def GetView(self, view_name, **kwargs):
        if "instance" not in self._views[view_name]:
            view_class = self._views[view_name]["class"]
            location = self._views[view_name]["location"]
            sidebar = self._view_sidebars[location]
            # create the view
            view = view_class(
                sidebar,
                **kwargs
            )
            # 设置视图在notebook中的位置顺序,如果放置在最后则设置为None
            view.position_key = self._views[view_name]["position_key"]
            self._views[view_name]["instance"] = view
        return self._views[view_name]["instance"]

    @ui_utils.call_after
    def check_external_changes(self):
        '''
            主界面在前台显示时,检查文本是否在外部改变
        '''
        # 防止重复弹出对话框
        if self._checking_external_changes:
            return
        self._checking_external_changes = True
        open_docs = get_app().GetDocumentManager().GetDocuments()
        for doc in open_docs:
            if isinstance(doc, projectdocument.ProjectDocument):
                view = self.projectview.GetView()
                if view._is_external_changed and utils.profile_get_int(globalkeys.CHECK_PROJECT_FILE_MODIFY_KEY, True):
                    view.check_for_external_changes()
            else:
                view = doc.GetFirstView()
                if hasattr(view, "_is_external_changed"):
                    if view._is_external_changed:
                        if utils.profile_get_int(globalkeys.CHECK_FILE_MODIFY_KEY, True):
                            # 切换文档标签页
                            view.GetFrame().SetFocus()
                            view.check_for_external_changes()
                        else:
                            view._is_external_changed = False
        # 重置选项,重新弹出文本改变提示对话框
        if self.reset_filechanged_answer:
            TextView.reset_file_changed_answer()
        self._checking_external_changes = False

    def hideall(self, hide=False):
        # 真正隐藏侧边窗口
        if hide:
            self._left_sidebar.hide()
            self._bottom_sidebar.hide()
            self._right_sidebar.hide()
        else:
            # 仅仅将侧边窗口最小化
            self._left_sidebar.shrink()
            self._bottom_sidebar.shrink()
            self._right_sidebar.shrink()

    def showall(self):
        self.activateProjectTab()
        self.activateOutlineTab()
        self.activateSearchResultsTab()

    def PushStatusText(self, msg):
        self.showStatusBarMessage(msg)

    def __create_layout(self):
        """Creates the UI layout"""
        self.editors_manager_widget = EditorsManagerWidget(self)
        self.em = self.editors_manager_widget.editorsManager

        # The layout is a sidebar-style one
        self._bottom_sidebar = SideBar(SideBar.South, self)
        self._bottom_sidebar.setTabsClosable(True)
        self._left_sidebar = SideBar(SideBar.West, self)
        self._right_sidebar = SideBar(SideBar.East, self)

        self._view_sidebars = {
            SideBar.West: self._left_sidebar,
            SideBar.South: self._bottom_sidebar,
            SideBar.East: self._right_sidebar,
        }

        # Create splitters
        self.__horizontal_splitter = QSplitter(Qt.Horizontal)
        self.__vertical_splitter = QSplitter(Qt.Vertical)

        self.__horizontal_splitter.addWidget(self._left_sidebar)
        self.__horizontal_splitter.addWidget(self.editors_manager_widget)
        self.__horizontal_splitter.addWidget(self._right_sidebar)

        # This prevents changing the size of the side panels
        self.__horizontal_splitter.setCollapsible(0, False)
        self.__horizontal_splitter.setCollapsible(2, False)
        self.__horizontal_splitter.setStretchFactor(0, 0)
        self.__horizontal_splitter.setStretchFactor(1, 1)
        self.__horizontal_splitter.setStretchFactor(2, 0)

        self.__vertical_splitter.addWidget(self.__horizontal_splitter)
        self.__vertical_splitter.addWidget(self._bottom_sidebar)
        # This prevents changing the size of the side panels
        self.__vertical_splitter.setCollapsible(1, False)
        self.__vertical_splitter.setStretchFactor(0, 1)
        self.__vertical_splitter.setStretchFactor(1, 1)

        self.setCentralWidget(self.__vertical_splitter)

        self._left_sidebar.setSplitter(self.__horizontal_splitter)
        self._bottom_sidebar.setSplitter(self.__vertical_splitter)
        self._right_sidebar.setSplitter(self.__horizontal_splitter)

    def __create_toolbar(self):
        """creates the buttons bar"""
        self._toolbar = ToolBar()
        self._toolbar.setMovable(False)
        self._toolbar.setAllowedAreas(Qt.TopToolBarArea)
        self._toolbar.setIconSize(
            QSize(constants.TOOLBAR_ICON_WIDTH, constants.TOOLBAR_ICON_HEIGHT))
        self.addToolBar(self._toolbar)
