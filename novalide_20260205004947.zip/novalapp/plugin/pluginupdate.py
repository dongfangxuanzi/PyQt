import sys
import os
import functools
import shutil
from ..util import utils, transfer
from .. import _, get_app
from ..lib.pyqt import QThread, QMessageBox
from .. import globalkeys
from ..common.version import compare_common_version
from ..api.api import ApiServer


def check_pluign_update(plugin_data, parent):
    plugin_name = plugin_data['name']
    ret = QMessageBox.question(
        parent,
        _("Plugin update available"),
        _("Plugin '%s' latest version '%s' is available,do you want to download and update it?") % (
            plugin_name, plugin_data['version'])
    )
    if ret == QMessageBox.Yes:
        update_plugin(plugin_data, parent)


def update_plugin(plugin_data, parent):
    app_version = utils.get_app_version()
    plugin_name = plugin_data['name']
    # 检查更新插件要求的软件版本是否大于当前版本,如果是则提示用户是否更新软件
    if compare_common_version(plugin_data['app_version'], app_version):
        ret = QMessageBox.question(
            parent,
            get_app().GetAppName(),
            _("Plugin '%s' requires application version at least '%s',Do you want to update your application?") % (
                plugin_name, plugin_data['app_version'])
        )
        if ret == QMessageBox.No:
            return
        # 更新软件,如果用户执行更新安装,则程序会退出,不会执行下面的语句
        CheckAppUpdate()
        return
    download_url = '%s/member/download_plugin' % (ApiServer.HOST_SERVER_ADDR)
    plugin_id = plugin_data['id']
    payload = {
        "app_version": app_version,
        "lang": get_app().locale.GetLanguageCanonicalName(),
        "os_name": sys.platform,
        "plugin_id": plugin_id
    }
    # 下载插件文件
    download_callback = functools.partial(after_update_download, plugin_data)
    transfer.FiledownloadSerivce().download_file(
        download_url,
        call_back=download_callback,
        parent=parent,
        **payload
    )


def after_update_download(plugin_data, egg_path, parent):
    '''
        插件更新下载后回调函数
    '''
    dist_location = plugin_data['dist_location']
    plugin_name = plugin_data['name']
    plugin_path = os.path.dirname(dist_location)
    plugin_version = plugin_data['dist_version']
    # 删除已经存在的旧版本否则会和新版本混在一起,有可能加载的是老版本
    try:
        os.remove(dist_location)
        utils.get_logger().info("remove plugin %s old version %s file %s success",
                                plugin_name, plugin_version, dist_location)
        dest_egg_path = os.path.join(plugin_path, plugin_data['path'])
        if os.path.exists(dest_egg_path):
            logger.error("plugin %s version %s dist egg path is exist when update it",
                         plugin_name, plugin_data['version'], dest_egg_path)
            os.remove(dest_egg_path)
    except Exception as ex:
        parent.SIG_DOWNLOAD_ERROR.emit(
            _("Remove plugin file %s fail:%s") % (dist_location, str(ex)))
        return
    # 将下载的插件文件移至插件目录下
    shutil.move(egg_path, plugin_path)
    # 执行插件的安装操作,需要在插件里面执行
    get_app().GetPluginManager().LoadPluginByName(plugin_name)
    parent.SIG_DOWNLOAD_SUCCESS.emit(
        _("Update plugin '%s' success") % plugin_name)


def pull_plugin_updateinfo(plugin_datas: list, max_num: int = 3):
    update_num = 0
    api = ApiServer()
    api_addr = '%s/member/get_plugin' % (ApiServer.HOST_SERVER_ADDR)
    for plugin_class, dist in get_app().GetPluginManager().GetPluginDistros().items():
        plugin_version = dist.version
        plugin_name = dist.key
        # 调用api接口查询每个插件的信息
        plugin_data = api.request_addr(
            api_addr, method='get', arg={'name': plugin_name})
        if not plugin_data or update_num >= max_num:
            # pop_error(plugin_data)
            break
        if 'id' not in plugin_data:
            continue
        plugin_name = plugin_data['name']
        plugin_data['dist_location'] = dist.location
        plugin_data['dist_version'] = plugin_version
        utils.get_logger().info("plugin %s version is %s latest verison is %s",
                                plugin_name, plugin_version, plugin_data['version'])
        # 比较安装插件版本和服务器上的插件版本是否一致
        if compare_common_version(plugin_data['version'], plugin_version):
            plugin_datas.append(plugin_data)
            update_num += 1


def update_plugin_byid(plugin_id):
    api = ApiServer()
    data = api.request_api('plugin/%s' % plugin_id)
    if not data:
        return
    for plugin_class, dist in get_app().GetPluginManager().GetPluginDistros().items():
        plugin_version = dist.version
        plugin_name = dist.key
        if plugin_name == data['lower_name']:
            data['dist_location'] = dist.location
            data['dist_version'] = plugin_version
            break
    update_plugin(data, get_app().MainFrame.GetNotebook())


class PluginUpdate(QThread):
    def __init__(self, parent):
        super().__init__(parent)

    def run(self):
        self.check_plugins()

    def check_plugins(self):
        '''
            检查插件更新信息
        '''
        if not utils.profile_get_int(globalkeys.CHECK_PLUGIN_UPDATE_KEY, True):
            return
        plugin_datas = []
        #  插件更新太多,每次只提示一个更新即可
        pull_plugin_updateinfo(plugin_datas, max_num=1)
        if len(plugin_datas) > 0:
            if not utils.profile_get_int(globalkeys.SHOW_WELCOME_PAGE_KEY, True):
                plugin_data = plugin_datas[0]
                self.parent().sigPluginUpdateVersion.emit(plugin_data)
