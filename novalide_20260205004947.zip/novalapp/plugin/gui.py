# -*- coding: utf-8 -*-
import inspect
import enum
import shutil
import urllib.parse
import urllib.request
from urllib.parse import quote, unquote
from logging import exception
from distutils.version import LooseVersion
import webbrowser
import sys
import subprocess
import re
import os
import logging
import abc
from .. import _, get_app
from ..lib.pyqt import (
    QDialog,
    QHBoxLayout,
    Qt,
    QTextDocument,
    QCheckBox,
    QTextBrowser,
    QApplication,
    QRadioButton,
    QGroupBox,
    QPushButton,
    QThread,
    QMessageBox,
    QListWidget,
    QVBoxLayout,
    pyqtSignal,
    QFrame,
    QLabel,
    QLineEdit,
    QFileDialog,
    QSizePolicy
)
from . import plugin, iface
from ..bars.menubar import find_menu
from ..util import utils, ui_utils, fileutils, strutils, transfer, pathutils
from .. import menuitems
from ..api.api import ApiServer
from ..widgets.imagebutton import ImageButton
from ..common.version import compare_common_version
from ..plugins.update import CheckAppUpdate
from ..preference import preference
from .pluginupdate import PluginUpdate


def show_pluginmanager_dlg(parent, plugin_names=[]):
    plugin_dlg = PluginsDialog(parent)
    if plugin_names:
        plugin_dlg.ShowAvailablePlugins(plugin_names)
    plugin_dlg.exec_()


class BannerLabel(QLabel):
    def __init__(self, label):
        super().__init__(label)


class QuerypluginNum(QThread):
    def __init__(self, parent):
        super().__init__(parent)
        self.plugin_dlg = parent
        self.plugin_dlg.sig_update_info.emit(_("Fetching plugin data..."))

    def run(self):
        ok, names = self.search_plugins()
        if ok:
            self.emit_plugin_num(names)

    def emit_plugin_num(self, names):
        count = len(names)
        self.plugin_dlg.sig_update_info.emit(
            _("There is total %d plugins.") % count)

    def search_plugins(self, name=''):
        '''
            搜索插件,如果指定插件名称,则返回包含插件名称的插件,否则返回所有插件
        '''
        api = ApiServer()
        api_addr = '%s/member/get_plugins' % (ApiServer.HOST_SERVER_ADDR)
        data = api.request_addr(api_addr, method='get', arg={'name': name})
        names = []
        ok = False
        if data:
            ok = True
            names = data['names']
        else:
            self.plugin_dlg.sig_update_info.emit(_("Could not fetch plugin."))
        PluginsDialog.API_SERVER_OK = ok
        return ok, names


class QueryPlugin(QuerypluginNum):
    def __init__(self, parent, name=''):
        super().__init__(parent)
        self.name = name

    def run(self):
        self.query_plugins()

    def query_plugins(self):
        '''
            请求获取所有插件名称列表
        '''
        ok, names = self.search_plugins(self.name)
        if ok:
            if self.name:
                self.plugin_dlg.sig_update_info.emit(
                    _("find total %d plugins named '%s' on server") % (count, self.name))
            else:
                self.plugin_dlg.sig_show_names.emit(names)
                self.emit_plugin_num(names)
        return ok


class SearchPlugin(QueryPlugin):
    def __init__(self, parent, name):
        super().__init__(parent, name)

    def run(self):
        ok = self.query_plugins()
        if not ok:
            ui_utils.failed_connect_api_server()


def GetPluginInstallpath():
    # 调式模式时默认安装到应用程序目录(系统目录)
    # 正常时默认安装到用户目录
    if get_app().GetDebug():
        # 系统目录(软件安装目录)
        value = utils.get_sys_plugin_path()
    else:
        # 用户数据目录
        value = utils.get_user_plugin_path()
    plugin_install_path = utils.profile_get("PluginInstallPath", value)
    return plugin_install_path


class CommonPluginDialog(QDialog):
    sig_update_info = pyqtSignal(str)
    # api服务器是否正常运行
    API_SERVER_OK = False

    def __init__(self, master):
        self._state = "idle"  # possible values: "listing", "fetching", "idle"
        self._process = None
        super().__init__(master)
        self.setFixedSize(750, 650)
        self.frame_layout = QVBoxLayout()
        self.setLayout(self.frame_layout)
        self.setWindowTitle(self._get_title())

    def _create_common_widgets(
        self,
        box_layout,
        install_label_text,
        button_text,
        label_text,
        tip_text
    ):
        hbox = QHBoxLayout()
        self.search_box = QLineEdit()
        hbox.addWidget(self.search_box)
        # 设置占位符
        self.search_box.setPlaceholderText(tip_text)
        self.search_box.setFocus()
#        self.search_box.bind("<Return>", self._on_search, False)
        self.search_button = QPushButton(button_text)
        self.search_button.clicked.connect(self._on_search)
        hbox.addWidget(self.search_button)

        box_layout.addLayout(hbox)
        mainhbox = QHBoxLayout()
        mainhbox.setAlignment(Qt.AlignLeft)
        listbox = QVBoxLayout()
        # 显示安装包标签

        self.installled_label = QLabel(install_label_text)
        self.install_label_text = install_label_text
        listbox.addWidget(self.installled_label)
        self.listbox = QListWidget()
        listbox.addWidget(self.listbox)
        self.add_install_label_item()
        self.listbox.setFixedWidth(150)
        self.listbox.itemSelectionChanged.connect(self._on_listbox_select)
        mainhbox.addLayout(listbox)

        self.infobox = QVBoxLayout()
        # 设置内容边距,四个参数是边距顺时针,从左开始
        self.infobox.setContentsMargins(0, 15, 0, 0)

        self.name_label = QLabel("")
        self.name_label.setStyleSheet(
            "font-size:16px;font-weight:bold;font-family:Arial;")
        self.infobox.addWidget(self.name_label)

        # 用文本控件显示包详细信息,并且设置为只读
        self.info_text = QTextBrowser()
        # 不是外部链接
        self.info_text.setOpenLinks(False)
        self.info_text.setOpenExternalLinks(False)
        self.info_text.anchorClicked.connect(self.open_link_info)
        self.info_text.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.infobox.addWidget(self.info_text)
        self.buttonbox = QHBoxLayout()
        self.command_frame = QFrame()
        command_box = QHBoxLayout()
        self.command_frame.setLayout(command_box)

        self.install_button = QPushButton(_(" Upgrade "))
        self.install_button.clicked.connect(self._on_click_install)
        self.install_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        command_box.addWidget(self.install_button)

        self.uninstall_button = QPushButton(_("Uninstall"))
        self.uninstall_button.clicked.connect(
            lambda: self._perform_action("uninstall"))
        self.install_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        command_box.addWidget(self.uninstall_button)

        self.buttonbox.addLayout(command_box)
        self.buttonbox.addStretch(1)

        close_button = QPushButton(_("Close"))
        self.install_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        close_button.clicked.connect(self._cancel)
        self.buttonbox.addWidget(close_button)
        self.infobox.addLayout(self.buttonbox)
        mainhbox.addLayout(self.infobox)
        box_layout.addLayout(mainhbox)
        self._start_update_list()

    def add_install_label_item(self):
        self.listbox.addItem(" <INSTALL>")

    def open_link_info(self, link_text):
        # 对url链接解码
        url = unquote(link_text.url())
        if not self._handle_url_click(url):
            self._handle_install_file_click()

    def CreateBottomLabel(self):
        info_hbox = QHBoxLayout()
        info_hbox.setAlignment(Qt.AlignLeft)
        self.info_label = QLabel()
        info_hbox.addWidget(self.info_label)
        self.sig_update_info.connect(self.update_info_label)
        return info_hbox

    def update_info_label(self, msg):
        self.info_label.setText(msg)

    @abc.abstractmethod
    def fetch_info_data(self):
        raise NotImplementedError('You must implemented it in derived class')

    def create_advance_buttons(self):
        '''
            创建其它按钮
        '''

    def _on_click_install(self):
        self._perform_action("install")

    def _set_state(self, state, force_normal_cursor=False):
        self._state = state
        widgets = [
            self.listbox,
            # self.search_box, # looks funny when disabled
            self.search_button,
            self.install_button,
            self.uninstall_button,
        ]

        if state == "idle":
            QApplication.restoreOverrideCursor()
            for widget in widgets:
                widget.setEnabled(True)
        else:
            if force_normal_cursor:
                self.config(cursor="")
            else:
               # self.config(cursor=ui_utils.get_busy_cursor())
                QApplication.setOverrideCursor((Qt.WaitCursor))

            for widget in widgets:
                widget.setEnabled(False)

    def _get_state(self):
        return self._state

    def _handle_outdated_or_missing_pip(self, error):
        raise NotImplementedError()

    def _install_pip(self):
        self._clear()
        self.info_text.direct_insert(
            "end", _("Installing pip\n\n"), ("caption",))
        self.info_text.direct_insert(
            "end",
            _(
                "pip, a required module for managing packages is missing or too old.\n\n"
                + "Downloading pip installer (about 1.5 MB), please wait ...\n"
            ),
        )
        self.update()
        self.update_idletasks()

        installer_filename, _ = urlretrieve(PIP_INSTALLER_URL)

        self.info_text.direct_insert(
            "end", _("Installing pip, please wait ...\n"))
        self.update()
        self.update_idletasks()

        proc, _ = self._create_python_process(
            [installer_filename], stderr=subprocess.PIPE)
        out, err = proc.communicate()
        os.remove(installer_filename)

        if err != "":
            raise RuntimeError("Error while installing pip:\n" + err)

        self.info_text.direct_insert("end", out + "\n")
        self.update()
        self.update_idletasks()

        # update list
        self._start_update_list()

    def _provide_pip_install_instructions(self, error):
        self._clear()
        self.info_text.direct_insert("end", error)
        self.info_text.direct_insert(
            "end", _("You seem to have problems with pip\n\n"), ("caption",)
        )
        self.info_text.direct_insert(
            "end",
            _(
                "pip, a required module for managing packages is missing or too old for Noval.\n\n"
                + "If your system package manager doesn't provide recent pip (9.0.0 or later), "
                + "then you can install newest version by downloading "
            ),
        )
        self.info_text.direct_insert("end", PIP_INSTALLER_URL, ("url",))
        self.info_text.direct_insert(
            "end",
            _(" and running it with ")
            + self._get_interpreter().Name
            + _(" (probably needs admin privileges).\n\n"),
        )

        self.info_text.direct_insert(
            "end", self._instructions_for_command_line_install())
        self._set_state("disabled", True)

    def _instructions_for_command_line_install(self):
        return _(
            "Alternatively, if you have an older pip installed, then you can install packages "
            + "on the command line (Tools → Open terminator...)"
        )

    def _start_update_list(self, name_to_show=None, refresh=False):
        self.installled_label.setText(self.install_label_text)

    def ShowNameList(self, names):
        self.listbox.clear()
        self.add_install_label_item()
        for name in sorted(names):
            self.listbox.addItem(" " + name)

    def _update_list(self, name_to_show):
        self.ShowNameList(self._active_distributions.keys())
        if name_to_show is None:
            self._show_instructions()
        else:
            self._start_show_package_info(name_to_show)

    def _on_listbox_select(self):
        if self._get_state() == "fetching":
            return
        selection = self.listbox.currentRow()
        if selection != -1:
            if selection == 0:  # special first item
                self._show_instructions()
            else:
                self._start_show_package_info(
                    self.listbox.currentItem().text().strip())
        self.listbox.setFocus()

    def search_by_name(self, name):
        return []

    def _on_search(self, event=None):
        if self._get_state() != "idle":
            # Search box is not made inactive for busy-states
            return
        # 搜索名称为空时显示已经安装的包列表
        search_name = self.search_box.text().strip()
        if search_name == "":
            self._start_update_list()
            return
        # 模糊搜索关键字
        names = self.search_by_name(search_name)
        # 列表框显示搜索结果
        self.ShowNameList(names)
        if not names:
            self._clear()
            self.NotFoundPackage(search_name)
            return
        # 显示第一个包名
        self._start_show_package_info(names[0])

    def _clear(self):
        self.current_package_data = {}
        self.infobox.removeWidget(self.name_label)
        self.name_label.setVisible(False)
        self.buttonbox.removeWidget(self.command_frame)
        self.command_frame.setVisible(False)
        self.info_text.clear()

    def _show_instructions(self):
        '''
            显示<INSTALL>提示信息
        '''

    def start_fetching_package_info(self, name):
        '''
            从pypi服务器上查询pypi包信息
        '''
        _start_fetching_package_info(name, None, self._show_package_info)

    def _start_show_package_info(self, name):
        self.current_package_data = {}
        # Fetch info from PyPI
        self._set_state("fetching")
        # Follwing fetches info about latest version.
        # This is OK even when we're looking an installed older version
        # because new version may have more relevant and complete info.
        self.info_text.clear()
        self.name_label.setText('')
        self.name_label.setVisible(True)
        self.infobox.insertWidget(0, self.name_label)
        self.command_frame.setVisible(True)
        self.buttonbox.insertWidget(0, self.command_frame)
        # 包是否已在本地安装,先显示安装信息
        active_dist = self._get_active_dist(name)
        if active_dist is not None:
            # 获取包的安装信息
            dist_version = active_dist["version"]
            self.current_package_data['name'] = active_dist["project_name"]
            self.current_package_data['version'] = dist_version
            # 已安装包
            self.name_label.setText(active_dist["project_name"])
            self.insert_head_text(
                _("Installed version") + ": ", new_line_end=False)
            self.insert_plain_text(active_dist["version"])
            self.info_text.append('')
            self.insert_head_text(_("Installed to") + ": ", new_line_end=False)
            dist_location = active_dist["location"]
            if not os.path.exists(dist_location):
                self.insert_plain_text(_('Path is not exist...'))
            else:
                self.insert_file_link(
                    strutils.normpath_with_actual_case(dist_location))
            self.info_text.append('')
            self.info_text.append('')
      #      self._select_list_item(name)
        else:
            # 未安装包
            self._select_list_item(0)

        # 从服务器上查询包信息,其次显示包信息,如果能查询到则覆盖包的安装信息
        self.start_fetching_package_info(name)

        # update gui
        if self._is_read_only_package(name):
            self.install_button.grid_remove()
            self.uninstall_button.grid_remove()
        else:
          #  self.install_button.grid(row=0, column=0)
            self.set_command_button(0, self.install_button)

            if active_dist is not None:
                # existing package in target directory
                self.install_button.setText(_("Upgrade"))
                # 比较包的安装版本号和最新版本号,如果小于最新版本则可以更新
                if not compare_common_version(self.current_package_data.get('version', '0.0'), dist_version):
                    self.install_button.setEnabled(False)
                else:
                    self.install_button.setEnabled(True)
               # self.uninstall_button.grid(row=0, column=1)
                self.set_command_button(1, self.uninstall_button)
            else:
                # new package
                self.install_button.setText(_("Install"))
                # self.uninstall_button.grid_remove()
                self.remove_command_button(self.uninstall_button)

    def NotFoundPackage(self, name):
        pass

    def write(self, s, tag=None, index="end"):
        if tag is None:
            tags = ()
        else:
            tags = (tag,)
        self.insert_plain_text(s)

    def write_att(self, caption, value, value_tag=None):
      #  self.write(caption + ": ", "caption")
        self.insert_head_text(caption + ": ", new_line_end=False)
        self.write(value, value_tag)
        self.info_text.append('')

    def _get_latest_stable_version(self, version_strings):
        '''
            获取pypi包的最新稳定版本号
        '''
        versions = []
        for s in version_strings:
            # Assuming stable versions have only dots and numbers
            if s.replace(".", "").isnumeric():
                versions.append(
                    LooseVersion(s)
                )  # LooseVersion __str__ doesn't change the version string

        if len(versions) == 0:
            return None

        return str(sorted(versions)[-1])

    def _show_package_info(self, name, data, error_code=None):
        self._set_state("idle")
        # 从服务器上查询到数据才能覆盖初始的安装信息
        if data:
            self.current_package_data = data
        # 如果未找到则设定为404错误
        else:
            error_code = 404

        if error_code is not None:
            if error_code == 404:
                self.NotFoundPackage(name)
            else:
                write(
                    _("Could not find the package info from PyPI. Error code: ") +
                    str(error_code)
                )

            return
        info = data
        # search name could have been a bit different
        self.name_label.setText(info["name"])
        latest_stable_version = self._get_latest_stable_version(
            data["releases"])
        if latest_stable_version is not None:
            self.write_att(_("Latest stable version"), latest_stable_version)
        else:
            self.write_att(_("Latest version"), data["version"])
        self.write_att(_("Summary"), info["summary"])
        self.write_att(_("Author"), info["author"])
        self.write_att(_("Homepage"), info["homepage"], "url")
        if info.get("bugtrack_url", None):
            self.write_att(_("Bugtracker"), info["bugtrack_url"], "url")
        if info.get("docs_url", None):
            self.write_att(_("Documentation"), info["docs_url"], "url")
        if info.get("package_url", None):
            self.write_att(_("PyPI page"), info["package_url"], "url")
        if info.get("requires_dist", None):
            # Available only when release is created by a binary wheel
            # https://github.com/pypa/pypi-legacy/issues/622#issuecomment-305829257
            self.write_att(_("Requires"), ", ".join(info["requires_dist"]))

        if self._get_active_version(name) != latest_stable_version or not self._get_active_version(
            name
        ):
            self.install_button.setEnabled(True)
        else:
            self.install_button.setEnabled(False)

    def _is_read_only_package(self, name):
        dist = self._get_active_dist(name)
        if dist is None:
            return False
        target_dir = self._get_target_directory()
        if not os.path.exists(dist["location"]) or target_dir is None:
            return True
        return False

    def _normalize_name(self, name):
        # looks like (in some cases?) pip list gives the name as it was used during install
        # ie. the list may contain lowercase entry, when actual metadata has uppercase name
        # Example: when you "pip install cx-freeze", then "pip list"
        # really returns "cx-freeze" although correct name is "cx_Freeze"

        # https://www.python.org/dev/peps/pep-0503/#id4
        return re.sub(r"[-_.]+", "-", name).lower().strip()

    def _select_list_item(self, name_or_index):
        if isinstance(name_or_index, int):
            index = name_or_index
        else:
            names = [self.listbox.item(i).text()
                     for i in range(self.listbox.count())]
            normalized_items = list(map(self._normalize_name, names))
            try:
                index = normalized_items.index(
                    self._normalize_name(name_or_index))
            except Exception:
                exception(
                    _("Can't find package name from the list: ") + name_or_index)
                return

        old_state = self.listbox.isEnabled()
        try:
            self.listbox.setEnabled(True)
           # self.listbox.select_clear(0, "end")
            self.listbox.setCurrentItem(self.listbox.item(index))
          #  self.listbox.activate(index)
           # self.listbox.see(index)
        finally:
            self.listbox.setEnabled(old_state)

    def _perform_install(self, package_data):
        '''
            安装
        '''
        self._start_update_list(package_data['name'], refresh=True)

    def _perform_uninstall(self, package_data):
        '''
            卸载
        '''
        self._show_instructions()
        # 卸载后重新加载并刷新包列表
        self._start_update_list(None, refresh=True)

    def _perform_advanced(self, package_data):
        '''
            其它操作
        '''
        self._start_update_list(package_data['name'])

    def _perform_action(self, action):
        assert self._get_state() == "idle"
        assert self.current_package_data
        if action == "install":
            if not self._confirm_install(self.current_package_data):
                return
            self._perform_install(self.current_package_data)

        elif action == "uninstall":
            self._perform_uninstall(self.current_package_data)
        else:
            raise RuntimeError("Unknown action")

    def _handle_install_file_click(self):
        if self._get_state() != "idle":
            return

    def _handle_target_directory_click(self, event):
        if self._get_target_directory():
            open_path_in_system_file_manager(self._get_target_directory())

    def _install_local_file(self, filename, is_requirements_file):
        self._start_update_list(None)

    def _handle_url_click(self, url):
        '''
            点击链接操作
        '''
        if url is not None:
            # 如果是http地址则打开web链接
            if url.startswith("http:") or url.startswith("https:"):
                webbrowser.open(url)
                return True
            if re.match('^file:///[a-zA-Z]:.*$', url):
                urlpath = url.replace('file:///', '', 1)
                filePath = fileutils.opj(unquote(urlpath))
                # 否则打开文件或文件夹
                pathutils.safe_open_file_directory(filePath)
                return True
        return False

    def _get_active_version(self, name):
        dist = self._get_active_dist(name)
        if dist is None:
            return None
        return dist["version"]

    def _get_active_dist(self, name):
        normname = self._normalize_name(name)
        for key in self._active_distributions:

            if self._normalize_name(key) == normname:
                return self._active_distributions[key]

        return None

    def _should_install_to_site_packages(self):
        raise NotImplementedError()

    def _use_user_install(self):
        # 虚拟解释器必须安装到到site-package目录下,不能使用user参数安装
        # 非虚拟解释器将使用user参数安装
        return not self._should_install_to_site_packages()

    def _get_target_directory(self):
        if self._use_user_install():
            assert hasattr(site, "getusersitepackages")
            os.makedirs(site.getusersitepackages(), exist_ok=True)
            return strutils.normpath_with_actual_case(site.getusersitepackages())
        else:
            for d in sys.path:
                if ("site-packages" in d or "dist-packages" in d) and path_startswith(
                    d, sys.prefix
                ):
                    return strutils.normpath_with_actual_case(d)
            return None

    def _get_title(self):
        return _("Manage packages")

    def _confirm_install(self, package_data):
        return True

    def _read_only(self):
        if self._should_install_to_site_packages():
            return False
            # readonly if not in a virtual environment
            # and user site packages is disabled
        return not site.ENABLE_USER_SITE

    def _targets_virtual_environment(self):
        # https://stackoverflow.com/a/42580137/261181
        return (
            hasattr(sys, "base_prefix")
            and sys.base_prefix != sys.prefix
            or hasattr(sys, "real_prefix")
            and getattr(sys, "real_prefix") != sys.prefix
        )


class PluginsDialog(CommonPluginDialog):
    sig_show_names = pyqtSignal(list)
    sig_install_plugin = pyqtSignal(str, dict, bool)

    def __init__(self, master):
        self._install_plugins = {}
        self._uninstall_plugins = set()
        super().__init__(master)
        # 插件配置是否改变,如果改变关闭对话框时提示用户需要重启软件才能生效
        self._plugin_configuration_changed = False

        self._create_widgets(self.frame_layout)
        self.create_advance_button()
        self.CreateBottomLabel()
        self.sig_show_names.connect(self.show_all_plugins)
        self.sig_install_plugin.connect(self.finish_install_plugin)

    def _is_read_only_package(self, name):
        return False

    def insert_head_text(self, head_text, new_line_end=True):
        self.info_text.insertHtml(f"<span><b>{head_text}</b></span>")
        if new_line_end:
            # 添加新行
            self.info_text.append('')

    def insert_plain_text(self, plain_text):
        self.info_text.insertHtml(f"<span>{plain_text}</span>")

    def insert_link(self, link_text, url):
        self.info_text.insertHtml(f"<a href='{url}'>{link_text}</a>")

    def insert_file_link(self, filepath):
        urlpath = urllib.request.pathname2url(filepath)
        # 对url链接编码
        urlpath = quote(urlpath)
        fileurl = urllib.parse.urljoin('file:', urlpath)
        self.insert_link(filepath, fileurl)

    def _show_instructions(self):
        '''
            显示插件<INSTALL>提示信息
        '''
        self._clear()

        self.insert_head_text(_("Install from server"))
        self.insert_plain_text(
            _("If you don't know where to get the plugin from, ")
            + _("then most likely you'll want to search the plugin Package Index. ")
            + _("Start by entering the name of the plugin in the search box above and pressing ENTER."),
        )
        self.info_text.append('')
        self.info_text.append('')

        self.insert_head_text(_("Install from local file"))
        self.insert_plain_text(_("Click"))
        # , ("install_file",)
        self.insert_link(_("here"), '_handle_install_file_click')
        self.insert_plain_text(
            _(
                " to locate and install the plugin file (usually with .egg extension)."
            ),
        )
        self.info_text.append('')
        self.info_text.append('')

        self.insert_head_text(_("Upgrade or uninstall"))
        self.insert_plain_text(
            _("Start by selecting the plugin from the left."))
        self.info_text.append('')
        self.info_text.append('')
        # 显示插件安装目录
        if self._get_target_directory():
            self.insert_head_text(
                _("Target:User directory or System directory"))
            self.insert_plain_text(
                _("This dialog lists all available plugins,")
                + _(" but allows upgrading and uninstalling only plugins from ")
            )
            # 插件有2个安装目录
            target_directorys = self._get_target_directory()
            # 第一个是用户目录
            self.insert_file_link(target_directorys[0])
            # 2个目录之间以逗号分隔
            self.insert_plain_text(", ")
            # 第二个是软件安装目录
            self.insert_file_link(target_directorys[1])
            self.insert_plain_text(
                _(". New plugin will be also installed into the user directory default.")
                + _(" if you want to install to other location,Please go to Tools->Options...->Misc->Plugin")
            )
#        self._select_list_item(0)

    def CreateBottomLabel(self):
        info_hbox = super().CreateBottomLabel()
        img = get_app().GetImage("plugins.png")
        btn = ImageButton(_("View all plugins"))
        btn.setIcon(img)
        btn.clicked.connect(self.ShowAllPlugins)
        info_hbox.addWidget(btn)
        self.fetch_info_data()
        self.frame_layout.addLayout(info_hbox)

    def fetch_info_data(self):
        QuerypluginNum(self).start()

    def ShowAllPlugins(self):
        '''
            查看所有插件
        '''
        QueryPlugin(self).start()

    def show_all_plugins(self, names):
        self.installled_label.setText(_("All plugins:"))
        self.ShowNameList(names)
        # 显示第一个包名
        if names:
            self._start_show_package_info(names[0])

    def ShowAvailablePlugins(self, names):
        self.installled_var.set(_("Available Plugins:"))
        self.ShowNameList(names)
        # 显示第一个包名
        self._start_show_package_info(names[0])

    def NotFoundPackage(self, name):
        self.write(_("Could not find the plugin from Server."))
        self.info_text.append('')
        if not self._get_active_version(name):
            # new package
            self.write(_("\nPlease check your spelling!") +
                       _("\nYou need to enter "))
            self.write(_("exact plugin name"), "bold")
            self.write("!")

    def search_by_name(self, name):
        names = []
        lower_name = name.lower()
        self.installled_label.setText(_("Searched plugins:"))
        SearchPlugin(self, lower_name).start()
        return names

    def _handle_install_file_click(self):
        if self._get_state() != "idle":
            return
        filename, _filetype = QFileDialog.getOpenFileName(
            self,
            _('Open plugin file'),
            None,
            _("Plugin") + " (*.egg)" + ";;" + _("All Files") + " (*.*)"
        )
        if not filename:
            return
        self._install_local_file(fileutils.opj(filename))

    def _get_latest_stable_version(self, version_strings):
        '''
            获取插件的最新稳定版本号
        '''
        versions = []
        # 插件版本号列表存储的是字典数据和pypi包的版本号列表不一样
        for s in version_strings:
            versions.append(
                LooseVersion(s['version'])
            )  # LooseVersion __str__ doesn't change the version string

        if len(versions) == 0:
            return None

        return str(sorted(versions)[-1])

    def start_fetching_package_info(self, name):
        '''
            从novalide服务器上查询插件信息
        '''
        _start_fetching_plugin_info(name, None, self._show_package_info)

    def _start_update_list(self, name_to_show=None, refresh=False):
        '''
            获取所有已安装插件,在插件对话框初始化时显示
        '''
        assert self._get_state() in [None, "idle"]
        CommonPluginDialog._start_update_list(self, name_to_show)
        pdata = get_app().GetPluginManager().GetPluginData()
        self._active_distributions = {
            plugin.GetName(): {
                "project_name": plugin.GetName(),
                "key": plugin.GetName(),
                "location": plugin.GetDist().location,
                "version": plugin.GetVersion(),
                'enabled': plugin.IsEnabled()
            }
            for plugin in pdata if plugin.GetName() not in self._uninstall_plugins
        }
        # 手动安装的插件
        self._active_distributions.update(self._install_plugins)
        self._update_list(name_to_show)

    def _conflicts_with_application_version(self, plugin_data):
        '''
            检查插件要求的软件版本是否小于等于当前版本,如果不是则需要提示用户更新软件版本
        '''
        app_version = utils.get_app_version()
        if not plugin_data['app_version']:
            return False
        # 检查插件要求的软件版本是否大于当前版本,如果是则提示用户是否更新软件
        if compare_common_version(plugin_data['app_version'], app_version):
            ret = QMessageBox.question(
                self,
                get_app().GetAppName(),
                _("Plugin '%s' requires application version at least '%s',Do you want to update your application?") % (
                    plugin_data['name'], plugin_data['app_version'])
            )
            if ret == QMessageBox.No:
                return True
            # 更新软件,如果用户执行更新安装,则程序会退出,不会执行下面的语句
            CheckAppUpdate()
        # 再检查一次
        return compare_common_version(plugin_data['app_version'], app_version)

    def _should_install_to_site_packages(self):
        return self._targets_virtual_environment()

    def GetInstallPluginPath(self, plugin_name):
        '''
            先检查插件是否安装,如果已安装则安装到插件安装的目录
            否则获取插件安装目录,有2种目录供选择,一种是用户数据目录,一种是软件安装目录
        '''
        dist = get_app().GetPluginManager().GetPluginDistro(plugin_name)
        # 如果插件未安装则选择2种插件目录中的一种
        if not dist:
            plugin_path = GetPluginInstallpath()
        else:
            plugin_path = os.path.dirname(dist.location)
        utils.get_logger().info("plugin %s install path is %s", plugin_name, plugin_path)
        # 确保插件目录存在
        fileutils.makedirs(plugin_path)
        return plugin_path

    @staticmethod
    def GetEggPyVersion(egg_name):
        '''
            从egg文件名称中提取python版本号
        '''
        i = egg_name.find("py")
        trim_name = egg_name[i:]
        return trim_name.replace("py", "").replace(".egg", "")

    @staticmethod
    def GetEggVersion(egg_name):
        '''
            从egg文件名称中提取插件版本号
        '''
        egg_version = egg_name.split("-")[1]
        return egg_version

    @classmethod
    def InstallEggtoPath(cls, name, egg_path, version, plugin_path, local=False):

        def copy_or_move_egg(src_egg_path, dest_to):
            '''
                src_egg_path:源egg文件路径
                dest_to:egg文件目的目录
            '''
            # 如果是本地安装egg插件,则使用拷贝方式
            dest_egg_path = os.path.join(
                dest_to, os.path.basename(src_egg_path))
            # 如果插件文件存在先删除
            if os.path.exists(dest_egg_path):
                # 删除已经存在的插件文件
                try:
                    os.remove(dest_egg_path)
                except:
                    QMessageBox.critical(self, get_app().GetAppName(), _(
                        "Remove plugin file:%s fail") % dest_egg_path)
                    return False
            # 将下载的插件文件移至插件目录下
            try:
                if local:
                    shutil.copy(src_egg_path, dest_to)
                # 如果是从服务器安装egg插件,则使用剪切方式
                else:
                    shutil.move(src_egg_path, dest_to)
                return True
            except Exception as e:
                QMessageBox.critical(get_app().MainFrame, _("Error"), str(e))
                return False

        if utils.is_windows():
            if not copy_or_move_egg(egg_path, plugin_path):
                return False
        # linux系统下有可能是python3.x解释器,只能加载python3.x的插件,故需要将插件的python版本改成3.x的
        else:
            # 如果python3不是3.6版本则需要更改egg文件名,改之后的插件也是可以加载的
            if utils.is_py3_plus():
                if sys.version_info.minor != 6:
                    egg_file_name = os.path.basename(egg_path)
                    egg_py_version = cls.GetEggPyVersion(egg_file_name)
                    # 将egg文件名的py版本号替换成sys版本号
                    new_egg_name = egg_file_name.replace(
                        "py%s" % egg_py_version, "3.%d" % sys.version_info.minor)
                    # 新的egg文件名
                    dest_egg_path = os.path.join(plugin_path, new_egg_name)
                    if not copy_or_move_egg(egg_path, dest_egg_path):
                        return False
                # 如果是3.6版本则不用更改egg文件名,直接拷贝即可
                else:
                    if not copy_or_move_egg(egg_path, plugin_path):
                        return False

        # 执行插件的安装操作,需要在插件里面执行
        get_app().GetPluginManager().LoadPluginByName(name)
        # 安装插件后同时删除旧版本的egg文件
        old_plugin = get_app().GetPluginManager().GetPlugin(name)
        if old_plugin and version != old_plugin.GetVersion():
            dist = old_plugin.GetDist()
            location = dist.location
            try:
                os.remove(location)
            except:
                pass
        return True

    def InstallEgg(self, name, egg_path, version, local=False):
        plugin_path = self.GetInstallPluginPath(name)
        if not self.InstallEggtoPath(name, egg_path, version, plugin_path, local):
            return False
        # 必须重新加载后才能启用插件
        if utils.profile_get_int("ENABLE_INSTALL_PLUGIN", True):
            get_app().GetPluginManager().EnablePlugin(name)
        # 将插件安装信息通知到界面
        self._install_plugins[name] = {
            "project_name": name,
            "key": name,
            "location": os.path.join(plugin_path, os.path.basename(egg_path)),
            "version": version,
            'enabled': True
        }
        self.install_button.setEnabled(False)
        self._plugin_configuration_changed = True
        return True

    def finish_install_plugin(self, name, package_data, install_suc):
        if install_suc:
            CommonPluginDialog._perform_install(self, package_data)
            QMessageBox.information(self, get_app().GetAppName(), _(
                "Install plugin '%s' success") % name)
        else:
            QMessageBox.critical(self, get_app().GetAppName(), _(
                "Install plugin '%s' fail") % name)

    def _perform_install(self, package_data):
        '''
            安装插件
        '''
        def after_download(egg_path):
            '''
                插件下载后回调函数
            '''
            if self.InstallEgg(name, egg_path, package_data['version']):
                self.sig_install_plugin.emit(name, package_data, True)
            else:
                self.sig_install_plugin.emit(name, {}, False)
        name = package_data["name"]
        self.InstallPlugin(package_data, after_download)

    @staticmethod
    def InstallPlugin(package_data, call_back):
        name = package_data["name"]
        lang = get_app().locale.GetLanguageCanonicalName()
        app_version = utils.get_app_version()
        download_url = '%s/member/download_plugin' % (
            ApiServer.HOST_SERVER_ADDR)
        payload = {
            "new_version": package_data['version'],
            "app_version": app_version,
            "lang": lang,
            "os_name": sys.platform,
            "plugin_id": package_data['id']
        }
        try:
            # 下载插件文件
            transfer.FiledownloadSerivce().download_file(download_url, call_back=call_back,
                                                         parent=get_app().MainFrame.GetNotebook(), **payload)
        except Exception as ex:
            utils.get_logger().error("download plugin %s fail:%s", name, ex)
            QMessageBox.critical(get_app().MainFrame, _("Error"), _(
                "Download plugin %s fail:%s") % (name, ex))

    def GetInstallEggPath(self, name):
        """Get the path of the plugin
        @return: string
        """
        return self._active_distributions[name]['location']

    def _perform_uninstall(self, package_data):
        '''
            卸载插件
        '''
        plist = utils.profile_get('UNINSTALL_PLUGINS', [])
        plist.append(self.GetInstallEggPath(package_data['name']))
        utils.profile_set('UNINSTALL_PLUGINS', plist)
        self._plugin_configuration_changed = True
        self.uninstall_button.setEnabled(False)
        # 通知界面删除卸载包
        self._uninstall_plugins.add(package_data['name'])
        CommonPluginDialog._perform_uninstall(self, package_data)
        # 执行插件的卸载操作,需要在插件里面执行
        get_app().GetPluginManager().UnloadPluginByName(package_data['name'])
        QMessageBox.information(
            self, get_app().GetAppName(), _("Uninstall success"))

    def _perform_enable_action(self, package_data):
        '''
            这里执行启动和禁止插件操作
        '''
        self._plugin_configuration_changed = True
        enable_label_text = _("Enabled")
        disable_label_text = _("Disabled")
        if self.enabled_button.text() == enable_label_text:
            self.enabled_button.setText(disable_label_text)
            # 启用插件
            get_app().GetPluginManager().EnablePlugin(
                package_data['name'], enable=True)
            # 执行插件的一些启用操作
            get_app().GetPluginManager().EnablePluginByName(
                package_data['name'])
            # 更改插件的状态显示,先选中状态文本,然后替换为新状态文本
            self.info_text.find(disable_label_text, QTextDocument.FindBackward)
            self.info_text.textCursor().insertText(enable_label_text)
        else:
            self.enabled_button.setText(enable_label_text)
            # 禁止插件
            get_app().GetPluginManager().EnablePlugin(
                package_data['name'], enable=False)
            # 执行插件的一些禁止操作
            get_app().GetPluginManager().DisablePluginByName(
                package_data['name'])
            # 更改插件的状态显示,先选中状态文本,然后替换为新状态文本
            self.info_text.find(enable_label_text, QTextDocument.FindBackward)
            self.info_text.textCursor().insertText(disable_label_text)

    def _confirm_install(self, package_data):
        '''
            确认是否安装插件
        '''
        # 插件是否需要登录
        if package_data.get('login_required', False) and not GetApp().is_login:
            messagebox.showinfo(GetApp().GetAppName(), _(
                'You need register an account and login if you want to install plugin "%s"') % package_data['name'])
            register.RegisterDialog(self).ShowModal()
            # 用户未登录成功
            if not GetApp().is_login:
                return False
        try:
            plugin_path = self.GetInstallPluginPath(package_data['name'])
        except Exception as e:
            QMessageBox.critical(self, _("Error"), str(e))
            return False
        dest_egg_path = os.path.join(plugin_path, package_data['path'])
        # 是否替换现有插件文件
        if os.path.exists(dest_egg_path):
            ret = QMessageBox.question(self, _("Move File"), _(
                "Plugin file is already exist,Do you want to overwrite it?"))
            if ret == QMessageBox.No:
                return False
        # 检查软件的版本是否是插件要求的最低版本
        return not self._conflicts_with_application_version(package_data)

    def _get_target_directory(self):
        '''
            获取插件安装目录
        '''
        return [utils.get_user_plugin_path(), utils.get_sys_plugin_path()]

    def _create_widgets(self, box_layout):
        banner_msg = (
            _("This dialog is for managing Noval plug-ins and their dependencies.\n")
            + _("If you want to look all available plugins on server please click on the button at bottom.\n")
        )
        banner_msg += (
            "\n"
            + _("NB! You need to restart Noval after installing / upgrading / uninstalling a plug-in.")
        )
        banner_text = BannerLabel(banner_msg)
        box_layout.addWidget(banner_text)
        super()._create_common_widgets(box_layout, _("Installed Plugins:"),
                                       _("Find plugin"), '', _("Input the plugin name"))

    def _get_title(self):
        return _("NovalIDE plug-ins")

    def create_advance_button(self):
        self.enabled_button = QPushButton(_("Enabled"))
        self.enabled_button.clicked.connect(
            lambda: self._perform_enable_action(self.current_package_data))
        self.command_frame.layout().addWidget(self.enabled_button)
        # self.buttonbox.insertWidget(2, self.enabled_button)
        self.enabled_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

    def _cancel(self):
        '''
            关闭对话框时检查插件配置是否更改,如果更提示用户需要重启软件
        '''
        if self._plugin_configuration_changed:
            QMessageBox.warning(
                self,
                _("Plugin Configuration Changed"),
                _("You must restart NovalIDE before your changes will take full affect.")
            )
        self.reject()

    def _install_local_file(self, filename):
        '''
            从本地安装插件
            filename:本地插件路径
        '''
        pi_path = os.path.dirname(filename)
        file_plugin_manager = plugin.PluginManager(pi_path=pi_path)
        plugin_data = file_plugin_manager.FindPluginByegg(filename)
        if plugin_data is None:
            QMessageBox.critical(
                self, get_app().GetAppName(), _("Invalid plugin"))
            return
        plugin_name = plugin_data.GetName()
        # 设置为本地安装插件
        if not self._confirm_install({'local': True, 'name': plugin_name, 'path': os.path.basename(filename), 'app_version': plugin_data.Instance.GetMinVersion()}):
            return

        # 必须要删除插件实例化对象
        instance = plugin_data.GetInstance()
        module = inspect.getmodule(instance)
        # 调用egg.activate()会报如下警告,是因为本地egg文件和插件目录下的egg文件重复加载了,不影响程序正常运行
        # 安装插件后重启软件即可
        # UserWarning: Module xxxxx was already imported from xxxxxx\__init__.py, but c:\users\administrator\appdata\roaming\novalidedebug\plugins\xxxxx.egg is being added to sys.path
        self.InstallEgg(plugin_name, filename,
                        plugin_data.GetVersion(), local=True)
        self._start_update_list(plugin_name)
        QMessageBox.information(self, get_app().GetAppName(), _(
            "Install plugin '%s' success") % plugin_name)

    def remove_command_button(self, button):
        self.command_frame.layout().removeWidget(button)
        button.setVisible(False)

    def set_command_button(self, pos, button):
        self.command_frame.layout().insertWidget(pos, button)
        button.setVisible(True)
        self.command_frame.setVisible(True)

    def _show_package_info(self, name, data, error_code=None):
        CommonPluginDialog._show_package_info(self, name, data, error_code)
        plugin_name = data['name'] if data else name
        # 未安装的插件不显示启用按钮
        if plugin_name in self._active_distributions:
            enabled = self._active_distributions[plugin_name]['enabled']
            # 加载安装插件的状态信息
            self.write_att(_("State"), _('Enabled')
                           if enabled else _("Disabled"))
            if enabled:
                self.enabled_button.setText(_("Disabled"))
            else:
                self.enabled_button.setText(_('Enabled'))
           # self.enabled_button.grid(row=0, column=2)
            self.set_command_button(2, self.enabled_button)
        else:
            self.remove_command_button(self.enabled_button)
        if data and error_code is None:
            self.write_att(_("Installs"), str(data['down_amount']))
        if not get_app().GetDebug():
            # 是否禁止卸载插件,调试模式时总是允许卸载插件
            if data.get('disable_uninstall', False):
                self.uninstall_button.setEnabled(False)
                self.enabled_button.setEnabled(False)
            else:
                self.uninstall_button.setEnabled(True)
                self.enabled_button.setEnabled(True)
        # 是否禁止安装插件
        if data.get('disabled', False):
            self.install_button.setEnabled(False)
        else:
            self.install_button.setEnabled(True)


def _ask_installation_details(master, data, selected_version):
    dlg = DetailsDialog(master, data, selected_version)
    ui_utils.show_dialog(dlg, master)
    return dlg.result


def _start_fetching_plugin_info(name, version_str, completion_handler):
    '''
        从服务器上获取插件信息
    '''
    # Fetch info from novalide server
    api_addr = '%s/member/get_plugin' % (ApiServer.HOST_SERVER_ADDR)

    def poll_fetch_complete():
        if PluginsDialog.API_SERVER_OK:
            data = ApiServer().request_addr(
                api_addr, method='get', arg={'name': name})
        else:
            data = None
        if data is not None:
            # 去掉非数据字段
            data.pop('message')
            data.pop('code')
        if data:
            completion_handler(name, data)
        else:
            # 未能从服务器上找到插件
            completion_handler(name, {}, error_code=404)

    # 这里最好不要异步获取,否则在频繁点击左侧列表项时会因为多线程导致界面信息混乱
    poll_fetch_complete()


def _extract_click_text(widget, event, tag):
    # http://stackoverflow.com/a/33957256/261181
    try:
        index = widget.index("@%s,%s" % (event.x, event.y))
        tag_indices = list(widget.tag_ranges(tag))
        for start, end in zip(tag_indices[0::2], tag_indices[1::2]):
            # check if the tag matches the mouse click index
            if widget.compare(start, "<=", index) and widget.compare(index, "<", end):
                return widget.get(start, end)
    except Exception:
        logging.exception("extracting click text")

    return None


class PluginInstallDir(enum.Enum):
    USER_DIR = 1
    SYSTEM_DIR = 2


class PluginOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    """

    def __init__(self, parent):
        super().__init__()
        sbox = QGroupBox(_("Default plugin directory:"))
        value = self.GetPluginInstallpath()
        option_box = QVBoxLayout()
        self.user_dir_radio = QRadioButton(_('User directory'))
        option_box.addWidget(self.user_dir_radio)
        if value == PluginInstallDir.USER_DIR:
            self.user_dir_radio.setChecked(True)

        self.sys_dir_radio = QRadioButton(_('System directory'))
        option_box.addWidget(self.sys_dir_radio)
        if value == PluginInstallDir.SYSTEM_DIR:
            self.sys_dir_radio.setChecked(True)
        sbox.setLayout(option_box)
        self.layout.addWidget(sbox)

        self.enablePluginCheckBox = QCheckBox(
            _("Enable plugin after install it"))
        self.enablePluginCheckBox.setChecked(
            utils.profile_get_int("ENABLE_INSTALL_PLUGIN", True))
        self.layout.addWidget(self.enablePluginCheckBox)

        self.enable_check_file_extension_checkbox = QCheckBox(
            _("Search plugin market When open unsupported file extension")
        )
        self.enable_check_file_extension_checkbox.setChecked(
            utils.profile_get_int("CHECK_FILE_EXTENSION_PLUGIN", True))
        self.layout.addWidget(self.enable_check_file_extension_checkbox)
        self.layout.addStretch(1)

    def OnOK(self, options_dialog):
        plugin_install_path = ''
        if self.user_dir_radio.isChecked():
            plugin_install_path = utils.get_user_plugin_path()
        elif self.sys_dir_radio.isChecked():
            plugin_install_path = utils.get_sys_plugin_path()
        utils.profile_set("PluginInstallPath", plugin_install_path)
        utils.profile_set("ENABLE_INSTALL_PLUGIN",
                          self.enablePluginCheckBox.isChecked())
        utils.profile_set("CHECK_FILE_EXTENSION_PLUGIN",
                          self.enable_check_file_extension_checkbox.isChecked())
        return True

    def GetPluginInstallpath(self):
        plugin_install_path = GetPluginInstallpath()
        if plugin_install_path == utils.get_sys_plugin_path():
            return PluginInstallDir.SYSTEM_DIR
        return PluginInstallDir.USER_DIR


class PluginManagerGUI(plugin.Plugin):
    plugin.Implements(iface.MainWindowI)

    def PlugIt(self, parent):
        self.parent = parent
        utils.get_logger().info("load default plugin gui plugin")
        # Add Menu
        menuBar = get_app().Menubar
        tools_menu = find_menu(_("&Tools"), menuBar)
        tools_menu.InsertBefore(
            menuitems.ID_PREFERENCES,
            menuitems.ID_PLUGIN,
            _("Plugin manager"),
            ("Plugin Manager GUI"),
            handler=self.show_plugins_dlg,
            img=get_app().GetImage("plugin.png")
        )
        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("Misc"), "Plugin", _('Plugin'), PluginOptionPanel)
        utils.get_logger().info("check plugins update informattion")
        # 检查插件更新
        self.check_plugins()

    def show_plugins_dlg(self):
        show_pluginmanager_dlg(self.parent)

    def check_plugins(self):
        PluginUpdate(get_app().MainFrame.GetNotebook()).start()
