import os
import datetime
import getpass
import sqlite3
from . import sql
from .basedb import BaseDb
from ..util import apputils, appdirs, fileutils, utils
from ..common.singleton import SingletonMeta
from .. import constants
from ..common.version import UpdateVersion
from .tables import USER_TABLE, DATA_TABLE
from ..api.api import ApiServer
from ..api.errors import OK, USER_NOT_EXIST
from ..executable import Executable

if apputils.is_windows():
    import wmi
    import pythoncom
    import platform

    def get_wmic_os_output(command_name):
        executable = Executable('wmic')
        output = executable.exec_command_output(f'os get {command_name}')
        return output.replace(command_name, "").strip()

    def get_wmic_os_name():
        return get_wmic_os_output('Caption')

    def get_wmic_os_osarchitecture():
        return get_wmic_os_output('OSArchitecture')

    def get_wmic_disk_output(command_name):
        executable = Executable('wmic')
        output = executable.exec_command_output(f'diskdrive get {command_name}')
        return output.replace(command_name, "").strip()

    def get_wmic_sn_name():
        sn = get_wmic_disk_output('SerialNumber')
        if sn == "":
            sn = get_wmic_disk_output('SystemName')
        return sn.splitlines()[0].strip()

    def get_host_info():
        pythoncom.CoInitialize()
        c = wmi.WMI()
        os_name = platform.platform()
        os_bit = platform.architecture()[0]
        sn = 'unkown disk sn'
        try:
            for os_sys in c.Win32_OperatingSystem():
                os_name = os_sys.Caption.strip()
                os_bit = os_sys.OSArchitecture
            for physical_disk in c.Win32_DiskDrive():
                if physical_disk.SerialNumber is not None:
                    sn = physical_disk.SerialNumber.strip()
                elif physical_disk.SystemName is not None:
                    sn = physical_disk.SystemName.strip()

        except Exception as e:
            utils.get_logger().warn("get os and disk info error:%s", e)
            os_name = get_wmic_os_name()
            os_bit = get_wmic_os_osarchitecture()
            sn = get_wmic_sn_name()
        return os_name, os_bit, sn
else:
    import platform

    def get_host_info():
        os_name = platform.platform()
        os_bit = platform.architecture()[0]
        sn = 'unkown disk sn'
        r = os.popen("ls -l /dev/disk/by-uuid")
        content = r.read()
        for line in content.split('\n'):
            if line.find("->") != -1:
                sn = line.split()[8].strip()
                break
        return os_name, os_bit, sn


class UserdataDb(BaseDb, UpdateVersion, metaclass=SingletonMeta):
    USER_DATA_DB_NAME = "data.db"
    DB_VERSION = "1.0.3"

    def __init__(self):
        db_dir = os.path.join(appdirs.get_user_data_path(),
                              constants.USER_CACHE_DIR)
        if not os.path.exists(db_dir):
            fileutils.makedirs(db_dir)
        self.db_file = os.path.join(db_dir, self.USER_DATA_DB_NAME)
        UpdateVersion.__init__(self, db_dir)
        self._version_file = self.USER_DATA_DB_NAME + ".version"
        utils.get_logger().debug(
            'db file is %s, db verison file is %s',
            self.db_file,
            self.get_version_file()
        )
        self.update_db()
        self.data_id = None
        self.user_id = None
        BaseDb.__init__(self, self.db_file)
        self.init_data_db()

    @staticmethod
    def get_db():
        return UserdataDb()

    def update_db(self):
        if self.need_update_version(self.DB_VERSION):
            if os.path.exists(self.db_file):
                utils.get_logger().info("the database file %s need to be updated", self.db_file)
                fileutils.safe_remove(self.db_file)
                if not os.path.exists(self.db_file):
                    self.update_new_version(self.DB_VERSION)
                else:
                    utils.get_logger().error("remove database file %s fail", self.db_file)

    def init_data_db(self):
        table_already_exist_flag = 'already exists'
        try:
            self.create_table(sql.CREATE_USER_TABLE_SQL, USER_TABLE)
        except sqlite3.OperationalError as e:
            if str(e).find(table_already_exist_flag) == -1:
                utils.get_logger().error(str(e))
            else:
                utils.get_logger().debug(str(e))
        try:
            self.create_table(sql.CREATE_USER_DATA_TABLE_SQL, DATA_TABLE)
        except sqlite3.OperationalError as e:
            if str(e).find(table_already_exist_flag) == -1:
                utils.get_logger().error(str(e))
            else:
                utils.get_logger().debug(str(e))

    def CreateUser(self):
        os_name, os_bit, sn = get_host_info()
        insert_sql = f'''
            insert into {USER_TABLE}(os_bit,os,sn,user_name) values (?,?,?,?)
        '''
        data = [(os_bit, os_name, sn, getpass.getuser())]
        utils.get_logger().debug('create user sql is: %s, data is %s',
                                 insert_sql, ApiServer.json_data(data))
        self.save(insert_sql, data)

    def GetUser(self):
        sql = f"select * from {USER_TABLE}"
        result = self.fetchone(sql)
        if not result:
            self.CreateUser()
            result = self.fetchone(sql)
        self.user_id = result[0]
        if result[1] is None:
            api = ApiServer()
            api_addr = '%s/member/getuser' % (ApiServer.HOST_SERVER_ADDR)
            sn = result[4]
            arg = {'sn': sn}
            data = api.request_addr(api_addr, arg=arg)
            # 序列号在服务器数据库中不存在,创建一个新用户
            if data is not None and data['code'] != OK:
                api_addr = '%s/member/createuser' % (
                    ApiServer.HOST_SERVER_ADDR)
                sn = result[4]
                args = {
                    'sn': sn,
                    'os_bit': result[3],
                    'os_name': result[5],
                    'user_name': result[2],
                    'app_version': apputils.get_app_version()
                }
                data = api.request_addr(api_addr, arg=args, method='post')
            # 序列号在服务器数据库中存在,将用户id更新到本地数据库
            if data is not None and data['code'] == OK:
                member_id = data['member_id']
                update_sql = '''
                    update user set user_id='%s' where id=%d
                ''' % (member_id, self.user_id)
                self.update(update_sql)

    def recreate_user(self):
        delete_sql = f'delete from {USER_TABLE}'
        self.delete(delete_sql)
        self.GetUser()

    def record_start(self):
        '''app使用开始时间'''
        self.GetUser()
        insert_sql = f'''
            insert into {DATA_TABLE}(user_id,app_version) values (?,?)
        '''
        data = [(self.user_id, utils.get_app_version()), ]
        utils.get_logger().debug('update start data sql is: %s, data is %s',
                                 insert_sql, ApiServer.json_data(data))
        self.data_id = self.save(insert_sql, data)

    def record_end(self):
        '''app使用结束时间'''
        utils.get_logger().debug('data id is %s, user id is %s', self.data_id, self.user_id)
        if self.data_id is None or self.user_id is None:
            return
        update_sql = '''
            update %s set end_time='%s' where id=%d
        ''' % (DATA_TABLE, datetime.datetime.now(), self.data_id)
        utils.get_logger().debug('update end data sql is: %s', update_sql)
        self.update(update_sql)

    def GetMemberId(self, user_id):
        sql = "select * from user where id=%d" % user_id
        result = self.fetchone(sql)
        if not result:
            return None
        return result[1]

    def delete_data(self, data_id):
        delete_sql = '''
            delete from data where id=%d
        ''' % data_id
        self.delete(delete_sql)

    def share_user_data(self):
        '''
            简单记录用户使用app的开始和结束时间,并提交到app服务器
            当app启动时会发送用户使用数据,并记录使用开始时间,
            当app退出时记录使用结束时间,下次app启动时提交使用数据
        '''
        sql = "select * from data"
        api = ApiServer()
        for result in self.fetchall(sql):
            utils.get_logger().debug('query user data result is %s', ApiServer.json_data(result))
            # 数据是否已经提交
            if not result[3]:
                api_addr = '%s/member/share_data' % (
                    ApiServer.HOST_SERVER_ADDR)
                member_id = self.GetMemberId(result[1])
                utils.get_logger().debug('user memberid is %s', member_id)
                # 删除无效数据
                if not member_id:
                    self.delete_data(result[0])
                    continue
                args = {
                    'member_id': member_id,
                    'start_time': result[4],
                    'end_time': result[5],
                    'app_version': result[2],
                }
                data = api.request_addr(api_addr, arg=args, method='post')
                if data is not None:
                    code = data['code']
                    # 提交数据,并设置标准以便下次删除
                    update_sql = '''
                        update data set submited=1 where id=%d
                    ''' % result[0]
                    utils.get_logger().debug('update sql is %s', update_sql)
                    self.update(update_sql)
                    # 用户id在服务器上不存在,重新生成user id
                    if code == USER_NOT_EXIST:
                        self.recreate_user()
            else:
                # 删除已经提交到服务器的数据
                self.delete_data(result[0])

    def GetUserId(self):
        '''获取服务器上数据库存储的id,mongodb id类型的字符串'''
        sql = "select * from user"
        result = self.fetchone(sql)
        if not result:
            return None
        return result[1]

    def GetUserInfo(self):
        sql = "select * from user"
        result = self.fetchone(sql)
        return result

    def GetToken(self):
        info = self.GetUserInfo()
        if not info:
            return None
        return info[10]

    def UpdateUserInfo(self, **kwargs):
        if self.user_id is None:
            self.GetUser()
        update_sql = '''
            update user set email='%s', user_name='%s', token='%s' where id=%d
        ''' % (kwargs.get('email'), kwargs.get('user_name'), kwargs.get('token', ''), self.user_id)
        self.update(update_sql)
