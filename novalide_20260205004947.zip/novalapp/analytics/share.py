import logging
from ..lib.pyqt import QThread
from .userdb import UserdataDb

sharelog = logging.getLogger(__name__)


class ShareData(QThread):
    """description of class"""

    def __init__(self, parent, is_debug):
        super().__init__(parent)
        self._is_debug = is_debug

    def run(self):
        self.share()

    def share(self):
        if self._is_debug:
            return
        try:
            UserdataDb.get_db().share_user_data()
            UserdataDb.get_db().record_start()
        except Exception as ex:
            sharelog.exception("share user db exception:")
