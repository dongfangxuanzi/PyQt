# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        model.py
Purpose:     软件支持的编程语言

Author:      wukan

Created:     2019-01-08
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''

LANGUAGE_PYTHON = "python"
LANGUAGE_NOTSET = "notset"
LANGUAGE_DEFAULT = LANGUAGE_PYTHON
