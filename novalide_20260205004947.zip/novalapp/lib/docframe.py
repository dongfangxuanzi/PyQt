from .. import get_app
from .pyqt import QFrame, QHBoxLayout, QVBoxLayout


class DocTabbedChildFrame(QFrame):
    """
    The wxDocMDIChildFrame class provides a default frame for displaying
    documents on separate windows. This class can only be used for MDI child
    frames.

    The class is part of the document/view framework supported by wxWindows,
    and cooperates with the wxView, wxDocument, wxDocManager and wxDocTemplate
    classes.
    """

    def __init__(self, doc, view, frame, id, title):
        """
        Constructor.  Note that the event table must be rebuilt for the
        frame since the EvtHandler is not virtual.
        """
        super().__init__(frame.GetNotebook())
        self._child_document = doc
        self._childview = view
        frame.AddNotebookPage(self, doc.GetPrintableName(), doc.GetFilename())
        if view:
            view.SetFrame(self)

    def GetIcon(self):
        """
        Dummy method since the icon of tabbed frames are managed by the notebook.
        """
        return None

    def SetIcon(self, icon):
        """
        Dummy method since the icon of tabbed frames are managed by the notebook.
        """

    def Destroy(self):
        """
        Removes the current notebook page.
        """
        get_app().GetTopWindow().RemoveNotebookPage(self)

    def SetFocus(self):
        """
        Activates the current notebook page.
        """
        get_app().GetTopWindow().ActivateNotebookPage(self)

    # Need this in case there are embedded sash windows and such, OnActivate is not getting called
    def Activate(self):
        """
        Activates the current view.
        """
        # Called by Project Editor
        if self._childview:
            self._childview.Activate(True)

    def GetTitle(self):
        """
        Returns the frame's title.
        """
        return get_app().GetTopWindow().GetNotebookPageTitle(self)

    def SetTitle(self, title):
        """
        Sets the frame's title.
        """
        get_app().GetTopWindow().set_notebook_page_title(self, title)

    def OnTitleIsModified(self):
        """
        Add/remove to the frame's title an indication that the document is dirty.
        If the document is dirty, an '*' is appended to the title
        """
        title = self.GetTitle()
        if title:
            if self.GetDocument().IsModified():
                if not title.endswith("*"):
                    title = title + "*"
                    self.SetTitle(title)
            else:
                if title.endswith("*"):
                    title = title[:-1]
                    self.SetTitle(title)

    def GetDocument(self):
        """
        Returns the document associated with this frame.
        """
        return self._child_document

    def SetDocument(self, document):
        """
        Sets the document for this frame.
        """
        self._child_document = document

    def GetView(self):
        """
        Returns the view associated with this frame.
        """
        return self._childview

    def SetView(self, view):
        """
        Sets the view for this frame.
        """
        self._childview = view

    def attach_horizontal_layout(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.setLayout(layout)

    def attach_vertical_layout(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.setLayout(layout)
