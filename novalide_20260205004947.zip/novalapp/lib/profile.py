import json
import logging
from . import get_app
logger = logging.getLogger(__name__)


class Profile:
    """description of class"""

    @staticmethod
    def get(key, value=""):
        if isinstance(value, str):
            return get_app().GetConfig().Read(key, value)
        key_value = get_app().GetConfig().Read(key, "")
        if key_value == "":
            logger.warning('key %s may not exist', key)
            return value
        try:
            return eval(key_value)
        except Exception as ex:
            logger.error('eval and get key %s value %s error:%s', key, key_value, ex)
            return value

    @staticmethod
    def get_int(key, value=-1):
        return get_app().GetConfig().ReadInt(key, value)

    @staticmethod
    def set(key, value):
        if isinstance(value, int) or isinstance(value, bool):
            get_app().GetConfig().WriteInt(key, value)
        else:
            if isinstance(value, str):
                get_app().GetConfig().Write(key, value)
            elif isinstance(value, (list, dict)):
                get_app().GetConfig().Write(key, json.dumps(value))
            elif isinstance(value, bytes):
                get_app().GetConfig().Write(key, repr(value))
            else:
                raise RuntimeError('invalid key value `%s`', repr(value))
