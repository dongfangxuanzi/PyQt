# -*- coding: utf-8 -*-
'''
Name:        docview.py
Purpose:     应用程序文档视图实现

Author:      wukan

Created:     2024-01-23
Copyright:   (c) wukan 2024
Licence:     <your licence>
'''
from . import get_app

DOC_NO_VIEW = 8


class View:
    """
    The view class can be used to model the viewing and editing component of
    an application's file-based data. It is part of the document/view
    framework supported by wxWindows, and cooperates with the wxDocument,
    wxDocTemplate and wxDocManager classes.
    """

    def __init__(self):
        """
        Constructor. Define your own default constructor to initialize
        application-specific data.
        """
        self._viewDocument = None
        self._viewFrame = None

    def Destroy(self):
        """
        Destructor. Removes itself from the document's list of views.
        """
        if self._viewDocument:
            self._viewDocument.RemoveView(self)

    def OnActivateView(self, activate, activeView, deactiveView):
        """
        Called when a view is activated by means of wxView::Activate. The
        default implementation does nothing.
        """

    def OnClosingDocument(self):
        """
        Override this to clean up the view when the document is being closed.
        The default implementation does nothing.
        """

    def UpdateUI(self, command_id):
        return False

    def OnPrint(self, dc, info):
        """
        Override this to print the view for the printing framework.  The
        default implementation calls View.OnDraw.
        """
        self.OnDraw(dc)

    def OnUpdate(self, sender, hint):
        """
        Called when the view should be updated. sender is a pointer to the
        view that sent the update request, or NULL if no single view requested
        the update (for instance, when the document is opened). hint is as yet
        unused but may in future contain application-specific information for
        making updating more efficient.
        """
        if hint:
            if hint[0] == "modify":  # if dirty flag changed, update the view's displayed title
                frame = self.GetFrame()
                if frame and hasattr(frame, "OnTitleIsModified"):
                    frame.OnTitleIsModified()
                    return True
        return False

    def OnChangeFilename(self):
        """
        Called when the filename has changed. The default implementation
        constructs a suitable title and sets the title of the view frame (if
        any).
        """
        if self.GetFrame():
            appname = get_app().GetAppName()
            if not self.GetDocument():
                if appname:
                    title = appname
                else:
                    return
            else:
                title = ''
                self.GetFrame().SetTitle(title + self.GetDocument().GetPrintableName())

    def GetDocument(self):
        """
        Returns the document associated with the view.
        """
        return self._viewDocument

    def SetDocument(self, doc):
        """
        Associates the given document with the view. Normally called by the
        framework.
        """
        self._viewDocument = doc
        if doc:
            doc.AddView(self)

    def GetViewName(self):
        """
        Gets the name associated with the view (passed to the wxDocTemplate
        constructor). Not currently used by the framework.
        """
        return self._viewTypeName

    def SetViewName(self, name):
        """
        Sets the view type name. Should only be called by the framework.
        """
        self._viewTypeName = name

    def Close(self, deleteWindow=True):
        """
        Closes the view by calling OnClose. If deleteWindow is true, this
        function should delete the window associated with the view.
        """
        if self.OnClose(deleteWindow=deleteWindow):
            return True
        return False

    def Activate(self, activate=True):
        """
        Call this from your view frame's OnActivate member to tell the
        framework which view is currently active. If your windowing system
        doesn't call OnActivate, you may need to call this function from
        OnMenuCommand or any place where you know the view must be active, and
        the framework will need to get the current view.

        The prepackaged view frame wxDocChildFrame calls wxView.Activate from
        its OnActivate member and from its OnMenuCommand member.
        """
        if self.GetDocument() and self.GetDocumentManager():
            self.OnActivateView(
                activate, self, self.GetDocumentManager().GetCurrentView())
            self.GetDocumentManager().ActivateView(self, activate)

    def OnClose(self, deleteWindow=True):
        """
        Implements closing behaviour. The default implementation calls
        wxDocument.Close to close the associated document. Does not delete the
        view. The application may wish to do some cleaning up operations in
        this function, if a call to wxDocument::Close succeeded. For example,
        if your application's all share the same window, you need to
        disassociate the window from the view and perhaps clear the window. If
        deleteWindow is true, delete the frame associated with the view.
        """
        if self.GetDocument():
            return self.GetDocument().Close()
        return True

    def OnCreate(self, doc, flags):
        """
        wxDocManager or wxDocument creates a wxView via a wxDocTemplate. Just
        after the wxDocTemplate creates the wxView, it calls wxView::OnCreate.
        In its OnCreate member function, the wxView can create a
        wxDocChildFrame or a derived class. This wxDocChildFrame provides user
        interface elements to view and/or edit the contents of the wxDocument.

        By default, simply returns true. If the function returns false, the
        view will be deleted.
        """
        return True

    def OnCreatePrintout(self):
        """
        Returns a wxPrintout object for the purposes of printing. It should
        create a new object every time it is called; the framework will delete
        objects it creates.

        By default, this function returns an instance of wxDocPrintout, which
        prints and previews one page by calling wxView.OnDraw.

        Override to return an instance of a class other than wxDocPrintout.
        """
        return DocPrintout(self, self.GetDocument().GetPrintableName())

    def GetFrame(self):
        """
        Gets the frame associated with the view (if any). Note that this
        "frame" is not a wxFrame at all in the generic MDI implementation
        which uses the notebook pages instead of the frames and this is why
        this method returns a wxWindow and not a wxFrame.
        """
        return self._viewFrame

    def SetFrame(self, frame):
        """
        Sets the frame associated with this view. The application should call
        this if possible, to tell the view about the frame.  See GetFrame for
        the explanation about the mismatch between the "Frame" in the method
        name and the type of its parameter.
        """
        self._viewFrame = frame

    def GetDocumentManager(self):
        """
        Returns the document manager instance associated with this view.
        """
        if self._viewDocument:
            return self.GetDocument().GetDocumentManager()
        return None

    def SetFocus(self):
        pass
        # if self.GetFrame() is None:
        #   return
        # self.GetFrame().SetFocus()

    def DoFind(self):
        pass

    def ProcessEvent(self, command_id):
        return False
