'''
Name:        config.py
Purpose:     应用程序配置类及其实现

Author:      wukan

Created:     2026-01-11
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import logging
import sys
from configparser import ConfigParser
import os
logger = logging.getLogger(__name__)


class LocalfileConfig:
    def __init__(self, app_name):
        self.app_name = app_name
        self.cfg = ConfigParser()
        self.config_path = os.path.join(
            os.path.expanduser("~"), "." + self.app_name)
        try:
            self.cfg.read(self.config_path)
        except Exception as e:
            logger.warn('load ide config file error %s,will reaload it', str(e))
            self.Reload()

    def GetDestSection(self, key, ensure_open=True):
        '''
            按照/分割线分割多级key,如果是写入操作,则创建所有子健
            如果是读取操作,则不能创建子健,只能打开,如果打开失败,则返回None
            ensure_open:打开子健失败时是否创建子健
        '''
        if -1 == key.find("/"):
            return 'DEFAULT', key
        sections = key.split("/")
        last_key = sections.pop()
        for i in range(len(sections)):
            section = ("/").join(sections[0:i + 1])
            if ensure_open:
                # 禁止写入空字段[]
                if section and not self.cfg.has_section(section):
                    self.cfg.add_section(section)
            else:
                if section and not self.cfg.has_section(section):
                    return None, last_key
        return ("/").join(sections), last_key

    def Read(self, key, default=""):
        section, last_key = self.GetDestSection(key, ensure_open=False)
        try:
            return self.cfg.get(section, last_key)
        except:
            assert isinstance(default, str)
            return default

    def ReadInt(self, key, default=-1):
        section, last_key = self.GetDestSection(key, ensure_open=False)
        try:
            return self.cfg.getint(section, last_key)
        except:
            assert (isinstance(default, int) or isinstance(default, bool))
            return default

    def Write(self, key, value):
        section, last_key = self.GetDestSection(key)
        if isinstance(value, str):
            self.cfg.set(section, last_key, value)
        else:
            self.cfg.set(section, last_key, repr(value))

    def WriteInt(self, key, value):
        section, last_key = self.GetDestSection(key)
        # 将bool值转换为int
        if isinstance(value, bool):
            value = int(value)
        assert isinstance(value, int)
        # python3 configparser不支持写入整形变量,必须先转换为字符串
        value = str(value)
        # 必须将整形转换为字符串写入
        self.cfg.set(section, last_key, str(value))

    def Save(self):
        with open(self.config_path, "w") as f:
            self.cfg.write(f)

    def DeleteEntry(self, key):
        section, last_key = self.GetDestSection(key)
        self.cfg.remove_option(section, last_key)
        self.Save()

    def GetGroups(self, key_path, names):
        for section in self.cfg.sections():
            if section.find(key_path) != -1:
                names.append(key_path)

    def DeleteGroup(self, key_path):
        for section in self.cfg.sections():
            if section.find(key_path) != -1:
                self.cfg.remove_section(section)
        self.Save()

    def Reload(self):
        '''
            如果配置文件加载错误,重新加载时删除原配置文件
        '''
        if os.path.exists(self.config_path):
            os.remove(self.config_path)
        self.cfg.read(self.config_path)


if sys.platform.startswith("win"):
    from .registry import Registry
    from winreg import KEY_ALL_ACCESS, REG_SZ, REG_BINARY, REG_DWORD

    class RegistryConfig:
        def __init__(self, app_name):
            self.app_name = app_name
            base_reg = Registry().Open('SOFTWARE')
            self.reg = self.EnsureOpenKey(base_reg, self.app_name)

        def EnsureOpenKey(self, parent_reg, key):
            # 打开时必须设置注册表有写的权限,否则会提示权限不足
            reg = parent_reg.Open(key, access=KEY_ALL_ACCESS)
            if reg is None:
                reg = parent_reg.CreateKey(key)
            return reg

        def GetDestRegKey(self, key, ensure_open=True):
            '''
                按照/分割线分割多级key,如果是写入操作,则创建所有子健
                如果是读取操作,则不能创建子健,只能打开,如果打开失败,则返回None
                ensure_open:打开子健失败时是否创建子健
            '''
            if -1 == key.find("/"):
                return self.reg, key
            child_keys = key.lstrip('/').split("/")
            last_key = child_keys.pop()
            loop_reg = self.reg
            for child in child_keys:
                if ensure_open:
                    child_reg = self.EnsureOpenKey(loop_reg, child)
                else:
                    child_reg = loop_reg.Open(child, access=KEY_ALL_ACCESS)
                    if child_reg is None:
                        return None, last_key
                loop_reg = child_reg
            return loop_reg, last_key

        def Read(self, key, value=""):
            dest_key_reg, last_key = self.GetDestRegKey(key, ensure_open=False)
            if dest_key_reg is None:
                return value
            try:
                return dest_key_reg.ReadEx(last_key)
            # 键值不存在不要记录错误信息
            except FileNotFoundError:
                return value
            except:
                logger.exception(f'read reg key:{last_key} error')
                assert isinstance(value, str)
                return value

        def ReadInt(self, key, default=-1):
            return int(self.Read(key, str(int(default))))

        def Write(self, key, value):
            try:
                dest_key_reg, last_key = self.GetDestRegKey(key)
                val_type = REG_SZ
                if isinstance(value, bytes):
                    val_type = REG_BINARY
                dest_key_reg.WriteValueEx(last_key, value, val_type=val_type)
            except Exception as e:
                logger.exception('write reg key %s fail', key)

        def WriteInt(self, key, value):
            try:
                dest_key_reg, last_key = self.GetDestRegKey(key)
                dest_key_reg.WriteValueEx(last_key, value, val_type=REG_DWORD)
            except:
                logger.exception('write reg key %s fail', key)

        def Exist(self, key):
            try:
                self.reg.ReadEx(key)
                return True
            except:
                return False

        def DeleteEntry(self, key_val):
            dest_key_reg, value = self.GetDestRegKey(
                key_val, ensure_open=False)
            if dest_key_reg is None:
                return
            try:
                dest_key_reg.DeleteValue(value)
            except:
                logger.debug('delete key_val %s fail', key_val)

        def GetGroups(self, key_path, names):
            if not self.reg.Exist(key_path):
                return
            dest_key_reg, value = self.GetDestRegKey(key_path)
            for name in dest_key_reg.EnumChildKeyNames():
                names.append(name)

        def DeleteGroup(self, key_path):
            self.reg.DeleteKeys(key_path)
    Config = RegistryConfig
elif sys.platform.startswith("linux"):
    Config = LocalfileConfig
