import logging
import os
import subprocess
import abc
from novalapp.syntax import lang
from novalapp.executable import Executable
from novalapp.syntax.syntax import SyntaxThemeManager
from novalapp.util import strutils
from novalapp.util import utils
from novalapp.util import fileutils
from novalapp.common.md5 import get_str_md5
from novalapp.python.interpreter.interpreter import BuiltinPythonInterpreter
from novalapp.python.project.configuration import ProjectConfiguration
from novalapp.python import pythonenv
from novalapp.python.interpreter.exceptions import InterpreterSyntaxError
from .strings import CODECHECK_TOOL_NANE
from . import configkeys

logger = logging.getLogger(__name__)


class BaseCheckTool(abc.ABC):
    """description of class"""
    PLAIN_TEXT_FORMAT = 1
    JSON_OUTPUT_FORMAT = 2

    def __init__(self, name, lang_id, path='', command=''):
        self._name = name
        self._lang_id = lang_id
        self._path = path
        self._enabled = True
        self.exts = SyntaxThemeManager.manager().GetLexer(self._lang_id).Exts
        self._command = command
        self._command_args = []
        self._output_format = self.PLAIN_TEXT_FORMAT
        self._version = BuiltinPythonInterpreter.UNKNOWN_VERSION_NAME
        self._enable_rules = []
        self._fixers = []

    @property
    def fixers(self):
        return self._fixers

    @property
    def enable_rules(self):
        return self._enable_rules

    @property
    def version(self):
        return self._version

    @property
    def output_format(self):
        return self._output_format

    @property
    def command_args(self):
        return self._command_args

    @command_args.setter
    def command_args(self, args):
        self._command_args = args

    @property
    def command(self):
        return self._command

    @property
    def name(self):
        return self._name

    @property
    def enabled(self):
        return self._enabled

    @enabled.setter
    def enabled(self, value):
        self._enabled = value

    @property
    def path(self):
        return self._path

    @property
    def lang_id(self):
        return self._lang_id

    def update_enable_rules(self, rules):
        self._enable_rules = rules

    def contain_file_extension(self, filepath):
        ext = strutils.get_file_extension(filepath)
        return ext in self.exts

    def is_filetool_enabled(self, filepath):
        is_file_contained = self.contain_file_extension(filepath)
        if not is_file_contained:
            utils.get_logger().warning(
                "file %s is not a valid file extension of tool %s", filepath, self.name)
        return self.enabled and is_file_contained

    def parse_file(self, doc, filepath):
        return self.parse_syntax_file(doc, filepath)

    def parse_syntax_file(self, doc, filepath):
        command = self._command
        command += " "
        command += strutils.emphasis_path(filepath)
        utils.get_logger().debug('tool %s run command is %s', self.name, command)
        return self.run_command(doc, command, filepath)

    def get_file_log_path(self, doc, filepath):
        data_out_path = self.get_cache_path(doc)
        file_log_name = get_str_md5(filepath)
        log_file_path = os.path.join(data_out_path, f"{file_log_name}.log")
        return log_file_path

    def run_command(self, doc, command, filepath):
        if utils.is_windows():
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
        else:
            startupinfo = None
        log_file_path = self.get_file_log_path(doc, filepath)
        data_out_path = os.path.dirname(log_file_path)
        fileutils.makedirs(data_out_path)
        utils.get_logger().info('file %s checktool %s log path is %s',
                                filepath, self.name, log_file_path)
        stdout_log = open(log_file_path, "w")
        stderr_log = open(log_file_path, "a")
        process_obj = subprocess.Popen(
            command,
            shell=True,
            startupinfo=startupinfo,
            cwd=doc.GetPath(),
            stdout=stdout_log,
            stderr=stderr_log,
            env=self.get_env(doc)
        )
        process_obj.wait()
        utils.get_logger().debug("tool %s exec command %s returncode is %d",
                                 self.name, command, process_obj.returncode)
        return log_file_path

    def get_cache_path(self, doc):
        dock_cache_path = doc.get_doc_cache_path()
        return os.path.join(dock_cache_path, CODECHECK_TOOL_NANE, self.name)

    def parse_line_msg(self, linetext):
        raise NotImplementedError('You must implemented it in derived class')

    def add_fixer(self, fixer):
        assert fixer.toolname == self.name
        fixer.check_tool = self
        self._fixers.append(fixer)

    def is_rule_fixable(self, rule_id):
        for fixer in self._fixers:
            if fixer.ruleid == rule_id and fixer.toolname == self.name:
                return True
        return False

    def find_fixer(self, rule_id):
        for fixer in self._fixers:
            if fixer.ruleid == rule_id and fixer.toolname == self.name:
                return fixer
        return None

    def fix_file(self, processor, doc, filepath):
        return False

    @abc.abstractmethod
    def build_version(self):
        raise NotImplementedError('You must implemented it in derived class')

    def get_env(self, doc):
        return None


class BasePythonCheckTool(BaseCheckTool):

    def __init__(self, name, interpreter=None):
        super().__init__(name, lang.ID_LANG_PYTHON)
        self._interpreter = interpreter
        if self._interpreter is not None:
            self.update(self._interpreter)

    @property
    def interpreter(self):
        return self._interpreter

    def get_version_output(self):
        args = ["-m", self.name, "--version"]
        exectable = Executable(self._interpreter.path)
        exectable_path = fileutils.get_filepath_from_path(
            self._interpreter.path)
        output = exectable.exec_command_output(args, cwd=exectable_path)
        return output

    def update_command(self):
        if self._interpreter is None:
            return
        exectable = Executable(self._interpreter.path, args=[
                               "-m", self.name] + self.command_args)
        command = exectable.get_cmd()
        logger.info('tool %s codecheck command is %s', self.name, command)
        self._command = command

    def update(self, interpreter):
        self._interpreter = interpreter
        self.enabled = utils.profile_get_int(
            "%s%s" % (self.name, configkeys.TOOL_STATUS_KEY), True)
        if not self.enabled:
            return
        toolpath = self._interpreter.find_tool(self.name)
        logger.info('find tool %s path is %s', self.name, toolpath)
        self.update_command()
        self._path = toolpath
        self.build_version()

    def get_env(self, doc):
        env = os.environ
        project_configuration = ProjectConfiguration(doc)
        python_path_list = project_configuration.LoadPythonPath()
        env[pythonenv.PYTHON_PATH_NAME] = os.pathsep.join(python_path_list)
        return env

    def check_file_syntax(self, filepath):
        try:
            ok, errorfile, lineno, msg = self._interpreter.check_syntax(
                filepath)
            if errorfile == "":
                errorfile = filepath
            if not ok:
                utils.get_logger().error("check fix file %s syntax error:%s", errorfile, msg)
                raise InterpreterSyntaxError(msg)
        except ValueError as ex:
            utils.get_logger().error("check file %s syntax error:%s", filepath, str(ex))
            ok = False
        return ok
