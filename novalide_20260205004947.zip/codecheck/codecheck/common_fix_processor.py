from novalapp import get_app, _
from novalapp.util import utils
from novalapp import globalkeys
from novalapp.lib.pyqt import QMessageBox
from novalapp.editor.textview import TextView
from .common_processor import CommonProcessor
from . import configkeys
from .codeutils import check_git_plugin_installed


class CommonFixProcessor(CommonProcessor):
    def __init__(self, parent, statusbar, processor_name):
        # 代码修复器默认禁止启动,只有在启动修复时才启用
        super().__init__(parent, statusbar, processor_name, False)
        # 被修复的文件数量
        self.fixed_file_count = 0
        self._configs = {}

    def save_configs(self):
        check_mixed_eol = utils.profile_get_int(
            globalkeys.CHECK_EOL_KEY, False)
        self._configs[globalkeys.CHECK_EOL_KEY] = check_mixed_eol
        replace_tabs = utils.profile_get_int(
            globalkeys.CHECK_CODE_EDITOR_TABS_KEY, True)
        self._configs[globalkeys.CHECK_CODE_EDITOR_TABS_KEY] = replace_tabs
        check_file_modify = utils.profile_get_int(
            globalkeys.CHECK_FILE_MODIFY_KEY, True)
        self._configs[globalkeys.CHECK_FILE_MODIFY_KEY] = check_file_modify
        fix_import_nodes = utils.profile_get_int(globalkeys.FIX_IMPORT_NODES_KEY, False)
        self._configs[globalkeys.FIX_IMPORT_NODES_KEY] = fix_import_nodes
        TextView.FILE_MODIFY_ANSWER = QMessageBox.YesToAll
        get_app().MainFrame.reset_filechanged_answer = False

    def check_doc_commit_status(self, doc):
        if not utils.profile_get_int(
            configkeys.PROJECT_FILES_MUSTBE_COMMITED_KEY,
            True
        ):
            return True
        try:
            check_git_plugin_installed()
            from git.repo import Repo, RepofileState
            from git.exceptions import UnmergeError
            repo = Repo(doc.GetPath())
            has_unmerged, commit_files = repo.status()
            if has_unmerged:
                raise UnmergeError(_('Repo has unmerged files!'))
            for commit_file in commit_files:
                if commit_file.file_state in [
                    RepofileState.FILE_MODIFIED_UNSTAGED,
                    RepofileState.FILE_MODIFIED_STAGED,
                    RepofileState.FILE_NEW_STAGED
                ]:
                    utils.get_logger().info(
                        "doc file %s is ready to commit",
                        commit_file.fullpath
                    )
                    self.stop(_('Please commit repo files before fix codes'))
                    return False
        except Exception as ex:
            utils.get_logger().error(str(ex))
            self.stop(str(ex))
            return False
        return True

    def init(self, doc):
        self.save_configs()
        utils.profile_set(globalkeys.CHECK_CODE_EDITOR_TABS_KEY, False)
        utils.profile_set(globalkeys.CHECK_EOL_KEY, False)
        utils.profile_set(globalkeys.FIX_IMPORT_NODES_KEY, False)
        self.fixed_file_count = 0
        if not self.check_doc_commit_status(doc):
            return False
        # 修复文件时禁止一些耗时的操作,以便加快修复速度
        projectview = get_app().MainFrame.projectview
        outlineview = get_app().MainFrame.outlineview
        try:
            projectview.sigFileUpdated.disconnect(
                projectview.update_analysis_data)
            get_app().MainFrame.GetNotebook().currentChanged.disconnect(
                outlineview._update_frame_contents)
            outlineview.show_nonelabel(
                show=True,
                labeltext=_('Fix processor running, Outline view is temporary disabled.')
            )
            outlineview.stop_outline_show(stop=True)
        except TypeError as typex:
            utils.get_logger().exception('init fix processor exception:')
        return super().init(doc)

    def end(self, doc):
        # 恢复被禁止的操作
        projectview = get_app().MainFrame.projectview
        projectview.sigFileUpdated.connect(projectview.update_analysis_data)
        outlineview = get_app().MainFrame.outlineview
        get_app().MainFrame.GetNotebook().currentChanged.connect(
            outlineview._update_frame_contents)
        outlineview.show_nonelabel(show=False)
        outlineview.stop_outline_show(stop=False)
        super().end(doc)

    def restore_configs(self):
        for config_key, value in self._configs.items():
            utils.profile_set(config_key, value)
        get_app().MainFrame.reset_filechanged_answer = True
