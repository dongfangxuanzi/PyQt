# -*- coding: utf-8 -*-
from novalapp import _, get_app
from novalapp.util import utils
from .common_processor import CommonProcessor
from .toolmanager import CodecheckToolManager


class CodecheckProcessor(CommonProcessor):
    '''
        扫描项目所有文件,每隔一段时间执行
        并发送文件路径作为信号发送给接收者,以便其做相应的处理
    '''

    def __init__(self, parent, statusbar):
        super().__init__(parent, statusbar, "Check", False)

    def init(self, doc):
        if not super().init(doc):
            return False
        doc_name = doc.GetModel().name
        utils.get_logger().debug('start check project %s files', doc.GetFilename())
        self._statusbar.emit_statusbar_messgae(
            _('Start check project "%s" code files') % doc_name)
        get_app().MainFrame.projectview.SIG_CLOSE_PROJECT_DOC.emit(doc)
        return True

    def end(self, doc):
        super().end(doc)
        doc_name = doc.GetModel().name
        utils.get_logger().debug('end check project %s files', doc.GetFilename())
        self._statusbar.emit_statusbar_messgae(
            _('Finish check project "%s" code files') % doc_name)

    def run(self, doc, filepath):
        if not super().run(doc, filepath):
            return
        utils.get_logger().debug('check code file %s', filepath)
        self.update_progress(filepath)
        self.check_single_file(doc, filepath)

    def check_single_file(self, doc, filepath, load_messages=True):
        if 0 == len(CodecheckToolManager.manager().CHECK_TOOLS):
            utils.get_logger().error('there is not codecheck tools to check code file %s', filepath)
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            if check_tool.is_filetool_enabled(filepath):
                message_file = check_tool.parse_file(doc, filepath)
                utils.get_logger().debug(
                    'tool %s check code file %s message file is %s',
                    check_tool.name,
                    filepath,
                    message_file
                )
                if load_messages:
                    self.load_message_file(doc, check_tool, message_file)

    def handle_message(self, doc, check_tool, msg):
        if self._stopped:
            utils.get_logger().debug('tool %s stopped when load messages file', check_tool.name)
            return
        self.message_viewer.SIG_APPEND_MESSAGE_ITEM.emit(msg)

    def update_progress(self, filepath):
        self._statusbar.emit_statusbar_messgae(
            _('Checking code file:%s') % filepath)
        super().update_progress(filepath)
