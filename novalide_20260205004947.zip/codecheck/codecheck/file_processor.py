from novalapp import get_app
from novalapp.lib.pyqt import QThread, QMessageBox
from novalapp.util import utils
from novalapp.editor.textview import TextView
from .sched_processor import CodecheckProcessor
from .fix_processor import FixerProcessor
from . import configkeys


class FileProcessor(QThread):
    """description of class"""

    def __init__(self, parent, processor, doc, filepath):
        super().__init__(parent)
        self._parent = parent
        self._processor = processor
        self._doc = doc
        self._filepath = filepath
        self._is_fixprocessor = False
        self._configs = {}
        self.save_configs()

    def save_configs(self):
        if isinstance(self._processor, FixerProcessor) and utils.profile_get_int(configkeys.AUTOFIX_FILE_SAVE_KEY, False):
            self._is_fixprocessor = True
            self._configs[configkeys.CLOSE_OPENDOC_KEY] = utils.profile_get_int(
                configkeys.CLOSE_OPENDOC_KEY, False)
            TextView.FILE_MODIFY_ANSWER = QMessageBox.YesToAll
            get_app().MainFrame.reset_filechanged_answer = False

    def run(self):
        self._processor.set_running()
        if self._is_fixprocessor:
            utils.profile_set(configkeys.CLOSE_OPENDOC_KEY, False)
            utils.get_logger().info('processor %s fixing update file %s',
                                    self._processor.name, self._filepath)
            self._processor.fix_single_file(self._doc, self._filepath)
            self.restore_configs()
        else:
            utils.get_logger().info('processor %s checking update file %s',
                                    self._processor.name, self._filepath)
            if isinstance(self._processor, CodecheckProcessor):
                self._processor.check_single_file(self._doc, self._filepath)
            else:
                self._parent._plugin._check_processor.check_single_file(
                    self._doc, self._filepath)
        self._processor.set_stopped()

    def restore_configs(self):
        for config_key, value in self._configs.items():
            utils.profile_set(config_key, value)
        get_app().MainFrame.reset_filechanged_answer = True
