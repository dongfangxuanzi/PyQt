from threading import Event
import os
from novalapp.util import utils
from novalapp.python.interpreter.exceptions import InterpreterSyntaxError
from novalapp import _
from novalapp.python.interpreter.exceptions import InterpretertoolNotExistError
from .common_fix_processor import CommonFixProcessor
from . import configkeys
from .toolmanager import CodecheckToolManager
from .exceptions import FixfileError
from .strings import FIX_PROCESSER_NAME


class FixerProcessor(CommonFixProcessor):
    """description of class"""

    def __init__(self, parent, statusbar):
        super().__init__(parent, statusbar, FIX_PROCESSER_NAME)
        self.fixed_warnings = 0
        self.event = Event()

    def init(self, doc):
        self.fixed_warnings = 0
        utils.get_logger().debug('start fix project %s files', doc.GetFilename())
        self.message_viewer._plugin._check_processor.init(doc)
        return super().init(doc)

    def end(self, doc):
        super().end(doc)
        self.message_viewer._plugin._check_processor.end(doc)
        utils.get_logger().debug('end fix project %s files', doc.GetFilename())
        doc_name = doc.GetModel().name
        self.restore_configs()
        self._statusbar.emit_statusbar_messgae(
            _('Finish fix project "%s" code files') % doc_name)

    def run(self, doc, filepath):
        if not super().run(doc, filepath):
            utils.get_logger().error('fixer is stopped')
            return
        utils.get_logger().debug('fix code file %s', filepath)
        self.update_progress(filepath)
        self.fix_single_file(doc, filepath)

    def fix_single_file(self, doc, filepath):
        self.message_viewer.SiG_CLEAR_FILE_MESSAGE_ITEMS.emit(filepath)
        if 0 == len(CodecheckToolManager.manager().CHECK_TOOLS):
            utils.get_logger().error('there is not codecheck tools to check code file %s', filepath)
        messages_count = {}
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            if check_tool.is_filetool_enabled(filepath):
                message_file = check_tool.get_file_log_path(doc, filepath)
                if not os.path.exists(message_file):
                    self.message_viewer._plugin._check_processor.check_single_file(
                        doc, filepath, load_messages=False)
                count = self.get_messages_count(check_tool, message_file)
                messages_count[check_tool.name] = count
                try:
                    check_tool.fix_file(self, doc, filepath)
                except (InterpreterSyntaxError, InterpretertoolNotExistError, FixfileError) as ex:
                    self.stop(str(ex))
        self.message_viewer._plugin._check_processor.check_single_file(
            doc, filepath)
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            if check_tool.is_filetool_enabled(filepath):
                message_file = check_tool.get_file_log_path(doc, filepath)
                count = self.get_messages_count(check_tool, message_file)
                diff = messages_count[check_tool.name] - count
                utils.get_logger().debug("code file %s tool %s messages count diff %d",
                                         filepath, check_tool.name, diff)
                self.fixed_warnings += diff
        self.fixed_file_count += 1
        if utils.profile_get_int(configkeys.CLOSE_OPENDOC_KEY, False):
            self.message_viewer.SiG_CLOSE_FILEDOC.emit(filepath)
        else:
            self.message_viewer.SiG_RELOAD_FILEDOC.emit(filepath)

    def get_messages_count(self, check_tool, message_file):
        return len(self.load_messages(check_tool, message_file))

    def handle_message(self, doc, check_tool, msg):
        rule_id = msg.ruleid
        can_fix = check_tool.is_rule_fixable(rule_id)
        if can_fix and not self.stopped:
            fixer = check_tool.find_fixer(rule_id)
            self.message_viewer.SIG_FIX_MESSAGE_ITEM.emit(fixer, doc, msg)
            self.event.wait()
            self.event.clear()
            if fixer.autofix and utils.profile_get_int(configkeys.CHECK_FILE_SYNTAX_KEY, True):
                check_tool.check_file_syntax(msg.filepath)

    def update_progress(self, filepath):
        self._statusbar.emit_statusbar_permanent_messgae(
            _('Fixing code file:%s') % filepath)
        super().update_progress(filepath)
