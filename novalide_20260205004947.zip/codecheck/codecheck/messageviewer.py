import os
import csv
from typing import Optional, List
from novalapp.lib.pyqt import (
    QLabel,
    QRadioButton,
    QHBoxLayout,
    Qt,
    QFileDialog,
    QProgressBar,
    QCoreApplication,
    QCursor,
    QFrame,
    pyqtSignal,
    QSizePolicy,
    QVBoxLayout,
    QTableWidget,
    QMessageBox,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView
)
from novalapp.util import fileutils, pathutils
from novalapp.util import ui_utils
from novalapp.util import utils
from novalapp.project import document as projectdocument
from novalapp.bars.menubar import NewQMenu
from novalapp.widgets.imagebutton import ImageButton
from novalapp import _, get_app, newid
from .toolmanager import CodecheckToolManager
from .basefix import BaseFixer
from .message import Message
from . import configkeys
from .exceptions import FixfileError
from .pkgres import get_start_image_path, get_stop_image_path

ID_COPY_MESSAGE = newid()
ID_COPY_RULE = newid()
ID_COPY_PATH = newid()
ID_EXPORT_ALL = newid()
ID_GOTO_PATH = newid()
ID_REPAIR_MESSAGE = newid()
ID_VIEW_LOG = newid()


class MessageViewer(QFrame):
    """description of class"""
    SIG_APPEND_MESSAGE_ITEM = pyqtSignal(Message)
    SIG_FIX_MESSAGE_ITEM = pyqtSignal(
        BaseFixer, projectdocument.ProjectDocument, Message)
    SiG_CLEAR_FILE_MESSAGE_ITEMS = pyqtSignal(str)
    SIG_INIT_PROCESSOR = pyqtSignal()
    SIG_END_PROCESSOR = pyqtSignal(str)
    SIG_UPDATE_PROGRESS = pyqtSignal(int)
    SIG_STOP_PROCESSOR = pyqtSignal(str)
    SiG_CLOSE_FILEDOC = pyqtSignal(str)
    SiG_RELOAD_FILEDOC = pyqtSignal(str)

    def __init__(self, parent=None, plugin=None):
        super().__init__(parent)
        self._plugin = plugin

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.setLayout(layout)
        hbox = QHBoxLayout()
        hbox.setAlignment(Qt.AlignLeft)
        hbox.addWidget(QLabel(_('Code')))

        self.code_check_radio = QRadioButton(_('Check'))
        self.code_check_radio.setChecked(True)
        hbox.addWidget(self.code_check_radio)

        self.code_fix_radio = QRadioButton(_('Fix'))
        hbox.addWidget(self.code_fix_radio)

        self.code_autofix_radio = QRadioButton(_('BatchFix'))
        hbox.addWidget(self.code_autofix_radio)

        self.start_run_img = get_app().GetImage(get_start_image_path())
        self.run_btn = ImageButton(_("Start run."))
        self.run_btn.setEnabled(True)
        self.run_btn.clicked.connect(self.run)
        self.run_btn.setIcon(self.start_run_img)
        hbox.addWidget(self.run_btn)

        self.stop_run_img = get_app().GetImage(get_stop_image_path())
        self.stop_btn = ImageButton(_("Stop run."))
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_run)
        self.stop_btn.setIcon(self.stop_run_img)
        hbox.addWidget(self.stop_btn)
        self.create_progress(hbox)
        layout.addLayout(hbox)
        columns = [_('Line'), _('Col'), _('Message'),
                   _('Rule'), _('Filepath'), _('Tool')]
        self.table = QTableWidget(0, len(columns), self)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.doubleClicked.connect(self.click_message)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.OnContextMenu)
        # self.table.itemSelectionChanged.connect(self.on_select)
        self.table.setColumnWidth(0, 50)
        self.table.setColumnWidth(1, 50)
        self.table.setColumnWidth(2, 370)
        self.table.setColumnWidth(3, 80)
        self.table.setColumnWidth(4, 710)
        self.table.setColumnWidth(5, 80)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table.setHorizontalHeaderLabels(columns)
        self.show_verticalheader(True)
        layout.addWidget(self.table)
        self._doc = None
        self._processor = None
        # 表格右键弹出菜单
        self.menu = None
        self.SIG_APPEND_MESSAGE_ITEM.connect(self.append_message_item)
        self.SIG_FIX_MESSAGE_ITEM.connect(self.autofix_message_item)
        self.SiG_CLEAR_FILE_MESSAGE_ITEMS.connect(self.clear_file_messages)
        self.SIG_INIT_PROCESSOR.connect(self.init_processor)
        self.SIG_END_PROCESSOR.connect(self.end_processor)
        self.SIG_UPDATE_PROGRESS.connect(self.update_progress)
        self.SIG_STOP_PROCESSOR.connect(self.stop_processor)
        self.SiG_CLOSE_FILEDOC.connect(self.close_file_doc)
        self.SiG_RELOAD_FILEDOC.connect(self.reload_doc)

    @property
    def processor(self):
        return self._processor

    @property
    def doc(self):
        return self._doc

    @doc.setter
    def doc(self, proj):
        self._doc = proj

    def reload_doc(self, filepath):
        filedoc = get_app().GetDocumentManager().GetDocument(filepath)
        if filedoc is not None:
            filedoc.reload()

    def close_file_doc(self, filepath):
        filedoc = get_app().GetDocumentManager().GetDocument(filepath)
        if filedoc is not None:
            filedoc.DeleteAllViews()

    def create_progress(self, hlayout):
        self.pb = QProgressBar()
        hlayout.addWidget(self.pb)
        self.pb.setVisible(False)

    def showprogress(self, visible=True):
        self.pb.setVisible(visible)

    def update_state(self):
        if self._processor is None or self._processor.running or not self._processor.use_codecheck(self._doc):
            self.run_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            self.code_check_radio.setEnabled(False)
            self.code_autofix_radio.setEnabled(False)
            self.code_fix_radio.setEnabled(False)
        else:
            self.run_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
            self.code_check_radio.setEnabled(True)
            self.code_autofix_radio.setEnabled(True)
            self.code_fix_radio.setEnabled(True)

    def init_processor(self):
        self.update_state()
        self.set_current_processor()
        self.showprogress()
        self.pb.setMaximum(self._processor.total_file_count)

    def update_progress(self, curval):
        utils.get_logger().debug("cur %s file count is %d, total file count is %d",
                                 self._processor.name, curval, self.pb.maximum())
        self.pb.setValue(curval)
        # 告诉qt在处理复杂逻辑工作的时候同时处理其他工作,并返回用户调用之处
        QCoreApplication.processEvents()

    def stop_processor(self, reason):
        if self._processor == self.get_fix_processor():
            QMessageBox.critical(self, _("Fix error"), reason)
        else:
            QMessageBox.critical(self, _("Check error"), reason)

    def get_fix_processor(self):
        if utils.profile_get_int(
                self._doc.GetKey(configkeys.ENABLE_FIX_2TO3_KEY), False):
            return self._plugin._fix2to3_processor
        return self._plugin._fix_processor

    def end_processor(self, processor_name):
        if processor_name != self._processor.name:
            return
        self.update_state()
        self.showprogress(False)
        if self._processor == self._plugin._fix_processor:
            QMessageBox.information(self, _("Fix success"), _(
                "Fix total %d code files, %d warnings") % (self._processor.fixed_file_count, self._processor.fixed_warnings))
        elif self._processor == self._plugin._fix2to3_processor:
            QMessageBox.information(self, _("Fix2to3 success"), _(
                "Fix total %d code files") % self._processor.fixed_file_count)

    def autofix_message_item(self, fixer, doc, msg):
        line = msg.line
        if fixer.reduce_line:
            line -= 1
        try:
            fixer.auto_fix_msg(doc, Message(
                line, msg.column, msg.ruleid, msg.filepath, msg.msg, msg.toolname, msg.fixers))
        except FixfileError as ex:
            self._processor.stop(str(ex))
        self._processor.event.set()

    def check_processor_running(self):
        if self._processor.running:
            if self._processor == self._plugin._check_processor:
                QMessageBox.warning(self, get_app().GetAppName(), _(
                    'Codecheck process is running'))
            elif self._processor == self.get_fix_processor():
                QMessageBox.warning(
                    self, get_app().GetAppName(), _('Fix process is running'))
            return True
        return False

    def close_window(self):
        if utils.profile_get_int(
                configkeys.CHECK_CODECHECK_PROCESS_RUNNING_KEY, True):
            return not self.check_processor_running()
        else:
            if self._processor and self._processor.running:
                self._processor.stop(_("User exit..."))
            return True

    def set_current_processor(self):
        if self.code_autofix_radio.isChecked():
            if self._processor == self._plugin._check_processor or self._processor != self.get_fix_processor():
                self._processor.enabled = False
            self.set_processor(self.get_fix_processor())
            self._processor.enabled = True
        elif self.code_check_radio.isChecked():
            if self._processor == self.get_fix_processor():
                self._processor.enabled = False
            self.set_processor(self._plugin._check_processor)
            self._processor.enabled = True

    def OnContextMenu(self):
        row = self.table.currentRow()
        if row == -1:
            return
        if self.menu is None:
            self.menu = NewQMenu(self)
            self.menu.Append(ID_COPY_MESSAGE, _(
                "Copy message"), handler=self.copy_message)
            self.menu.Append(ID_COPY_RULE, _("Copy rule"),
                             handler=self.copy_rule)
            self.menu.Append(ID_COPY_PATH, _("Copy path"),
                             handler=self.copy_path)
            self.menu.Append(ID_REPAIR_MESSAGE, _(
                "Repair"), handler=self.fix_message_item, tester=self.update_repair_menu_item)
            self.menu.Append(ID_EXPORT_ALL, _("Export messages"),
                             handler=self.export_all)
            self.menu.Append(ID_GOTO_PATH, _(
                "Open path in explorer"), handler=self.goto_path)
            self.menu.Append(ID_VIEW_LOG, _("View log"),
                             handler=self.view_msg_log)
        self.menu.popup(QCursor.pos())

    def view_msg_log(self):
        row = self.table.currentRow()
        filepath = self.table.item(row, 4).text()
        tool_name = self.table.item(row, 5).text()
        check_tool = CodecheckToolManager.manager().find_tool(tool_name)
        logpath = check_tool.get_file_log_path(self._doc, filepath)
        pathutils.safe_open_file_directory(logpath)

    def copy_message(self):
        row = self.table.currentRow()
        message = self.table.item(row, 2).text()
        ui_utils.copytoclipboard(message)

    def copy_rule(self):
        row = self.table.currentRow()
        rule = self.table.item(row, 3).text()
        ui_utils.copytoclipboard(rule)

    def copy_path(self):
        row = self.table.currentRow()
        path = self.table.item(row, 4).text()
        ui_utils.copytoclipboard(path)

    def export_all(self):
        columns = []
        for i in range(self.table.columnCount()):
            column_label = self.table.horizontalHeaderItem(i).text()
            columns.append(column_label)
        default_file_name = "%s_messages.csv" % self._doc.GetModel().name
        filename, filetype = QFileDialog.getSaveFileName(
            self,
            _('Export messages'),
            os.path.join(os.getcwd(), default_file_name),
            _("CSV File") + " (*.csv)"
        )
        if filename == "":
            return
        csv_file_path = fileutils.opj(filename)
        with open(csv_file_path, "w", newline='') as file_obj:
            writer = csv.writer(file_obj)
            writer.writerow(columns)
            for row in range(self.table.rowCount()):
                line = self.table.item(row, 0).text()
                col = self.table.item(row, 1).text()
                message = self.table.item(row, 2).text()
                path = self.table.item(row, 4).text()
                rule_id = self.table.item(row, 3).text()
                tool_name = self.table.item(row, 5).text()
                writer.writerow([line, col, message, rule_id, path, tool_name])

    def goto_path(self):
        row = self.table.currentRow()
        path = self.table.item(row, 4).text()
        pathutils.safe_open_file_directory(path)

    def set_processor(self, processor):
        self._processor = processor

    def update_repair_menu_item(self):
        return self.is_fix_enabled()

    def is_fix_enabled(self):
        row = self.table.currentRow()
        if -1 == row:
            return False
        rule_id = self.table.item(row, 3).text()
        tool_name = self.table.item(row, 5).text()
        check_tool = CodecheckToolManager.manager().find_tool(tool_name)
        can_fix = check_tool.is_rule_fixable(rule_id)
        return can_fix

    def run(self):
        self.start_run()

    def start_run(self, files: Optional[List]=None):
        assert not isinstance(files, bool)
        self._doc = get_app().get_current_project()
        if self._doc is None:
            QMessageBox.critical(self, _('Error'), _(
                'There is no active project'))
            return
        if self.code_fix_radio.isChecked():
            self.fix_message_item()
        else:
            self.set_current_processor()
            get_app().MainFrame.projectview.Rundoc(
                self._doc,
                [self._processor],
                files,
                stop_running_doc=False
            )

    def stop_run(self):
        self._processor.stop(_('User stoped') + '...')

    def fix_message_item(self):
        if self.check_processor_running():
            return
        row = self.table.currentRow()
        if row == -1:
            QMessageBox.information(self, _('Waning'), _(
                'you must select one fix item'))
            return
        col = int(self.table.item(row, 1).text())
        path = self.table.item(row, 4).text()
        rule_id = self.table.item(row, 3).text()
        toolitem = self.table.item(row, 5)
        fixers = toolitem.data(Qt.UserRole)
        tool_name = toolitem.text()
        check_tool = CodecheckToolManager.manager().find_tool(tool_name)
        line = int(self.table.item(row, 0).text())
        fixer = check_tool.find_fixer(rule_id)
        if fixer is None:
            QMessageBox.information(self, get_app().GetAppName(), _(
                'Rule %s could not be fixed') % rule_id)
            return
        if fixer.reduce_line:
            line -= 1
        message = self.table.item(row, 2).text()
        if not fixer.fix_message(self._doc, Message(line, col, rule_id, path, message, tool_name, fixers)):
            QMessageBox.critical(self, _('Error'), _("Fix %s fail") % rule_id)

    def append_message_item(self, msg):
        insertrow = 0
        self.table.insertRow(insertrow)
        lineitem = QTableWidgetItem(str(msg.line))
        lineitem.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 0, lineitem)

        colitem = QTableWidgetItem(str(msg.column))
        colitem.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 1, colitem)

        messageitem = QTableWidgetItem(msg.msg)
        self.table.setItem(insertrow, 2, messageitem)

        ruleitem = QTableWidgetItem(msg.ruleid)
        ruleitem.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 3, ruleitem)

        pathitem = QTableWidgetItem(msg.filepath)
        self.table.setItem(insertrow, 4, pathitem)

        toolitem = QTableWidgetItem(msg.toolname)
        toolitem.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 5, toolitem)
        toolitem.setData(Qt.UserRole, msg.fixers)

    def show_verticalheader(self, visible):
        if visible:
            self.table.verticalHeader().show()
        else:
            self.table.verticalHeader().hide()

    def click_message(self, index):
        row = self.table.currentRow()
        line = int(self.table.item(row, 0).text()) - 1
        col = int(self.table.item(row, 1).text())
        path = self.table.item(row, 4).text()
        get_app().GotoView(path, lineNum=line, colno=col, load_outline=False)

    def clear_messages(self):
        # 清空表格所有内容
        self.table.clearContents()
        while self.table.rowCount():
            self.table.removeRow(0)

    def clear_file_messages(self, filepath):
        row_count = self.table.rowCount()
        for i in range(row_count - 1, -1, -1):
            cell_path = self.table.item(i, 4).text()
            if fileutils.ComparePath(cell_path, filepath):
                self.table.removeRow(i)
