from novalapp.lib.pyqt import QCheckBox, QTableWidgetItem, pyqtSignal
from novalapp import _
from novalapp.util import utils
from .baseconfig import CommonPythonOptionPanel, RulesSearcher, ToolRulesLoader
from ..pkgres import get_flake8_rules_path
from ..strings import FLAKE8_TOOL_NAME


class Flake8RulesSearcher(RulesSearcher):
    """description of class"""

    def __init__(self, parent, res_file, name=None):
        super().__init__(parent, res_file, FLAKE8_TOOL_NAME, name)

    def run(self):
        toolrules = self.load_data()
        for data in self._parent.datas:
            rule_enabled = self.is_rule_enabled(toolrules, data[0])
            try:
                if self._name is None or self._name == "":
                    self._parent.SIG_LOAD_RULE_MSG.emit(
                        data[0], data[1], rule_enabled)
                else:
                    if data[0].lower().find(self._name) != -1:
                        self._parent.SIG_LOAD_RULE_MSG.emit(
                            data[0], data[1], rule_enabled)
            except RuntimeError as ex:
                utils.get_logger().error("%s", str(ex))


class ToolFlake8RulesLoader(Flake8RulesSearcher, ToolRulesLoader):

    def __init__(self, parent, res_file):
        Flake8RulesSearcher.__init__(self, parent, res_file)

    def get_ruleid(self, data):
        return data[0]

    def run(self):
        Flake8RulesSearcher.run(self)
        self.load_message_counter()


class Flake8OptionPanel(CommonPythonOptionPanel):
    """
    """
    SIG_LOAD_RULE_MSG = pyqtSignal(str, str, bool)

    def __init__(self, parent, **kwargs):
        super().__init__(
            parent,
            ["", _("Ruleno"), _("AutoFix"), _("Description")],
            FLAKE8_TOOL_NAME
        )
        self.SIG_LOAD_RULE_MSG.connect(self.load_rule)

    def init_table(self):
        self.table.setColumnWidth(0, 20)
        self.table.setColumnWidth(1, 50)
        self.table.setColumnWidth(2, 55)

    def get_resfile_path(self):
        self.rules_file_path = get_flake8_rules_path()

    def search_rules(self):
        rulename = self.search_rules_ctrl.text()
        self.clear_rules()
        Flake8RulesSearcher(self, self.rules_file_path,
                            rulename.lower()).start()

    def load_rules(self):
        ToolFlake8RulesLoader(self, self.rules_file_path).start()

    def load_rule(self, ruleid, text, checked):
        if not self.is_rule_load(ruleid, checked):
            return
        autofix = self.find_fixer(ruleid)[1]
        row = self.insert_table_row()

        chkbox = QCheckBox("")
        chkbox.setChecked(checked)
        self.table.setCellWidget(row, 0, chkbox)

        ruleid_item = QTableWidgetItem(ruleid)
        self.table.setItem(row, 1, ruleid_item)

        autofix_flag = _('Yes') if autofix else _('No')
        autofix_item = QTableWidgetItem(autofix_flag)
        self.table.setItem(row, 2, autofix_item)

        text_item = QTableWidgetItem(text)
        self.table.setItem(row, 3, text_item)
