from novalapp.lib.pyqt import QCheckBox, QTableWidgetItem, pyqtSignal
from novalapp.util import utils
from novalapp import _
from ..pkgres import get_pylint_rules_path
from ..strings import PYLINT_TOOL_NAME
from .. import configkeys
from .baseconfig import (
    CommonPythonOptionPanel,
    RulesSearcher,
    ToolRulesLoader,
    MessageCounter
)


class PylintRulesSearcher(RulesSearcher):
    """description of class"""

    def __init__(self, parent, res_file, name=None):
        super().__init__(parent, res_file, PYLINT_TOOL_NAME, name)

    def run(self):
        toolrules = self.load_data()
        for data in self._parent.datas:
            rule_enabled = self.is_rule_enabled(toolrules, data[1])
            try:
                if self._name is None or self._name == "":
                    self._parent.SIG_LOAD_RULE_MSG.emit(
                        data[1], data[0], data[2], rule_enabled)
                else:
                    if data[1].lower().find(self._name) != -1 or data[0].lower().find(self._name) != -1:
                        self._parent.SIG_LOAD_RULE_MSG.emit(
                            data[1], data[0], data[2], rule_enabled)
            except RuntimeError as ex:
                utils.get_logger().error("%s", str(ex))


class ToolPylintRulesLoader(PylintRulesSearcher, ToolRulesLoader):

    def __init__(self, parent, res_file):
        PylintRulesSearcher.__init__(self, parent, res_file)

    def get_ruleid(self, data):
        return data[1]

    def run(self):
        PylintRulesSearcher.run(self)
        self.load_message_counter()


class PylintOptionPanel(CommonPythonOptionPanel):
    """
    """
    SIG_LOAD_RULE_MSG = pyqtSignal(str, str, str, bool)

    def __init__(self, parent, **kwargs):
        columns = ["", _("Ruleno"), _("Rulename"), _(
            "Fix"), _("AutoFix"), _("Description")]
        super().__init__(parent, columns, PYLINT_TOOL_NAME)
        self.SIG_LOAD_RULE_MSG.connect(self.load_rule)

    def create_fix_buttons(self, button_hbox):
        self.enable_fix_button = self.create_tool_button(_("Fix"), button_hbox)
        self.enable_fix_button.toggled.connect(self.show_fix_rules)
        super().create_fix_buttons(button_hbox)

    def init_table(self):
        self.table.setColumnWidth(0, 20)
        self.table.setColumnWidth(1, 50)
        self.table.setColumnWidth(3, 30)
        self.table.setColumnWidth(4, 45)

    def load_message_counter(self, message_counter: MessageCounter):
        super().load_message_counter(message_counter)
        self.enable_fix_button.setText(
            _("Fix") + "(%d)" % message_counter.fix_num)

    def show_fix_rules(self):
        if self.enable_fix_button.isChecked():
            self.enabled_button.setChecked(False)
            self.enable_autofix_button.setChecked(False)
            self.not_enabled_button.setChecked(False)

    def search_rules(self):
        rulename = self.search_rules_ctrl.text()
        self.clear_rules()
        PylintRulesSearcher(self, self.rules_file_path,
                            rulename.lower()).start()

    def get_resfile_path(self):
        self.rules_file_path = get_pylint_rules_path()

    def load_rules(self):
        ToolPylintRulesLoader(self, self.rules_file_path).start()

    def load_rule(self, ruleid, rulename, text, checked):
        if not self.is_rule_load(ruleid, checked):
            return
        fix, autofix = self.find_fixer(ruleid)
        if self.enable_fix_button.isChecked() and not fix:
            return

        row = self.insert_table_row()
        chkbox = QCheckBox("")
        chkbox.setChecked(checked)
        self.table.setCellWidget(row, 0, chkbox)

        ruleid_item = QTableWidgetItem(ruleid)
        self.table.setItem(row, 1, ruleid_item)

        rulename_item = QTableWidgetItem(rulename)
        self.table.setItem(row, 2, rulename_item)

        fix_flag = _('Yes') if fix else _('No')
        fix_item = QTableWidgetItem(fix_flag)
        self.table.setItem(row, 3, fix_item)

        autofix_flag = _('Yes') if autofix else _('No')
        autofix_chkbox = QCheckBox(autofix_flag)
        if autofix:
            autofix_chkbox.setChecked(True)
        else:
            autofix_chkbox.setChecked(False)
        if fix:
            autofix_chkbox.setEnabled(True)
            autofix_chkbox.clicked.connect(self.update_autofix_status)
        else:
            autofix_chkbox.setEnabled(False)
        self.table.setCellWidget(row, 4, autofix_chkbox)

        text_item = QTableWidgetItem(text)
        self.table.setItem(row, 5, text_item)

    def update_autofix_status(self):
        autofix_chkbox = self.sender()
        if autofix_chkbox.isChecked():
            autofix_chkbox.setText(_('Yes'))
        else:
            autofix_chkbox.setText(_('No'))

    def update_autofix_rules(self):
        for row in range(self.table.rowCount()):
            ruleid = self.table.item(row, 1).text()
            fix, autofix = self.find_fixer(ruleid)
            if fix:
                autofix_chkbox = self.table.cellWidget(row, 4)
                is_checked = autofix_chkbox.isChecked()
                if autofix != is_checked:
                    autofix_key = configkeys.TOOL_RULES_AUTOFIX_KEY % (
                        PYLINT_TOOL_NAME, ruleid)
                    utils.profile_set(autofix_key, is_checked)
                    fixer = self.fix_tool.find_fixer(ruleid)
                    fixer.autofix = is_checked

    def OnOK(self, optionsDialog):
        super().OnOK(optionsDialog)
        self.update_autofix_rules()
        return True

    def show_enable_rules(self):
        super().show_enable_rules()
        if self.enabled_button.isChecked():
            self.enable_fix_button.setChecked(False)

    def show_not_enable_rules(self):
        super().show_not_enable_rules()
        if self.not_enabled_button.isChecked():
            self.enable_fix_button.setChecked(False)

    def show_autofix_rules(self):
        super().show_autofix_rules()
        if self.enable_autofix_button.isChecked():
            self.enable_fix_button.setChecked(False)
