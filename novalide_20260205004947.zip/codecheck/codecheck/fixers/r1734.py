from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintR1734Fixer(PylintFixer):
    '''
    规则说明: 赋值空列表不要使用list(),应使用[]
    '''

    def __init__(self):
        super().__init__('R1734', True)
        self._reduce_line = False

    @staticmethod
    def fix_list_node(textview, value_node):
        if value_node.as_string() == "list()":
            fix_range = get_node_range(value_node)
            nodestr = '[]'
            fix_range.replace_with_text(textview, nodestr)
            return True
        return False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if not node:
            return False
        if isinstance(node, nodes.Assign):
            return self.fix_list_node(textview, node.value)
        if isinstance(node, nodes.Return) and isinstance(node.value, nodes.Call):
            return self.fix_list_node(textview, node.value)
        return False
