from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintE0711Fixer(PylintFixer):
    '''
    规则说明: 抛出未实现方法异常要用raise NotImplementedError而不是raise NotImplemented
    '''

    def __init__(self):
        super().__init__('E0711', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if isinstance(node, nodes.Raise):
            fix_range = get_node_range(node)
            nodestr = node.as_string()
            fixstr = nodestr.replace("NotImplemented", "NotImplementedError")
            fix_range.replace_with_text(textview, fixstr)
            return True
        return False
