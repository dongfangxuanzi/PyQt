import re
from novalapp.widgets import simpledialog
from astroid import nodes
from ..basefix import fix_code_file_msg
from ..pylint_fix import PylintFixer
from ..codeutils import ImportVisitor, get_add_range


class PylintE0601Fixer(PylintFixer):
    '''
    规则说明: 
    '''

    def __init__(self):
        super().__init__('E0601', True)
        self._reduce_line = False

    @staticmethod
    def check_if_main(statement):
        is_main_statement = False
        if isinstance(statement, nodes.If) and isinstance(statement.test, nodes.Compare):
            is_main_statement = isinstance(statement.test.left, nodes.Name) and \
                statement.test.left.name == "__name__" and isinstance(
                    statement.test.ops[0][1], nodes.Const) and statement.test.ops[0][1].value == "__main__"
        return is_main_statement

    @staticmethod
    def get_init_values():
        init_values = {
            'None': 'init None',
            "''": 'init empty str',
            "[]": 'init empty list',
            "{}": 'init empty dict',
            'set()': 'init empty set',
            "-1": 'init int(-1)',
            '0': 'init int(0)'
        }
        return init_values

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)
        pattern = r"Using variable '(\w+)' before assignment \(used-before-assignment\)"
        res = re.search(pattern, msg.msg)
        visitor = ImportVisitor(
            textview.ModuleAnalyzer.Module, textview)
        variable_name = None
        if not res:
            return False
        variable_name = res.groups()[0]
        for node in textview.ModuleAnalyzer.Module.body:
            if self.check_if_main(node):
                for child in node.body:
                    if isinstance(child, nodes.Assign):
                        for target in child.targets:
                            if isinstance(target, nodes.AssignName) and target.name == variable_name:
                                title = "Create global variable name"
                                descrption = "Please choose one global '%s' value" % variable_name
                                init_values = self.get_init_values()
                                choices = init_values.values()
                                sel = simpledialog.asklist(
                                    title, descrption, choices, selection=0, master=text_ctrl)
                                if sel != -1:
                                    insert_line = visitor.get_import_line()
                                    add_range = get_add_range(
                                        insert_line + 1, 0)
                                    init_global_value = list(
                                        init_values.keys())[sel]
                                    add_range.add_text(
                                        textview,
                                        "%s = %s" % (
                                            variable_name, init_global_value) + "\n"
                                    )
                                    return True
        return False
