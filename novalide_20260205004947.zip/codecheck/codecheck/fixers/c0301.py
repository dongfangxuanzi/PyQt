import os
import re
from astroid import nodes
from novalapp.lib.qsci import QsciLexerPython
from novalapp.util import strutils, fileutils, utils
from ..codeutils import get_node_range, DEFAULT_TAB_BLANKS, FixRange, get_file_linetext
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg


class PylintC0301Fixer(PylintFixer):
    '''
    规则说明:修复语句过长
    '''

    def __init__(self):
        super().__init__('C0301', True)
        self._reduce_line = False

    @staticmethod
    def find_node(textview, line):
        node = textview.ModuleAnalyzer.find_line_node(line)
        if isinstance(node, (nodes.ImportFrom, nodes.FunctionDef, nodes.Assign)):
            return node
        else:
            linenodes = []
            textview.ModuleAnalyzer.find_line_range_nodes(line, linenodes)
            if linenodes and isinstance(linenodes[0], (nodes.ImportFrom, nodes.Assign)):
                return linenodes[0]
        return None

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)
        line = msg.line
        linenode = self.find_node(textview, line)
        if not linenode:
            return False
        res = re.search(r"Line too long \((\d+)/(\d+)\)", msg.msg)
        if not res:
            return False
        linetext = get_file_linetext(msg.filepath, line - 1)
        utils.get_logger().debug(
            'get text of line %d in filename %s is:%s,text length is %d',
            line,
            msg.filepath,
            linetext,
            len(linetext)
        )
        # 行号内容发生改变,停止修复
        if len(linetext) != int(res.groups()[0]):
            utils.get_logger().warning(
                'line %d of filename %s has changed, stop fix rule %s',
                line,
                msg.filepath,
                msg.ruleid
            )
            return False
        line_offset_blanks = linenode.col_offset * ' '
        linetext = text_ctrl.get_line_text(line - 1)
        comment_index = linetext.find('#')
        pos = text_ctrl.position_from_linecol(line - 1, comment_index)
        style = text_ctrl.styleAt(pos)
        if comment_index != -1 and style == QsciLexerPython.Comment:
            fixrange = FixRange(line)
            comment_text = linetext[comment_index:]
            fixrange.replace_line(textview, linetext[0:comment_index])
            fixrange.add_text(
                textview, line_offset_blanks + comment_text + os.linesep)
            return True
        if isinstance(linenode, nodes.ImportFrom):
            modname = linenode.modname
            if linenode.level is not None:
                # 如果相对导入全是dot符合,则包或模块名称为空字符串
                level_name = "." * linenode.level
                if not strutils.is_none_empty(modname):
                    modname = level_name + modname
                else:
                    modname = level_name
            fix_str = 'from %s import (\n' % modname
            for name, asname in linenode.names[0:-1]:
                import_name = "%s%s,\n" % (DEFAULT_TAB_BLANKS, name)
                fix_str += import_name
            fix_str += "%s%s\n" % (DEFAULT_TAB_BLANKS, linenode.names[-1][0])
            fix_str += ")"
            fix_range = get_node_range(linenode)
            fix_range.replace_with_text(textview, fix_str)
            return True
        if isinstance(linenode, nodes.FunctionDef):
            args = linenode.args
            args.lineno = args.args[0].lineno
            args.col_offset = args.args[0].col_offset
            args.end_lineno = args.args[-1].end_lineno
            args.end_col_offset = args.args[-1].end_col_offset

            default_args = args.defaults or [] + args.kw_defaults or []
            if default_args:
                args.end_lineno = default_args[-1].end_lineno
                args.end_col_offset = default_args[-1].end_col_offset

            argstr = args.as_string()
            arglist = argstr.split(',')
            if args.kwarg is not None:
                arglist = arglist[0:-1]
            argnum = len(arglist)
            fix_range = get_node_range(args)
            fix_line_head = line_offset_blanks + DEFAULT_TAB_BLANKS
            fix_str = ''
            fix_str += os.linesep
            for i, arg in enumerate(arglist):
                fix_str += fix_line_head
                fix_str += arg.strip()
                if i < argnum - 1:
                    fix_str += ","
                fix_str += os.linesep
                if i == argnum - 1:
                    fix_str += fix_line_head
            fix_range.replace_with_text(textview, fix_str)
            return True
        if isinstance(linenode, nodes.Assign):
            if isinstance(linenode.value, (nodes.List, nodes.Tuple)):
                has_comment_in_lines = self.has_comment_in_node_lines(linenode.value)
                utils.get_logger().info(
                    'node:%s start line:%d,end line:%d has comment:%s',
                    linenode.value,
                    linenode.value.lineno,
                    linenode.value.end_lineno,
                    strutils.bool_to_str(has_comment_in_lines)
                )
                if has_comment_in_lines:
                    return False
                fixrange = get_node_range(linenode.value)
                fixstr = '[' if isinstance(linenode.value, nodes.List) else '('
                fixstr += os.linesep
                fix_line_head = line_offset_blanks + DEFAULT_TAB_BLANKS
                elts = linenode.value.elts
                eltnum = len(elts)
                for i, elt in enumerate(elts):
                    fixstr += fix_line_head
                    # 这里必须使用原始字符串,使用as_string会对原始字符串进行转义,
                    # 从而改变原始字符串内容
                    if isinstance(elt, nodes.Const) and isinstance(elt.value, str):
                        str_quote = self.get_line_str_quote(elt)
                        utils.get_logger().debug(
                            "str quote of line %d is %s",
                            elt.lineno,
                            str_quote
                        )
                        # 字符串被r包裹
                        if str_quote == "r":
                            fixstr += "r"
                            # 字符串引号在r字符右移1位
                            elt.col_offset += 1
                            str_quote = self.get_line_str_quote(elt)
                            elt.col_offset -= 1
                        if str_quote != "'" and str_quote != '"':
                            utils.get_logger().error(
                                "find str quote in line %d of file %s error",
                                elt.lineno,
                                msg.filepath
                            )
                            return False
                        fixstr += (str_quote + elt.value + str_quote)
                    else:
                        fixstr += elt.as_string()
                    if i < eltnum - 1:
                        fixstr += ","
                    fixstr += os.linesep
                fixstr += line_offset_blanks
                fixstr += "]" if isinstance(linenode.value,
                                            nodes.List) else ')'
                fixstr += os.linesep
                fixrange.replace_with_text(textview, fixstr)
                return True
        return False

    def has_comment_in_node_lines(self, node):
        '''
        检查节点开始结束行之间是否有注释
        '''
        start_line = node.lineno
        end_line = node.end_lineno
        utils.get_logger().debug(
            'node:%s start line:%d,end line:%d',
            node,
            start_line,
            end_line
        )
        root_file = node.root().file
        content = fileutils.get_file_content(root_file, allow_exception=False)
        if content is None:
            return False
        for i, line in enumerate(content.splitlines()[start_line:end_line]):
            if line.strip().startswith('#'):
                utils.get_logger().info(
                    'file %s line %d start with comment:#',
                    root_file,
                    start_line + i
                )
                return True
        return False

    def get_line_str_quote(self, node):
        '''
        获取行字符串是用单引号还是双引号括起来
        '''
        linetext = get_file_linetext(node.root().file, node.lineno - 1)
        if linetext is None:
            return '"'
        return linetext[node.col_offset]
