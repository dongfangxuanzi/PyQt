import copy
from novalapp.widgets import simpledialog
from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import DEFAULT_TAB_BLANKS


class PylintC0116Fixer(PylintFixer):
    '''
    规则说明: 函数或方法缺少文档字符串说明
    '''

    def __init__(self):
        super().__init__('C0116', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(
            textview.ModuleAnalyzer.Module).find_scope(msg.line)
        function_or_method_string = ''
        if isinstance(scope, nodes.FunctionDef):
            function_or_method_string = self.get_function_string(
                scope, text_ctrl)
            if function_or_method_string is None:
                return False
            text_ctrl.GotoPos(msg.line, 0)
            textview.AddText(function_or_method_string + "\n")
            return True
        return False

    def get_function_string(self, func_node, text_ctrl):
        title = ''
        if isinstance(func_node.parent, nodes.ClassDef):
            title = "Fix method docstring"
        else:
            title = "Fix function docstring"
        choices = ['simple docstring', 'detail docstring']
        sel = simpledialog.asklist(
            title, "Please choose one docstring option", choices, selection=0, master=text_ctrl)
        if sel == -1:
            return None
        if 0 == sel:
            return self.get_function_simple_string(func_node)
        if 1 == sel:
            return self.get_function_detail_string(func_node)

    @staticmethod
    def get_function_simple_string(func_node):
        indent_blanks = DEFAULT_TAB_BLANKS + func_node.position.col_offset * ' '
        function_or_method_string = indent_blanks + "'''" + "'''"
        return function_or_method_string

    @staticmethod
    def get_function_detail_string(func_node):
        indent_blanks = DEFAULT_TAB_BLANKS + func_node.position.col_offset * ' '
        function_or_method_string = indent_blanks + "'''"
        function_or_method_string += "\n"
        function_or_method_string += "\n"
        args = copy.copy(func_node.args.args)
        if isinstance(func_node.parent, nodes.ClassDef):
            if args[0].as_string() == "self" or args[0].as_string() == "cls":
                args.remove(args[0])
        for arg in args:
            arg_name_str = f":param {arg.name}:"
            function_or_method_string += indent_blanks + arg_name_str
            function_or_method_string += "\n"
            arg_type_str = f":type {arg.name}:"
            function_or_method_string += indent_blanks + arg_type_str
            function_or_method_string += "\n"
        function_or_method_string += indent_blanks + ":return:"
        function_or_method_string += "\n"
        function_or_method_string += indent_blanks + ":rtype:"
        function_or_method_string += "\n"

        function_or_method_string += indent_blanks + "'''"
        function_or_method_string += "\n"
        return function_or_method_string
