# -*- coding: utf-8 -*-
'''
Name:        e0602.py
Purpose:     E0602:未定义的变量规则修复器
修复方法:
导入未识别的模块或从模块中导入未识别成员

Author:      wukan

Created:     2023-11-16
Copyright:   (c) wukan 2023
Licence:     <your licence>
'''
import re
import os
from novalapp.util import fileutils
from novalapp.python.analysis.module_analyzer import _code_parser
from novalapp.python.apis import memberkeys
from novalapp.widgets import simpledialog
from novalapp import get_app
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import ImportVisitor, get_add_range


class PylintE0602Fixer(PylintFixer):
    '''
    规则说明: 未定义的变量
    '''

    def __init__(self):
        super().__init__('E0602', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)
        res = re.search("Undefined variable '(.*)'", msg.msg)
        undefined_name = res.groups()[0]
        mdloader = get_app().intellisence_mananger.GetModule(
            undefined_name
        )
        visitor = ImportVisitor(
            textview.ModuleAnalyzer.Module, textview)
        if mdloader:
            if not visitor.is_import_exist(undefined_name):
                insert_line = visitor.get_import_line()
                add_range = get_add_range(insert_line + 1, 0)
                add_range.add_text(textview, "import %s" %
                                   undefined_name + "\n")
                return True
        else:
            all_modules = get_app().intellisence_mananger.load_modules()
            import_names = []
            import_files = []
            for mdloader in all_modules:
                modname = mdloader.Name + "." + undefined_name
                with open(mdloader.apifile) as freader:
                    for line in freader:
                        regstr = r"%s\?\d" % modname
                        if re.search(regstr, line):
                            member_data = mdloader.get_member(undefined_name)
                            if memberkeys.PATH_KEY_NAME not in member_data or mdloader.is_package():
                                import_names.append(mdloader.Name)
                                import_files.append(mdloader.path)

            if import_names:
                if len(import_names) == 1:
                    sel = 0
                elif len(import_names) > 1:
                    sel = simpledialog.asklist(
                        "Find undefined variable",
                        "Please choose one import module of undefined variable",
                        import_names,
                        selection=0,
                        master=text_ctrl
                    )
                    if sel == -1:
                        return False
                insert_line = visitor.get_import_line()
                add_range = get_add_range(insert_line + 1, 0)
                import_module_path = import_names[sel]
                import_module_path = self.path_to_relativepath(
                    msg.filepath, import_module_path, import_files[sel])
                add_range.add_text(
                    textview,
                    "from %s import %s" % (
                        import_module_path, undefined_name) + "\n"
                )
                return True
        return False

    @staticmethod
    def get_level_path(file_path, import_file_path):
        level = 1
        module_dir_path = os.path.dirname(file_path)
        import_dir_path = os.path.dirname(import_file_path)
        parent_dir_path = module_dir_path
        while True:
            if level >= 5:
                break
            if fileutils.ComparePath(import_dir_path, parent_dir_path):
                break
            parent_dir_path = os.path.dirname(parent_dir_path)
            level += 1
        return level * '.'

    def path_to_relativepath(self, file_path, import_module_path, import_file_path):
        module_path = _code_parser.analyzer.get_relative_path(file_path)
        paths = module_path.split(".")
        import_paths = import_module_path.split(".")
        if paths[0] == import_paths[0]:
            if len(paths) > len(import_paths):
                level = self.get_level_path(file_path, import_file_path)
                import_module_path = level + import_paths[-1]
            else:
                pass
        return import_module_path
