from astroid import nodes
from ..basefix import fix_code_file_msg
from ..pylint_fix import PylintFixer
from ..codeutils import FixRange


class PylintW1406Fixer(PylintFixer):
    '''
    规则说明:unicode字符串不需要加u前缀
    '''

    def __init__(self):
        super().__init__('W1406', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        line = msg.line
        self.load_module(textview, msg.filepath)
        node = self.find_msg_node(textview, msg, use_column=True)
        if isinstance(node, nodes.Const) and isinstance(node.value, str):
            linetext = text_ctrl.get_line_text(line - 1)
            if linetext.find("u'") != -1 or linetext.find('u"') != -1:
                fixrange = FixRange(line)
                newlinetext = linetext.replace("u'", "'").replace('u"', '"')
                fixrange.replace_line(
                    textview, newlinetext)
                return True
        return False
