from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ..pylint_fix import PylintCommonFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintW0410Fixer(PylintCommonFixer):
    '''
    规则说明:from __future__ import xx语句必须放在导入语句最前面
    '''

    def __init__(self):
        super().__init__('W0410', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
        line = msg.line
        scope = ScopeFinder(
            textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if node is None:
            return False
        if isinstance(node, nodes.ImportFrom) and node.modname == "__future__":
            pnode = node.parent
            if isinstance(pnode, nodes.Module):
                # 为了防止结点变动或者位置变换导致修复错误,必须满足以上条件才能进行修复功能
                # 先使用通用sarif格式修复,如果不能修复则使用自定义方法修复
                if super().fix_message(doc, msg):
                    return True
                first_nodoc_node = pnode.body[0]
                exchange_fix_range = get_node_range(first_nodoc_node)
                exchange_fix_range.replace_with_text(
                    textview, node.as_string())
                fix_range = get_node_range(node)
                fix_range.replace_with_text(
                    textview, first_nodoc_node.as_string())
                return True
        return False
