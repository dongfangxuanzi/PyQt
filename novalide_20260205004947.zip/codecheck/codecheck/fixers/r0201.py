import re
from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from novalapp.widgets import simpledialog
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range
from ..codeutils import get_add_range, ImportVisitor


class PylintR0201Fixer(PylintFixer):
    '''
    规则说明:成员方法没有引用类成员,可以转换为staticmethod,classmethod或者abstractmethod
    '''

    def __init__(self):
        super().__init__('R0201', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)
        line = msg.line
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        if isinstance(scope, nodes.FunctionDef):
            choices = ["convert to abstractmethod",
                       "convert to staticmethod", 'convert to classmethod']
            sel = simpledialog.asklist(
                "Convert to",
                "Please choose one method option",
                choices,
                selection=0,
                master=text_ctrl
            )
            blanks = scope.position.col_offset * ' '
            add_range = get_add_range(scope.position.lineno, 0)
            if sel == 0:
                visitor = ImportVisitor(
                    textview.ModuleAnalyzer.Module, textview)
                if visitor.is_import_exist('abc'):
                    add_range.add_text(textview, blanks +
                                       "@abc.abstractmethod" + "\n")
                elif visitor.is_fromimport_exist('abc', 'abstractmethod'):
                    add_range.add_text(textview, blanks +
                                       "@abstractmethod" + "\n")
                else:
                    insert_line = visitor.get_import_line()
                    add_range.add_text(textview, blanks +
                                       "@abc.abstractmethod" + "\n")
                    add_range = get_add_range(insert_line + 1, 0)
                    add_range.add_text(textview, "import abc" + "\n")
                return True
            else:
                args = scope.args
                args.lineno = args.args[0].lineno
                args.col_offset = args.args[0].col_offset
                args.end_lineno = args.args[-1].end_lineno
                args.end_col_offset = args.args[-1].end_col_offset
                argstr = args.as_string()
                if sel == 1:
                    replace_argstr = re.sub(r"self\s*,", "", argstr).strip()
                    arg_range = get_node_range(args)
                    arg_range.replace_with_text(textview, replace_argstr)
                    add_range.add_text(textview, blanks +
                                       "@staticmethod" + "\n")
                elif sel == 2:
                    replace_argstr = re.sub(
                        r"self\s*,", "cls,", argstr).strip()
                    arg_range = get_node_range(args)
                    arg_range.replace_with_text(textview, replace_argstr)
                    add_range.add_text(textview, blanks +
                                       "@classmethod" + "\n")
                return True
        return False
