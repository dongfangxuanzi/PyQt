from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintW0402Fixer(PylintFixer):
    '''
    规则说明: 过期的模块
    '''
    REPLACE_DEPRECATED_MODULES = {
        "optparse": "argparse",
        "tkinter.tix": "tkinter.ttk",
        "xml.etree.cElementTree": "xml.etree.ElementTree",
        "imp": "importlib",
        "distutils": "setuptools"
    }

    def __init__(self):
        super().__init__('W0402', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(msg.line)
        if isinstance(node, nodes.Import):
            modname = node.names[0][0]
            if modname in self.REPLACE_DEPRECATED_MODULES:
                replace_modname = self.REPLACE_DEPRECATED_MODULES[modname]
                fixrange = get_node_range(node)
                fixstr = "import %s" % replace_modname
                fixrange.replace_with_text(textview, fixstr)
                return True
        return False
