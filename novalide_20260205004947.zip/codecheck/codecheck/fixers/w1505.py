from novalapp.python.parser.node_utils import infer_all
from astroid import nodes
from ..pylint_fix import PylintCommonFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintW1505Fixer(PylintCommonFixer):
    '''
    规则说明: 过期的函数和方法
    '''
    REPLACE_DEPRECATED_METHODS = {
        "logging.warn": "logging.warning",
        "logging.Logger.warn": "logging.Logger.warning",
        "logging.LoggerAdapter.warn": "logging.LoggerAdapter.warning",
        "base64.encodestring": "base64.encodebytes",
        "base64.decodestring": "base64.decodebytes"
    }

    def __init__(self):
        super().__init__('W1505', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(line)
        if isinstance(node, nodes.Expr):
            if isinstance(node.value.func, nodes.Attribute):
                func_name = node.value.func.attrname
            elif isinstance(node.value.func, nodes.Name):
                func_name = node.value.func.name
            else:
                return False
            # 为了防止结点变动或者位置变换导致修复错误,必须满足以上条件才能进行修复功能
            # 先使用通用sarif格式修复,如果不能修复则使用自定义方法修复
            if super().fix_message(doc, msg):
                return True
            results = infer_all(node.value.func)
            for inferred in results:
                qnames = {inferred.qname(), func_name}
                for qname in qnames:
                    if qname in self.REPLACE_DEPRECATED_METHODS:
                        replace_qname = self.REPLACE_DEPRECATED_METHODS[qname]
                        replace_func_name = replace_qname.split(".")[-1]
                        fixrange = get_node_range(node.value.func)
                        fixstr = node.value.func.expr.as_string() + "." + replace_func_name
                        fixrange.replace_with_text(textview, fixstr)
                        return True
        return False
