# -*- coding: utf-8 -*-
'''
Name:        w0702.py
Purpose:     W0702:捕获异常没有具体的异常类型规则修复器
修复方法:
弹出所有内建异常类型,用户选择某个异常类型

Author:      wukan

Created:     2023-11-16
Copyright:   (c) wukan 2023
Licence:     <your licence>
'''
import builtins
from novalapp.widgets import simpledialog
from astroid import nodes
from ..pylint_fix import PylintCommonFixer
from ..basefix import fix_code_file_msg
from ..codeutils import FixRange


class PylintW0702Fixer(PylintCommonFixer):
    '''
    规则说明:捕获异常没有具体的异常类型
    '''

    def __init__(self):
        super().__init__('W0702', False)
        self._reduce_line = False
        self.sel = -1

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        line = msg.line
        node = textview.ModuleAnalyzer.find_line_node(line)
        if not isinstance(node, nodes.ExceptHandler):
            return False
        if super().fix_message(doc, msg):
            return True
        choices = []
        for name in dir(builtins):
            builtinobj = getattr(builtins, name)
            if isinstance(builtinobj, type) and issubclass(builtinobj, Exception):
                choices.append(name)
        self.sel = simpledialog.asklist(
            "Fix bare except",
            "Please choose one except option",
            choices,
            selection=0,
            master=text_ctrl
        )
        if self.sel == -1:
            return False
        fix_range = FixRange(line)
        fix_range.replace_line(textview, "except %s:" % choices[self.sel])
        return True
