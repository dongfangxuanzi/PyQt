import os
import re
from novalapp.util import fileutils
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import FixRange


class PylintC0114Fixer(PylintFixer):
    '''
    规则说明: 模块缺少文档字符串说明
    '''
    MAX_DOC_LINE = 20

    def __init__(self):
        super().__init__('C0114', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        filecontent = fileutils.get_file_content(msg.filepath)
        lines = filecontent.splitlines()
        match_doc_comment = self.is_matched_doc_comment(lines)
        if not match_doc_comment:
            textview.InsertCommentTemplate()
        else:
            self.file_fix_doc(textview, lines)
        return True

    @classmethod
    def is_matched_doc_comment(cls, filelines):
        match_doc_reg = r'^#\s*(name|author|created|date|modify|modified)\s*:'
        match_doc_comment = False
        for i, linestr in enumerate(filelines):
            if linestr.startswith('#'):
                if re.match(match_doc_reg, linestr, re.I):
                    match_doc_comment = True
            elif i > cls.MAX_DOC_LINE:
                break
        return match_doc_comment

    @staticmethod
    def get_fix_comment_line(linestr):
        return linestr.lstrip('#').strip()

    @staticmethod
    def is_encoding_line(linestr):
        return re.match(r'^[ \t\f]*#.*coding[:=][ \t]*([-\w.]+)', linestr)

    @staticmethod
    def is_shebang_line(linestr):
        return re.match(r'#!\s*(/usr/bin/python|/usr/env/bin\s*python)', linestr)

    @classmethod
    def file_fix_doc(cls, textview, filelines):
        start_line = -1
        end_line = -1
        fixstr = "'''"
        fixstr += os.linesep
        for i, linestr in enumerate(filelines[0:cls.MAX_DOC_LINE]):
            if linestr.strip() == "":
                if start_line == -1:
                    continue
                else:
                    break
            elif linestr.startswith('#'):
                if cls.is_encoding_line(linestr) or cls.is_shebang_line(linestr):
                    continue
                if start_line == -1:
                    start_line = i
                    fixstr += cls.get_fix_comment_line(linestr)
                    fixstr += os.linesep
                else:
                    end_line = i + 1
                    fixstr += cls.get_fix_comment_line(linestr)
                    fixstr += os.linesep
            else:
                break
        fixstr += "'''"
        fixstr += os.linesep
        start_line = textview.get_shebang_encoding_line()
        fixrange = FixRange(start_line + 1, 0, end_line + 1, 0)
        fixrange.replace_with_text(textview, fixstr)
