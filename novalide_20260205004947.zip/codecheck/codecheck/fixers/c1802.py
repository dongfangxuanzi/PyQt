from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range


class PylintC1802Fixer(PylintFixer):
    '''
    规则说明: 使用列表隐式表达式判断bool值
    '''

    def __init__(self):
        super().__init__('C1802', True)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if not node:
            return False
        if isinstance(node, nodes.Call) and (
            isinstance(node.func, nodes.Name) and node.func.name == 'len'
        ):
            fix_range = get_node_range(node)
            nodestr = node.args[0].as_string()
            fix_range.replace_with_text(textview, nodestr)
            return True
        return False
