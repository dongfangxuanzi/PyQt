from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg


class PylintC2201Fixer(PylintFixer):
    '''
    规则说明: 
    '''

    def __init__(self):
        super().__init__('C2201', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        kwargs.get('textview')
