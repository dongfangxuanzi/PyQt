from ..pylint_fix import PylintCommonFixer
from ..basefix import fix_code_file_msg


class PylintW0212Fixer(PylintCommonFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('W0212', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
