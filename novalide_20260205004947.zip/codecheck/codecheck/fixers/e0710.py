import logging
from astroid import nodes
import astroid
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_add_range, get_node_range

log = logging.getLogger(__name__)


class PylintE0710Fixer(PylintFixer):
    '''
    规则说明:异常类没有继承自Exception
    '''

    def __init__(self):
        super().__init__('E0710', True)
        self._reduce_line = False

    def is_raise_node_line(self, textview, line):
        node = textview.ModuleAnalyzer.find_line_node(line)
        if not isinstance(node, nodes.Raise):
            return False
        return True

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        if not self.is_raise_node_line(textview, line):
            return False
        node = textview.ModuleAnalyzer.find_line_node(line)
        try:
            for infered in node.exc.func.infer():
                if infered == astroid.Uninferable:
                    continue
                if isinstance(infered, nodes.ClassDef):
                    position = infered.position
                    if not infered.bases:
                        add_range = get_add_range(
                            position.lineno, position.end_col_offset)
                        add_range.add_text(textview, "(Exception)")
                    else:
                        base_class_node = infered.bases[0]
                        fixrange = get_node_range(base_class_node)
                        fixrange.replace_with_text(textview, "Exception")
                    return True
        except astroid.InferenceError as ex:
            log.error(str(ex))
        return False
