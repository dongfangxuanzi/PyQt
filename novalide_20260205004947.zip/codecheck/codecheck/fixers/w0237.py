import re
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg


class PylintW0237Fixer(PylintFixer):
    '''
    规则说明: 继承方法的参数名称改变了
    '''

    def __init__(self):
        super().__init__('W0237', False)
        self._reduce_line = False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
        regstr = r"Parameter '(\w+)' has been renamed to '(\w+)' in (overridden|overriding) '(.*)' method"
        res = re.search(regstr, msg.msg)
        if not res:
            return False
        results = res.groups()
        node = textview.ModuleAnalyzer.find_line_node(msg.line)
        if isinstance(node, nodes.FunctionDef):
            self.replace_variable_name_in_scope(
                textview, node, results[1], results[0])
            return True
        return False
