import re
from astroid import nodes
from novalapp.widgets import simpledialog
from ..pylint_fix import PylintFixer
from ..basefix import fix_code_file_msg
from ..codeutils import get_node_range, FixNode


class PylintW0612Fixer(PylintFixer):
    '''
    规则说明:未使用的变量
    '''

    def __init__(self):
        super().__init__('W0612', True)
        self._reduce_line = False
        self.sel = 1

    @staticmethod
    def get_node_scope(node):
        parent_node = node
        while parent_node:
            if hasattr(parent_node, 'body') and not isinstance(parent_node, nodes.Tuple):
                return parent_node
            parent_node = parent_node.parent
        return None

    @staticmethod
    def is_parent_one_statement(node):
        parent = node.parent
        if not hasattr(parent, "body"):
            return False
        if isinstance(parent, nodes.FunctionDef):
            if len(parent.body) == 1 and node == parent.body[0]:
                return True
        elif isinstance(parent, nodes.If):
            if len(parent.body) == 1 and node == parent.body[0]:
                return True
            if len(parent.orelse) == 1 and node == parent.orelse[0]:
                return True
        return False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg)
        res = re.search(
            r"Unused variable '(\w+)' \(unused-variable\)", msg.msg)
        if not node or not res:
            return False
        unused_name = res.groups()[0]
        parent_scope = self.get_node_scope(node)
        if isinstance(parent_scope, nodes.For) and (
            isinstance(parent_scope.iter, nodes.Call) and (
                isinstance(parent_scope.iter.func, nodes.Name) and parent_scope.iter.func.name == "enumerate"
            )
        ):
            loop_index, loop_name = parent_scope.target.elts
            if node != loop_index:
                return False
            assert unused_name == loop_index.as_string()
            fix_func_node = FixNode(parent_scope.iter, textview)
            arg_names = ",".join([arg.as_string() for arg in parent_scope.iter.args])
            fix_func_node.replace_node_with_text(arg_names)
            fix_target_node = FixNode(parent_scope.target, textview)
            fix_target_node.replace_node_with_text(loop_name.as_string())
            return True
        # 下面的修复操作不支持自动修复
        if self.is_autofix_msg:
            return False
        if isinstance(node, nodes.Assign):
            left = node.targets[0]
            if isinstance(left, nodes.AssignName):
                if left.as_string() == unused_name:
                    choices = ["Delete left expression",
                               "Delete total expression"]
                    if not self.is_autofix_msg:
                        self.sel = simpledialog.asklist(
                            "Delete unused variable",
                            "Please choose one delete option",
                            choices,
                            selection=0,
                            master=text_ctrl
                        )
                    else:
                        if self.is_parent_one_statement(node):
                            self.sel = 0
                        else:
                            self.sel = 1
                    if self.sel == 0:
                        fix_range = get_node_range(node)
                        value_str = node.value.as_string()
                        fix_range.replace_with_text(textview, value_str)
                        return True
                    if self.sel == 1:
                        fix_range = get_node_range(node)
                        fix_range.replace_with_text(textview, '')
                        textview.delete_line(node.lineno - 1)
                        return True
        return False
