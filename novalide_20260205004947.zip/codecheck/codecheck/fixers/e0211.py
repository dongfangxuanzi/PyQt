from ..pylint_fix import PylintCommonFixer


class PylintE0211Fixer(PylintCommonFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('E0211', False)
