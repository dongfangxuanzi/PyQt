import subprocess
import os
import shutil
import re
import json
from novalapp.util.cmp_func import py_sorted
from novalapp.util import strutils, fileutils
from novalapp.util import utils
from novalapp.executable import Executable
from novalapp.common.configparser import ConfigWriter
from novalapp.common import md5
from novalapp.common.compat import ensure_string
from novalapp import _
from .pkgres import get_pylint_rc_path, get_flake8_config_path, _get_pkg_res_path
from . import configkeys
from .flake8_fix import Flake8Fixer
from .fixers import (
    PylintW0611Fixer,
    PylintC0327Fixer,
    PylintE0001Fixer,
    PylintF0010Fixer,
    PylintC2503Fixer,
    PylintW0404Fixer,
    PylintE0711Fixer,
    PylintR0402Fixer,
    PylintR1705Fixer,
    PylintW0107Fixer,
    PylintC0303Fixer,
    PylintC0411Fixer,
    PylintC0325Fixer,
    PylintR0205Fixer,
    PylintR1725Fixer,
    PylintC0114Fixer,
    PylintC0116Fixer,
    PylintC0410Fixer,
    PylintW0614Fixer,
    PylintW0235Fixer,
    PylintC0123Fixer,
    PylintW0511Fixer,
    PylintW1201Fixer,
    PylintW0612Fixer,
    PylintR0201Fixer,
    PylintC0121Fixer,
    PylintW0109Fixer,
    PylintE0710Fixer,
    PylintW0702Fixer,
    PylintR1720Fixer,
    PylintC0202Fixer,
    PylintE0211Fixer,
    PylintE0213Fixer,
    PylintC0301Fixer,
    PylintW1505Fixer,
    PylintW1512Fixer,
    PylintW0402Fixer,
    PylintW0237Fixer,
    PylintE0602Fixer,
    PylintC0200Fixer,
    PylintW0410Fixer,
    PylintC1802Fixer,
    PylintR1734Fixer,
    PylintR1735Fixer,
    PylintR1716Fixer,
    PylintW0102Fixer,
    PylintC0103Fixer,
    PylintW1401Fixer,
    PylintR1714Fixer,
    PylintI0021Fixer,
    PylintC0413Fixer,
    PylintW1406Fixer,
    PylintR1723Fixer,
    PylintC0206Fixer,
    PylintC2201Fixer,
    PylintW0212Fixer,
    PylintE0601Fixer,
    PylintW0123Fixer
)
from .basetool import BasePythonCheckTool
from .strings import PYLINT_TOOL_NAME, FLAKE8_TOOL_NAME, AUTOPEP8_TOOL_NAME
from .exceptions import FixfileError
from .message import Message
from .pylint_fix import PylintCommonFixer


class Flake8Tool(BasePythonCheckTool):
    """description of class"""

    def __init__(self, interpreter=None):
        super().__init__(FLAKE8_TOOL_NAME, interpreter)
        self._command_args.append('--config')
        self._command_args.append(get_flake8_config_path())
        self._command_args.append('--exit-zero')
        self.add_fixer(Flake8Fixer(self))

    @staticmethod
    def build_common_arguments(rules):
        '''
        flake8和autopep8工具共有的参数
        '''
        args = []
        if rules is not None:
            args.append('--select')
            args.append(','.join(rules))
        return args

    @staticmethod
    def compare_file_content(filepath, newfilepath):
        src_file_hash = md5.get_normal_file_md5(filepath)
        dest_file_hash = md5.get_normal_file_md5(newfilepath)
        utils.get_logger().debug(
            "src file %s md5 hash is %s, dest file %s md5 has is %s",
            filepath,
            src_file_hash,
            newfilepath,
            dest_file_hash
        )
        return src_file_hash != dest_file_hash

    @classmethod
    def build_arguments(cls, rules):
        '''
            构造flake8工具运行的参数
        '''
        args = cls.build_common_arguments(rules)
        args.append('--exit-zero')
        return args

    def parse_line_msg(self, linetext):
        result = re.search(r'(.*):(\d+):(\d+): (\w+) (.*)', linetext)
        if result is None:
            return None
        path, line, col, rule, messgae = result.groups()
        msg = Message(int(line), int(col), rule, path, messgae, self.name, [])
        return msg

    def update(self, interpreter):
        super().update(interpreter)
        if self._fixers:
            self._fixers[0].update_fix_rules()

    def fix_file(self, processor, doc, filepath):
        autopep8_path = self._interpreter.find_tool(AUTOPEP8_TOOL_NAME)
        utils.get_logger().info('find tool %s path is %s',
                                AUTOPEP8_TOOL_NAME, autopep8_path)
        command_args = ["--global-config", get_flake8_config_path()]
        exectable = Executable(self._interpreter.path, args=[
                               "-m", AUTOPEP8_TOOL_NAME] + command_args)
        command = exectable.get_cmd()
        command += " "
        command += strutils.emphasis_path(filepath)
        utils.get_logger().info('tool %s fix command is %s', AUTOPEP8_TOOL_NAME, command)
        backup_file_path = "%s.bak" % (filepath)
        startupinfo = exectable.hide_startupinfo()
        utils.get_logger().debug('backfile is %s', backup_file_path)
        stdout_log = open(backup_file_path, "w")
        process_obj = subprocess.Popen(
            command,
            shell=True,
            startupinfo=startupinfo,
            cwd=doc.GetPath(),
            stdout=stdout_log,
            stderr=subprocess.PIPE
        )
        process_obj.wait()
        stdout_log.close()
        if process_obj.returncode != 0:
            utils.get_logger().info("tool %s exec command %s returncode is %d",
                                    AUTOPEP8_TOOL_NAME, command, process_obj.returncode)
            utils.get_logger().error("tool %s exec command %s error", AUTOPEP8_TOOL_NAME, command)
            utils.get_logger().error(
                'error output is %s',
                ensure_string(process_obj.stderr.read())
            )
            raise FixfileError(_("tool %s fix file %s error") %
                               (AUTOPEP8_TOOL_NAME, filepath))
        if utils.profile_get_int(configkeys.CHECK_FILE_SYNTAX_KEY, True):
            ok = self.check_file_syntax(backup_file_path)
            if not ok:
                return False
        # 如果修复后的文件内容没有发生改变, 无需替换文件
        if self.compare_file_content(filepath, backup_file_path):
            utils.get_logger().debug(
                "code file %s content is changed after autopep8 fix, replace with back file %s",
                filepath,
                backup_file_path
            )
            shutil.copy(backup_file_path, filepath)
        else:
            utils.get_logger().debug(
                "code file %s content is not changed after autopep8 fix",
                filepath
            )
        # 不管是否有无替换文件, 删除生成的备份文件
        os.remove(backup_file_path)
        utils.get_logger().debug("remove autopep8 fixed backfile %s success", backup_file_path)
        return True

    def build_version(self):
        if self._interpreter is None:
            return
        output = self.get_version_output()
        lines = output.splitlines()
        if not lines:
            utils.get_logger().error("build tool %s version error", self._path)
            return
        self._version = lines[0].strip().split()[0]

    def is_rule_fixable(self, rule_id):
        return rule_id in self._fixers[0].fix_rules

    def find_fixer(self, rule_id):
        if not self.is_rule_fixable(rule_id):
            return None
        return self._fixers[0]

    def update_enable_rules(self, rules):
        super().update_enable_rules(rules)
        flake8_conf_path = get_flake8_config_path()
        cfg_writer = ConfigWriter(
            flake8_conf_path, space_around_delimiters=False)
        if rules is None:
            enabled_rules_text = "all"
        else:
            enabled_rules_text = ",".join(rules)
        utils.get_logger().debug("flake8 enable rules is %s", enabled_rules_text)
        try:
            cfg_writer.write_cofig(
                'flake8', 'select', enabled_rules_text)
        except Exception as ex:
            utils.get_logger().exception(
                'update flake8 conf file %s exception:',
                flake8_conf_path
            )
            fileutils.safe_remove(flake8_conf_path)
            raise ex


class PylintTool(BasePythonCheckTool):
    """description of class"""

    def __init__(self, interpreter=None, json_output=False):
        super().__init__(PYLINT_TOOL_NAME, interpreter)
        if json_output:
            self._output_format = self.JSON_OUTPUT_FORMAT
            self._command_args = ['--fix', '-f', 'sarif']

            fixrules_file = os.path.join(_get_pkg_res_path(), "fixrules.json")
            utils.get_logger().info("fix rules file is %s", fixrules_file)

            with open(fixrules_file) as fr:
                fix_rules = json.load(fr)
                for key, value in fix_rules.items():
                    if isinstance(value, str):
                        bval = strutils.str_to_bool(value)
                        self.add_fixer(PylintCommonFixer(key, bval))
                    elif isinstance(value, list):
                        assert (value[0] in ["true", "false"])
                        fixer_class = utils.get_class_from_dynamicimport_module(value[1])
                        fixer = fixer_class()
                        self.add_fixer(fixer)
                    else:
                        raise RuntimeError('invalid fix rule value')
        else:
            self._command_args = [
                '--msg-template',
                "{abspath}:{line}:{column}: {msg_id}: {msg} ({symbol})"
            ]
            self.add_fixer(PylintW0511Fixer())
            self.add_fixer(PylintC0123Fixer())
            self.add_fixer(PylintE0710Fixer())
            self.add_fixer(PylintW0402Fixer())
            self.add_fixer(PylintW1512Fixer())
            self.add_fixer(PylintW0102Fixer())

        self._command_args.append('--rcfile')
        self._command_args.append(get_pylint_rc_path())
        self._command_args.append('--exit-zero')
        self.add_fixer(PylintW0611Fixer())
        self.add_fixer(PylintC0327Fixer())
        self.add_fixer(PylintE0001Fixer())
        self.add_fixer(PylintF0010Fixer())
        self.add_fixer(PylintC2503Fixer())
        self.add_fixer(PylintW0404Fixer())
        self.add_fixer(PylintE0711Fixer())
        self.add_fixer(PylintR0402Fixer())
        self.add_fixer(PylintR1705Fixer())
        self.add_fixer(PylintW0107Fixer())
        self.add_fixer(PylintC0303Fixer())
        self.add_fixer(PylintC0411Fixer())
        self.add_fixer(PylintC0325Fixer())
        self.add_fixer(PylintR0205Fixer())
        self.add_fixer(PylintR1725Fixer())
        self.add_fixer(PylintC0114Fixer())
        self.add_fixer(PylintC0116Fixer())
        self.add_fixer(PylintC0410Fixer())
        self.add_fixer(PylintW0614Fixer())
        self.add_fixer(PylintW0235Fixer())
        self.add_fixer(PylintW1201Fixer())
        self.add_fixer(PylintW0612Fixer())
        self.add_fixer(PylintR0201Fixer())
        self.add_fixer(PylintC0121Fixer())
        self.add_fixer(PylintW0702Fixer())
        self.add_fixer(PylintR1720Fixer())
        self.add_fixer(PylintE0213Fixer())
        self.add_fixer(PylintE0211Fixer())
        self.add_fixer(PylintC0202Fixer())
        self.add_fixer(PylintC0301Fixer())
        self.add_fixer(PylintE0602Fixer())
        self.add_fixer(PylintC0200Fixer())
        self.add_fixer(PylintW0410Fixer())
        self.add_fixer(PylintW0109Fixer())
        self.add_fixer(PylintR1734Fixer())
        self.add_fixer(PylintR1735Fixer())
        self.add_fixer(PylintR1716Fixer())
        self.add_fixer(PylintC0103Fixer())
        self.add_fixer(PylintW1401Fixer())
        self.add_fixer(PylintR1714Fixer())
        self.add_fixer(PylintW1505Fixer())
        self.add_fixer(PylintI0021Fixer())
        self.add_fixer(PylintC0413Fixer())
        self.add_fixer(PylintW1406Fixer())
        self.add_fixer(PylintR1723Fixer())
        self.add_fixer(PylintW0237Fixer())
        self.add_fixer(PylintC0206Fixer())
        self.add_fixer(PylintC2201Fixer())
        self.add_fixer(PylintW0212Fixer())
        self.add_fixer(PylintC1802Fixer())
        self.add_fixer(PylintE0601Fixer())
        self.add_fixer(PylintW0123Fixer())

    @staticmethod
    def compare_with_message_line(left, right):
        '''
        按告警行号进行排序,如果左边行号小于右边行号,返回正值表示倒叙,
        否则表示正序,此排序函数表示按行号进行倒叙排序
        '''
        if left.line < right.line:
            return 1
        return -1

    def parse_line_msg(self, linetext):
        if linetext.find('*************') != -1:
            return None
        result = re.search(r'(.*):(\d+):(\d+): (\w+): (.*)', linetext)
        if result is None:
            return None
        path, line, col, rule, messgae = result.groups()
        msg = Message(int(line), int(col), rule, path, messgae, self.name, [])
        return msg

    def build_version(self):
        if self._interpreter is None:
            return
        output = self.get_version_output()
        lines = output.splitlines()
        if not lines:
            utils.get_logger().error("build tool %s version error", self._path)
            return
        self._version = lines[0].strip().split()[1]

    def fix_file(self, processor, doc, filepath):
        message_file = self.get_file_log_path(doc, filepath)
        processor.message_viewer._plugin._check_processor.check_single_file(
            doc, filepath, load_messages=False)
        messages = processor.load_messages(self, message_file)
        # 对告警进行按行号倒叙排序,从下往上修复告警,可以避免修复过程中告警行号的波动
        for msg in py_sorted(messages, self.compare_with_message_line):
            if self.enable_rules and msg.ruleid not in self.enable_rules:
                utils.get_logger().warning('pylint tool rule %s is not enabled', msg.ruleid)
                continue
            processor.handle_message(doc, self, msg)
        if utils.profile_get_int(configkeys.CHECK_FILE_SYNTAX_KEY, True):
            self.check_file_syntax(filepath)

    def update_enable_rules(self, rules):
        super().update_enable_rules(rules)
        pylint_conf_path = get_pylint_rc_path()
        cfg_writer = ConfigWriter(
            pylint_conf_path, space_around_delimiters=False)
        if rules is None:
            enabled_rules_text = "all"
        else:
            enabled_rules_text = ",".join(rules)
        utils.get_logger().debug("pylint enable rules is %s", enabled_rules_text)
        try:
            cfg_writer.write_cofig(
                'MESSAGES CONTROL', 'enable', enabled_rules_text)
            cfg_writer.write_cofig('MESSAGES CONTROL', 'disable', "all")
        except Exception as ex:
            utils.get_logger().exception(
                'update pylint conf file %s exception:',
                pylint_conf_path
            )
            fileutils.safe_remove(pylint_conf_path)
            raise ex
