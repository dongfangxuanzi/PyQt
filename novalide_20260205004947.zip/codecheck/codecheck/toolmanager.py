from novalapp.common.singleton import Singleton
from .pythontool import Flake8Tool, PylintTool
from .strings import PYLINT_TOOL_NAME, FLAKE8_TOOL_NAME


@Singleton
class CodecheckToolManager:
    """description of class"""
    CHECK_TOOLS = []

    def __init__(self):
        self._tools_initialized = False

    @property
    def tools_initialized(self):
        return self._tools_initialized

    @classmethod
    def check_tool_name(cls, name):
        for tool in cls.CHECK_TOOLS:
            if tool.name == name:
                return True
        else:
            return False

    @staticmethod
    def manager():
        return CodecheckToolManager()

    @classmethod
    def tool_names(cls):
        names = []
        for tool in cls.CHECK_TOOLS:
            names.append(tool.name)
        return names

    @classmethod
    def find_tool(cls, name):
        for tool in cls.CHECK_TOOLS:
            if tool.name == name:
                return tool
        return None

    def register(self, tool):
        if self.check_tool_name(tool.name):
            return
        CodecheckToolManager.CHECK_TOOLS.append(tool)

    def register_python_tools(self, interpreter, json_output=False):
        if not self.check_tool_name(PYLINT_TOOL_NAME):
            self.register(PylintTool(interpreter, json_output))
        self.update_python_tool(PYLINT_TOOL_NAME, interpreter)
        if not self.check_tool_name(FLAKE8_TOOL_NAME):
            self.register(Flake8Tool(interpreter))
        self.update_python_tool(FLAKE8_TOOL_NAME, interpreter)
        self._tools_initialized = True

    def update_python_tool(self, toolname, interpreter):
        tool = self.find_tool(toolname)
        tool.update(interpreter)

    def init_tools(self):
        self.register(PylintTool())
        self.register(Flake8Tool())
