import os
from novalapp import _, get_app, prog_lang, newid
from novalapp.plugin import iface
from novalapp.plugin import plugin
from novalapp.util import utils, strutils
from novalapp.preference import preference
from novalapp.python.interpreter.interpreteradmin import InterpreterAdmin
from novalapp.python.interpreter.interpretermanager import InterpreterManager
from novalapp.project.wizard.templatemanager import WizardtemplateManager
from novalapp.sidebar.sidebar import SideBar
from novalapp.python.interpreter.exceptions import (
    InterpreternameExistError,
    InterpreterpathExistError
)
from novalapp.bars.menubar import NewQMenu
from novalapp.lib.pyqt import QMessageBox
from novalapp.project.sched import SchedulerRun
from codecheck import codecheck
from codecheck import messageviewer
from .toolmanager import CodecheckToolManager
from .codeutils import get_tools_data_path
from .configure import pylintconfig, flake8config
from .file_processor import FileProcessor
from .fix_processor import FixerProcessor
from .pkgres import get_message_icon_path
from .sched_processor import CodecheckProcessor
from .fix2to3 import Fix2to3Processor
from .strings import FLAKE8_TOOL_NAME, MESSAGE_VIEW_NAME


class CodecheckPlugin(plugin.Plugin):
    """plugin description here..."""
    plugin.Implements(iface.MainWindowI)

    def PlugIt(self, parent):
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing codecheck plugin")
        get_app().MainFrame.SIG_SHOW_PROPERTY_DIALOG.connect(self.show_property_page)
        self.statubar = get_app().MainFrame.GetStatusBar()
        self.project_browser = get_app().MainFrame.projectview
        self._use_internal_interpreter = False
        get_app().add_message_catalog('codecheck', __name__)
        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("CodeCheck"),
            "General",
            _("General"),
            codecheck.CodecheckOptionPanel,
            **{'plugin': self}
        )

        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("CodeCheck"),
            "Pylint",
            _("Pylint"),
            pylintconfig.PylintOptionPanel
        )

        preference.PreferenceManager.manager().AddOptionsPanelClass(
            _("CodeCheck"),
            "Flake8",
            _("Flake8"),
            flake8config.Flake8OptionPanel
        )

        WizardtemplateManager.get_manager().AddProjectTemplate(
            "Python/CodeCheck",
            "CodecheckProject",
            _("Codecheck Project"),
            [
                ("novalapp.python.project.page.BasePythonProjectNameLocationPage", {
                 'can_finish': False}),
                codecheck.CodecheckOptionPage,
                "novalapp.project.wizard.importfiles.ImportfilesPage"
            ]
        )
        message_icon_path = get_message_icon_path()
        view = get_app().MainFrame.AddView(
            MESSAGE_VIEW_NAME,
            messageviewer.MessageViewer,
            _("Messages"),
            SideBar.South,
            create=True,
            image_file=message_icon_path,
            visible_in_menu=True,
            **{'plugin': self}
        )
        self.message_viewer = view['instance']
        self._check_processor = CodecheckProcessor(
            self.message_viewer, self.statubar)
        self.message_viewer.set_processor(self._check_processor)
        get_app().MainFrame.projectview.register_sched_processor(self._check_processor)

        self._fix2to3_processor = Fix2to3Processor(
            self.message_viewer, self.statubar)
        get_app().MainFrame.projectview.register_sched_processor(self._fix2to3_processor)

        self._fix_processor = FixerProcessor(
            self.message_viewer, self.statubar)
        get_app().MainFrame.projectview.register_sched_processor(self._fix_processor)
        get_app().MainFrame.projectview.sigFileUpdated.connect(self.udpate_file_message)
        get_app().MainFrame.projectview.SIG_CLOSE_PROJECT_DOC.connect(self.clear_messages)

        # 项目文件节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_FILE_MENU.connect(
            self.popup_file_menu)
        # 项目根节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_ROOT_MENU.connect(
            self.popup_root_menu)
        get_app().MainFrame.projectview.SIG_EDIT_TEXT_POPUP_MENU.connect(self.popup_edit_text_menu)
        if self._use_internal_interpreter:
            self.load_internal_interpreter()
        else:
            CodecheckToolManager.manager().init_tools()

    def popup_root_menu(self, menu, item):
        submenu = NewQMenu(_("CodeCheck"))
        menu.AppendMenu(newid(), submenu)
        submenu.Append(
            newid(),
            _("Full Files Check"),
            handler=self.check_all_files,
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("BatchFix"),
            handler=self.batch_fix_files,
            tester=self.is_codecheck_menu_enabled
        )

    def popup_file_menu(self, menu, item):
        filepath = self.project_browser.GetView()._GetItemFilePath(item)
        if not self.is_code_file(filepath):
            return
        submenu = NewQMenu(_("CodeCheck"))
        menu.AppendMenu(newid(), submenu)
        submenu.Append(
            newid(),
            _("Single File Check"),
            handler=lambda: self.check_single_file(filepath),
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("Full Files Check"),
            handler=self.check_all_files,
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("AutoFix(Single File)"),
            handler=lambda: self.fix_single_file(filepath),
            tester=self.is_codecheck_menu_enabled
        )
        edit_view = None
        doc = get_app().GetDocumentManager().GetDocument(filepath)
        if doc is not None:
            edit_view = doc.GetFirstView()
        submenu.Append(
            newid(),
            _("Code Format"),
            handler=lambda: self.format_code_file(
                self.project_browser.GetView().GetDocument(),
                filepath,
                edit_view
            ),
            tester=self.is_codecheck_menu_enabled
        )

    @staticmethod
    def is_code_file(filepath):
        ext = strutils.get_file_extension(filepath)
        return ext in SchedulerRun.SYNTAX_EXTS

    def is_codecheck_menu_enabled(self):
        '''
        代码检测或修复过程中,代码检查菜单是禁止状态
        '''
        return not self.message_viewer.processor.running

    def popup_edit_text_menu(self, doc, menu, editor):
        edit_view = editor.get_view()
        if not self.is_code_file(
            edit_view.GetDocument().GetFilename()
        ):
            return
        filepath = edit_view.GetDocument().GetFilename()
        submenu = NewQMenu(_("CodeCheck"))
        menu.AppendMenu(newid(), submenu)
        submenu.Append(
            newid(),
            _("Single File Check"),
            handler=lambda: self.check_single_file(filepath),
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("Full Files Check"),
            handler=self.check_all_files,
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("AutoFix(Single File)"),
            handler=lambda: self.fix_single_file(filepath),
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("Code Format"),
            handler=lambda: self.format_code_file(
                doc,
                filepath,
                editor.get_view()
            ),
            tester=self.is_codecheck_menu_enabled
        )

    def is_enabled_for_extension(self, filepath):
        '''
        插件是否有支持检测该文件后缀的工具
        '''
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            if check_tool.is_filetool_enabled(filepath):
                return True
        else:
            ext = strutils.get_file_extension(filepath)
            QMessageBox.critical(
                get_app().GetTopWindow(),
                _('Error'),
                _('There is no valid check tool for file extension `*.%s`') % ext
            )
        return False

    def check_single_file(self, filepath):
        if not self.is_enabled_for_extension(filepath):
            return
        get_app().MainFrame.activateBottomTab(MESSAGE_VIEW_NAME)
        self.message_viewer.code_check_radio.setChecked(True)
        # 只检测单个文件
        self.message_viewer.start_run([filepath])

    def check_all_files(self):
        get_app().MainFrame.activateBottomTab(MESSAGE_VIEW_NAME)
        self.message_viewer.code_check_radio.setChecked(True)
        self.message_viewer.start_run()

    def batch_fix_files(self):
        get_app().MainFrame.activateBottomTab(MESSAGE_VIEW_NAME)
        self.message_viewer.code_autofix_radio.setChecked(True)
        self.message_viewer.start_run()

    def format_code_file(self, doc, filepath, edit_view=None):
        if not self.is_enabled_for_extension(filepath):
            return
        flake8_tool = CodecheckToolManager.manager().find_tool(FLAKE8_TOOL_NAME)
        if flake8_tool.interpreter is None:
            interpreter = doc.GetModel().interpreter
            if interpreter is None:
                return
            flake8_tool.update(interpreter)
        fixer = flake8_tool.fixers[0]
        fixer.openfile = False
        fixer.fix_code_file(doc, filepath, edit_view)

    def fix_single_file(self, filepath):
        if not self.is_enabled_for_extension(filepath):
            return
        get_app().MainFrame.activateBottomTab(MESSAGE_VIEW_NAME)
        self.message_viewer.code_autofix_radio.setChecked(True)
        # 只修复单个文件
        self.message_viewer.start_run([filepath])

    def load_internal_interpreter(self):
        tools_data_path = get_tools_data_path()
        internal_interpreter_path = os.path.join(
            tools_data_path, r"python\pylint\venv\scripts\python.exe")
        if not os.path.exists(internal_interpreter_path):
            CodecheckToolManager.manager().init_tools()
            utils.get_logger().error("internal interpreter path %s is not exist",
                                     internal_interpreter_path)
            return False
        utils.get_logger().info("find internal interpreter path is %s",
                                internal_interpreter_path)
        internal_interpreter_name = "codecheck_python38"
        try:
            admin = InterpreterAdmin(InterpreterManager.manager().interpreters)
            interpreter = admin.add_python_interpreter(
                internal_interpreter_path, internal_interpreter_name)
            interpreter.gen_id()
        except (InterpreternameExistError, InterpreterpathExistError) as error:
            utils.get_logger().warning("%s", str(error))
            interpreter = InterpreterManager.manager(
            ).GetInterpreterByName(internal_interpreter_name)
        except Exception as ex:
            utils.get_logger().error("load interpreter codecheck_python38 information error:%s", ex)
            return False
        CodecheckToolManager.manager().register_python_tools(
            interpreter, self._use_internal_interpreter)
        get_app().interpreters_combo.reload()
        return True

    def clear_messages(self, doc):
        if doc == self.message_viewer.doc:
            self.message_viewer.clear_messages()

    def udpate_file_message(self, doc, filepath):
        self.message_viewer.doc = doc
        self.message_viewer.set_current_processor()
        if self.message_viewer.processor is None or not self.message_viewer.processor.use_codecheck(doc):
            utils.get_logger().warning('codecheck is disabled when update file %s', filepath)
            return
        if not self.message_viewer.processor.get_doc_interpreter(doc):
            utils.get_logger().error('project doc %s interpreter is not exist', doc.GetFilename())
            return
        if not self.message_viewer.processor.find_doc_file(doc, filepath):
            utils.get_logger().error('file %s is not exist in project doc %s',
                                     filepath, doc.GetFilename())
            return
        if self.message_viewer.processor.running:
            utils.get_logger().warning(
                'processor %s is running when update file %s', self.message_viewer.processor.name, filepath)
            return
        if not CodecheckToolManager.manager().tools_initialized:
            utils.get_logger().error(
                "tools %s is not initialized yet.....",
                ",".join(CodecheckToolManager.manager().tool_names())
            )
            return
        self.message_viewer.clear_file_messages(filepath)
        FileProcessor(self.message_viewer, self.message_viewer.processor,
                      doc, filepath).start()

    def show_property_page(self, property_dlg, property_item_type):
        if property_item_type == "root":
            codecheck_panel_name = _('CodeCheck')
            property_dlg.add_panel_item(
                codecheck_panel_name, codecheck.CodecheckPropertyPanel)
            panel = property_dlg.GetOptionPanel(codecheck_panel_name)
            panel.set_plugin(self)

    def GetMinVersion(self):
        """Override in subclasses to return the minimum version of novalide that
        the plugin is compatible with. By default it will return the current
        version of novalide.
        @return: version str
        """

    def InstallHook(self):
        """Override in subclasses to allow the plugin to be loaded
        dynamically.
        @return: None

        """

    def UninstallHook(self):
        pass

    def EnableHook(self):
        pass

    def DisableHook(self):
        pass

    def get_prog_lang(self):
        return prog_lang.LANGUAGE_NOTSET

    def required_packages(self):
        return ['flake8', 'pylint']
