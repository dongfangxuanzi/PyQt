# -*- coding: utf-8 -*-
import logging
import os
import pickle
import time
from astroid import nodes
from astroid.raw_building import build_module, build_class, build_function
from ..parser.exceptions import CodefileNotExistError
from ...util import fileutils
from ..parser import objtypes
from ..apis import memberkeys
from ..parser.define import PACKAGE_INIT_FILE


log = logging.getLogger(__name__)


class ModuleLoader:

    MAX_TRY_TIMES = 5

    def __init__(self, name, members_file, member_list_file, mananger=None):
        self._name = name
        self._members_file = members_file
        self._member_list_file = member_list_file
        self._manager = mananger
        self._path = None
        self._data = None
        self._doc = None

    @property
    def membersfile(self):
        return self._members_file

    @property
    def apifile(self):
        return self._member_list_file

    @property
    def Name(self):
        return self._name

    @property
    def data(self):
        return self._data

    @property
    def path(self):
        return self._path

    @staticmethod
    def build_simple_node(data, parent=None):
        if data[memberkeys.OBJTYPE_KEY_NAME] == objtypes.MODULE:
            path = data.get(memberkeys.PATH_KEY_NAME, None)
            doc = data.get(memberkeys.DOC_KEY_NAME)
            node = build_module(
                data.get(memberkeys.MODNAME_KEY_NAME),
                doc
            )
            node.pure_python = not path is None
            node.file = path
            return node
        if data[memberkeys.OBJTYPE_KEY_NAME] == objtypes.CLASS_DEF:
            cls_node = build_class(
                data.get(memberkeys.NAME_KEY_NAME),
                doc=data.get(memberkeys.DOC_KEY_NAME)
            )
            cls_node.lineno = data.get(memberkeys.LINE_KEY_NAME, None)
            cls_node.col_offset = data.get(memberkeys.COL_KEY_NAME, None)
            cls_node.parent = parent
            cls_node.bases = [
                base_data[memberkeys.MODNAME_KEY_NAME]
                for base_data in data.get(memberkeys.BASES_KEY_NAME, [])
            ]
            return cls_node
        if data[memberkeys.OBJTYPE_KEY_NAME] == objtypes.FUNCTION_DEF:
            func = build_function(
                data.get(memberkeys.NAME_KEY_NAME),
                doc=data.get(memberkeys.DOC_KEY_NAME)
            )
            func.lineno = data.get(memberkeys.LINE_KEY_NAME, None)
            func.col_offset = data.get(memberkeys.COL_KEY_NAME, None)
            func.parent = parent
            return func
        return nodes.Name(
            data.get(memberkeys.NAME_KEY_NAME),
            data.get(memberkeys.LINE_KEY_NAME, None),
            data.get(memberkeys.COL_KEY_NAME, None),
            parent=parent,
            end_lineno=None,
            end_col_offset=None
        )

    def find_member_in_classdef(self, class_data, member_mod_name):
        members = []
        if class_data[memberkeys.OBJTYPE_KEY_NAME] == objtypes.CLASS_DEF:
            for class_child in class_data.get(memberkeys.CHILD_KEY_NAME, []):
                class_child_mod_name = class_child[memberkeys.MODNAME_KEY_NAME]
                if class_child_mod_name == member_mod_name:
                    log.info(
                        "find member %s of class %s in members file %s",
                        class_child_mod_name,
                        class_data[memberkeys.MODNAME_KEY_NAME],
                        self.membersfile
                    )
                    members.append(class_child)
        return members

    def is_package(self):
        if self._path is None:
            return False
        return fileutils.get_filename_from_path(self._path) == PACKAGE_INIT_FILE

    def load(self, check_path=False):
        if self._data is None:
            self.__load_data()

        if self._data is None:
            # 数据文件加载失败, 删掉非法的数据格式文件
            self.delete_api_files()
        else:
            if not self._name:
                self._name = self._data['name']
            self._path = self._data.get(memberkeys.PATH_KEY_NAME, None)
            if check_path and self._path and not os.path.exists(self._path):
                raise CodefileNotExistError
            self._doc = self._data.get(memberkeys.DOC_KEY_NAME, None)
        return self._data

    def reload(self):
        self.clear()
        try:
            self.load(check_path=True)
            return True
        except CodefileNotExistError:
            self.delete_api_files()
            log.warning("code file %s is not exist", self._path)
            return False

    def delete_api_files(self):
        fileutils.safe_remove(self._members_file)
        fileutils.safe_remove(self._member_list_file)
        log.debug("delelte members files %s", self._members_file)
        log.debug("delelte memberlist files %s", self._member_list_file)

    def GetDoc(self):
        self.load()
        return self._doc

    def load_membe_list(self):
        self.load()
        member_list = [
            member[memberkeys.NAME_KEY_NAME]
            for member in self._data[memberkeys.CHILD_KEY_NAME]
        ]
        return member_list

    def find_child(self, name):
        modname = self._data[memberkeys.MODNAME_KEY_NAME]
        for child in self._data[memberkeys.CHILD_KEY_NAME]:
            if child[memberkeys.MODNAME_KEY_NAME] == modname + "." + name:
                return child
        return None

    def find_childs_with_object_type(self, typename):
        childs = []
        for child in self._data[memberkeys.CHILD_KEY_NAME]:
            if child[memberkeys.OBJTYPE_KEY_NAME] == typename:
                childs.append(child)
        return childs

    def get_member_list(self):
        return self.load_membe_list()

    def get_member(self, name):
        self.load()
        return self.find_child(name)

    def clear(self):
        if self._data is not None:
            self._data.clear()
        self._data = None

    def __load_data(self):
        # 由于第一次加载数据文件可能会失败,最多重试5次
        for i in range(self.MAX_TRY_TIMES):
            try:
                if os.path.exists(self._members_file):
                    with open(self._members_file, 'rb') as f:
                        self._data = pickle.load(f)
                    break
            except Exception:
                log.exception('')
                log.error(
                    'load data members file %s error in %d times, wait 1 seconds to try load again',
                    self._members_file,
                    i + 1
                )
                # 等待1秒以便充分加载数据文件
                time.sleep(1)
