# -*- coding: utf-8 -*-
import os
from ...plugin import iface, plugin
from ...sidebar import sidebar
from ...backend.shell import BaseShellText, BaseShell
from .cmd_names import CmdName
from .cmd_running import CmdRunner, PowerShellProxy, SystemSimulateCmdProxy, GitBashProxy
from ...util import utils
from ...editor.codeview import CodeCtrl
from ... import get_app, _
from ...syntax.syntax import SyntaxThemeManager
from ...syntax import lang
from ...editor.texteditor import TextEditor
from ...lib.pyqt import QCheckBox, Qt, QSpinBox, QLabel, QHBoxLayout, QComboBox
from ...util import ui_utils
from ...preference import preference
from ... import globalkeys
from ...lib import newid
from ...preference.preference import PreferenceDialog
from ...preference.manager import GetOptionName
runner = None


def get_runner():
    return runner


class ShellText(BaseShellText):

    def __init__(self, master):
        super().__init__(master, shell_name="pseudoterminal")

    def submit_command(self, cmd_line, tags):
        if not cmd_line.endswith(constants.LF):
            cmd_line += constants.LF
        assert get_runner().is_waiting_toplevel_command()
        linenum = self.lineIndexFromPosition(self.input_start)[0]
        line_end_pos = self.line_end_position(linenum)
        if line_end_pos > self.input_start:
            self.delete_target(self.input_start, line_end_pos)
        self.insert_text(self.input_start, cmd_line)
        self.move_cursor_to_end()
        self._try_submit_input()

    def perform_return(self, event=None):
        if get_runner().is_running():
            # if we are fixing the middle of the input string and pressing ENTER
            # then we expect the whole line to be submitted not linebreak to be inserted
            # (at least that's how IDLE works)
            self.move_cursor_to_end()  # move cursor to the end
            # Do the return without auto indent
            CodeCtrl.keyPressEvent(self, event)
            self._try_submit_input()

        elif get_runner().is_waiting_toplevel_command():
            # Same with editin middle of command, but only if it's a single line command
            if self.__is_cursor_on_last_line():
                # 按回车键时需要将光标移至行尾
                self.move_cursor_to_end()
                if event is not None:
                    CodeCtrl.keyPressEvent(self, event)
                else:
                    self.insert_new_line()
                self._try_submit_input()

    def process_cmd_line(self, text_to_be_submitted):
        cmd_line = text_to_be_submitted.strip()
        self.get_runner().send_program_input(cmd_line)

    def compute_smart_home_destination_index(self):
        """Is used by EnhancedText"""

        if self._in_current_input_range("insert"):
            # on input line, go to just after prompt
            return "input_start"
        return super().compute_smart_home_destination_index()

    def get_runner(self):
        return get_runner()

    def can_backend_aborted(self):
        return get_runner().get_backend_proxy() is not None

    def update_appearance(self):
        '''
        cmd模拟窗口的基本背景色和文字颜色
        '''
        self._lang_lexer = SyntaxThemeManager.manager().GetLexer(lang.ID_LANG_TXT)
        syntax_options = self._lang_lexer.style_items.get(
            get_app().skin['shellSyntaxTheme'], {})
        TextEditor.set_syntax(self, syntax_options)

    def config_terminal(self):
        preference_dlg = PreferenceDialog(
            self, selection=GetOptionName(_("Misc"), "Terminal"))
        preference_dlg.exec_()

    def CreatePopupMenu(self):
        append_new_item = self._menu is None
        super().CreatePopupMenu()
        if append_new_item:
            self._menu.Append(
                newid(),
                _("Configure Terminal"),
                handler=self.config_terminal
            )

    def _try_submit_input(self):
        # see if there is already enough inputted text to submit
        line = self.get_current_line()
        # 提交命令文本不能包含换行符
        submit_text = self.get_submit_text()
        utils.get_logger().info('submit text is %s in %s', submit_text, self._shell_name)
        self._submit_input(submit_text)

    def _extract_submittable_input(self, input_text, tail):
        if get_runner().is_waiting_toplevel_command():
            if input_text.endswith("\n"):
                if input_text.strip().startswith("%") or input_text.strip().startswith("!"):
                    # if several magic command are submitted, then take only first
                    return input_text[: input_text.index("\n") + 1]
                if self._code_is_ready_for_submission(input_text, tail):
                    return input_text
                return None
            return None
        if get_runner().is_running():
            i = 0
            while True:
                if i >= len(input_text):
                    return None
                if input_text[i] == "\n":
                    return input_text[: i + 1]
                i += 1
        return None

    def _code_is_ready_for_submission(self, source, tail=""):
        # Ready to submit if ends with empty line
        # or is complete single-line code

        if tail.strip() != "":
            return False

        parser = roughparse.RoughParser(self.indent_width, self.tabwidth)
        parser.set_str(source.rstrip() + "\n")
        if (
            parser.get_continuation_type() != roughparse.C_NONE
            or parser.is_block_opener()
        ):
            return False

        # Multiline compound statements need to end with empty line to be considered
        # complete.
        lines = source.splitlines()
        # strip starting empty and comment lines
        while len(lines) > 0 and (
            lines[0].strip().startswith("#") or lines[0].strip() == ""
        ):
            lines.pop(0)

        compound_keywords = [
            "if",
            "while",
            "for",
            "with",
            "try",
            "def",
            "class",
            "async",
            "await",
        ]
        if len(lines) > 0:
            first_word = lines[0].strip().split()[0]
            if first_word in compound_keywords and not source.replace(" ", "").replace(
                "\t", ""
            ).endswith("\n\n"):
                # last line is not empty
                return False

        return True

    def _hyperlink_enter(self, event):
        self.config(cursor="hand2")

    def _hyperlink_leave(self, event):
        self.config(cursor="")

    def _handle_hyperlink(self, event):
        try:
            line = self.get("insert linestart", "insert lineend")
            matches = re.findall(r'File "([^"]+)", line (\d+)', line)
            if len(matches) == 1 and len(matches[0]) == 2:
                filename, lineno = matches[0]
                lineno = int(lineno)
                if os.path.exists(filename) and os.path.isfile(filename):
                    GetApp().GotoView(filename, lineno, load_outline=False)
        except Exception:
            traceback.print_exc()

    def __is_cursor_on_last_line(self):
        """
        Private method to check, if the cursor is on the last line.
        @return flag indicating that the cursor is on the last line (boolean)
        """
        cline, _ccol = self.getCursorPosition()
        return cline == self.lines() - 1

    def _insert_prompt(self, prompt=None, new_line=False):
        super()._insert_prompt('', new_line)


class CommandShell(BaseShell):
    def __init__(self, mater):
        global runner
        super().__init__(mater)
        self._add_main_backends()
        runner = self._runner

    def GetTextCtrl(self):
        return self.text

    def close_window(self):
        self._runner.destroy_backend()
        return True

    def GetShelltextClass(self):
        return ShellText

    def GetRunner(self):
        return CmdRunner(self)

    def _start_runner(self):
        try:
            self._runner.start()
        except Exception:
            utils.get_logger().exception("Error when initializing backend")

    def _add_main_backends(self):
        if utils.is_windows():
            get_app().add_backend(
                CmdName.POWERSHELLCMD,
                PowerShellProxy,
                _("PowerShell"),
                "1",
            )
            get_app().add_backend(
                CmdName.SIMULATECMD,
                SystemSimulateCmdProxy,
                _("Command Prompt"),
                "2",
            )
        get_app().add_backend(
            CmdName.GITCMD,
            GitBashProxy,
            _("Git Bash"),
            "3",
        )


class TerminalOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    模拟终端配置面板
    """

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.__use_tty_chkbox = QCheckBox(_("Use tty mode"))
        self.__use_tty_chkbox.setChecked(
            utils.profile_get_int(globalkeys.OUTLINE_SHOWLINENUMBER_KEY, True))
        self.layout.addWidget(self.__use_tty_chkbox)

        hbox = QHBoxLayout()
        hbox.setAlignment(Qt.AlignLeft)
        hbox.addWidget(QLabel(_("Default backend") + ":"))
        self.backend_combox = QComboBox()
        items = [CmdName.SIMULATECMD.value, CmdName.POWERSHELLCMD.value, CmdName.GITCMD.value]
        self.backend_combox.addItems(items)
        self.backend_combox.setCurrentIndex(items.index(CmdName.SIMULATECMD.value))
        hbox.addWidget(self.backend_combox)
        self.layout.addLayout(hbox)

        size_hbox = QHBoxLayout()
        size_hbox.setAlignment(Qt.AlignLeft)
        size_hbox.addWidget(QLabel(_('Set pseudo screen size') + ":"))

        size_hbox.addWidget(QLabel(_('Columns')))
        self.columns_ctrl = QSpinBox(value=utils.profile_get_int(
            'PSEUDO_SCREEN_COLUMNS_KEY',
            80
        ),
            maximum=500,
            minimum=10,
            singleStep=1)
        self.lines_ctrl = QSpinBox(value=utils.profile_get_int(
            'PSEUDO_SCREEN_LINES_KEY',
            24
        ),
            maximum=200,
            minimum=10,
            singleStep=1)
        size_hbox.addWidget(self.columns_ctrl)
        size_hbox.addWidget(QLabel(_('Lines')))
        size_hbox.addWidget(self.lines_ctrl)
        self.layout.addLayout(size_hbox)
        self.layout.setAlignment(Qt.AlignTop)

    def OnOK(self, options_dialog):
        utils.profile_set(globalkeys.OUTLINE_SHOWLINENUMBER_KEY,
                          self.__use_tty_chkbox.isChecked())
        return True


class PseudoterminalLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)

    def load(self):
        get_app().MainFrame.AddView(
            "pseudoterminal",
            CommandShell,
            _("Terminal"),
            sidebar.SideBar.South,
            image_file="terminal.png",
            active=True
        )
        # 首选项显示面板
        preference.PreferenceManager().add_options_panel_class(
            _("Misc"), "Terminal", _("Terminal"), TerminalOptionPanel)
