import argparse
from novalapp.python.interpreter.interpreter import PythonInterpreter
from novalapp.util import logger

def anaylze(
        interpreter_path,
        dbver,
        outpath,
        path_list,
        multi_process
    ):
    python_interpreter = PythonInterpreter('',interpreter_path)
    python_interpreter.gen_intellisence_data(
        dbver,
        outpath,
        pathlist=path_list,
        multiprocess=multi_process
    )

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-i", 
        "--interpreter",
        type=str, 
        dest="interpreter_path", 
        help='path of interpreter',
        required=True
    )
    parser.add_argument('--path', action='append',dest='pathlist',default=[],help='extra pythonpath of interpreter')
    parser.add_argument(
        "--multiprocess",
        action='store_true',
        dest="multiprocess",
        help='use multi process to analyze interpreter code data',
        default=False
    )
    parser.add_argument(
        "--debug",
        action='store_true',
        dest="debug",
        help='show debug log of program or not',
        default=False
    )

    parser.add_argument(
        "-o", 
        "--out",
        type=str, 
        dest="outpath", 
        help='dest out path of intellisense data',
        required=True
    )
    parser.add_argument(
        "-v", 
        "--dbver",
        type=str, 
        dest="dbver", 
        help='database version of intellisense data',
        required=True
    )   
    args = parser.parse_args()
    logger.initLogging(args.debug)
    anaylze(
        args.interpreter_path,
        args.dbver,
        args.outpath,
        args.pathlist,
        args.multiprocess
    )
