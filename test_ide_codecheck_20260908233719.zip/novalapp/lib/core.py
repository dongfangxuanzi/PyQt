# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        core.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-08
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
from .. import get_app,_
import novalapp
from .pyqt import QApplication, QFrame, Qt
import tempfile
import mmap
import sys
from .limits import MAX_MRU_FILE_LIMIT
from ..util import apputils, strutils, utils, fileutils, checker
import pickle
import time
import os
import shutil
import json
import io

class App(QApplication):
    
    def __init__(self,debug=False, argv=[]):
        QApplication.__init__(self, argv)
        novalapp._AppInstance = self
        self._debug = debug
        self._singleInstance = True
        self._splash = None
        self.locale = novalapp.Locale(novalapp.ui_lang.LANGUAGE_DEFAULT)
        self.frame = None
        self._clip_board = None
        self.initializing = False
        # 高分辨率DPI屏幕自动缩放和去除弹窗的?按钮
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling | Qt.AA_DisableWindowContextHelpButton)
        self._BootstrapApp()
        
    def GetLocale(self):
        return self.locale

    def OpenCommandLineArgs(self):
        """
        Called to open files that have been passed to the application from the
        command line.
        """
        args = sys.argv[1:]
        self.OpenFileWithArgs(args)

    def OpenFileWithArgs(self,args):
        for arg in args:
            if (not apputils.is_windows() or arg[0] != "/") and arg[0] != '-' and os.path.exists(arg):
                self.GetDocumentManager().CreateDocument(os.path.normpath(arg), DOC_SILENT)

    def GetDocumentManager(self):
        """
        Returns the document manager associated to the DocApp.
        """
        return self._docManager

    def SetDocumentManager(self, docManager):
        """
        Sets the document manager associated with the DocApp and loads the
        DocApp's file history into the document manager.
        """
        self._docManager = docManager
        config = self.GetConfig()
        #加载历史文件记录
        self.GetDocumentManager().FileHistoryLoad(config)

    def ShowTip(self, frame, tipProvider):
        """
        Shows the tip window, generally this is called when an application starts.
        A wx.TipProvider must be passed.
        """
        config = wx.ConfigBase_Get()
        showTip = config.ReadInt("ShowTipAtStartup", 1)
        if showTip:
            index = config.ReadInt("TipIndex", 0)
            showTipResult = wx.ShowTip(wx.GetApp().GetTopWindow(), tipProvider, showAtStartup = showTip)
            if showTipResult != showTip:
                config.WriteInt("ShowTipAtStartup", showTipResult)

    def GetDebug(self):
        """
        Returns True if the application is in debug mode.
        """
        return self._debug

    def SetDebug(self, debug):
        """
        Sets the application's debug mode.
        """
        self._debug = debug
        
    def SetAppName(self,app_name):
        self._app_name = app_name
        if not self.objectName():
            self.setObjectName(self._app_name)
        
    def GetAppName(self):
        return self._app_name

    def GetSingleInstance(self):
        """
        Returns True if the application is in single instance mode.  Used to determine if multiple instances of the application is allowed to launch.
        """
        return self._singleInstance

    def SetSingleInstance(self, singleInstance):
        """
        Sets application's single instance mode.
        """
        self._singleInstance = singleInstance

    def OnInit(self):
        """
        Initializes the App.
        """
        if not hasattr(self, "_debug"):  # only set if not already initialized
            self._debug = False
        if not hasattr(self, "_singleInstance"):  # only set if not already initialized
            self._singleInstance = True
        # if _singleInstance is TRUE only allow one single instance of app to run.
        # When user tries to run a second instance of the app, abort startup,
        # But if user also specifies files to open in command line, send message to running app to open those files
        self.initializing = True
        if self._singleInstance:
            # create shared memory temporary file
            if apputils.is_windows():
                tfile = tempfile.TemporaryFile(prefix="ag", suffix="tmp")
                fno = tfile.fileno()
                self._sharedMemory = mmap.mmap(fno, 1024, "shared_memory")
            else:
                tfile = open(os.path.join(tempfile.gettempdir(), tempfile.gettempprefix() + self.GetAppName() + "NovalSharedMemory"), 'w+b')
                tfile.write(bytes("*",'ascii'))
                tfile.seek(1024)
                tfile.write(bytes(" ",'ascii'))
                tfile.flush()
                fno = tfile.fileno()
                self._sharedMemory = mmap.mmap(fno, 1024)

            self._singleInstanceChecker = checker.SingleInstanceChecker()
            #仅允许一个实例运行
            if self._singleInstanceChecker.IsAnotherRunning():
                utils.get_logger().info('another instance is running,exit now....')
                # have running single instance open file arguments
                
                data = pickle.dumps(sys.argv[1:])
                while 1:
                    self._sharedMemory.seek(0)
                    marker = self._sharedMemory.read_byte()
                    #ord是将asc字符转换成数字,chr是将数字转换成asc字符
                    if marker == '\0' or marker == ord('\0') or marker == '*' or marker == ord('*'):        # available buffer
                        self._sharedMemory.seek(0)
                        if type(marker) == int:
                            self._sharedMemory.write_byte(ord('-'))     # set writing marker
                            self._sharedMemory.write(data)  # write files we tried to open to shared memory
                            self._sharedMemory.seek(0)
                            self._sharedMemory.write_byte(ord('+'))     # set finished writing marker
                        elif type(marker) == str:
                            self._sharedMemory.write_byte('-')     # set writing marker
                            self._sharedMemory.write(data)  # write files we tried to open to shared memory
                            self._sharedMemory.seek(0)
                            self._sharedMemory.write_byte('+')     # set finished writing marker
                        self._sharedMemory.flush()
                        break
                    else:
                        time.sleep(1)  # give enough time for buffer to be available

                return False
            else:
                self.DoBackgroundListenAndLoad()

        return True
        
    #统计程序启动时间
    @utils.compute_time
    def _BootstrapApp(self):
        if not self.OnInit():
            self.exit()
            sys.exit(0)

    def DoBackgroundListenAndLoad(self):
        """
        Open any files specified in the given command line argument passed in via shared memory
        """
        if not hasattr(self, "_singleInstanceChecker"):
            utils.get_logger().warn('application has been quit,stop background listen and load')
            return
        self.after(1000,self.DoBackgroundListenAndLoad)
        self._sharedMemory.seek(0)
        byte = self._sharedMemory.read_byte()
        if  byte == '+' or byte == ord('+'):  # available data
            data = self._sharedMemory.read(1024-1)
            self._sharedMemory.seek(0)
            if utils.is_py2():
                self._sharedMemory.write_byte("*")
            elif utils.is_py3_plus():
                self._sharedMemory.write_byte(ord("*"))     # finished reading, set buffer free marker
            self._sharedMemory.flush()
            args = pickle.loads(data)
            self.OpenFileWithArgs(args)
            # force display of running app
            self.RaiseWindow()
        
    def GetConfig(self):
        return self._config
        
    def SetDefaultIcon(self, img):
        """
        Sets the application's default icon.
        """
        QApplication.setWindowIcon(img)
    
    def Quit(self):
        self._docManager.FileHistorySave(get_app().GetConfig())
        if hasattr(self, "_singleInstanceChecker"):
            self._sharedMemory.close()
            del self._singleInstanceChecker
        self.quit()        

    def RaiseWindow(self, force=True):
        '''
            将程序窗口置于桌面前台
        '''
        # Looks like at least on Windows all following is required
        # for ensuring the window gets focus
        # (deiconify, ..., iconify, deiconify)
        self.deiconify()
        if force:
            self.attributes("-topmost", True)
            self.after_idle(self.attributes, "-topmost", False)
            self.lift()
            if not utils.is_linux():
                # http://stackoverflow.com/a/13867710/261181
                #最小化窗口
                self.iconify()
                self.deiconify()
        self.focus_set()

    def CreateDocumentFrame(self, view, doc, flags, id = -1, title = ""):
        """
        Called by the DocManager to create and return a new Frame for a Document.
        Chooses whether to create an MDIChildFrame or SDI Frame based on the
        DocManager's flags.
        """
        frame = self.CreateTabbedDocumentFrame(doc, view, id, title)
        #if not frame.GetIcon() and self._defaultIcon:
         #   frame.SetIcon(self.GetDefaultIcon())
        view.SetFrame(frame)
        return frame

    def CreateTabbedDocumentFrame(self, doc, view, id=-1, title=""):
        """
        Creates and returns an MDI Document Frame for a Tabbed MDI view
        """
        frame = DocTabbedChildFrame(doc, view, self.MainFrame, id, title)
        return frame
        
    def GetTopWindow(self):
        return self.frame

    def ShowSplash(self, image_path):
        """
        Shows a splash window with the given image.  Input parameter 'image' can either be a wx.Bitmap or a filename.
        """
        self._splash = ui_base.SplashScreen(self,image_path)
        self._splash.Show()
        #隐藏主窗口
        self.withdraw()
        self.attributes("-alpha", 0)
        

    def CloseSplash(self):
        """
        Closes the splash window.
        """
        if self._splash:
            self._splash.Close()
            
    def GetIDESplashBitmap(self):
        return None
        
    def get_default_hsplitter_width(self):
        screenSize = self.desktop().screenGeometry()
        return screenSize.width()//6
        
    def get_default_vsplitter_height(self):
        screenSize = self.desktop().screenGeometry()
        return screenSize.height()//6
        
    @property
    def TheClipboard(self):
        if self._clip_board is None:
            self._clip_board = Clipboard()
        return self._clip_board

class DocTabbedChildFrame(QFrame):
    """
    The wxDocMDIChildFrame class provides a default frame for displaying
    documents on separate windows. This class can only be used for MDI child
    frames.

    The class is part of the document/view framework supported by wxWindows,
    and cooperates with the wxView, wxDocument, wxDocManager and wxDocTemplate
    classes.
    """

    def __init__(self, doc, view, frame, id, title):
        """
        Constructor.  Note that the event table must be rebuilt for the
        frame since the EvtHandler is not virtual.
        """
        super().__init__(frame.GetNotebook())
        self._childDocument = doc
        self._childView = view
        frame.AddNotebookPage(self, doc.GetPrintableName(),doc.GetFilename())
        if view:
            view.SetFrame(self)

    def GetIcon(self):
        """
        Dummy method since the icon of tabbed frames are managed by the notebook.
        """
        return None


    def SetIcon(self, icon):
        """
        Dummy method since the icon of tabbed frames are managed by the notebook.
        """
        pass

    def Destroy(self):
        """
        Removes the current notebook page.
        """
        get_app().GetTopWindow().RemoveNotebookPage(self)

    def SetFocus(self):
        """
        Activates the current notebook page.
        """
        get_app().GetTopWindow().ActivateNotebookPage(self)

    def Activate(self):  # Need this in case there are embedded sash windows and such, OnActivate is not getting called
        """
        Activates the current view.
        """
        # Called by Project Editor
        if self._childView:
            self._childView.Activate(True)

    def GetTitle(self):
        """
        Returns the frame's title.
        """
        return get_app().GetTopWindow().GetNotebookPageTitle(self)

    def SetTitle(self, title):
        """
        Sets the frame's title.
        """
        get_app().GetTopWindow().SetNotebookPageTitle(self, title)

    def OnTitleIsModified(self):
        """
        Add/remove to the frame's title an indication that the document is dirty.
        If the document is dirty, an '*' is appended to the title
        """
        title = self.GetTitle()
        if title:
            if self.GetDocument().IsModified():
                if not title.endswith("*"):
                    title = title + "*"
                    self.SetTitle(title)
            else:
                if title.endswith("*"):
                    title = title[:-1]
                    self.SetTitle(title)

    def GetDocument(self):
        """
        Returns the document associated with this frame.
        """
        return self._childDocument

    def SetDocument(self, document):
        """
        Sets the document for this frame.
        """
        self._childDocument = document

    def GetView(self):
        """
        Returns the view associated with this frame.
        """
        return self._childView


    def SetView(self, view):
        """
        Sets the view for this frame.
        """
        self._childView = view
        

class DataObject(object):
    
    def __init__(self,data_type="str"): 
        self._data_type = data_type
        self._data = ''

    def SetData(self,data):
        self._data = data

    def GetData(self):
        return self._data
        
    def GetDataSize(self):
        return len(self._data)
        
    @property
    def RawData(self):
        return self._data
        
    @RawData.setter
    def RawData(self,data):
        self._data = data

class JsonDataobject(DataObject):
    
    def __init__(self): 
        DataObject.__init__(self,data_type="json")

    def SetData(self,data):
        DataObject.SetData(self,json.dumps(data))

    def GetData(self):
        data = DataObject.GetData(self)
        d = json.loads(data)
        return json.loads(data)
            
class Clipboard(object):
    def __init__(self):
        self._is_opened = False
        
    def Open(self):
        if self._is_opened:
            return True
        self.buf = StringIO.StringIO()
        self._is_opened = True
        return self._is_opened

    def Close(self):
        self.buf.close()
        self._is_opened = False

    def IsOpened(self):
        return self._is_opened

    def AddData(self,data_ojbect):
        self.buf.write(data_ojbect.RawData)

    def SetData(self,data_ojbect):
        self.Clear()
        self.AddData(data_ojbect)

    def GetData(self,data_ojbect):
        if not self.buf.getvalue():
            return False
        data_ojbect.RawData = self.buf.getvalue()
        return True

    def Clear(self):
        self.buf.truncate(0)
        self.buf.seek(0)

    def Flush(self):
        self.buf.flush()

    def Get(*args, **kwargs):
        """
        Get() -> Clipboard

        Returns global instance (wxTheClipboard) of the object.
        """
        return _misc_.Clipboard_Get(*args, **kwargs)