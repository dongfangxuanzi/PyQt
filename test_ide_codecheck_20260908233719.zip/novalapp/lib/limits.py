
#最大历史文件个数
MAX_MRU_FILE_LIMIT = 20