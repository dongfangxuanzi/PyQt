import os
from .util import appdirs
from .lib.pyqt import QPixmap, QIcon


def load_image(path):
    if not os.path.isabs(path):
        path = os.path.join(appdirs.get_app_image_location(), path)
    path = os.path.normpath(path)
    pixmap = QPixmap(path)
    return pixmap
    
def load_icon(path):
    """Provides a pixmap as an icon"""
    return QIcon(load_image(path))

def application_icon():
    path = os.path.join(appdirs.get_app_path(),"noval.ico")
    return load_icon(path)
    
def empty_icon():
    return QIcon(QPixmap())

def blank_icon():
    return load_icon("file/blank.png")

def text_icon():
    return load_icon("file/file.gif")
    
def image_icon():
    return load_icon("file/photo.png")
    
def python_icon():
    return load_icon("file/python_module.png")
    

def getPackageFolderIcon():
    return load_image("","project/python/package_obj.gif")

def getFolderClosedIcon():
    return load_icon("project/folder_close.png")
    
def getProjectIcon():
    return load_icon("project/project.png")