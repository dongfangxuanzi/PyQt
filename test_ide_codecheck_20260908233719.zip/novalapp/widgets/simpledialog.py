# -*- coding: utf-8 -*-
from .. import get_app
from ..lib.pyqt import QDialog, QLabel, QListWidget, QVBoxLayout, QInputDialog
from ..util import ui_utils

class SingleChoiceDialog(ui_utils.BaseModalDialog):
    def __init__(self, title, label, choices, selection=-1, master=None):
        super().__init__(title, master)
        #禁止对话框改变大小
        layout = QVBoxLayout(self)
        label = QLabel(label)
        layout.addWidget(label)
    
        self.listbox = QListWidget()
        for item in choices:
            self.listbox.addItem(item)
        if selection != -1:
            self.listbox.setCurrentRow(selection)
        self.listbox.itemDoubleClicked.connect(self.selectionitem)
        layout.addWidget(self.listbox)
        self.create_standard_buttons(layout)
        self.selection = -1

    def accept(self, event=None):
        self.selection = self.listbox.currentRow()
        super().accept()
        
    def selectionitem(self):
        self.accept()
        
def asklist(title, label, choices, selection=-1, master=None):
    dlg = SingleChoiceDialog(title, label, choices, selection, master)
    dlg.exec_()
    return dlg.selection
    
def askinteger(title, label, *, minnum=1,maxnum=-1,master=None):
    num, ok = QInputDialog.getInt(master, title, label, 1, minnum, maxnum)
    return ok, num

def askstring(title, label, *, initialvalue=None,master=None):
    name, ok = QInputDialog.getText(master, title, label, text=initialvalue)
    return ok, name

def askitem(title, label, choices, selection=-1, master=None):
    name, ok = QInputDialog.getItem(master,title, label, choices, selection,editable=False)
    return name, ok