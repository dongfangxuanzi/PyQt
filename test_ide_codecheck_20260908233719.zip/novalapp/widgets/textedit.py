from .. import get_app
import os.path
import re
from ..lib.pyqt import QPlainTextEdit

class DoubleClickTextEdit(QPlainTextEdit):
    def __init__(self, parent):
        super().__init__(parent)
        
    def mouseDoubleClickEvent(self, event):
        cursor = self.textCursor()
        line = cursor.block().blockNumber()
        doc = self.document()
        line_text = doc.findBlockByNumber(line).text()
        res = re.match("^\s+File\s+\"(?P<filepath>.*)\",\s+line\s+(?P<line>\d+),\s+in\s+\w+",line_text)
        if res is not None:
            self.jumpto(res)
        else:
            # syntax error
            res = re.match("^\s+File\s+\"(?P<filepath>.*)\",\s+line\s+(?P<line>\d+)",line_text)
            if res is not None:
                self.jumpto(res)
            
    def jumpto(self, regres):
        filepath = os.path.abspath(regres.group('filepath'))
        line = int(regres.group('line'))
        get_app().GotoView(filepath, lineNum=line, load_outline=False)