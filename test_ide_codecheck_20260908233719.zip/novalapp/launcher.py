# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        launcher.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-08
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
import os
import sys
from .prog_lang import LANGUAGE_PYTHON, LANGUAGE_NOTSET

def run(language):
    if language == LANGUAGE_PYTHON:
        from .python import pyide
        app = pyide.PyIDEApplication()
    elif language == LANGUAGE_NOTSET:
        from . import ide
        app = ide.IDEApplication()
    ret = app.exec_()
    sys.exit(ret)
    
if __name__ == "__main__":
    run(LANGUAGE_PYTHON)

