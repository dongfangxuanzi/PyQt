DEFAULT_PLUGINS = (
 #   "noval.plugins.fileview.FileViewLoader",
  #  "noval.find.findresult.FindResultsviewLoader",
   # "noval.plugins.printer.FilePrinterPluginLoader",
    "novalapp.plugins.about.AboutLoader",
    "novalapp.plugins.update.UpdateLoader",
    "novalapp.plugin.gui.PluginManagerGUI"
)