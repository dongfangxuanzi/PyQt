from ..lib.pyqt import QWidget

class OutlineView(QWidget):
    
    def __init__(self, master, show_header=False):
        super().__init__(master)
        self.tree = None
        self.createLayout()
        #不显示表头
        if not show_header:
            self.tree.setHeaderHidden(True)
        self.root = self.tree.invisibleRootItem()
        #当前在大纲中显示的文本视图
        self._callback_view = None
        #哪些视图类型允许在大纲中显示
        self._validViewTypes = []
        
    def createLayout(self):
        pass
        
    def AddViewTypeForBackgroundHandler(self, viewType):
        self._validViewTypes.append(viewType)

    def GetViewTypesForBackgroundHandler(self):
        return self._validViewTypes

    def RemoveViewTypeForBackgroundHandler(self, viewType):
        self._validViewTypes.remove(viewType)
        
    def IsValidViewType(self,currView):
        for viewType in self._validViewTypes:
            if isinstance(currView, viewType):
                return True
        return False

    def _update_frame_contents(self, index):
        if index <0:
            self._clear_tree()
            return
        self._clear_tree()

    # clears the tree by deleting all items
    def _clear_tree(self):
        self.root.takeChildren()
            
    def GetCallbackView(self):
        return self._callback_view
        
    def SetCallbackView(self,view):
        self._callback_view = view