# -*- coding: utf-8 -*-
from .. import get_app, _
import os
##import noval.consts as consts
##import noval.constants as constants
from .. import menuitems
from ..menubar import NewQMenu
from ..lib.pyqt import (
    QTreeWidget, 
    QWidget,
    Qt,
    QSize,
    QVBoxLayout,
    QSizePolicy,
    QToolButton,
    QToolBar,
    QAction,
    QTreeWidgetItem,
    QCursor,
    QMessageBox
)
from ..toolbar import ToolBar
from ..util import utils,fileutils,strutils
from ..syntax.syntax import SYNATAX_MANAGER
##import noval.ui_utils as ui_utils
from ..widgets import simpledialog
from ..widgets.labels import HeaderFitLabel
from ..qtimage import load_icon
from ..widgets.spacers import ToolBarExpandingSpacer

_dummy_node_text = "..."

if utils.is_windows():
    from win32com.shell import shell, shellcon
    
    def GetDriveDisplayName(path):
        return shell.SHGetFileInfo(path, 0, shellcon.SHGFI_DISPLAYNAME)[1][3]
        
    def GetRoots():
        roots = []
        import ctypes
        import os
        for i in range(65,91):
            vol = chr(i) + ':'
            if os.path.isdir(vol):
                roots.append([GetDriveDisplayName(vol),vol])
        return roots
else:
    def GetRoots():
        roots = []
        home_dir = wx.GetHomeDir()
        roots.append([_("Home directory"),home_dir])
        desktop_dir = home_dir + "/Desktop"
        roots.append([_("Desktop"),desktop_dir])
        roots.append(["/","/"])
        return roots
        

def get_win_drives():
    # http://stackoverflow.com/a/2288225/261181
    # http://msdn.microsoft.com/en-us/library/windows/desktop/aa364939%28v=vs.85%29.aspx
    roots = []
    import ctypes
    import os
    for i in range(65,91):
        vol = chr(i) + ':'
        if os.path.isdir(vol):
            roots.append(vol)
    return roots
    
SAVE_OPEN_FOLDER_KEY = "FileViewSaveFolder"
OPEN_FOLDER_KEY = "FileViewLastFolder"

class FileBrowser(QTreeWidget):
    def __init__(self, master=None, show_hidden_files=False):
        super().__init__(master)
        lexer = SYNATAX_MANAGER.GetLexer(get_app().GetDefaultLangId())
        self.default_extentsion = "." + lexer.GetDefaultExt()
        self.show_hidden_files = show_hidden_files

        wb = get_app()
        self.folder_icon = wb.GetImage("files/folder.gif")
        self.default_file_icon = lexer.GetFileViewIcon()
        self.text_file_icon = wb.GetImage("files/text-file.gif")
        self.generic_file_icon = wb.GetImage("files/generic-file.gif")
        self.hard_drive_icon = wb.GetImage("files/hard-drive.gif")
        #不显示表头
        self.setHeaderHidden(True)
        self.root = self.invisibleRootItem()

        self.refresh_tree(self.root)
        self.itemExpanded.connect(self.on_open_node)

        #加载上次打开的文件夹
        self.open_initial_folder()

    def open_initial_folder(self):
        if utils.profile_get_int(SAVE_OPEN_FOLDER_KEY,True):
            path = utils.profile_get(OPEN_FOLDER_KEY)
            if path:
                self.open_path_in_browser(path, True)

    def save_current_folder(self, filepath):
        if not filepath:
            return
        if os.path.isfile(filepath):
            path = os.path.dirname(filepath)
        else:
            path = filepath
        utils.profile_set(OPEN_FOLDER_KEY, path)

    def on_open_node(self, item):
        if item:
            self.refresh_tree(item, True)

    def get_selected_node(self):
        nodes = self.selectedItems()
        if len(nodes) >= 1:
            return nodes[0]
        else:
            return None

    def get_selected_path(self, node=None):
        if not node:
            nodes=self.selectedItems()
            if nodes:
                node=nodes[0]
        if node:
            return node.data(0, Qt.UserRole)
        return None

    def open_path_in_browser(self, path, see=True):
        # unfortunately os.path.split splits from the wrong end (for this case)
        def split(path):
            head, tail = os.path.split(path)
            if head == "" and tail == "":
                return []
            elif head == path or tail == path:
                return [path]
            elif head == "":
                return [tail]
            elif tail == "":
                return split(head)
            else:
                return split(head) + [tail]
        
        parts = split(path)
        current_node = self.root
        current_path = ""
        while parts != []:
            current_path = os.path.join(current_path, parts.pop(0))
            for i in range(current_node.childCount()):
                childnode = current_node.child(i)
                child_path = childnode.data(0, Qt.UserRole)
                if child_path == current_path:
                    childnode.setExpanded(True)
                    self.refresh_tree(childnode)
                    current_node = childnode
                    break

        if see and current_node:
            #选中节点
            current_node.setSelected(True)
##            self.tree.focus(current_node_id)
##
##            if self.tree.set(current_node_id, "kind") == "file":
##                self.tree.see(self.tree.parent(current_node_id))
##            else:
##                self.tree.see(current_node_id)

    def refresh_tree(self, parent, opening=None):
        if parent == self.root:
            path = ""
        else:
            path = parent.data(0, Qt.UserRole)
        if os.path.isfile(path):
            parent.setExpanded(False)
        else:
            # either root or directory
            if parent == self.root or parent.isExpanded() or opening == True:
                #在windows下如果path为根硬盘路径,例如c:,d:需要将根路径后面添加路径分割符
                #因为调用os.path.join连接路径时不会自动添加路径分割符
                if path != "" and not path.endswith(os.sep):
                    path += os.sep
                fs_children_names = self.listdir(path, self.show_hidden_files)
                tree_child_nodes =[]
                for i in range(parent.childCount()):
                    tree_child_nodes.append(parent.child(i))

                # recollect children
                children = {}

                # first the ones, which are present already in tree
                for child_node in tree_child_nodes:
                    name = child_node.text(0)
                    if name in fs_children_names:
                        children[name] = child_id

                # add missing children
                for name in fs_children_names:
                    if name not in children:
                        tree_item = QTreeWidgetItem()
                        parent.addChild(tree_item)
                        tree_item.setData(0, Qt.UserRole, os.path.join(path, name))
                        children[name] = tree_item

                def file_order(name):
                    # items in a folder should be ordered so that
                    # folders come first and names are ordered case insensitively
                    return (os.path.isfile(os.path.join(path, name)), name.upper())

                # update tree
                ids_sorted_by_name = list(
                    map(
                        lambda key: children[key],
                        sorted(children.keys(), key=file_order),
                    )
                )
                parent.takeChildren()
                parent.addChildren(ids_sorted_by_name)
                for child_node in ids_sorted_by_name:
                    #更新节点文本
                    self.update_node_format(child_node)
                    self.refresh_tree(child_node)

            else:
                # closed dir
                # Don't fetch children yet, but ensure that expand button is visible
                child_count = parent.childCount()
                if child_count == 0:
                    parent.addChild(QTreeWidgetItem())

    def update_node_format(self, node):
        path = node.data(0, Qt.UserRole)
        if os.path.isdir(path) or path.endswith(":") or path.endswith(":\\"):
            if path.endswith(":") or path.endswith(":\\"):
                img = self.hard_drive_icon
            else:
                img = self.folder_icon
        else:
            if path.lower().endswith(self.default_extentsion):
                img = self.default_file_icon
            elif path.lower().endswith(".txt") or path.lower().endswith(".csv"):
                img = self.text_file_icon
            else:
                img = self.generic_file_icon
        # compute caption
        text = os.path.basename(path)
        #此处是根节点,即硬盘符号节点
        if text == "":  # in case of drive roots
            #text = path.strip(os.sep)
            if utils.is_windows():
                name = GetDriveDisplayName(path)
                text = name
            else:
                #去掉最后的路径分隔符
                text = path.strip(os.sep)

        node.setText(0," " + text)
        node.setIcon(0,img)
        node.setData(0, Qt.UserRole,path)

    def listdir(self, path="", include_hidden_files=False):
        key = str.upper
        if path == "" and utils.is_windows():
            drives = get_win_drives()
            #将所有硬盘符号后面加上路径分隔符
            result = [ drive + "\\" for drive in drives]
        else:
            if path == "":
                first_level = True
                path = "/"
            else:
                first_level = False
            result = [
                x
                for x in self.ListDir(path)
                if include_hidden_files
                or not fileutils.is_file_path_hidden(os.path.join(path, x))
            ]

            if first_level:
                result = ["/" + x for x in result]
        return sorted(result, key=key)
        
    def ListDir(self,path):
        for x in os.listdir(path):
            yield x

class FileFrame(QWidget):
    def __init__(self, master, show_hidden_files=False):
        super().__init__(master)
        self.__fsContextItem = None
        self.__createLayout()
        self._fscontextmenu = None

##        #鼠标双击Tree控件事件
        self.filesystemView.itemDoubleClicked.connect(self.on_double_click)
        self.filesystemView.setContextMenuPolicy(Qt.CustomContextMenu)
        self.filesystemView.customContextMenuRequested.connect(
            self.__fsContextMenuRequested)
            
    def __fsContextMenuRequested(self):
        if self._fscontextmenu is None:
            self._fscontextmenu = NewQMenu(self)
            self._fscontextmenu.Append(menuitems.ID_REFRESH_PATH, _("&Refresh"),handler=self.RefreshPath)
            self._fscontextmenu.Append(menuitems.ID_OPEN_CMD_PATH, _("Open Command Prompt here..."),handler=self.OpenPathInterminal)
            self._fscontextmenu.Append(menuitems.ID_COPY_FULLPATH, _("Open Path in Explorer"),handler=self.OpenPathInexplower)
            self._fscontextmenu.Append(menuitems.ID_ADD_FOLDER, _("&Create new folder"),handler=self.create_new_folder)
            self._fscontextmenu.Append(menuitems.ID_CREATE_NEW_FILE, _("&Create new file"),handler=self.create_new_file)
        self._fscontextmenu.popup(QCursor.pos())
        
    def RefreshPath(self,node_id=None):
        selected_path = self.filesystemView.get_selected_path()
        node = self.filesystemView.get_selected_node()
        if not os.path.exists(selected_path):
            node = node.parent()
        node.takeChildren()
        try:
            self.filesystemView.refresh_tree(node,True)
        except Exception as e:
            QMessageBox.critical(self,_("Error"),str(e))
        
    def OpenPathInexplower(self):
        selected_path = self.filesystemView.get_selected_path()
        fileutils.safe_open_file_directory(selected_path)
        
    def OpenPathInterminal(self):
        selected_path = self.filesystemView.get_selected_path()
        if os.path.isfile(selected_path):
            selected_path = os.path.dirname(selected_path)
        try:
            fileutils.open_path_in_terminator(selected_path)
        except RuntimeError as e:
            QMessageBox.critical(self,_("Error"),str(e))

    def create_new_file(self):
        selected_path = self.filesystemView.get_selected_path()

        if not selected_path:
            return

        if os.path.isdir(selected_path):
            parent_path = selected_path
        else:
            parent_path = os.path.dirname(selected_path)

        initial_name = self.get_proposed_new_file_name(parent_path, self.filesystemView.default_extentsion)
        ok, name = simpledialog.askstring(
            "File name",
            "Provide filename",
            initialvalue=initial_name
        )
        if not ok:
            return
        path = os.path.join(parent_path, name)
        if os.path.exists(path):
            QMessageBox.critical(self,"Error", "The file '" + path + "' already exists")
            return
        else:
            open(path, "w").close()

        self.filesystemView.open_path_in_browser(path, True)
        get_app().GotoView(path)

    def create_new_folder(self):
        selected_path = self.filesystemView.get_selected_path()
        if not selected_path:
            return
        if os.path.isdir(selected_path):
            parent_path = selected_path
        else:
            parent_path = os.path.dirname(selected_path)

        initial_name = self.get_proposed_new_file_name(parent_path, "","newfoler")
        ok,name = simpledialog.askstring(
            _("New folder"),
            "Provide folder name",
            initialvalue=initial_name,
        )

        if not ok:
            return
            
        path = os.path.join(parent_path, name)
        try:
            os.mkdir(path)
        except Exception as e:
            QMessageBox.critical(self,_("Error"),str(e))
            return

        self.filesystemView.open_path_in_browser(path, True)

    def get_proposed_new_file_name(self, folder, extension,base = "new_file"):
        if os.path.exists(os.path.join(folder, base + extension)):
            i = 2
            while True:
                name = base + "_" + str(i) + extension
                path = os.path.join(folder, name)
                if os.path.exists(path):
                    i += 1
                else:
                    return name
        else:
            return base + extension

    def on_secondary_click(self, event):
        node_id = self.tree.identify_row(event.y)
        if node_id:
            self.tree.selection_set(node_id)
            self.tree.focus(node_id)
            self.menu.tk_popup(event.x_root, event.y_root)

    def on_double_click(self, item):
        path = self.filesystemView.get_selected_path(item)
        if os.path.isfile(path):
            ext = strutils.get_file_extension(path)
            if utils.is_ext_supportable(ext):
                get_app().GotoView(path,lineNum=0,load_outline=False)
            else:
                try:
                    fileutils.startfile(path)
                    #检查文件扩展名是否有对应的文件扩展插件
                   # ui_utils.CheckFileExtension(path,True)
                except:
                    utils.get_logger().exception("")
            #双击文件时,记住并保存文件夹的状态
            self.filesystemView.save_current_folder(path)
        elif os.path.isdir(path):
            self.filesystemView.refresh_tree(item, True)
            #GetApp().event_generate(constants.DOUBLECLICKPATH_EVT,path=path)
            
    def __createLayout(self):
        """Helper to create the viewer layout"""
       # self.clViewer = BaseFileBrowser()
        self.lower = self.__createFilesystemPartLayout()

##        # Toolbar part - buttons
##        self.definitionButton = QAction(
##            getIcon('definition.png'),
##            'Jump to highlighted item definition', self)
##        self.definitionButton.triggered.connect(self.__goToDefinition)
##        self.findButton = QAction(
##            getIcon('findusage.png'),
##            'Find highlighted item occurences', self)
##        self.findButton.triggered.connect(self.__findWhereUsed)
##        self.copyPathButton = QAction(
##            getIcon('copymenu.png'), 'Copy path to clipboard', self)
##        self.copyPathButton.triggered.connect(self.clViewer.copyToClipboard)
##
##        self.toolbar = ToolBar(self)
##        self.toolbar.setMovable(False)
##        self.toolbar.setAllowedAreas(Qt.TopToolBarArea)
##        self.toolbar.setIconSize(QSize(16, 16))
##        self.toolbar.setContentsMargins(0, 0, 0, 0)
##        self.toolbar.addAction(self.definitionButton)
##        self.toolbar.addAction(self.findButton)
##        self.toolbar.addAction(self.copyPathButton)
##
##        filterLabel = QLabel("  Filter ")
##        filterLabel.setStyleSheet('background: transparent')
##        self.toolbar.addWidget(filterLabel)
##        self.filterEdit = CDMComboBox(True, self.toolbar)
##        self.filterEdit.setSizePolicy(QSizePolicy.Expanding,
##                                      QSizePolicy.Expanding)
##        self.filterEdit.lineEdit().setToolTip(
##            "Space separated regular expressions")
##        self.toolbar.addWidget(self.filterEdit)
##        self.filterEdit.editTextChanged.connect(self.__filterChanged)
##        self.filterEdit.itemAdded.connect(self.__filterItemAdded)
##        self.filterEdit.enterClicked.connect(self.__enterInFilter)
##
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.lower)
      #  layout.addWidget(self.clViewer)

        self.setLayout(layout)
        self.__updateFSToolbarButtons()
    def __createFilesystemPartLayout(self):
        """Creates the lower part of the project viewer"""
        # Header part: label + show/hide button

        # Tree view part
        self.filesystemView = FileBrowser()
##        self.filesystemView.sigFirstSelectedItem.connect(
##            self.__fsSelectionChanged)
##        self.filesystemView.setContextMenuPolicy(Qt.CustomContextMenu)
##        self.filesystemView.customContextMenuRequested.connect(
##            self.__fsContextMenuRequested)

        # Toolbar part - buttons
        self.fsFindInDirButton = QAction(
            load_icon('findindir.png'), 'Find in highlighted directory', self)
        self.fsFindInDirButton.triggered.connect(
            self.findInDirectory)
        self.fsAddTopLevelDirButton = QAction(
            load_icon('addtopleveldir.png'),
            'Add as a top level directory', self)
        self.fsAddTopLevelDirButton.triggered.connect(self.addToplevelDir)
        self.fsRemoveTopLevelDirButton = QAction(
            load_icon('removetopleveldir.png'),
            'Remove from the top level directories', self)
       # self.fsRemoveTopLevelDirButton.triggered.connect(
        #    self.removeToplevelDir)
        self.fsShowParsingErrorsButton = QAction(
            load_icon('showparsingerrors.png'), 'Show lexer/parser errors', self)
      #  self.fsShowParsingErrorsButton.triggered.connect(
       #     self.showFsParserError)
        self.fsCopyToClipboardButton = QAction(
            load_icon('copymenu.png'), 'Copy path to clipboard', self)
        self.fsCopyToClipboardButton.triggered.connect(
            self.copyToClipboard)
        self.fsReloadButton = QAction(load_icon('reload.png'),
                                      'Re-read the file system tree', self)
        self.fsReloadButton.triggered.connect(self.reload)

        self.lowerToolbar = QToolBar()
        self.lowerToolbar.setMovable(False)
        self.lowerToolbar.setAllowedAreas(Qt.TopToolBarArea)
        self.lowerToolbar.setIconSize(QSize(16, 16))
        self.lowerToolbar.setContentsMargins(0, 0, 0, 0)
        self.lowerToolbar.addAction(self.fsFindInDirButton)
        self.lowerToolbar.addAction(self.fsAddTopLevelDirButton)
        self.lowerToolbar.addAction(self.fsRemoveTopLevelDirButton)
        self.lowerToolbar.addAction(self.fsCopyToClipboardButton)
        self.lowerToolbar.addAction(self.fsShowParsingErrorsButton)
        self.lowerToolbar.addWidget(ToolBarExpandingSpacer(self))
        self.lowerToolbar.addAction(self.fsReloadButton)

        fsLayout = QVBoxLayout()
        fsLayout.setContentsMargins(0, 0, 0, 0)
        fsLayout.setSpacing(0)
        fsLayout.addWidget(self.lowerToolbar)
        fsLayout.addWidget(self.filesystemView)

        lowerContainer = QWidget()
        lowerContainer.setContentsMargins(0, 0, 0, 0)
        lowerContainer.setLayout(fsLayout)
        return lowerContainer       
        
    def __updateFSToolbarButtons(self):
        """Updates the toolbar buttons depending on the __fsContextItem"""
        self.fsFindInDirButton.setEnabled(False)
        self.fsAddTopLevelDirButton.setEnabled(False)
        self.fsRemoveTopLevelDirButton.setEnabled(False)
        self.fsShowParsingErrorsButton.setEnabled(False)
        self.fsCopyToClipboardButton.setEnabled(False)

        if self.__fsContextItem is None:
            return

        if self.__fsContextItem.itemType not in \
           [NoItemType, SysPathItemType, GlobalsItemType,
            ImportsItemType, FunctionsItemType,
            ClassesItemType, StaticAttributesItemType,
            InstanceAttributesItemType]:
            self.fsCopyToClipboardButton.setEnabled(True)

        if self.__fsContextItem.itemType == DirectoryItemType:
            self.fsFindInDirButton.setEnabled(True)
            globalData = GlobalData()
            if globalData.project.isLoaded():
                if globalData.project.isTopLevelDir(
                        self.__fsContextItem.getPath()):
                    if self.__fsContextItem.parentItem.itemType == NoItemType:
                        self.fsRemoveTopLevelDirButton.setEnabled(True)
                else:
                    if self.__fsContextItem.parentItem.itemType != NoItemType:
                        self.fsAddTopLevelDirButton.setEnabled(True)

        if self.__fsContextItem.itemType == FileItemType:
            if isPythonMime(self.__fsContextItem.fileType) and \
               'broken-symlink' not in self.__fsContextItem.fileType:
                self.fsShowParsingErrorsButton.setEnabled(
                    self.__fsContextItem.parsingErrors)     
                    
    def findInDirectory(self):
        pass
        
    def addToplevelDir(self):
        pass
        
    def copyToClipboard(self):
        """Copies the path to the file where the element is to the clipboard"""
        item = self.model().item(self.currentIndex())
        path = item.getPath()
        QApplication.clipboard().setText(path)
        
    def reload(self):
        pass

##class FileviewOptionPanel(ui_utils.CommonOptionPanel):
##    """
##    """
##    def __init__(self, parent):
##        ui_utils.CommonOptionPanel.__init__(self, parent)
##        self._saveFolderCheckVar = tk.IntVar(value=utils.profile_get_int(SAVE_OPEN_FOLDER_KEY, True))
##        #记住上次打开文件夹状态,只有双击文件时才能记住文件夹打开状态
##        saveFoldeCheckBox = ttk.Checkbutton(self.panel,text=_("Load last open folder state When program startup"),variable=self._saveFolderCheckVar)
##        saveFoldeCheckBox.pack(fill=tk.X)
##
##        self._execute_cd_CheckVar = tk.IntVar(value=utils.profile_get_int("ExecuateCdDoubleClick", True))
##        execute_cdCheckBox = ttk.Checkbutton(self.panel,text=_("Execute 'cd' command in python shell When double click folder"),variable=self._execute_cd_CheckVar)
##        execute_cdCheckBox.pack(fill=tk.X)
##
##    def OnOK(self, optionsDialog):
##        utils.profile_set(SAVE_OPEN_FOLDER_KEY, self._saveFolderCheckVar.get())
##        utils.profile_set("ExecuateCdDoubleClick", self._execute_cd_CheckVar.get())
##        return True
##        


#首选项显示面板                
#preference.PreferenceManager().AddOptionsPanelClass("Misc","File View",FileviewOptionPanel)
