# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        about.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-05-10
# Copyright:   (c) wukan 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from .. import get_app, _
from ..util import apputils, ui_utils
import webbrowser
import datetime
import platform
from ..qtimage import load_image
from ..plugin import iface, plugin
from ..lib.pyqt import QDialog, QLabel, QVBoxLayout, Qt, QDialogButtonBox
from .. import menuitems

class AboutDialog(QDialog):
    def __init__(self, parent):
        """
        Initializes the about dialog.
        """
        super().__init__(parent)
        title = _("About ") + get_app().GetAppName()
        self.setWindowTitle(title)
        app_version = apputils.get_app_version()
        if apputils.is_dev():
            app_version += "dev"
        vbox = QVBoxLayout()
        head_text = get_app().GetAppName() + ' '  + app_version
        heading_label = QLabel(head_text)
        heading_label.setStyleSheet("color:rgb(0,0,0);font-size:19px;font-weight:bold;font-family:Arial;")
        heading_label.setAlignment(Qt.AlignCenter)
        vbox.setSpacing(20)
        vbox.addWidget(heading_label)
        
        logo_img = load_image("logo.png")
        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignCenter)
        logo_label.setPixmap(logo_img)
        vbox.addWidget(logo_label)

        url = "http://www.novalide.com"
        url_label = QLabel()
        url_label.setText(f"<A href='{url}'>{url}</a>")
        url_label.setAlignment(Qt.AlignCenter)
        url_label.setOpenExternalLinks(True)
        vbox.addWidget(url_label)
        

        platform_label = QLabel()
        text = "Python " + apputils.get_embed_python_version() + "PyQt " + ui_utils.getQtVersion() + '\nMAIL wekay102200@sohu.com\nQQ 273655394\nWX w89730387'
        platform_label.setText(text)
        platform_label.setAlignment(Qt.AlignCenter)
        vbox.addWidget(platform_label)
        
        credits_label = QLabel()
        credits_label.setText("<A href='https://gitee.com/wekay/NovalIDE'>%s</a>"%_("Based on the open source version →"))
        credits_label.setAlignment(Qt.AlignCenter)
        credits_label.setOpenExternalLinks(True)
        vbox.addWidget(credits_label)
        
        text = _("Copyright © 2018-") + str(datetime.datetime.now().year) + _(" wukan\nAll rights reserved")
        license_label = QLabel()
        license_label.setText(text)
        license_label.setAlignment(Qt.AlignCenter)
        vbox.addWidget(license_label)

        buttonBox = QDialogButtonBox(self)
        buttonBox.setOrientation(Qt.Horizontal)
        buttonBox.setStandardButtons(QDialogButtonBox.Ok)
        buttonBox.setCenterButtons(True)
        buttonBox.accepted.connect(self.accept)
        vbox.addWidget(buttonBox)
        self.setLayout(vbox)


class AboutLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)
    def Load(self):
        get_app().AddCommand(
            menuitems.ID_ABOUT,
            _("&Help"),
            _("&About"),
            self.OnAbout,
            image="about.png"
        )

    def OnAbout(self):
        aboutdlg = AboutDialog(get_app().GetTopWindow())
        aboutdlg.exec_()
