# -*- coding: utf-8 -*-
import os
import threading
import gettext
from . import ui_lang
from . import prog_lang


_lock = threading.Lock()

def newid():
    global _idCounter
    
    with _lock:
        _idCounter += 1
    return _idCounter

def get_app():
    global _AppInstance
    
    assert(_AppInstance is not None)
    return _AppInstance

class Locale:
    def __init__(self,lang_id):
        self._lang_id = lang_id
        self._domains = []
        self._trans = []
        self._lookup_dirs = []

    @property
    def lang_id(self):
        return self._lang_id

    def add_catalog_lookup_pathprefix(self,lookup_dir):
        lookup_dir = os.path.normpath(lookup_dir)
        if lookup_dir not in self._lookup_dirs:
            self._lookup_dirs.append(lookup_dir)
    
    def add_catalog(self,domain):
        
        if domain in self._domains:
            raise RuntimeError("domain %s already exist in locale domains" % domain)
        self._domains.append(domain)
        
        for lookup_dir in self._lookup_dirs:
            #搜索翻译文件存储目录,中文简体为zh_CN目录,英文目录为en_US,具体语言对应的目录参见ui_lang模块LANGUAGE_LIST
            t = gettext.translation(domain, lookup_dir, languages = [self.GetLanguageCanonicalName()],fallback=True)
            self._trans.append(t)
            
    def GetLanguageName(self):
        for lang in ui_lang.LANGUAGE_LIST:
            if lang[0] == self._lang_id:
                return lang[2]
        raise RuntimeError("unknown lang id %d",self._lang_id)
        
    def GetLanguageCanonicalName(self):
        for lang in ui_lang.LANGUAGE_LIST:
            if lang[0] == self._lang_id:
                return lang[1]
        raise RuntimeError("unknown lang id %d",self._lang_id)
        
    def get_text(self,raw_text):
        for tran in self._trans:
            to_text = tran.gettext(raw_text)
            if to_text != raw_text:
                return to_text
        return raw_text
        
    @classmethod
    def is_available(cls,lang_id):
        for lang in ui_lang.LANGUAGE_LIST:
            if lang[0] == lang_id:
                return True
        return False
        
def _get_translation(raw_text):
    global _AppInstance
    assert (_AppInstance is not None)
    return _AppInstance.GetLocale().get_text(raw_text)
    
def get_prog_lang():
    return prog_lang.LANGUAGE_DEFAULT
    
_ = _get_translation

_idCounter = 1000
_AppInstance = None
