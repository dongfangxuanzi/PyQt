# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""Codimension main window menu"""
import copy
from . import _
import os.path
from .keybinds import DEFAULT_KEY_BINDS
from typing import NamedTuple, Callable
from .qtimage import empty_icon
from .lib.pyqt import QMenu, QAction
from .constants import NORMAL_MENU_ITEM_KIND, CHECK_MENU_ITEM_KIND
    
class MenuItem(NamedTuple):
    id: int
    action: QAction
    tester: Callable
    menu: QMenu
    
class KeyBinder:
    """Class for managing keybinding configurations"""
    cprofile = None # Current Profile Name String
    key_binds = copy.copy(DEFAULT_KEY_BINDS) # Active Profile (dict)
    KEY_BINDING_FILE = "keybinding.json"
    def __init__(self):
        """Create the KeyBinder object"""
        # Attributes
        self.cache = None
        
    def LoadCacheKeybinds(self):
        '''
            从配置文件中加载自定义快捷键配置
        '''
        self.GetCachedir()
        key_binding_file = os.path.join(self.cache,self.KEY_BINDING_FILE)
        if os.path.exists(key_binding_file):
            try:
                with open(key_binding_file) as f:
                     data = json.load(f)
                     binds = {}
                     for key in data:
                         binds[getattr(constants,key)] = data[key]
                     #替换默认快捷键配置
                     KeyBinder.key_binds = binds
            except:
                utils.get_logger().exception("")
        
    def GetCachedir(self):
        if self.cache is None:
            self.cache = os.path.join(utils.get_user_data_path(),consts.USER_CACHE_DIR)
        return self.cache
        
    @classmethod
    def CheckKeybindsConflict(cls):
        '''
            检查快捷键冲突
        '''
        accels = list(cls.key_binds.values())
        for accel in accels:
            temp_list = accels
            temp_list.remove(accel)
            if temp_list.count(accel) != 0:
                raise RuntimeError("accelerator %s is conflicted...." % accel)

    @classmethod
    def GetCurrentProfile(cls):
        """Get the name of the currently set key profile if one exists
        @param cls: Class Object
        @return: string or None

        """
        return cls.cprofile

    @classmethod
    def GetCurrentProfileDict(cls):
        """Get the dictionary of keybindings
        @param cls: Class Object
        @return: dict

        """
        return cls.keyprofile

    @staticmethod
    def GetKeyProfiles():
        """Get the list of available key profiles
        @return: list of strings

        """
        recs = util.GetResourceFiles(u'cache', trim=True, get_all=False,
                                     suffix='.ekeys', title=False)
        if recs == -1:
            recs = list()

        tmp = util.GetResourceFiles(u'ekeys', True, True, '.ekeys', False)
        if tmp != -1:
            recs.extend(tmp)

        return recs

    def GetProfilePath(self, pname):
        """Get the full path to the given keyprofile
        @param pname: profile name
        @return: string or None
        @note: expects unique name for each profile in the case that
               a name exists in both the user and system paths the one
               found on the user path will be returned.

        """
        if pname is None:
            return None

        rname = None
        for rec in self.GetKeyProfiles():
            if rec.lower() == pname.lower():
                rname = rec
                break

        # Must be a new profile
        if rname is None:
            rname = pname

        kprof = u"%s%s.ekeys" % (ed_glob.CONFIG['CACHE_DIR'], rname)
        if not os.path.exists(kprof):
            # Must be a system supplied keyprofile
            rname = u"%s%s.ekeys" % (ed_glob.CONFIG['KEYPROF_DIR'], rname)
            if not os.path.exists(rname):
                # Doesn't exist at syspath either so instead assume it is a new
                # custom user defined key profile.
                rname = kprof
        else:
            rname = kprof

        return rname

    @classmethod
    def GetBinding(cls, item_id):
        """Get the raw key binding tuple
        @param cls: Class Object
        @param item_id: MenuItem Id
        @return: tuple

        """
        return cls.key_binds.get(item_id, None)

    @classmethod
    def FindMenuId(cls, keyb):
        """Find the menu item ID that the
        keybinding is currently associated with.
        @param cls: Class Object
        @param keyb: tuple of unicode (u'Ctrl', u'C')
        @return: int (-1 if not found)

        """
        menu_id = -1
        for key, val in cls.keyprofile.iteritems():
            if val == keyb:
                menu_id = key
                break
        return menu_id

    @classmethod
    def LoadDefaults(cls):
        """Load the default key profile"""
        cls.keyprofile = dict(_DEFAULT_BINDING)
        cls.cprofile = None

    def LoadKeyProfile(self, pname):
        """Load a key profile from profile directory into the binder
        by name.
        @param pname: name of key profile to load

        """
        if pname is None:
            ppath = None
        else:
            ppath = self.GetProfilePath(pname)
        self.LoadKeyProfileFile(ppath)

    def LoadKeyProfileFile(self, path):
        """Load a key profile from the given path
        @param path: full path to file

        """
        keydict = dict()
        pname = None
        if path:
            pname = os.path.basename(path)
            pname = pname.rsplit('.', 1)[0]

        if pname is not None and os.path.exists(path):
            reader = util.GetFileReader(path)
            if reader != -1:
                util.Log("[keybinder][info] Loading KeyProfile: %s" % path)
                for line in reader:
                    parts = line.split(u'=', 1)
                    # Check that the line was formatted properly
                    if len(parts) == 2:
                        # Try to find the ID value
                        item_id = _GetValueFromStr(parts[0])
                        if item_id is not None:
                            tmp = [ part.strip()
                                    for part in parts[1].split(u'+')
                                    if len(part.strip()) ]

                            # Do some checking if the binding is valid
                            nctrl = len([key for key in tmp
                                         if key not in (u'Ctrl', u'Alt', u'Shift')])
                            if nctrl:
                                if parts[1].strip().endswith(u'++'):
                                    tmp.append(u'+')
                                kb = tuple(tmp)
                                if kb in keydict.values():
                                    for mid, b in keydict.iteritems():
                                        if kb == b:
                                            del keydict[mid]
                                            break
                                keydict[item_id] = tuple(tmp)
                            else:
                                # Invalid key binding
                                continue

                reader.close()
                KeyBinder.keyprofile = keydict
                KeyBinder.cprofile = pname
                return
            else:
                util.Log("[keybinder][err] Couldn't read %s" % path)
        elif pname is not None:
            # Fallback to default keybindings
            util.Log("[keybinder][err] Failed to load bindings from %s" % pname)

        util.Log("[keybinder][info] Loading Default Keybindings")
        KeyBinder.LoadDefaults()

    def SaveKeyProfile(self):
        """Save the current key profile to disk"""
        if KeyBinder.cprofile is None:
            util.Log("[keybinder][warn] No keyprofile is set, cant save")
        else:
            ppath = self.GetProfilePath(KeyBinder.cprofile)
            writer = util.GetFileWriter(ppath)
            if writer != -1:
                itemlst = list()
                for item in KeyBinder.keyprofile.keys():
                    itemlst.append(u"%s=%s%s" % (_FindStringRep(item),
                                                self.GetBinding(item).lstrip(),
                                                os.linesep))
                writer.writelines(sorted(itemlst))
                writer.close()
            else:
                util.Log("[keybinder][err] Failed to open %s for writing" % ppath)

    @classmethod
    def SetBinding(cls, item_id, keys):
        """Set the keybinding of a menu id
        @param cls: Class Object
        @param item_id: item to set
        @param keys: string or list of key strings ['Ctrl', 'S']

        """
        if isinstance(keys, basestring):
            keys = [ key.strip() for key in keys.split(u'+')
                     if len(key.strip())]
            keys = tuple(keys)

        if len(keys):
            # Check for an existing binding
            menu_id = cls.FindMenuId(keys)
            if menu_id != -1:
                del cls.keyprofile[menu_id]
            # Set the binding
            cls.keyprofile[item_id] = keys
        elif item_id in cls.keyprofile:
            # Clear the binding
            del cls.keyprofile[item_id]
        else:
            pass

    @classmethod
    def SetProfileName(cls, pname):
        """Set the name of the current profile
        @param cls: Class Object
        @param pname: name to set profile to

        """
        cls.cprofile = pname

    @classmethod
    def SetProfileDict(cls, keyprofile):
        """Set the keyprofile using a dictionary of id => bindings
        @param cls: Class Object
        @param keyprofile: { menu_id : (u'Ctrl', u'C'), }

        """
        cls.keyprofile = keyprofile

class NewQMenu(QMenu):
    """Custom wxMenu class that makes it easier to customize and access items.

    """
    INVALID_ITEM_POS = -1
    INVALID_ITEM_ID = -1
    def __init__(self, parent_or_name, menubar=None):
        """Initialize a Menu Object
        @param title: menu title string
        @param style: type of menu to create

        """
        if menubar is not None:
            super().__init__(parent_or_name, menubar)
            menubar.addMenu(self)
        else:
            super().__init__(parent_or_name)
        self.name = parent_or_name
        self.images = []
        self._items = []
        self._submenus = []
        self.aboutToShow.connect(self._update_menu)
        
    @property
    def SubMenus(self):
        return self._submenus
        
    def Append(self, 
           item_id, 
           label, 
           handler=None,
           img=None,
           accelerator=None,
           tester=None,
           kind=NORMAL_MENU_ITEM_KIND
        ):
        """Append a MenuItem
        @param id_: New MenuItem ID
        @keyword text: Menu Label
        @keyword helpstr: Help String
        @keyword kind: MenuItem type
        @keyword use_bmp: try and set a bitmap if an appropriate one is
                          available in the ArtProvider

        """
        if img is None:
            img = empty_icon()
        args = [img, label, handler]
        if accelerator is not None:
            args.append(accelerator)
        if kind == NORMAL_MENU_ITEM_KIND:
            action = self.addAction(*args)
        elif kind == CHECK_MENU_ITEM_KIND:
            action = self.addAction(*args)
            action.setCheckable(True)
        elif kind == RADIO_MENU_ITEM_KIND:
            self.add_radiobutton(**kwargs)
        menu_item = MenuItem(item_id, action, tester, None)
        self._items.append(menu_item)
        return menu_item

    def AppendItem(self, item):
        """Appends a MenuItem to the menu and adds an associated
        bitmap if one is available, unless use_bmp is set to false.
        @param item: wx.MenuItem
        @keyword use_bmp: try and set a bitmap if an appropriate one is
                          available in the ArtProvider

        """
        self.addAction(item.action)
        menu_item = MenuItem(item.id,item.action,item.tester,item.menu)
        self._items.append(menu_item)
        
    def AppendMenu(self,menu_id,menu):
        self._submenus.append((menu_id,menu))
        menu_item = MenuItem(menu_id,None,None,menu)
        self._items.append(menu_item)
        self.addMenu(menu)
        
    def InsertMenu(self,pos,id_, text,menu):
        text = MenubarMixin.FormatMenuName(text)
        self._submenus.append((id_,menu))
        menu_menu_item = MenuItem(id_,text,None,None,None)
        self._items.insert(pos,menu_menu_item)
        self.insert(
            pos,
            "cascade",
            label= text,
            menu=menu
        )
        return menu_menu_item
        
    def InsertMenuAfter(self,item_id,id_, text,menu):
        '''
            插入某个子菜单
        '''
        pos = -1
        for i,menu_item in enumerate(self._items):
            if menu_item.id == item_id:
                pos = i
                break
        if pos >-1:
            mitem = self.InsertMenu(pos + 1, id_, text, menu)
        else:
            mitem = self.AppendMenu(id_, text,menu)
        return mitem
        
    def GetMenu(self,menuid):
        for menu in self._submenus:
            if menu[0] == menuid:
                return menu[1]
        return None
        
    def GetMenuByname(self,menu_name):
        menu_item = self.FindMenuItemByname(menu_name)
        if not menu_item:
            return None
        for menu in self._submenus:
            if menu[0] == menu_item.id:
                return menu[1]
        return None
        
    def find_pos(self, item_id):
        pos = self.INVALID_ITEM_POS
        for i, menu_item in enumerate(self._items):
            if menu_item.id == item_id:
                pos = i
                break
        return pos
        
    def InsertAfter(
            self, 
            after_id, 
            item_id, 
            label, 
            helpstr=u'', 
            handler=None,
            img=None,
            accelerator=None,
            kind=NORMAL_MENU_ITEM_KIND,
            tester=None
        ):
        pos = self.find_pos(after_id)
        if pos == self.INVALID_ITEM_POS:
            return self.Insert(pos, item_id, label, helpstr,handler,img,accelerator,kind,tester)
        else:
            return self.Insert(pos+1, item_id, label, helpstr,handler,img,accelerator,kind,tester)

    def InsertBefore(
            self, 
            before_id, 
            item_id, 
            label, 
            helpstr=u'', 
            handler=None,
            img=None,
            accelerator=None,
            kind=NORMAL_MENU_ITEM_KIND,
            tester=None
        ):
        pos = self.find_pos(before_id)
        return self.Insert(pos, item_id, label, helpstr,handler,img,accelerator,kind,tester)
    
    def Insert(
            self, 
            pos, 
            item_id, 
            label, 
            helpstr=u'', 
            handler=None,
            img=None,
            accelerator=None,
            kind=NORMAL_MENU_ITEM_KIND,
            tester=None
        ):
        """Insert an item at position and attach a bitmap
        if one is available.
        @param pos: Position to insert new item at
        @param id_: New MenuItem ID
        @keyword label: Menu Label
        @keyword helpstr: Help String
        @keyword kind: MenuItem type
        @keyword use_bmp: try and set a bitmap if an appropriate one is
                          available in the ArtProvider
        插入某个菜单项
        """
        if img is None:
            img = empty_icon()
        if pos == self.INVALID_ITEM_POS:
            return self.Append(
                item_id, 
                label, 
                handler,
                img,
                accelerator,
                kind,
                tester
            )
        item = self._items[pos]
        if item.id == self.INVALID_ITEM_ID:
           item = self._items[pos+1] 
        before_action = item.action
        action = QAction(img, label)
        if before_action is None:
            self.insertAction(
                self._items[pos].menu.menuAction(),
                action
            )
        else:
            self.insertAction(
                before_action,
                action
            )
        action.triggered.connect(handler)
        menu_item = MenuItem(item_id, action, tester, None)
        self._items.insert(pos,menu_item)
        return menu_item

    def RemoveItemByName(self, name):
        """Removes an item by the label. It will remove the first
        item matching the given name in the menu, the matching is
        case sensitive. The return value is the either the id of the
        removed item or None if the item was not found.
        @param name: name of item to remove
        @return: id of removed item or None if not found

        """
        menu_id = None
        for pos in range(self.GetMenuItemCount()):
            item = self.FindItemByPosition(pos)
            if name == item.GetLabel():
                menu_id = item.GetId()
                self.Remove(menu_id)
                break
        return menu_id
        
    def FindMenuItem(self,menu_id):
        for menu_item in self._items:
            if menu_item.id == menu_id:
                return menu_item
        return None

    def FindMenuItemByname(self,menu_name):
        for menu_item in self._items:
            if menu_item.label == menu_name:
                return menu_item
        return None
        
    def add_separator(self):
        menu_item = MenuItem(self.INVALID_ITEM_ID,None,None,None)
        self._items.append(menu_item)
        super().addSeparator()
        
    def GetItemCount(self):
        return len(self._items)
        
    def GetItemByIndex(self,index):
        return self._items[index]

    def delete(self,start,end="end"):
        if end == "end":
            end_index = len(self._items) -1
        else:
            end_index = end
        
        #倒序删除,防止数组越界或者索引错误
        for i in range(end_index,start-1,-1):
            item = self._items[i]
            super().removeAction(item.action)
            del self._items[i]
        
    def _update_menu(self):
        '''
            弹出菜单时更新菜单的可用状态
        '''
        for item in self._items:
            tester = item.tester
            #根据菜单回调函数返回bool值设置菜单是否是灰色状态
            #分割线
            if item.id == self.INVALID_ITEM_ID or item.action is None:
                continue
            elif tester and not tester():
                item.action.setEnabled(False)
            else:
                item.action.setEnabled(True)
                    
    def Enable(self,menu_id,enabled=True):
        for i in range(self.index("end") + 1):
            item_data = self.entryconfigure(i)
            if "label" in item_data:
                menu_item = self._items[i]
                if menu_id == menu_item.id:
                    if not enabled:
                        self.entryconfigure(i, state=tk.DISABLED)
                    else:
                        self.entryconfigure(i, state=tk.NORMAL)
                        
def find_menu(name, menubar):
    for child in menubar.children()[1:]:
        #todo 这里不知道什么地方会插入QMenu类型的子菜单，所有代码中添加的子菜单都是NewQMenu类型的
        #不知道pyqt框架内部什么时候会插入QMenu类型的,需要了解其内部机制,理解后再优化
        assert(isinstance(child, (QMenu, NewQMenu)))
        if child.title() == name:
            return child
    newmenu = NewQMenu(name, menubar)
    return newmenu

class MenubarMixin:

    """Main window menu mixin"""

    def __init__(self):
        pass

    def _initMainMenu(self):
        """Initializes the main menu bar"""
        menuBar = self.menuBar()
        self.__buildFilesMenu(menuBar)
        self.__buildEditMenu(menuBar)
        self.__buildViewMenu(menuBar)
        self.__buildFormatMenu(menuBar)
        self.__buildProjectMenu(menuBar)

    def __buildFilesMenu(self, menuBar):
        """Build the tab menu"""
        filesMenu = NewQMenu(_("&File"), menuBar)
        filesMenu.setObjectName('tab')
        return filesMenu

    def __buildEditMenu(self, menuBar):
        """Builds edit menu"""
        editMenu = NewQMenu(_("&Edit"), menuBar)
        editMenu.setObjectName('edit')
        return editMenu

    def __buildViewMenu(self, menuBar):
        """Build the view menu"""
        viewMenu = NewQMenu(_("&View"), menuBar)
        viewMenu.setObjectName('view')
        return viewMenu
        
    def __buildFormatMenu(self, menuBar):
        """Build the view menu"""
        formatMenu = NewQMenu(_("&Format"), menuBar)
        formatMenu.setObjectName('format')
        return formatMenu

    def __buildProjectMenu(self, menuBar):
        """Build the view menu"""
        projMenu = NewQMenu(_("&Project"), menuBar)
        projMenu.setObjectName('project')
        return projMenu

KEYBINDER = KeyBinder()