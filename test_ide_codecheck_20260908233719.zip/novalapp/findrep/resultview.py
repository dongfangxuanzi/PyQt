# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""Find in files viewer implementation"""
import re
import os
from .. import get_app, _
import logging
from uuid import uuid1
from ..qtimage import load_icon
from ..lib.pyqt import (Qt, QSize, QToolBar, QBrush, QHBoxLayout, QWidget, QAction,
                   QLabel, QFrame, QTreeWidget, QApplication, QTreeWidgetItem,
                   QHeaderView, QPalette, QColor, QStackedWidget, QSizePolicy,
                   QVBoxLayout, QPlainTextEdit, QMessageBox,pyqtSignal)
from ..widgets.spacers import ToolBarExpandingSpacer
from ..widgets.labels import HeaderLabel, HeaderFitLabel
from .findindir import FILENAME_MARKER,PROJECT_MARKER,FILE_MARKER,FindService

MAX_RESULTS = 32

class DoubleClickTextEdit(QPlainTextEdit):
    def __init__(self, parent):
        super().__init__(parent)
        
    def mouseDoubleClickEvent(self, event):
        cursor = self.textCursor()
        line = cursor.block().blockNumber()
        doc = self.document()
        line_text = doc.findBlockByNumber(line).text()
        res = re.match("^Line\s(?P<line>\d+):.*",line_text)
        if res is not None:
            defLineNum = line
            filename = self.GetDefineFilename(defLineNum)
            foundDoc = get_app().GetDocumentManager().GetDocument(filename)
            foundView = None
            if not foundDoc:
                if not os.path.exists(filename):
                    QMessageBox.critical(
                        self,
                        _("Open File Error"),
                        _("The file '%s' doesn't exist and couldn't be opened!") % filename
                    )
                    return
            get_app().GotoView(filename,lineNum=int(res.groupdict().get('line')),load_outline=False)

    def GetDefineFilename(self,defLineNum):        
        while defLineNum >0:
            lineText = self.document().findBlockByNumber(defLineNum).text()
            if lineText.find(FILENAME_MARKER) != -1 and lineText.find(FindService.LINE_PREFIX) == -1:
                filename = lineText.replace(FILENAME_MARKER,"").strip()
                return filename
            defLineNum -=1
        return None

class FindResultsview(QWidget):
    """Search results viewer tab widget"""
    MAX_LINES = 10000
    append_result_signal = pyqtSignal(str)

    def __init__(self, parent=None):
        QWidget.__init__(self, parent)

        self.__isEmpty = True

        self.__bufferChangeConnected = False

        self.__results = DoubleClickTextEdit(self)
        self.__results.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.__results.setReadOnly(True)
        self.__results.setMaximumBlockCount(FindResultsview.MAX_LINES)

        # Default font size is good enough for most of the systems.
        # 12.0 might be good only in case of the XServer on PC (Xming).
        # self.messages.setFontPointSize( 12.0 

        self.__createLayout(parent)
        self.__updateButtonsStatus()
        self.append_result_signal.connect(self.AddLine)

      #  GlobalData().project.sigProjectChanged.connect(self.__onProjectChanged)
      
    def emit_result_signal(self, line):
        self.append_result_signal.emit(line)

    def __createLayout(self, parent):
        """Creates the toolbar and layout"""
        del parent  # unused argument

        # Buttons etc.
        self.clearButton = QAction(load_icon('trash.png'),
                                   'Delete current results', self)
        self.clearButton.triggered.connect(self.__clear)

        self.prevButton = QAction(load_icon('1leftarrow.png'),
                                  'Previous results', self)
        self.prevButton.triggered.connect(self.__previous)

        self.nextButton = QAction(load_icon('1rightarrow.png'),
                                  'Next results', self)
        self.nextButton.triggered.connect(self.__next)

        self.doAgainButton = QAction(load_icon('searchagain.png'),
                                     'Do again', self)
        self.doAgainButton.triggered.connect(self.__doAgain)

        self.removeItemButton = QAction(load_icon('delitem.png'),
                                        'Remove currently selected item (Del)',
                                        self)
        self.removeItemButton.triggered.connect(self.__removeItem)

        # The toolbar
        self.toolbar = QToolBar(self)
        self.toolbar.setOrientation(Qt.Vertical)
        self.toolbar.setMovable(False)
        self.toolbar.setAllowedAreas(Qt.RightToolBarArea)
        self.toolbar.setIconSize(QSize(16, 16))
        self.toolbar.setFixedWidth(28)
        self.toolbar.setContentsMargins(0, 0, 0, 0)

        self.toolbar.addAction(self.prevButton)
        self.toolbar.addAction(self.nextButton)
        self.toolbar.addAction(self.doAgainButton)
        self.toolbar.addWidget(ToolBarExpandingSpacer(self.toolbar))
        self.toolbar.addAction(self.removeItemButton)
        self.toolbar.addAction(self.clearButton)

        self.__hLayout = QHBoxLayout()
        self.__hLayout.setContentsMargins(0, 0, 0, 0)
        self.__hLayout.setSpacing(0)
        self.__hLayout.addWidget(self.toolbar)
   #     self.__hLayout.addWidget(self.__noneLabel)
        self.__hLayout.addWidget(self.__results)
  #      self.__results.hide()

        self.setLayout(self.__hLayout)

    def getResultsViewer(self):
        """Provides a reference to the results tree"""
        return self.__results

    def __updateButtonsStatus(self):
        """Updates the buttons status"""
        if not self.__isEmpty:
##            index = self.__results.currentIndex()
##            widget = self.__results.currentWidget()
##            self.prevButton.setEnabled(index > 0)
##            self.nextButton.setEnabled(index < self.__results.count() - 1)
##            self.doAgainButton.setEnabled(widget.canDoAgain())
##            self.removeItemButton.setEnabled(widget.selectedItem is not None)
            self.clearButton.setEnabled(True)
        else:
            self.prevButton.setEnabled(False)
            self.nextButton.setEnabled(False)
            self.doAgainButton.setEnabled(False)
            self.removeItemButton.setEnabled(False)
            self.clearButton.setEnabled(False)

    def __updateIndicators(self):
        """Updates all the indicators"""
        total = self.__results.count()
        for index in range(total):
            self.__results.widget(index).updateIndicator(index + 1, total)

    def setFocus(self):
        """Overridden setFocus"""
       # self.__hLayout.setFocus()

    def __onProjectChanged(self, what):
        """Triggered when a project is changed"""
        if what == CodimensionProject.CompleteProject:
            self.__saveProjectResults()
            self.__populateForProject()

    def __connectBufferChange(self):
        """Connects the sigBufferChange"""
        if not self.__bufferChangeConnected:
            self.__bufferChangeConnected = True
            mainWindow = GlobalData().mainWindow
            editorsManager = mainWindow.editorsManagerWidget.editorsManager
            editorsManager.sigBufferModified.connect(self.onBufferModified)

    def __disconnectBufferChange(self):
        """Disconnects the sigBufferModified signal"""
        if self.__bufferChangeConnected:
            self.__bufferChangeConnected = False
            mainWindow = GlobalData().mainWindow
            editorsManager = mainWindow.editorsManagerWidget.editorsManager
            editorsManager.sigBufferModified.disconnect(self.onBufferModified)

    def onBufferModified(self, fileName, uuid):
        """Triggered when a buffer is modified"""
        for index in range(self.__results.count()):
            self.__results.widget(index).resultsTree.onBufferModified(
                fileName, uuid)

    def __previous(self):
        """Switch to the previous results"""
        if self.__isReportShown():
            index = self.__results.currentIndex()
            if index > 0:
                self.__results.setCurrentIndex(index - 1)
                self.__updateButtonsStatus()

    def __next(self):
        """Switch to the next results"""
        if self.__isReportShown():
            index = self.__results.currentIndex()
            if index < self.__results.count() - 1:
                self.__results.setCurrentIndex(index + 1)
                self.__updateButtonsStatus()

    def keyPressEvent(self, event):
        """Del key processing"""
        if event.key() == Qt.Key_Delete:
            event.accept()
            self.__removeItem()
        else:
            QWidget.keyPressEvent(self, event)

    def __removeItem(self):
        """Removes one entry of the search"""
        widget = self.__results.currentWidget()
        if widget.selectedItem is None:
            return

        widget.removeSelectedItem()
        if widget.resultsTree.topLevelItemCount() == 0:
            # The last result, need to remove the search result
            self.__clear()
        else:
            self.__updateButtonsStatus()

    def __clear(self):
        """Clears the content of the vertical layout"""
        if not self.__isReportShown():
            return

        index = self.__results.currentIndex()
        widget = self.__results.currentWidget()
        widget.clear()

        if self.__results.count() == 1:
            self.__results.hide()
            self.__noneLabel.show()
            self.__disconnectBufferChange()

        self.__results.removeWidget(widget)
        widget.deleteLater()

        if self.__results.count() > 0:
            if index >= self.__results.count():
                index -= 1
            self.__results.setCurrentIndex(index)

        self.__updateButtonsStatus()
        self.__updateIndicators()

    def __doAgain(self):
        """Performs the action once again"""
        if self.__isReportShown():
            self.__results.currentWidget().doAgain(self)

    def showReport(self, providerId, results, parameters, searchId=None):
        """Shows the find in files results"""
        # Memorize the screen width
        searchTooltip.setScreenWidth(
            GlobalData().application.desktop().screenGeometry().width())

        if searchId is None:
            resultWidget = ResultsViewerWidget(providerId, results,
                                               parameters,
                                               str(uuid1()), self)
            index = self.__results.addWidget(resultWidget)
        else:
            # Find the widget with this searchId
            found = False
            for index in range(self.__results.count()):
                if self.__results.widget(index).searchId == searchId:
                    found = True
                    break
            if not found:
                # add as a new one
                resultWidget = ResultsViewerWidget(providerId, results,
                                                   parameters,
                                                   str(uuid1()), self)
                index = self.__results.addWidget(resultWidget)
            else:
                # Repopulate it
                widget = self.__results.widget(index)
                widget.populate(results)

        self.__results.setCurrentIndex(index)

        # Show the complete information
        self.__noneLabel.hide()
        self.__results.show()

        self.__updateButtonsStatus()
        self.__updateIndicators()
        self.__connectBufferChange()

    def __populateForProject(self):
        """Load the project saved search results"""

    def __saveProjectResults(self):
        """Serialize to the disk the search results"""
        # Should not overwrite empty results when IDE is loaded

    def AddLine(self,line_text):
        self.__results.appendPlainText(line_text.strip())
        self.__results.ensureCursorVisible()
        self.__isEmpty = False
        self.__updateButtonsStatus()

    def ClearLines(self):
        #只读状态时无法删除数据需要先解除只读
        self.__isEmpty = True
        self.__results.clear()
        self.__updateButtonsStatus()
        
##    def ScrolltoEnd(self):
##        self.__results.ensureCursorVisible()
