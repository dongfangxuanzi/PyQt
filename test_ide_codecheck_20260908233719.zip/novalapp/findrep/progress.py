from ..lib.pyqt import QProgressDialog, pyqtSignal,QCoreApplication,QLabel,Qt

class FindTextQProgressDialog(QProgressDialog):
    
    update_progress_signal = pyqtSignal(int, str)
    def __init__(self, title, cancel_button_name, minimum, maximum, parent):
        super().__init__(title, cancel_button_name, minimum, maximum, parent)
        self.update_progress_signal.connect(self.update_progress)
        
        info_label = self.get_info_label()
        if info_label is not None:
            info_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        
    def get_info_label(self):
        for childctrl in self.children():
            if isinstance(childctrl, QLabel):
                return childctrl
        return None
        
    def update_progress(self, curval, msg):
        if msg == "end":
            self.setValue(self.maximum())
            self.close()
        else:
            self.setValue(curval)
            self.setLabelText(msg)
            QCoreApplication.processEvents()