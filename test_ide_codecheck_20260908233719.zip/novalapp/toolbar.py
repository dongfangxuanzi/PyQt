# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        toolbar.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-16
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
from typing import NamedTuple, Any
from .lib.pyqt import QToolBar, QAction, QComboBox

class ToolbarItem(NamedTuple):
    id: int
    action: QAction
    tester: Any

class ToolBar(QToolBar):
    def __init__(self,parent=None):
        super().__init__(parent)
        self._items = []

    def AddButton(self,command_id,action,add_separator=False,tester=None,pos=-1):
        self.addAction(action)
        if add_separator:
            self.AddSeparator()
        self.SetWidgetPos(command_id,action,pos,tester)
        shortcut = action.shortcut().toString()
        if shortcut:
            tooltip = action.toolTip()
            tooltip += " (" + shortcut + ")"
            action.setToolTip(tooltip)

    def Update(self):
        for item in self._items:
            tester = item.tester
            if item.id == -1:
                continue
            elif tester and not tester():
                item.action.setEnabled(False)
            else:
                item.action.setEnabled(True)
        
    def AddCombox(self,pos=-1,state='readonly'):
        combo = QComboBox()
        self.addWidget(combo)
        return combo

    def AddLabel(self,text,pos=-1):
        group_frame = self.CreateSlave()
        label = ttk.Label(group_frame,text=text)
        self.SetControlPos(-1,label,pos)

    def SetWidgetPos(self,command_id,action,pos,tester=None):
        '''
            pos为-1表示在最后添加控件,不为-1表示在某个位置插入控件
        '''
        update_layout = False
        if pos == -1:
            self._items.append(ToolbarItem(command_id,action, tester))
        #这里要插入控件,插入控件后需要重新排列控件
        else:
            update_layout = True
            self._items.insert(pos,[command_id,ctrl])

        if update_layout:
            #重新调整控件的位置
            self.UpdateLayout(pos)

    def UpdateLayout(self,pos):
        for i,data in enumerate(self._commands):
            ctrl = data[1]
            #所有位置大于pos的控件都需要重新排列
            if i>pos:
                if self._orient == tk.HORIZONTAL:
                    ctrl.grid(row=0,column=i)
                elif self._orient == tk.VERTICAL:
                    ctrl.grid(row=i,column=0)

    def AddSeparator(self):
        self._items.append(ToolbarItem(-1,None, None))
        self.addSeparator()
        
    def EnableTool(self,button_id,enable=True):
        for command_button in self._commands:
            if command_button[0] == button_id:
                button = command_button[1]
                if enable:
                    button["state"] = tk.NORMAL
                else:
                    button["state"] = tk.DISABLED