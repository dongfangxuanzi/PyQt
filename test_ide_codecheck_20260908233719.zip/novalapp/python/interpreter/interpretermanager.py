# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        InterpreterManager.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-10
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------

import sys
import os
from ... import get_app,_,newid
from ...util import apputils,utils,fileutils,strutils
import pickle
from . import interpreter as pythoninterpreter
import json
from ...lib.pyqt import QMessageBox
#import noval.constants as constants
from .exceptions import NotsupportInterpreterError, InvalidInterpreterError, UnknownVersionInterpreterError
from shutil import which
from ...widgets import simpledialog

BUILTIN_INTERPRETER_NAME = "Builtin_Interpreter"

class InterpreterManager:

    KEY_PREFIX = "interpreters"
    def __init__(self):
        self.interpreters = []
        self.DefaultInterpreter = None
        self.CurrentInterpreter = None

    def LoadDefaultInterpreter(self):
        if self.LoadPythonInterpretersFromConfig():
            self.SetCurrentInterpreter(self.DefaultInterpreter)
            return
        self.LoadPythonInterpreters()
        if 0 == len(self.interpreters):
            if apputils.is_windows():
                QMessageBox.warning(
                    None,
                    _("Python interpreter not found"),
                    _("No python interpreter found in your computer,will use the builtin interpreter instead")
                )
            else:
                QMessageBox.warning(
                    None,
                    _("No Interpreter"),
                    _("Python interpreter not found!")
                )

        if apputils.is_windows() and None == self.GetInterpreterByName(BUILTIN_INTERPRETER_NAME):
            self.LoadBuiltinInterpreter()
        if 1 == len(self.interpreters):
            self.MakeDefaultInterpreter()
        elif 1 < len(self.interpreters):
            self.ChooseDefaultInterpreter()
        self.SetCurrentInterpreter(self.DefaultInterpreter)
        #when load interpreter first,save the interpreter info to config
        self.SavePythonInterpretersConfig()
        
    def ShowChooseInterpreterDlg(self,parent=None):
        choices = []
        for interpreter in self.interpreters:
            choices.append(interpreter.name)
        result = simpledialog.asklist(_("Choose Interpreter"), _("Please Choose Default Interpreter:"),choices,0)
        if result != -1:
            name = choices[result]
            interpreter = self.GetInterpreterByName(name)
            return interpreter
        return None

    def ChooseDefaultInterpreter(self):
        interpreter = self.ShowChooseInterpreterDlg()
        if interpreter:
            self.SetDefaultInterpreter(interpreter)
        else:
            QMessageBox.warning(None,_("Choose Interpreter"),_("No default interpreter selected, application may not run normal!"))
            del self.interpreters[:]
            self.SetDefaultInterpreter(None)

    def GetInterpreterByName(self,name):
        for interpreter in self.interpreters:
            if name == interpreter.name:
                return interpreter
        return None

    def GetInterpreterByPath(self,path):
        for interpreter in self.interpreters:
            if path == interpreter.Path:
                return interpreter
        return None

    def LoadPythonInterpreters(self):
        if apputils.is_windows():
            from ...common import registry
            ROOT_KEY_LIST = [registry.HKEY_LOCAL_MACHINE,registry.HKEY_CURRENT_USER]
            ROOT_KEY_NAMES = ['LOCAL_MACHINE','CURRENT_USER']
            for k,root_key in enumerate(ROOT_KEY_LIST):
                try:
                    with registry.Registry(root_key).Open(r"SOFTWARE\Python\Pythoncore") as open_key:
                        for name in open_key.EnumChildKeyNames():
                            try:
                                child_key = open_key.Open(name)
                                install_path = child_key.Read("InstallPath")
                                interpreter_path = os.path.join(install_path,pythoninterpreter.PythonInterpreter.CONSOLE_EXECUTABLE_NAME)
                                if not os.path.exists(interpreter_path):
                                    utils.get_logger().error("interpreter name %s path %s from reg config is not exist",name,interpreter_path)
                                    continue
                                try:
                                    interpreter = pythoninterpreter.PythonInterpreter(name,interpreter_path)
                                    interpreter.gen_id()
                                except NotsupportInterpreterError as e:
                                    utils.get_logger().warning(str(e))
                                    continue
                                assert(interpreter.Id is not None)
                                self.interpreters.insert(0,interpreter)
                                help_key = child_key.Open("Help")
                                help_path = help_key.Read("Main Python Documentation")
                                interpreter.HelpPath = help_path
                                help_key.CloseKey()
                                child_key.CloseKey()
                                utils.get_logger().debug(
                                    "load python interpreter name:%s path:%s version:%s help path:%s",
                                    interpreter.name,
                                    interpreter.path,
                                    interpreter.Version,
                                    interpreter.HelpPath
                                )
                            except Exception as e:
                                utils.get_logger().warn("read python child regkey %s\\xxx\\%s error:%s",ROOT_KEY_NAMES[k],name,e)
                                utils.get_logger().exception("")
                                continue
                except Exception as e:
                    utils.get_logger().warn("load python interpreter from regkey %s error:%s",ROOT_KEY_NAMES[k],e)
                    ####utils.get_logger().exception("")
                    continue
            #还要到系统环境变量中去找解释器
            name = "python"
            python_path = which(name)
            if python_path is not None and os.path.exists(python_path):
                try:
                    interpreter = pythoninterpreter.PythonInterpreter(name,python_path)
                    interpreter.gen_id()
                    admin = InterpreterAdmin(self.interpreters)
                    if not admin.CheckInterpreterExist(interpreter):
                        utils.get_logger().info("find interpreter path %s from environment",python_path)
                        interpreter.Name = interpreter.Version
                        self.interpreters.insert(0,interpreter)
                        files = []
                        #获取python帮助文档路径
                        fileutils.GetDirFiles(os.path.join(os.path.dirname(python_path),"doc"),files,"chm")
                        if files:
                            interpreter.HelpPath = files[0]
                    else:
                        utils.get_logger().warn("interpreter path %s in environment is already exist",python_path)
                except (InvalidInterpreterError, UnknownVersionInterpreterError) as ex:
                    utils.get_logger().warning(str(ex))
        else:
            from .. import explain as explain_environment
            targets = explain_environment.get_targets("python")
            target_executables = [target[1] for target in targets]
            executable_path = sys.executable
            if executable_path not in target_executables:
                targets.append(("default",executable_path))
                    
            for cmd,target in targets:
                interpreter = pythoninterpreter.PythonInterpreter(cmd,target)
                interpreter.gen_id()
                self.interpreters.append(interpreter)

    def LoadPythonInterpretersFromConfig(self):
        '''
            从配置文件或者注册表中读取python解释器信息
        '''
        config = get_app().GetConfig()
        #windows从注册吧中读取
        if apputils.is_windows():
            data = config.Read(self.KEY_PREFIX)
            if not data:
                return False
            has_builtin_interpreter = False
            #python3存储的是binary类型
            if type(data) == bytes:
                lst = pickle.loads(data)
            else:
                #兼容python2存储类型
                lst = pickle.loads(bytes(data,encoding = utils.get_default_encoding()),encoding=utils.get_default_encoding())
            for l in lst:
                is_builtin = l.get('is_builtin',False)
                if is_builtin:
                    interpreter = pythoninterpreter.BuiltinPythonInterpreter(l['name'],l['path'],l['id'])
                    has_builtin_interpreter = True
                else:
                    try:
                        interpreter = pythoninterpreter.PythonInterpreter(l['name'],l['path'],l['id'],init_build=False)
                    except NotsupportInterpreterError as e:
                        utils.get_logger().warning(str(e))
                        continue
                interpreter.Default = l['default']
                if interpreter.Default:
                    self.SetDefaultInterpreter(interpreter)
                data = {
                    'version': l['version'],
                    'minor_version':l.get('minor_version',''),
                    #should convert tuple type to list
                    'builtins': list(l['builtins']),
                    #'path_list' is the old key name of sys_path_list,we should make compatible of old version
                    'sys_path_list': l.get('sys_path_list',l.get('path_list')),
                    'python_path_list': l.get('python_path_list',[]),
                    'is_builtin':is_builtin
                }
                interpreter.build_from_data(**data)
                interpreter.HelpPath = l.get('help_path','')
                interpreter.Environ.SetEnviron(l.get('environ',{}))
                interpreter.Packages = interpreter.LoaPackagesFromDict(l.get('packages',{}))
                self.interpreters.append(interpreter)
                path = interpreter.path
                utils.get_logger().debug('load python interpreter from app config name:%s path:%s,version:%s,builtin:%s',\
                                     interpreter.name,path,interpreter.Version,interpreter.IsBuiltIn)
            if len(self.interpreters) > 1 or (len(self.interpreters) == 1 and not has_builtin_interpreter):
                return True
        else:
            #Linux从配置文件中读取
            prefix = self.KEY_PREFIX
            data = config.Read(prefix)
            if not data:
                return False
            ids = data.split(os.pathsep)
            for id in ids:
                name = config.Read("%s/%s/Name" % (prefix,id))
                path = config.Read("%s/%s/Path" % (prefix,id))
                is_default = config.ReadInt("%s/%s/Default" % (prefix,id))
                version = config.Read("%s/%s/Version" % (prefix,id))
                minor_version = config.Read("%s/%s/MinorVersion" % (prefix,id),"")
                sys_paths = config.Read("%s/%s/SysPathList" % (prefix,id))
                python_path_list = config.Read("%s/%s/PythonPathList" % (prefix,id),"")
                builtins = config.Read("%s/%s/Builtins" % (prefix,id))
                environ = json.loads(config.Read("%s/%s/Environ" % (prefix,id),"{}"))
                packages = json.loads(config.Read("%s/%s/Packages" % (prefix,id),"{}"))
                interpreter = pythoninterpreter.PythonInterpreter(name,path,id,True)
                interpreter.Default = is_default
                interpreter.Environ.SetEnviron(environ)
                interpreter.Packages = interpreter.LoaPackagesFromDict(packages)
                if interpreter.Default:
                    self.SetDefaultInterpreter(interpreter)
                data = {
                    'version': version,
                    'minor_version':minor_version,
                    'builtins': builtins.split(os.pathsep),
                    'sys_path_list': sys_paths.split(os.pathsep),
                    'python_path_list':python_path_list.split(os.pathsep)
                }
                interpreter.build_from_data(**data)
                self.interpreters.append(interpreter)
            if len(self.interpreters) > 0:
                return True

        return False

    def ConvertInterpretersToDictList(self):
        lst = []
        for interpreter in self.interpreters:
            assert(interpreter.Id is not None)
            d = dict(
                id=interpreter.Id,
                name=interpreter.name,
                version=interpreter.Version,
                path=interpreter.path,
                default=interpreter.Default,
                sys_path_list=interpreter.sys_path_list,
                python_path_list=interpreter.python_path_list,
                builtins=interpreter.Builtins,
                help_path=interpreter.HelpPath,
                environ=interpreter.Environ.environ,
                packages=interpreter.DumpPackages(),
                is_builtin=interpreter.IsBuiltIn,
                minor_version=interpreter.MinorVersion
            )
            lst.append(d)
        return lst

    def SavePythonInterpretersConfig(self):
        '''
            保存解释器配置信息
        '''
        config = get_app().GetConfig()
        #windows写入注册表
        if apputils.is_windows():
            dct = self.ConvertInterpretersToDictList()
            if dct == []:
                return
            config.Write(self.KEY_PREFIX ,pickle.dumps(dct))
        #Linux写入配置文件
        else:
            prefix = self.KEY_PREFIX
            id_list = [ str(kl.Id) for kl in self.interpreters ]
            config.Write(prefix,os.pathsep.join(id_list))
            for kl in self.interpreters:
                assert(kl.Id is not None)
                config.WriteInt("%s/%d/Id"%(prefix,kl.Id),kl.Id)
                config.Write("%s/%d/Name"%(prefix,kl.Id),kl.name)
                config.Write("%s/%d/Version"%(prefix,kl.Id),kl.Version)
                config.Write("%s/%d/MinorVersion"%(prefix,kl.Id),kl.MinorVersion)
                config.Write("%s/%d/Path"%(prefix,kl.Id),kl.path)
                config.WriteInt("%s/%d/Default"%(prefix,kl.Id),kl.Default)
                config.Write("%s/%d/SysPathList"%(prefix,kl.Id),os.pathsep.join(kl.sys_path_list))
                config.Write("%s/%d/PythonPathList"%(prefix,kl.Id),os.pathsep.join(kl.python_path_list))
                config.Write("%s/%d/Builtins"%(prefix,kl.Id),os.pathsep.join(kl.Builtins))
                config.Write("%s/%d/Environ"%(prefix,kl.Id),json.dumps(kl.Environ.environ))
                config.Write("%s/%d/Packages"%(prefix,kl.Id),json.dumps(kl.DumpPackages()))

    def RemovePythonInterpreter(self,interpreter):
        #if current interpreter has been removed,choose default interpreter as current interpreter
        if interpreter == self.CurrentInterpreter:
            self.SetCurrentInterpreter(self.GetDefaultInterpreter())
        self.interpreters.remove(interpreter)

    def SetDefaultInterpreter(self,interpreter):
        '''
            设置默认解释器
        '''
        self.DefaultInterpreter = interpreter
        for kl in self.interpreters:
            if kl.Id == interpreter.Id:
                interpreter.Default = True
            else:
                kl.Default = False

    def MakeDefaultInterpreter(self):
        self.DefaultInterpreter = self.interpreters[0]
        self.DefaultInterpreter.Default = True

    def GetDefaultInterpreter(self):
        return self.DefaultInterpreter

    def GetChoices(self):
        choices = []
        default_index = -1
        for i,interpreter in enumerate(self.interpreters):
            #set current interpreter index as default index
            if interpreter == self.CurrentInterpreter:
                default_index = i
            choices.append(interpreter.Name)
        return choices,default_index

    def CheckIdExist(self,interpreter_id):
        for kb in self.interpreters:
            if kb.Id == interpreter_id:
                return True
        return False

    def GenerateId(self):
        interpreter_id = newid()
        while self.CheckIdExist(interpreter_id):
            interpreter_id = newid()
        return interpreter_id

    def IsInterpreterAnalysing(self):
        for kb in self.interpreters:
            if kb.Analysing:
                return True
        return False

    def SetCurrentInterpreter(self,interpreter):
        '''
            设置当前正在使用的解释器
        '''
        self.CurrentInterpreter = interpreter
        if interpreter is None:
            return

    def GetCurrentInterpreter(self):
        return self.CurrentInterpreter

    def LoadBuiltinInterpreter(self):
        builtin_interpreter = pythoninterpreter.BuiltinPythonInterpreter(BUILTIN_INTERPRETER_NAME,sys.executable)
        builtin_interpreter.gen_id()
        self.interpreters.append(builtin_interpreter)
        
    def GetInterpreterNames(self):
        names = []
        for interpreter in self.interpreters:
            names.append(interpreter.name)
        return names
        
INTERPRETER_MANAGER = InterpreterManager()
        
class InterpreterAdmin():
    def __init__(self,interpreters):
        self.interpreters = interpreters

    def CheckInterpreterExist(self,interpreter,is_virtual_env=False):
        for kb in self.interpreters:
            if kb.name.lower() == interpreter.name.lower():
                return True
            #解释器路径有可能不存在了
            #虚拟解释器的路径有可能是原解释器的一个链接,导致2者路径相同,需要排除添加虚拟解释器的情况
            elif os.path.exists(kb.path) and strutils.is_sample_file(kb.path,interpreter.path) and not is_virtual_env:
                return True
        return False

    def AddPythonInterpreter(self,interpreter_path,name,is_virtual_env=False):
        interpreter = pythoninterpreter.PythonInterpreter(name,interpreter_path)
        if not interpreter.IsValidInterpreter:
            raise RuntimeError(_("%s is not a valid interpreter path") % interpreter_path)
        interpreter.Name = name
        if self.CheckInterpreterExist(interpreter,is_virtual_env):
            raise RuntimeError(_("interpreter have already exist"))
        self.interpreters.append(interpreter)
        #first interpreter should be the default interpreter by default
        if 1 == len(self.interpreters):
            self.MakeDefaultInterpreter()
        return interpreter

    def GetInterpreterById(self,id):
        for interpreter in self.interpreters:
            if interpreter.Id == id:
                return interpreter
        return None

    def MakeDefaultInterpreter(self):
        self.interpreters[0].Default = True


