

class NotsupportInterpreterError(Exception):
    '''不支持的python的解释器'''
    
class UnknownVersionInterpreterError(Exception):
    '''未知版本的解释器'''
    

class InvalidInterpreterError(Exception):
    '''不是有效的解释器'''