import sys
import os

class BuiltinModule:
    BUILTMODULE_NAME = 'builtins'
    def __init__(self):
        self.members = []
        self.modname = BuiltinModule.BUILTMODULE_NAME
        self.doc = None
        
    def load(self,data):
        self.doc = data['doc']
        assert(data['name'] == self.modname)
        assert(data['is_builtin'])
        for data in data['childs']:
            self.members.append(data)
              
    def get_member(self, name):
        for member in self.members:
            if member['name'] == name:
                return member
        return None