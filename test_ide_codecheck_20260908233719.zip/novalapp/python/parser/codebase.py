from collections.abc import Sequence
from astroid import nodes
from . import node_utils
from .ast_walker import ASTWalker

class CodebaseParser(object):
    """description of class"""

    def __init__(self):
        self._visitors = []
        self.walker = ASTWalker()
        
    def prepare_visitors(self):
        raise NotImplementedError
        
    def visit_functiondef(self, node):
        raise NotImplementedError
        
    def visit_asyncfunctiondef(self, node):
        raise NotImplementedError
        
    def visit_classdef(self, node):
        raise NotImplementedError

    def visit_assign(self, node):
        raise NotImplementedError
       
    def visit_annassign(self, node):
        raise NotImplementedError
        
    def visit_import(self, node):
        raise NotImplementedError
        
    def visit_importfrom(self, node):
        raise NotImplementedError
        
    def visit_if(self, node):
        raise NotImplementedError
        
    def visit_tryexcept(self, node):
        raise NotImplementedError
        
    def visit_for(self, node):
        raise NotImplementedError
        
    def visit_return(self, node):
        raise NotImplementedError
        
    def visit_with(self, node):
        raise NotImplementedError
        
    def visit_while(self, node):
        raise NotImplementedError
        
    @staticmethod
    def is_none_empty(value):
        if value is None:
            return True
        elif value == "":
            return True
        return False

    def get_node_doc(self,node):
        if not isinstance(
            node, 
            (nodes.Module, nodes.ClassDef, nodes.FunctionDef)
        ):
            return None
        return node.doc

    def is_module_range(self, node):
        parent = node.parent 
        if isinstance(parent, nodes.Module):
            return True
        if isinstance(parent, (nodes.TryExcept, nodes.TryFinally,nodes.If)):
            while parent:
                if not isinstance(parent, (nodes.If, nodes.TryExcept, nodes.TryFinally,nodes.Module)):
                    return False
                elif node_utils.is_main_statement(parent):
                    return False
                parent = parent.parent
            return True
        else:
            return False
            
    def is_class_range(self, node):
        return isinstance(node.parent, nodes.ClassDef)
        
    def visit_child(self, child_node):
        cid = child_node.__class__.__name__.lower()
        visit_events: Sequence[ASTWalker.AstCallback] = self.walker.visit_events.get(cid, ())
        for callback in visit_events:
            callback(child_node)
            
    def find_base_class_module(slef, node, name):
        if isinstance(getattr(builtins, name, None), type):
            return builtins.__name__
        if node is None or node.parent is None:
            return None
        parent = node.parent
        for child in parent.get_children():
            if isinstance(child, nodes.ClassDef) and child.name == name:
                return ''
            elif isinstance(child, nodes.Import):
                for modename, asname in child.names:
                    if asname is None:
                        if modename == name:
                            return modename
                    else:
                        if asname == name:
                            return modename
            elif isinstance(child, nodes.ImportFrom):
                for childname, asname in child.names:
                    if asname is None:
                        if childname == name:
                            return child.modname + "." + childname
                    else:
                        if asname == name:
                            return child.modname + "." + asname
        return find_base_class_module(node.parent, name)
       
    def getbases(self, node):
        print(node.root(),node)
        base_names = []
        for base in node.bases:
            if isinstance(base, nodes.Name):
                base_class_module = self.find_base_class_module(node, base.name)
                if base_class_module is not None:
                    if base_class_module == '':
                        base_names.append(base.name)
                    else:
                        base_names.append(base_class_module + "." + base.name)
            elif isinstance(base, nodes.Attribute):
                name = base.expr.as_string()
                print(name)
                base_class_module = self.find_base_class_module(node, name)
                if base_class_module is not None:
                    base_name = base_class_module + "." + base.attrname
                    base_names.append(base_name)
        return base_names
