from ..lib.pyqt import QThread

class IntellisenceDataGen(QThread):
    """description of class"""
    def __init__(self, intellisencemanager,statusbar):
        super().__init__(statusbar)
        self.statusbar = statusbar
        self.intellisencemanager = intellisencemanager
