
IMPORT = "import"
FROMIMPORT = "importfrom"
FUNCTION_DEF = "functiondef"
ARGUMENT = 'arg' 
CLASS_DEF = "classdef"
OBJECT_PROPERTY = "objectproperty"
CLASS_PROPERTY = "classproperty"
MODULE = "module"