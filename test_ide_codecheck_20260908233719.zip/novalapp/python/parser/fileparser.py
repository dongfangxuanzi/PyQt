#coding:utf-8
import ast
import os
import traceback
import contextlib
from collections.abc import Callable, Iterator, Sequence
import sys
import functools
from . import node_utils
from .codebase import CodebaseParser
import logging
import astroid
from astroid import nodes
from .ast_walker import ASTWalker
from .moduleitem import ModuleItem
from . import nodetypes
from .. import prog_lang_ext
from .define import PACKAGE_INIT_FILE,CLASS_METHOD_NAME,STATIC_METHOD_NAME,CLASS_INIT_METHOD
from .exceptions import ReferenceModuleNotAnalyzedError 
from ..analysis.moduleloader import ModuleLoader

if sys.version_info >= (3, 8):
    from typing import Protocol
else:
    from typing_extensions import Protocol


class GetAstProtocol(Protocol):
    def __call__(
        self, filepath: str, modname: str, data: str | None = None
    ) -> nodes.Module:
        ...

MANAGER = astroid.MANAGER

logger = logging.getLogger('ide.codefile.parser')

IGNORE_CHECK_MODULES = ['os','types','functools','logging','traceback','argparse','collections','heapq','unittest']

class CodefileParser(CodebaseParser):

    def __init__(self,python_path_analyzer):
        super().__init__()
        self._python_path_analyzer = python_path_analyzer
        self.filepath = None
        self.node_childs = {}
        self._module_node = None
        
    def get_module_childs(self):
        return self.node_childs[self._module_node]
        
    def get_doc(self):
        return self.get_node_doc(self._module_node)

    def get_ast(
        self, filepath: str, modname: str, data: str | None = None
    ) -> nodes.Module | None:
        """Return an ast(roid) representation of a module or a string.

        :param filepath: path to checked file.
        :param str modname: The name of the module to be checked.
        :param str data: optional contents of the checked file.
        :returns: the AST
        :rtype: astroid.nodes.Module
        :raises AstroidBuildingError: Whenever we encounter an unexpected exception
        """
        try:
            if data is None:
                return MANAGER.ast_from_file(filepath, modname, source=True)
            return astroid.builder.AstroidBuilder(MANAGER).string_build(
                data, modname, filepath
            )
        except astroid.AstroidSyntaxError as ex:
            line = getattr(ex.error, "lineno", None)
            if line is None:
                line = 0
            logger.error('parse file %s syntax-error:%s',filepath,str(ex))
        except astroid.AstroidBuildingError as ex:
            self.add_message("parse-error", args=ex)
        except Exception as ex:
            traceback.print_exc()
            # We raise BuildingError here as this is essentially an astroid issue
            # Creating an issue template and adding the 'astroid-error' message is handled
            # by caller: _check_files
            raise astroid.AstroidBuildingError(
                "Building error when trying to create ast representation of module '{modname}'",
                modname=modname,
            ) from ex
        return None
        
    def _check_astroid_module(
        self,
        node: nodes.Module,
        walker: ASTWalker,
      #  rawcheckers: list[checkers.BaseRawFileChecker],
       # tokencheckers: list[checkers.BaseTokenChecker],
    ) -> bool | None:
        """Check given AST node with given walker and checkers.

        :param astroid.nodes.Module node: AST node of the module to check
        :param pylint.utils.ast_walker.ASTWalker walker: AST walker
        :param list rawcheckers: List of token checkers to use
        :param list tokencheckers: List of raw checkers to use

        :returns: True if the module was checked, False if ignored,
            None if the module contents could not be parsed
        """
        if not node.pure_python:
            self.add_message("raw-checker-failed", args=node.name)
        else:
            pass
      
        # generate events to astroid checkers
        walker.walk(node)
        return True
        
    def parse_single_file(self, name: str, filepath: str, modname: str) -> None:
        self.parse_single_file_item(ModuleItem(name, filepath, modname))

    def parse_single_file_item(self, file: ModuleItem) -> None:
        """Check single file item.

        The arguments are the same that are documented in _check_files

        initialize() should be called before calling this method
        """
        self.filepath = file.filepath
        with self._astroid_module_visitor() as parse_astroid_module:
            self._parse_file(self.get_ast, parse_astroid_module, file)
            
    def prepare_visitors(self):
        self._visitors.append(self.visit_functiondef)
        self._visitors.append(self.visit_classdef)
        self._visitors.append(self.visit_assign)
        self._visitors.append(self.visit_annassign)
        self._visitors.append(self.visit_import)
        self._visitors.append(self.visit_importfrom)
        self._visitors.append(self.visit_if)
        self._visitors.append(self.visit_tryexcept)
        return self._visitors

    @contextlib.contextmanager
    def _astroid_module_visitor(
        self,
    ) -> Iterator[Callable[[nodes.Module], bool | None]]:
        """Context manager for checking ASTs.

        The value in the context is callable accepting AST as its only argument.
        """
        
        _visitors = self.prepare_visitors()
        if len(_visitors) == 0:
            raise RuntimeError('empty node visitors')
        # notify global begin
        for visitor in _visitors:
            self.walker.add_visitor(visitor)

        yield functools.partial(
            self._check_astroid_module,
            walker=self.walker
        )
            
    def _parse_file(
        self,
        get_ast: GetAstProtocol,
        check_astroid_module: Callable[[nodes.Module], bool | None],
        file: ModuleItem,
    ) -> None:
        # get the module representation
        ast_node = get_ast(file.filepath, file.name)
        self._module_node = ast_node
        self.node_childs[ast_node] = []
        if ast_node is None:
            return

        self._ignore_file = False
        check_astroid_module(ast_node)
        
    def visit_functiondef(self, node):
        if not self.is_class_range(node) and not self.is_module_range(node):
            return
        def_name = node.name
        line_no = node.lineno
        col = node.col_offset
        
        is_property_def = False
        is_class_method = False
        decorators = node.decorators
        if decorators is not None:
            for deco in decorators.nodes:
                line_no += 1
                if isinstance(deco, nodes.Name):
                    #property装饰符
                    if deco.name == "property":
                        is_property_def = True
                        break
                    #classmthod和staticmethod装饰符
                    elif deco.name == CLASS_METHOD_NAME or deco.name == STATIC_METHOD_NAME:
                        is_class_method = True
                        break
        is_method = False
        default_arg_num = len(node.args.defaults)
        arg_num = len(node.args.args)
        args = []
        for i,arg in enumerate(node.args.args):
            is_default = False
            #the last serveral argments are default arg if default argment number is not 0
            #最后面几个是默认参数,如果默认参数不为空的话
            default_value = None
            if i >= arg_num - default_arg_num:
                is_default = True
                default_value = node.args.defaults[i - (arg_num - default_arg_num)].as_string()
            if arg.name == 'self' and isinstance(node.parent, nodes.ClassDef):
                is_method = True
            kwargs = {'is_default':is_default}
            if default_value is not None:
                kwargs.update({'value':default_value})
            arg_node = self._python_path_analyzer.make_node_dict(
                arg.name,
                nodetypes.ARGUMENT,
                line=arg.lineno,
                col=arg.col_offset,
                **kwargs
            )
            args.append(arg_node)
                    
        #可变列表参数,以*开头
        if node.args.vararg is not None:
            name = node.args.vararg
            arg_node = self._python_path_analyzer.make_node_dict(
                name,
                nodetypes.ARGUMENT,
                line=line_no,
                col=col,
                **{'is_var':True}
            )
            args.append(arg_node)
        #可变字典参数,以**开头
        if node.args.kwarg is not None:
            name = node.args.kwarg
            arg_node=self._python_path_analyzer.make_node_dict(
                name,
                nodetypes.ARGUMENT,
                line=line_no,
                col=col,
                **{'is_kw':True}
            )
            args.append(arg_node)
        doc = self.get_node_doc(node)
        #is_class_property必须是函数用property装饰并且为类方法时才为True
        if is_property_def and is_method:
            #类属性方法按对象属性处理
            func_def = self._python_path_analyzer.make_node_dict(
                def_name,
                nodetypes.OBJECT_PROPERTY,
                line=line_no,
                col=col,
                doc=doc
            )
        else:
            func_def = self._python_path_analyzer.make_node_dict(
                def_name,
                nodetypes.FUNCTION_DEF,
                line=line_no,
                col=col,
                doc=doc,
                **{'is_method':is_method,
                   'is_class_method':is_class_method,
                   'args':args
                }
            )
        if self.is_class_range(node):
            if node.parent in self.node_childs:
                self.node_childs[node.parent].append(func_def)
        elif self.is_module_range(node):
            self.node_childs[node.root()].append(func_def)
        if isinstance(node.parent, nodes.ClassDef) and node.name == CLASS_INIT_METHOD:
            for child in node.body:
                self.visit_child(child)

    def visit_import(self, node):
        if not self.is_module_range(node):
            return
        for name, asname in node.names:
            modname = name
            if name in IGNORE_CHECK_MODULES:
                continue
            self.check_refmod_analyzed(modname)
            if asname is not None:
                name = asname
            data = self._python_path_analyzer.make_node_dict(
                name,
                nodetypes.MODULE,
                line=node.lineno, 
                col=node.col_offset,
                **{'modname':modname}
            )
            self.node_childs[node.root()].append(data)
            
    def check_refmod_analyzed(self, modname):
        #查找内建模块
        if self._python_path_analyzer.interpreter.is_builtin_module(modname):
            membersfile,memberlistfile = self._python_path_analyzer.builtin_analyzer.get_member_filenames(modname)
        else:
            #查找系统路径下的模块
            membersfile,memberlistfile = self._python_path_analyzer.get_member_filenames(modname)
        logger.debug('reference module %s members file is %s',modname,membersfile)
        if not os.path.exists(membersfile):
            if self._python_path_analyzer.get_mod_file_path(modname) is None:
                return None, None
            else:
                raise ReferenceModuleNotAnalyzedError(f'reference module {modname} has not analyzed yet in pyton file {self.filepath}')
        return membersfile,memberlistfile
        
    def visit_importfrom(self, node):
        if not self.is_module_range(node):
            return
        mod_name = node.modname
        dir_path = os.path.dirname(self.filepath)
        #处理相对导入的情况
        #有相对导入
        if node.level is not None:
            #相对导入不含包或模块名称
            if self.is_none_empty(mod_name):
                modpath = os.path.abspath(os.path.join(dir_path, "." * node.level))
            #相对导入含包或模块名称
            else:
                modpath = os.path.abspath(os.path.join(dir_path, "." * node.level + os.sep + mod_name)) + "." + prog_lang_ext.PYTHON_CODE_FILE_EXT[0]
                if not os.path.exists(modpath):
                    modpath = os.path.abspath(os.path.join(dir_path, "." * node.level + os.sep + mod_name)) + os.sep + PACKAGE_INIT_FILE
                    if not os.path.exists(modpath):
                        return
                    
            mod_name = self._python_path_analyzer.get_relative_path(modpath)
        if mod_name in IGNORE_CHECK_MODULES:
            return
        membersfile,memberlistfile = self.check_refmod_analyzed(mod_name)
        if membersfile is None:
            return
        mdloader = ModuleLoader(mod_name,membersfile,memberlistfile)
        mdloader.load()
        for name, asname in node.names:
            if name == '*':
                childs = mdloader.data['childs']
                for child in childs:
                    kw = child
                    kw.update({'modname':mod_name})
                    data = self._python_path_analyzer.make_node_dict(**kw)
                    self.node_childs[node.root()].append(data)
            else:
                data = mdloader.find_child(name, mdloader.data['childs'])
                if data is None:
                    logger.error('could not find name %s in module %s',name,mod_name)
                    return
                if asname is not None:
                    data['name'] = asname
                    data['realname'] = name
                data.update({'modname':mod_name})
                self.node_childs[node.root()].append(data)
            
    def visit_assign(self, node):
        targets = node.targets
        line_no = node.lineno
        col = node.col_offset
        target = targets[0]
        #连等表达式
        if isinstance(target, nodes.Tuple):
            elts = target.elts
            for i,elt in enumerate(elts):
                if isinstance(elt, nodes.AssignName):
                    name = elt.name
                    if isinstance(node.value, nodes.Tuple):
                        kw = node_utils.get_const_node_value(node.value.elts[i])
                        data = self._python_path_analyzer.make_node_dict(
                            name,
                            nodetypes.OBJECT_PROPERTY,
                            line=elt.lineno,
                            col=elt.col_offset,
                            **kw
                        )
                        if self.is_module_range(node):
                            self.node_childs[node.root()].append(data)
                        elif self.is_class_range(node):
                            data['typenode'] = nodetypes.CLASS_PROPERTY
                            self.node_childs[node.parent].append(data)
                            
        elif isinstance(target, nodes.AssignName):
            name = target.name
            kw = node_utils.get_const_node_value(node.value)
            data = self._python_path_analyzer.make_node_dict(
                name,
                nodetypes.OBJECT_PROPERTY,
                line=line_no,
                col=col,
                **kw
            )
            if self.is_module_range(node):
                self.node_childs[node.root()].append(data)
            elif self.is_class_range(node) and node.parent in self.node_childs:
                data['typenode'] = nodetypes.CLASS_PROPERTY
                self.node_childs[node.parent].append(data)
        elif isinstance(target, nodes.AssignAttr):
            if not (isinstance(node.parent, nodes.FunctionDef) and node.parent.name == CLASS_INIT_METHOD):
                return
            #如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
            if isinstance(target.expr, nodes.Name) and target.expr.name == "self" \
                    and isinstance(node.parent.parent,nodes.ClassDef):
                name = target.attrname
                kw = node_utils.get_const_node_value(node.value)
                data = self._python_path_analyzer.make_node_dict(
                    name,
                    nodetypes.OBJECT_PROPERTY,
                    line=line_no,
                    col=col,
                    **kw
                )
                if node.parent.parent in self.node_childs:
                    self.node_childs[node.parent.parent].append(data)
            
    def visit_classdef(self, node):
        if not self.is_module_range(node):
            return
        class_name = node.name
        base_names = self.getbases(node)
        line_no = node.lineno
        col = node.col_offset
        doc = self.get_node_doc(node)
        class_def = self._python_path_analyzer.make_node_dict(
            class_name,
            nodetypes.CLASS_DEF,
            doc=doc,
            line=line_no,
            col=col,
            **{'bases':[]}
        )
        self.node_childs[node.root()].append(class_def)
        self.node_childs[node] = []
            
    def visit_tryexcept(self, node):
        if not self.is_module_range(node):
            return
        for orelse in node.orelse:
            self.visit_child(orelse)
        for handler in node.handlers:
            self.visit_child(handler)
        
    def visit_if(self, node):
        if node_utils.is_main_statement(node) or not self.is_module_range(node):
            return
        
        for orelse in node.orelse:
            if isinstance(orelse, nodes.If):
                for child in orelse.body:
                    self.visit_child(child)
            else:
                self.visit_child(orelse)
    
    def visit_annassign(self, node):
        line_no = node.lineno
        col = node.col_offset
        target = node.target
        if isinstance(target, nodes.AssignName):
            name = target.name
            annotation=node.annotation
            kw = node_utils.get_const_annnode_value(node)
            data = self._python_path_analyzer.make_node_dict(
                name,
                nodetypes.OBJECT_PROPERTY,
                line=target.lineno,
                col=target.col_offset,
                **kw
            )
            if self.is_module_range(node):
                self.node_childs[node.root()].append(data)
            elif self.is_class_range(node) and node.parent in self.node_childs:
                self.node_childs[node.parent].append(data)
        elif isinstance(target, nodes.AssignAttr):
            if not (isinstance(node.parent, nodes.FunctionDef) and node.parent.name == CLASS_INIT_METHOD):
                return
            #如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
            if isinstance(target.expr, nodes.Name) and target.expr.name == "self" \
                    and isinstance(node.parent.parent,nodes.ClassDef):
                name = target.attrname
                kw = node_utils.get_const_annnode_value(node)
                data = self._python_path_analyzer.make_node_dict(
                    name,
                    nodetypes.OBJECT_PROPERTY,
                    line=target.lineno,
                    col=target.col_offset,
                    **kw
                )
                if node.parent.parent in self.node_childs:
                    self.node_childs[node.parent.parent].append(data)
