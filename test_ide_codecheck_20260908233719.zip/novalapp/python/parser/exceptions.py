class ReferenceModuleNotAnalyzedError(Exception):
    '''引用模块还没有解析生成智能提示数据'''
    
class CodefileNotExistError(Exception):
    '''代码文件被删除或移走'''