from typing import NamedTuple

class ModuleItem(NamedTuple):
    """Represents data about a file handled by pylint.

    Each file item has:
    - name: full name of the module
    - filepath: path of the file
    - modname: module name
    """
    name: str
    filepath: str
    modpath: str