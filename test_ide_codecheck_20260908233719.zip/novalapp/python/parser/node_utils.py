from astroid import nodes
from .define import MAIN_FUNCTION_NAME

def get_const_value(value):
    kw = {}
    value_type = type(value)
    if nodes.node_classes._is_const(value):
        value_kind = value_type.__name__
        if isinstance(value, tuple):
            value = tuple(value)
            value_kind = 'tuple'
        kw.update({'value_kind':value_kind})
        if value_type not in [list, set, dict]:
            kw.update({'value':value})
    return kw
    
def get_const_pytype(type_value):
    return type_value.replace('builtins.','')
    
def get_const_node_value(node):
    if isinstance(node, nodes.Const):
        return {'value':node.value,'value_kind':get_const_pytype(node.pytype())}
    elif isinstance(node, nodes.UnaryOp):
        if node.op == '-' or node.op=='+':
            kw = get_const_node_value(node.operand)
            if kw:
                kw['value'] = node.as_string()
                return kw
    elif isinstance(node, nodes.List):
        return {'value_kind':'list'}
    elif isinstance(node, nodes.Set):
        return {'value_kind':'set'}
    elif isinstance(node, nodes.Dict):
        return {'value_kind':'dict'}
    elif isinstance(node, nodes.Tuple):
        return {'value_kind':'tuple'}
    elif isinstance(node, nodes.Call):
        if isinstance(node.func, nodes.Name):
            func_name = node.func.name
            if func_name in ['list', 'tuple', 'set', 'dict']:
                return {'value_kind':func_name}
    return {}
    
def get_const_annnode_value(node):
    annotation = node.annotation
    if isinstance(annotation, nodes.Subscript):
        if isinstance(annotation.value, nodes.Name):
            if annotation.value.name in ['list', 'tuple', 'set', 'dict']:
                return {'value_kind':annotation.value.name}
    elif isinstance(annotation, nodes.Name):
        if annotation.name in ['bool','int','float','complex','str','bytes']:
            kw = {'value_kind':annotation.name}
            if isinstance(node.value, nodes.Const):
                kw.update({'value':node.value.value})
            return kw
    return {}

def is_main_statement(element):
    if isinstance(element, nodes.If) and isinstance(element.test,nodes.Compare) and isinstance(element.test.left,nodes.Name) and element.test.left.name == "__name__" \
                and element.test.ops and isinstance(element.test.ops[0][1],nodes.Const) \
                and element.test.ops[0][1].value == MAIN_FUNCTION_NAME:
        return True
    return False
    
def get_node_type(node):
    if is_main_statement(node):
        return config.MAIN_FUNCTION_NAME
    elif isinstance(node, (nodes.Assign, nodes.AnnAssign)):
        if isinstance(node.parent, nodes.ClassDef):
            return config.CLASS_PROPERTY
        else:
            return config.OBJECT_PROPERTY
    else:
        return node.__class__.__name__.lower()
        