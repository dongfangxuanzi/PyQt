from astroid import nodes
import intellisence
                
def locate_in_scope(node, line):
    if node.lineno <= line <= node.end_lineno:
        return True
    return False

class ScopeFinder:
    def __init__(self, node):
        self.node = node
        
    def find_scope(self, line):
        for child in self.node.get_children():
            if locate_in_scope(child, line):
                if self.is_scope(child):
                    if self.is_end_scope(child):
                        return child
                    else:
                        found_scope = ScopeFinder(child).find_scope(line)
                        if found_scope is None:
                            return child
                        return found_scope
                else:
                    return child.parent
        if isinstance(self.node, nodes.Module):
            return self.node
        return None
                    
    def is_end_scope(self, node):
        if self.is_scope(node):
            for child_scope in node.body:
                if self.is_scope(child_scope):
                    return False
            return True
        return False
        
    def is_scope(self, node):
        return hasattr(node, 'body')
        
    def get_definitions(self, scope, name):
        names = name.strip().split('.')
        if not names:
            return []
        nodes = self.find_nodes(scope, names)

    def find_nodes(self, scope, names):
        pass
        
    def find_import_node(self, node, name):
        for modname, asname in node.names:
            if asname == name or modname == name:
                #node.names = [modname, asname]
                return node
        return None
                
    def find_fromimport_node(self, node, name):
        modname = node.modname
        for importname, asname in node.names:
            if asname == name or importname == name:
                #node.names = [modname, asname]
                return node
        return None

    def find_classdef_node(self, node, name):
        if node.name == name:
            return node
        return None

    def find_funcdef_node(self, node, name):
        if node.name == name:
            return node
        return None
        
    
        

    def VisitAnnAssignNode(self, element, parent):
        line_no = element.lineno
        col = element.col_offset
        target = element.target
        if isinstance(target, node_utils.nodes.AssignName):
            name = target.name
            kw = node_utils.get_const_annnode_value(element)
            current = self.tree.insert(
                    parent, "end", text=display_name, values=(child.lineno,child.col_offset,node_type), image=self.property_image
            )
        elif isinstance(target, node_utils.nodes.AssignAttr):
            #如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
            if isinstance(target.expr, nodes.Name) and target.expr.name == "self" \
                    and self.GetParentType(parent) == config.CLASS_DEF:
                name = target.attrname
                kw = node_utils.get_const_annnode_value(element)
                self.AddNodeData(name,line_no,col,config.OBJECT_PROPERTY,parent=parent,**kw)
                current = self.tree.insert(
                        parent, "end", text=display_name, values=(child.lineno,child.col_offset,node_type), image=self.property_image
                    )

    def find_assign(self, node, name):    
        target = node.targets[0]
        if isinstance(target, node_utils.nodes.Tuple):
            elts = target.elts
            for i,elt in enumerate(elts):
                if isinstance(elt, node_utils.nodes.AssignName):
                    elt_name = elt.name
                    if elt_name == name:
                        return elt
                    
        elif isinstance(target, node_utils.nodes.AssignName):
            if target.name == name:
                return target
        if isinstance(target, node_utils.nodes.AssignAttr):
            #如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
            if isinstance(target.expr, node_utils.nodes.Name) and target.expr.name == "self" \
                    and node_utils.get_node_type(element.parent.parent) == parserconfig.CLASS_DEF:
                name = target.attrname
            return current
