# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        outline.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-03-11
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
import os
from ... import get_app,_
from ...plugin import iface, plugin
from ...lib.pyqt import QTreeWidget, QWidget, Qt, QSize, QVBoxLayout, QAction, QToolBar, QLabel, QComboBox, QSizePolicy, QTreeWidgetItem
from ...toolbar import ToolBar
from ... import constants
from ...sidebar.outline import OutlineView
from ..analysis.module_analyzer import _code_parser
from ..parser import node_utils
##import noval.syntax.lang as lang
from ...util import utils, ui_utils
from ...qtimage import load_icon
##import noval.constants as constants
from ..editor import PythonView
from astroid import nodes
##import noval.preference as preference
##import noval.ui_utils as ui_utils
from ...sidebar import sidebar
from ..parser.define import CLASS_METHOD_NAME,STATIC_METHOD_NAME,CLASS_INIT_METHOD,MAIN_FUNCTION_NAME

class OutlineBrowser(QTreeWidget):
    def __init__(self, master=None):
        super().__init__(master)
        self.func_image = get_app().GetImage("python/outline/func.png")
        self.class_image = get_app().GetImage("python/outline/class.png")
        self.property_image = get_app().GetImage("python/outline/property.png")
        self.import_image = get_app().GetImage("python/outline/import.png")
        self.from_import_image = get_app().GetImage("python/outline/from_import.png")
        self.mainfunction_image = get_app().GetImage("python/outline/mainfunction.gif")
        self.error_image = get_app().GetImage("python/outline/error.png")
        
    def add_assign_node(self, name, node, parent):
        return self.add_item(name, node, parent, self.property_image)
        
    def add_func_node(self, name, node, parent):
        return self.add_item(name, node, parent, self.func_image)
        
    def add_import_node(self, name, node, parent):
        return self.add_item(name, node, parent, self.import_image)
        
    def add_fromimport_node(self, name, node, parent):
        return self.add_item(name, node, parent, self.from_import_image)
        
    def add_class_item(self, name, node, parent):
        return self.add_item(name, node, parent, self.class_image)
        
    def add_mainfunction_item(self, node, parent):
        return self.add_item(MAIN_FUNCTION_NAME, node, parent, self.mainfunction_image)
        
    def show_syntax_error(self, ex, parent):
        line = getattr(ex.error, "lineno", None)
        if line is None:
            line = 0
        self.add_item("syntax-error",ex,parent,self.error_image)
        #logger.error('parse file %s syntax-error:%s',filepath,str(ex))
        
    def add_item(self, name, node, parent, img):
        tree_item = QTreeWidgetItem()
        tree_item.setText(0," " + name)
        tree_item.setIcon(0,img)
        tree_item.setData(0, Qt.UserRole,node)
        parent.addChild(tree_item)
        return tree_item

class PythonOutlineView(OutlineView):
    
    DISPLAY_ITEM_NAME = 0
    DISPLAY_ITEM_LINE = 1
    DISPLAY_ITEM_CLASS_BASE = 2
    DISPLAY_ITEM_FUNCTION_PARAMETER = 4
    
    def __init__(self, master):
        super().__init__(master)
        self._display_item_flag = self.DISPLAY_ITEM_NAME
        #显示行号
        if utils.profile_get_int("OutlineShowLineNumber", True):
            self._display_item_flag |= self.DISPLAY_ITEM_LINE
        #显示参数
        if utils.profile_get_int("OutlineShowParameter", False):
            self._display_item_flag |= self.DISPLAY_ITEM_FUNCTION_PARAMETER
        #显示基类
        if utils.profile_get_int("OutlineShowBaseClass", False):
            self._display_item_flag |= self.DISPLAY_ITEM_CLASS_BASE
        self.node_childs = {}
        self.tree.itemSelectionChanged.connect(self._on_select)
            
    def createLayout(self):
        """Helper to create the viewer layout"""
        self.tree = OutlineBrowser()

        # Toolbar part - buttons
        self.definitionButton = QAction(
            load_icon('definition.png'),
            'Jump to highlighted item definition', self)
        self.definitionButton.triggered.connect(self.__goToDefinition)
        self.findButton = QAction(
            load_icon('findusage.png'),
            'Find highlighted item occurences', self)
        self.findButton.triggered.connect(self.__findWhereUsed)
        self.copyPathButton = QAction(
            load_icon('copymenu.png'), 'Copy path to clipboard', self)
        self.copyPathButton.triggered.connect(self.copyToClipboard)

        self.toolbar = QToolBar(self)
        self.toolbar.setMovable(False)
        self.toolbar.setAllowedAreas(Qt.TopToolBarArea)
        self.toolbar.setIconSize(QSize(16, 16))
        self.toolbar.setContentsMargins(0, 0, 0, 0)
        self.toolbar.addAction(self.definitionButton)
        self.toolbar.addAction(self.findButton)
        self.toolbar.addAction(self.copyPathButton)

        filterLabel = QLabel("  Filter ")
        filterLabel.setStyleSheet('background: transparent')
        self.toolbar.addWidget(filterLabel)
        self.filterEdit = QComboBox(self.toolbar)
        self.filterEdit.setSizePolicy(QSizePolicy.Expanding,
                                      QSizePolicy.Expanding)
        self.filterEdit.setEditable(True)
        self.filterEdit.lineEdit().setToolTip(
            "Space separated regular expressions")
        self.toolbar.addWidget(self.filterEdit)
        self.filterEdit.editTextChanged.connect(self.__filterChanged)
    #    self.filterEdit.itemAdded.connect(self.__filterItemAdded)
      #  self.filterEdit.enterClicked.connect(self.__enterInFilter)
        get_app().MainFrame.GetNotebook().currentChanged.connect(self._update_frame_contents)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.toolbar)
        layout.addWidget(self.tree)

        self.setLayout(layout)
        
    def copyToClipboard(self):
        """Copies the path to the file where the element is to the clipboard"""
        item = self.model().item(self.currentIndex())
        QApplication.clipboard().setText(item.getPath())
        
    def __goToDefinition(self):
        pass
        
    def __findWhereUsed(self):
        """ Find where used context menu handler """
        if self.__contextItem is not None:
            GlobalData().mainWindow.findWhereUsed(self.__contextItem.getPath(),
                                                  self.__contextItem.sourceObj)

    #由于此消息是异步消息,创建标签页是文本控件还没有创建,故需要延迟执行
    #以便等待文本控件创建成功
    @ui_utils.call_after_with_time(10)
    def _update_frame_contents(self, index):
        if index <0:
            self._clear_tree()
            return
        currentWidget = get_app().MainFrame.GetNotebook().widget(index)
        if currentWidget is None:
            return
        current_view = currentWidget.GetView()
        self.LoadOutLine(current_view)
        
    def __filterChanged(self, text):
        """Triggers when the filter text changed"""
        self.clViewer.setFilter(text)
        self.clViewer.updateCounter()
        
    def LoadOutLine(self,currView,lineNum=-1):
        foundRegisteredView = False
        if currView:
            #是否是允许在大纲显示的视图类型
            if self.IsValidViewType(currView):
                if not currView.GetDocument()._is_loading_doc:
                    currView.LoadOutLine(self,lineNum=lineNum)
                    self.SetCallbackView(currView)
                    foundRegisteredView = True
                else:
                    utils.get_logger().debug("%s is loading document,will not load outline",currView.GetDocument().GetFilename())
               
        #不支持显示大纲视图的文档类型,大纲内容显示为空
        if not foundRegisteredView:
            self.SetCallbackView(None)
            self._clear_tree()


    def SyncToPosition(self, view,lineNum):
        assert(view == self.GetCallbackView())
        if lineNum >= 0 and view.Module is not None:
            self.SelectAndFindNodeItem(lineNum)
            
    def SelectAndFindNodeItem(self,lineno):
        item = self.FindNodeItem(lineno,self.root)
        if item.parent() is not None:
            item.parent().setExpanded(True)
        self.clear_selections()
        self.tree.setCurrentItem(item)
        item.setSelected(True)
        
    def clear_selections(self):
        nodes=self.tree.selectedItems()
        for node in nodes:
            node.setSelected(False)
        
    def FindNodeItem(self,lineno,treeitem):
        childcount = treeitem.childCount()
        for i in range(childcount):
            childitem = treeitem.child(i)
            node = childitem.data(0, Qt.UserRole)
            if node.lineno == lineno:
                return childitem
            if i < childcount-1:
                nnode = treeitem.child(i+1).data(0, Qt.UserRole)
                if nnode.lineno == lineno:
                    return treeitem.child(i+1)
                elif node.lineno < lineno < nnode.lineno:
                    return self.FindNodeItem(lineno, childitem)
            else:
                return self.FindNodeItem(lineno, childitem)
        return treeitem

    # clears the tree by deleting all items
    def _on_select(self):
        editor = get_app().MainFrame.GetNotebook().get_current_editor()
        if editor:
            item = self.tree.currentItem()
            if item is None or not item.isSelected():
                return
            node = item.data(0, Qt.UserRole)
            lineno = node.lineno-1
            editor.selectedPosition = ((lineno,0),(lineno,len(editor.lines[lineno])))
        
    def visit_functiondef(self, node):
        if not _code_parser.is_class_range(node) and not _code_parser.is_module_range(node):
            return
        def_name = node.name
        line_no = node.lineno
        col = node.col_offset
        
        is_property_def = False
        is_class_method = False
        decorators = node.decorators
        if decorators is not None:
            for deco in decorators.nodes:
                line_no += 1
                if isinstance(deco, nodes.Name):
                    #property装饰符
                    if deco.name == "property":
                        is_property_def = True
                        break
                    #classmthod和staticmethod装饰符
                    elif deco.name == CLASS_METHOD_NAME or deco.name == STATIC_METHOD_NAME:
                        is_class_method = True
                        break
        is_method = False
        default_arg_num = len(node.args.defaults)
        arg_num = len(node.args.args)
        args = []
        for i,arg in enumerate(node.args.args):
            is_default = False
            #the last serveral argments are default arg if default argment number is not 0
            #最后面几个是默认参数,如果默认参数不为空的话
            default_value = None
            if i >= arg_num - default_arg_num:
                is_default = True
                default_value = node.args.defaults[i - (arg_num - default_arg_num)].as_string()
            if arg.name == 'self' and isinstance(node.parent, nodes.ClassDef):
                is_method = True
            kwargs = {'is_default':is_default}
            if default_value is not None:
                kwargs.update({'value':default_value})
                    
        #可变列表参数,以*开头
        if node.args.vararg is not None:
            name = node.args.vararg
        #可变字典参数,以**开头
        if node.args.kwarg is not None:
            name = node.args.kwarg
        #is_class_property必须是函数用property装饰并且为类方法时才为True
        if is_property_def and is_method:
            self.tree.add_assign_node(def_name, node, self.node_childs[node.parent])
        else:
            if _code_parser.is_class_range(node):
                self.tree.add_func_node(def_name, node, self.node_childs[node.parent])
            elif _code_parser.is_module_range(node):
                self.tree.add_func_node(def_name, node, self.node_childs[node.root()])
        if isinstance(node.parent, nodes.ClassDef) and node.name == CLASS_INIT_METHOD:
            for child in node.body:
                _code_parser.visit_child(child)
                
    def visit_asyncfunctiondef(self, node):
        self.tree.add_func_node(node.name, node, self.node_childs[node.root()])
                    
    def visit_classdef(self,node):
        if not _code_parser.is_module_range(node):
            return
        class_name = node.name
        item = self.tree.add_class_item(class_name, node, self.node_childs[node.root()])
        self.update_tree_class(node, item)
                    
    def visit_assign(self, node):
        targets = node.targets
        line_no = node.lineno
        col = node.col_offset
        target = targets[0]
        #连等表达式
        if isinstance(target, nodes.Tuple):
            elts = target.elts
            for i,elt in enumerate(elts):
                if isinstance(elt, nodes.AssignName):
                    name = elt.name
                    if isinstance(node.value, nodes.Tuple):
                        if _code_parser.is_module_range(node):
                            self.tree.add_assign_node(name, elt, self.root)
                        elif _code_parser.is_class_range(node):
                            self.tree.add_assign_node(name, elt, self.node_childs[node.parent])
                            
        elif isinstance(target, nodes.AssignName):
            name = target.name
            if _code_parser.is_module_range(node):
                self.tree.add_assign_node(name, node, self.root)
            elif _code_parser.is_class_range(node) and node.parent in self.node_childs:
                self.tree.add_assign_node(name, node, self.node_childs[node.parent])
                
        elif isinstance(target, nodes.AssignAttr):
            if not (isinstance(node.parent, nodes.FunctionDef) and node.parent.name == CLASS_INIT_METHOD):
                return
            #如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
            if isinstance(target.expr, nodes.Name) and target.expr.name == "self" \
                    and isinstance(node.parent.parent,nodes.ClassDef):
                name = target.attrname
                self.tree.add_assign_node(name, node, self.node_childs[node.parent.parent])
        
    def visit_annassign(self, node):
        line_no = node.lineno
        col = node.col_offset
        target = node.target
        if isinstance(target, nodes.AssignName):
            name = target.name
            if _code_parser.is_module_range(node):
                self.tree.add_assign_node(name, node, self.root)
            elif _code_parser.is_class_range(node) and node.parent in self.node_childs:
                self.tree.add_assign_node(name, node, self.node_childs[node.parent])
        elif isinstance(target, nodes.AssignAttr):
            if not (isinstance(node.parent, nodes.FunctionDef) and node.parent.name == CLASS_INIT_METHOD):
                return
            #如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
            if isinstance(target.expr, nodes.Name) and target.expr.name == "self" \
                    and isinstance(node.parent.parent,nodes.ClassDef):
                name = target.attrname
                self.tree.add_assign_node(name, node, self.node_childs[node.parent.parent])

    def visit_import(self, node):
        if not _code_parser.is_module_range(node):
            return
        for name, asname in node.names:
            modname = name
            if asname is not None:
                name = asname
            self.tree.add_import_node(name, node, self.root)
        
    def visit_importfrom(self, node):
        if not _code_parser.is_module_range(node):
            return
        mod_name = node.modname
        #处理相对导入的情况
        #有相对导入
        if node.level is not None:
            #相对导入不含包或模块名称
            if _code_parser.is_none_empty(mod_name):
                mod_name = "." * node.level
            #相对导入含包或模块名称
            else:
                mod_name =  "." * node.level + mod_name
        item = self.tree.add_fromimport_node(mod_name, node, self.root)
        for name, asname in node.names:
            if asname is not None:
                name = asname
            self.tree.add_import_node(name, node, item)
        
    def _clear_tree(self):
        super()._clear_tree()
        self.node_childs.clear()
        
    def update_tree_module(self, module):
        self.node_childs[module] = self.root
        
    def update_tree_class(self, classnode, item):
        self.node_childs[classnode] = item
        
    def show_syntax_error(self, ex):
        self._clear_tree()
        self.tree.show_syntax_error(ex,self.root)
        
    def visit_if(self, node):
        if node_utils.is_main_statement(node):
            self.tree.add_mainfunction_item(node, self.root)
            
        for orelse in node.orelse:
            if isinstance(orelse, nodes.If):
                for child in orelse.body:
                    _code_parser.visit_child(child)
            else:
                _code_parser.visit_child(orelse)
 
def OutlineSort(outline_sort_id):
    sort_order = ui_base.OutlineView.SORT_BY_NONE
    if outline_sort_id == constants.ID_SORT_BY_LINE:
        sort_order = ui_base.OutlineView.SORT_BY_LINE
    elif outline_sort_id == constants.ID_SORT_BY_TYPE:
        sort_order = ui_base.OutlineView.SORT_BY_TYPE
    elif outline_sort_id == constants.ID_SORT_BY_NAME:
        sort_order = ui_base.OutlineView.SORT_BY_NAME
    GetApp().MainFrame.GetView(consts.OUTLINE_VIEW_NAME).Sort(sort_order)
    
##class OutlineOptionPanel(ui_utils.CommonOptionPanel):
##    """
##    """
##    def __init__(self, parent):
##        ui_utils.CommonOptionPanel.__init__(self, parent)
##        self._showLineNumberCheckVar = tk.IntVar(value=utils.profile_get_int("OutlineShowLineNumber", True))
##        showLineNumberCheckBox = ttk.Checkbutton(self.panel,text=_("Show Line Number"),variable=self._showLineNumberCheckVar)
##        showLineNumberCheckBox.pack(fill=tk.X)
##
##        self._showParameterCheckVar = tk.IntVar(value=utils.profile_get_int("OutlineShowParameter", False))
##        showParameterCheckBox = ttk.Checkbutton(self.panel,text=_("Show parameter of function"),variable=self._showParameterCheckVar)
##        showParameterCheckBox.pack(fill=tk.X)
##        
##        self._showClassBaseCheckVar = tk.IntVar(value=utils.profile_get_int("OutlineShowBaseClass", False))
##        showClassBaseCheckBox = ttk.Checkbutton(self.panel, text=_("Show base classes of class"),variable=self._showClassBaseCheckVar)
##        showClassBaseCheckBox.pack(fill=tk.X)
##
##    def OnOK(self, optionsDialog):
##  
##        utils.profile_set("OutlineShowLineNumber", self._showLineNumberCheckVar.get())
##        utils.profile_set("OutlineShowParameter", self._showParameterCheckVar.get())
##        utils.profile_set("OutlineShowBaseClass", self._showClassBaseCheckVar.get())
##        
##        display_item_flag = PythonOutlineView.DISPLAY_ITEM_NAME
##        if self._showLineNumberCheckVar.get():
##            display_item_flag |= PythonOutlineView.DISPLAY_ITEM_LINE
##            
##        if self._showParameterCheckVar.get():
##            display_item_flag |= PythonOutlineView.DISPLAY_ITEM_FUNCTION_PARAMETER
##            
##        if self._showClassBaseCheckVar.get():
##            display_item_flag |= PythonOutlineView.DISPLAY_ITEM_CLASS_BASE
##        
##        outline_view = GetApp().MainFrame.GetView(consts.OUTLINE_VIEW_NAME)
##        if display_item_flag != outline_view._display_item_flag:
##            outline_view._display_item_flag = display_item_flag
##            active_text_view = GetApp().GetDocumentManager().GetCurrentView()
##            if active_text_view != None and hasattr(active_text_view,"LoadOutLine"):
##                active_text_view.LoadOutLine(outline_view,True)
##        return True
##        
    
class PythonOutlineViewLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)
    def Load(self):
        outlineview_info = get_app().MainFrame.AddView(
            constants.OUTLINE_VIEW_NAME,
            PythonOutlineView,
            _("Outline"), 
            sidebar.SideBar.East,
            image_file="python/outline/outline.ico",
            active=False
        )
        outline_view = outlineview_info['instance']
        _code_parser.add_module_visitor(outline_view)
##        view_menu = GetApp().Menubar.GetMenu(_("&View"))
##        outline_menu = tkmenu.PopupMenu()
##        self.outline_sort_var = tk.IntVar(value=utils.profile_get_int("OutlineSort", ui_base.OutlineView.SORT_BY_NONE))
##        view_menu.InsertMenuAfter(constants.ID_ZOOM,constants.ID_OUTLINE_SORT,_("Outline Sort"),outline_menu)
##
##        #设置Python文本视图在大纲中显示语法树
        outline_view.AddViewTypeForBackgroundHandler(PythonView)
##        
##        GetApp().AddMenuCommand(constants.ID_SORT_BY_NONE,outline_menu,_("Unsorted"),lambda:OutlineSort(constants.ID_SORT_BY_NONE),\
##                                default_command=True,default_tester=True,kind=consts.RADIO_MENU_ITEM_KIND,variable=self.outline_sort_var,value=ui_base.OutlineView.SORT_BY_NONE)
##        GetApp().AddMenuCommand(constants.ID_SORT_BY_LINE,outline_menu,_("Sort By Line"),lambda:OutlineSort(constants.ID_SORT_BY_LINE),\
##                                default_command=True,default_tester=True,kind=consts.RADIO_MENU_ITEM_KIND,variable=self.outline_sort_var,value=ui_base.OutlineView.SORT_BY_LINE)
##        GetApp().AddMenuCommand(constants.ID_SORT_BY_TYPE,outline_menu,_("Sort By Type"),lambda:OutlineSort(constants.ID_SORT_BY_TYPE),\
##                                default_command=True,default_tester=True,kind=consts.RADIO_MENU_ITEM_KIND,variable=self.outline_sort_var,value=ui_base.OutlineView.SORT_BY_TYPE)
##        GetApp().AddMenuCommand(constants.ID_SORT_BY_NAME,outline_menu,_("Sort By Name(A-Z)"),lambda:OutlineSort(constants.ID_SORT_BY_NAME),\
##                                default_command=True,default_tester=True,kind=consts.RADIO_MENU_ITEM_KIND,variable=self.outline_sort_var,value=ui_base.OutlineView.SORT_BY_NAME)
##        #首选项显示面板                
##        preference.PreferenceManager().AddOptionsPanelClass("Misc","Outline",OutlineOptionPanel)
