from ..lib.docmanager import DocManager, DEFAULT_DOCMAN_FLAGS
from ..constants import DEFAULT_MRU_PROJECT_NUM
from ..globalkeys import RECENTPROJECT_LENGTH_KEY
from ..util import utils
from .project import ext
from .project.history import ProjectHistory

class PydocManager(DocManager):

    def __init__(self, flags=DEFAULT_DOCMAN_FLAGS, initialize=True):
        super().__init__(flags, initialize)
        #存储历史项目对象
        self._projectHistory = None

    def OnCreateFileHistory(self):
        """
        A hook to allow a derived class to create a different type of file
        history. Called from Initialize.
        """
        super().OnCreateFileHistory()
        #获取配置最大历史项目个数
        max_project_files = utils.profile_get_int(RECENTPROJECT_LENGTH_KEY, DEFAULT_MRU_PROJECT_NUM)
        self._projectHistory = ProjectHistory(maxFiles=max_project_files)
