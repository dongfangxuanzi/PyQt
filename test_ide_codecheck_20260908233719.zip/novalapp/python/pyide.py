# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        pyide.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-10
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
from .. import _, newid
from ..ide import IDEApplication
from .docmanager import PydocManager
from .interpreter.interpretermanager import INTERPRETER_MANAGER
from ..plugin import plugin_config
from ..util import ui_utils, utils, fileutils, environments, terminal
from .. import menuitems
from ..prog_lang import LANGUAGE_PYTHON
import os
##import sys
from ..syntax import lang
from ..menubar import find_menu
from ..lib.pyqt import QMessageBox
from .. import constants
import subprocess
##import noval.ui_common as ui_common
##import noval.misc as misc
##import noval.python.debugger.debugger as pythondebugger
##import noval.running as running


class PyIDEApplication(IDEApplication):

    def __init__(self):
        super().__init__()

    def OnInit(self):
        if not super().OnInit():
            return False

        #这里必须用相对导入,因为搜索路径已经添加了,如果使用长路径导入会导致IntellisenceManager的实例信息和其它地方的不一样
        from .parser.intellisence import IntellisenceManager
##        from noval.project.document import ProjectDocument
##        
##        self._debugger_class = pythondebugger.PythonDebugger
##        
##        #pyc和pyo二进制文件类型禁止添加到项目中
##        ProjectDocument.BIN_FILE_EXTS = ProjectDocument.BIN_FILE_EXTS + ['pyc','pyo']
##        self.interpreter_combo = self.MainFrame.GetToolBar().AddCombox()
##        self.interpreter_combo.bind("<<ComboboxSelected>>",self.OnCombo)
##      
        help_menu = find_menu(_("&Help"), self.Menubar)
        if utils.is_windows():
            self.InsertCommand(
                menuitems.ID_FEEDBACK,
                menuitems.ID_OPEN_PYTHON_HELP,
                help_menu,
                _("&Python help document"),
                handler=self.OpenPythonHelpDocument,
                image=self.GetImage("pydoc.png")
            )
            
        #self.AddCommand(constants.ID_GOTO_DEFINITION,_("&Edit"),_("Goto Definition"),self.GotoDefinition,default_tester=True,default_command=True)
        self.InsertCommand(
            menuitems.ID_FEEDBACK,
            menuitems.ID_GOTO_PYTHON_WEB,
            help_menu,
            _("&Python website"),
            handler=self.GotoPythonWebsite,
        )
        tools_menu = find_menu(_("&Tools"), self.Menubar)
        #解释器菜单插入在插件管理菜单之前
        self.InsertCommand(
            menuitems.ID_PLUGIN,
            menuitems.ID_OPEN_INTERPRETER,
            tools_menu,
            _("&Interpreter"),
            self.OpenInterpreter,
            image=self.GetImage("python/interpreter.png"),
        )
        edit_menu = find_menu(_("&Edit"),self.Menubar)
        insert_menu = edit_menu.GetMenu(menuitems.ID_INSERT)
        self.AddDefaultCommand(
            menuitems.ID_INSERT_DECLARE_ENCODING,
            insert_menu,
            _("Insert encoding declaration"),
            self.InsertEncodingDeclare
        )
        run_menu = find_menu(_("&Run"), self.Menubar)

        self.AddDefaultCommand(
            menuitems.ID_START_WITHOUT_DEBUG,
            run_menu,
            _("&Start Without Debugging"),
            self.RunWithoutDebug
        )

        self.AddDefaultCommand(
            menuitems.ID_SET_EXCEPTION_BREAKPOINT,
            run_menu,
            _("&Exceptions..."),
            self.SetExceptionBreakPoint,
            add_separator=True
        )
        self.AddDefaultCommand(
            menuitems.ID_STEP_INTO,
            run_menu,_("&Step Into"),
            self.StepInto,
            image=self.GetImage('python/debugger/step_into.png')
        )
        self.AddDefaultCommand(
            menuitems.ID_STEP_NEXT,
            run_menu,
            _("&Step Over"),
            self.StepNext,
            add_separator=True,
            image=self.GetImage('python/debugger/step_next.png')
        )

        self.AddDefaultCommand(
            menuitems.ID_CHECK_SYNTAX,
            run_menu,
            _("&Check Syntax..."),
            self.CheckSyntax
        )
        self.AddDefaultCommand(
            menuitems.ID_SET_PARAMETER_ENVIRONMENT,
            run_menu,
            _("&Set Parameter And Environment"),
            self.SetParameterEnvironment,
            image=self.GetImage('python/debugger/runconfig.png')
        )
      #  self.AddCommand(menuitems.ID_RUN_LAST,_("&Run"),_("&Run Using Last Settings"),self.RunLast,default_tester=True,default_command=True)
       # self.AddCommand(menuitems.ID_DEBUG_LAST,_("&Run"),_("&Debug Using Last Settings"),self.DebugLast,default_tester=True,default_command=True,add_separator=True)    
        
        self.AddDefaultCommand(
            menuitems.ID_TOGGLE_BREAKPOINT,
            run_menu,
            _("&Toggle Breakpoint"),
            self.ToogleBreakPoint,
            image=self.GetImage('python/debugger/breakpoint.png')
        )
        self.AddCommand(
            menuitems.ID_CLEAR_ALL_BREAKPOINTS,
            run_menu,
            _("&Clear All Breakpoints"),
            self.ClearAllBreakPoints,
        ) 
        #关闭软件启动图片
        self.CloseSplash()
##        self.bind(constants.DOUBLECLICKPATH_EVT,self.request_focus_into,True)
##        
        self.LoadDefaultInterpreter()
        self.AddInterpreters()
##        #在加载解释器后发送安装必须插件的消息
##        self.event_generate("InstallRequiredPluginsMsg")
        self.intellisence_mananger = IntellisenceManager()
        self.intellisence_mananger.generate_default_intellisence_data()
        return True
        
    def request_focus_into(self, event):
        '''
           双击文件视图文件夹时同时在解释器shell中切换路径
        '''
        path = event.get('path')
        if not os.path.isdir(path) or not utils.profile_get_int("ExecuateCdDoubleClick", True):
            return
            
        self.MainFrame.ShowView(consts.PYTHON_INTERPRETER_VIEW_NAME,toogle_visibility_flag=True)
        shell = self.MainFrame.GetCommonView(consts.PYTHON_INTERPRETER_VIEW_NAME)
        proxy = shell.Runner.get_backend_proxy()
        if (
            proxy
            and proxy.uses_local_filesystem()
            and proxy.get_cwd() != path
            and shell.Runner.is_waiting_toplevel_command()
        ):
            shell.submit_magic_command(running.construct_cd_command(path))

    def GetInterpreterManager(self):
        return INTERPRETER_MANAGER
        
    def SetExceptionBreakPoint(self):
        self.MainFrame.GetView(consts.BREAKPOINTS_TAB_NAME).SetExceptionBreakPoint()
        
    def StepNext(self):
        self.GetDebugger().StepNext()
        
    def StepInto(self):
        self.GetDebugger().StepInto()
        
    def DebugLast(self):
        self.GetDebugger().DebugLast()
        
    def RunLast(self):
        self.GetDebugger().RunLast()

    def CheckSyntax(self):
        self.GetDebugger().CheckScript()
        
    def SetParameterEnvironment(self):
        self.GetDebugger().SetParameterAndEnvironment()
        
    def ToogleBreakPoint(self):
        current_view = self.GetDocumentManager().GetCurrentView()
        #只有python文件才能设置断点
        if current_view is None or not hasattr(current_view,"ToogleBreakpoint"):
            return
        current_view.GetCtrl().ToogleBreakpoint()
        
    def ClearAllBreakPoints(self):
        self.MainFrame.GetView(consts.BREAKPOINTS_TAB_NAME).ClearAllBreakPoints()
        
    @ui_utils.update_toolbar
    def LoadDefaultInterpreter(self):
        INTERPRETER_MANAGER.LoadDefaultInterpreter()
        
    def GotoDefinition(self):
        current_view = self.GetDocumentManager().GetCurrentView()
        #只有python文件才能执行转到定义功能
        if current_view is None or not hasattr(current_view,"GotoDefinition"):
            return
        current_view.GotoDefinition()
        
    def GetDocmanagerClass(self):
        return PydocManager

    def LoadDefaultPlugins(self):
        '''
            加载python默认插件
        '''
##        import noval.preference as preference
##        import noval.python.interpreter.gerneralconfiguration as interpretergerneralconfiguration
##        import noval.python.interpreter.interpreterconfigruation as interpreterconfigruation
##        import noval.keybinds as keybinds
        IDEApplication.LoadDefaultPlugins(self)
        
        #添加Python语言仅有的首选项面板,在other面板之前
##        preference.PreferenceManager().AddOptionsPanelClass(preference.INTERPRETER_OPTION_NAME,preference.GENERAL_ITEM_NAME,interpretergerneralconfiguration.InterpreterGeneralConfigurationPanel)
##        preference.PreferenceManager().AddOptionsPanelClass(preference.INTERPRETER_OPTION_NAME,preference.INTERPRETER_CONFIGURATIONS_ITEM_NAME,interpreterconfigruation.InterpreterConfigurationPanel)
##        #不能用斜杆分割,斜杆作为数据默认分割符,显示时会替换|为/
##        preference.PreferenceManager().AddOptionsPanelClass("Debug|Run","Debug",pythondebugger.DebuggerOptionsPanel)
##        preference.PreferenceManager().AddOptionsPanelClass("Debug|Run","Output",pythondebugger.OutputOptionsPanel)
##        preference.PreferenceManager().AddOptionsPanelClass("Debug|Run","Run",pythondebugger.RunOptionsPanel)
##        
##        preference.PreferenceManager().AddOptionsPanelClass("Misc","KeyBindings",keybinds.KeybindOptionPanel)
##        consts.DEFAULT_PLUGINS += ("noval.python.project.browser.ProjectViewLoader",)
##        consts.DEFAULT_PLUGINS += ('noval.python.plugins.pyshell.pyshell.PyshellViewLoader',)
##        #window面板在outline面板之前,故需在outline之前初始化
##        consts.DEFAULT_PLUGINS += ('noval.plugins.windowservice.WindowServiceLoader',)
        plugin_config.DEFAULT_PLUGINS += ('novalapp.python.plugins.outline.PythonOutlineViewLoader',)
##        consts.DEFAULT_PLUGINS += ('noval.python.project.viewer.DefaultProjectTemplateLoader',)
##        consts.DEFAULT_PLUGINS += ('noval.python.plugins.unittest.UnittestLoader',)
##        consts.DEFAULT_PLUGINS += ('noval.python.debugger.watchs.WatchsViewLoader',)
##        consts.DEFAULT_PLUGINS += ('noval.python.debugger.breakpoints.BreakpointsViewLoader',)
##        consts.DEFAULT_PLUGINS += ('noval.python.debugger.stacksframe.StackframeViewLoader',)
##        consts.DEFAULT_PLUGINS += ('noval.python.debugger.inspectconsole.InspectConsoleViewLoader',)
##        
    def CreateLexerTemplates(self):
        from ..syntax.synglob import LexerFactory
        super().CreateLexerTemplates()
        LexerFactory.CreateLexerTemplates(LANGUAGE_PYTHON)
        
    def GetCurrentInterpreter(self):
        return INTERPRETER_MANAGER.GetCurrentInterpreter()
                            
    def Quit(self):
        #self.intellisence_mananger.Stop()
        super().Quit()
    
    @property
    def OpenProjectPath(self):
        return self._open_project_path
        
    def GetIDESplashBitmap(self):
        return os.path.join(utils.get_app_image_location(),"python/welcome.png")
        
    def AddInterpreters(self):
        names = INTERPRETER_MANAGER.GetInterpreterNames()
        self.debuger_combo.insertItems(0,names)
        self.SetCurrentInterpreter()
        
    def SetCurrentInterpreter(self):
        current_interpreter = INTERPRETER_MANAGER.GetCurrentInterpreter()
        if current_interpreter is None:
            return
        for i in range(self.debuger_combo.count()):
            data = INTERPRETER_MANAGER.interpreters[i]
            if data == current_interpreter:
                self.debuger_combo.setCurrentIndex(i)
                break

    @ui_utils.update_toolbar
    def selectdebugger(self,i):
        prompt = False
        if i == self.debuger_combo.count() - 1:
            if pythondebugger.BaseDebuggerUI.DebuggerRunning():
                prompt = True
            else:
                ui_common.ShowInterpreterConfigurationPage()
        else:
            interpreter = INTERPRETER_MANAGER.interpreters[i]
            #if interpreter != self.GetCurrentInterpreter() and pythondebugger.BaseDebuggerUI.DebuggerRunning():
             #   prompt = True
            #else:
            self.SelectInterpreter(interpreter)
        if prompt:
            messagebox.showinfo(self.GetAppName(),_("Please stop the debugger first!"),parent=self.GetTopWindow())
            self.SetCurrentInterpreter()
        
    def OpenPythonHelpDocument(self):
        interpreter = self.GetCurrentInterpreter()
        if interpreter is None:
            return
        if interpreter.HelpPath == "":
            return
        fileutils.startfile(interpreter.HelpPath)
        
    def GotoPythonWebsite(self):
        fileutils.startfile("http://www.python.org")

    def SelectInterpreter(self,interpreter):
        if interpreter != INTERPRETER_MANAGER.GetCurrentInterpreter():
            INTERPRETER_MANAGER.SetCurrentInterpreter(interpreter)
            #if self.intellisence_mananger.IsRunning:
             #   return
            #self.intellisence_mananger.load_intellisence_data(interpreter)
        #切换解释器时是否更新解释器的后端进程
       # if utils.profile_get_int('UPDATE_SHELL_SWITCH_INTERPRETER',True):
        #    self.event_generate("UpdateShell")
            
    def GetDefaultLangId(self):
        if not hasattr(lang, "ID_LANG_PYTHON"):
            return super().GetDefaultLangId()
        return lang.ID_LANG_PYTHON
        
    def InsertCodingDeclare(self):
        pass
        
    def OpenInterpreter(self):
        interpreter = self.GetCurrentInterpreter()
        if interpreter is None:
            messagebox.showinfo(self.GetAppName(),_("No interpreter..."))
            return
        try:
            if utils.is_windows():
                fileutils.startfile(interpreter.path)
            else:
                cmd_list = ['gnome-terminal','-x','bash','-c',interpreter.path]
                subprocess.Popen(cmd_list,shell = False)
        except Exception as e:
            QMessageBox.critical(self.GetTopWindow(),_("Open Error"),_("%s") % str(e))

    def OpenTerminator(self,filename=None):
        if filename:
            if os.path.isdir(filename):
                cwd = filename
            else:
                cwd = os.path.dirname(filename)
        else:
            cwd = os.getcwd()
        #打开终端时不嵌入解释器环境
        if not utils.profile_get_int("EmbedInterpreterInterminator", True):
            IDEApplication.OpenTerminator(self,filename)
            return 
            
        interpreter = self.GetCurrentInterpreter()
        if interpreter is None:
            IDEApplication.OpenTerminator(self,filename)
            return
        else:
            target_executable = interpreter.path
        
        exe_dirs = interpreter.GetExedirs()
        env_overrides = {}
        env_overrides["PATH"] = environments.get_augmented_system_path(exe_dirs) 
        #设置安装路径的环境变量,运行程序时需要在路径中移除此路径
        env_overrides['MAIN_MODULE_APTH'] = utils.get_app_path()
        explainer = os.path.join(os.path.dirname(__file__), "explain.py")
        cmd = [target_executable, explainer]
        #检测是否虚拟解释器
        activate = os.path.join(os.path.dirname(target_executable), 
                                "activate.bat" if utils.is_windows()
                                else "activate")
        
        if os.path.isfile(activate):
            del env_overrides["PATH"]
            if utils.is_windows():
                cmd = [activate, "&"] + cmd
            else:
                cmd = ["source", activate, ";"] + cmd 
        return terminal.run_in_terminal(cmd, cwd, env_overrides, True)

    def RunWithoutDebug(self):
        self.GetDebugger().RunWithoutDebug()

    def InsertEncodingDeclare(self,text_view = None):
        if text_view is None:
            text_view = self.GetDocumentManager().GetCurrentView()
        
        lines = text_view.GetCtrl().GetTopLines(consts.ENCODING_DECLARE_LINE_NUM)
        coding_name,line_num = strutils.get_python_coding_declare(lines)
        if  coding_name is not None:
            ret = messagebox.askyesno(_("Declare Encoding"),_("The Python Document have already declare coding,Do you want to overwrite it?"),parent=text_view.GetFrame())
            if ret == True:
                text_view.SetSelection(text_view.GetCtrl().PositionFromLine(line_num),text_view.GetCtrl().PositionFromLine(line_num+1))
                text_view.GetCtrl().DeleteBack()
            else:
                return True
                
        dlg = ui_utils.EncodingDeclareDialog(text_view.GetFrame())
        if dlg.ShowModal() == constants.ID_OK:
            text_view.GetCtrl().GotoPos(0,0)
            text_view.AddText(dlg.name_var.get() + "\n")
            return True
        return False
        
    def UpdateUI(self,command_id):
        if command_id == menuitems.ID_CLEAR_ALL_BREAKPOINTS:
            return 0 != len(self.MainFrame.GetView(consts.BREAKPOINTS_TAB_NAME).GetMasterBreakpointDict())
##        current_project = self.MainFrame.GetProjectView(False).GetCurrentProject()
##        current_interpreter = self.GetCurrentInterpreter()
##        builtin_item_ids = [constants.ID_RUN,constants.ID_SET_EXCEPTION_BREAKPOINT,constants.ID_STEP_INTO,constants.ID_STEP_NEXT,constants.ID_RUN_LAST]
##        all_item_ids = builtin_item_ids + [constants.ID_SET_PARAMETER_ENVIRONMENT,constants.ID_DEBUG_LAST,constants.ID_START_WITHOUT_DEBUG]
##        #使用内建解释器时,禁止运行按钮和菜单
##        if command_id in builtin_item_ids:
##            if current_interpreter is None or current_interpreter.IsBuiltIn:
##                return False
##        elif command_id in all_item_ids:
##            if current_interpreter is None:
##                return False
##        if current_project is not None:
##            if command_id in all_item_ids:
##                return True
        return super().UpdateUI(command_id)
        
    def GotoView(self,file_path,*,lineNum=-1,colno=-1,trace_track=True,load_outline=True):
        foundView = super().GotoView(file_path, lineNum=lineNum, colno=colno, trace_track=trace_track, load_outline=load_outline)
        #如果视图是允许在大纲显示的视图类型,则跳转到指定行并选中对应的语法行
        if load_outline and self.MainFrame.GetView(constants.OUTLINE_VIEW_NAME).IsValidViewType(foundView):
            self.MainFrame.GetView(constants.OUTLINE_VIEW_NAME).LoadOutLine(foundView, lineNum=lineNum)
    