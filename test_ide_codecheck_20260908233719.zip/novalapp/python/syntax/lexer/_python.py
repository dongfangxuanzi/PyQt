# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        _python.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-17
# Copyright:   (c) wukan 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

#-----------------------------------------------------------------------------#
from novalapp import _
import keyword
from novalapp.syntax import syndata,lang
import novalapp.util.appdirs as appdirs
import os
from novalapp.python import editor as pythoneditor
from novalapp.qtimage import python_icon,load_icon
from novalapp.python import prog_lang_ext
# Highlighted builtins
import builtins
#-----------------------------------------------------------------------------#

#---- Keyword Specifications ----#

builtinlist = [str(name) for name in dir(builtins)
                                        if not name.startswith('_') and name not in keyword.kwlist]



class SyntaxLexer(syndata.BaseLexer):
    """SyntaxData object for Python"""       
    def __init__(self):
        lang_id = lang.RegisterNewLangId("ID_LANG_PYTHON")
        syndata.BaseLexer.__init__(self,lang_id)

    def GetKeywords(self):
        """Returns Specified Keywords List """
        return [PY_KW, PY_BIN]
        
    def GetDescription(self):
        return _('Python Script')
        
    def GetExt(self):
        return " ".join(prog_lang_ext.PYTHON_CODE_FILE_EXT)

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return [u'#']

    def GetShowName(self):
        return "Python"
        
    def GetDefaultExt(self):
        return prog_lang_ext.PYTHON_CODE_FILE_EXT[0]
        
    def GetDocTypeName(self):
        return "Python Document"
        
    def GetViewTypeName(self):
        return _("Python Editor")
        
    def GetDocTypeClass(self):
        return pythoneditor.PythonDocument
        
    def GetViewTypeClass(self):
        return pythoneditor.PythonView
        
    def GetDocIcon(self):
        return python_icon()
        
    def GetFileViewIcon(self):
        return load_icon('files/python-file.gif')
        
    def GetSampleCode(self):
        sample_file_path = os.path.join(appdirs.get_app_data_location(),"sample","python.sample")
        return self.GetSampleCodeFromFile(sample_file_path)
        
    def GetCommentTemplate(self):
        return '''\'\'\'
Name:        {File}
Purpose:

Author:      {Author}

Created:     {Date}
Copyright:   (c) {Author} {Year}
Licence:     {Licence}
\'\'\'
'''
    def GetKeywords(self):
        return keyword.kwlist + builtinlist
        
    def syntax_xmlname(self):
        return 'python.xml'
