import os
import glob
import logging
from ...util import utils, fileutils, strutils
from .base_analyzer import BaseAnalyzer
import sys
from ..parser import node_utils, nodetypes
import types
import datetime

logger = logging.getLogger('ide.builtin.analyzer')

class BuiltinAnalyzer(BaseAnalyzer):
    def __init__(self, dbver, data_outpath,interpreter):
        super().__init__(dbver, data_outpath,interpreter)
        #解释器自带内建模块数据存放位置
        self.data_out_path = os.path.join(data_outpath, "builtins")
        self._need_renew_database = self.need_renew_database(self.dbver)
        
    def get_builtin_doc(self, builtin_intance):
        doc = builtin_intance.__doc__
        if isinstance(doc, str):
            return doc
        return None

    def make_builtin_types(self, builtin_type,recursive=True):
        childs = []
        for name in dir(builtin_type):
            if not hasattr(builtin_type, name):
                continue
            builtin_intance = getattr(builtin_type, name)
            builtin_attr_type = type(builtin_intance)
            if isinstance(builtin_intance, type):
                if not recursive:
                    continue
                builtin_childs = self.make_builtin_types(builtin_intance,False)
                data = self.make_node_dict(
                    name,
                    nodetypes.CLASS_DEF,
                    childs=builtin_childs,
                    doc=self.get_builtin_doc(builtin_intance)
                )
                childs.append(data)
            elif builtin_attr_type == types.BuiltinFunctionType or builtin_attr_type == types.BuiltinMethodType \
                        or str(builtin_attr_type).find("method_descriptor") != -1:
                data = self.make_node_dict(name, nodetypes.FUNCTION_DEF,doc=self.get_builtin_doc(builtin_intance))
                childs.append(data)
            else:
                kw = node_utils.get_const_value(builtin_intance)
                data = self.make_node_dict(name, nodetypes.OBJECT_PROPERTY,**kw)
                childs.append(data)
        return childs

    @utils.compute_time
    def run(self):
        fileutils.makedirs(self.data_out_path)
        if not self._need_renew_database:
            logger.info('builtin database is the lates version %s,not analyze again',self.dbver)
            return
        for modname in self.interpreter.Builtins:
            try:
                mod = __import__(modname)
            except ModuleNotFoundError as e:
                logger.warning(str(e))
                continue
            childs = self.make_builtin_types(mod)
            self.make_builtin_members_file(modname, childs, doc=mod.__doc__)
        self.save_database_version(self.dbver)

    def make_builtin_members_file(self, modname, childs, *,doc=None):
        members_file_name, memberlist_file_name = super().make_members_file(modname,childs,is_builtin=True,doc=doc)
        logger.info("generate mod %s members file %s,%s success" ,modname, members_file_name,memberlist_file_name)
