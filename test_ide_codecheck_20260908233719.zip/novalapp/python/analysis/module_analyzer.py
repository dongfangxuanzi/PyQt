# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        analyzer.py
# Purpose:   解析Python语法
#
# Author:      wukan
#
# Created:     2019-02-20
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
import sys
import os
thisfile = os.path.abspath(__file__)
root = thisfile.rsplit(os.sep, 2)[0]
# 添加第三方解析包astroid的搜索路径,以便能找到包
sys.path.append(os.path.join(root, "thirdparty"))
import astroid
from ..parser import codeparser
import threading
#import noval.util.utils as utils

_code_parser = codeparser.CodeParser()

class PythonModuleAnalyzer:
    """description of class"""
    
    def __init__(self,mod_view):
        self._mod_view = mod_view
        self._lock = threading.Lock()
        self._module = None
        self.ex = None

    def parse_module(self,filename):
        document = self._mod_view.GetDocument()
        try:
            self._module = _code_parser.parse_content(
                document.GetFilename(),
                self._mod_view.GetValue(),
                document.file_encoding
            )
        except astroid.AstroidSyntaxError as ex:
            self.ex = ex
        
    def AnalyzeModuleSynchronizeTree(self,view,outlineView,force,lineNum):
        self.LoadMouduleSynchronizeTree(view,outlineView,force,lineNum)

    def LoadMouduleSynchronizeTree(self,callback_view,outlineView,force,lineNum):
        with self._lock:
            document = self._mod_view.GetDocument()
            filename = document.GetFilename()
            if not force and callback_view == self._mod_view:
                return False
            if force:
                self.parse_module(filename)
            if self._module is not None:
                #should freeze control to prevent update and treectrl flick
                self.load_module_ast(outlineView, lineNum)
                self.View.update_bar()
            #如果语法解析错误,则清除大纲视图内容
            else:
                outlineView.show_syntax_error(self.ex)
            return True
            
    def load_module_ast(self,outlineView,lineNum=-1):
        outlineView._clear_tree()
        outlineView.update_tree_module(self._module)
        _code_parser.walker.walk(self._module)
#        self.Sort(self._sortOrder)
        if lineNum >= 0:
            outlineView.SyncToPosition(self._mod_view,lineNum)
        
    @property
    def SyntaxError(self):
        return self._syntax_error_msg
        
    @property
    def View(self):
        return self._mod_view
        
    @property
    def Module(self):
        return self._module
