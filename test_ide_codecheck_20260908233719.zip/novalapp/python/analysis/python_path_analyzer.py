import os
import sys
import glob
import importlib
import multiprocessing
import logging
from ...util import utils, fileutils, strutils
from .builtin_analyzer import BuiltinAnalyzer
from ..parser import fileparser
from .. import prog_lang_ext
from ..parser.define import PACKAGE_INIT_FILE
from ..parser.exceptions import ReferenceModuleNotAnalyzedError
from ..parser import nodetypes
from ..parser.define import MEMBERS_FILE_EXTENSION,MEMBERLIST_FILE_EXTENSION
from .moduleloader import ModuleLoader
from ..parser.builtinmodule import BuiltinModule

logger = logging.getLogger('ide.pythonpath.analyzer')

class PythonPathAnalyzer(BuiltinAnalyzer):
    """解析系统和用户搜索路径的所有python代码文件并生成语法数据文件"""
    SPECIAL_MODULES = ['os.path']
    #多进程分析语法数据时最大进程数量
    MAX_POOL_COUNT = 5
    def __init__(self, dbver, data_outpath, interpreter,pathlist, builtin_analyzer):
        super().__init__(dbver, data_outpath, interpreter)
        #解释器和用户模块数据存放位置
        self.data_out_path = os.path.join(data_outpath, self.interpreter.MinorVersion)
        self.pathlist = pathlist
        self.builtin_analyzer = builtin_analyzer
        self._builtmodule = BuiltinModule()
        self._need_renew_database = self.need_renew_database(self.dbver)
        
    def load_builtin_module(self):
        data = self.builtin_analyzer.load_module(BuiltinModule.BUILTMODULE_NAME)
        self._builtmodule.load(data)
        
    @property
    def BuiltinModule(self):
        return self._builtmodule
        
    @utils.compute_time
    def run(self):
        fileutils.makedirs(self.data_out_path)
        self.load_builtin_module()
        pathlist = self.pathlist
        for i,path in enumerate(pathlist):
            pathlist[i] = os.path.normcase(os.path.abspath(path))
        updated = 0
        for pythonpath in pathlist:
            logger.info('analyze pythonpath %s intellisence data',pythonpath)
            updated += self.scan_python_path(pythonpath)
        self.end()
        logger.info('total update %d code analysis files',updated)
        
    @utils.compute_time
    def pool_run(self):
        fileutils.makedirs(self.data_out_path)
        pathlist = self.pathlist
        for i,path in enumerate(pathlist):
            pathlist[i] = os.path.normcase(os.path.abspath(path))
        pool = multiprocessing.Pool(processes=min(self.MAX_POOL_COUNT,len(pathlist)))
        future_list = []
        result = []
        for path in pathlist:
            logger.info('analyze pythonpath %s intellisence data',path)
            res = pool.apply_async(self.scan_python_path,(path,))
            result.append(res)
        pool.close()
        pool.join()
        updated = 0
        for res in result:
            updated += res.get()
        logger.info('total update %d code analysis files',updated)
        self.end()
        
    def end(self):
        #一些特殊模块的数据文件生成
        self.make_specialmodule_members_file()
        #最后的清理工作,删除一些不存在的代码数据库文件
        self.clean_database_files()
        if self._need_renew_database:
            self.save_database_version(self.dbver)
        self.save_update_time()
          
    @staticmethod  
    def is_test_dir(dir_path):
        dir_name = os.path.basename(dir_path)
        if dir_name.lower() == "test" or dir_name.lower() == "tests":
            return True
        else:
            return False
       
    @staticmethod     
    def is_package_dir(dirpath):
        if os.path.exists(os.path.join(dirpath,PACKAGE_INIT_FILE)):
            return True
        return False

    def scan_python_path(self, pythonpath):
        updated = 0
        searchpath = os.path.join(pythonpath,"*")
        for filepath in glob.glob(searchpath):
            if os.path.isfile(filepath):
                ext = strutils.get_file_extension(filepath)
                if ext in prog_lang_ext.PYTHON_CODE_FILE_EXT:
                    modname = self.get_relative_path(filepath)
                    if not self.need_renew_module(modname):
                        continue
                    logger.info('python file %s modname is %s',filepath,modname)
                    filename = os.path.basename(filepath)
                    if self.make_code_members_file(filename, filepath, modname):
                        updated += 1
                elif ext == prog_lang_ext.PYTHON_PYD_FILE_EXT:
                   if self.make_pyd_members_file(filepath):
                       updated += 1
                else:
                    logger.info("skip no python file %s",filepath)
            elif os.path.isdir(filepath):
                if self.is_test_dir(filepath):
                    logger.info("skip test dir %s",filepath)
                elif not self.is_package_dir(filepath):
                    logger.info("skip nonpackage dir %s",filepath)
                else:
                    updated += self.scan_python_path(filepath)
        return updated
                    
    def need_renew_module(self, modname):
        '''模块更新数据库文件机制,如果文件已存在不用更新'''
        if self._need_renew_database:
            return True
        return not self.is_membersfile_exist(modname)
                    
    def is_membersfile_exist(self, modname):
        membersfile = self.get_member_filenames(modname)[0]
        if os.path.exists(membersfile):
            logger.debug('modname %s database file %s already exist',modname,membersfile)
            return True
        return False
                    
    def get_relative_path(self, module_path):
        path = os.path.dirname(module_path)
        recent_path = ''
        while True:
            #when route to sys path or root path,such as / or c:\\,skip the circle
            if fileutils.PathsContainPath(self.pathlist,path) or os.path.dirname(path) == path:
                recent_path = path
                break
            path = os.path.dirname(path)
        path_name = module_path.replace(recent_path + os.sep,'').split('.')[0]
        if utils.is_windows():
            path_name = path_name.replace(os.sep,'/')
        parts = path_name.split('/')
        if parts[-1] == "__init__":
            relative_module_name = '.'.join(parts[0:-1])
        else:
            relative_module_name = '.'.join(parts)
        return relative_module_name
        
    def get_mod_file_path(self, modname):
        relative_mod_path = modname.replace(".", os.sep) + "." + prog_lang_ext.PYTHON_CODE_FILE_EXT[0]
        package_mod_path = modname.replace(".", os.sep) + os.sep + PACKAGE_INIT_FILE
        for path in self.pathlist:
            modpath = os.path.join(path, relative_mod_path)
            package_path = os.path.join(path,package_mod_path)
            if os.path.exists(modpath):
                return modpath
            elif os.path.exists(package_path):
                return package_path
        return None
        
    def get_package_modules(self, filepath):
        module_dir = os.path.dirname(filepath)
        child_modules = []
        for filename in os.listdir(module_dir):
            child_file_path = os.path.join(module_dir,filename)
            if os.path.isfile(child_file_path):
                ext = strutils.get_file_extension(child_file_path)
                if ext not in prog_lang_ext.PYTHON_CODE_FILE_EXT + (prog_lang_ext.PYTHON_PYD_FILE_EXT, ):
                    continue
                elif filename == PACKAGE_INIT_FILE:
                    continue
            elif os.path.isdir(child_file_path):
                if not self.is_package_dir(child_file_path):
                    continue
            if os.path.isfile(child_file_path):
                child_mod_name = self.get_relative_path(child_file_path)
                if strutils.get_file_extension(child_file_path) == prog_lang_ext.PYTHON_PYD_FILE_EXT:
                    name = child_mod_name.split('.')[-1]
                else:
                    name = strutils.get_filename_without_ext(filename)
            else:
                file_path_name = os.path.join(child_file_path,PACKAGE_INIT_FILE)
                child_mod_name = self.get_relative_path(file_path_name)
                name = filename
            data = self.make_node_dict(
                name,
                nodetypes.MODULE,
                **{'modname':child_mod_name}
            )
            child_modules.append(data)        
        return child_modules
        
    def make_pyd_members_file(self, filepath):
        modname = self.get_relative_path(filepath)
        if not self.need_renew_module(modname):
            return False
        logger.info('pyd file %s modname is %s',filepath,modname)
        try:
            mod = importlib.import_module(modname)
        except (ModuleNotFoundError, ImportError) as e:
            logger.error("import pyd file %s fail:%s",filepath,str(e))
            return False
        childs = self.make_builtin_types(mod)
        self.make_members_file(modname, childs, path=filepath,is_builtin=True,doc=mod.__doc__)
        return True
        
    def make_code_members_file(self, filename, filepath ,modname):
        file_parser = fileparser.CodefileParser(self)
        try:
            file_parser.parse_single_file(filename, filepath, modname)
            childs = file_parser.get_module_childs()
            doc = file_parser.get_doc()
            #解析包文件,包目录下的其他文件都是包的子模块
            if filename == PACKAGE_INIT_FILE:
                child_modules = self.get_package_modules(filepath)
                childs.extend(child_modules)
            self.make_members_file(modname, childs, path=filepath,is_builtin=False,doc=doc)
            return True
        except ReferenceModuleNotAnalyzedError as ex:
            logger.warning(str(ex))
            return False
                
    def make_specialmodule_members_file(self):
        for special_module in self.SPECIAL_MODULES:
            if not self.need_renew_module(special_module):
                continue
            special_module_path = self.interpreter.find_module(special_module)
            if not special_module_path:
                continue
            self.make_code_members_file('',special_module_path,special_module)

    def clean_database_files(self):
        '''
        检查数据库里面的代码源文件是否存在如果不存在则删除
        '''
        delete_num = 0
        for members_filepath in glob.glob(os.path.join(self.data_out_path,"*" + MEMBERS_FILE_EXTENSION)):
            members_filepath = os.path.abspath(members_filepath)
            filename = os.path.basename(members_filepath)
            modname = strutils.get_filename_without_ext(filename)
            memberlist_filepath = os.path.abspath(os.path.join(self.data_out_path,modname+MEMBERLIST_FILE_EXTENSION))
            if not ModuleLoader('',members_filepath, memberlist_filepath).reload():
                delete_num += 1
            
        logger.info('delete total %d intelliense database files',delete_num)
