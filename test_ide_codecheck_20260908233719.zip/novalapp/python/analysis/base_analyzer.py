import os
import sys
import datetime
from ...common import version
thisfile = os.path.abspath(__file__)
root = thisfile.rsplit(os.sep, 2)[0]
# 添加第三方解析包astroid的搜索路径,以便能找到包
sys.path.append(os.path.join(root, "thirdparty"))
from ..parser import nodetypes
import pickle
from ..parser.define import MEMBERS_FILE_EXTENSION,MEMBERLIST_FILE_EXTENSION
from ...util.cmp_func import py_sorted,cmp_name
from .moduleloader import ModuleLoader

class BaseAnalyzer:
    """description of class"""
    DATABASE_FILE = "version"
    
    UPDATE_FILE = 'update_time'
    ISO_8601_DATE_FORMAT = "%Y-%m-%d"
    ISO_8601_TIME_FORMAT = "%H:%M:%S"
    ISO_8601_DATETIME_FORMAT = "%s %s" %(ISO_8601_DATE_FORMAT,
                                     ISO_8601_TIME_FORMAT)
    def __init__(self, dbver, data_outpath, interpreter):
        self.dbver = dbver
        self.data_out_path = data_outpath
        self.interpreter = interpreter
        self._need_renew_database = self.need_renew_database(self.dbver)
        
    @property
    def dbpath(self):
        return self.data_out_path
        
    def load_database_version(self):
        with open(os.path.join(self.data_out_path,BaseAnalyzer.DATABASE_FILE)) as f:
            return f.read()
        
    def save_database_version(self, new_version):
        with open(os.path.join(self.data_out_path,BaseAnalyzer.DATABASE_FILE),"w") as f:
            f.write(new_version)
        
    def need_renew_database(self,new_database_version):
        if not os.path.exists(os.path.join(self.data_out_path,BaseAnalyzer.DATABASE_FILE)):
            return True
        old_database_version = self.load_database_version()
        if 0 == version.compare_common_version(new_database_version,old_database_version):
            return False
        return True
        
    def make_module_dict(self, name, *, path=None,is_builtin=False,childs=[],doc=None,refs=[]):
        if is_builtin:
            module_data = dict(name=name,is_builtin=True,path=path,doc=doc,childs=childs,typenode=nodetypes.MODULE)
        else:
            module_data = dict(name=name,path=path,childs=childs,doc=doc,refs=refs,typenode=nodetypes.MODULE)
        return module_data
    
    def make_node_dict(self, name, typenode, *, childs=[], doc=None, line=-1, col=-1, **kwargs):
        data = dict(name=name,typenode=typenode)
        if childs:
            data.update({'childs':childs})
        if doc is not None:
            data.update({'doc':doc})
        if line != -1:
            data.update({'line':line,'col':col})
        if kwargs:
            data.update(kwargs)
        return data
        
    def get_member_filenames(self, modname):
        members_file_name = os.path.abspath(os.path.join(self.data_out_path, modname+MEMBERS_FILE_EXTENSION))
        memberlist_file_name = os.path.abspath(os.path.join(self.data_out_path, modname+MEMBERLIST_FILE_EXTENSION))
        return members_file_name, memberlist_file_name

    def make_members_file(self, modname, childs, *, path=None,is_builtin=False,doc=None):
        members_file_name, memberlist_file_name = self.get_member_filenames(modname)
        #去掉重复名称
        child_names = set([child['name'] for child in childs])
        names = list(child_names)
        names = py_sorted(names,cmp_name)
        with open(memberlist_file_name, 'w') as f:
            for name in names:
                f.write(name)
                f.write('\n')
        module_dict = self.make_module_dict(modname,path=path,is_builtin=is_builtin,childs=childs,doc=doc)
        with open(members_file_name, 'wb') as j:
            # Pickle dictionary.
            pickle.dump(module_dict, j)
        return members_file_name, memberlist_file_name
        
    def save_update_time(self):
        with open(os.path.join(self.data_out_path,BaseAnalyzer.UPDATE_FILE),"w") as f:
            datetime_str = datetime.datetime.strftime(datetime.datetime.now(), BaseAnalyzer.ISO_8601_DATETIME_FORMAT)
            f.write(datetime_str)
            
    def load_module(self, modname):
        membersfile,memberlistfile = self.get_member_filenames(modname)
        if not os.path.exists(membersfile):
            return None
        mdloader = ModuleLoader(modname,membersfile,memberlistfile)
        mdloader.load()
        return mdloader.data
