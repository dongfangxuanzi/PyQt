# -*- coding: utf-8 -*-
from ...lib import hiscache

class ProjectHistory(hiscache.CycleCache):
    '''
        记录历史项目列表,在起始页显示
    '''
    def __init__(self, maxFiles):
        hiscache.CycleCache.__init__(self,size=maxFiles,trim=hiscache.CycleCache.TRIM_LAST,add=hiscache.CycleCache.ADD_FIRST)
        
    def GetMaxFiles(self):
        return self._size
        
    def AddFileToHistory(self, file_path):
        assert(strutils.get_file_extension(file_path) == consts.PROJECT_SHORT_EXTENSION)
        #检查文件路径是否在历史项目列表中,如果存在则删除
        index = self.GetHistoryFileIndex(file_path)
        if index != -1:
            del self._list[index]
        self.PutPath(file_path)
        
    def Load(self,config):
        index = 1
        paths = []
        while True:
            key = "%s/file%d" % (consts.RECENT_PROJECTS_KEY,index)
            path = config.Read(key)
            if path:
                paths.append(path)
                index += 1
            else:
                break
        #务必按照倒序加载文件列表
        for path in paths[::-1]:
            self.PutPath(path)
            
    def PutPath(self,path):
        if self.GetCurrentSize() >= self._size:
            utils.get_logger().debug('history project list size %d is greater then max list size %d,will trim the last file item',self.GetCurrentSize(),self._size)
        #这里超过文件限制,会删除最后一个文件
        self.PutItem(path)

    def Clear(self,config):
        '''
            清空存储历史项目列表
        '''
        index = 1
        while True:
            key = "%s/file%d" % (consts.RECENT_PROJECTS_KEY,index)
            path = config.Read(key)
            if path:
                config.DeleteEntry(key)
                index += 1
            else:
                break

    def Save(self,config):
        #保存历史项目之前先要清空
        self.Clear(config)
        for i,item in enumerate(self._list):
            config.Write("%s/file%d" % (consts.RECENT_PROJECTS_KEY,i+1),item)
            
        if utils.is_linux():
            config.Save()
            
    def GetHistoryFile(self,i):
        assert(i >=0 and i < len(self._list))
        return self._list[i]
        
    def GetHistoryFileIndex(self,path):
        for i,item in enumerate(self._list):
            if parserutils.ComparePath(item,path):
                return i
        return -1
        
    def RemoveFileFromHistory(self,path):
        i = self.GetHistoryFileIndex(path)
        if i == -1:
            return
        del self._list[i]