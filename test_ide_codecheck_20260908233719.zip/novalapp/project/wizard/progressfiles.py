import os
from ...lib.pyqt import QThread
from ...util import utils
from ..command import ProjectAddProgressFilesCommand

class ImportProgressFiles(QThread):
    """description of class"""
    def __init__(self, project_browser, progress_ui,file_list,src_path,dest_path):
        super().__init__(progress_ui)
        self.project_browser = project_browser
        self.progress_ui = progress_ui
        self.files = file_list
        self.sourcepath = src_path
        self.destto = dest_path

    def BuildFileList(self,file_list):
        return file_list
        
    def run(self):
        self.copyfiles_to_project()
        
    @utils.compute_time
    def copyfiles_to_project(self):
        #构建路径对应文件列表的对照表
        utils.get_logger().info('start import total %d files from path %s to path %s',len(self.files),self.sourcepath,self.destto)
        files_dict = self.BuildFileMaps(self.files)
        copy_file_count = 0
        #按照路径分别来拷贝文件
        for dir_path in files_dict:
            if self.progress_ui.is_cancel:
                break
            #路径下所有拷贝的文件列表
            file_path_list = files_dict[dir_path]
            self.BuildFileList(file_path_list)
            #导入文件的相对路径
            folder_path = dir_path.replace(self.sourcepath,"").replace(os.sep,"/").lstrip("/").rstrip("/")
            paths = self.destto.split(os.sep)
            #目录路径如果有多层则导入文件的相对路径需添加多层目录
            if len(paths) > 1:
                #第一层目录为项目目录必须剔除
                dest_folder_path =  "/".join(paths[1:])
                if folder_path != "":
                    dest_folder_path +=  "/" + folder_path
            else:
                dest_folder_path = folder_path
            self.project_browser.GetView().GetDocument().GetCommandProcessor().Submit(
                ProjectAddProgressFilesCommand(
                    self.progress_ui,
                    self.project_browser.GetView().GetDocument(), 
                    file_path_list,
                    folderPath=dest_folder_path,
                    range_value = copy_file_count
                )
            )
            copy_file_count += len(file_path_list)
        self.progress_ui.update_progress_signal.emit(None, 'end')
        self.progress_ui.reset_prompt_message_id()
        #导入完成后设置启动文件
       # if is_wizard:
        #    progress_ui.SetStartupfile()

    def BuildFileMaps(self,file_list):
        d = {}
        for file_path in file_list:
            dir_path = os.path.dirname(file_path)
            if not dir_path in d:
                d[dir_path] = [file_path]
            else:
                d[dir_path].append(file_path)
        return d