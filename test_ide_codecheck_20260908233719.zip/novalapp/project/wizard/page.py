from ...lib.pyqt import QDialog, QHBoxLayout, QPushButton,QDialogButtonBox, Qt, QFrame, QVBoxLayout, QLabel,QSizePolicy
from ... import qtimage

class TitledWizardPage(QFrame):
    def __init__(self, title):
        super().__init__()
        self.title = title
        self.next = self.prev = None
        self.can_finish = True

    def SetNext(self, follow):
        self.next = follow

    def SetPrev(self, prev):
        self.prev = prev

    def GetNext(self):
        return self.next

    def GetPrev(self):
        return self.prev
        
    def Validate(self):
        return True

    def Finish(self):
        return True
        
    def CanFinish(self):
        return self.can_finish
        
    def Cancel(self):
        '''
            取消按钮事件,默认不处理,如果要处理取消事件,需要在派生类继承并重写该方法
        '''
        pass
        
    def Init(self):
        pass
        
class BitmapTitledWizardPage(TitledWizardPage):
    '''
        显示标题和图标的通用页面
    '''
    def __init__(self, master,title,label,bitmap):
        TitledWizardPage.__init__(self,title=title)
        self.img = qtimage.load_image(bitmap)
        self.page_box = QVBoxLayout()
        self.page_box.setContentsMargins(0,0,0,0)
        
        #创建向导标题框
        labels = label.split("\n")
        show_text = labels[0]
        hbox = QHBoxLayout()
        #设置标题的大号字体
        heading_label = QLabel(show_text)
        #标题大号字体
        heading_label.setStyleSheet("color:rgb(0,0,0);font-size:22px;font-weight:bold;")
        heading_label.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        hbox.addWidget(heading_label)
        heading_label.setSizePolicy(QSizePolicy.Expanding,
                                      QSizePolicy.Fixed)
        #label_ctrl.pack(fill="x",expand=1)
        #如果标题内容包含换行符,则创建一个小号的文本标签
        if len(labels) > 1:
            detail_text = labels[1]
            detail_text_ctrl = ttk.Label(label_frame,text=detail_text)
            #缩进小号的文本
            detail_text_ctrl.pack(fill="x",expand=1,padx=DEFAUT_CONTRL_PAD_X)
        #标题框图标
        img_ctrl = QLabel()
        img_ctrl.setPixmap(self.img)
        img_ctrl.adjustSize()
        img_ctrl.setSizePolicy(QSizePolicy.Fixed,
                                      QSizePolicy.Fixed)
        hbox.addWidget(img_ctrl)
        self.page_box.addLayout(hbox)
        self.setLayout(self.page_box)
        self.can_finish = False
        

class BitmapTitledContainerWizardPage(BitmapTitledWizardPage):
    '''
        显示标题和图标以及包含上下分隔符的通用页面
    '''
    def __init__(self, master,title,label,bitmap,**kwargs):
        BitmapTitledWizardPage.__init__(self,master,title,label,bitmap)
        
        bottom_box = QVBoxLayout()
        bottom_box.setContentsMargins(0,0,0,0)
        #创建顶部分隔符
        top_separator = QFrame()
        top_separator.setEnabled(False)
        top_separator.setFrameShape(QFrame.HLine)
        top_separator.setFrameShadow(QFrame.Plain)
        bottom_box.addWidget(top_separator)
        
        #创建向导框内容
        content_frame = QFrame()
        content_box = QVBoxLayout()
        bottom_box.addWidget(content_frame)
        #设置内容框左右间隔
        self.CreateContent(content_box,**kwargs)
        content_frame.setLayout(content_box)
        
        
        #创建底部分隔符
        bottom_separator = QFrame()
        bottom_separator.setEnabled(False)
        bottom_separator.setFrameShape(QFrame.HLine)
        bottom_separator.setFrameShadow(QFrame.Plain)
        bottom_box.addWidget(bottom_separator)
        
        self.page_box.addLayout(bottom_box)

    def CreateContent(self,content_frame,**kwargs):
        pass
