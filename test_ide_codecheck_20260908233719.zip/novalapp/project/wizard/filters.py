from ... import get_app, _
from ...lib.pyqt import QHBoxLayout,QDialog,QPushButton,QListWidget, Qt, QFrame, QVBoxLayout, QLabel,QSizePolicy,QLineEdit
import os
from ...util.ui_utils import BaseModalDialog

class FileFilterDialog(BaseModalDialog):
    def __init__(self,parent,filters,rejects=[]):
        BaseModalDialog.__init__(self,_("File Filters"),parent)
        self.filters = filters
        print(self.filters)
        vbox = QVBoxLayout()
        vbox.addWidget(QLabel(_("Please select file types to to allow added to project:")))      
        self.listbox = QListWidget()
        vbox.addWidget(self.listbox)
        vbox.addWidget(QLabel(_("Other File Extensions:(seperated by ';')")))
        self.other_extensions_ctrl = QLineEdit()
        vbox.addWidget(self.other_extensions_ctrl)
        self.InitFilters()
        
        self.create_standard_buttons(vbox)
        self.setLayout(vbox)

    def accept(self):
        filters = []
        for i in range(self.listbox.count()):
            item = self.listbox.item(i)
            if item.checkState() == Qt.Checked:
               filters.append(item.text())
        extension_value = self.other_extensions_ctrl.text().strip()
        if extension_value != "":
            extensions = extension_value.split(";")
            filters.extend(extensions)
        self.filters = [fitler.replace("*","").replace(".","") for fitler in filters]
        super().accept()
        
    def InitFilters(self):
        descr = ''
        for temp in get_app().GetDocumentManager().GetTemplates():
            if temp.IsVisible() and temp.GetDocumentName() != 'Project Document':
                filters = temp.GetFileFilter().split(";")
                for temp_filter in filters:
                    self.listbox.addItem(temp_filter)
                    i = self.listbox.count()-1
                    item = self.listbox.item(i)
                    if str(temp_filter.replace("*","").replace(".","")) in self.filters:
                        item.setCheckState(Qt.Checked)
                    else:
                        item.setCheckState(Qt.Unchecked)
