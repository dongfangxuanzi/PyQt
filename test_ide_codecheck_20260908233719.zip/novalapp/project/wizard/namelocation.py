import os
import uuid
from ... import _, get_app
from ...lib.pyqt import QHBoxLayout, QPushButton,QComboBox, Qt, QFrame, QVBoxLayout, QLabel,QSizePolicy,QLineEdit,QFileDialog,QCheckBox,QMessageBox
from . import page as wizardpage
from ... import globalkeys
from ...util import appdirs, utils, fileutils,strutils
from .templatemanager import WizardtemplateManager
from .. import ext
from ..config import ProjectConfiguration
from ...lib.docmanager import DOC_NEW

NEW_PROJECT_DIRECTORY_DEFAULT = appdirs.getSystemDir()

class ProjectNameLocationPage(wizardpage.BitmapTitledContainerWizardPage):
    def __init__(self,master,**kwargs):
        self.is_empty_project = kwargs.get('is_empty_project',False)
        wizardpage.BitmapTitledContainerWizardPage.__init__(
            self,
            master,
            _("Enter the name and location for the project"),
            _("Name and Location"),
            master.get_titled_bitmap(),
            **kwargs
        )
        self.can_finish = kwargs.get('can_finish',True)
        self.allowOverwriteOnPrompt = True
        self.new_project_doc = None
            
    def CreateContent(self,content_box,**kwargs):
        info_label = QLabel(_("Enter the name and location for the project."))
        info_label.setSizePolicy(QSizePolicy.Expanding,
                                      QSizePolicy.Fixed)
        content_box.addWidget(info_label)
        self.CreateNamePage(content_box)
        self.CreateBottomFrame(content_box)
       #这等于说是给控件间添加了一个空白控件，并把它两边，或上下的控件向两端推，像弹簧一样
        content_box.addStretch(1)
        self.infotext_label = QLabel("")
        self.infotext_label.setStyleSheet("color:red")
        content_box.addWidget(self.infotext_label)
            
    def GetChoiceDirs(self,choiceDirs):
        choiceDirs.append(utils.profile_get(globalkeys.PROJECT_DIRECTORY_KEY, NEW_PROJECT_DIRECTORY_DEFAULT))
        curProjectDoc = get_app().MainFrame.projectview.GetCurrentProject()
        projectDirs = []
        #先添加当前项目文档的路径到可选路径列表中
        if curProjectDoc:
            homeDir = os.path.dirname(curProjectDoc.GetAppDocMgr().homeDir)
            if homeDir and (homeDir not in choiceDirs):
                choiceDirs.append(homeDir)
            #if not startingDirectory:
             #   startingDirectory = homeDir
        #再添加其它项目文档的路径到可选路径列表中
        for projectDoc in get_app().MainFrame.projectview.GetOpenProjects():
            if projectDoc == curProjectDoc:
                continue
            homeDir = os.path.dirname(projectDoc.GetAppDocMgr().homeDir)
            if homeDir and (homeDir not in projectDirs):
                projectDirs.append(homeDir)
        for projectDir in projectDirs:
            if projectDir not in choiceDirs:
                choiceDirs.append(projectDir)
                
        #添加当前路径到可选路径列表中
        cwdir = None
        try:
            cwdir = os.getcwd()
        except:
            pass
        if cwdir and cwdir not in choiceDirs:
            choiceDirs.append(cwdir)   
        #最后添加系统默认路径到可选路径列表中             
        if appdirs.getSystemDir() not in choiceDirs:
            choiceDirs.append(appdirs.getSystemDir()) 
            
    def CreateNamePage(self,content_box):
        name_hbox = QHBoxLayout()
        name_label = QLabel(_("Name:"))
        name_label.setSizePolicy(QSizePolicy.Fixed,
                                      QSizePolicy.Fixed)
        name_hbox.addWidget(name_label)
        self.name_entry = QLineEdit()
        self.name_entry.setSizePolicy(QSizePolicy.Expanding,
                                      QSizePolicy.Fixed)
        name_hbox.addWidget(self.name_entry)
        content_box.addLayout(name_hbox)
        
        location_hbox = QHBoxLayout()
        dir_label = QLabel(_("Location:"))
        dir_label.setSizePolicy(QSizePolicy.Fixed,
                                      QSizePolicy.Fixed)
        location_hbox.addWidget(dir_label)
        choiceDirs = []
        self.GetChoiceDirs(choiceDirs)
        utils.get_logger().debug('choice dirs is :%s',choiceDirs)
        self.dir_entry = QComboBox()
        self.dir_entry.setSizePolicy(QSizePolicy.Expanding,
                                      QSizePolicy.Fixed)
        self.dir_entry.setEditable(True)
        self.dir_entry.addItems(choiceDirs)
        location_hbox.addWidget(self.dir_entry)
        self.browser_button = QPushButton(_("Browse..."))
        location_hbox.addWidget(self.browser_button)
        self.browser_button.clicked.connect(self.BrowsePath)
        content_box.addLayout(location_hbox)
 
    def CreateBottomFrame(self,content_box):
        #默认创建项目目录
        self.create_projectdir_checkbtn = QCheckBox(("Create project directory"))
        self.create_projectdir_checkbtn.setChecked(True)
        content_box.addWidget(self.create_projectdir_checkbtn)
            
    def Init(self):
        #项目模板是导入文件模板时不显示创建项目目录复选框
        if WizardtemplateManager.get_manager().current_template.name == WizardtemplateManager.PROJECT_FROM_EXIST_CODE:
            self.create_projectdir_checkbtn.setVisible(False)
        else:
            self.create_projectdir_checkbtn.setVisible(True)
        
    def BrowsePath(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog | QFileDialog.ShowDirsOnly
        dirName = QFileDialog.getExistingDirectory(
            self, _("Select project directory"), self.dir_entry.lineEdit().text(),
            options)
        if dirName:
            self.dir_entry.lineEdit().setText(fileutils.opj(dirName))

    def Validate(self):
        self.infotext_label.setText("")
        projName = self.name_entry.text().strip()
        if projName == "":
            self.infotext_label.setText(_("Please provide a file name."))
            return False
        #项目名称不能包含空格
        if projName.find(' ') != -1:
            self.infotext_label.setText(_("Please provide a file name that does not contains spaces."))        
            return False

        if projName[0].isdigit():
            self.infotext_label.setText(_("File name cannot start with a number.  Please enter a different name."))            
            return False
        if projName.endswith(ext.PROJECT_EXTENSION):
            projName2 = projName[:-len(ext.PROJECT_EXTENSION)]
        else:
            projName2 = projName
        #项目名称必须是字母或数字,下划线字符串允许合法
        if not projName2.replace("_", "a").isalnum():  # [a-zA-Z0-9_]  note '_' is allowed and ending '.agp'.
            self.infotext_label.setText(_("Name must be alphanumeric ('_' allowed).  Please enter a valid name."))
            return False

        dirName = self.dir_entry.lineEdit().text().strip()
        if dirName == "":
            self.infotext_label.setText(_("No directory.  Please provide a directory."))
            return False
        if os.sep == "\\" and dirName.find("/") != -1:
            self.dir_entry.setText(_("Wrong delimiter '/' found in directory path.  Use '%s' as delimiter.") % os.sep)            
            return False
            
        return True
        
    def GetProjectLocation(self):
        projName = self.name_entry.text().strip()
        dirName = self.dir_entry.lineEdit().text().strip()
        #是否创建项目名称目录,如果是则目录包含项目名称
        if self.create_projectdir_checkbtn.isChecked() and self.create_projectdir_checkbtn.isVisible():
            dirName = os.path.join(dirName,projName)
        return dirName
        
    def Finish(self):
        dirName = self.GetProjectLocation()
        #if dir not exist,create it first
        if not os.path.exists(dirName):
            try:
                fileutils.makedirs(dirName)
            except Exception as e:
                #如果不是最后的页面,错误提示控件不可见
                #错误的信息需要弹出来,来醒目地提示用户错误,否则用户看不到错误信息
                if self.infotext_label.isVisible():
                    self.infotext_label.setText("%s"%str(e))
                else:
                    QMessageBox.critical(self.parent(),_('Error'),str(e))
                return False
            
        projName = self.name_entry.text().strip()
        fullProjectPath = os.path.join(dirName, strutils.MakeNameEndInExtension(projName, ext.PROJECT_EXTENSION))
        if os.path.exists(fullProjectPath):
            if self.allowOverwriteOnPrompt:
                res = QMessageBox.question(
                    self.parent(),
                    _("File Exists"),
                    _("That project file already exists. Would you like to overwrite it."), 
                    QMessageBox.Yes|QMessageBox.No
                )
                if res != QMessageBox.Yes:
                    return False
            else:                
                #如果不是最后的页面,错误提示控件不可见
                #错误的信息需要弹出来,来醒目地提示用户错误,否则用户看不到错误信息
                if self.infotext_label.isVisible():
                    self.infotext_label_var.set(_("That file already exists. Please choose a different name."))
                else:
                    QMessageBox.critical(self.parent(),_('File Exists'),_("That file already exists. Please choose a different name."))
                return False
                
            # What if the document is already open and we're overwriting it?
            documents = get_app().GetDocumentManager().GetDocuments()
            for document in documents:
                if os.path.normcase(document.GetFilename()) == os.path.normcase(fullProjectPath):  # If the renamed document is open, update it
                    document.DeleteAllViews()
                    break
            os.remove(fullProjectPath)
   
        self._new_project_configuration = self.GetNewPojectConfiguration()
        utils.profile_set(globalkeys.PROJECT_DIRECTORY_KEY, self._new_project_configuration.Location)
        if not self.SaveProject(fullProjectPath):
            return False
        return True

    def SaveProject(self,path):
        template = self.GetProjectTemplate()
        self.new_project_doc = template.CreateDocument(path, flags = DOC_NEW)
        #set project name
        self.new_project_doc.GetModel().Name = self._new_project_configuration.Name
        self.new_project_doc.GetModel().Id = str(uuid.uuid1()).upper()
        if not self.new_project_doc.OnSaveDocument(path):
            return False
        view = get_app().MainFrame.projectview.GetView()
        view.AddProjectToView(self.new_project_doc)
        #强制显示项目视图
        get_app().MainFrame.activateProjectTab()
        return True

    def GetProjectTemplate(self):
        return get_app().GetDocumentManager().FindTemplateForTestPath(ext.PROJECT_EXTENSION)

    def GetNewPojectConfiguration(self):
        project_dir_created = True
        if self.create_projectdir_checkbtn.isVisible():
            project_dir_created = False
        else:
            project_dir_created = self.create_projectdir_checkbtn.isChecked()
        return ProjectConfiguration(self.name_entry.text().strip(),self.dir_entry.lineEdit().text().strip(),project_dir_created)
        