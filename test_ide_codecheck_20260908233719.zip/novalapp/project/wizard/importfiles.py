# -*- coding: utf-8 -*-
from ... import _ ,get_app
from ...lib.pyqt import QHBoxLayout, QTreeWidgetItem,QCoreApplication,QDialog,QMessageBox,QPushButton,pyqtSignal,QTreeWidget, QProgressBar,QListWidgetItem,QListWidget, Qt, QFrame, QVBoxLayout, QLabel,QSizePolicy,QLineEdit,QFileDialog,QCheckBox
import os
from ...util import utils, fileutils,strutils,apputils
from . import page as wizardpage
from .. import ext
from .filters import FileFilterDialog
from threading import Event

class ImportfilesPage(wizardpage.BitmapTitledContainerWizardPage):
    
    #添加项目文件覆盖已有文件时默认处理方式
    DEFAULT_PROMPT_MESSAGE_ID = QMessageBox.Yes
    
    update_progress_signal = pyqtSignal(int, str)
    sig_show_messagebox = pyqtSignal(str)
    
    def __init__(self,master,filters=[],rejects=[],is_wizard=True,folderPath=None):
        '''
            is_wizard表示该页面是否是新建项目向导时的页面
        '''
        self.folderPath = folderPath
        self.dest_path = ''
        self._is_wizard = is_wizard
        #文件类型过滤列表
        self.filters = filters
        self.rejects = []
        #self.rejects = rejects + projectdocument.ProjectDocument.BIN_FILE_EXTS
        
        super().__init__(master,_("Import codes from File System"),_("Local File System"),master.get_titled_bitmap())
        self.can_finish = True
        self.project_browser = get_app().MainFrame.projectview
        self.update_progress_signal.connect(self.update_progress)
        self.sig_show_messagebox.connect(self.show_messagebox)
        #等待用户确认事件
        self.wait_event = Event()
        
    def CreateContent(self,content_box,**kwargs):
        content_box.setContentsMargins(0,0,0,0)
        path_hbox = QHBoxLayout()
        dir_label = QLabel(_("Source Location:"))
        path_hbox.addWidget(dir_label)
        self.dir_entry = QLineEdit()
        path_hbox.addWidget(self.dir_entry)
       # self.dir_entry_var.trace("w", self.ChangeDir)
        self.dir_entry.textChanged.connect(self.ChangeDir)
        self.browser_button = QPushButton(_("Browse..."))
        self.browser_button.clicked.connect(self.BrowsePath)
        path_hbox.addWidget(self.browser_button)
        content_box.addLayout(path_hbox)
        
        list_hbox = QHBoxLayout()
        self.check_box_view = QTreeWidget()
        self.check_box_view.setHeaderHidden(True)
        list_hbox.addWidget(self.check_box_view)
     #   self.check_box_view.tree.bind("<<TreeviewSelect>>", self._on_select, True)
        self.check_box_view.itemSelectionChanged.connect(self._on_select)
      #  self.check_box_view.tree.bind("<Button-1>", self._box_click, True)
        self.current_item = None
        
        self.check_listbox = QListWidget()
        list_hbox.addWidget(self.check_listbox)
        content_box.addLayout(list_hbox)
        
        button_hbox = QHBoxLayout()
        button_hbox.setAlignment(Qt.AlignLeft)
        
        self.file_filter_btn = QPushButton(_("File Filters"))
        self.file_filter_btn.clicked.connect(self.SetFilters)
        button_hbox.addWidget(self.file_filter_btn)
        self.file_filter_btn.setSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed)
        
        self.select_all_btn = QPushButton(_("Select All"))
        self.select_all_btn.clicked.connect(self.SelectAll)
        self.select_all_btn.setSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed)
        button_hbox.addWidget(self.select_all_btn)
        
        self.unselect_all_btn = QPushButton(_("UnSelect All"))
        self.unselect_all_btn.clicked.connect(self.UnselectAll)
        self.unselect_all_btn.setSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed)
        button_hbox.addWidget(self.unselect_all_btn)
        content_box.addLayout(button_hbox)
        #导入对话框页面添加一行控件
        if not self._is_wizard:
            frame = ttk.Frame(content_frame)
            ttk.Label(frame, text=_('Dest Directory:')).pack(side=tk.LEFT,fill="x")
            self.dest_pathVar = tk.StringVar(value=self.dest_path)
            destDirCtrl = ttk.Entry(frame, textvariable=self.dest_pathVar,state=tk.DISABLED)
            destDirCtrl.pack(side=tk.LEFT,fill="x",padx=consts.DEFAUT_CONTRL_PAD_X)
            frame.grid(column=0, row=5, sticky="nsew",pady=(consts.DEFAUT_CONTRL_PAD_Y,0))
            sbox_frame = ttk.LabelFrame(content_frame, text=_("Option"))
            self.overwrite_chkboxVar = tk.IntVar(value=False)
            ttk.Checkbutton(sbox_frame, variable=self.overwrite_chkboxVar,text = _("Overwrite existing files without warning")).pack(fill="x",padx=consts.DEFAUT_CONTRL_PAD_X)
            self.root_folder_chkboxVar = tk.IntVar(value=False)
            ttk.Checkbutton(sbox_frame, variable=self.root_folder_chkboxVar,text = _("Create top-level folder")).pack(fill="x",padx=consts.DEFAUT_CONTRL_PAD_X,pady=(0,consts.DEFAUT_CONTRL_PAD_Y))
            sbox_frame.grid(column=0, row=6, sticky="nsew")
            self._progress_row = 7
        self.create_progress(content_box)
        self.root_item = None
        self.is_cancel = False

    def GetDestpath(self):
        #目的路径必须用相对路径
        current_project = self.project_browser.GetView().GetDocument()
        if current_project is None:
            raise RuntimeError(_('There is no available project yet.'))

        project_path = os.path.dirname(current_project.GetFilename())
        self.dest_path = os.path.basename(project_path)
        if self.folderPath:
            self.dest_path = os.path.join(self.dest_path,self.folderPath)

        #格式化系统标准路径
        if apputils.is_windows():
            self.dest_path = self.dest_path.replace("/",os.sep)
            
    def InitDestpath(self):
        assert(not self._is_wizard)
        self.GetDestpath()
        self.dest_pathVar.set(self.dest_path)
        
    def create_progress(self, content_box):
        self.info_label = QLabel()
        content_box.addWidget(self.info_label)
        self.pb = QProgressBar()
        content_box.addWidget(self.pb)
        self.pb.setVisible(False)
        
    def ShowProgress(self):
        self.pb.setVisible(True)
        
    def update_progress(self, curval, msg):
        if msg == "end":
            self.pb.setValue(self.pb.maximum())
            self.parent().parent().close()
        else:
            self.pb.setValue(curval)
            self.info_label.setText(_("Importing file ") + msg)
            QCoreApplication.processEvents()

    def SetFilters(self):
        filter_dlg = FileFilterDialog(self,self.filters,self.rejects)
        if filter_dlg.exec_() == FileFilterDialog.Accepted:
            self.filters = filter_dlg.filters

    def BrowsePath(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog | QFileDialog.ShowDirsOnly
        dirName = QFileDialog.getExistingDirectory(
            self, _("Select project directory"), self.dir_entry.text(),
            options)
        if dirName:
            self.dir_entry.setText(fileutils.opj(dirName))
            
    def ChangeDir(self,*args):
        path =  self.dir_entry.text().strip()
        if path == "":
            self.check_box_view.clear()
            return
        path = fileutils.opj(path)
        self.ListDirItemFiles(path.rstrip(os.sep))

    def ListDirItemFiles(self,path):
        self.check_box_view.clear()
        self.check_listbox.clear()
        rootitem = QTreeWidgetItem()
        rootitem.setText(0, os.path.basename(path))
        rootitem.setCheckState(0,Qt.Checked)
        rootitem.setData(0, Qt.UserRole,path)
        self.check_box_view.invisibleRootItem().addChild(rootitem)
        self.root_item = rootitem
        self.current_item = self.root_item
        self.ListDirTreeItem(self.root_item,path)
        self.ListDirFiles(self.root_item, Qt.Checked)
    #    self.check_box_view.CheckItem(self.root_item)
       # self.check_box_view.focus(self.root_item)
        self.check_box_view.setCurrentItem(self.root_item)
        
    def _on_select(self,):
        item = self.check_box_view.currentItem()
        self.SelectItem(item)

    def _box_click(self,event):
        x, y, widget = event.x, event.y, event.widget
        elem = widget.identify("element", x, y)
        if not "image" in elem:
            return
        item = self.check_box_view.tree.identify_row(y)
        self.SelectItem(item)
        
    def SelectItem(self,item):
        #同一个节点无需遍历目录
        if self.current_item == item:
            self.CheckListbox(item.checkState(0))
            return
        self.current_item = item
        self.ListDirFiles(item,item.checkState(0))
        
    def ListDirTreeItem(self,parent_item,path):
        if not os.path.exists(path):
            return
        files = os.listdir(path)
        for f in files:
            file_path = os.path.join(path, f)
            if os.path.isdir(file_path) and not fileutils.is_file_path_hidden(file_path):
                diritem = QTreeWidgetItem()
                diritem.setText(0, f)
                diritem.setCheckState(0,Qt.Checked)
                diritem.setData(0, Qt.UserRole,file_path)
                parent_item.addChild(diritem)
                self.ListDirTreeItem(diritem,file_path)
        parent_item.setExpanded(True)
        
    def ListDirFiles(self,item,checkstate):
        path = item.data(0, Qt.UserRole)
        if not os.path.exists(path):
            self.check_box_view.clear()
            return
        self.check_listbox.clear()
        files = os.listdir(path)
        for f in files:
            file_path = os.path.join(path, f)
            if os.path.isfile(file_path) and not fileutils.is_file_path_hidden(file_path) and not strutils.get_file_extension(file_path) in self.rejects:
                listitem = QListWidgetItem(f)
                self.check_listbox.addItem(listitem)
                listitem.setCheckState(checkstate)

    def Finish(self):
        global DEFAULT_PROMPT_MESSAGE_ID
        file_list = self.GetImportFileList()
        total_file_count = len(file_list)
        if 0 == total_file_count:
            return False
        utils.get_logger().debug("there is total %d import files",total_file_count)
        self.GetDestpath()
        if not hasattr(self,"cur_prog_val"):
            self.ShowProgress()

        self.DisableUI()
        if self._is_wizard:
            self.parent().parent().ok_button.setEnabled(False)
            self.parent().parent().prev_button.setEnabled(False)
        else:
            self.master.master.ok_button['state'] = tk.DISABLED
        self.pb.setMaximum(total_file_count)
        prev_page = self.GetPrev()
        root_path = self.root_item.data(0, Qt.UserRole)
        self.root_item.setExpanded(True)       
        if not self._is_wizard:
            if self.overwrite_chkboxVar.get():
                DEFAULT_PROMPT_MESSAGE_ID = constants.ID_YESTOALL
            if self.root_folder_chkboxVar.get():
                self.dest_path = os.path.join(self.dest_path,self.check_box_view.tree.item(self.root_item,"text"))
            
        self.project_browser.copyfiles_to_project(self,file_list,root_path,self.dest_path)
        return False
        
    def GetImportFileList(self):
        file_list = []
        root_path = self.root_item.data(0, Qt.UserRole)
        #如果根节点未选中则直接从硬盘中获取根路径的文件列表
        if not self.IsItemSelected(self.root_item):
            fileutils.GetDirFiles(root_path,file_list,self.filters)
        else:
            #如果根节点选中则从界面获取有哪些文件被选中了
            self.GetCheckedItemFiles(self.root_item,file_list)
        #扫描根节点下的所有文件列表
        self.RotateItems(self.root_item,file_list)
        if 0 == len(file_list):
            QMessageBox.information(self,get_app().GetAppName(),_("You don't select any file"))
            return file_list

        project_file_path = self.project_browser.GetView().GetDocument().GetFilename()
        #如果项目文件在文件列表中剔除
        if project_file_path in file_list:
            file_list.remove(project_file_path)
        return file_list
        
    def DisableUI(self):
        self.dir_entry.setEnabled(False)
        self.browser_button.setEnabled(False)
        self.select_all_btn.setEnabled(False)
        self.unselect_all_btn.setEnabled(False)
        self.file_filter_btn.setEnabled(False)
        self.check_box_view.setEnabled(False)
        self.check_listbox.setEnabled(False)
        
    def IsItemSelected(self,item):
        return self.check_box_view.currentItem() == item
        
    def GetCheckedItemFiles(self,item,file_list):
        dir_path = item.data(0, Qt.UserRole)
        for i in range(self.check_listbox.count()):
            listitem = self.check_listbox.item(i)
            if listitem.checkState() == Qt.Checked:
                f = os.path.join(dir_path,listitem.text())
                if self.filters != []:
                    if strutils.get_file_extension(f) in self.filters:
                        file_list.append(f)
                else:
                    file_list.append(f)
            
    def RotateItems(self,parent_item,file_list):
        for i in range(parent_item.childCount()):
            item = parent_item.child(i)
            if item.checkState(0) != Qt.Unchecked:
                dir_path = item.data(0, Qt.UserRole)
                #如果节点未选中则直接从硬盘中获取路径的文件列表
                if not self.IsItemSelected(item):
                    fileutils.GetDirFiles(dir_path,file_list,filters=self.filters,rejects=self.rejects)
                else:
                    #如果节点选中则从界面获取有哪些文件被选中了
                    self.GetCheckedItemFiles(item,file_list)
            #递归子节点
            self.RotateItems(item,file_list)
        
    def SelectAll(self):
        if self.root_item is None:
            return
        self.check_box_view.tree.CheckItem(self.root_item)
        self.CheckListbox(Qt.Checked)
        
    def CheckListbox(self,checkstate):
        for i in range(self.check_listbox.count()):
            listitem = self.check_listbox.item(i)
            listitem.setCheckState(checkstate)
        
    def UnselectAll(self):
        if self.root_item is None:
            return
        self.check_box_view.tree.CheckItem(self.root_item,False)
        self.CheckListbox(Qt.Unchecked)
        
    def Validate(self):
        if self.root_item is None or self.root_item.checkState(0) == Qt.Unchecked:
            QMessageBox.information(self,get_app().GetAppName(),_("You don't select any file"))
            return False
        return True
        
    def Cancel(self):
        if hasattr(self,"cur_prog_val"):
            self.label_var.set("cancel importing file.....")
        self.is_cancel = True

    def SetStartupfile(self):
        '''
            导入文件后设置项目的启动文件
        '''
        prev_page = self.GetPrev()
        while prev_page:
            #顺序查找上一个页面是否是新建项目页面
            if hasattr(prev_page,"startup_path_var"):
                startup_file_path = prev_page.GetStartupfile()
                doc = self.project_browser.GetView().GetDocument()
                startup_file = doc.GetModel().FindFile(startup_file_path)
                if startup_file:
                    item = doc.GetFirstView()._treeCtrl.FindItem(startup_file.filePath)
                    doc.GetFirstView().SetProjectStartupFileItem(item)
                else:
                    #启动文件未找到
                    messagebox.showwarning(GetApp().GetAppName(),_("Startup path %s is not exists in project")%startup_file_path)
                break
            prev_page = prev_page.GetPrev()
            
    def show_messagebox(self, filePath):
        ret = QMessageBox.question(
            self,
            _("Project File Exists"),
            ("The file %s is already exist in project ,Do You Want to overwrite it?") % filePath,
            QMessageBox.Yes|QMessageBox.No|QMessageBox.YesToAll|QMessageBox.NoToAll
        )
        self.DEFAULT_PROMPT_MESSAGE_ID = ret
        #设置事件
        self.wait_event.set()
        
    @classmethod
    def reset_prompt_message_id(cls):
        cls.DEFAULT_PROMPT_MESSAGE_ID = QMessageBox.Yes

class ImportfilesDialog(QDialog):
    
    def __init__(self, master,folderPath):
        super().__init__(master)
        self.setWindowTitle(_("Import Files"))
        project_template = get_app().GetDocumentManager().FindTemplateForTestPath(ext.PROJECT_EXTENSION)
        #rejects为项目禁止导入的文件类型列表
        self.import_page = ImportfilesPage(self.main_frame,is_wizard=False,folderPath=folderPath,rejects=project_template.GetDocumentType().BIN_FILE_EXTS)
        self.import_page.pack(fill="both",expand=1)
        #初始化目的地址
        self.import_page.InitDestpath()
        self.AddokcancelButton()
        self.ok_button.configure(text=_("&Import"),default="active")
        self.FormatTkButtonText(self.ok_button)

    def _ok(self,event=None):
        if not self.import_page.Validate():
            return
        #导入文件时强制显示项目视图
        GetApp().MainFrame.GetProjectView(show=True)
        if not self.import_page.Finish():
            return
        ui_base.CommonModaldialog._ok(self,event)

    def _cancel(self):
        self.import_page.Cancel()
        ui_base.CommonModaldialog._cancel(self)


