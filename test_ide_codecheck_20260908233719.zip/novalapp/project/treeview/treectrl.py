import os
from ...lib.pyqt import (Qt, QModelIndex, QSortFilterProxyModel, QAbstractItemView,
                 QApplication, QTreeView, pyqtSignal)
                 
from ... import qtimage, get_app
from .projectbrowsermodel import ProjectBrowserModel
from . import treeitems 
from .. import ext
from .sortmodel import FilesBrowserSortFilterProxyModel
from ..resolver.model import ProjectFile

class ProjectTreeCtrl(QTreeView):
    
    #用来设置粗体节点,粗体节点用来表示项目启动文件
    BOLD_TAG = 'BoldItem'
    NORMAL_TAG = 'NormalItem'
    sigFirstSelectedItem = pyqtSignal(QModelIndex)
    sigAddFileItem = pyqtSignal(ProjectFile)
    #----------------------------------------------------------------------------
    # Overridden Methods
    #----------------------------------------------------------------------------

    def __init__(self, master):
        super().__init__(master)
        self._iconLookup = {}
        
        self.__model = ProjectBrowserModel(master)
        self.__sortModel = FilesBrowserSortFilterProxyModel(False)
        self.__sortModel.setSourceModel(self.__model)
        self.setModel(self.__sortModel)
        
        self.setRootIsDecorated(True)
        self.setAlternatingRowColors(True)
        self.setUniformRowHeights(True)
        self.setSortingEnabled(True)
        
        self._blankIconImage = qtimage.blank_icon()
      #  self._packageFolderImage = imageutils.getPackageFolderIcon()
        self._folderClosedImage = qtimage.getFolderClosedIcon()
        
        self.is_edit_state = False
        self.entryPopup = None
        
    #    self.bind("<Escape>", self.EndLabel)
     #   self.bind("<Button-1>", self.FinishLabel)
        self.sigAddFileItem.connect(self.add_progress_file)
        
    def SelectItem(self,node):
        self.selection_set(node)
        self.focus(node)
        
    def BuildLookupIcon(self):
        if 0 == len(self._iconLookup):
            self.RebuildLookupIcon()
        
    def RebuildLookupIcon(self):
        templates = get_app().GetDocumentManager().GetTemplates()
        for template in templates:
            icon = template.GetIcon()
            self._iconLookup[template] = icon
        
    #设置项目启动文件节点为粗体
    def SetItemBold(self,node,bold=True):
        if bold:
            self.item(node, tags=(self.BOLD_TAG))
            self.tag_configure(self.BOLD_TAG, font=consts.TREE_VIEW_BOLD_FONT)
        else:
            self.item(node, tags=(self.NORMAL_TAG))
            self.tag_configure(self.NORMAL_TAG, font=consts.TREE_VIEW_FONT)
        
    def GetChildrenCount(self,item):
        return len(self.get_children(item))
        
    def DeleteChildren(self,node):
        for child_id in self.get_children(node):
            self.delete(child_id)

    def GetRootItem(self):
        return self.GetFirstChild(self.__model.rootItem)
        
    def GetFirstChild(self,item):
        childs = item.children()
        if 0 == len(childs):
            return None
        return childs[0]
        
    def EndLabel(self,event):
        if not self.is_edit_state or self.entryPopup is None:
            return
        self.entryPopup.destroy()
        self.entryPopup = None
        self.is_edit_state = False
                
    def FinishLabel(self,event):
        if not self.is_edit_state or self.entryPopup is None:
            return
        self.master.GetView().OnEndLabelEdit(self.entryPopup.item,self.entryPopup.get())
        self.EndLabel(event)
        
    def EditLabel(self,item):
        self.is_edit_state = True
        item_box = self.bbox(item)
        if not item_box:
            self.see(item)
            return
        x,y,width,height = item_box
        # y-axis offset
        pady = height // 2
        # place Entry popup properly         
        text = self.item(item, 'text')
        self.entryPopup = EntryPopup(self,text,item)
        self.entryPopup.place( x=30, y=y+pady, anchor=tk.W, relwidth=1)
        
    def AppendFolder(self, parent, folderName):
        folder_item = treeitems.TreeViewFolderItem(parent, folderName)
        folder_item.icon = self._folderClosedImage
        parent_index = self.__model.buildIndex(parent.getRowPath())
        self.__model.addItem(folder_item,parent_index)
        return folder_item
        
    def GetIconFromName(self,filename):
        template = wx.GetApp().GetDocumentManager().FindTemplateForPath(filename)
        return self.GetTemplateIcon(template)
        
    def GetProjectIcon(self):
        template = get_app().GetDocumentManager().FindTemplateForTestPath(ext.PROJECT_EXTENSION)
        project_file_image = self.GetTemplateIcon(template)
        return project_file_image
        
    def source_model(self):
        return self.model().sourceModel()
        
    def AddProjectRoot(self,project_name):
        item = treeitems.TreeViewItem(self.__model.rootItem, project_name)
        item.icon = self.GetProjectIcon()
        item.itemType = treeitems.ProjectRootType
        parent_index = self.__model.buildIndex(self.__model.rootItem.getRowPath())
        self.__model.addItem(item,parent_index)
        return item
        
    def GetTemplateIcon(self,template):
        self.BuildLookupIcon()
        if template in self._iconLookup:
            return self._iconLookup[template]
        return self._blankIconImage

    def AppendItem(self, parent, filename, file):
        #查找项目文件是否有另外的打开方式模板
        template = get_app().MainFrame.projectview.GetView().GetOpenDocumentTemplate(file)
        found = False
        #如果没有则使用项目文件扩展名对应的默认模板
        if template is None:
            template = get_app().GetDocumentManager().FindTemplateForPath(filename)
        file_image = self.GetTemplateIcon(template)
        fileitem = treeitems.TreeViewFileItem(parent, filename)
        fileitem.setPath(file.filePath)
        fileitem.icon = file_image
        parent_index = self.__model.buildIndex(parent.getRowPath())
        self.__model.addItem(fileitem,parent_index)
        return fileitem

    def AddFolder(self, folderPath):
        folderItems = []
        
        if folderPath != None:
            folderTree = folderPath.split('/')
            
            item = self.GetRootItem()
            for folderName in folderTree:
                found = False
                for child in item.children():
                    if child.itemType == treeitems.FileItemType:
                        pass
                    else: # folder
                        if child.data() == folderName:
                            item = child
                            found = True
                            break
                    
                if not found:
                    item = self.AppendFolder(item, folderName)
                    folderItems.append(item)

        return folderItems
        

    def FindItem(self, filePath, parentItem=None):
        if not parentItem:
            parentItem = self.GetRootItem()
            
        for child in parentItem.children():
            if child.itemType == treeitems.FileItemType:
                if child.path == filePath:
                    return child
            else: # folder
                result = self.FindItem(filePath, child)  # do recursive call
                if result:
                    return result
        
        return None


    def FindFolder(self, folderPath):
        if folderPath != None:
            folderTree = folderPath.split('/')
            
            item = self.GetRootItem()
            for folderName in folderTree:
                found = False
                for child in item.children():
                    if child.itemType == treeitems.FileItemType:
                        pass
                    else: # folder
                        if child.data() == folderName:
                            item = child
                            found = True
                            break
                    
            if found:
                return item
                
        return None

    def FindClosestFolder(self, x, y):
        item, flags = self.HitTest((x,y))
        if item:
            file = self.GetPyData(item)
            if file:
                item = self.GetItemParent(item)
                return item
            return item
        return None

    def GetSingleSelectItem(self):
        items = self.selection()
        if not items:
            return None
        return items[0]
        
    def copyToClipboard(self):
        """Copies the path to the file where the element is to the clipboard"""
        item = self.model().item(self.currentIndex())
        path = item.getPath()
        QApplication.clipboard().setText(path)

    @staticmethod
    def showParsingErrors(path):
        """Fires the show errors dialog window"""
        try:
            dialog = ParserErrorsDialog(path)
            dialog.exec_()
        except Exception as ex:
            logging.error(str(ex))

    def findInDirectory(self):
        """Find in directory popup menu handler"""
        index = self.currentIndex()
        searchDir = self.model().item(index).getPath()

        dlg = FindInFilesDialog(FindInFilesDialog.IN_DIRECTORY, "", searchDir)
        dlg.exec_()
        if dlg.searchResults:
            GlobalData().mainWindow.displayFindInFiles(
                FindInFilesSearchProvider().getName(),
                dlg.searchResults, dlg.getParameters())
                
    def add_progress_file(self, project_file):
        folderPath = project_file.logicalFolder
        if folderPath:
            self.AddFolder(folderPath)
            folder = self.FindFolder(folderPath)
        else:
            folder = self.GetRootItem()
        if not self.FindItem(project_file.filePath,folder):
            item = self.AppendItem(folder, os.path.basename(project_file.filePath), project_file)
        self.expand(self.source_model().buildIndex(folder.getRowPath()))
