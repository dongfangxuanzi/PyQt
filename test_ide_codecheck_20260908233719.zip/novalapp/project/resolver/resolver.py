import os
from . import xmlutils
from .const import PROJECT_VERSION_050826, PROJECT_VERSION_050730, PROJECT_VERSION_191025
from .model import KNOWNTYPES


def load(fileObject):
    version = xmlutils.getAgVersion(fileObject.name)
    # most current versions on top
    if version >= PROJECT_VERSION_050826:
        fileObject.seek(0)
        project = xmlutils.load(fileObject.name, knownTypes=KNOWNTYPES, knownNamespaces=xmlutils.KNOWN_NAMESPACES, createGenerics=True)
    elif version == PROJECT_VERSION_050730:
        fileObject.seek(0)
        project = xmlutils.load(fileObject.name, knownTypes={"project" : Project_10}, createGenerics=True)
        project = project.upgradeVersion()
    else:
        # assume it is old version without version number
        fileObject.seek(0)
        project = xmlutils.load(fileObject.name, knownTypes={"project" : Project_10}, createGenerics=True)
        if project:
            project = project.upgradeVersion()
        else:
           # print "Project, unknown version:", version
            return None

    if project:
        project._projectDir = os.path.dirname(fileObject.name)
        project.RelativeToAbsPath()
    return project


def save(fileObject, project, productionDeployment=False):
    if not project._projectDir:
        project._projectDir = os.path.dirname(fileObject.name)
    project.AbsToRelativePath()  # temporarily change it to relative paths for saving
    savedHomeDir = project.homeDir
    if productionDeployment:
        # for deployments, we don't want an abs path in homeDir since that
        # would tie the app to the current filesystem. So unset it.
        project.homeDir = None
    
    xmlutils.save(fileObject.name, project, prettyPrint=True, knownTypes=KNOWNTYPES, knownNamespaces=xmlutils.KNOWN_NAMESPACES)

    if productionDeployment:
        project.homeDir = savedHomeDir

    project.RelativeToAbsPath()  # swap it back to absolute path

