# -*- coding: utf-8 -*-
from noval import GetApp,_,core,constants
import os
import tkinter as tk
from tkinter import messagebox,filedialog
import noval.consts as consts
from tkinter import ttk
import noval.util.utils as utils
import noval.util.fileutils as fileutils
import noval.util.strutils as strutils
import noval.project.baseviewer as baseviewer
import noval.imageutils as imageutils
import noval.menu as tkmenu
import noval.misc as misc
import threading
from noval.project.command import ProjectAddProgressFilesCommand
from noval.python.parser.utils import py_cmp,py_sorted
import noval.terminal as terminal
import noval.project.property as projectproperty
import time
import noval.project.document as projectdocument
import noval.ui_utils as ui_utils
import noval.syntax.syntax as syntax
import noval.project.command as projectcommand
import noval.project.openwith as openwith

class EntryPopup(tk.Entry):

    def __init__(self, parent, text, item,**kw):
        ''' If relwidth is set, then width is ignored '''
        tk.Entry.__init__(self,parent, **kw)
        self.item = item

        self.insert(0, text) 
        self['readonlybackground'] = 'white'
        self['selectbackground'] = '#1BA1E2'
        self['exportselection'] = False

        self.focus_force()
        self.bind("<Control-a>", self.selectAll)
        self.bind("<Escape>", lambda *ignore: self.destroy())
        self.bind("<Return>",self.master.FinishLabel)
        self.selectAll()

    def selectAll(self, *ignore):
        ''' Set selection on the whole text '''
        self.selection_range(0, 'end')

        # returns 'break' to interrupt default key-bindings
        return 'break'



class BaseProjectbrowser(ttk.Frame):
    def __init__(
        self,
        master,
        columns=["#0", "kind", "path"],
        displaycolumns="#all",
        show_scrollbar=True,
        borderwidth=0,
        relief="flat",
        **tree_kw
    ):
        ttk.Frame.__init__(self, master, borderwidth=borderwidth, relief=relief)
        #文档和项目的对照表
        self._mapToProject = dict()
        #绑定ShowView事件,在事件中加载保存的历史项目列表
        GetApp().bind("ShowView", self.Show, True)
        # http://wiki.tcl.tk/44444#pagetoc50f90d9a
        self.vert_scrollbar = ttk.Scrollbar(
            self, orient=tk.VERTICAL, style=None
        )
        if show_scrollbar:
            self.vert_scrollbar.grid(row=1, column=1, sticky=tk.NSEW)
            
        self.project_combox = ttk.Combobox(self)
        self.project_combox.bind("<<ComboboxSelected>>",self.ProjectSelect)
        self.project_combox.grid(row=0, column=0, sticky=tk.NSEW)
        #设置combox只读不能编辑
        self.project_combox.state(['readonly'])
        self.tree = self.GetProjectTreectrl(**tree_kw)

        #控件默认会显示头部,此处用以屏蔽头部的显示
        self.tree.column("#0", anchor=tk.W, stretch=True)
        self.tree["show"] = ("tree",)
        self.tree.grid(row=1, column=0, sticky=tk.NSEW)
        self.vert_scrollbar["command"] = self.tree.yview
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        #鼠标双击Tree控件事件
        self.tree.bind("<Double-Button-1>", self.on_double_click, "+")
        self.tree.bind("<Return>",self.OnEnter)
        #展开节点时记住并保存子节点展开状态
        self.tree.bind("<<TreeviewOpen>>", self.OpenTreeItem)
        #软件启动时加载存储配置保存的历史项目列表,记住这个状态
        self._is_loading = False
        #创建项目视图,所有项目共享同一个视图,必须在函数的最后创建
        view = self.CreateView()
        self.SetView(view)
        self.GetView().AddProjectRoot(_("Projects"))
        GetApp().bind("InitTkDnd",self.SetDropTarget,True)
        self.tree.bind("<3>", self.on_secondary_click, True)
        self.tree.bind("<<TreeviewSelect>>", self._on_select, True)
        #加载默认过滤项目文件扩展名列表,刷新项目文件夹时使用
        self.filters = utils.profile_get("DEFAULT_FILE_FILTERS",syntax.SyntaxThemeManager().GetLexer(GetApp().GetDefaultLangId()).Exts)
        
    def SetDropTarget(self,event):
        #项目视图允许拖拽添加文件
        if GetApp().dnd is not None and utils.profile_get_int('ALLOW_DROP_OPENFILE',True):
            GetApp().dnd.bindtarget(self, baseviewer.ProjectFileDropTarget(self.GetView()), 'text/uri-list')
        
    def GetProjectTreectrl(self,**tree_kw):
        return ProjectTreeCtrl(self,
            yscrollcommand=self.vert_scrollbar.set,**tree_kw)
    
    def _on_select(self,event):
        #选中项目节点时设置项目视图为活跃视图
        GetApp().GetDocumentManager().ActivateView(self.GetView())

    def _clear_tree(self):
        for child_id in self.tree.get_children():
            self.tree.delete(child_id)

    def clear(self):
        self._clear_tree()            
            

        
    def OnEnter(self,event):
        if self.tree.is_edit_state:
            self.tree.FinishLabel(event)
            return
            
        self.OpenSelection()


                    
    def ChangeItemsImageWithFilename(self,parent_item,filename,template_icon):
        '''
            所有项目文件的文件名匹配的均批量修改图标
        '''
        if parent_item is None:
            return
        tree_ctrl = self.GetView()._treeCtrl
        childs = tree_ctrl.get_children(parent_item)
        for child_item in childs:
            if self.GetView()._IsItemFile(child_item):
                file_name = tree_ctrl.item(child_item,"text")
                #匹配文件名
                if file_name == filename:
                    tree_ctrl.item(child_item,image=template_icon)
            #递归更改图标
            self.ChangeItemsImageWithFilename(child_item,filename,template_icon)
        
    def ChangeItemsImageWithExtension(self,parent_item,extension,template_icon):
        '''
            所有项目文件的扩展名匹配的均批量修改图标
        '''
        if parent_item is None:
            return
        tree_ctrl = self.GetView()._treeCtrl
        childs = tree_ctrl.get_children(parent_item)
        for child_item in childs:
            if self.GetView()._IsItemFile(child_item):
                file_name = tree_ctrl.item(child_item,"text")
                #匹配扩展名
                if strutils.get_file_extension(file_name) == extension:
                    tree_ctrl.item(child_item,image=template_icon)
            #递归更改图标
            self.ChangeItemsImageWithExtension(child_item,extension,template_icon)
            
    def GetView(self):
        return self._view
        
    def CreateView(self):
        return baseviewer.ProjectView(self)
        
    def SetView(self,view):
        self._view = view
        
    def AddProject(self,name):
        if type(self.project_combox['values']) == str:
            self.project_combox['values'] = [name]
            return 0
        else:
            self.project_combox['values'] = self.project_combox['values'] + (name,)
            return len(self.project_combox['values']) - 1
            
    def LoadSavedProjects(self):
        self._is_loading = True
        openedDocs = False
        if utils.profile_get_int(consts.PROJECT_DOCS_SAVED_KEY, True):
            docList = utils.profile_get(consts.PROJECT_SAVE_DOCS_KEY,[])
            doc = None
            for fileName in docList:
                if isinstance(fileName, str) and \
                        strutils.get_file_extension(fileName) == consts.PROJECT_SHORT_EXTENSION:
                    if utils.is_py2():
                        fileName = fileName.decode("utf-8")
                    if os.path.exists(fileName):
                        doc = GetApp().GetDocumentManager().CreateDocument(fileName, core.DOC_SILENT|core.DOC_OPEN_ONCE)
                if doc:
                    openedDocs = True
        self._is_loading = False
        return openedDocs
        
    def SetCurrentProject(self):
        #如果是命令行打开项目,则设置该项目为当前项目
        open_project_path = GetApp().OpenProjectPath
        if open_project_path is not None:
            self.GetView().SetProject(open_project_path)
        #否则从存储配置中加载当前项目
        else:
            currProject = utils.profile_get(consts.CURRENT_PROJECT_KEY)
            docList = [document.GetFilename() for document in self.GetView().Documents]
            #从所有存储项目中查找是否存在当前项目,如果存在则加载为活跃项目
            if currProject in docList:
                self.GetView().SetProject(currProject)
          
    @property
    def IsLoading(self):
        return self._is_loading
        
    def SetFocus(self):
        self.focus_set()
        self.tree.focus_set()
        
    def ProjectSelect(self,event):
        self.GetView().ProjectSelect()
        
    def Show(self,event):
        if event.get('view_name') != consts.PROJECT_VIEW_NAME:
            utils.get_logger().info("project view could not handler view %s showview event",event.get('view_name'))
            return
        project = self.GetView().GetDocument()
        #加载存储项目
        if not project:
            self.LoadSavedProjects()
            
    def OpenTreeItem(self,event):
        #项目列表为空时不处理事件
        if self.GetView().GetDocument() == None:
            return
        self.GetView().SaveFolderState()
        


    def AddProjectMapping(self, key, projectDoc=None):
        """ 设置文档或者其他对象对应的项目
        """
        if not projectDoc:
            projectDoc = self.GetCurrentProject()
        self._mapToProject[key] = projectDoc


            
    def GetCurrentProject(self):
        view = self.GetView()
        if view:
            return view.GetDocument()
        return None


        


            

        
    def on_secondary_click(self, event):
        items = self.tree.selection()
        if not items:
            return
        if self.GetView()._HasFilesSelected():
            menu = self.GetPopupFileMenu(items[0])
        else:
            if not self.tree.parent(items[0]):
                menu = self.GetPopupProjectMenu(items[0])
            else:
                menu = self.GetPopupFolderMenu(items[0])
        menu["postcommand"] = lambda: menu._update_menu()
        menu.tk_popup(event.x_root, event.y_root)


            


    def GetItemPath(self,item):
        if self.GetView()._IsItemFile(item):
            filePath = self.GetView()._GetItemFilePath(item)
        else:
            document = self.GetCurrentProject()
            project_path = os.path.dirname(document.GetFilename())
            filePath = fileutils.opj(os.path.join(project_path,self.GetView()._GetItemFolderPath(item)))
        return filePath


        

        
    def SaveProjectConfig(self):
        return self.GetView().WriteProjectConfig()
        

        
    def GetReferenceProjects(self,doc_or_path,ensure_open=False):
        if isinstance(doc_or_path,str):
            doc = GetApp().GetDocumentManager().GetDocument(doc_or_path)
            if doc is None:
                return []
        else:
            doc = doc_or_path
        ref_project_names = utils.profile_get(doc.GetKey() + "/ReferenceProjects",[])
        if not ensure_open or not ref_project_names:
            return ref_project_names
        ref_docs = []
        for pj_doc in self.GetView().Documents:
            if pj_doc.GetFilename() in ref_project_names:
                ref_docs.append(pj_doc)
        return ref_docs
