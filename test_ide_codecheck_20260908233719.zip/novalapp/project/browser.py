# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""project viewer implementation"""

# pylint: disable=W0702
# pylint: disable=W0703
from .. import get_app,_
import os
import os.path
import logging
import shutil
from ..qtimage import load_icon
from ..util import fileutils,ui_utils,strutils,utils
from ..lib.docmanager import DOC_SILENT, DOC_OPEN_ONCE, DOC_NEW
from ..lib.pyqt import (QSize, Qt, QWidget, QVBoxLayout, QSplitter, QToolBar,
                 QAction, QToolButton, QSizePolicy, QDialog, QMenu,
                 QMessageBox, QCursor, pyqtSignal, QComboBox,QFileDialog,QDir,QUrl)
#from .projectproperties import ProjectPropertiesDialog
from .treeview.treectrl import ProjectTreeCtrl
from .treeview import treeitems
from .view import ProjectView,AddProjectMapping
from . import document as projectdocument
from . import ext
from .wizard.progressfiles import ImportProgressFiles
from ..widgets.labels import HeaderFitLabel
from .. import menuitems
from ..menubar import find_menu, NewQMenu
from .openwith import EditorSelectionDlg


class ProjectViewer(QWidget):

    """Project viewer widget"""

    sigFileUpdated = pyqtSignal(str, str)

    def __init__(self, parent):
        QWidget.__init__(self, parent)
        self._view = None
        #文档和项目的对照表
        self._mapToProject = dict()

        self.__mainWindow = parent

        self.__prjContextItem = None
        self.__prjContextMenu = None

        self.upper = self.__createProjectPartLayout()
        
        self.__createProjectPopupMenu()

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
   #     self.splitter = QSplitter(Qt.Vertical)
  #      self.splitter.addWidget(self.upper)
 #       self.splitter.setCollapsible(0, False)
#        self.splitter.setCollapsible(1, False)

        layout.addWidget(self.upper)
        self.setLayout(layout)


        self.__updatePrjToolbarButtons()
##
##        GlobalData().project.sigProjectChanged.connect(
##            self.__onProjectChanged)
##        GlobalData().project.sigRestoreProjectExpandedDirs.connect(
##            self.__onRestorePrjExpandedDirs)
##
##        # Support switching to debug and back
##        self.__mainWindow.debugModeChanged.connect(
##            self.projectTreeView.onDebugMode)
##        self.__mainWindow.debugModeChanged.connect(
##            self.filesystemView.onDebugMode)
##        self.__mainWindow.debugModeChanged.connect(self.onDebugMode)
##
##        # Plugin context menu support
##        self.__pluginFileMenus = {}
##        self.__pluginDirMenus = {}
##        GlobalData().pluginManager.sigPluginActivated.connect(
##            self.__onPluginActivated)
##        GlobalData().pluginManager.sigPluginDeactivated.connect(
##            self.__onPluginDeactivated)
##
##        # Keep the min and max height of the FS part initialized
##        self.__minH = self.lower.minimumHeight()
##        self.__maxH = self.lower.maximumHeight()
##        self.__splitterSizes = self.splitter.sizes()

        # Restoring of the lower part state via self.onShowHide(True)
        # is done in the codimension.py when the UI is already launched and
        # drawn. Otherwise the height is not calculated properly
        
        #软件启动时加载存储配置保存的历史项目列表,记住这个状态
        self.is_loading = False
        #创建项目视图,所有项目共享同一个视图,必须在函数的最后创建
        view = self.CreateView()
        self.SetView(view)
        self.GetView().AddProjectRoot(_("Projects"))
        
    def GetView(self):
        return self._view
        
    def CreateView(self):
        return ProjectView(self)
        
    def SetView(self,view):
        self._view = view
        
    def AddProject(self,name):
        self.project_combox.addItem(name)
        itemcount = self.project_combox.count()
        return itemcount -1

    def setTooltips(self, switchOn):
        """Triggers the tooltips mode"""
        self.projectTreeView.model().sourceModel().setTooltips(switchOn)
        self.filesystemView.model().sourceModel().setTooltips(switchOn)

    def __createProjectPartLayout(self):
        """Creates the upper part of the project viewer"""
        self.projectTreeView = ProjectTreeCtrl(self.__mainWindow)
        self.projectTreeView.setHeaderHidden(True)
        self.projectTreeView.doubleClicked.connect(self.on_double_click)

        # Header part: label + i-button
        self.project_combox = QComboBox(self)
        self.project_combox.setSizePolicy(QSizePolicy.Expanding,
                                        QSizePolicy.Fixed)
       # self.projectLabel.setMinimumWidth(10)

        self.propertiesButton = QToolButton(self)
        self.propertiesButton.setAutoRaise(True)
        self.propertiesButton.setIcon(load_icon('smalli.png'))
        self.propertiesButton.setFixedSize(self.project_combox.height(),
                                           self.project_combox.height())
        self.propertiesButton.setToolTip('Project properties')
        self.propertiesButton.setEnabled(False)
        self.propertiesButton.setFocusPolicy(Qt.NoFocus)
        self.propertiesButton.clicked.connect(self.projectProperties)

        self.unloadButton = QToolButton(self)
        self.unloadButton.setAutoRaise(True)
        self.unloadButton.setIcon(load_icon('unloadproject.png'))
        self.unloadButton.setFixedSize(self.project_combox.height(),
                                       self.project_combox.height())
        self.unloadButton.setToolTip('Unload project')
        self.unloadButton.setEnabled(False)
        self.unloadButton.setFocusPolicy(Qt.NoFocus)
        self.unloadButton.clicked.connect(self.unloadProject)

        self.prjHeaderToolbar = QToolBar(self)
        self.prjHeaderToolbar.setIconSize(QSize(18, 18))
        self.prjHeaderToolbar.setContentsMargins(1, 1, 1, 1)
        self.prjHeaderToolbar.addWidget(self.unloadButton)
        self.prjHeaderToolbar.addWidget(self.project_combox)
        self.prjHeaderToolbar.addWidget(self.propertiesButton)

        # Toolbar part - buttons
        self.prjFindWhereUsedButton = QAction(
            load_icon('findusage.png'),
            'Find where the highlighted item is used', self)
        self.prjFindWhereUsedButton.triggered.connect(self.__findWhereUsed)
        self.prjFindInDirButton = QAction(
            load_icon('findindir.png'), 'Find in highlighted directory', self)
        self.prjFindInDirButton.triggered.connect(
            self.projectTreeView.findInDirectory)
        self.prjShowParsingErrorsButton = QAction(
            load_icon('showparsingerrors.png'), 'Show lexer/parser errors', self)
        self.prjShowParsingErrorsButton.triggered.connect(
            self.showPrjParserError)
        self.prjNewDirButton = QAction(
            load_icon('newdir.png'), 'Create sub directory', self)
        self.prjNewDirButton.triggered.connect(self.__createDir)
        self.prjCopyToClipboardButton = QAction(
            load_icon('copymenu.png'), 'Copy path to clipboard', self)
        self.prjCopyToClipboardButton.triggered.connect(
            self.projectTreeView.copyToClipboard)

        self.upperToolbar = QToolBar()
        self.upperToolbar.setMovable(False)
        self.upperToolbar.setAllowedAreas(Qt.TopToolBarArea)
        self.upperToolbar.setIconSize(QSize(16, 16))
        self.upperToolbar.setContentsMargins(0, 0, 0, 0)
        self.upperToolbar.addAction(self.prjFindWhereUsedButton)
        self.upperToolbar.addAction(self.prjFindInDirButton)
        self.upperToolbar.addAction(self.prjShowParsingErrorsButton)
        self.upperToolbar.addAction(self.prjNewDirButton)
        self.upperToolbar.addAction(self.prjCopyToClipboardButton)

        self.projectTreeView.sigFirstSelectedItem.connect(
            self.__prjSelectionChanged)

        self.projectTreeView.setContextMenuPolicy(Qt.CustomContextMenu)
        self.projectTreeView.customContextMenuRequested.connect(
            self.__prjContextMenuRequested)
        pLayout = QVBoxLayout()
        pLayout.setContentsMargins(0, 0, 0, 0)
        pLayout.setSpacing(0)
        pLayout.addWidget(self.prjHeaderToolbar)
        pLayout.addWidget(self.upperToolbar)
        pLayout.addWidget(self.projectTreeView)

        upperContainer = QWidget()
        upperContainer.setContentsMargins(0, 0, 0, 0)
        upperContainer.setLayout(pLayout)
        return upperContainer

    def getProjectToolbar(self):
        """Provides a reference to the project toolbar"""
        return self.upperToolbar

    def __createProjectPopupMenu(self):
        """Generates the various popup menus for the project browser"""
        # popup menu for python files content
        self.prjPythonMenu = QMenu(self)
        self.prjUsageAct = self.prjPythonMenu.addAction(
            load_icon('findusage.png'), 'Find occurences', self.__findWhereUsed)
        self.prjPythonMenu.addSeparator()
        self.prjCopyAct = self.prjPythonMenu.addAction(
            load_icon('copymenu.png'),
            'Copy path to clipboard', self.projectTreeView.copyToClipboard)

##        # popup menu for directories
##        self.prjDirMenu = QMenu(self)
##        self.prjDirMenu.aboutToShow.connect(self.__updatePluginMenuData)
##        self.prjDirImportDgmAct = self.prjDirMenu.addAction(
##            getIcon('importsdiagram.png'),
##            "Imports diagram", self.__onImportDiagram)
##        self.prjDirImportDgmTunedAct = self.prjDirMenu.addAction(
##            getIcon('detailsdlg.png'),
##            'Fine tuned imports diagram', self.__onImportDgmTuned)
##        self.prjDirMenu.addSeparator()
##        self.prjDirNewDirAct = self.prjDirMenu.addAction(
##            getIcon('newdir.png'), 'Create nested directory', self.__createDir)
##        self.prjDirMenu.addSeparator()
##        self.prjDirFindAct = self.prjDirMenu.addAction(
##            getIcon('findindir.png'),
##            'Find in this directory', self.projectTreeView.findInDirectory)
##        self.prjDirCopyPathAct = self.prjDirMenu.addAction(
##            getIcon('copymenu.png'),
##            'Copy path to clipboard', self.projectTreeView.copyToClipboard)
##        self.prjDirMenu.addSeparator()
##        self.prjDirRemoveFromDiskAct = self.prjDirMenu.addAction(
##            getIcon('trash.png'),
##            'Remove directory from the disk recursively', self.__removePrj)
##        self.__prjDirPluginSeparator = self.prjDirMenu.addSeparator()
##        self.__prjDirPluginSeparator.setVisible(False)
##
##        # popup menu for files
##        self.prjFileMenu = QMenu(self)
##        self.prjFileMenu.aboutToShow.connect(self.__updatePluginMenuData)
##        self.prjFileImportDgmAct = self.prjFileMenu.addAction(
##            getIcon('importsdiagram.png'),
##            "Imports diagram", self.__onImportDiagram)
##        self.prjFileImportDgmTunedAct = self.prjFileMenu.addAction(
##            getIcon('detailsdlg.png'),
##            'Fine tuned imports diagram', self.__onImportDgmTuned)
##        self.prjFileMenu.addSeparator()
##        self.prjFileCopyPathAct = self.prjFileMenu.addAction(
##            getIcon('copymenu.png'),
##            'Copy path to clipboard', self.projectTreeView.copyToClipboard)
##        self.prjFileShowErrorsAct = self.prjFileMenu.addAction(
##            getIcon('showparsingerrors.png'),
##            'Show lexer/parser errors', self.showPrjParserError)
##        self.prjDisasmMenu = self.prjFileMenu.addMenu(
##            getIcon('disassembly.png'), 'Disassembly')
##        self.prjDisasmAct0 = self.prjDisasmMenu.addAction(
##            getIcon(''), 'Disassembly (no optimization)',
##            self.onPrjDisasm0)
##        self.prjDisasmAct1 = self.prjDisasmMenu.addAction(
##            getIcon(''), 'Disassembly (optimization level 1)',
##            self.onPrjDisasm1)
##        self.prjDisasmAct2 = self.prjDisasmMenu.addAction(
##            getIcon(''), 'Disassembly (optimization level 2)',
##            self.onPrjDisasm2)
##        self.prjFileMenu.addMenu(self.prjDisasmMenu)
##        self.prjDisasmPycAct = self.prjFileMenu.addAction(
##            getIcon('disassembly.png'), 'Disassembly .pyc',
##            self.onPrjDisasm0)
##        self.prjFileMenu.addSeparator()
##        self.prjFileRemoveFromDiskAct = self.prjFileMenu.addAction(
##            getIcon('trash.png'),
##            'Remove file from the disk', self.__removePrj)
##        self.__prjFilePluginSeparator = self.prjFileMenu.addSeparator()
##        self.__prjFilePluginSeparator.setVisible(False)
##
##        # Popup menu for broken symlinks
##        self.prjBrokenLinkMenu = QMenu(self)
##        self.prjBrokenLinkMenu.addAction(
##            getIcon('trash.png'),
##            'Remove broken link from the disk', self.__removePrj)



    def getFileSystemToolbar(self):
        """Provides a reference to the file system part toolbar"""
        return self.lowerToolbar

    @staticmethod
    def unloadProject():
        """Unloads the project"""
        # Check first if the project can be unloaded
        globalData = GlobalData()
        mainWindow = globalData.mainWindow
        editorsManager = mainWindow.editorsManagerWidget.editorsManager
        if editorsManager.closeRequest():
            globalData.project.tabsStatus = editorsManager.getTabsStatus()
            editorsManager.closeAll()
            globalData.project.fsBrowserExpandedDirs = \
                mainWindow.getProjectExpandedPaths()
            globalData.project.unloadProject()

    def __onRestorePrjExpandedDirs(self):
        """Triggered when a project tree should restore its previous state"""
        for path in GlobalData().project.fsBrowserExpandedDirs:
            self.projectTreeView.highlightItem(path)

    def __onProjectChanged(self, what):
        """Triggered when a signal comes"""
        if what != CodimensionProject.CompleteProject:
            return

        project = GlobalData().project
        if project.isLoaded():
            self.projectLabel.setText('Project: ' + project.getProjectName())
            self.propertiesButton.setEnabled(True)
            self.unloadButton.setEnabled(True)
        else:
            self.projectLabel.setText('Project: none')
            self.propertiesButton.setEnabled(False)
            self.unloadButton.setEnabled(False)
        self.filesystemView.layoutDisplay()
        self.projectTreeView.layoutDisplay()


        self.__prjContextItem = None

        self.__updateFSToolbarButtons()
        self.__updatePrjToolbarButtons()

    def projectProperties(self):
        """Triggered when the project properties button is clicked"""
        project = GlobalData().project
        dialog = ProjectPropertiesDialog(project, self)
        if dialog.exec_() == QDialog.Accepted:
            importDirs = []
            for index in range(dialog.importDirList.count()):
                importDirs.append(dialog.importDirList.item(index).text())

            scriptName = dialog.scriptEdit.text().strip()
            if scriptName != "":
                relativePath = os.path.relpath(scriptName,
                                               project.getProjectDir())
                if not relativePath.startswith('..'):
                    scriptName = relativePath

            mdDocFile = dialog.mdDocEdit.text().strip()
            if mdDocFile != '':
                relativePath = os.path.relpath(mdDocFile,
                                               project.getProjectDir())
                if not relativePath.startswith('..'):
                    mdDocFile = relativePath

            project.updateProperties(
                {'scriptname': scriptName,
                 'mddocfile': mdDocFile,
                 'creationdate': dialog.creationDateEdit.text().strip(),
                 'author': dialog.authorEdit.text().strip(),
                 'license': dialog.licenseEdit.text().strip(),
                 'copyright': dialog.copyrightEdit.text().strip(),
                 'version': dialog.versionEdit.text().strip(),
                 'email': dialog.emailEdit.text().strip(),
                 'description': dialog.descriptionEdit.toPlainText().strip(),
                 'uuid': dialog.uuidEdit.text().strip(),
                 'importdirs':  importDirs,
                 'encoding': dialog.encodingCombo.currentText().strip()})

            self.sigFileUpdated.emit(project.fileName, "")
            self.onFileUpdated(project.fileName, "")

    def __fsSelectionChanged(self, index):
        """Handles the changed selection in the FS browser"""
        if index.isValid():
            self.__fsContextItem = self.filesystemView.model().item(index)
        else:
            self.__fsContextItem = None
        self.__updateFSToolbarButtons()

    def __prjSelectionChanged(self, index):
        """Handles the changed selection in the project browser"""
        if index.isValid():
            self.__prjContextItem = self.projectTreeView.model().item(index)
        else:
            self.__prjContextItem = None
       # self.__updatePrjToolbarButtons()



    def __updatePrjToolbarButtons(self):
        """Updates the toolbar buttons depending on the __prjContextItem"""
        self.prjFindWhereUsedButton.setEnabled(False)
        self.prjFindInDirButton.setEnabled(False)
        self.prjShowParsingErrorsButton.setEnabled(False)
        self.prjNewDirButton.setEnabled(False)
        self.prjCopyToClipboardButton.setEnabled(False)
#        self.prjDelProjectDirButton.setEnabled(False)

        if self.__prjContextItem is None:
            return

        if self.__prjContextItem.itemType not in \
                    [NoItemType, SysPathItemType, GlobalsItemType,
                     ImportsItemType, FunctionsItemType,
                     ClassesItemType, StaticAttributesItemType,
                     InstanceAttributesItemType]:
            self.prjCopyToClipboardButton.setEnabled(True)

        if self.__prjContextItem.itemType == DirectoryItemType:
            self.prjFindInDirButton.setEnabled(True)
            self.prjNewDirButton.setEnabled(True)

            # if it is a top level and not the project file containing dir then
            # the del button should be enabled
            if self.__prjContextItem.parentItem.itemType == NoItemType:
                projectDir = os.path.dirname(GlobalData().project.fileName) + \
                             os.path.sep

        if self.__prjContextItem.itemType == FileItemType:
            if isPythonMime(self.__prjContextItem.fileType):
                self.prjShowParsingErrorsButton.setEnabled(
                    self.__prjContextItem.parsingErrors)

        if self.__prjContextItem.itemType in [FunctionItemType, ClassItemType,
                                              AttributeItemType,
                                              GlobalItemType]:
            self.prjFindWhereUsedButton.setEnabled(True)

    def create_context_menu(self):
        if self.__prjContextMenu is not None:
            self.__prjContextMenu.destroy()
            self.__prjContextMenu = None
        self.__prjContextMenu = NewQMenu(self)
            
    def popup_project_menu(self):
        self.create_context_menu()
      #  menu["postcommand"] = lambda: menu._update_menu()
        common_item_ids = self.GetPopupProjectItemIds()
        self.GetCommonItemsMenu(self.__prjContextMenu, common_item_ids)
        if self.GetCurrentProject() is not None:
            self.__prjContextMenu.InsertAfter(
                menuitems.ID_ADD_FOLDER,
                menuitems.ID_REFRESH_FOLDER,
                _("&Refresh folder"),
                img=get_app().GetImage("project/refresh.png"),
                handler=lambda:self.ProcessEvent(constants.ID_REFRESH_FOLDER)
            )
            self.__prjContextMenu.Append(
                menuitems.ID_RENAME,
                _("&Rename"),
                handler=lambda:self.ProcessEvent(constants.ID_RENAME)
            )
            self.__prjContextMenu.Append(
                menuitems.ID_OPEN_TERMINAL_PATH,
                _("Open Command Prompt here..."),
                handler=lambda:self.ProcessEvent(constants.ID_OPEN_TERMINAL_PATH)
            )
            self.__prjContextMenu.Append(
                menuitems.ID_COPY_PATH,
                _("Copy full path"),
                handler=lambda:self.ProcessEvent(constants.ID_COPY_PATH)
            )
        #GetApp().event_generate(constants.PROJECTVIEW_POPUP_ROOT_MENU_EVT,menu=menu,item=item)
        self.__prjContextMenu.popup(QCursor.pos())
        
    def GetPopupProjectItemIds(self):
        project_item_ids = [menuitems.ID_NEW_PROJECT,menuitems.ID_OPEN_PROJECT]
        if self.GetCurrentProject() is not None:
            project_item_ids.extend([
                    menuitems.ID_CLOSE_PROJECT,
                    menuitems.ID_SAVE_PROJECT, 
                    menuitems.ID_DELETE_PROJECT,
                    menuitems.ID_CLEAN_PROJECT,
                    menuitems.ID_ARCHIVE_PROJECT
                ]
            )
            project_item_ids.extend(
                [
                    None,
                    menuitems.ID_IMPORT_FILES,
                    menuitems.ID_ADD_FILES_TO_PROJECT,
                    menuitems.ID_ADD_DIR_FILES_TO_PROJECT,
                    None,
                    menuitems.ID_ADD_NEW_FILE,
                    menuitems.ID_ADD_FOLDER
                ]
            )
            project_item_ids.extend(
                [None, menuitems.ID_PROPERTIES,menuitems.ID_OPEN_FOLDER_PATH]
            )
        return project_item_ids
        
    def AppendFileFoderCommonMenu(self,menu):
        menu.add_separator()
        menu.Append(menuitems.ID_PROPERTIES,_("&Properties"),handler=lambda:self.ProcessEvent(menuitems.ID_PROPERTIES))
        menu.Append(menuitems.ID_OPEN_FOLDER_PATH,_("Open Path in Explorer"),handler=lambda:self.ProcessEvent(menuitems.ID_OPEN_FOLDER_PATH))
        menu.Append(menuitems.ID_OPEN_TERMINAL_PATH,_("Open Command Prompt here..."),handler=lambda:self.ProcessEvent(menuitems.ID_OPEN_TERMINAL_PATH))
        menu.Append(menuitems.ID_COPY_PATH,_("Copy Full Path"),handler=lambda:self.ProcessEvent(menuitems.ID_COPY_PATH))
        
    def popup_folder_menu(self):
        self.create_context_menu()
     #   menu["postcommand"] = lambda: menu._update_menu()
        common_item_ids = self.GetPopupFolderItemIds()
        self.GetCommonItemsMenu(self.__prjContextMenu,common_item_ids,is_folder=True)
        
        self.__prjContextMenu.Append(menuitems.ID_RENAME,_("&Rename"),handler=lambda:self.ProcessEvent(menuitems.ID_RENAME))
        self.__prjContextMenu.Append(menuitems.ID_REMOVE_FROM_PROJECT,_("Remove from Project"),handler=lambda:self.ProcessEvent(menuitems.ID_REMOVE_FROM_PROJECT))
        self.__prjContextMenu.InsertAfter(menuitems.ID_ADD_FOLDER,menuitems.ID_REFRESH_FOLDER,_("&Refresh folder"),handler=lambda:self.ProcessEvent(menuitems.ID_REFRESH_FOLDER),img=get_app().GetImage("project/refresh.png"))
       # GetApp().event_generate(constants.PROJECTVIEW_POPUP_FOLDER_MENU_EVT,menu=menu,item=item)
        self.AppendFileFoderCommonMenu(self.__prjContextMenu)
        self.__prjContextMenu.popup(QCursor.pos())
        
    def GetPopupFolderItemIds(self):
        folder_item_ids = [
            menuitems.ID_IMPORT_FILES,
            menuitems.ID_ADD_FILES_TO_PROJECT,
            menuitems.ID_ADD_DIR_FILES_TO_PROJECT,
            None,
            menuitems.ID_ADD_NEW_FILE,
            menuitems.ID_ADD_FOLDER,
            None,
            menuitems.ID_UNDO,
            menuitems.ID_REDO,
            menuitems.ID_CUT,
            menuitems.ID_COPY,
            menuitems.ID_PASTE,
            menuitems.ID_CLEAR,
            None
        ]
                                
        return folder_item_ids
        
    def popup_file_menu(self):
        self.create_context_menu()
        self.__prjContextMenu.Append(
            menuitems.ID_OPEN_SELECTION, 
            _("&Open"),
            handler=lambda:self.ProcessEvent(menuitems.ID_OPEN_SELECTION)
        )
        self.__prjContextMenu.Append(
            menuitems.ID_OPEN_SELECTION_WITH, 
            _("&Open With..."), 
            handler=lambda:self.ProcessEvent(menuitems.ID_OPEN_SELECTION_WITH)
        )
        common_item_ids = [
            None,
            menuitems.ID_UNDO,
            menuitems.ID_REDO,
            menuitems.ID_CUT,
            menuitems.ID_COPY,
            menuitems.ID_PASTE,
            menuitems.ID_CLEAR,
            None,
        ]
        self.GetCommonItemsMenu(self.__prjContextMenu,common_item_ids)
        
        self.__prjContextMenu.Append(menuitems.ID_RENAME,_("&Rename"),handler=lambda:self.ProcessEvent(menuitems.ID_RENAME))
        self.__prjContextMenu.Append(menuitems.ID_REMOVE_FROM_PROJECT,_("Remove from Project"),handler=lambda:self.ProcessEvent(menuitems.ID_REMOVE_FROM_PROJECT))
        #GetApp().event_generate(constants.PROJECTVIEW_POPUP_FILE_MENU_EVT,menu=menu,item=item)
        self.AppendFileFoderCommonMenu(self.__prjContextMenu)
        self.__prjContextMenu.popup(QCursor.pos())
        
    def GetCommonItemsMenu(self,menu, menu_item_ids,is_folder=False):
        project_menu = find_menu(_("&Project"),get_app().Menubar)
        edit_menu = find_menu(_("&Edit"),get_app().Menubar)
        for item_id in menu_item_ids:
            if item_id == None:
                menu.add_separator()
                continue
            menu_item = project_menu.FindMenuItem(item_id)
            if menu_item is not None:
                menu.AppendItem(menu_item)
                continue
            menu_item = edit_menu.FindMenuItem(item_id)
            menu.AppendItem(menu_item)

    def __prjContextMenuRequested(self, coord):
        """Triggered before the project context menu is shown"""
        index = self.projectTreeView.indexAt(coord)
        if not index.isValid():
            return

        # This will update the __prjContextItem
        self.__prjSelectionChanged(index)
        if self.__prjContextItem is None:
            return

        if self.__prjContextItem.itemType == treeitems.ProjectRootType:
            self.popup_project_menu()
        elif self.__prjContextItem.itemType == treeitems.FileItemType:
            self.popup_file_menu()
        elif self.__prjContextItem.itemType == treeitems.FolderItemType:
            self.popup_folder_menu()

    def GetFilesFromCurrentProject(self):
        view = self.GetView()
        if view:
            project = view.GetDocument()
            if project:
                return project.GetFiles()
        return None

    def __findWhereUsed(self):
        """Triggers analysis where the highlighted item is used"""
        if self.__prjContextItem is not None:
            GlobalData().mainWindow.findWhereUsed(
                self.__prjContextItem.getPath(),
                self.__prjContextItem.sourceObj)

    def __fsFindWhereUsed(self):
        """Triggers analysis where the FS highlighted item is used"""
        if self.__fsContextItem is not None:
            GlobalData().mainWindow.findWhereUsed(
                self.__fsContextItem.getPath(),
                self.__fsContextItem.sourceObj)

    def __createDir(self):
        """Triggered when a new subdir should be created"""
        if self.__isValidPrjItem(DirectoryItemType):
            dlg = NewProjectDirDialog(self)
            if dlg.exec_() == QDialog.Accepted:
                try:
                    os.mkdir(self.__prjContextItem.getPath() +
                             dlg.getDirName())
                except Exception as exc:
                    logging.error(str(exc))

    def __isValidPrjItem(self, itemType):
        """True if it is a valid project item"""
        if self.__prjContextItem is None:
            return False
        return self.__prjContextItem.itemType == itemType

    def __isValidPrjPythonFile(self):
        """True if it is a valid project python file item"""
        if self.__isValidPrjItem(FileItemType):
            if isPythonMime(self.__prjContextItem.fileType):
                return True
        return False

    def showPrjParserError(self):
        """Triggered when parsing errors must be displayed"""
        if self.__isValidPrjPythonFile():
            self.projectTreeView.showParsingErrors(
                self.__prjContextItem.getPath())

    def onDisasm(self, path, opt):
        """Disassemble a file"""
        if path.endswith('.pyc') or path.endswith('.pyo'):
            GlobalData().mainWindow.showPycDisassembly(path)
        else:
            GlobalData().mainWindow.showFileDisassembly(path, opt)

    def onPrjDisasm0(self):
        """Disassemble without optimization"""
        # This one is also called for .pyc files
        if self.__isValidPrjItem(FileItemType):
            if isPythonMime(self.__prjContextItem.fileType) or \
               isPythonCompiledFile(self.__prjContextItem.getPath()):
                self.onDisasm(self.__prjContextItem.getPath(),
                              OPT_NO_OPTIMIZATION)

    def onPrjDisasm1(self):
        """Disassemble with optimization level 1"""
        if self.__isValidPrjPythonFile():
            self.onDisasm(self.__prjContextItem.getPath(), OPT_OPTIMIZE_ASSERT)

    def onPrjDisasm2(self):
        """Disassemble with optimization level 2"""
        if self.__isValidPrjPythonFile():
            self.onDisasm(self.__prjContextItem.getPath(),
                          OPT_OPTIMIZE_DOCSTRINGS)

    def __isValidFsItem(self, itemType):
        """True if it is a valid filesystem item"""
        if self.__fsContextItem is None:
            return False
        return self.__fsContextItem.itemType == itemType

    def __isValidFsPythonFile(self):
        """True if it is a valid filesystem python file item"""
        if self.__isValidFsItem(FileItemType):
            if isPythonMime(self.__fsContextItem.fileType):
                return True
        return False

    def onFsDisasm0(self):
        """Disassemble without optimization"""
        # This one is also called for .pyc files
        if self.__isValidFsItem(FileItemType):
            if isPythonMime(self.__fsContextItem.fileType) or \
               isPythonCompiledFile(self.__fsContextItem.getPath()):
                self.onDisasm(self.__fsContextItem.getPath(),
                              OPT_NO_OPTIMIZATION)

    def onFsDisasm1(self):
        """Disassemble with optimization level 1"""
        if self.__isValidFsPythonFile():
            self.onDisasm(self.__fsContextItem.getPath(), OPT_OPTIMIZE_ASSERT)

    def onFsDisasm2(self):
        """Disassemble with optimization level 2"""
        if self.__isValidFsPythonFile():
            self.onDisasm(self.__fsContextItem.getPath(),
                          OPT_OPTIMIZE_DOCSTRINGS)

    def showFsParserError(self):
        """Triggered when parsing errors must be displayed"""
        if self.__isValidFsPythonFile():
            self.filesystemView.showParsingErrors(
                self.__fsContextItem.getPath())

    def addToplevelDir(self):
        """Triggered for adding a new top level directory"""
        self.filesystemView.addToplevelDir()
        self.__updateFSToolbarButtons()

    def removeToplevelDir(self):
        """Triggered for removing a top level directory"""
        self.filesystemView.removeToplevelDir()
        self.__updateFSToolbarButtons()

    def __removePrj(self):
        """Remove the selected item"""
        if self.__prjContextItem is not None:
            fName = self.__prjContextItem.getPath()
            if self.__removeItem(fName):
                GlobalData().mainWindow.recentProjectsViewer.removeRecentFile(
                    fName)

    def __removeFs(self):
        """Remove the selected item"""
        if self.__fsContextItem is not None:
            fName = self.__fsContextItem.getPath()
            if self.__removeItem(fName):
                # The item has really been deleted. Update the view
                dirname, basename = self.filesystemView._splitPath(fName)
                self.filesystemView._delFromTree(self.__fsContextItem,
                                                 dirname, basename)
                GlobalData().mainWindow.recentProjectsViewer.removeRecentFile(
                    fName)

    def __removeItem(self, path):
        """Removes a link, a file or a directory"""
        path = os.path.abspath(path)
        if os.path.islink(path):
            header = "Deleting a link"
            text = "Are you sure you want to delete the " \
                   "symbolic link <b>" + path + "</b>?"
        elif os.path.isdir(path):
            header = "Deleting a directory"
            text = "Are you sure you want to delete the " \
                   "directory <b>" + path + "</b> recursively?"
        else:
            header = "Deleting a file"
            text = "Are you sure you want to delete the " \
                   "file <b>" + path + "</b>?"

        res = QMessageBox.warning(self, header, text,
                                  QMessageBox.StandardButtons(
                                      QMessageBox.Cancel | QMessageBox.Yes),
                                  QMessageBox.Cancel)
        if res == QMessageBox.Yes:
            try:
                # Unfortunately, remote file system may fail to report that
                # something has been deleted. So let's check that the
                # requested item still exists
                if os.path.exists(path):
                    if os.path.islink(path):
                        os.remove(path)
                    elif os.path.isdir(path):
                        shutil.rmtree(path)
                    else:
                        os.remove(path)
                else:
                    logging.info("Could not find " + path +
                                 " on the disk. Ignoring and "
                                 "deleting from the browser.")
            except Exception as exc:
                logging.error(str(exc))
                return False
            return True
        return False

    @staticmethod
    def __canDeleteFile(path):
        """Returns True if the file can be deleted"""
        return GlobalData().project.fileName != os.path.realpath(path)

    @staticmethod
    def __canDeleteDir(path):
        """Returns True if the dir can be deleted"""
        path = os.path.realpath(path)
        if not path.endswith(os.path.sep):
            path += os.path.sep
        return not GlobalData().project.fileName.startswith(path)

    @staticmethod
    def __areTherePythonFiles(path):
        """Tests if a directory has at least one python file"""
        for item in os.listdir(path):
            if os.path.isdir(path + item):
                if ProjectViewer.__areTherePythonFiles(path + item +
                                                       os.path.sep):
                    return True
                continue
            if isPythonFile(path + item):
                return True
        return False

    def __onImportDiagram(self):
        """Triggered when an import diagram is requested"""
        if self.__prjContextItem is None:
            return

        if self.__prjContextItem.itemType == DirectoryItemType:
            # Check first if there are python files in it
            if not self.__areTherePythonFiles(self.__prjContextItem.getPath()):
                logging.warning("There are no python files in " +
                                self.__prjContextItem.getPath())
                return
            projectDir = GlobalData().project.getProjectDir()
            if projectDir == self.__prjContextItem.getPath():
                what = ImportsDiagramDialog.ProjectFiles
                tooltip = "Generated for the project"
            else:
                what = ImportsDiagramDialog.DirectoryFiles
                tooltip = "Generated for directory " + \
                          self.__prjContextItem.getPath()
            self.__generateImportDiagram(what, ImportDiagramOptions(),
                                         tooltip)
        else:
            self.__generateImportDiagram(ImportsDiagramDialog.SingleFile,
                                         ImportDiagramOptions(),
                                         "Generated for file " +
                                         self.__prjContextItem.getPath())

    def __onImportDgmTuned(self):
        """Triggered when a tuned import diagram is requested"""
        if self.__prjContextItem is None:
            return

        if self.__prjContextItem.itemType == DirectoryItemType:
            # Check first if there are python files in it
            if not self.__areTherePythonFiles(self.__prjContextItem.getPath()):
                logging.warning("There are no python files in " +
                                self.__prjContextItem.getPath())
                return

        if self.__prjContextItem.itemType == DirectoryItemType:
            projectDir = GlobalData().project.getProjectDir()
            if projectDir == self.__prjContextItem.getPath():
                what = ImportsDiagramDialog.ProjectFiles
                dlg = ImportsDiagramDialog(what, "", self)
                tooltip = "Generated for the project"
            else:
                what = ImportsDiagramDialog.DirectoryFiles
                dlg = ImportsDiagramDialog(what,
                                           self.__prjContextItem.getPath(),
                                           self)
                tooltip = "Generated for directory " + \
                          self.__prjContextItem.getPath()
        else:
            what = ImportsDiagramDialog.SingleFile
            dlg = ImportsDiagramDialog(what,
                                       self.__prjContextItem.getPath(),
                                       self)
            tooltip = "Generated for file " + self.__prjContextItem.getPath()

        if dlg.exec_() == QDialog.Accepted:
            self.__generateImportDiagram(what, dlg.options, tooltip)

    def __generateImportDiagram(self, what, options, tooltip):
        """Show the generation progress and display the diagram"""
        progressDlg = ImportsDiagramProgress(what, options,
                                             self.__prjContextItem.getPath())
        if progressDlg.exec_() == QDialog.Accepted:
            GlobalData().mainWindow.openDiagram(progressDlg.scene,
                                                tooltip)

    def onFileUpdated(self, fileName, uuid):
        """Triggered when the file is updated"""
        self.projectTreeView.onFileUpdated(fileName, uuid)
        self.__updatePrjToolbarButtons()
        self.filesystemView.onFileUpdated(fileName, uuid)
        self.__updateFSToolbarButtons()

    def onFileTypeChanged(self, fileName, uuid, newMime):
        """Triggered when the file type is changed"""
        self.projectTreeView.onFileTypeChanged(fileName, uuid, newMime)
        self.filesystemView.onFileTypeChanged(fileName, uuid, newMime)

    def onShowHide(self, startup=False):
        """Triggered when show/hide button is clicked"""
        if startup or self.filesystemView.isVisible():
            self.__minH = self.lower.minimumHeight()
            self.__maxH = self.lower.maximumHeight()
            self.__splitterSizes = self.splitter.sizes()

            self.filesystemView.setVisible(False)
            self.lowerToolbar.setVisible(False)
            self.__showHideButton.setIcon(getIcon('more.png'))
            self.__showHideButton.setToolTip('Show file system tree')

            self.lower.setMinimumHeight(self.fsHeaderToolbar.height())
            self.lower.setMaximumHeight(self.fsHeaderToolbar.height())

            Settings()['showFSViewer'] = False
        else:
            self.filesystemView.setVisible(True)
            self.lowerToolbar.setVisible(True)
            self.__showHideButton.setIcon(getIcon('less.png'))
            self.__showHideButton.setToolTip('Hide file system tree')

            self.lower.setMinimumHeight(self.__minH)
            self.lower.setMaximumHeight(self.__maxH)
            self.splitter.setSizes(self.__splitterSizes)

            Settings()['showFSViewer'] = True

    def highlightPrjItem(self, path):
        """Triggered when the file is to be highlighted in a project tree"""
        return self.projectTreeView.highlightItem(path)

    def highlightFSItem(self, path):
        """Triggered when the file is to be highlighted in the FS tree"""
        result = self.filesystemView.highlightItem(path)
        if result:
            # Found, so check if the panel is shown
            if not self.filesystemView.isVisible():
                self.onShowHide()
        return result

    def __onPluginActivated(self, plugin):
        """Triggered when a plugin is activated"""
        pluginName = plugin.getName()
        try:
            fMenu = QMenu(pluginName, self)
            plugin.getObject().populateFileContextMenu(fMenu)
            if fMenu.isEmpty():
                fMenu = None
            else:
                self.__pluginFileMenus[plugin.getPath()] = fMenu
                self.prjFileMenu.addMenu(fMenu)
                self.__prjFilePluginSeparator.setVisible(True)
                self.fsFileMenu.addMenu(fMenu)
                self.__fsFilePluginSeparator.setVisible(True)
        except Exception as exc:
            logging.error("Error populating " + pluginName +
                          " plugin file context menu: " +
                          str(exc) + ". Ignore and continue.")

        try:
            dMenu = QMenu(pluginName, self)
            plugin.getObject().populateDirectoryContextMenu(dMenu)
            if dMenu.isEmpty():
                dMenu = None
            else:
                self.__pluginDirMenus[plugin.getPath()] = dMenu
                self.prjDirMenu.addMenu(dMenu)
                self.__prjDirPluginSeparator.setVisible(True)
                self.fsDirMenu.addMenu(dMenu)
                self.__fsDirPluginSeparator.setVisible(True)
        except Exception as exc:
            logging.error("Error populating " + pluginName +
                          " plugin directory context menu: " +
                          str(exc) + ". Ignore and continue.")

    def __onPluginDeactivated(self, plugin):
        """Triggered when a plugin is deactivated"""
        try:
            path = plugin.getPath()
            if path in self.__pluginFileMenus:
                fMenu = self.__pluginFileMenus[path]
                del self.__pluginFileMenus[path]
                self.prjFileMenu.removeAction(fMenu.menuAction())
                pluginMenuCount = len(self.__pluginFileMenus)
                self.__prjFilePluginSeparator.setVisible(pluginMenuCount > 0)
                self.fsFileMenu.removeAction(fMenu.menuAction())
                self.__fsFilePluginSeparator.setVisible(pluginMenuCount > 0)
                fMenu = None
        except Exception as exc:
            pluginName = plugin.getName()
            logging.error("Error removing " + pluginName +
                          " plugin file context menu: " +
                          str(exc) + ". Ignore and continue.")

        try:
            path = plugin.getPath()
            if path in self.__pluginDirMenus:
                dMenu = self.__pluginDirMenus[path]
                del self.__pluginDirMenus[path]
                self.prjDirMenu.removeAction(dMenu.menuAction())
                dirMenuCount = len(self.__pluginDirMenus)
                self.__prjDirPluginSeparator.setVisible(dirMenuCount > 0)
                self.fsDirMenu.removeAction(dMenu.menuAction())
                self.__fsDirPluginSeparator.setVisible(dirMenuCount > 0)
                dMenu = None
        except Exception as exc:
            pluginName = plugin.getName()
            logging.error("Error removing " + pluginName +
                          " plugin directory context menu: " +
                          str(exc) + ". Ignore and continue.")

    def __updatePluginMenuData(self):
        """Triggered when a file or dir menu is about to show"""
        if self.projectTreeView.hasFocus():
            value = self.__prjContextItem.getPath()
        else:
            value = self.__fsContextItem.getPath()

        for path in self.__pluginFileMenus:
            menu = self.__pluginFileMenus[path]
            menu.menuAction().setData(value)
        for path in self.__pluginDirMenus:
            menu = self.__pluginDirMenus[path]
            menu.menuAction().setData(value)

    def onDebugMode(self, newState):
        """Triggered when a debug mode is changed"""
        self.unloadButton.setEnabled(GlobalData().project.isLoaded() and
                                     not newState)


    def on_double_click(self, model_index):
        if not model_index.isValid():
            return
        item = self.projectTreeView.model().item(model_index)
        self.OpenSelection(item)
        
    def OpenSelection(self, treeitem):
        doc = None
        try:
           # filepath = self.GetView()._GetItemFilePath(item)
            #项目文件的打开方式模板
            file_template = None
            if treeitem.itemType == treeitems.FileItemType:
                filepath = treeitem.path
                #标准化文件路径
                filepath = fileutils.opj(filepath)
                if not os.path.exists(filepath):
                    msgTitle = get_app().GetAppName()
                    if not msgTitle:
                        msgTitle = _("File Not Found")
                    ret = QMessageBox.question(
                        self,
                        msgTitle,
                        _("The file '%s' was not found in '%s'.\n\nWould you like to browse for the file?") \
                                        % (fileutils.get_filename_from_path(filepath), fileutils.get_filepath_from_path(filepath)),
                         QMessageBox.Yes|QMessageBox.No
                    )
                    #选中否
                    if ret == QMessageBox.No:
                        return
##                    newpath = filedialog.askopenfilename(
##                            master=self,
##                           ### filetypes=descrs,
##                            initialdir=os.getcwd(),
##                            title = _("Choose a file"),
##                            initialfile = fileutils.get_filename_from_path(filepath)
##                    )
                    options = QFileDialog.Options()
                    options |= QFileDialog.DontUseNativeDialog
                    newpath, _f = QFileDialog.getOpenFileName(
                        self,
                        _("Choose a file"),
                        None,
                        options=options
                    )
                    if newpath:
                        # update Project Model with new location
                        self.GetView().GetDocument().UpdateFilePath(filepath, newpath)
                        filepath = newpath
                    else:
                        #选择取消按钮
                        return
                else:        
                    project_file = self.GetItemFile(filepath)
                    #获取项目文件的打开方式模板
                    file_template = self.GetView().GetOpenDocumentTemplate(project_file)
                #如果存在项目文件的打开方式模板,则以打开方式模板打开项目文件
                if file_template:
                    doc = get_app().GetDocumentManager().CreateTemplateDocument(file_template,filepath, DOC_SILENT|DOC_OPEN_ONCE)
                    docs = [doc]
                #否则以扩展名默认模板打开项目文件
                else:
                    docs = get_app().GetDocumentManager().CreateDocument(filepath, DOC_SILENT|DOC_OPEN_ONCE)
                if not docs and filepath.endswith(ext.PROJECT_EXTENSION):  # project already open
                    self.SetProject(filepath)
                elif docs:
                    AddProjectMapping(docs[0])
                    #检查文件扩展名是否有对应的文件扩展插件
                    #ui_utils.CheckFileExtension(filepath,False)
        except IOError as e:
            msgTitle = wx.GetApp().GetAppName()
            if not msgTitle:
                msgTitle = _("File Error")
            wx.MessageBox("Could not open '%s'." % wx.lib.docview.FileNameFromPath(filepath),
                          msgTitle,
                          wx.OK | wx.ICON_EXCLAMATION,
                          self.GetFrame())
                          
    def OpenSelectionWith(self, treeitem):
        '''
            用户选择打开方式来打开项目文件
        '''
        selected_file_path = treeitem.path
        item_file = self.GetItemFile(selected_file_path)
        dlg = EditorSelectionDlg(get_app().GetTopWindow(),item_file,self.GetView().GetDocument())
        if dlg.exec_() == EditorSelectionDlg.Accepted:
            found_doc = get_app().GetDocumentManager().GetDocument(selected_file_path)
            if found_doc:
                ret = messagebox.askyesno(get_app().GetAppName(),_("The document \"%s\" is already open,Do you want to close it?") %selected_file_path)
                if ret == True:
                    found_view = found_doc.GetFirstView()
                    found_view.Close()
                    if found_doc in GetApp().GetDocumentManager().GetDocuments():
                        found_doc.Destroy()
                    frame = found_view.GetFrame()
                    if frame:
                        frame.Destroy()
                else:
                    return
            doc = get_app().GetDocumentManager().CreateTemplateDocument(dlg.selected_template,selected_file_path, DOC_SILENT)
            #用户更改了打开方式
            if doc is not None and dlg._is_changed and get_app().GetDocumentManager().GetDocument(selected_file_path):
                #打开方式的模板图标
                template_icon = dlg.selected_template.GetIcon()
                if dlg.Openwith == dlg.OPEN_WITH_PATH:
                    utils.profile_set(self.GetView().GetDocument().GetFileKey(item_file,"Open"),dlg.selected_template.GetDocumentName())
                    file_template = get_app().GetDocumentManager().FindTemplateForPath(selected_file_path)
                    if file_template != dlg.selected_template:
                        if template_icon is not None:
                            #更改文件item的模板图标
                            treeitem.setIcon(template_icon)
                #以所有文件名方式打开
                elif dlg.Openwith == dlg.OPEN_WITH_NAME:
                    filename = os.path.basename(selected_file_path)
                    #保存文件名对应的模板
                    utils.profile_set("Open/filenames/%s" % filename,dlg.selected_template.GetDocumentName())
                    if template_icon is not None:
                        #批量更改所有文件名的图标
                        self.ChangeItemsImageWithFilename(self.GetView()._treeCtrl.GetRootItem(),filename,template_icon)
                #以所有扩展名方式打开
                elif dlg.Openwith == dlg.OPEN_WITH_EXTENSION:
                    extension = strutils.get_file_extension(os.path.basename(selected_file_path))
                    #保存扩展名对应的模板
                    utils.profile_set("Open/extensions/%s" % extension,dlg.selected_template.GetDocumentName())
                    if template_icon is not None:
                        #批量更改所有扩展名的图标
                        self.ChangeItemsImageWithExtension(self.GetView()._treeCtrl.GetRootItem(),extension,template_icon)
                else:
                    assert(False)
                    
    def GetItemFile(self, file_path):
        return self.GetView().GetDocument().GetModel().FindFile(file_path)
        
    def FindProjectByFile(self, filename):
        '''查找包含文件的所有项目文档,当前项目文档放在第一位'''
        retval = []
        for document in get_app().GetDocumentManager().GetDocuments():
            #文档类型为项目文档
            if isinstance(document.GetDocumentTemplate(), projectdocument.ProjectDocument):
                if document.GetFilename() == filename:
                    retval.append(document)
                #项目文档是否包含该文件
                elif document.IsFileInProject(filename):
                    retval.append(document)
                    
        #将当前项目置于第一位
        currProject = self.GetCurrentProject()
        if currProject and currProject in retval:
            retval.remove(currProject)
            retval.insert(0, currProject)
                
        return retval
        
    def GetCurrentProject(self):
        view = self.GetView()
        if view:
            return view.GetDocument()
        return None
        

    def AddProjectMapping(self, key, projectDoc=None):
        """ 设置文档或者其他对象对应的项目
        """
        if not projectDoc:
            projectDoc = self.GetCurrentProject()
        self._mapToProject[key] = projectDoc
        
    def _InitCommands(self):
        project_menu = find_menu(_("&Project"), get_app().Menubar)
        get_app().AddCommand(menuitems.ID_NEW_PROJECT,project_menu,_("New Project"),self.NewProject,image="project/new.png")
        get_app().AddCommand(menuitems.ID_OPEN_PROJECT,project_menu,_("Open Project"),self.OpenProject,image="project/open.png")
        get_app().AddCommand(
            menuitems.ID_CLOSE_PROJECT,
            project_menu,
            _("Close Project"),
            self.CloseProject,
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_CLOSE_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_SAVE_PROJECT,
            project_menu,
            _("Save Project"),
            self.SaveProject,
            image="project/save.png",
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_SAVE_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_DELETE_PROJECT,
            project_menu,
            _("Delete Project"),
            self.DeleteProject,
            image="project/trash.png",
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_DELETE_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_CLEAN_PROJECT,
            project_menu,
            _("Clean Project"),
            self.CleanProject,
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_CLEAN_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_ARCHIVE_PROJECT,
            project_menu,
            _("Archive Project"),
            self.ArchiveProject,
            image="project/archive.png",
            add_separator=True,
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_ARCHIVE_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_IMPORT_FILES,
            project_menu,
            _("Import Files..."),
            image="project/import.png",
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_IMPORT_FILES),
            handler=lambda:self.ProcessEvent(menuitems.ID_IMPORT_FILES)
        )
        get_app().AddCommand(
            menuitems.ID_ADD_FILES_TO_PROJECT,
            project_menu,
            _("Add &Files to Project..."),
            handler=lambda:self.ProcessEvent(constants.ID_ADD_FILES_TO_PROJECT),
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_ADD_FILES_TO_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_ADD_DIR_FILES_TO_PROJECT,
            project_menu,
            _("Add Directory Files to Project..."),
            handler=lambda:self.ProcessEvent(constants.ID_ADD_DIR_FILES_TO_PROJECT),
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_ADD_DIR_FILES_TO_PROJECT)
        )
        get_app().AddCommand(
            menuitems.ID_ADD_CURRENT_FILE_TO_PROJECT,
            project_menu,
            _("&Add Active File to Project..."),
            handler=lambda:self.ProcessEvent(constants.ID_ADD_CURRENT_FILE_TO_PROJECT),
            add_separator=True,
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_ADD_CURRENT_FILE_TO_PROJECT)
        )
        
        get_app().AddCommand(
            menuitems.ID_ADD_NEW_FILE,
            project_menu,
            _("New File"),
            image="project/new_file.png",
            handler=lambda:self.ProcessEvent(constants.ID_ADD_NEW_FILE),
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_ADD_NEW_FILE)
        )
        get_app().AddCommand(
            menuitems.ID_ADD_FOLDER,
            project_menu,_("New Folder"),
            image="project/folder.png",
            handler=lambda:self.ProcessEvent(constants.ID_ADD_FOLDER),
            add_separator=True,
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_ADD_FOLDER)
        )
        
        get_app().AddCommand(
            menuitems.ID_PROPERTIES,
            project_menu,
            _("Project Properties"),
            self.OnProjectProperties,
            image="project/properties.png",
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_PROPERTIES)
        )
        get_app().AddCommand(
            menuitems.ID_OPEN_FOLDER_PATH,
            project_menu,
            _("Open Project Path in Explorer"),
            handler=self.OpenProjectPath,
            tester=lambda:self.GetView().UpdateUI(menuitems.ID_OPEN_FOLDER_PATH)
        )

    def NewProject(self):
        '''
            新建项目
        '''
        template = get_app().GetDocumentManager().FindTemplateForTestPath(ext.PROJECT_EXTENSION)
        template.CreateDocument("", flags = DOC_NEW)
    
    def OpenProject(self):
        '''
            打开项目
        '''
        dialog = QFileDialog(self, _('Open project'))
        dialog.setFileMode(QFileDialog.ExistingFile)
        dialog.setOption(QFileDialog.DontUseNativeDialog, True)
        
        template = get_app().GetDocumentManager().FindTemplateForTestPath(ext.PROJECT_EXTENSION)
        descr = strutils.get_template_filter(template)
        dialog.setNameFilter(descr)
        urls = []
        for dname in QDir.drives():
            urls.append(QUrl.fromLocalFile(dname.absoluteFilePath()))
        urls.append(QUrl.fromLocalFile(QDir.homePath()))
        dialog.setDirectory(QDir.homePath())
        dialog.setSidebarUrls(urls)
        if dialog.exec_() != QDialog.Accepted:
            return

        fileNames = dialog.selectedFiles()
        fileName = os.path.realpath(str(fileNames[0]))
        project_path = fileutils.opj(fileName)
        current_project  = self.GetCurrentProject()
        if current_project is not None and project_path == current_project.GetFilename():
            logging.warning("The selected project to load is "
                            "the currently loaded one.")
            return

        self.GetView().OpenProject(project_path)
          
    @ui_utils.update_toolbar  
    def CloseProject(self):
        self.GetView().CloseProject()
        
    @ui_utils.update_toolbar
    def SaveProject(self):
        self.GetView().SaveProject()
        
    @ui_utils.update_toolbar
    def DeleteProject(self):
        self.GetView().DeleteProject()

    def ArchiveProject(self):
        self.GetView().ArchiveProject()

    def CleanProject(self):
        self.GetView().CleanProject()
        
    def OnProjectProperties(self,item_name=None):
        projectproperty.PropertiesService().ShowPropertyDialog(self.tree.GetRootItem(),option_name=item_name)
        
    def OpenProjectPath(self):
        document = self.GetCurrentProject()
        fileutils.safe_open_file_directory(document.GetFilename())
        
    def GetOpenProjects(self):
        return self.GetView().Documents
        
    def copyfiles_to_project(self,progress_ui,file_list,src_path,dest_path):
     #   self.projectTreeView.GetRootItem().setExpanded(True)
        copy_thread = ImportProgressFiles(self, progress_ui,file_list,src_path,dest_path)
        copy_thread.start()
        
    def FindProjectFromMapping(self, key):
        """ 从对照表中快速查找文档对应的项目"""
        return self._mapToProject.get(key,None)
        
    def ProcessEvent(self, id):
        view = self.GetView()
        if id == menuitems.ID_ADD_FILES_TO_PROJECT:
            view.OnAddFileToProject()
            return True
        elif id == menuitems.ID_ADD_DIR_FILES_TO_PROJECT:
            view.OnAddDirToProject()
            return True
        elif id == menuitems.ID_ADD_CURRENT_FILE_TO_PROJECT:
            view.OnAddCurrentFileToProject()
            return True
        elif id == menuitems.ID_ADD_NEW_FILE:
            view.OnAddNewFile()
            return True
        elif id == menuitems.ID_ADD_FOLDER:
            view.OnAddFolder()
            return True
        elif id == menuitems.ID_RENAME:
            view.OnRename()
            return True
        elif id == menuitems.ID_CLEAR:
            view.DeleteFromProject()
            return True
        elif id == menuitems.ID_DELETE_PROJECT:
            self.OnDeleteProject(event)
            return True
        elif id == menuitems.ID_CUT:
            view.OnCut()
            return True
        elif id == menuitems.ID_COPY:
            view.OnCopy()
            return True
        elif id == menuitems.ID_PASTE:
            view.OnPaste()
            return True
        elif id == menuitems.ID_REMOVE_FROM_PROJECT:
            view.RemoveFromProject()
            return True
        elif id == menuitems.ID_SELECTALL:
            self.OnSelectAll(event)
            return True
        elif id == menuitems.ID_OPEN_SELECTION:
            self.OpenSelection(self.__prjContextItem)
            return True
        elif id == menuitems.ID_OPEN_SELECTION_WITH:
            self.OpenSelectionWith(self.__prjContextItem)
            return True
        elif id == menuitems.ID_PROPERTIES:
            self.OnProperties()
            return True
        elif id == menuitems.ID_IMPORT_FILES:
            view.ImportFilesToProject()
            return True
        elif id == menuitems.ID_OPEN_FOLDER_PATH:
            self.OpenFolderPath()
            return True
        elif id == menuitems.ID_OPEN_TERMINAL_PATH:
            self.OpenPromptPath()
            return True
        elif id == menuitems.ID_COPY_PATH:
            self.CopyPath()
            return True
        elif id == menuitems.ID_REFRESH_FOLDER:
            self.Refresh()
        else:
            return False
            

    def Refresh(self):
        item = self.tree.GetSingleSelectItem()
        filePath = self.GetItemPath(item)
        self.RefreshPath(filePath)
        
    def RefreshPath(self,path):
        '''
            刷新文件夹添加新文件
        '''
        add_count = 0
        doc = self.GetCurrentProject()
        item = self.tree.GetSingleSelectItem()
        folderPath = self.GetView()._GetItemFolderPath(item)
        try:
            #扫描文件夹下的新文件
            for l in os.listdir(path):
                file_path = os.path.join(path,l)
                if fileutils.is_file_path_hidden(file_path):
                    continue
                if os.path.isfile(file_path) and strutils.get_file_extension(l) in self.filters:
                    if not doc.GetModel().FindFile(file_path):
                        add_count += 1
                        doc.GetCommandProcessor().Submit(projectcommand.ProjectAddFilesCommand(doc, [file_path], folderPath=folderPath))
                elif os.path.isdir(file_path):
                    if folderPath:
                        child_folderPath = folderPath + "/" + l
                    else:
                        child_folderPath = l
                    folder = self.GetView()._treeCtrl.FindFolder(child_folderPath)
                    if not folder:
                        #空文件夹下创建一个虚拟文件,防止空文件夹节点被删除
                        doc.GetCommandProcessor().Submit(projectcommand.ProjectAddFolderCommand(self.GetView(), doc, child_folderPath))
                        dummy_file = os.path.join(file_path,consts.DUMMY_NODE_TEXT)
                        doc.GetCommandProcessor().Submit(projectcommand.ProjectAddFilesCommand(doc,[dummy_file],folderPath=folderPath))
        except Exception as e:
            messagebox.showerror(GetApp().GetAppName(),str(e))
            return
            
        #检查节点文件或文件夹是否存在
        for child in self.GetView()._treeCtrl.get_children(item):
            item_path = self.GetItemPath(child)
            if not os.path.exists(item_path):
                self.GetView()._treeCtrl.delete(child)
                doc.GetCommandProcessor().Submit(projectcommand.ProjectRemoveFilesCommand(doc, [item_path]))
        if 0 == add_count:
            messagebox.showinfo(GetApp().GetAppName(),_("there is not files to add"))
        else:
            messagebox.showinfo(GetApp().GetAppName(),_("total add %d files to project")%add_count)
        
            
    def OnProperties(self):
        projectproperty.PropertiesService().ShowPropertyDialog(self.tree.GetSingleSelectItem())

    def OnProjectProperties(self,item_name=None):
        projectproperty.PropertiesService().ShowPropertyDialog(self.tree.GetRootItem(),option_name=item_name)
            
    def OpenProjectPath(self):
        document = self.GetCurrentProject()
        fileutils.safe_open_file_directory(document.GetFilename())
        
    def OpenFolderPath(self):
        document = self.GetCurrentProject()
        project_path = os.path.dirname(document.GetFilename())
        item = self.tree.GetSingleSelectItem()
        filePath = self.GetItemPath(item)
        fileutils.safe_open_file_directory(filePath)
        
    def OpenPromptPath(self):
        item = self.tree.GetSingleSelectItem()
        filePath = self.GetItemPath(item)
        GetApp().OpenTerminator(filename=filePath)
            
    def CopyPath(self):
        document = self.GetCurrentProject()
        item = self.tree.GetSingleSelectItem()
        filePath = self.GetItemPath(item)
        utils.CopyToClipboard(filePath)
        
    def RemoveProjectMapping(self, key):
        """ Remove mapping from model or document to project.  """
        if key in self._mapToProject:
            del self._mapToProject[key]