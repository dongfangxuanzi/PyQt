
def calc_version_value(ver_str="0.0.0"):
    """Calculates a version value from the provided dot-formated string

    1) SPECIFICATION: Version value calculation AA.BBB.CCC
         - major values: < 1     (i.e 0.0.85 = 0.850)
         - minor values: 1 - 999 (i.e 0.1.85 = 1.850)
         - micro values: >= 1000 (i.e 1.1.85 = 1001.850)

    @keyword ver_str: Version string to calculate value of

    """
    ver_str = ''.join([char for char in ver_str
                       if char.isdigit() or char == '.'])
    ver_lvl = ver_str.split(u".")
    if len(ver_lvl) < 3:
        return 0

    major = int(ver_lvl[0]) * 1000
    minor = int(ver_lvl[1])
    if len(ver_lvl[2]) <= 2:
        ver_lvl[2] += u'0'
    micro = float(ver_lvl[2]) / 1000
    return float(major) + float(minor) + micro

def compare_common_version(new_version,old_version):
    '''
        比较通用版本号大小,如果新版本号大于旧版本号返回1,否则返回0,返回0才正常,返回1需要更新
    '''
    def format_version_str(version_str):
        '''
            标准化版本字符串,至少包含3个点.如果是类似x.x的版本则转换为x.x.0之类的
        '''
        if len(version_str.split('.')) == 2:
            version_str += ".0"
        return version_str

    new_version = format_version_str(new_version)
    old_version = format_version_str(old_version)
    if calc_version_value(new_version) <= calc_version_value(old_version):
        return 0
    return 1