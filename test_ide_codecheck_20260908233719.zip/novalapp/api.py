from .util import urlutils

class ApiServer:
    ###HOST_SERVER_ADDR = 'http://127.0.0.1:8000'
    HOST_SERVER_ADDR = 'http://www.novalide.com'
    ####HOST_SERVER_ADDR = 'http://47.105.90.123:8080/'
    
    def __init__(self):
        self.root_addr = self.HOST_SERVER_ADDR
        
    def api_root_addr(self):
        api_addr = f'{self.root_addr}/api/'
        return api_addr
        
    def get_api_addr(self, addr):
        if addr.startswith('/'):
            addr = addr.lstrip('/')
        return self.api_root_addr() + addr
        
    def request_addr(self, addr, arg={}, method='get'):
        api_addr = self.get_api_addr(addr)
        return urlutils.request_data(api_addr, arg, method)