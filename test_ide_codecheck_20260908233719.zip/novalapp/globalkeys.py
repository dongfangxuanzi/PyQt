CHECK_UPDATE_ATSTARTUP_KEY = "CheckUpdateAtStartup"
DEFAULT_FILE_ENCODING_KEY = "DefaultFileEncoding"
REMBER_FILE_KEY = "RemberFile"
DEFAULT_DOCUMENT_TYPE_KEY = "DefaultDocumentType"
EDITOR_FONT_FAMILY_KEY =  "EditorFontFamily"
EDITOR_FONT_SIZE_KEY = "EditorFontSize"
IO_FONT_FAMILY_KEY =  "IoFontFamily"
SYNTAX_THEME_KEY = "SyntaxThemeName"
FRAME_MAXIMIZED_KEY = "MDIFrameMaximized"
#MDIFrame key表示主界面的坐标以及宽高
FRAME_TOP_LOC_KEY = "MDIFrameTopLoc"
FRAME_LEFT_LOC_KEY = "MDIFrameLeftLoc"
FRAME_WIDTH_KEY = "MDIFrameWidth"
FRAME_HEIGHT_KEY = "MDIFrameHeight"

FRAME_VIEW_MINIMIZED_KEY = "%sViewActived"
TOOLBAR_VISIBLE_KEY = "toolbarVisible"
STATUS_VISIBLE_KEY = "statusbarVisible"
RECENT_FILES_KEY = "RecentFiles"
RECENT_PROJECTS_KEY = "RecentProjects"
CURRENT_PROJECT_KEY = "ProjectCurrent"
PROJECT_DOCS_SAVED_KEY = "IsProjectSaveDocs"
PROJECT_SAVE_DOCS_KEY  = "ProjectSavedDocs"
ENABLE_MRU_KEY = "EnableMRU"
MRU_LENGTH_KEY = "MRULength"
LANGUANGE_ID_KEY = "LanguageId"
CHECK_FILE_MODIFY_KEY = "CheckFileModify"
SHOW_WELCOME_PAGE_KEY = 'ShowWelcomePage'
RECENTPROJECT_LENGTH_KEY = "RecentProjectLength"

REDIRECT_APP_EXCEPTION = "RedirectAppException"

APP_SKIN_KEY = 'AppSkin'

PROJECT_DIRECTORY_KEY = "NewProjectDirectory"