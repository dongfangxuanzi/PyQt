import os
from ..util import utils, strutils
import sys
import importlib
from .syntax import SYNATAX_MANAGER
from ..lib.template import DocTemplate
#import noval.imageutils as imageutils

class LexerFactory:
    """description of class"""
    
    @staticmethod
    def CreateLexers(lang=""):
        app_dir = "novalapp"
        if lang == "":
            lexer_path = os.path.join(utils.get_app_path(),app_dir,"syntax","lexer")
        else:
            lexer_path = os.path.join(utils.get_app_path(),app_dir,lang,"syntax","lexer")
        sys.path.append(lexer_path)
        for fname in os.listdir(lexer_path):
            if not fname.endswith(".py"):
                continue
            modname = strutils.get_filename_without_ext(fname)
            try:
                module = importlib.import_module(modname)
                if not hasattr(module,"SyntaxLexer"):
                    continue
                cls_lexer = getattr(module,"SyntaxLexer")
                lexer_instance = cls_lexer()
                lexer_instance.Register()
            except Exception as e:
                utils.get_logger().exception("")
                utils.get_logger().error("load lexer error:%s",e)

    @classmethod
    def CreateLexerTemplates(cls, lang=""):
        cls.CreateLexers(lang)
        
    @classmethod
    def LoadLexerTemplates(cls, docManager):
        for lexer in SYNATAX_MANAGER.Lexers:
            cls.AddLexer(docManager,lexer)
    
    @staticmethod
    def AddLexer(docManager, lexer):
        utils.get_logger().info("load lexer id:%d description %s ",lexer.LangId,lexer.GetDescription())
        templateIcon = lexer.GetDocIcon()
        if templateIcon is None:
            templateIcon = imageutils.getBlankIcon()
        docTemplate = DocTemplate(docManager,
                lexer.GetDescription(),
                lexer.GetExtStr(),
                os.getcwd(),
                "." + lexer.GetDefaultExt(),
                lexer.GetDocTypeName(),
                lexer.GetViewTypeName(),
                lexer.GetDocTypeClass(),
                lexer.GetViewTypeClass(),
                icon = templateIcon)
        docManager.AssociateTemplate(docTemplate)
