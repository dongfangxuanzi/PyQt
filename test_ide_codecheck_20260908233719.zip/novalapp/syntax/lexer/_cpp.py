# -- coding: utf-8 --
#-------------------------------------------------------------------------------
# Name:        _python.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-17
# Copyright:   (c) wukan 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

#-----------------------------------------------------------------------------#
from novalapp import _
from novalapp.syntax import syndata, lang
import novalapp.util.appdirs as appdirs
import os
from novalapp.qtimage import load_icon
import _c


#-----------------------------------------------------------------------------#

#---- Keyword Specifications ----#

kwlist = _c.kwlist + ["class",'namespace',"public","private","protected","virtual","friend"]

class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""
    def __init__(self):
        lang_id = lang.RegisterNewLangId("ID_LANG_CPP")
        syndata.BaseLexer.__init__(self,lang_id)

    def GetDescription(self):
        return _('C++ Source File')

    def GetExt(self):
        return "cc c++ cpp cxx hh h++ hpp hxx"

    def GetDefaultCommentPattern(self):
        """c++有2种注释方式,这里默认使用行注释方式"""
        return [u'//']
        
    def GetCommentPatterns(self):
        """
            c++注释有2种,行注释和块注释
        """
        return [self.DefaultCommentPattern,['/*','*/']]

    def GetShowName(self):
        return "C/C++"

    def GetDefaultExt(self):
        return "cpp"

    def GetDocTypeName(self):
        return "C++ Document"

    def GetViewTypeName(self):
        return _("C++ Editor")

    def GetDocIcon(self):
        return load_icon("file/cpp.png")

    def GetSampleCode(self):
        sample_file_path = os.path.join(appdirs.get_app_data_location(),"sample","cpp.sample")
        return self.GetSampleCodeFromFile(sample_file_path)

    def GetCommentTemplate(self):
        return '''//******************************************************************************
// Name: {File}
// Copyright: (c) {Author} {Year}
// Author: {Author}
// Created: {Date}
// Description:
// Licence:     {Licence}
//******************************************************************************
'''
    def GetKeywords(self):
        return kwlist + _c._builtinlist

    def syntax_xmlname(self):
        return 'cpp.xml'