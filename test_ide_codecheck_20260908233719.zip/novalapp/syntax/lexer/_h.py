# -- coding: utf-8 --
#-------------------------------------------------------------------------------
# Name:        _python.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-17
# Copyright:   (c) wukan 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

#-----------------------------------------------------------------------------#
from novalapp import _
from novalapp.syntax import syndata, lang
import novalapp.util.appdirs as appdirs
import os
from novalapp.qtimage import load_icon
import _cpp
import _c

class SyntaxLexer(_c.SyntaxLexer):
    """SyntaxData object for Python""" 
    def __init__(self):
        lang_id = lang.RegisterNewLangId("ID_LANG_H")
        syndata.BaseLexer.__init__(self,lang_id)
        
    def GetDescription(self):
        return _('C/C++ Header File')
        
    def GetExt(self):
        return "h"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return [u'/*',u'*/']

    def GetShowName(self):
        return "C/C++"
        
    def GetDefaultExt(self):
        return "h"
        
    def GetDocTypeName(self):
        return "C/C++ Header Document"
        
    def GetViewTypeName(self):
        return _("C/C++ Header Editor")
        
    def GetDocIcon(self):
        return load_icon("file/h_file.gif")
    
    def IsVisible(self):
        return False

    def syntax_xmlname(self):
        return 'cpp.xml'