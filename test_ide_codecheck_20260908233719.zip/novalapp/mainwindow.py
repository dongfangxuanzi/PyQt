# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""Codimension main window"""

# pylint: disable=W0702
# pylint: disable=W0703

# cml 1 gb id=0 title="System imports"
import os.path
import sys
import logging
import gc
from . import get_app, _, newid
from .menubar import find_menu
from .util.ui_utils import extendInstance
from .lib.pyqt import (Qt, QSize, QTimer, QDir, QUrl, pyqtSignal, QWidget,
                 QVBoxLayout, QSplitter, QSizePolicy, QAction,
                 QMainWindow, QApplication, QCursor, QToolButton, QTabBar,
                 QToolTip, QFileDialog, QDialog, QMenu, QDesktopServices, QFrame)
from .menubar import MenubarMixin
from . import menuitems
from .plugin import plugin, plugin_joint
from . import constants
from .toolbar import ToolBar
from .statusbar import StatusBarMixin
from . import globalkeys
from .util import utils, ui_utils
from .sidebar.sidebar import SideBar
from .qtimage import empty_icon
##from .functionsviewer import FunctionsViewer
##from .globalsviewer import GlobalsViewer
##from .classesviewer import ClassesViewer
##from .recentprojectsviewer import RecentProjectsViewer
##from .projectviewer import ProjectViewer
##from .outline import FileOutlineViewer
##from .pyflakesviewer import PyflakesViewer
from .editor.notebook import EditorNotebook
from .editor.textview import TextView
##from .projectproperties import ProjectPropertiesDialog
##from .findreplacewidget import FindReplaceWidget
##from .gotolinewidget import GotoLineWidget
##from .findname import FindNameDialog
##from .findfile import FindFileDialog
##from .mainwindowtabwidgetbase import MainWindowTabWidgetBase
##from .mainstatusbar import MainWindowStatusBarMixin
##from .mainmenu import MainWindowMenuMixin
##from .mainredirectedio import MainWindowRedirectedIOMixin
##from .floatingrendererwindow import DetachedRendererWindow
##from .spacers import ToolBarExpandingSpacer, ToolBarHSpacer
### cml 1 ge id=1
from .project import document as projectdocument


class EditorsManagerWidget(QWidget):

    """Tab widget which has tabs with editors and viewers"""

    def __init__(self, parent):

        QWidget.__init__(self, parent)

        self.editorsManager = EditorNotebook(parent)
      #  self.findReplaceWidget = FindReplaceWidget(self.editorsManager)
       # self.gotoLineWidget = GotoLineWidget(self.editorsManager)
     #   self.editorsManager.registerAuxWidgets(self.findReplaceWidget,
      #                                         self.gotoLineWidget)

        self.editorsManager.setSizePolicy(QSizePolicy.Preferred,
                                          QSizePolicy.Expanding)
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(1, 1, 1, 1)

        self.layout.addWidget(self.editorsManager)
     #   self.layout.addWidget(self.findReplaceWidget)
      #  self.layout.addWidget(self.gotoLineWidget)

        self.setLayout(self.layout)


class IDEMainWindow(QMainWindow):

    """Main application window"""

    def __init__(self, splash):
        QMainWindow.__init__(self)
        
        extendInstance(self, StatusBarMixin)
        StatusBarMixin.__init__(self)

        extendInstance(self, MenubarMixin)
        MenubarMixin.__init__(self)

        self._last_perspective = {}
        self._views = {}
        self.LoadLastperspective()
        self.__initialisation = True
        # This prevents context menu on the main window toolbar.
        # I don't really know why but it is what I need
        self.setContextMenuPolicy(Qt.NoContextMenu)

        # The size restore is done twice to avoid huge flickering
        # This one is approximate, the one in restoreWindowPosition()
        # is precise
        #窗口最大化
        screenSize = get_app().desktop().screenGeometry()
        self.resize(screenSize.width(), screenSize.height())
##        if screenSize.width() != settings['screenwidth'] or \
##           screenSize.height() != settings['screenheight']:
##            # The screen resolution has been changed, use the default pos
##            defXPos, defYpos, \
##            defWidth, defHeight = settings.getDefaultGeometry()
##            self.resize(defWidth, defHeight)
##            self.move(defXPos, defYpos)
##        else:
##            # No changes in the screen resolution
##            self.resize(settings['width'], settings['height'])
##            self.move(settings['xpos'] + settings['xdelta'],
##                      settings['ypos'] + settings['ydelta'])

##        splash.showMessage("Creating toolbar...")
        self.__createToolBar()
##
##        splash.showMessage("Creating layout...")
        self._leftSideBar = None
        self._bottomSideBar = None
        self._rightSideBar = None

        self.__horizontalSplitter = None
        self.__verticalSplitter = None
##
        #创建代码编辑器区域
        self.__createLayout()
##
##        splash.showMessage("Initializing main menu bar...")
##        self.__initPluginSupport()
        self._initMainMenu()
##
        self.updateWindowTitle()
   #     self.__printThirdPartyAvailability()

        

        #settings.sigTextZoomChanged.connect(self.onTextZoomChanged)

        # Flow UI/markdown renderer
##        self.__detachedRenderer = DetachedRendererWindow(settings, self.em)
##        if settings['floatingRenderer']:
##            self.__detachedRenderer.show()
##
##        self.__registerSearchProviders()

    def _InitCommands(self):
        views_menu = find_menu(_("&View"), self.menuBar())
        item = get_app().AddCommand(
            menuitems.ID_VIEW_TOOLBAR,
            views_menu,
            command_label=_("&Toolbar"),
            handler=self.OnViewToolBar,
            kind=constants.CHECK_MENU_ITEM_KIND
        )
        item.action.setChecked(utils.profile_get_int(globalkeys.TOOLBAR_VISIBLE_KEY, True))
        item = get_app().AddCommand(
            menuitems.ID_VIEW_STATUSBAR,
            views_menu,
            command_label=_("&Statusbar"),
            handler=self.OnViewStatusBar,
            kind=constants.CHECK_MENU_ITEM_KIND
        )
        item.action.setChecked(utils.profile_get_int(globalkeys.STATUS_VISIBLE_KEY,True))
        edits_menu = find_menu(_("&Edit"), self.menuBar())  
        get_app().AddDefaultCommand(
            menuitems.ID_UNDO,
            edits_menu,
            _("&Undo"),
            handler=lambda:self.edit_command_handler(menuitems.ID_UNDO),
            image="toolbar/undo.png",
            include_in_toolbar=True
        )
        get_app().AddDefaultCommand(
            menuitems.ID_REDO,
            edits_menu,
            _("&Redo"),
            handler=lambda:self.edit_command_handler(menuitems.ID_REDO),
            image="toolbar/redo.png",
            include_in_toolbar=True,
            add_separator=True
        )
        get_app().AddDefaultCommand(
            menuitems.ID_CUT,
            edits_menu,
            _("&Cut"),
            handler=lambda:self.edit_command_handler(menuitems.ID_CUT),
            image="toolbar/cut.png",
            include_in_toolbar=True
        )
        get_app().AddDefaultCommand(
            menuitems.ID_COPY,
            edits_menu,
            _("&Copy"),
            handler=lambda:self.edit_command_handler(menuitems.ID_COPY),
            image="toolbar/copy.png",
            include_in_toolbar=True
        )
        get_app().AddDefaultCommand(
            menuitems.ID_PASTE,
            edits_menu,
            _("&Paste"),
            handler=lambda:self.edit_command_handler(menuitems.ID_PASTE),
            image="toolbar/paste.png",
            include_in_toolbar=True
        )
        self.GetToolBar().AddSeparator()
        get_app().AddDefaultCommand(
            menuitems.ID_CLEAR,
            edits_menu,_("&Delete"),
            handler=lambda:self.edit_command_handler(menuitems.ID_CLEAR),
            image="delete.png"
        )
        get_app().AddDefaultCommand(
            menuitems.ID_SELECTALL,
            edits_menu,
            _("Select A&ll"),
            handler=lambda:self.edit_command_handler(menuitems.ID_SELECTALL),
            add_separator=True
        )
        self.GetNotebook()._InitCommands()

    def AddToolbarButton(self, command_id, action, add_separator=False, tester=None):
        self._toolbar.AddButton(command_id, action, add_separator, tester)

    def restoreWindowPosition(self):
        """Makes sure that the window frame delta is proper"""
        screenSize = GlobalData().application.desktop().screenGeometry()
        if screenSize.width() != self.settings['screenwidth'] or \
           screenSize.height() != self.settings['screenheight']:
            # The screen resolution has been changed, save the new values
            self.settings['screenwidth'] = screenSize.width()
            self.settings['screenheight'] = screenSize.height()
            self.settings['xdelta'] = self.settings['xpos'] - self.x()
            self.settings['ydelta'] = self.settings['ypos'] - self.y()
            self.settings['xpos'] = self.x()
            self.settings['ypos'] = self.y()
        else:
            # Screen resolution is the same as before
            if self.settings['xpos'] != self.x() or \
               self.settings['ypos'] != self.y():
                # The saved delta is incorrect, update it
                self.settings['xdelta'] = self.settings['xpos'] - self.x() + \
                                          self.settings['xdelta']
                self.settings['ydelta'] = self.settings['ypos'] - self.y() + \
                                          self.settings['ydelta']
                self.settings['xpos'] = self.x()
                self.settings['ypos'] = self.y()
        self.__initialisation = False

    def __createLayout(self):
        """Creates the UI layout"""
        self.editorsManagerWidget = EditorsManagerWidget(self)
        self.em = self.editorsManagerWidget.editorsManager
    #    self.em.sigTabRunChanged.connect(self.setDebugTabAvailable)

    #    self.editorsManagerWidget.findReplaceWidget.hide()
     #   self.editorsManagerWidget.gotoLineWidget.hide()

        # The layout is a sidebar-style one
        self._bottomSideBar = SideBar(SideBar.South, self)
        self._bottomSideBar.setTabsClosable(True)
        self._leftSideBar = SideBar(SideBar.West, self)
        self._rightSideBar = SideBar(SideBar.East, self)
        
        self._view_sidebars = {
            SideBar.West: self._leftSideBar,
            SideBar.South: self._bottomSideBar,
            SideBar.East: self._rightSideBar,
        }

        # Create splitters
        self.__horizontalSplitter = QSplitter(Qt.Horizontal)
        self.__verticalSplitter = QSplitter(Qt.Vertical)

        self.__horizontalSplitter.addWidget(self._leftSideBar)
        self.__horizontalSplitter.addWidget(self.editorsManagerWidget)
        self.__horizontalSplitter.addWidget(self._rightSideBar)

        # This prevents changing the size of the side panels
        self.__horizontalSplitter.setCollapsible(0, False)
        self.__horizontalSplitter.setCollapsible(2, False)
        self.__horizontalSplitter.setStretchFactor(0, 0)
        self.__horizontalSplitter.setStretchFactor(1, 1)
        self.__horizontalSplitter.setStretchFactor(2, 0)

        self.__verticalSplitter.addWidget(self.__horizontalSplitter)
        self.__verticalSplitter.addWidget(self._bottomSideBar)
        # This prevents changing the size of the side panels
        self.__verticalSplitter.setCollapsible(1, False)
        self.__verticalSplitter.setStretchFactor(0, 1)
        self.__verticalSplitter.setStretchFactor(1, 1)

        self.setCentralWidget(self.__verticalSplitter)

        self._leftSideBar.setSplitter(self.__horizontalSplitter)
        self._bottomSideBar.setSplitter(self.__verticalSplitter)
        self._rightSideBar.setSplitter(self.__horizontalSplitter)
        
    def LoadLastperspective(self):
        if utils.profile_get_int("LoadLastPerspective",True):
            self._last_perspective = utils.profile_get('LastPerspective',value={})
            utils.get_logger().debug("last perspective is %s",self._last_perspective)
            
    def is_location_visible(self, location):
        for viewinfo in self._views.values():
            if viewinfo['location'] == location:
                return True
        return False
            
    def get_splitter_width(self, location):
        for view_name in self._last_perspective:
            position = self._last_perspective[view_name].get('position', {})
            if not position:
                continue
            if position['location'] == location and self._last_perspective[view_name]['active']:
                return position['width']
        if self.is_location_visible(location):
            return get_app().get_default_hsplitter_width()
        return 0

    def get_splitter_height(self,location):
        for view_name in self._last_perspective:
            position = self._last_perspective[view_name].get('position', {})
            if not position:
                continue
            if position['location'] == location and self._last_perspective[view_name]['active']:
                return position['height']
        if self.is_location_visible(location):
            return get_app().get_default_vsplitter_height()
        return 0
        
    def LoadPerspective(self,is_full_screen=False):
        active_views = []
        if self.is_sidebar_minimized(SideBar.West, active_views):
            self._leftSideBar.shrink()
        if self.is_sidebar_minimized(SideBar.South, active_views):
            self._bottomSideBar.shrink()
        if self.is_sidebar_minimized(SideBar.East, active_views):
            self._rightSideBar.shrink()
            
        utils.get_logger().debug('active views :%s',active_views)
        for viewname in active_views:
            self.activateTab(viewname)
            
    def is_sidebar_minimized(self, location, activeviews):
        is_visible = False
        is_minimized = True
        for viewname  in self._last_perspective:
            viewinfo = self._last_perspective[viewname]
            position = viewinfo.get('position', {})
            if not position:
                continue
            if position['location'] == location:
                is_visible = True
                if viewinfo['active']:
                    activeviews.append(viewname)
                    is_minimized = False
                    break
        if not self._last_perspective:
            for view_name in self._views:
                if self._views[view_name]['location'] == location:
                    is_visible = True
                    if self._views[view_name]['active']:
                        activeviews.append(viewname)
                        is_minimized = False
                        break
        
        if not is_visible:
            is_minimized = False
        return is_minimized

    def restoreSplitterSizes(self):
        """Restore the side bar state"""
        west_width = self.get_splitter_width(SideBar.West)
        east_width = self.get_splitter_width(SideBar.East)
        
        screenSize = get_app().desktop().screenGeometry()
        notebook_width = screenSize.width()-east_width-west_width
        utils.get_logger().debug(
            'screen width:%d,east width:%d, west width:%d,notebook width:%d',
            screenSize.width(),
            east_width,
            west_width,
            notebook_width
        )
        hSplitterSizes = [west_width,notebook_width,east_width]
        self.__horizontalSplitter.setSizes(hSplitterSizes)
        
        self.__horizontalSplitterSizes = hSplitterSizes
        
        south_height = self.get_splitter_height(SideBar.South)+50
        notebook_height = screenSize.height()-south_height
        utils.get_logger().debug(
            'screen height:%d,south height:%d, notebook height:%d',
            screenSize.height(),
            south_height,
            notebook_height
        )
        vSplitterSizes = [notebook_height,south_height]
        self.__verticalSplitterSizes = vSplitterSizes
        self.__verticalSplitter.setSizes(vSplitterSizes)
        self.LoadPerspective()
        # Setup splitters movement handlers
        self.__verticalSplitter.splitterMoved.connect(self.vSplitterMoved)
        self.__horizontalSplitter.splitterMoved.connect(self.hSplitterMoved)

    def vSplitterMoved(self, pos, index):
        """Vertical splitter moved handler"""
        del pos     # unused argument
        del index   # unused argument

        newSizes = list(self.__verticalSplitter.sizes())

        if not self._bottomSideBar.isMinimized():
            self.__verticalSplitterSizes[0] = newSizes[0]

        self.__verticalSplitterSizes[1] = sum(newSizes) - \
            self.__verticalSplitterSizes[0]

    def hSplitterMoved(self, pos, index):
        """Horizontal splitter moved handler"""
        del pos     # unused argument
        del index   # unused argument

        newSizes = list(self.__horizontalSplitter.sizes())

        if not self._leftSideBar.isMinimized():
            self.__horizontalSplitterSizes[0] = newSizes[0]
        if not self._rightSideBar.isMinimized():
            self.__horizontalSplitterSizes[2] = newSizes[2]

        self.__horizontalSplitterSizes[1] = sum(newSizes) - \
            self.__horizontalSplitterSizes[0] - \
            self.__horizontalSplitterSizes[2]
            
    def GetToolBar(self):
        return self._toolbar
        
    def GetStatusBar(self):
        return self._statusbar

    def __createToolBar(self):
        """creates the buttons bar"""
        self._toolbar = ToolBar()
        self._toolbar.setMovable(False)
        self._toolbar.setAllowedAreas(Qt.TopToolBarArea)
        self._toolbar.setIconSize(QSize(16, 16))

        show = utils.profile_get_int(globalkeys.TOOLBAR_VISIBLE_KEY, True)
        self.setVisible(show)
        self.addToolBar(self._toolbar)

    def __guessMaximized(self):
        """True if the window is maximized"""
        # Ugly but I don't see any better way.
        # It is impossible to catch the case when the main window is maximized.
        # Especially when networked XServer is used (like xming)
        # So, make a wild guess instead and do not save the status if
        # maximized.
        availGeom = GlobalData().application.desktop().availableGeometry()
        if self.width() + abs(self.settings['xdelta']) > availGeom.width() or \
           self.height() + abs(self.settings['ydelta']) > availGeom.height():
            return True
        return False

    def resizeEvent(self, resizeEv):
        """Triggered when the window is resized"""
        del resizeEv    # unused argument
        QTimer.singleShot(1, self.__resizeEventdelayed)

    def __resizeEventdelayed(self):
        """Memorizes the new window size"""
        if self.__initialisation:
            return
        if self.__guessMaximized():
            return

        self.settings['width'] = self.width()
        self.settings['height'] = self.height()
        self.vSplitterMoved(0, 0)
        self.hSplitterMoved(0, 0)

    def moveEvent(self, moveEv):
        """Triggered when the window is moved"""
        del moveEv  # unused argument
        QTimer.singleShot(1, self.__moveEventDelayed)

    def __moveEventDelayed(self):
        """Memorizes the new window position"""
        if not self.__initialisation and not self.__guessMaximized():
            self.settings['xpos'] = self.x()
            self.settings['ypos'] = self.y()

    def onProjectChanged(self, what):
        """Slot to receive sigProjectChanged signal"""
        if what == CodimensionProject.CompleteProject:
            self.closeAllIOConsoles()
            self.updateToolbarStatus()
            self.updateWindowTitle()

            projectLoaded = GlobalData().project.isLoaded()
            self._unloadProjectAct.setEnabled(projectLoaded)
            self._projectPropsAct.setEnabled(projectLoaded)
            self._prjTemplateMenu.setEnabled(projectLoaded)
            self._findNameMenuAct.setEnabled(projectLoaded)
            self._deadCodeMenuAct.setEnabled(projectLoaded)
            self._findProjectFileAct.setEnabled(projectLoaded)
            self._prjImportDgmAct.setEnabled(projectLoaded)
            self._prjImportsDgmDlgAct.setEnabled(projectLoaded)

            self.settings['projectLoaded'] = projectLoaded
            if projectLoaded:
                # The editor tabs must be loaded after a VCS plugin has a
                # chance to receive sigProjectChanged signal where it reads
                # the plugin configuration
                QTimer.singleShot(1, self.__delayedEditorsTabRestore)
        self.updateRunDebugButtons()

        # Updating of the jedi library project should happen regardless
        # whether the properties or the whole project is changed
        getJediProject(force=True)

    def __delayedEditorsTabRestore(self):
        """Delayed restore editor tabs"""
        self.em.restoreTabs(GlobalData().project.tabStatus)

    def updateWindowTitle(self):
        """Updates the main window title with the current so file"""
        self.setWindowTitle(get_app().GetAppName())

    def updateToolbarStatus(self):
        """Enables/disables the toolbar buttons"""
        projectLoaded = GlobalData().project.isLoaded()
        self.importsDiagramButton.setEnabled(projectLoaded and
                                             GlobalData().graphvizAvailable)
        self.__findNameButton.setEnabled(projectLoaded)
        self.__findFileButton.setEnabled(projectLoaded)
        self.__deadCodeButton.setEnabled(projectLoaded)
        self.__projectDocButton.setEnabled(projectLoaded)

    def findInFilesClicked(self):
        """Triggered when the find in files button is clicked"""
        txt = ""
        currentWidget = self.em.currentWidget()
        if currentWidget.getType() in \
           [MainWindowTabWidgetBase.PlainTextEditor]:
            txt, _, _, _ = currentWidget.getEditor().getCurrentOrSelection()

        dlg = FindInFilesDialog(FindInFilesDialog.IN_PROJECT, txt, "")
        dlg.exec_()
        if dlg.searchResults:
            self.displayFindInFiles(FindInFilesSearchProvider().getName(),
                                    dlg.searchResults,
                                    dlg.getParameters())

    def jumpToLine(self, lineNo):
        """Usually used when definition is in the current unsaved buffer"""
        self.em.jumpToLine(lineNo)

    def openPixmapFile(self, path):
        """User double clicked on a file"""
        self.em.openPixmapFile(path)
        
    def SaveLayout(self):
        utils.profile_set(globalkeys.TOOLBAR_VISIBLE_KEY, self._toolbar.isVisible())
        utils.profile_set(globalkeys.STATUS_VISIBLE_KEY, self._statusbar.isVisible())
        self.SavePerspective()
        utils.profile_set("LastPerspective",self._last_perspective)
    
    def GetViews(self):
        return self._views

    def SavePerspective(self,is_full_screen=False):
        def get_location_width(location):
            if location in [SideBar.East, SideBar.West]:
                if len(self.__horizontalSplitterSizes) == 2:
                    assert(location == SideBar.West)
                    return self.__horizontalSplitterSizes[0]
                elif len(self.__horizontalSplitterSizes) == 3:
                    if location == SideBar.West:
                        return self.__horizontalSplitterSizes[0]
                    elif location == SideBar.East:
                        return self.__horizontalSplitterSizes[2]
                    else:
                        assert(False)
                else:
                    assert(False)
        self._last_perspective.clear()
        for view_name in self._views:
           # visibility_flag = views[view_name]['visibility_flag']
            viewinfo = self._views[view_name]
            if 'instance' not in viewinfo:
                utils.get_logger().error('view %s is not valid view instance when save perspective',view_name)
                continue
            location = self._views[view_name]["location"]
            sidebar = self._view_sidebars[location]
            d = {}
            if sidebar.isMinimized():
                d['active'] = False
            else:
                if sidebar.currentTabName() == view_name:
                    d['active'] = True
                else:
                    d['active'] = False
            position = {}
            position['location'] = location
            position['width'] = get_location_width(location)
            position['height'] = self.__verticalSplitterSizes[-1]
            d["position"] = position
            self._last_perspective[view_name] = d

        if is_full_screen:
            self._last_perspective[self.GetStatusBar().GetStatusbarKey()] = dict(visible=self.GetStatusBar().IsShown())
            self._last_perspective[self.GetToolBar().GetToolbarKey()] = dict(visible=self.GetToolBar().IsShown())
            

        

    #重写主窗口右上角X关闭按钮事件,等同于点击退出菜单
    def closeEvent(self, event):
        get_app().Quit()
        event.ignore()
        #return False
        #    event.accept()   
        """Triggered when the IDE is closed"""
##        # Save the side bars status
##        self.settings['vSplitterSizes'] = self.__verticalSplitterSizes
##        self.settings['hSplitterSizes'] = self.__horizontalSplitterSizes
##        self.settings['bottomBarMinimized'] = self._bottomSideBar.isMinimized()
##        self.settings['leftBarMinimized'] = self._leftSideBar.isMinimized()
##        self.settings['rightBarMinimized'] = self._rightSideBar.isMinimized()
##
##        # Ask the editors manager to close all the editors
##        if self.em.getUnsavedCount() == 0:
##            project = GlobalData().project
##            if project.isLoaded():
##                project.tabsStatus = self.em.getTabsStatus()
##                self.settings.tabsStatus = []
##            else:
##                self.settings.tabsStatus = self.em.getTabsStatus()
##
##        if self.em.closeEvent(event):
##            # The IDE is going to be closed just now
##            if self.debugMode:
##                self._onStopDbgSession()
##
##            project = GlobalData().project
##            project.fsBrowserExpandedDirs = self.getProjectExpandedPaths()
##            project.unloadProject(False)
##
##            # Stop the VCS manager threads
##            self.vcsManager.dismissAllPlugins()
##
##            # Kill all the non-detached processes
##            self._runManager.killAll()
##
##            # On ubuntu codimension produces core dumps coming from QT when:
##            # - a new project is created
##            # - the IDE is closed via Alt+F4
##            # It seems that python GC conflicts with QT at finishing. Explicit
##            # call of GC resolves the problem.
##            while gc.collect():
##                pass
##
##            self.__detachedRenderer.close()

    def onTextZoomChanged(self):
        """Triggered when a text zoom is changed"""
        #self.logViewer.onTextZoomChanged()

        # Handle run/profile IO consoles and the debug IO console
        index = self._bottomSideBar.count - 1
        while index >= 0:
            widget = self._bottomSideBar.widget(index)
            if hasattr(widget, 'procuuid'):
                if hasattr(widget, 'onTextZoomChanged'):
                    widget.onTextZoomChanged()
            index -= 1

    def displayFindInFiles(self, providerId, searchResults, parameters):
        """Displays the results on a tab"""
        self.searchResultsViewer.showReport(providerId, searchResults,
                                            parameters)
        self.activateBottomTab('search')

    def activateBottomTab(self, tabName):
        """Makes sure the bottom bar is visible and activates the required tab"""
        if self._bottomSideBar.height() == 0:
            # It was hidden completely, so need to move the slider
            splitterSizes = self.settings['vSplitterSizes']
            splitterSizes[0] -= 200
            splitterSizes[1] += 200
            self.__verticalSplitter.setSizes(splitterSizes)

        self._bottomSideBar.show()
        self._bottomSideBar.setCurrentTab(tabName)
        self._bottomSideBar.raise_()

    def findNameClicked(self):
        """Find name dialog should come up"""
        try:
            FindNameDialog("", self).exec_()
        except Exception as exc:
            logging.error(str(exc))



    @staticmethod
    def hideTooltips():
        """Hides all the tooltips"""
        QToolTip.hideText()
        hideSearchTooltip()

    def onRunTab(self):
        """Triggered when run tab script is requested"""
        currentWidget = self.em.currentWidget()
        self._runManager.run(currentWidget.getFileName(), False)

    def onRunTabDlg(self):
        """Triggered when run tab script dialog is requested"""
        currentWidget = self.em.currentWidget()
        self._runManager.run(currentWidget.getFileName(), True)

    def onRunProject(self, _=None):
        """Runs the project with saved sattings"""
        if self.__checkProjectScriptValidity():
            fileName = GlobalData().project.getProjectScript()
            self._runManager.run(fileName, False)

    def onRunProjectDlg(self):
        """Brings up the dialog with run script settings"""
        if self.__checkProjectScriptValidity():
            fileName = GlobalData().project.getProjectScript()
            self._runManager.run(fileName, True)

    def onProfileTab(self):
        """Triggered when profile script is requested"""
        currentWidget = self.em.currentWidget()
        self._runManager.profile(currentWidget.getFileName(), False)

    def onProfileTabDlg(self):
        """Triggered when profile tab script dialog is requested"""
        currentWidget = self.em.currentWidget()
        self._runManager.profile(currentWidget.getFileName(), True)

    def onProfileProject(self, _=None):
        """Profiles the project with saved settings"""
        if self.__checkProjectScriptValidity():
            fileName = GlobalData().project.getProjectScript()
            self._runManager.profile(fileName, False)

    def onProfileProjectDlg(self):
        """Brings up the dialog with profile script settings"""
        if self.__checkProjectScriptValidity():
            fileName = GlobalData().project.getProjectScript()
            self._runManager.profile(fileName, True)

    def onDebugTab(self):
        """Triggered when debug tab is requested"""
        if not self.debugMode:
            currentWidget = self.em.currentWidget()
            self._runManager.debug(currentWidget.getFileName(), False)

    def onDebugTabDlg(self):
        """Triggered when debug tab script dialog is requested"""
        if not self.debugMode:
            currentWidget = self.em.currentWidget()
            self._runManager.debug(currentWidget.getFileName(), True)

    def onDebugProject(self, _=None):
        """Debugging is requested"""
        if not self.debugMode:
            if self.__checkDebugProjectPrerequisites():
                fileName = GlobalData().project.getProjectScript()
                self._runManager.debug(fileName, False)

    def onDebugProjectDlg(self):
        """Brings up the dialog with debug script settings"""
        if not self.debugMode:
            if self.__checkDebugProjectPrerequisites():
                fileName = GlobalData().project.getProjectScript()
                self._runManager.debug(fileName, True)

    def __checkDebugProjectPrerequisites(self):
        """Returns True if should continue"""
        if not self.__checkProjectScriptValidity():
            return False

        modifiedFiles = self.em.getModifiedList(True)
        if len(modifiedFiles) == 0:
            return True

        dlg = ModifiedUnsavedDialog(modifiedFiles, "Save and debug")
        if dlg.exec_() != QDialog.Accepted:
            # Selected to cancel
            return False

        # Need to save the modified project files
        return self.em.saveModified(True)

    def __checkProjectScriptValidity(self):
        """Checks and logs error message if so. Returns True if all is OK"""
        if not GlobalData().isProjectScriptValid():
            self.updateRunDebugButtons()
            logging.error("Invalid project script. "
                          "Use project properties dialog to "
                          "select existing python script.")
            return False
        return True

    def _verticalEdgeChanged(self):
        """Editor setting changed"""
        self.settings['verticalEdge'] = not self.settings['verticalEdge']
        self.em.updateEditorsSettings()

    def _showSpacesChanged(self):
        """Editor setting changed"""
        self.settings['showSpaces'] = not self.settings['showSpaces']
        self.em.updateEditorsSettings()

    def _lineWrapChanged(self):
        """Editor setting changed"""
        self.settings['lineWrap'] = not self.settings['lineWrap']
        self.em.updateEditorsSettings()

    def _showBraceMatchChanged(self):
        """Editor setting changed"""
        self.settings['showBraceMatch'] = not self.settings['showBraceMatch']
        self.em.updateEditorsSettings()

    def _indentationGuidesChanged(self):
        """Editor setting changed"""
        self.settings['indentationGuides'] = \
            not self.settings['indentationGuides']
        self.em.updateEditorsSettings()

    def _currentLineVisibleChanged(self):
        """Editor setting changed"""
        self.settings['currentLineVisible'] = \
            not self.settings['currentLineVisible']
        self.em.updateEditorsSettings()

    def _homeToFirstNonSpaceChanged(self):
        """Editor setting changed"""
        self.settings['jumpToFirstNonSpace'] = \
            not self.settings['jumpToFirstNonSpace']
        self.em.updateEditorsSettings()

    def _removeTrailingChanged(self):
        """Editor setting changed"""
        self.settings['removeTrailingOnSave'] = \
            not self.settings['removeTrailingOnSave']

    def _editorCalltipsChanged(self):
        """Editor calltips changed"""
        self.settings['editorCalltips'] = not self.settings['editorCalltips']

    def _showNavBarChanged(self):
        """Editor setting changed"""
        self.settings['showNavigationBar'] = \
            not self.settings['showNavigationBar']
        self.em.updateEditorsSettings()

    def _showMainToolbarChanged(self):
        """Main toolbar visibility changed"""
        self.settings['showMainToolBar'] = \
            not self.settings['showMainToolBar']
        self._toolbar.setVisible(self.settings['showMainToolBar'])

    def _projectTooltipsChanged(self):
        """Tooltips setting changed"""
        self.settings['projectTooltips'] = \
            not self.settings['projectTooltips']
        self.projectViewer.setTooltips(self.settings['projectTooltips'])

    def _recentTooltipsChanged(self):
        """Tooltips setting changed"""
        self.settings['recentTooltips'] = \
            not self.settings['recentTooltips']
        self.recentProjectsViewer.setTooltips(self.settings['recentTooltips'])

    def _classesTooltipsChanged(self):
        """Tooltips setting changed"""
        self.settings['classesTooltips'] = \
            not self.settings['classesTooltips']
        self.classesViewer.setTooltips(self.settings['classesTooltips'])

    def _functionsTooltipsChanged(self):
        """Tooltips setting changed"""
        self.settings['functionsTooltips'] = \
            not self.settings['functionsTooltips']
        self.functionsViewer.setTooltips(self.settings['functionsTooltips'])

    def _outlineTooltipsChanged(self):
        """Tooltips setting changed"""
        self.settings.outlineTooltips = \
            not self.settings['outlineTooltips']
        self.outlineViewer.setTooltips(self.settings['outlineTooltips'])

    def _findNameTooltipsChanged(self):
        """Tooltips setting changed"""
        self.settings['findNameTooltips'] = \
            not self.settings['findNameTooltips']

    def _findFileTooltipsChanged(self):
        """Tooltips setting changed"""
        self.settings['findFileTooltips'] = \
            not self.settings['findFileTooltips']

    def _editorTooltipsChanged(self):
        """Tooltips setting changed"""
        self.settings['editorTooltips'] = \
            not self.settings['editorTooltips']
        self.em.setTooltips(self.settings['editorTooltips'])

    def _tabOrderPreservedChanged(self):
        """Tab order preserved option changed"""
        self.settings['taborderpreserved'] = \
            not self.settings['taborderpreserved']

    def _openTabsMenuTriggered(self, act):
        """Tab list settings menu triggered"""
        if act == -1:
            self.settings.tablistsortalpha = True
            self.__alphasort.setChecked(True)
            self.__tabsort.setChecked(False)
        elif act == -2:
            self.settings.tablistsortalpha = False
            self.__alphasort.setChecked(False)
            self.__tabsort.setChecked(True)

    def _onSkin(self, skinName):
        """Triggers when a skin is selected"""
        if self.settings['skin'] != skinName.data():
            logging.info("Please restart codimension to apply the new skin")
            self.settings['skin'] = skinName.data()

    def _onStyle(self, styleName):
        """Sets the selected style"""
        QApplication.setStyle(styleName.data())
        self.settings['style'] = styleName.data().lower()

    def checkOutsideFileChanges(self):
        """Checks if there are changes in the currently opened files"""
        self.em.checkOutsideFileChanges()

    def __loadProject(self, projectFile):
        """Loads the given project"""
        QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        if self.em.closeRequest():
            prj = GlobalData().project
            prj.tabsStatus = self.em.getTabsStatus()
            self.em.closeAll()
            prj.loadProject(projectFile)
            if not self._leftSideBar.isMinimized():
                self.activateProjectTab()
        QApplication.restoreOverrideCursor()


    def _onContextHelp(self):
        """Triggered when Ctrl+F1 is clicked"""
        self.em.currentWidget().getEditor().onTagHelp()

    def _onEmbeddedHelp(self):
        """Triggered when ebedded Codimension help is requested"""
        # File name to get the embedded help
        exeDir = os.path.dirname(os.path.realpath(sys.argv[0]))
        docPath = os.path.dirname(exeDir) + os.path.sep + 'doc' + os.path.sep
        startMD = docPath + 'index.md'
        if not os.path.exists(startMD):
            logging.error('Documentation is not found. '
                          ' Expected here: %s', startMD)
        else:
            self.em.openMarkdownFullView(startMD, True)

    @staticmethod
    def _onAllShortcurs():
        """Triggered when opening key bindings page is requested"""
        QDesktopServices.openUrl(
            QUrl("http://codimension.org/documentation/cheatsheet.html"))

    def _activateSideTab(self, act):
        """Triggered when a side bar should be activated"""
        if isinstance(act, str):
            name = act
        else:
            name = act.data()
        if name in ["project", "recent", "classes", "functions", "globals"]:
            self._leftSideBar.show()
            self._leftSideBar.setCurrentTab(name)
            self._leftSideBar.raise_()
        elif name in ['fileoutline', 'debugger', 'exceptions',
                      'breakpoints', 'calltrace']:
            self._rightSideBar.show()
            self._rightSideBar.setCurrentTab(name)
            self._rightSideBar.raise_()
        elif name in ['log', 'search']:
            self._bottomSideBar.show()
            self._bottomSideBar.setCurrentTab(name)
            self._bottomSideBar.raise_()

    def _onTabJumpToDef(self):
        """Triggered when jump to defenition is requested"""
        self.em.currentWidget().getEditor().onGotoDefinition()

    def _onTabJumpToScopeBegin(self):
        """Jumps to the beginning of the current scope"""
        self.em.currentWidget().getEditor().onScopeBegin()

    def _onFindOccurences(self):
        """Triggered when search for occurences is requested"""
        self.em.currentWidget().getEditor().onOccurences()

    def findWhereUsed(self, fileName, item):
        """Find occurences for c/f/g browsers"""
        QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        definitions = getOccurrences(None, fileName, item.line, item.pos)
        QApplication.restoreOverrideCursor()

        self.showStatusBarMessage('')
        result = []
        for definition in definitions:
            if definition.line is None or definition.module_path is None:
                continue

            fName = definition.module_path
            if not fName:
                fName = fileName
            lineno = definition.line
            index = getSearchItemIndex(result, fName)
            if index < 0:
                widget = self.getWidgetForFileName(fName)
                if widget is None:
                    uuid = ""
                else:
                    uuid = widget.getUUID()
                newItem = ItemToSearchIn(fName, uuid)
                result.append(newItem)
                index = len(result) - 1
            result[index].addMatch(item.name, lineno)

        if len(result) == 0:
            self.showStatusBarMessage('No occurrences found')
            return

        self.displayFindInFiles(OccurrencesSearchProvider().getName(),
                                result,
                                {'name': item.name,
                                 'filename': fileName,
                                 'line': item.line,
                                 'column': item.column})

    def _onTabOpenImport(self):
        """Triggered when open import is requested"""
        self.em.currentWidget().onOpenImport()

    def _onShowCalltip(self):
        """Triggered when show calltip is requested"""
        self.em.currentWidget().getEditor().onShowCalltip()

    def _onOpenAsFile(self):
        """Triggered when open as file is requested"""
        self.em.currentWidget().getEditor().openAsFile()

    def _onDownloadAndShow(self):
        """Triggered when a selected string should be treated as URL"""
        self.em.currentWidget().getEditor().downloadAndShow()

    def _onOpenInBrowser(self):
        """Triggered when a selected url should be opened in a browser"""
        self.em.currentWidget().getEditor().openInBrowser()

    def _onHighlightInOutline(self):
        """Triggered to highlight the current context in the outline browser"""
        self.em.currentWidget().getEditor().highlightInOutline()

    def _onGoToLine(self):
        """Triggered when go to line is requested"""
        self.em.onGoto()

    def __getEditor(self):
        """Provides reference to the editor"""
        return self.em.currentWidget().getEditor()

    def _onComment(self):
        """Triggered when comment/uncomment is requested"""
        self.__getEditor().onCommentUncomment()

    def _onDuplicate(self):
        """Triggered when duplicate line is requested"""
        self.__getEditor().duplicateLine()

    def _onAutocomplete(self):
        """Triggered when autocomplete is requested"""
        self.__getEditor().onAutoComplete()

    def _onExpandTabs(self):
        """Triggered when tabs expansion is requested"""
        self.em.currentWidget().onExpandTabs()

    def _onRemoveTrailingSpaces(self):
        """Triggered when trailing spaces removal is requested"""
        self.em.currentWidget().onRemoveTrailingWS()

    def getCurrentFrameNumber(self):
        """Provides the current stack frame number"""
        return self.debuggerContext.getCurrentFrameNumber()

    def __onClientExceptionsCleared(self):
        """Triggered when the user cleared the client exceptions"""
        self._rightSideBar.setTabText('exceptions', "Exceptions")

    def activateProjectTab(self):
        """Activates the project tab"""
        self.activateTab(constants.PROJECT_VIEW_NAME)

    def activateOutlineTab(self):
        """Activates the outline tab"""
        self.activateTab(constants.OUTLINE_VIEW_NAME)
        
    def activateSearchResultsTab(self):
        """Activates the outline tab"""
        self.activateTab(constants.SEARCH_RESULTS_VIEW_NAME)
        
    def activateTab(self, tabname):
        if not tabname in self._views:
            return
        view_info = self._views[tabname]
        location = view_info['location']
        sidebar = self._view_sidebars[location]
        sidebar.show()
        sidebar.setCurrentTab(tabname)
        sidebar.raise_()

    def passFocusToEditor(self):
        """Passes the focus to the text editor if it is there"""
        return self.em.passFocusToEditor()

    def passFocusToFlow(self):
        """Passes the focus to the flow UI if it is there"""
        return self.em.passFocusToFlow()

    def _onFloatingRenderer(self, action=None):
        """Triggered when the renderer type button is triggered"""
        del action  # unused argument
        self.settings['floatingRenderer'] = not self.settings['floatingRenderer']

        if self.floatingRendererButton.isChecked():
            # Need to make the renderer floating
            self.__detachedRenderer.show()
        else:
            # Need to get back to the embedded renderer
            self.__detachedRenderer.hide()

    def setFocusToFloatingRenderer(self):
        """Raises the window up if it is shown and passes focus"""
        if not self.__detachedRenderer.isHidden():
            self.__detachedRenderer.raise_()
            self.__detachedRenderer.activateWindow()

    def GetNotebook(self):
        return self.em
        
    def AddNotebookPage(self, childframe, title,filename):
        """
        Adds a document page to the notebook.
        """
        template = childframe.GetView().GetDocument().GetDocumentTemplate()
        img = template.GetIcon()   
        self.GetNotebook().addTab(childframe, img, title)
        self.GetNotebook().activateTab(self.GetNotebook().count() - 1)
       # windowMenuService = wx.GetApp().GetService(wx.lib.pydocview.WindowMenuService)
        #if windowMenuService:
         #   windowMenuService.BuildWindowMenu(wx.GetApp().GetTopWindow())  # build file menu list when we open a file

    def GetNotebookPageTitle(self, childframe):
        notebook = self.GetNotebook()
        index = notebook.get_tab_index(childframe)
        return notebook.tabText(index)
        
    def SetNotebookPageTitle(self, childframe, title):
        notebook = self.GetNotebook()
        #todo 这里每次都要自己实现循环遍历,如果以后有更好的方法或者内部实现的的方法要替换此处逻辑代码
        index = notebook.get_tab_index(childframe)
        notebook.setTabText(index, title)
        childframe.GetView().SetFocus()
        
    def ActivateNotebookPage(self,childframe):
        index = self.GetNotebook().get_tab_index(childframe)
        self.GetNotebook().activateTab(index)
        childframe.GetView().SetFocus()
        
    def RemoveNotebookPage(self,childframe):
        #需要判断文档框架是否已经在notebook中不存在了
        index = self.GetNotebook().get_tab_index(childframe)
        if index == -1:
            utils.get_logger().warn("child editor is not in notebook yet when remove it....")
            return
        self.GetNotebook().removeTab(index)
        
    def UpdateToolbar(self):
        if not hasattr(self, "_toolbar"):
            return
        self._toolbar.Update()
        
    def UpdateUI(self,command_id):
        if command_id == menuitems.ID_SAVEALL:
            return self.SaveAllEnabled()
        return True
        
    def SaveAllEnabled(self):
        for index in range(self.GetNotebook().count()):
            widget = self.GetNotebook().widget(index)
            if widget.GetView().GetDocument().IsModified():
                return True
        return False

    def CloseDoc(self):
        editor = self.GetNotebook().currentWidget()
        if editor is None:
            return
        doc = editor.GetView().GetDocument()
        doc.DeleteAllViews()
        
    def CloseAllDocs(self):
        self.GetNotebook().CloseAllWithoutDoc(closeall=True)

    def InitPlugins(self):
        # Setup Plugins after locale as they may have resource that need to be loaded.
        plgmgr = plugin.PluginManager()
        get_app().SetPluginManager(plgmgr)

        #加载内置插件
        common_plugin_loader = plugin_joint.CommonPluginLoader(plgmgr)
        common_plugin_loader.Load()
        #加载用户安装插件
        main_window_addon = plugin_joint.MainWindowAddOn(plgmgr)
        main_window_addon.Init(self)
        
    def OnViewToolBar(self):
        """
        Toggles whether the ToolBar is visible.
        """
        self.GetToolBar().setVisible(not self._toolbar.isVisible())
        #更新工具栏菜单按钮状态
        self.UpdateToolbar()
                
    def OnViewStatusBar(self):
        """
        Toggles whether the StatusBar is visible.
        """
        self.GetStatusBar().setVisible(not self._statusbar.isVisible())
        
    @ui_utils.update_toolbar
    def edit_command_handler(self, command_id):
        editor = self.GetNotebook().currentWidget()
        if editor is None:
            return
        currrent_view = editor.GetView()
        if command_id == menuitems.ID_REDO:
            currrent_view.GetCtrl().onRedo()
        elif command_id == menuitems.ID_UNDO:
            currrent_view.GetCtrl().onUndo()
        elif command_id == menuitems.ID_CUT:
            currrent_view.GetCtrl().onShiftDel()
        elif command_id == menuitems.ID_PASTE:
            currrent_view.GetCtrl().paste()
        elif command_id == menuitems.ID_SELECTALL:
            currrent_view.GetCtrl().selectAll()
        elif command_id == menuitems.ID_COPY:
            currrent_view.GetCtrl().onCtrlC()
        elif command_id == menuitems.ID_CLEAR:
            currrent_view.GetCtrl().selectedText = ''
        else:
            utils.get_logger().warning("unknown edit comand it %d",command_id)
            
    def AddView(
            self,
            view_name,
            view_class,
            label,
            default_location,
            *,
            default_position_key=None,
            create=True,
            active=False,
            image_file=None,
            visible_in_menu=True
        ):
        """Adds item to "View" menu for showing/hiding given view. 
        Args:
            view_class: Class or constructor for view. Should be callable with single
                argument (the master of the view)
            label: Label of the view tab
            location: Location descriptor. Can be "nw", "sw", "s", "se", "ne"
        Returns: None        
        """        
        is_actived = utils.profile_get_int(globalkeys.FRAME_VIEW_MINIMIZED_KEY % view_name,active)
        utils.get_logger().debug("%s is actived:%s",globalkeys.FRAME_VIEW_MINIMIZED_KEY % view_name,is_actived)
        image = None
        if image_file is not None:
            image = get_app().GetImage(image_file)
        else:
            image = empty_icon()
        self._views[view_name] = {
            "class": view_class,
            "label": label,
            "location": default_location,
            "position_key": default_position_key,
            "active": is_actived,
            'image':image
        }
        # handler
        def toggle_view_activiity():
            self.activateTab(view_name)
        views_menu = find_menu(_("&View"), self.menuBar())
        if visible_in_menu:
            views_menu.InsertAfter(
                menuitems.ID_VIEW_STATUSBAR,
                newid(),
                label,
                handler=toggle_view_activiity,
                img=image
            )
        if create:
            self.ShowView(view_name,active = is_actived)
        return self._views[view_name]

    def ShowView(
            self,
            view_name,
            set_focus=True,
            active=False
        ):
        """View must be already registered.
        
        Args:
            view_id: View class name 
            without package name (eg. 'ShellView') """
        # NB! Don't forget that view.home_widget is added to notebook, not view directly
        # get or create
        view = self.GetView(view_name)
        sidebar = view.home_widget.parent()  # type: ignore
        sidebar.addTab(
            view.home_widget, 
            self._views[view_name]["image"],
            self._views[view_name]['label'], 
            view_name, 
            self._views[view_name]['position_key']
        )
        # switch to the tab
        if self._views[view_name]['location'] == SideBar.South:
            sidebar.tabButton(view_name, QTabBar.RightSide).resize(0, 0)
        # add focus
        if set_focus:
            view.setFocus()
        
        if not active:
            self._views[view_name]['active'] = False
            #self._view_sidebars[self._views[view_name]['location']].shrink()
        else:
           # self.activateTab(view_name)
            self._views[view_name]['active'] = True
        return view
        
    def GetView(self, view_name,**kwargs):
        if "instance" not in self._views[view_name]:
            view_class = self._views[view_name]["class"]
            location = self._views[view_name]["location"]
            sidebar = self._view_sidebars[location]
            home_widget = QFrame(sidebar)
            # create the view
            view = view_class(
                home_widget
            ) 
            layout = QVBoxLayout(home_widget)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(view)
            #设置视图在notebook中的位置顺序,如果放置在最后则设置为None
            view.position_key = self._views[view_name]["position_key"]
            self._views[view_name]["instance"] = view
            # create the view home_widget to be added into notebook
            view.home_widget = home_widget
            #关闭窗口事件,同时修改菜单选中状态
##            if not hasattr(view.home_widget,'close'):
##                view.home_widget.close = lambda: self.ShowView(view_name,False,hidden=True,toogle_visibility_flag=True)  # type: ignore
##            else:
##                utils.get_logger().debug('view %s already has close method,will not attach close attr aggain',view_name)
            if hasattr(view, "position_key"):
                view.home_widget.position_key = view.position_key  # type: ignore
        return self._views[view_name]["instance"]
        
    @ui_utils.call_after
    def check_external_changes(self):
        '''
            主界面在前台显示时,检查文本是否在外部改变
        '''
        openDocs = get_app().GetDocumentManager().GetDocuments()
        for doc in openDocs:
            if isinstance(doc, projectdocument.ProjectDocument):
                view = self.projectview.GetView()
                if view._is_external_changed and utils.profile_get_int(globalkeys.CHECK_FILE_MODIFY_KEY, True):
                    view.check_for_external_changes()
            else:
                view = doc.GetFirstView()
                if hasattr(view,"_is_external_changed"):
                    if view._is_external_changed and utils.profile_get_int(globalkeys.CHECK_FILE_MODIFY_KEY, True):
                        view.check_for_external_changes()
                        TextView.FILE_MOVE_DELETED_ANSWER = None
                        TextView.FILE_MODIFY_ANSWER = None
    def hideall(self):
        self._leftSideBar.shrink()
        self._bottomSideBar.shrink()
        self._rightSideBar.shrink()
        
    @property       
    def projectview(self):
        return self.GetView(constants.PROJECT_VIEW_NAME)
    
    @property         
    def resourceview(self):
        return self.GetView(FILE_VIEW_NAME)
        
    @property     
    def resultsview(self):
        return self.GetView(constants.SEARCH_RESULTS_VIEW_NAME)
        
    def PushStatusText(self, msg):
        self.showStatusBarMessage(msg)
        
    