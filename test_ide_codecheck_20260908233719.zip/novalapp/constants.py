# -*- coding: utf-8 -*-
from .menuitems import *
APPLICATION_NAME = "NovalIDE"
DEBUG_APPLICATION_NAME = APPLICATION_NAME + "Debug"



UPDATE_ONCE_STARTUP = 0
UPDATE_ONCE_DAY = 1
UPDATE_ONCE_WEEK = 2
UPDATE_ONCE_MONTH = 3
NEVER_UPDATE_ONCE = 4

TEMPLATE_FILE_NAME = "template.xml"
USER_CACHE_DIR = "cache"

DEFAULT_FONT_FAMILY = "Courier New"
DEFAULT_FONT_SIZE = 11

NORMAL_MENU_ITEM_KIND = 0
SUB_MENU_ITEM_KIND = 1
CHECK_MENU_ITEM_KIND = 2
RADIO_MENU_ITEM_KIND = 3


OUTLINE_VIEW_NAME = "Outline"
FILE_VIEW_NAME = "Fileview"
PROJECT_VIEW_NAME = "Projectview"
SEARCH_RESULTS_VIEW_NAME = "SearchResults"
PYTHON_INTERPRETER_VIEW_NAME = "PythonInterpreter"

#默认历史文件个数
DEFAULT_MRU_FILE_NUM = 9

#默认历史项目个数
DEFAULT_MRU_PROJECT_NUM = 5
#最大历史项目个数
MAX_MRU_PROJECT_LIMIT = 10


#状态栏显示的标签名称,行列以及文件编码
STATUS_BAR_LABEL_LINE = "line"
STATUS_BAR_LABEL_COL = "column"
STATUS_BAR_LABEL_ENCODING = "encoding"

#工具栏排列在第一行的位置
DEFAULT_TOOL_BAR_ROW = 0
#工具栏排列在第三行的位置
DEFAULT_STATUS_BAR_ROW = 3
#主框架排列在第二行的位置
DEFAULT_MAIN_FRAME_ROW = 1


PROJECT_ADD_COMMAND_NAME            = "add"
PROJECT_ADD_PROGRESS_COMMAND_NAME   = "progress_add"

#the first 2 line no of python file to place encoding declare
ENCODING_DECLARE_LINE_NUM = 2

NOT_IN_ANY_PROJECT = "Not in any Project"

DEFAULT_EDGE_GUIDE_WIDTH = 78

EOL_CR = 0
EOL_LF = 1
EOL_CRLF = 2
MIXED_CRLF = 3

CR = "\r"
LF = "\n"
CRLF = "\r\n"

EOL = {
    EOL_CR:CR,
    EOL_LF:LF,
    EOL_CRLF:CRLF
}

INTERACTCONSOLE_TAB_NAME = "InteractConsole"
BREAKPOINTS_TAB_NAME = "Breakpoints"
STACKFRAME_TAB_NAME = "StackFrame"
WATCH_TAB_NAME = "Watchs"

#默认url请求连接超时时间
DEFAULT_URL_REQUEST_TIMEOUT = 10


DEFAULT_APP_SKIN = "default"
DEFAULT_APP_STYLE = "fusion"

OLD_FASHION_GREENBLACK_SKIN = "Old fashion green-black"


PUFIFY_MODE = 'purify'
FULLY_MODE = 'fully'

DEFAULT_MODE = PUFIFY_MODE

#文本默认编码
DEFAULT_ENCODING = "utf-8"