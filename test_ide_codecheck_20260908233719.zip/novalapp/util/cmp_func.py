import functools

def py_sorted(iter_obj,cmp_func):
    sorted_items = sorted(iter_obj, key=functools.cmp_to_key(cmp_func))
    return sorted_items
    
def py_cmp(l,r):
    if r < l:
        return 1
    if l < r:
        return -1
    return 0
def strcmp(str1,str2):
    i = 0
    while i<len(str1) and i<len(str2):
        if str1[i] != str2[i]:
            if str1[i] == '_':
                return 1
            elif str2[i] == '_':
                return -1
            outcome = py_cmp(str1[i],str2[i])
            return outcome
        i += 1
    return py_cmp(len(str1),len(str2))

def cmp_name(x,y):
    if strcmp(x.lower() , y.lower()) == 1:
        return 1
    return -1
