# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        misc.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-16
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
import os
from .. import get_app, _
from ..lib.pyqt import QDialog, Qt, QDialogButtonBox, QMessageBox, QTimer, QApplication, QT_VERSION_STR,QCursor,QFrame
from . import utils
from .. import constants
        
def update_toolbar(func):
    def wrap_func(*args,**kwargs):
        func(*args,**kwargs)
        get_app().MainFrame.UpdateToolbar()
    return wrap_func
    

def update_statusbar(func):
    def wrap_func(*args,**kwargs):
        func(*args,**kwargs)
        get_app().MainFrame.GetNotebook().updateStatusBar()
    return wrap_func
    
class AlarmEventMixin:
    
    def __init__(self):
        self._asking_about_external_change = False
        self._alarm_event = -1
        self._is_external_changed = False
        
    def Alarm(self, alarm_event):
        if os.path.exists(self.GetDocument().GetFilename()) and self.GetDocument().IsDocumentModificationDateCorrect():
            utils.get_logger().warn("accept modify alarm event,but file %s modify time is not chanaged",self.GetDocument().GetFilename())
            return
        self._alarm_event = alarm_event
        self._is_external_changed = True
        
    def check_for_external_changes(self):
        self._is_external_changed = False
        

class BaseModalDialog(QDialog):
    def __init__(self, title, master=None):
        if master is None:
            master = get_app().MainFrame
        super().__init__(master)
        self.setWindowTitle(title)
        
    def create_standard_buttons(self, layout):
        buttonBox = QDialogButtonBox(self)
        buttonBox.setOrientation(Qt.Horizontal)
        buttonBox.setStandardButtons(QDialogButtonBox.Ok |
                                     QDialogButtonBox.Cancel)
        self.__OKButton = buttonBox.button(QDialogButtonBox.Ok)
        self.__OKButton.setDefault(True)
        buttonBox.accepted.connect(self.accept)
        buttonBox.rejected.connect(self.reject)
        layout.addWidget(buttonBox)

def extendInstance(obj, cls):
    """dynamic mixin support"""
    base_cls = obj.__class__
    base_cls_name = obj.__class__.__name__
    obj.__class__ = type(base_cls_name, (base_cls, cls), {})

def check_debugger(func):
    '''
    '''
    def wrapped_func(*args,**kwargs):
        if get_app().GetDebuggerClass() is None:
            QMessageBox.critical(
                get_app().MainFrame,
                _("Error"),
                _("There is no debuger")
            )
            return
        ret = func(*args,**kwargs)
        return ret
    return wrapped_func
    
def wait_cursor(func):
    '''
       执行方法时显示等待光标,完成后恢复光标
    '''
    def wrapped_func(*args,**kwargs):
        QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        ret = func(*args,**kwargs)
        QApplication.restoreOverrideCursor()
        return ret
    return wrapped_func

def no_implemented_yet(func): 
    def _wrapper(*args, **kwargs): 
        QMessageBox.warning(get_app().MainFrame,get_app().GetAppName(),_("This function not implemented yet!"))
    return _wrapper
    
def call_after(func):
    '''
        延迟调用不带参数的装饰器,使用计时器实现
    '''
    def _wrapper(*args, **kwargs): 
        QTimer.singleShot(100, lambda:func(*args, **kwargs)) 
    return _wrapper 
    
def call_after_with_time(*wrap_args,**wrap_kwargs):
    '''
        延迟调用不带参数延迟时间的装饰器,使用计时器实现
    '''
    def call_after(func): 
        def _wrapper(*args, **kwargs): 
            QTimer.singleShot(wrap_args[0], lambda:func(*args, **kwargs)) 
        return _wrapper
    return call_after
    
def copytoclipboard(text):
    QApplication.clipboard().setText(text)
    
def getQtVersion():
    """Provides the Qt version"""
    return QT_VERSION_STR
    
def get_eol(eol):
    for key ,val in constants.EOL.items():
        if eol == val:
            return key
    raise RuntimeError(f'unkown eol value {eol}')
    

class BaseConfigurationPanel(QFrame):
    
    def __init__(self,master=None):
        super().__init__(master)
        #某些情况下配置界面是禁止的
        self._is_disabled = False
        self._configuration_changed = False
        
    def OnOK(self,optionsDialog):
        if not self.Validate():
            return False
        return True
        
    def OnCancel(self,optionsDialog):
        if self._configuration_changed:
            return False
        return True
        
    def NotifyConfigurationChanged(self):
        self._configuration_changed = True
        
    def Validate(self):
        return True
        
    def IsDisabled(self):
        return self._is_disabled

    def DisableUI(self,parent):
        self._is_disabled = True
        for child in parent.winfo_children():
            #这里禁止其子控件
            if isinstance(child,ttk.Frame) or isinstance(child,ttk.Labelframe):
                self.DisableUI(child)
            #label控件不禁止,Scrollbar和Treeview没有state属性
            elif isinstance(child,ttk.Label) or isinstance(child,ttk.Scrollbar) or isinstance(child,ttk.Treeview):
                continue
            #entry控件设置为只读状态
            elif isinstance(child,ttk.Entry):
                child['state'] = "readonly"
            else:
                child['state'] = tk.DISABLED
        