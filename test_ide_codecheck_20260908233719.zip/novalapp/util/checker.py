# -*- coding: utf-8 -*-
from . import appdirs, utils
import os
import psutil
#import noval.python.parser.utils as parserutils

class SingleInstanceChecker(object):
    """description of class"""

    def __init__(self):
        user_data_path = appdirs.get_user_data_path()
        if not os.path.exists(user_data_path):
            parserutils.MakeDirs(user_data_path)
        self.lock = os.path.join(user_data_path,"lock")
        self.pid = None
        self.Create()

    def Create(self):
        if not os.path.exists(self.lock):
            self.SetPid()
        else:
            self.GetPid()

    def IsAnotherRunning(self):
        if self.pid is None:
            return False
        try:
            p = psutil.Process(int(self.pid))
            #有可能进程号被别的程序占用了,故还需要判断进程名是否是novalide或python进程
            if p.name().lower() not in [utils.get_exe_name("novalide"),utils.get_exe_name("python")]:
                return False
            #如果是python进程还需要判断命令行是否包含novalide关键字
            if p.name().lower() == utils.get_exe_name("python"):
                running = False
                for cmd in p.cmdline():
                    if cmd.lower().find("novalide") != -1:
                        running = True
                    if cmd.lower() == "-debug":
                        running = False
                        break
                return running
        except:
            utils.get_logger().info("app process id %s is not run again",self.pid)
            self.SetPid()
            return False
        return True
        
    def GetPid(self):
        with open(self.lock) as f:
            self.pid = f.read()
        
    def SetPid(self):
        with open(self.lock,"w") as f:
            f.write(str(os.getpid()))
        
