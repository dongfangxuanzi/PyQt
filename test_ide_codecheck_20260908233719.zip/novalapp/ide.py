# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        ide.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-08
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
'''
    尽量少在文件头部导入太多模块,会导致程序启动很慢
'''
from . import Locale, _, get_app
from .lib.core import App
from .lib.docmanager import DocManager
from . import qtimage
from .util import strutils, logger, utils, ui_utils, fileutils
from .constants import (
    APPLICATION_NAME, 
    NORMAL_MENU_ITEM_KIND, 
    DEBUG_APPLICATION_NAME, 
    DEFAULT_APP_SKIN,
    OLD_FASHION_GREENBLACK_SKIN,
    DEFAULT_APP_STYLE,
    DEFAULT_MODE,
    FULLY_MODE,
    SEARCH_RESULTS_VIEW_NAME,
    PROJECT_VIEW_NAME,
    FILE_VIEW_NAME
)
from . import globalkeys
from . import menuitems
from .skin import Skin
from .menubar import find_menu, KEYBINDER
from .widgets.exceptiondlg import ExceptionMessageDialog
from pkg_resources import resource_filename
import sys
import os
import abc
from .syntax.synglob import LexerFactory
from .syntax.syntax import SYNATAX_MANAGER
from .syntax import lang
from .preference import preference
import subprocess
from .editor import docposition
#import noval.ui_utils as ui_utils
import traceback
#import noval.logview as logview
from .analytics.userdb import UserDataDb
#from noval.util.command import BackendSpec
from .lib.docmanager import DEFAULT_DOCMAN_FLAGS, DOC_NEW, DOC_SILENT, DOC_OPEN_ONCE
from .lib.pyqt import QMessageBox,QEvent
from .api import ApiServer
#由于syndata在项目中没有显示导入,故pyinstaller打包的时候不会把这个模块打包到程序中，
#程序运行使会出现如下错误
#ImportError: cannot import name 'syndata' from 'novalapp.syntax' 
#为了保证syndata能打包打包到程序中,这里需要显示导入一下,虽然没有使用,但是不能缺少这个
#除非其他地方引用了这个模块
import novalapp.syntax.syndata as syndata

#----------------------------------------------------------------------------
# Classes
#----------------------------------------------------------------------------
class IDEApplication(App):

    def __init__(self):
        super().__init__()

    def OnInit(self):
        args = sys.argv
        #设置软件是否处于调式模式运行
        if strutils.isInArgs("debug", args):
            self.SetAppName(DEBUG_APPLICATION_NAME)
            self.SetDebug(True)
            self.SetSingleInstance(False)
        else:
            self.SetAppName(APPLICATION_NAME)
            self.SetDebug(False)
            self.SetSingleInstance(True)
            
        #python脚本用pyinstaller转换成可执行程序后需要重定向输入到日志文件
        #必须在日志初始化之前启动
        from . import boot_common
        logger.initLogging(self.GetDebug())
        sys.excepthook = self._hook_callback_exception
        if not super().OnInit():
            return False
     #   self.ShowSplash(self.GetIDESplashBitmap())
        #尽量在这里导入模块
        from .lib.template import DocTemplate, TEMPLATE_INVISIBLE, TEMPLATE_NO_CREATE
        from .editor.imageview import ImageDocument, ImageView
        from .editor.textview import TextDocument, TextView
##        from noval.editor import text as texteditor
##        import noval.colorfont as colorfont
##        import noval.docoption as docoption
        from .preference.general import GeneralOptionPanel
##        import noval.project.debugger as basedebugger

        #将tk程序的异常输出重定向
        self._open_project_path = None
        self.frame = None           
        self._pluginmgr = None
        
        self._debugger_class = None
#        self._debugger_view_class = basedebugger.DebugView
        self._config = utils.Config(self.GetAppName())

        ##locale must be set as app member property,otherwise it will only workable when app start up
        ##it will not workable after app start up,the translation also will not work
        #默认从配置文件获取语言id
        lang_id = utils.profile_get_int(globalkeys.LANGUANGE_ID_KEY,utils.get_lang_config())
        if Locale.is_available(lang_id):
            self.locale = Locale(lang_id)
            self.locale.add_catalog_lookup_pathprefix(os.path.join(utils.get_app_path(),'novalapp/locale'))
            ibRet = self.locale.add_catalog(APPLICATION_NAME.lower())
            ibRet = self.locale.add_catalog("wxstd")
            self.locale.add_catalog("wxstock")
        else:
            utils.get_logger().error("lang id %d is not available",lang_id)

        docManager = self.GetDocmanagerClass()()
        self.SetDocumentManager(docManager)
        
        # Note:  These templates must be initialized in display order for the "Files of type" dropdown for the "File | Open..." dialog
        #这个是默认模板,所有未知扩展名的文件类型均使用这个模板
        defaultTemplate = DocTemplate(docManager,
            _("All Files"),
            "*.*",
            os.getcwd(),
            ".*",
            "Blank Document",
            _("Blank Editor"),
            TextDocument,
            TextView,
            TEMPLATE_INVISIBLE,
            icon = qtimage.blank_icon()
        )
        docManager.AssociateTemplate(defaultTemplate)

        imageTemplate = DocTemplate(docManager,
            _("Image File"),
            "*.bmp;*.ico;*.gif;*.jpg;*.jpeg;*.png",
            os.getcwd(),
            ".png",
            "Image Document",
            _("Image Viewer"),
            ImageDocument,
            ImageView,
            #could not be newable
            TEMPLATE_NO_CREATE,
            icon = qtimage.image_icon()
        )
        docManager.AssociateTemplate(imageTemplate)

        #创建各种支持编程语言的模板
        self.CreateLexerTemplates()
        self.LoadLexerTemplates()
        self.CreateProjectTemplate()
        self.SetDefaultIcon(qtimage.application_icon())
        self.InitConfigs()
        self.load_skin()
##        
##        self._backends = {}  # type: Dict[str, BackendSpec]
        #先创建主框架
        self._InitMainFrame()
##        #再初始化程序菜单及其命令
        self._InitCommands()
        self._init_sidebars()
##        #添加通用首选项面板
        preference.PreferenceManager.manager().AddOptionsPanelClass(
            preference.ENVIRONMENT_OPTION_NAME,
            preference.GENERAL_ITEM_NAME,
            _("General"),
            GeneralOptionPanel
        )
##        preference.PreferenceManager().AddOptionsPanelClass(preference.ENVIRONMENT_OPTION_NAME,preference.PROJECT_ITEM_NAME,baseprojectviewer.ProjectOptionsPanel)
##        preference.PreferenceManager().AddOptionsPanelClass(preference.ENVIRONMENT_OPTION_NAME,preference.TEXT_ITEM_NAME,texteditor.TextOptionsPanel)
##        preference.PreferenceManager().AddOptionsPanelClass(preference.ENVIRONMENT_OPTION_NAME,"Document",docoption.DocumentOptionsPanel)
##        preference.PreferenceManager().AddOptionsPanelClass(preference.ENVIRONMENT_OPTION_NAME,preference.FONTS_CORLORS_ITEM_NAME,colorfont.ColorFontOptionsPanel)
##        #必须等菜单栏和主窗口初始化完成才在此处初始化插件
        self.InitPlugins()
##        #打开从命令行传递的参数文件
##        self.OpenCommandLineArgs()
##        
##        #加载上次程序退出时的活跃项目
##        self.SetCurrentProject()
##        ###self.ShowTipfOfDay()
##
##
        self.initializing = False
        
##        #插入,删除文本时触发事件
##        self.bind("TextInsert", self.EventTextChange, True)
##        self.bind("TextDelete", self.EventTextChange, True)
##        #文本字体与颜色,以及高亮语法设置更改时触发该事件
##        self.bind("<<UpdateAppearance>>", self.EventTextChange, True)
        self.installEventFilter(self)
        return True
        
    def eventFilter(self, obj, event):
        """Event filter to catch ESC application wide.

        Pass focus explicitly on broken window managers when the app is
        activated; Catch Ctrl+1 and Ctrl+2 application wide;
        """
        del obj     # unused argument
        # todo 这个方法执行后会导致程序退出时卡住很长一段时间才退出
        # TODO 需要后面想办法解决这个卡顿的问题
        try:
            eventType = event.type()
            if eventType == QEvent.ApplicationActivate:
                if self.frame:
                    self.frame.check_external_changes()
        except:
            pass
        return False
        
    def GetDocmanagerClass(self):
        return DocManager
        
    def InitConfigs(self):
        '''
            初始化配置文件信息
        '''
        default_pip_source = "http://pypi.douban.com/simple"
        if utils.is_windows():
            #windows使用注册表存储配置信息,写入配置文件的信息必须新生成配置文件
            utils.write_cofig('virtual_env','pip_source_path',default_pip_source)
        else:
            #linux使用配置文件存储配置信息,故使用同一个配置文件,无需新创建一个配置文件
            config = self.GetConfig()
            config.Write('virtual_env/pip_source_path',default_pip_source)
            
    #统计插件加载时间
    @utils.compute_time
    def InitPlugins(self):
        self.LoadDefaultPlugins()
        self.MainFrame.InitPlugins()
        #在插件初始化完后才创建项目菜单和外观菜单
        self.MainFrame.projectview._InitCommands()
        self.frame.show()
        self.MainFrame.restoreSplitterSizes()
        
    def _hook_callback_exception(self, exc, val, tb):
        # copied from tkinter.Tk.report_callback_exception with modifications
        # see http://bugs.python.org/issue22384
        sys.last_type = exc
        sys.last_value = val
        sys.last_traceback = tb
        
        # Keyboard interrupt is a special case
        if issubclass(exc, KeyboardInterrupt):
            self.quit()
            return
        self.report_exception(exc, val, tb)

    def report_exception(self, exc, val, tb):
        title = _("Internal error")
        utils.get_logger().exception(title,exc_info=(exc, val, tb))
        #是否重定向异常信息到消息对话框
        if utils.profile_get_int(globalkeys.REDIRECT_APP_EXCEPTION, True if self.GetDebug() else False):
            msg = ''.join(traceback.format_exception(exc, val, tb))
            #异常输出重定向到消息对话框中
            dlg = ExceptionMessageDialog(title, msg, self.MainFrame)
            dlg.exec_()

    def LoadDefaultPlugins(self):
        '''
            默认插件在consts.DEFAULT_PLUGINS中指定
        '''
        pass
        
    def SetAppTitle(self):
        self.SetAppName(self._app_name)
        
    def CreateLexerTemplates(self):
        LexerFactory.CreateLexerTemplates()
        
    def LoadLexerTemplates(self):
        LexerFactory.LoadLexerTemplates(self.GetDocumentManager())
        
    def CreateProjectTemplate(self):
        from .project import view as projectview
        from .project import document as projectdocument
        from .project import ext
        projectTemplate = projectview.ProjectTemplate(
            self.GetDocumentManager(),
            _("Project File"),
            "*%s" % ext.PROJECT_EXTENSION,
            os.getcwd(),
            ext.PROJECT_EXTENSION,
            "Project Document",
            _("Project Viewer"),
            projectdocument.ProjectDocument,
            projectview.ProjectView,
            icon = qtimage.getProjectIcon()
        )
        self.GetDocumentManager().AssociateTemplate(projectTemplate)
        
    def GetDefaultLangId(self):
        return lang.ID_LANG_TXT
    
    @property
    def MainFrame(self):
        return self.frame
                
    def GotoView(self,file_path,*,lineNum=-1,colno=-1,trace_track=True,load_outline=True):
        docs = self.GetDocumentManager().CreateDocument(file_path, DOC_SILENT|DOC_OPEN_ONCE)
        if docs == []:
            return None
        foundView = docs[0].GetFirstView()
        if foundView:
            foundView.GetFrame().SetFocus()
            foundView.Activate()
            if not hasattr(foundView,"GotoLine"):
                return None
            if colno == -1:
                foundView.GotoLine(lineNum)
            else:
                #定位到具体位置时是否追踪位置
                if trace_track:
                    foundView.GotoPos(lineNum,colno)
                else:
                    foundView.GetCtrl().GotoPos(lineNum,colno)
            return foundView
        return None
    
    @property
    def OpenProjectPath(self):
        return self._open_project_path
        
    def GetPluginManager(self):
        """Returns the plugin manager used by this application
        @return: Apps plugin manager
        @see: L{plugin}

        """
        return self._pluginmgr
        
    def SetPluginManager(self,pluginmgr):
        self._pluginmgr = pluginmgr

    def AddMessageCatalog(self, name, path):
        """
            添加翻译文件的查找路径,在插件中使用,如果插件需要翻译,可以在egg文件里面添加翻译文件在egg文件里面的相对路径
        """
        if self.locale is not None:
            #这里会把egg文件解压到一个临时的目录,以便程序能搜索到翻译文件的绝对路径
            #windows egg文件的临时目录类似:C:\Users\Administrator\AppData\Roaming\Python-Eggs\calculator-0.6-py2.7.egg-tmp\calculator\locale
            path = resource_filename(path, 'locale')
            self.locale.AddCatalogLookupPathPrefix(path)
            self.locale.AddCatalog(name)
        
    @property
    def Menubar(self):
        return self.MainFrame.menuBar()
        
    def InsertCommand(
            self,
            before_command_id,
            command_id,
            menu,
            command_label,
            handler,
            accelerator=None,
            image = None,
            add_separator=False,
            tester=None,
            kind=NORMAL_MENU_ITEM_KIND
        ):
        assert(type(command_id) == int)
        if image is not None and type(image) == str:
            image = self.GetImage(image)
        if isinstance(menu, str):
            menu = find_menu(menu, self.Menubar)
        menu_item = menu.InsertBefore(
            before_command_id,
            command_id,
            command_label,
            handler=handler,
            img=image,
            accelerator=accelerator,
            kind=kind,
            tester=tester
        )
        return menu_item
        
    def AddDefaultCommand(self,
            command_id,
            menu,
            command_label,
            handler,
            accelerator=None,
            image = None,
            include_in_toolbar = False,
            add_separator=False,
            kind=NORMAL_MENU_ITEM_KIND
        ):
        return self.AddCommand(
            command_id,
            menu,
            command_label,
            handler,
            accelerator,
            image,
            include_in_toolbar,
            add_separator,
            lambda:self.UpdateUI(command_id),
            kind
        )

    def AddCommand(self,
            command_id,
            menu,
            command_label,
            handler,
            accelerator=None,
            image = None,
            include_in_toolbar = False,
            add_separator=False,
            tester = None,
            kind=NORMAL_MENU_ITEM_KIND
        ):
    
        '''
            tester表示菜单状态更新的回调函数,返回bool值
            default_command表示菜单是否在文本编辑区为空白时(即没有一个文本编辑窗口),菜单状态为灰选
        '''
        if image is not None and type(image) == str:
            image = self.GetImage(image)
            
        if accelerator is None:
            accelerator = KEYBINDER.GetBinding(command_id)
            
        if isinstance(menu, str):
            menu = find_menu(menu, self.Menubar)

        item = menu.Append(
            command_id,
            command_label,
            handler=handler,
            img=image,
            kind=kind,
            accelerator=accelerator,
            tester=tester 
        )
        if add_separator:
            menu.add_separator()
        if include_in_toolbar:
            self.MainFrame.AddToolbarButton(command_id, item.action, add_separator, tester)
        return item

    def UpdateUI(self,command_id):
        #优先处理运行调试菜单,如果存在打开项目,状态应该为可用
        if command_id in [menuitems.ID_RUN, menuitems.ID_DEBUG]:
            if self.MainFrame.projectview.GetCurrentProject() is not None:
                return True
             
        current_editor = self.MainFrame.GetNotebook().currentWidget()
        if current_editor is None:
            return False
        active_view = current_editor.GetView()
        assert(active_view is not None)
        return active_view.UpdateUI(command_id) and self.MainFrame.UpdateUI(command_id)
            
    def _InitCommands(self):
        files_menu = find_menu(_("&File"), self.Menubar)
        self.AddCommand(
            menuitems.ID_NEW,
            files_menu,
            _("&New..."),
            self.OnNew,
            image="toolbar/new.png",
            include_in_toolbar=True
        )
        self.AddCommand(
            menuitems.ID_OPEN,
            files_menu,
            _("&Open..."),
            self.OnOpen,
            image="toolbar/open.png",
            include_in_toolbar=True
        )
        self.AddDefaultCommand(
            menuitems.ID_CLOSE,
            files_menu,_("&Close"),
            self.OnClose
        )
        self.AddDefaultCommand(
            menuitems.ID_CLOSE_ALL,
            files_menu,
            _("&Close A&ll"),
            self.OnCloseAll,
            add_separator=True
        )

        self.AddDefaultCommand(
            menuitems.ID_SAVE,
            files_menu,
            _("&Save..."),
            self.OnFileSave,
            image="toolbar/save.png",
            include_in_toolbar=True
        )
        self.AddDefaultCommand(
            menuitems.ID_SAVEAS,
            files_menu,
            _("Save &As..."),
            self.OnFileSaveAs
        )
        
        self.AddDefaultCommand(
            menuitems.ID_SAVEALL,
            files_menu,
            _("Save All"),
            self.OnFileSaveAll,
            image="toolbar/saveall.png",
            include_in_toolbar=True,
            add_separator=True
        )
                    
        self.AddCommand(
            menuitems.ID_EXIT,
            files_menu,
            _("E&xit"),
            self.Quit,
            image="exit.png"
        )
        
        #设置历史文件菜单为Files菜单
        self.GetDocumentManager().FileHistoryUseMenu(files_menu)
        #加载历史文件记录到Files菜单最后
        self.GetDocumentManager().FileHistoryAddFilesToMenu()
        self.MainFrame._InitCommands()
        views_menu = find_menu(_("&View"), self.Menubar)
        self.AddCommand(
            menuitems.ID_SHOW_FULLSCREEN,
            views_menu,
            _("Show FullScreen"),
            self.ShowFullScreen,
            image="monitor.png"
        )
        run_menu = find_menu(_("&Run"), self.Menubar)
        tools_menu = find_menu(_("&Tools"), self.Menubar)
        help_menu = find_menu(_("&Help"), self.Menubar)
        self.AddDefaultCommand(
            menuitems.ID_RUN,
            run_menu,
            _("&Start Running"),
            self.Run,
            image="toolbar/run.png",
            include_in_toolbar=True
        )
        self.AddDefaultCommand(
            menuitems.ID_DEBUG,
            run_menu,
            _("&Start Debugging"),
            self.Debug,
            image="toolbar/debug.png",
            include_in_toolbar=True,
        )
        self.debuger_combo = self.MainFrame.GetToolBar().AddCombox()
        self.debuger_combo.addItem(_("Configuration"))
        self.debuger_combo.setCurrentIndex(-1)
        self.debuger_combo.currentIndexChanged.connect(self.selectdebugger)
        self.AddCommand(
            menuitems.ID_OPEN_TERMINAL,
            tools_menu,
            _("&Open terminator..."),
            self.OpenTerminator,
            image="cmd.png"
        )
        
        self.AddCommand(
            menuitems.ID_PREFERENCES,
            tools_menu,
            _("&Options..."),
            self.OnOptions,
            image=self.GetImage("prefer.png"),
        )
        
        self.AddCommand(
            menuitems.ID_OPEN_DOCUMENTATION,
            help_menu,
            _("Product documentation"),
            handler=self.OpenDocumentation,
            image=self.GetImage("documentation.png")
        )
        self.AddCommand(
            menuitems.ID_GOTO_OFFICIAL_WEB,
            help_menu,
            _("&Visit NovalIDE Website"),
            self.GotoWebsite
        )
        self.AddCommand(
            menuitems.ID_FEEDBACK,
            help_menu,
            _("Feedback"),
            self.Feedback
        )
        
    @ui_utils.update_toolbar
    @ui_utils.check_debugger
    def Run(self):
        '''
            在终端中运行程序
        '''
        self.GetDebugger().Run()
        
    @ui_utils.update_toolbar
    @ui_utils.check_debugger
    def Debug(self):
        '''
            在程序调试窗口中运行程序
        '''
        self.GetDebugger().Debug()
        
    def OpenTerminator(self,filename=None):
        if filename:
            if os.path.isdir(filename):
                cwd = filename
            else:
                cwd = os.path.dirname(filename)
        else:
            cwd = os.getcwd()

        if utils.is_windows():
            subprocess.Popen('start cmd.exe',shell=True,cwd=cwd)
        else:
            subprocess.Popen('gnome-terminal',shell=True,cwd=cwd)
        
    def GetImage(self,file_name):
        return qtimage.load_icon(file_name)
        
    def _init_sidebars(self):
        from .sidebar import logframe, sidebar, fileview
        from .findrep.resultview import FindResultsview
        from .project.browser import ProjectViewer
        #首先加载日志窗口,日志窗口,其它插件才能写入日志到日志窗口中
        if self.GetDebug():
            self.MainFrame.AddView(
                "Logs",
                logframe.LogFrame,
                _("Logs"), 
                sidebar.SideBar.South,
                default_position_key=0,
                image_file="logview.png",
                active=True
            )
        self.MainFrame.AddView(
            SEARCH_RESULTS_VIEW_NAME,
            FindResultsview, 
            _("Search results"), 
            sidebar.SideBar.South,
            image_file="search.ico",
            default_position_key=1
        )
        self.MainFrame.AddView(
            PROJECT_VIEW_NAME,
            ProjectViewer,
            _("Project browser"), 
            sidebar.SideBar.West,
            default_position_key=0,
            image_file="project/project_view.ico",
            active=True
        )
        self.MainFrame.AddView(
            FILE_VIEW_NAME,
            fileview.FileFrame,
            _("File View"), 
            sidebar.SideBar.West,
            default_position_key=1,
            image_file="filenav_nav.png"
        )

    def _InitMainFrame(self):
        from .mainwindow import IDEMainWindow

        self.frame = IDEMainWindow(self._splash)
        get_app().lastWindowClosed.connect(get_app().quit)
        #最大化窗口
        if utils.profile_get_int(globalkeys.FRAME_MAXIMIZED_KEY,True):
            self.frame.showMaximized()
        
        
    @ui_utils.update_toolbar
    def OnOpen(self):
        docs = self.GetDocumentManager().CreateDocument('',DEFAULT_DOCMAN_FLAGS)
        #检查文件扩展名是否有对应的文件扩展插件
        #if docs:
         #   ui_utils.CheckFileExtension(docs[0].GetFilename(),False)

    @ui_utils.update_toolbar     
    def OnNew(self):
        self.GetDocumentManager().CreateDocument('',DOC_NEW)
        
    @ui_utils.update_toolbar
    def OnClose(self):
        self.MainFrame.CloseDoc()
        
    @ui_utils.update_toolbar
    def OnCloseAll(self):
        self.MainFrame.CloseAllDocs()

    @ui_utils.update_toolbar
    def OnFileSave(self):
        """
        Saves the current document by calling wxDocument.Save for the current
        document.
        """
        doc = self.GetDocumentManager().GetCurrentDocument()
        if not doc:
            return
        doc.Save()

    @ui_utils.update_toolbar
    def OnFileSaveAs(self):
        """
        Calls wxDocument.SaveAs for the current document.
        """
        doc = self.GetDocumentManager().GetCurrentDocument()
        if not doc:
            return
        self.SaveAsDocument(doc)
        
    @ui_utils.update_statusbar
    def SaveAsDocument(self,doc):
        '''
            另存为文件
        '''
        #另存文件之前的文件名
        old_filename = doc.GetFilename()
        if not doc.SaveAs():
            return
        #另存文件之后的文件名
        new_filename = doc.GetFilename()
        #比较另存文件之前和之后的文件名,如果不一致,则从监视中删除先前的文件,并监视新的文件名
        if doc.IsWatched and not fileutils.ComparePath(new_filename,old_filename):
            doc.FileWatcher.RemoveFile(old_filename)

    @ui_utils.update_toolbar
    def OnFileSaveAll(self):
        """
        Saves all of the currently open documents.
        """
        docs = self.GetDocumentManager().GetDocuments()
        # save child documents first
        for doc in docs:
            doc.Save()
        
    def AllowClose(self):
        #程序退出时问询所有插件是否可以退出
        try:
            if not self._pluginmgr.Exit(exit=False):
                return False
        except:
            utils.get_logger().error("query plugin exit error...")
        #先询问是否允许关闭调试器
#        if not self.GetDebuggerClass().CloseDebugger():
 #           return False
        #查询是否允许关闭所有窗口
       # if not self.MainFrame.CloseWindows():
        #    return False
        if not self.GetDocumentManager().Clear(force=False):
            return False
        return True

    def SaveLayout(self):
        #退出时保存窗口是否最大化的标志
        utils.profile_set(globalkeys.FRAME_MAXIMIZED_KEY, self.MainFrame.isMaximized())
        if not self.MainFrame.isMaximized():
            # can't restore zoom on mac without setting actual dimensions
            #程序退出时记住界面的坐标位置以及宽高
            utils.profile_set(globalkeys.FRAME_TOP_LOC_KEY, self.MainFrame.y())
            #TODO:这里可能会出现错误:OverflowError: can't convert negative value to unsigned int
            utils.profile_set(globalkeys.FRAME_LEFT_LOC_KEY, self.MainFrame.x())
            utils.profile_set(globalkeys.FRAME_WIDTH_KEY, self.MainFrame.width())
            utils.profile_set(globalkeys.FRAME_HEIGHT_KEY, self.MainFrame.height())
        self.MainFrame.SaveLayout()
        
    def Quit(self):
        if not self.AllowClose():
            return
        #程序退出时通知所有插件退出
        try:
            if not self._pluginmgr.Exit():
                return
        except:
            utils.get_logger().error("plugin exit error....")
        UserDataDb.get_db().RecordEnd()
        self.SaveLayout()
        docposition.DocMgr.WriteBook()
        #保存插件信息
        self._pluginmgr.WritePluginConfig()
        super().Quit()

    @ui_utils.update_toolbar
    def OpenMRUFile(self, n):
        """
        Opens the appropriate file when it is selected from the file history
        menu.
        """
        filename = self._docManager.GetHistoryFile(n)
        if filename and os.path.exists(filename):
            self._docManager.CreateDocument(filename, DOC_SILENT)
        else:
            self._docManager.RemoveFileFromHistory(n)
            msgTitle = self.GetAppName()
            if not msgTitle:
                msgTitle = _("File Error")
            if filename:
                QMessageBox.critical(
                    self.MainFrame, 
                    msgTitle,
                    _("The file '%s' doesn't exist and couldn't be opened!") % filename
                )

    def SetCurrentProject(self):
        self.MainFrame.GetProjectView().SetCurrentProject()
        
    def load_skin(self):
        #设置程序样式,使程序更美观
        App.setStyle(DEFAULT_APP_STYLE)
        self.skin = Skin()
        self.skin.loadByName(utils.profile_get(globalkeys.APP_SKIN_KEY, DEFAULT_APP_SKIN))
        
        appCSS = ''
        if self.skin['dark']:
            import qdarkstyle
            appCSS = qdarkstyle.load_stylesheet(qt_api='pyqt5')
            #appCSS = appCSS.replace('QStatusBar QLabel',
            #                        'QStatusBar QComboBox')
            #appCSS = appCSS.replace('QStatusBar::item',
            #                        'QStatusBar QComboBox')

        # Avoid having rectangular frames on the status bar and
        # some application wide style changes
        adjustmentCSS = self.skin['appCSS']
        if adjustmentCSS:
            appCSS += '\n' + adjustmentCSS

        if appCSS:
            self.setStyleSheet(appCSS)
    
    def Feedback(self):
        fileutils.startfile("https://gitee.com/wekay/NovalIDE/issues")

    def GotoWebsite(self,):
        fileutils.startfile(ApiServer.HOST_SERVER_ADDR)
        
    def OnOptions(self):
        preference_dlg = preference.PreferenceDialog(self.MainFrame,selection=utils.profile_get("PrefereceOptionName",''))
        preference_dlg.exec_()
        
    def ShowFullScreen(self):
        if not self.MainFrame.isFullScreen():
            self.MainFrame.showFullScreen()
            return
            ui_utils.GetFullscreenDialog().Show()
            #全屏时是否隐藏菜单栏
            if utils.profile_get_int("HideMenubarFullScreen", False):
                self.ShowMenubar(False)
        else:
            self.MainFrame.showNormal()
           # ui_utils.GetFullscreenDialog().CloseDialog()
            
    def ShowMenubar(self,show=True):
        if show:
            pass
            
    def GetDefaultTextDocumentType(self):
        '''
            默认新建文本文档类型
        '''
        return SYNATAX_MANAGER.GetLexer(self.GetDefaultLangId()).GetDocTypeName()
        
    def GetDebugviewClass(self):
        return self._debugger_view_class

    def GetDebuggerClass(self):
        return self._debugger_class

    def GetDebugger(self):
        debugger = self.GetDebuggerClass()()
        current_project = self.MainFrame.GetProjectView(False).GetCurrentProject()
        debugger.SetCurrentProject(current_project)
        return debugger
        
    def add_backend(self,name,proxy_class,description,sort_key):
        self._backends[name] = BackendSpec(
            name,
            proxy_class,
            description,
            sort_key if sort_key is not None else description,
        )

        # assing names to related classes
        proxy_class.backend_name = name  # type: ignore

    def get_backends(self):
        return self._backends
        
    def ShowPluginsDlg(self,plugin_names):
        self.event_generate("ShowInstallPluginsDlg",plugin_names=plugin_names)
        
    def new_module(self):
        lexer = SYNATAX_MANAGER.GetLexer(self.GetDefaultLangId())
        temp = self.GetDocumentManager().FindTemplateForPath(
            "test.%s" % lexer.GetDefaultExt()
        )
        newDoc = temp.CreateDocument("", DOC_NEW)
        if newDoc:
            newDoc.SetDocumentName(temp.GetDocumentName())
            newDoc.SetDocumentTemplate(temp)
            newDoc.OnNewDocument()
    
    @ui_utils.update_toolbar 
    @abc.abstractmethod
    def selectdebugger(self, i):
        '''
            select a application debugger
        '''
        
    def OpenDocumentation(self):
        fileutils.startfile("https://wekay.gitee.io/novalide")