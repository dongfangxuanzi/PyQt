# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        generalopt.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-04-18
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
from .. import _,Locale,get_app
from ..lib.pyqt import QHBoxLayout, QPushButton,QComboBox, Qt, QFrame, QVBoxLayout, QLabel,QSizePolicy,QLineEdit,QSpinBox,QCheckBox
import glob
import os
from .. import globalkeys,constants
from .. import ui_lang
from ..util import ui_utils, utils, apputils

MIN_MRU_FILE_LIMIT = 1
MAX_MRU_FILE_LIMIT = 20

def GetAvailLocales():
    """Gets a list of the available locales that have been installed
    for the editor. Returning a list of strings that represent the
    canonical names of each language.
    @return: list of all available local/languages available

    """
    avail_loc = list()
    loc = glob.glob(os.path.join(apputils.mainModuleDir,'locale', "*"))
    for path in loc:
        the_path = os.path.join(path, "LC_MESSAGES", constants.APPLICATION_NAME.lower() + ".mo")
        if os.path.exists(the_path):
            avail_loc.append(os.path.basename(path))
    return avail_loc

def GetLocaleDict(loc_list):
    """Takes a list of cannonical locale names and by default returns a
    dictionary of available language values using the canonical name as
    the key. Supplying the Option OPT_DESCRIPT will return a dictionary
    of language id's with languages description as the key.
    @param loc_list: list of locals
    @keyword opt: option for configuring return data
    @return: dict of locales mapped to wx.LANGUAGE_*** values

    """
    lang_dict = dict()
    for lang in [x for x in dir(ui_lang) if x.startswith("LANGUAGE_")]:
        langId = getattr(ui_lang, lang)
        langOk = Locale.is_available(langId)
        if langOk:
            loc_i = Locale(langId)
            if loc_i.GetLanguageCanonicalName() in loc_list:
                lang_dict[loc_i.GetLanguageName()] = langId
    return lang_dict

def GetLangName(langId):
    """Gets the ID of a language from the description string. If the
    language cannot be found the function simply returns the default language
    @param lang_n: Canonical name of a language
    @return: wx.LANGUAGE_*** id of language

    """
    langOk = Locale.is_available(langId)
    if not langOk:
        raise RuntimeError("unknown lang id %d",langId)
        
    loc_i = Locale(langId)
    return loc_i.GetLanguageName()
    
def GetLangList():
    lang_list = []
    available_locales = GetAvailLocales()
    lang_ids = GetLocaleDict(available_locales).values()
    for i,lang_id in enumerate(lang_ids):
        loc_i = Locale(lang_id)
        lang_list.append((i,lang_id,loc_i.GetLanguageName()),)
    return lang_list

class GeneralOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    A general options panel that is used in the OptionDialog to configure the
    generic properties of a pydocview application, such as "show tips at startup"
    and whether to use SDI or MDI for the application.
    """


    def __init__(self, master, **kwargs):
        """
        Initializes the panel by adding an "Options" folder tab to the parent notebook and
        populating the panel with the generic properties of a pydocview application.
        """
        super().__init__()
        vbox = QVBoxLayout()
        vbox.setContentsMargins(0,0,0,0)
       # self._showTipsCheckBox = wx.CheckBox(self, -1, _("Show tips at start up"))
        #self._showTipsCheckBox.SetValue(config.ReadInt("ShowTipAtStartup", True))
        self.chkplugin_UpdateCheckBox = QCheckBox(_("Check plugin update at start up"))
        vbox.addWidget(self.chkplugin_UpdateCheckBox)
        self.chkplugin_UpdateCheckBox.setChecked(utils.profile_get_int("CheckPluginUpdate", True))

        self.lang_list = GetLangList()
        values = [_(lang[2]) for lang in self.lang_list]
        self.lang_id = utils.profile_get_int(globalkeys.LANGUANGE_ID_KEY,utils.get_lang_config())
        try:
            #安装包选择中文安装界面时,没有写入注册表,这里修复在界面的语言框里面显示为空的问题
            if self.lang_id == -1 and GetApp().locale.LangId != ui_lang.LANGUAGE_DEFAULT:
                self.lang_id = GetApp().locale.LangId
            lang_name = GetLangName(self.lang_id)
            #显示翻译后的语言名称
            lang = _(lang_name)
        except RuntimeError as e:
            utils.get_logger().error(e)
            lang = ""
        hbox = QHBoxLayout()
        hbox.setAlignment(Qt.AlignLeft)
        hbox.addWidget(QLabel(_("Language: ")))
        self.language_combox = QComboBox()
        self.language_combox.addItems(values)
        hbox.addWidget(self.language_combox)
        vbox.addLayout(hbox)
        
        self.enableMRUCheckBox = QCheckBox(_("Enable MRU Menu"))
        self.enableMRUCheckBox.setChecked(utils.profile_get_int(globalkeys.ENABLE_MRU_KEY, True))
        vbox.addWidget(self.enableMRUCheckBox)
        
        mru_hbox = QHBoxLayout()
        mru_hbox.setAlignment(Qt.AlignLeft)
        self.mru_ctrl = QSpinBox(value=utils.profile_get_int(globalkeys.MRU_LENGTH_KEY,constants.DEFAULT_MRU_FILE_NUM),
                               maximum=MAX_MRU_FILE_LIMIT,
                               minimum=MIN_MRU_FILE_LIMIT,
                               singleStep=1)
        mru_hbox.addWidget(QLabel(_("File History length in MRU Files") + "(%d-%d): " % (MIN_MRU_FILE_LIMIT,MAX_MRU_FILE_LIMIT)))
        mru_hbox.addWidget(self.mru_ctrl)
        self.enableMRUCheckBox.toggled.connect(self.checkEnableMRU)
        vbox.addLayout(mru_hbox)

        self.redirectOutputCheckBox = QCheckBox(_("Redirect Application exception output to Message dialog"))
        self.redirectOutputCheckBox.setChecked(utils.profile_get_int("RedirectTkException", True if get_app().GetDebug() else False))
        vbox.addWidget(self.redirectOutputCheckBox)
        vbox.addStretch(1)
        self.checkEnableMRU()
        self.setLayout(vbox)

    def checkEnableMRU(self):
        enableMRU = self.enableMRUCheckBox.isChecked()
        if enableMRU:
            self.mru_ctrl.setEnabled(True)
        else:
            self.mru_ctrl.setEnabled(False)

    def GetLangId(self):
        current = self.language_combox.current()
        if current == -1:
            return -1
        for i,lang in enumerate(self.lang_list):
            if i == current:
                return lang[1]

    def OnOK(self, optionsDialog):
        """
        Updates the config based on the selections in the options panel.
        """
        if self.enablemru_var.get() and self.mru_var.get() > consts.MAX_MRU_FILE_LIMIT:
            messagebox.showerror(GetApp().GetAppName(),_("MRU Length must not be greater than %d")%consts.MAX_MRU_FILE_LIMIT,parent=self)
            return False
            
        if self.enablemru_var.get() and self.mru_var.get() < 1:
            messagebox.showerror(GetApp().GetAppName(),_("MRU Length must not be less than 1"),parent=self)
            return False
            
       # utils.WriteInt("ShowTipAtStartup", self._showTipsCheckBox.GetValue())
        if self.GetLangId() != self.lang_id:
            messagebox.showinfo(_("Language Options"),_("Language changes will not appear until the application is restarted."),parent=self)
        utils.profile_set(consts.LANGUANGE_ID_KEY,self.GetLangId())
        utils.profile_set(consts.MRU_LENGTH_KEY,self.mru_var.get())
        utils.profile_set(consts.ENABLE_MRU_KEY,self.enablemru_var.get())
        utils.profile_set("RedirectTkException",self.redirect_output_var.get())
        utils.profile_set("CheckPluginUpdate",self.check_plugin_update_var.get())
        utils.profile_set("StartupAutoLogin",self.auto_login_var.get())
        return True

    def GetIcon(self):
        """ Return icon for options panel on the Mac. """
        return wx.GetApp().GetDefaultIcon()
