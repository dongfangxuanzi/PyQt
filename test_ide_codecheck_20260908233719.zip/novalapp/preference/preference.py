# -*- coding: utf-8 -*-
from .. import _
from .manager import PreferenceManager
from ..lib.pyqt import QDialog,QHBoxLayout,Qt,QPushButton,QMessageBox,QListWidget,QVBoxLayout,QFrame,QTreeWidget,QDialogButtonBox,QTreeWidgetItem
from ..util import ui_utils
ENVIRONMENT_OPTION_NAME = "Environment"

#option item names
GENERAL_ITEM_NAME = "General"
TEXT_ITEM_NAME = "Text"
PROJECT_ITEM_NAME = "Project"
FONTS_CORLORS_ITEM_NAME = "Fonts and Colors"
INTERPRETER_OPTION_NAME = "Interpreter"
INTERPRETER_CONFIGURATIONS_ITEM_NAME = "Configuration List"

EXTENSION_ITEM_NAME = "Extension"


PREFERENCE_DLG_WIDITH = 850
PREFERENCE_DLG_HEIGHT = 580



class PreferenceDialog(ui_utils.BaseModalDialog):
    
    def __init__(self, master,selection=None):
        super().__init__(_("Options"),master)
        #self.geometry("%dx%d" % (PREFERENCE_DLG_WIDITH,PREFERENCE_DLG_HEIGHT))
        if not selection:
            selection=ENVIRONMENT_OPTION_NAME+"/"+GENERAL_ITEM_NAME
        
        self.current_panel = None
        self.current_item = None
        self._optionsPanels = {}
        frame_box = QVBoxLayout()
        contentbox = QHBoxLayout()

        #设置path列存储模板路径,并隐藏改列 
        self.tree = QTreeWidget()
        contentbox.addWidget(self.tree)
        self.rootitem = self.tree.invisibleRootItem()
        #不显示表头
        self.tree.setHeaderHidden(True)
        self.tree.itemSelectionChanged.connect(self._on_select)

        # configure the only tree column
        
        right_box = QVBoxLayout()
        self.page_frame = QFrame()
        page_box = QVBoxLayout()
        self.page_frame.setLayout(page_box)
        right_box.addWidget(self.page_frame)
        
        bottom_separator = QFrame()
        bottom_separator.setEnabled(False)
        bottom_separator.setFrameShape(QFrame.HLine)
        bottom_separator.setFrameShadow(QFrame.Plain)
        right_box.addWidget(bottom_separator)
        contentbox.addLayout(right_box)
        
        frame_box.addLayout(contentbox)
        option_catetory,sel_option_name = self.GetOptionNames(selection)
        category_list = PreferenceManager.manager().GetOptionList()
        category_dct = PreferenceManager.manager().GetOptionPageClasses()
        for category in category_list:
            item = QTreeWidgetItem()
            item.setText(0,category)
            self.rootitem.addChild(item)
            option_panel_infos = category_dct[category]
            for noption_panel_info in option_panel_infos:
                name = noption_panel_info.name
                option_panel = noption_panel_info.option_class(self.page_frame)
                option_name = noption_panel_info.path
                self._optionsPanels[option_name] = option_panel
                child = QTreeWidgetItem()
                child.setData(0, Qt.UserRole, noption_panel_info)
                child.setText(0,name)
                item.addChild(child)
                #select the default item,to avoid select no item
                if name == GENERAL_ITEM_NAME and category == ENVIRONMENT_OPTION_NAME:
                    self.tree.setCurrentItem(child)
                if name == sel_option_name and category == option_catetory:
                    self.tree.setCurrentItem(child)
        self.create_standard_buttons(frame_box)
        self.setLayout(frame_box)
        
    def select_item(self,item):
        self.tree.focus(item)
        self.tree.see(item)
        self.tree.selection_set(item)
        
    def GetOptionNames(self,selection_name):
        names = selection_name.split("/")
        if 1 >= len(names):
            return "",selection_name
        return names[0],names[1]
        
    def GetOptionPanel(self,category,option_name):
        return self._optionsPanels[GetOptionName(category , option_name)]
        
    def _on_select(self):
        nodes = self.tree.selectedItems()
        sel = nodes[0]
        if sel.childCount() >0:
            sel = sel.child(0)
        option_panel_info = sel.data(0, Qt.UserRole)
        panel = self._optionsPanels[option_panel_info.path]
        if self.current_item is not None and sel != self.current_item:
            if not self.current_panel.Validate():
                self.tree.SelectItem(self.current_item)
                return 
        if self.current_panel is not None and panel != self.current_panel:
            self.current_panel.grid_forget()
        self.current_panel = panel
        self.page_frame.layout().addWidget(self.current_panel)
        
    def _ok(self, event=None):
        if not self.current_panel.Validate():
            return
        for name in self._optionsPanels:
            optionsPanel = self._optionsPanels[name]
            if not optionsPanel.OnOK(self):
                return
        sel = self.tree.selection()[0]
        if len(self.tree.get_children(sel)) > 0:
            sel = self.tree.get_children(sel)[0]
        text = self.tree.item(sel)['values'][0]
        utils.profile_set("PrefereceOptionName",text)
        ui_base.CommonModaldialog._ok(self,event)
        
    def _cancel(self, event=None):
        for name in self._optionsPanels:
            optionsPanel = self._optionsPanels[name]
            if hasattr(optionsPanel,"OnCancel") and not optionsPanel.OnCancel(self):
                return
        ui_base.CommonModaldialog._cancel(self,event)
