from ..common.singleton import Singleton
from typing import NamedTuple, Type

class OptionTemplate(NamedTuple):
    catlog: str
    name: str
    label: str
    path: str
    option_class: Type
    
def GetOptionName(caterory,name):
    return caterory + "/" + name

@Singleton
class PreferenceManager:
    
    def __init__(self):
        self._optionsPanelClasses = {}
        self.category_list = []
        
    def GetOptionPageClasses(self):
        return self._optionsPanelClasses

    def AddOptionsPanelClass(self,category,name,label, optionsPanelClass):
        path = GetOptionName(category,name)
        if category not in self._optionsPanelClasses:
            self._optionsPanelClasses[category] = [OptionTemplate(category,name,label,path,optionsPanelClass),]
            self.category_list.append(category)
        else:
            self._optionsPanelClasses[category].append(OptionTemplate(category,name,label,path,optionsPanelClass),)
            
    def GetOptionList(self):
        return self.category_list
        
    @staticmethod
    def manager():
        return PreferenceManager()
