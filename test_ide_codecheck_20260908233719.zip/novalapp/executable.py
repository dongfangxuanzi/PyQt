# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        executable.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-10
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
import os
import logging
from .util import strutils, utils

logger = logging.getLogger('ide.executable')


class Executable:
    def __init__(self,path, cwd=None, env=None, args=[]):
        self._path = path
        self._install_path = os.path.dirname(self._path)
        
    @property
    def path(self):
        return self._path
        
    @property
    def install_path(self):
        return self._install_path
        
    def get_cmd(self):
        return strutils.emphasis_path(self.path) + " " + ' '.join(args)
        
    def get_command_output(self, command, stderr=False):
        if isinstance(command, (list, tuple)):
            command = ' '.join(command)
        exe_command = "%s %s" % (strutils.emphasis_path(self.path), command) 
        logger.debug(f'run command is {exe_command}')
        return utils.GetCommandOutput(exe_command,stderr)
