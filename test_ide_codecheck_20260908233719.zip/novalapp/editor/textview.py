# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        text.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-03-11
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
from .. import get_app, _
from ..lib.document import Document
from ..lib.docview import View
from ..util import filewatcher
import codecs
import os
import sys
from ..util import utils, fileutils, ui_utils
##import noval.ui_base as ui_base
##import time
from ..syntax import lang
##import noval.util.strutils as strutils
import shutil
##from noval.filewatcher import FileEventHandler
##import noval.ui_common as ui_common
##import noval.misc as misc
from . import docposition
from .. import globalkeys, constants
from ..widgets import simpledialog
##import noval.ui_utils as ui_utils
##import noval.syntax.syntax as syntax
##import noval.editor.format as textformat
from .texteditor import TextEditor
from .textframe import TextFrame
from ..lib.pyqt import QVBoxLayout, QMessageBox, QFileDialog
from .. import menuitems
from ..util.filewatcher import FileEventHandler

def classifyws(s, tabwidth):
    raw = effective = 0
    for ch in s:
        if ch == " ":
            raw = raw + 1
            effective = effective + 1
        elif ch == "\t":
            raw = raw + 1
            effective = (effective // tabwidth + 1) * tabwidth
        else:
            break
    return raw, effective
    
def index2line(index):
    return int(float(index))


def line2index(line):
    return str(float(line))

class TextDocument(Document):
    
    ASC_FILE_ENCODING = "ascii"
    UTF_8_FILE_ENCODING = "utf-8"
    ANSI_FILE_ENCODING = "cp936"
    
    DEFAULT_FILE_ENCODING = ASC_FILE_ENCODING
    
    def __init__(self):
        super().__init__()
        self._inModify = False
        self.file_watcher = filewatcher.FileAlarmWatcher()
        self._is_watched = False
        self.file_encoding = TextDocument.DEFAULT_FILE_ENCODING
        self._is_new_doc = True
        self._is_loading_doc = False

    def GetSaveObject(self,filename):
        return codecs.open(filename, 'w',self.file_encoding)

    def DoSave(self):
        if self._is_watched:
            self.file_watcher.StopWatchFile(self)
        #文件保存后可能会改变,需要再此检测文件编码
        self.file_encoding = self.DetectDocumentEncoding()
        #在状态栏现实变化后的文件编码
        get_app().MainFrame.sbEncoding.setText(
            self.file_encoding
        )

    def GetOpenDocument(self,filepath,exclude_self=True):
        '''
            通过文件名查找打开文件
            exclude_self:是否排查自身
            
        '''
        if exclude_self and fileutils.ComparePath(
            self.GetFilename(),
            filepath
        ):
            return None
        doc = get_app().GetDocumentManager().GetDocument(filepath)
        return doc
        
    def SaveAs(self):
        """
        Prompts the user for a file to save to, and then calls OnSaveDocument.
        """
        docTemplate = self.GetDocumentTemplate()
        if not docTemplate:
            return False

        default_ext = docTemplate.GetDefaultExtension()
        if docTemplate.GetFileFilter() == "*.*":
            default_ext = ""
        descrs = get_app().GetDocumentManager().get_filters()
        initialfile = os.path.basename(self.GetFilename())
        if not initialfile.endswith(default_ext):
            initialfile += default_ext
        filename, filetype = QFileDialog.getSaveFileName(
            get_app().MainFrame,  
            _('Save As'),  
            initialfile,
            descrs# 设置文件扩展名过滤,用双分号间隔
           # initialfile=
        )
        if filename == "":
            return False
            
        #将路径转换成系统标志路径格式
        filename = fileutils.opj(filename)
        #检查文件名是否已经被打开的文件占用,如果占用了则不能保存文件
        if self.GetOpenDocument(filename):
            QMessageBox.warning(
                get_app().MainFrame,
                get_app().GetAppName(),
                _("File has already been opened,could not overwrite it.")
            )
            return False
            
        if not self.OnSaveDocument(filename):
            return False

        self.SetFilename(filename)
        self.SetTitle(fileutils.get_filename_from_path(filename))

        for view in self._documentViews:
            view.OnChangeFilename()

        if docTemplate.FileMatchesTemplate(filename):
            self.GetDocumentManager().AddFileToHistory(filename)
            
        return True
        
    @ui_utils.wait_cursor
    def OnSaveDocument(self, filename):
        """
        Constructs an output file for the given filename (which must
        not be empty), and calls SaveObject. If SaveObject returns true, the
        document is set to unmodified; otherwise, an error message box is
        displayed.
        """
        if not filename:
            return False

        msgTitle = get_app().GetAppName()
        if not msgTitle:
            msgTitle = _("File Error")

        self._is_loading_doc = False
        backupFilename = None
        fileObject = None
        copied = False
        try:
            self.DoSave()
            # if current file exists, move it to a safe place temporarily
            if os.path.exists(filename):

                # Check if read-only.
                if not os.access(filename, os.W_OK):
                    messagebox.showerror(msgTitle,"Could not save '%s'.  No write permission to overwrite existing file." % \
                                         fileutils.get_filename_from_path(filename))
                    return False

                backupFilename = "%s.bk%s" % (filename, 1)
                shutil.copy(filename, backupFilename)
                copied = True
            fileObject = self.GetSaveObject(filename)
            self.SaveObject(fileObject)
            fileObject.close()
            fileObject = None
            
            if backupFilename:
                os.remove(backupFilename)
        except Exception as e:
            utils.get_logger().exception("")
            if fileObject:
                fileObject.close()  # file is still open, close it, need to do this before removal 

            # save failed, remove copied file
            if backupFilename and copied:
                shutil.copy(backupFilename,filename)
                os.remove(backupFilename)
            utils.get_logger().exception('error save file')
            QMessageBox.critical(
                self.GetDocumentWindow(),
                msgTitle,
                _("Could not save '%s':  %s") % (fileutils.get_filename_from_path(filename), e)
            )
                          
            if not self._is_new_doc:
                self.SetDocumentModificationDate()
            return False

        self.SetFilename(filename, True)
        self.Modify(False)
        self.SetDocumentSaved(True)
        self._is_watched = True
        self._is_new_doc = False
        self.file_watcher.StartWatchFile(self)
        self.SetDocumentModificationDate()
        return True

    def DetectFileEncoding(self,filepath):
        file_encoding = TextDocument.DEFAULT_FILE_ENCODING
        try:
            file_encoding = fileutils.detect_file_encoding(filepath)
        except:
            utils.get_logger().exception("")
        #if detect file encoding is None,we should assume the file encoding is ansi,which cp936 encoding is instead
        if None == file_encoding or file_encoding.lower().find('iso') != -1:
            file_encoding = TextDocument.ANSI_FILE_ENCODING
        return file_encoding
        
    def DetectDocumentEncoding(self):
        view = self.GetFirstView()
        file_encoding = self.file_encoding
        #when the file encoding is accii or new document,we should check the document data contain chinese character,
        #the we should change the document encoding to utf-8 to save chinese character
        if file_encoding == self.ASC_FILE_ENCODING or self.IsNewDocument:
            guess_encoding = file_encoding.lower()
            if guess_encoding == self.ASC_FILE_ENCODING:
                guess_encoding = self.UTF_8_FILE_ENCODING
            result = fileutils.detect(view.GetValue().encode(guess_encoding))
            file_encoding = result['encoding']
            if None == file_encoding:
                file_encoding = TextDocument.ASC_FILE_ENCODING
        return file_encoding

    @ui_utils.wait_cursor
    def OnOpenDocument(self, filename):
        """
        Constructs an input file for the given filename (which must not
        be empty), and calls LoadObject. If LoadObject returns true, the
        document is set to unmodified; otherwise, an error message box is
        displayed. The document's views are notified that the filename has
        changed, to give windows an opportunity to update their titles. All of
        the document's views are then updated.
        """
        #文件在外部改变重新打开时检查界面文本是否更改需要保存
        if not self.OnSaveModified():
            return False
        self._is_loading_doc = True
        msgTitle = get_app().GetAppName()
        if not msgTitle:
            msgTitle = _("File Error")
        self.file_encoding = self.DetectFileEncoding(filename)
        fileObject = None
        try:
            if self.file_encoding == 'binary':
                fileObject = open(filename, 'rb')
                is_bytes = True
            else:
                fileObject = codecs.open(filename, 'r',self.file_encoding)
                is_bytes = False
            self.LoadObject(fileObject,is_bytes)
            fileObject.close()
            fileObject = None
        except Exception as e:
            utils.get_logger().exception("")
            if fileObject:
                fileObject.close()  # file is still open, close it 

            QMessageBox.critical(
                self.GetDocumentWindow(), 
                msgTitle,
                _("Could not open '%s':  %s") % (fileutils.get_filename_from_path(filename), e)
            )
            self._is_loading_doc = False
            return False

        self.SetDocumentModificationDate()
        self.SetFilename(filename, True)
        self.Modify(False)
        self.SetDocumentSaved(True)
        self.UpdateAllViews()
        self.file_watcher.AddFileDoc(self)
        self._is_watched = True
        self._is_new_doc = False
        rember_file_pos = get_app().GetConfig().ReadInt(globalkeys.REMBER_FILE_KEY, True)
        if rember_file_pos:
            pos = docposition.DocMgr.GetPos(filename)
            if pos[0] != None:
                self.GetFirstView().GetCtrl().cursorPosition = pos
        self._is_loading_doc = False
        return True

    @property
    def IsWatched(self):
        return self._is_watched

    @property
    def FileWatcher(self):
        return self.file_watcher

    def SaveObject(self, fileObject):
        view = self.GetFirstView()
        msg = {'doc':self,'data':view.GetValue()}
        #保存文件事件
       # GetApp().event_generate(constants.FILE_SAVEING_EVT,msg=msg)
        fileObject.write(msg['data'])
        view.SetModified(False)
        return True
        
    def LoadObject(self, fileObject,is_bytes=False):
        view = self.GetFirstView()
        data = fileObject.read()
        msg = {'doc':self,'data':data}
        #打开文件事件
#        GetApp().event_generate(constants.FILE_OPENING_EVT,msg=msg)
        if is_bytes:
            view.SetBinaryValue(msg['data'])
        else:
            view.SetValue(msg['data'])
        view.SetModified(False)
        return True

    def IsModified(self):
        filename = self.GetFilename()
        if filename and not os.path.exists(filename) and not self._is_new_doc:
            return True
        view = self.GetFirstView()
        if view:
            return view.IsModified()
        return False
    
    @property
    def IsNewDocument(self):
        return self._is_new_doc

    def Modify(self, modify):
        if self._inModify:
            return
        self._inModify = True
        view = self.GetFirstView()
        if not modify and view:
            #设置编辑器状态为未修改
            view.SetModified(False)
        super().Modify(modify) 
        self._inModify = False

class TextView(View, ui_utils.AlarmEventMixin):
    FILE_MODIFY_ANSWER = None
    FILE_MOVE_DELETED_ANSWER = None
    def __init__(self):
        super().__init__()
        ui_utils.AlarmEventMixin.__init__(self)
        self._textEditor = None
        self._markerCount = 0
        self.eol = ui_utils.get_eol(os.linesep)
        # Initialize the classes position manager for the first control
        # that is created only.
        if not docposition.DocMgr.IsInitialized():
            docposition.DocMgr.InitPositionCache()
         
    def GetCtrlClass(self):
        """ Used in split window to instantiate new instances """
        return TextEditor
    
    def GetLangId(self):
        return lang.ID_LANG_TXT

    def GetCtrl(self):
        return self._textEditor

    def SetCtrl(self, ctrl):
        self._textEditor = ctrl
            
    def OnCreate(self, doc, flags):
        frame = get_app().CreateDocumentFrame(self, doc, flags)
        self._text_frame = TextFrame(frame, self, text_class=self.GetCtrlClass())
        self._textEditor = self._text_frame.getEditor()
        #移到鼠标和光标实时在状态栏显示移动位置等
        get_app().MainFrame.GetNotebook().connectEditorWidget(self._text_frame)
    #    self.__cursorPositionChanged()
        
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._text_frame)
        self._textEditor.setFocus()
        self.update_appearance()
        #更新高亮行颜色
        self._textEditor._updateExtraSelections()
        return True
        
    def update_appearance(self):
        #self._text_frame.set_gutter_visibility(utils.profile_get_int("TextViewLineNumbers", True))
        #设置代码边界线长度
        view_right_edge = utils.profile_get_int("TextViewRightEdge", True)
        if view_right_edge:
            line_length_margin = utils.profile_get_int(
                "TextEditorEdgeGuideWidth",
                constants.DEFAULT_EDGE_GUIDE_WIDTH
            )
        else:
            line_length_margin = 0
        if line_length_margin > 0:
            self.GetCtrl().lineLengthEdge = constants.DEFAULT_EDGE_GUIDE_WIDTH
            self.GetCtrl().lineLengthEdgeColor = get_app().skin['edgeColor']
            self.GetCtrl().drawSolidEdge = True
        # 是否高亮文本当前行
        tag_current_line = utils.profile_get_int("TextHighlightCaretLine", True)
        if tag_current_line:
            self.GetCtrl().currentLineColor = get_app().skin['currentLinePaper']
        else:
            self.GetCtrl().currentLineColor = None
        
    def ToogleFullScreen(self,event):
        if GetApp().IsFullScreen:
            ui_utils.GetFullscreenDialog().CloseDialog()
        
    def ButtonRelease(self,event):
        self.ActivateView(event)
        self.RecordTrack()
        
    @ui_utils.update_toolbar
    @docposition.jumpto
    def RecordTrack(self):
        pass
        
    def ActivateView(self,event):
        self.SetFocus()
        #设置视图为活跃视图
        GetApp().GetDocumentManager().ActivateView(self)
        #设置状态栏行列号
        self.set_line_and_column()
        
    def _cmd_zoom_with_mouse(self, event):
        if event.delta > 0:
            self.UpdateFontSize(1)
        else:
            self.UpdateFontSize(-1)
        
    def set_pos(self):
        #获取当前行,列位置
        line, column = self._textEditor.cursorPosition
        if column is not None:
            get_app().MainFrame.sbPos.setText('Pos: ' + str(column + 1))
        else:
            get_app().MainFrame.sbPos.setText('Pos: n/a')
        if line is not None:
            get_app().MainFrame.sbLine.setText('Line: ' + str(line + 1))
        else:
            get_app().MainFrame.sbLine.setText('Line: n/a')
            
    def set_encoding(self):
        get_app().MainFrame.sbEncoding.setText(
            self.GetDocument().file_encoding
        )
        get_app().MainFrame.sbEncoding.setToolTip('')
        
    def set_eol(self):
        eol = self.eol
        if eol != constants.MIXED_CRLF:
            self.GetCtrl().eol = constants.EOL[eol]
            eol_label = self.GetCtrl().getEolIndicator()
        else:
            eol_label = 'MIXED'
        get_app().MainFrame.sbEol.setText(eol_label)

    @ui_utils.call_after
    @ui_utils.update_toolbar
    def OnModify(self):
        self.GetDocument().Modify(self.IsModified())

    def SetValue(self, value,keep_undo=False):
        self.GetCtrl().text = value
        #加载文件后需要禁止undo操作
 #       if not keep_undo:
#            self.GetCtrl().edit_reset()
      #  self._text_frame.update_gutter()
     #   self.GetCtrl().after(100,self.CheckEol,value)
        self.CheckEol(value)
        
    @ui_utils.call_after
    def CheckEol(self,value):
      #  end_line = self.GetCtrl().get_line_col(self.GetCtrl().index('end'))[0]
        check_mixed_eol = utils.profile_get_int("check_mixed_eol",False)
        mixed = False
        tmp = None
        line_eol = None
        #检查混合行尾时检查全部行,否则只检查前10行文本作为eol的判断依据
        checked_lines = 10
        i = 0
        for cur in value.splitlines(True):
            if cur.endswith(constants.CRLF):
                line_eol = constants.EOL_CRLF
            elif cur.endswith(constants.LF):
                line_eol = constants.EOL_LF
            elif cur.endswith(constants.CR):
                line_eol = constants.EOL_CR
            i += 1
            if line_eol is not None:
                self.eol = line_eol
            if check_mixed_eol:
                if line_eol and not tmp:
                    tmp = line_eol
                elif tmp:
                    if line_eol != tmp:
                        mixed = True
                        break
            elif i >=checked_lines:
                break
        if mixed:
            self.eol = constants.MIXED_CRLF
            msg = _("Mixed EOL characters detected.\n\n"
                "Would you like to format them to all be the same?")
            EOL_CHOICES = [
                "Old Machintosh (\\r)",
                "Unix (\\n)",
                "Windows (\\r\\n)"
            ]  
            name, ok  = simpledialog.askitem(_("Format EOL?"),msg,EOL_CHOICES,ui_utils.get_eol(os.linesep))
            eol = EOL_CHOICES.index(name)
            if ok:
                self.GetCtrl().eol = constants.EOL[eol]
                self.SetModified(True)
                self.GetDocument().Modify(True)
        get_app().MainFrame.GetNotebook().updateStatusBar()
    @docposition.jump
    def GotoLine(self,line):
        self.GetCtrl().gotoLine(line)
        self.set_pos()
        
    @docposition.jump
    def GotoPos(self,line,col):
        self.GetCtrl().GotoPos(line,col)

    def IsModified(self):
        if self._textEditor is not None: 
            return self.GetCtrl().document().isModified()
        return False

    def SetModified(self,modified):
        self.GetCtrl().document().setModified(modified)
        
    def SetFocus(self):
        if self._textEditor is not None:
            self._text_frame.setFocus()
        
    def GetValue(self):
        return self.GetCtrl().text
        
    #关闭文档以及文档标签页
    def OnClose(self, deleteWindow = True):
        if not View.OnClose(self, deleteWindow):
            return False
    
        document = self.GetDocument()
        if document.IsWatched:
            document.FileWatcher.RemoveFileDoc(document)
        #关闭文档时纪录当前光标位置,下次从新打开文件时定位到该位置
        if not document.IsNewDocument:
            docposition.DocMgr.AddRecord(
                [
                    document.GetFilename(),
                    #行列元组
                    self.GetCtrl().cursorPosition
                ]
            )
        self.Activate(False)
        #关闭窗口时销毁右键菜单
        self.GetCtrl()._menu.destroy()
        if deleteWindow and self.GetFrame():
            self.GetFrame().Destroy()

        return True

    def check_for_external_changes(self):
        if self._asking_about_external_change:
            return
        self._asking_about_external_change = True
        document = self.GetDocument()
        filename = document.GetFilename()
        if self._alarm_event == FileEventHandler.FILE_MODIFY_EVENT:
            if TextView.FILE_MODIFY_ANSWER != QMessageBox.YesToAll and TextView.FILE_MODIFY_ANSWER != QMessageBox.NoToAll:
                ret = QMessageBox.question(
                    self.GetFrame(),
                    _("Reload.."),
                    _("File \"%s\" has already been modified outside,Do You Want to reload it?")%filename,
                    QMessageBox.Yes|QMessageBox.No|QMessageBox.YesToAll|QMessageBox.NoToAll
                )
                TextView.FILE_MODIFY_ANSWER = ret
            else:
                ret = TextView.FILE_MODIFY_ANSWER
            if ret == QMessageBox.Yes or ret == QMessageBox.YesToAll:
                document.OnOpenDocument(filename)
                
        elif self._alarm_event == FileEventHandler.FILE_MOVED_EVENT or \
                self._alarm_event == FileEventHandler.FILE_DELETED_EVENT:
            if TextView.FILE_MOVE_DELETED_ANSWER != QMessageBox.YesToAll and TextView.FILE_MOVE_DELETED_ANSWER != QMessageBox.NoToAll:
                ret = QMessageBox.question(
                    self.GetFrame(),
                    _("Keep Document.."),
                    _("File \"%s\" has already been moved or deleted outside,Do You Want to keep it in Editor?") % filename,
                    QMessageBox.Yes|QMessageBox.No|QMessageBox.YesToAll|QMessageBox.NoToAll
                )
                TextView.FILE_MOVE_DELETED_ANSWER = ret
            else:
                ret = TextView.FILE_MOVE_DELETED_ANSWER
            if ret == QMessageBox.Yes or ret == QMessageBox.YesToAll:
                document.Modify(True)
            else:
                document.DeleteAllViews()
        self._asking_about_external_change = False
        ui_utils.AlarmEventMixin.check_for_external_changes(self)

    def ZoomView(self,delta = 0):
        editor = self.GetCtrl()
        if delta > 0:
            editor.zoomIn(1)
        else:
            editor.zoomOut(1)
                
    def AddText(self,txt,pos=None):
        if pos == None:
            line,col = self.GetCtrl().GetCurrentLineColumn()
        else:
            line,col = pos
        self.GetCtrl().insert("insert", txt,"%d.%d" % (line,col))
        
    def UpdateUI(self, command_id):
        if self.GetCtrl() is None:
            return False
        if command_id == menuitems.ID_SAVE:
            return self.GetDocument().IsModified()
        elif command_id in [
            menuitems.ID_INSERT_COMMENT_TEMPLATE,
            menuitems.ID_INSERT_DECLARE_ENCODING,
            menuitems.ID_UNITTEST,
            menuitems.ID_COMMENT_LINES,
            menuitems.ID_UNCOMMENT_LINES,
            menuitems.ID_RUN,
            menuitems.ID_DEBUG,
            menuitems.ID_GOTO_DEFINITION,
            menuitems.ID_SET_EXCEPTION_BREAKPOINT,
            menuitems.ID_STEP_INTO,
            menuitems.ID_STEP_NEXT,
            menuitems.ID_RUN_LAST,
            menuitems.ID_CHECK_SYNTAX,
            menuitems.ID_SET_PARAMETER_ENVIRONMENT,
            menuitems.ID_DEBUG_LAST,
            menuitems.ID_START_WITHOUT_DEBUG,
            menuitems.ID_AUTO_COMPLETE,
            menuitems.ID_TOGGLE_BREAKPOINT
        ]:
            return False
        elif command_id == menuitems.ID_UNDO:
            return self.GetCtrl().CanUndo()
        elif command_id == menuitems.ID_REDO:
            return self.GetCtrl().CanRedo()
        elif command_id in[menuitems.ID_CUT,menuitems.ID_COPY,menuitems.ID_CLEAR]:
            return self.GetCtrl().CanCopy()
        elif command_id == menuitems.ID_PASTE:
            return self.GetCtrl().CanPaste()
        elif command_id in [
            menuitems.ID_UPPERCASE,
            menuitems.ID_LOWERCASE,
            menuitems.ID_CLEAN_WHITESPACE,
            menuitems.ID_TAB_SPACE,
            menuitems.ID_SPACE_TAB
        ]:
            return self.GetCtrl().HasSelection()
        elif command_id in [
            menuitems.ID_EOL_MAC,
            menuitems.ID_EOL_UNIX,
            menuitems.ID_EOL_WIN
        ]:
            GetApp().MainFrame.GetNotebook().eol_var.set(self.GetCtrl().eol)
        return True
        
##class TextOptionsPanel(ui_utils.BaseConfigurationPanel):
##
##    def __init__(self, parent,  hasWordWrap = False):
##        ui_utils.BaseConfigurationPanel.__init__(self, parent)
##        self._hasWordWrap = hasWordWrap
##        self._hasTabs = False
##        if self._hasWordWrap:
##            self._wordWrapCheckBox = ttk.Checkbutton(self, text=_("Wrap words inside text area"))
##            self._wordWrapCheckBox.SetValue(wx.ConfigBase_Get().ReadInt(self._configPrefix + "EditorWordWrap", False))
##  #      self._viewWhitespaceCheckBox = wx.CheckBox(self, -1, _("Show whitespace"))
##   #     self._viewWhitespaceCheckBox.SetValue(config.ReadInt(self._configPrefix + "EditorViewWhitespace", False))
##    #    self._viewEOLCheckBox = wx.CheckBox(self, -1, _("Show end of line markers"))
##     #   self._viewEOLCheckBox.SetValue(config.ReadInt(self._configPrefix + "EditorViewEOL", False))
##      #  self._viewIndentationGuideCheckBox = wx.CheckBox(self, -1, _("Show indentation guides"))
##       # self._viewIndentationGuideCheckBox.SetValue(config.ReadInt(self._configPrefix + "EditorViewIndentationGuides", False))
##        self._viewRightEdgeVar = tk.IntVar(value=utils.profile_get_int("TextViewRightEdge", True))
##        viewRightEdgeCheckBox = ttk.Checkbutton(self,text=_("Show right edge"),variable=self._viewRightEdgeVar,command=self.CheckViewRightEdge)
##        viewRightEdgeCheckBox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x",pady=(consts.DEFAUT_CONTRL_PAD_Y,0))
##        
##        self._viewLineNumbersVar = tk.IntVar(value=utils.profile_get_int("TextViewLineNumbers", True))
##        viewLineNumbersCheckBox = ttk.Checkbutton(self,text=_("Show line numbers"),variable=self._viewLineNumbersVar)
##        viewLineNumbersCheckBox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x")
##
##        self._highlightCaretLineVar = tk.IntVar(value=utils.profile_get_int("TextHighlightCaretLine", True))
##        highlightCaretLineCheckBox = ttk.Checkbutton(self,text=_("Highlight Caret Line"),variable=self._highlightCaretLineVar)
##        highlightCaretLineCheckBox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x")
##        
##        self._highlightParenthesesVar = tk.IntVar(value=utils.profile_get_int("TextHighlightParentheses", True))
##        highlightParenthesesCheckBox = ttk.Checkbutton(self,text=_("Highlight parentheses"),variable=self._highlightParenthesesVar)
##        highlightParenthesesCheckBox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x")
##        
##        self._highlightSyntaxVar = tk.IntVar(value=utils.profile_get_int("TextHighlightSyntax", True))
##        highlightSyntaxCheckBox = ttk.Checkbutton(self,text=_("Highlight syntax elements"),variable=self._highlightSyntaxVar)
##        highlightSyntaxCheckBox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x")
##        
##  #      self._hasTabsVar = tk.IntVar(value=utils.profile_get_int("TextEditorUseTabs", False))
##   #     hasTabsCheckBox = ttk.Checkbutton(self,text=_("Use spaces instead of tabs"),variable=self._hasTabsVar)
##    #    hasTabsCheckBox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x")
##        
##
####        row = ttk.Frame(self)
####        indentWidthLabel = ttk.Label(row,text=_("Indent Width:"))
####        indentWidthLabel.pack(side=tk.LEFT)
####        self._indentWidthVar = tk.IntVar(value = utils.profile_get_int("TextEditorIndentWidth", 4))
####        indentWidthChoice = ttk.Combobox(row, values = ["2", "4", "6", "8", "10"],textvariable=self._indentWidthVar)
####        indentWidthChoice.pack(side=tk.LEFT)
####        row.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x",pady=(consts.DEFAUT_CONTRL_PAD_Y,0))
##        self.checkTabsVar = tk.IntVar(value=utils.profile_get_int("check_text_tabs", True))
##        chkTabBox = ttk.Checkbutton(self, text=_("Warn when text contains Tabs"),variable=self.checkTabsVar)
##        chkTabBox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x")
##        
##        row = ttk.Frame(self)
##        edgeWidthLabel = ttk.Label(row, text= _("Edge Guide Width:"))
##        edgeWidthLabel.pack(side=tk.LEFT)
##        self._edgeWidthVar = tk.IntVar(value = utils.profile_get_int("TextEditorEdgeGuideWidth", consts.DEFAULT_EDGE_GUIDE_WIDTH))
##        self.edge_spin_ctrl = tk.Spinbox(row, from_=0, to=160,textvariable=self._edgeWidthVar)
##        self.edge_spin_ctrl.pack(side=tk.LEFT)
##        row.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x",pady=(consts.DEFAUT_CONTRL_PAD_Y,0))
##        
##
##        self.autoIndentVar = tk.IntVar(value=utils.profile_get_int("AutoIndent", True))
##        autoIndentBox = ttk.Checkbutton(self, text=_("Auto Indent"),variable=self.autoIndentVar)
##        autoIndentBox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x",pady=consts.DEFAUT_CONTRL_PAD_Y)
##
##        sbox = ttk.LabelFrame(self, text=_("Smart tips"))
##        self.use_autocompletion_var =  tk.BooleanVar(value=utils.profile_get_int("UseAutoCompletion", True))
##        ttk.Checkbutton(sbox,text=_('Auto-Completion'),variable=self.use_autocompletion_var,command=self.SetAutoCompletion).pack(fill="x",padx=consts.DEFAUT_CONTRL_PAD_X)
##        
##        self.use_enhanced_autocompletion_var =  tk.BooleanVar(value=utils.profile_get_int("UseEnhancedAutoCompletion", False))
##        self.enhanced_autocompletion_btn = ttk.Checkbutton(sbox,text=_('Use Enhanced Auto-Completion'),variable=self.use_enhanced_autocompletion_var)
##        self.enhanced_autocompletion_btn.pack(fill="x",padx=consts.DEFAUT_CONTRL_PAD_X*2)
##        
##        self._tabCompletionVar = tk.IntVar(value=utils.profile_get_int("TextTabCompletion", True))
##        tabCompletionCheckBox = ttk.Checkbutton(sbox,text=_("Allow code completion with tab-key"),variable=self._tabCompletionVar)
##        tabCompletionCheckBox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x")
##        
##        self.show_tips_var =  tk.BooleanVar(value=utils.profile_get_int("ShowDocumentTips", True))
##        ttk.Checkbutton(sbox,text=_('Show tips when mouse hover over word'),variable=self.show_tips_var).pack(fill="x",padx=consts.DEFAUT_CONTRL_PAD_X)
##        sbox.pack(padx=consts.DEFAUT_CONTRL_PAD_X,fill="x")
##        
####        defaultEOLModelLabel = wx.StaticText(self, -1, _("Default EOL Mode:"))
####        self.eol_model_combox = wx.ComboBox(self, -1,choices=EOLFormat.EOLFormatDlg.EOL_CHOICES,style= wx.CB_READONLY)
####        if sysutilslib.isWindows():
####            eol_mode = config.ReadInt(self._configPrefix + "EditorEOLMode", wx.stc.STC_EOL_CRLF)
####        else:
####            eol_mode = config.ReadInt(self._configPrefix + "EditorEOLMode", wx.stc.STC_EOL_LF)
####        idx = EOLFormat.EOLFormatDlg.EOL_ITEMS.index(eol_mode)
####        self.eol_model_combox.SetSelection(idx)
##
##        self.CheckViewRightEdge()
##        self.SetAutoCompletion()
##        
##    def SetAutoCompletion(self):
##        if self.use_autocompletion_var.get():
##            self.enhanced_autocompletion_btn['state'] = tk.NORMAL
##        else:
##            self.enhanced_autocompletion_btn['state'] = tk.DISABLED
##        
##    def CheckViewRightEdge(self):
##        if self._viewRightEdgeVar.get():
##            self.edge_spin_ctrl['state'] = tk.NORMAL
##        else:
##            self.edge_spin_ctrl['state'] = tk.DISABLED
##
##    def OnOK(self, optionsDialog):
##        doViewStuffUpdate = False
##    #    doViewStuffUpdate = config.ReadInt(self._configPrefix + "EditorViewWhitespace", False) != self._viewWhitespaceCheckBox.GetValue()
##     #   config.WriteInt(self._configPrefix + "EditorViewWhitespace", self._viewWhitespaceCheckBox.GetValue())
##      #  doViewStuffUpdate = doViewStuffUpdate or config.ReadInt(self._configPrefix + "EditorViewEOL", False) != self._viewEOLCheckBox.GetValue()
##       # config.WriteInt(self._configPrefix + "EditorViewEOL", self._viewEOLCheckBox.GetValue())
##        #doViewStuffUpdate = doViewStuffUpdate or config.ReadInt(self._configPrefix + "EditorViewIndentationGuides", False) != self._viewIndentationGuideCheckBox.GetValue()
##        #config.WriteInt(self._configPrefix + "EditorViewIndentationGuides", self._viewIndentationGuideCheckBox.GetValue())
##        doViewStuffUpdate = doViewStuffUpdate or utils.profile_get_int("TextViewRightEdge", False) != self._viewRightEdgeVar.get()
##        utils.profile_set( "TextViewRightEdge", self._viewRightEdgeVar.get())
##        
##        doViewStuffUpdate = doViewStuffUpdate or utils.profile_get_int("TextViewLineNumbers", True) != self._viewLineNumbersVar.get()
##        utils.profile_set("TextViewLineNumbers", self._viewLineNumbersVar.get())
##        
##        doViewStuffUpdate = doViewStuffUpdate or utils.profile_get_int("TextHighlightCaretLine", True) != self._highlightCaretLineVar.get()
##        utils.profile_set("TextHighlightCaretLine", self._highlightCaretLineVar.get())
##        
##        doViewStuffUpdate = doViewStuffUpdate or utils.profile_get_int("TextHighlightParentheses", True) != self._highlightParenthesesVar.get()
##        utils.profile_set("TextHighlightParentheses", self._highlightParenthesesVar.get())
##        
##        doViewStuffUpdate = doViewStuffUpdate or utils.profile_get_int("TextHighlightSyntax", True) != self._highlightSyntaxVar.get()
##        utils.profile_set("TextHighlightSyntax", self._highlightSyntaxVar.get())
##        
##      #  if sysutilslib.isWindows():
##       #     default_eol_mode = wx.stc.STC_EOL_CRLF
##        #else:
##         #   default_eol_mode = wx.stc.STC_EOL_LF
##        #eol_mode = EOLFormat.EOLFormatDlg.EOL_ITEMS[self.eol_model_combox.GetSelection()]
##        #doViewStuffUpdate = doViewStuffUpdate or config.ReadInt(self._configPrefix + "EditorEOLMode", default_eol_mode) != eol_mode
##        #config.WriteInt(self._configPrefix + "EditorEOLMode", eol_mode)
##        if self._viewRightEdgeVar.get():
##            doViewStuffUpdate = doViewStuffUpdate or utils.profile_get_int("TextEditorEdgeGuideWidth", consts.DEFAULT_EDGE_GUIDE_WIDTH) != self._edgeWidthVar.get()
##            utils.profile_set("TextEditorEdgeGuideWidth", self._edgeWidthVar.get())
##       # if self._hasFolding:
##        #    doViewStuffUpdate = doViewStuffUpdate or config.ReadInt(self._configPrefix + "EditorViewFolding", True) != self._viewFoldingCheckBox.GetValue()
##         #   config.WriteInt(self._configPrefix + "EditorViewFolding", self._viewFoldingCheckBox.GetValue())
##        #if self._hasWordWrap:
##          #  doViewStuffUpdate = doViewStuffUpdate or config.ReadInt(self._configPrefix + "EditorWordWrap", False) != self._wordWrapCheckBox.GetValue()
##           # config.WriteInt(self._configPrefix + "EditorWordWrap", self._wordWrapCheckBox.GetValue())
##        if self._hasTabs:
##            doViewStuffUpdate = doViewStuffUpdate or not config.ReadInt(self._configPrefix + "EditorUseTabs", True) != self._hasTabsCheckBox.GetValue()
##            config.WriteInt(self._configPrefix + "EditorUseTabs", not self._hasTabsCheckBox.GetValue())
##            newIndentWidth = int(self._indentWidthChoice.GetStringSelection())
##            oldIndentWidth = config.ReadInt(self._configPrefix + "EditorIndentWidth", 4)
##            if newIndentWidth != oldIndentWidth:
##                doViewStuffUpdate = True
##                config.WriteInt(self._configPrefix + "EditorIndentWidth", newIndentWidth)
##        GetApp().MainFrame.GetNotebook().update_appearance()
##        utils.profile_set("TextTabCompletion",self._tabCompletionVar.get())
##        utils.profile_set("check_text_tabs",self.checkTabsVar.get())
##        utils.profile_set("UseAutoCompletion",self.use_autocompletion_var.get())
##        if self.use_autocompletion_var.get():
##            utils.profile_set("UseEnhancedAutoCompletion",self.use_enhanced_autocompletion_var.get())
##        else:
##            utils.profile_set("UseEnhancedAutoCompletion",False)
##        #使用自动完成增强功能时需要安装自动完成插件  
##        if self.use_autocompletion_var.get() and self.use_enhanced_autocompletion_var.get():
##            plugin_dist = GetApp().GetPluginManager().GetPluginDistro('AutoCompletion')
##            if plugin_dist is None:
##                ok = messagebox.askokcancel(GetApp().GetAppName(),_("You need to install 'AutoCompletion' plugin if you want to use enhanced auto-completion"))
##                if ok:
##                    GetApp().ShowPluginsDlg(['AutoCompletion'])
##        utils.profile_set("ShowDocumentTips",self.show_tips_var.get())
##        utils.profile_set("AutoIndent",self.autoIndentVar.get())
##        return True
##               
##         
##    def GetIcon(self):
##        return getTextIcon()
