# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        imageviewer.py
# Purpose:     图片查看器,浏览所有支持图片类型
#
# Author:      wukan
#
# Created:     2019-01-21
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------
import os
from .. import get_app, _
from ..lib.document import Document
from ..lib.docview import View
from ..lib.pyqt import (
    QMessageBox,
    QLabel,
    QScrollArea,
    pyqtSignal,
    QPalette,
    QSizePolicy,
    Qt,
    QHBoxLayout,
    QImage,
    QPixmap
)
from ..util import utils
from ..qtimage import load_image
from .. import menuitems


class PixmapWidget(QScrollArea):

    """The pixmap widget"""

    sigEscapePressed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)

        self.pixmapLabel = QLabel()
        self.pixmapLabel.setBackgroundRole(QPalette.Base)
        self.pixmapLabel.setSizePolicy(QSizePolicy.Ignored,
                                       QSizePolicy.Ignored)
        self.pixmapLabel.setScaledContents(True)

        self.zoom = 1.0
        self.info = ""
        self.formatInfo = ""
        #查找文本字符串
        self.selectedText = ''
        self.fileSize = 0

        self.setBackgroundRole(QPalette.Dark)
        self.setWidget(self.pixmapLabel)
        self.setAlignment(Qt.AlignCenter)

    def loadFromFile(self, fileName):
        """Loads a pixmap from a file"""
        image = QImage(fileName)
        if image.isNull():
            raise Exception("Unsupported pixmap format (" + fileName + ")")

        self.pixmapLabel.setPixmap(QPixmap.fromImage(image))
        self.pixmapLabel.adjustSize()

        self.fileSize = os.path.getsize(fileName)
        if self.fileSize < 1024:
            fileSizeString = str(self.fileSize) + "bytes"
        else:
            kiloBytes = self.fileSize / 1024
            if (self.fileSize % 1024) >= 512:
                kiloBytes += 1
            fileSizeString = str(kiloBytes) + "kb"
        self.info = str(image.width()) + "px/" + \
            str(image.height()) + "px/" + fileSizeString
        try:
            self.formatInfo = FORMAT_STRINGS[image.format()]
        except:
            self.formatInfo = "Unknown"

    def setPixmap(self, pixmap):
        """Shows the provided pixmap"""
        pix = QPixmap.fromImage(pixmap)
        self.pixmapLabel.setPixmap(pix)
        self.pixmapLabel.adjustSize()

        self.info = str(pix.width()) + "px/" + str(pix.height()) + "px"
        self.formatInfo = str(pix.depth()) + " bpp"

    def keyPressEvent(self, event):
        """Handles the key press events"""
        if event.key() == Qt.Key_Escape:
            self.sigEscapePressed.emit()
            event.accept()
        else:
            QScrollArea.keyPressEvent(self, event)

    def resetZoom(self):
        """Resets the zoom"""
        self.zoom = 1.0
        self.pixmapLabel.adjustSize()

    def doZoom(self, factor):
        """Performs zooming"""
        self.zoom *= factor
        self.pixmapLabel.resize(self.zoom * self.pixmapLabel.pixmap().size())

        self.__adjustScrollBar(self.horizontalScrollBar(), factor)
        self.__adjustScrollBar(self.verticalScrollBar(), factor)

    def __adjustScrollBar(self, scrollBar, factor):
        """Adjusts a scrollbar by a certain factor"""
        scrollBar.setValue(int(factor * scrollBar.value() +
                               ((factor - 1) * scrollBar.pageStep() / 2)))

    def setReadOnly(self, newValue):
        """Make it similar to a text editor"""


class ImageDocument(Document):
    def OnOpenDocument(self, filename):
        '''
        '''
        try:
            self.GetFirstView().GetCtrl().loadFromFile(filename)
        except Exception as ex:
            utils.get_logger().exception(f'load image:{filename} error')
            QMessageBox.critical(
                get_app().MainFrame, 
                _("Open Image File"),
                _("Error loading '%s'. %s") % (self.GetPrintableName(), ex)
            )
            return False
        self.SetDocumentModificationDate()
        self.SetFilename(filename, True)
        self.Modify(False)
        self.SetDocumentSaved(True)
        self.UpdateAllViews()
        return True


class ImageView(View):

    #----------------------------------------------------------------------------
    # Overridden methods
    #----------------------------------------------------------------------------

    def __init__(self):
        super().__init__()
        self._viewer = None

    def OnCreate(self, doc, flags):
        frame = get_app().CreateDocumentFrame(self, doc, flags)
        self._viewer = PixmapWidget(frame)
       # self._viewer.sigEscapePressed.connect(self.__onEsc)
        hLayout = QHBoxLayout()
        hLayout.setContentsMargins(0, 0, 0, 0)
        hLayout.setSpacing(0)
        hLayout.addWidget(self._viewer)
        frame.setLayout(hLayout)
        self.Activate()
        return True

    def SetFocus(self):
        if self._viewer is not None:
            self._viewer.pixmapLabel.setFocus()

    def OnClose(self, deleteWindow = True):
        self.Activate(False)
        if deleteWindow and self.GetFrame():
            self.GetFrame().Destroy()
        return True
        
    def OnActivateView(self, activate, activeView, deactiveView):
        if activate and activeView:
            pass
           ### wx.GetApp().MainFrame.GetStatusBar().Reset()
        
    def set_pos(self):
        '''
            图片视图不在状态栏显示行列号
        '''
        get_app().MainFrame.sbPos.setText('Pos: n/a')
        get_app().MainFrame.sbLine.setText('Line: n/a')
        
    def set_encoding(self):
        get_app().MainFrame.sbEncoding.setText('   ')
        
    def set_eol(self):
        get_app().MainFrame.sbEol.setText(' ')
        
    def UpdateUI(self, command_id):
        '''
            图片视图只允许关闭菜单有效
        '''
        if command_id in [menuitems.ID_CLOSE,menuitems.ID_CLOSE_ALL,menuitems.ID_ZOOM_IN,menuitems.ID_ZOOM_OUT]:
            return True
        return super().UpdateUI(command_id)

    def GotoLine(self,line):
        '''
            图片视图不能跳转到行,实现一个空方法
        '''
        pass

    def ZoomView(self,delta = 0):
        '''
            实现图片的放大缩小
        '''
        #当前大小
        if delta > 0:
            self._viewer.doZoom(1.25)
        else:
            self._viewer.doZoom(0.8)
        
    def __onEsc(self):
        """Triggered when Esc is pressed"""
        self.sigEscapePressed.emit()
        
    def GetCtrl(self):
        return self._viewer