# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        NovalIDE.py
# Purpose:
#
# Author:      wukan
#
# Created:     2019-01-08
# Copyright:   (c) wukan 2019
# Licence:     GPL-3.0
#-------------------------------------------------------------------------------


from novalapp.launcher import run
import novalapp.prog_lang as prog_lang
#设置软件运行的语言,默认为Python
run(prog_lang.LANGUAGE_DEFAULT)

