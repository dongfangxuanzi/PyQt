#!/bin/bash

env_dir=/opt/ttwxenv
src_dir=${env_dir}/ttwx-server/devops

source ${env_dir}/bin/activate

p=$1



fab -f ${src_dir}/celery.py $p



