from bz2 import BZ2File
from ..common import compat
from .. import get_app, _
from ..lib.pyqt import QMessageBox, QScrollArea, QPalette, QSizePolicy, Qt, QListWidget, QSortFilterProxyModel
import os
from .. import qtimage
from ..editor.commonview import NocreateView
from ..lib.document import Document
from ..plugin import iface, plugin
from ..util import strutils, utils
from ..lib.template import DocTemplate, TEMPLATE_NO_CREATE






class ZipLoaderPlugin(plugin.Plugin):
    """plugin description here..."""

    plugin.Implements(iface.MainWindowI)

    def PlugIt(self, parent):
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing ziploader plugin")
        zipfile_template = DocTemplate(
            get_app().GetDocumentManager(),
            _("Zip File"),
            "*.zip;*.bz2",
            os.getcwd(),
            ".zip",
            "ZipFile Document",
            _("ZipFile Viewer"),
            ZipDocument,
            ZipView,
            # could not be newable
            TEMPLATE_NO_CREATE,
            icon=qtimage.load_icon("zip.png")
        )
        get_app().GetDocumentManager().AssociateTemplate(zipfile_template)
       # get_app().MainFrame.GetProjectView(False).tree.RebuildLookupIcon()
