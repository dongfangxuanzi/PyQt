import logging

log=logging.getLogger(__name__)
num_str = some_num.__str__() # [unnecessary-dunder-call]
num_repr = some_num.__add__(2) # [unnecessary-dunder-call]
my_repr = my_module.my_object.__repr__() # [unnecessary-dunder-call]

MY_CONTAINS_BAD = {1, 2, 3}.__contains__(1) # [unnecessary-dunder-call]
MY_CONTAINS_GOOD = 1 in {1, 2, 3} # todo ggggggg

def foo1(x, y, z):
    MY_CONTAINS_BAD=False
    for i in x:
        if i > y:  # [no-else-break]
            break
        else:
            a = z
    return

def test_W0120_for():
    dic1 = dict()
    dct2 = dict(a=1,b=2)
    dct3.update(dict(a=5,c=6))
    for i in range(10):
        if i>9:
            return i
    else:
        return -1
        
def test_W0120_while():
    while i:
        if i>9:
            return i
        i +=1
    else:
        return -1
        
def func1(a):
    raise
    
def func2(b):
    return

class A:
    # pylint: disable = ggggg
    # pylint: disable=kkkk
    def __init__(self):
        self.name = 'a'
        self.out()
    def method1(self):
        print('this is another method1')

    def out(self, msg):
        print(self.name)
        
    def method1(self):
        print('this is method1')


class B(A):
    def __init__(self):
        self.name = 'b'
        self.age = 11
        self.out()
        
    def out(self, doc,msg):
        print(self.age)
        
    def set_age(self, age):
        if self.age <=0:
            self.age =0
        self.age = age
        if self.age >=100:
            self.age =100
        self.addr = 'hubei'

class C(A):
    def __init__(self, a, b): ...
    
    def __setitem__(self, key, item): setattr(self.obj, key, item)
    def __delitem__(self, key): delattr(self.obj, key)
    
    
    def OnResourceViewToolClicked(self, event):
        id = event.GetId()
        if id in (ResourceView.REFRESH_PATH_ID, ResourceView.ADD_FOLDER_ID):
            return self.dir_ctrl.ProcessEvent(event)
    def OnToolClicked(self, id):
        super().OnToolClicked(id)
        if id == self.TERMINATE_ALL_PROCESS_ID:
            self.ShutdownAllRunners()
            
def test():
    print(a)
    '''todo
    this is pointless string statement
    '''
    endstr = '....'
    logging.error("this a logger test:" + str(a))
    logging.warn("this a logger test:" + str(a) +",end str:" + endstr)
    log.warn('this is warn message')
    logging.info('hello, world:%s'%str(a))
    logging.info('hello, world:%s:%s'%(str(a), endstr))
    logging.debug('{},{}'.format('first ','sencond'))
    b = B()
    '''this is another pointless string statement'''
    if 1:
        logging.debug('1')
    else:
        '''else pointless string statement'''
        
    try:
        return Tracer._execute_prepared_user_code(self, statements, expression, global_vars, 'fix return call')
    finally:
        """
        from thonny.misc_utils import _win_get_used_memory
        print("Memory:", _win_get_used_memory() / 1024 / 1024)
        print("States:", len(self._saved_states))
        print(self._fulltags.most_common())
        """
        btn = Tag(
            name='button',
            attrs={'role': 'group', 'data-href': 'command:workbench.extensions.action.showLanguageExtensions', 'onclick': click_event}
        )

        attrs={'role': 'group', 'data-href': "command:workbench.extensions.action.showLanguageExtensions", 'onclick': click_event}
        
def func1(b,c):
    diskValues = {}
    for item in diskValues:
        val = diskValues[item]
        if item in self.__values:
            if type(self.__values[item]) != type(val):
                readErrors.append("Settings '" + item +
                                  "' type from the disk file " +
                                  self.__fullFileName +
                                  ' does not match the expected one. '
                                  'The default value is used.')
            else:
                self.__values[item] = val
        else:
            readErrors.append('Disk file ' + self.__fullFileName +
                              " contains extra value '" + item +
                              "'. It will be lost.")
    i =0
    if i>1 and i<10:
        return i
        
    for i in range(100):
        if i>56:
            return i
    else:
        return -1
        
    while i<100:
        if i>67:
            return i
        i+=1
    else:
        return -1
        
    if i<1:
        return 0
    elif i<2:
        return 1
    elif i<3:
        return 2
        
    if 100<i:
        return 4
    return -1
    
if __name__ == "__main__":
    a=1
    b=4
    c=5
    test()
    func1(1,2,3)