from ..lib.template import DocTemplate, TEMPLATE_NO_CREATE
from ..common import compat
from .. import get_app, _, newid
from ..lib.pyqt import QMessageBox,QScrollArea,QPalette,QSizePolicy,Qt,QListWidget,\
            QModelIndex, QRegExp, pyqtSignal, QSortFilterProxyModel
import os
from .. import qtimage
from ..editor.commonview import NocreateView
from ..lib.document import Document
from ..plugin import iface, plugin
from ..util import strutils, utils
from bz2 import BZ2File


class ZipWidget(QScrollArea):
    """The pixmap widget"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.listfiles = QListWidget()
        self.listfiles.setBackgroundRole(QPalette.Base)
        self.listfiles.setSizePolicy(QSizePolicy.Ignored,
                                     QSizePolicy.Ignored)
        # 允许子控件调整大小
        self.setWidgetResizable(True)
        self.setBackgroundRole(QPalette.Dark)
        self.setWidget(self.listfiles)
        self.setAlignment(Qt.AlignTop)

    def populate_filelist(self, filelist):
        self.listfiles.addItems(filelist)


class ZipDocument(Document):
    def OnOpenDocument(self, filename):
        '''
        解析压缩文件
        '''
        try:
            filelist = []
            ext = strutils.get_file_extension(filename)
            if ext == "zip":
                with zipfile.ZipFile(filename, 'r') as zfile:
                    for file_info in zfile.infolist():
                        utils.get_logger().debug(
                            "filename:%s, filesize:%d bytes, compress_size:%d bytes",
                            file_info.filename,
                            file_info.file_size,
                            file_info.compress_size
                        )
                        filelist.append(file_info.filename)
                self.GetFirstView().GetCtrl().populate_filelist(filelist)
            elif ext == "bz2":
                content = ''
                with BZ2File(filename, "r") as f:
                    for i, line in enumerate(f):
                        line = compat.ensure_string(line)
                        filelist.append(line.strip('\0').strip('\r').strip('\n'))
                self.GetFirstView().GetCtrl().populate_filelist(filelist)

        except Exception as ex:
            utils.get_logger().exception(f'load zipfile:{filename} error')
            QMessageBox.critical(
                get_app().MainFrame,
                _("Open Zip File"),
                _("Error loading '%s'. %s") % (self.GetPrintableName(), ex)
            )
            return False
        self.SetDocumentModificationDate()
        self.SetFilename(filename, True)
        self.Modify(False)
        self.SetDocumentSaved(True)
        self.UpdateAllViews()
        return True


class ZipView(NocreateView):

    # ----------------------------------------------------------------------------
    # Overridden methods
    # ----------------------------------------------------------------------------

    def __init__(self):
        super().__init__()
        self._viewer = None

    def OnCreate(self, doc, flags):
        frame = get_app().CreateDocumentFrame(self, doc, flags)
        frame.attach_horizontal_layout()
        self._viewer = ZipWidget(frame)
        self._viewer.setSizePolicy(QSizePolicy.Expanding,
                                   QSizePolicy.Expanding)
        layout = frame.layout()
        layout.addWidget(self._viewer)
        self.Activate()
        return True

    def GetCtrl(self):
        return self._viewer


class ZipLoaderPlugin(plugin.Plugin):
    """plugin description here..."""

    plugin.Implements(iface.MainWindowI)

    def PlugIt(self, parent):
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing ziploader plugin")
        zipfile_template = DocTemplate(
            get_app().GetDocumentManager(),
            _("Zip File"),
            "*.zip;*.bz2",
            os.getcwd(),
            ".zip",
            "ZipFile Document",
            _("ZipFile Viewer"),
            ZipDocument,
            ZipView,
            # could not be newable
            TEMPLATE_NO_CREATE,
            icon=qtimage.load_icon("zip.png")
        )
        get_app().GetDocumentManager().AssociateTemplate(zipfile_template)
       # get_app().MainFrame.GetProjectView(False).tree.RebuildLookupIcon()
