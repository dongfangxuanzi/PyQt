#########################################################################
# File Name: restart_all_dockers.sh
# Author: wukan
# mail: kan.wu@genetalks.com
# Created Time: Wed 27 Apr 2016 09:31:55 AM CST
#########################################################################
#!/bin/bash

workdir=/raid0/nipt-workflow


function remove_all_containers() {
	docker stop $(docker ps -q -a)
	docker rm $(docker ps -q -a)
}

function start_all_containers() {
	$workdir/0-zookeeper/start_zookeeper.py
	$workdir/1-stagedb_logger_server/start_stagedb.py
	$workdir/1-stagedb_nitpresult_server/start_nipt_result_stagedb.py
	$workdir/2-gearman/start_gearman_for_localdebug.py
	$workdir/4-nipt_wf/start_workflow_task_for_localdebug.py
	$workdir/4-fastnipt_server/start_fastnipt_server_for_localdebug.py
	$workdir/5-nipt_align/start_align_task_for_localdebug.py
	$workdir/5-nipt_cnv/start_cnv_task_for_localdebug.py
	$workdir/5-nipt_gccor/start_gccor_task_for_localdebug.py
	$workdir/6-restful_api/restful_server/start.sh
}

###step1: stop & remove all docker containers
docker stop $(docker ps -q -a)
docker rm $(docker ps -q -a)

###step2: start all docker containters

$workdir/0-zookeeper/start_zookeeper.py
$workdir/1-stagedb_logger_server/start_stagedb.py
$workdir/1-stagedb_nitpresult_server/start_nipt_result_stagedb.py
$workdir/2-gearman/start_gearman_for_localdebug.py
$workdir/4-nipt_wf/start_workflow_task_for_localdebug.py
$workdir/4-fastnipt_server/start_fastnipt_server_for_localdebug.py
$workdir/5-nipt_align/start_align_task_for_localdebug.py
$workdir/5-nipt_cnv/start_cnv_task_for_localdebug.py
$workdir/5-nipt_gccor/start_gccor_task_for_localdebug.py
$workdir/6-restful_api/restful_server/start.sh

###step3: start web

electron $workdir/7-frontend/main.js
