# --------------------------------------------------------------------------#
# Dependancies
import io as cStringIO
import json
from bz2 import BZ2File
import os
from pkg_resources import resource_filename
from novalapp.python.project.view import (
    PythonProjectTemplate,
    PythonProjectView,
    PACKAGE_INIT_FILE,
    PythonProjectDocument
)
from novalapp.python.project.document import utils, PythonProject
import novalapp.qtimage as imageutils
from novalapp.util import fileutils, pathutils
from novalapp.project.wizard.page import BitmapTitledContainerWizardPage
from novalapp.project import command
import novalapp.python.project.command as pythoncommand
from novalapp.common import compat
from novalapp.python.project.ext import PYTHON_PROJECT_EXTENSION
from novalapp.lib.pyqt import (
    QVBoxLayout,
    QLabel,
    QGridLayout,
    QRadioButton,
    QGroupBox,
    Qt,
    QLineEdit,
    QMessageBox,
    QComboBox,
    QListWidget,
    QTextEdit
)
import novalapp.python.project.configuration as runconfiguration
from novalapp import _, prog_lang, get_app
from novalapp.python.interpreter import interpretermanager
from novalapp.python.project.property.runui import PythonBaseConfigurationPanel
from novalapp.python.project.page import BasePythonProjectNameLocationPage


class PyPIOptionPanel(PythonBaseConfigurationPanel):

    ZIP_FILE_EXTENSION = 0
    EGG_FILE_EXTENSION = 1
    WHEEL_FILE_EXTENSION = 2

    def __init__(self, parent, item, current_project, **kwargs):
        PythonBaseConfigurationPanel.__init__(self, parent, current_project)
        self.layout.setAlignment(Qt.AlignTop)
        self.current_project = current_project
        self.item = item
        sbox = QGroupBox(_("Output file extension") + ":")
        option_box = QVBoxLayout()

        self.zip_btn = QRadioButton(_('Zip'))
        self.zip_btn.setChecked(True)
        option_box.addWidget(self.zip_btn)

        self.whl_btn = QRadioButton(_('Wheel'))
        option_box.addWidget(self.whl_btn)

        self.egg_btn = QRadioButton(_('Egg'))
        option_box.addWidget(self.egg_btn)
        sbox.setLayout(option_box)
        self.layout.addWidget(sbox)

        self.DisableNoPythonfile(item)

    def OnOK(self, options_dialog=None):
        if self.get_current_interpreter() is None:
            return True
        self.current_project.SaveBuildConfiguration(self.GetItemFile(self.item), self.GetBuildArgs(
        ), self.GetBuildArgs(), self.current_project.GetModel().interpreter.name)
        return True

    def GetBuildArgs(self):
        if self.zip_btn.isChecked():
            return 'sdist'
        if self.whl_btn.isChecked():
            return 'bdist_wheel'
        if self.egg_btn.isChecked():
            return 'bdist_egg'


class NovalPluginOptionPanel(PyPIOptionPanel):
    def __init__(self, parent, item, current_project, **kwargs):
        PyPIOptionPanel.__init__(self, parent, item, current_project, **kwargs)
        self.egg_btn.setChecked(True)
        self.zip_btn.setEnabled(False)
        self.whl_btn.setEnabled(False)

    def OnOK(self, options_dialog=None):
        if self.get_current_interpreter() is None:
            return True
        project_interperter = self.current_project.GetModel().interpreter
        if project_interperter is None:
            return False
        self.current_project.SaveBuildConfiguration(self.GetItemFile(
            self.item), "bdist_novalplugin_egg", self.GetBuildArgs(), project_interperter.name)
        return True


class PyPIProject(PythonProject):
    def __init__(self):
        super().__init__()
        self._runinfo.DocumentTemplate = "pypi.pypi.PyPIProjectTemplate"


class NovalPluginProject(PythonProject):
    def __init__(self):
        super().__init__()
        self._runinfo.DocumentTemplate = "pypi.pypi.NovalPluginProjectTemplate"


class PyPIProjectDocument(PythonProjectDocument):

    def __init__(self, model=None):
        PythonProjectDocument.__init__(self, model)

    @staticmethod
    def GetProjectModel():
        return PyPIProject()

    def CleanProject(self):
        PythonProjectDocument.CleanProject(self)
        self.CleanBuilddir()
        self.CleanOutput()

    def CleanBuilddir(self):
        project_path = self.GetPath()
        build_dir = os.path.join(project_path, 'build')
        self.Cleandir(build_dir)
        pathutils.safe_delete_dir(build_dir)

    def GetDistPath(self):
        dist_path = os.path.join(self.GetPath(), 'dist')
        return dist_path

    def GetProjectStartupFile(self):
        startup_file = self.GetandSetProjectStartupfile()
        return startup_file

    def GetProjectDocInterpreter(self):
        return self.GetandSetProjectDocInterpreter()

    def GetEgg(self):
        dist_path = self.GetDistPath()
        startup_file = self.GetProjectStartupFile()
        if startup_file is None:
            return None, None, None
        interpreter = self.GetProjectDocInterpreter()
        if not interpreter:
            return None, None, None
        cmd = "%s --help --fullname" % (startup_file.filePath)
        exitcode, output = interpreter.exec_command_exit_output(cmd, cwd=self.GetPath())
        if exitcode != 0:
            utils.get_logger().error(
                'exec command:%s error output is :%s',
                interpreter.combine_command(cmd),
                output
            )
            QMessageBox.critical(self.GetFirstView().GetFrame(), _('Error'), output)
            return None, None, None
        fullname = output.strip()
        utils.get_logger().info("interpreter %s minorversion is %s--------------",
                                interpreter.name, interpreter.MinorVersion)
        if not interpreter.MinorVersion:
            interpreter.GetMinorVersion()
            interpretermanager.InterpreterManager().SavePythonInterpretersConfig()
        egg_path = "%s/%s-py%s.egg" % (dist_path,
                                       fullname, interpreter.MinorVersion)
        plugin_name = fullname.split("-")[0]
        version = fullname.split("-")[1]
        return egg_path, plugin_name, version

    def CleanOutput(self):
        egg_path = self.GetEgg()[0]
        if egg_path is None:
            return
        utils.get_logger().info('egg path is %s----------', egg_path)
        self.Cleanfile(egg_path)

    def SaveBuildConfiguration(
        self,
        main_module_file,
        configuration_name,
        build_args,
        interpreter_name
    ):
        file_configuration = runconfiguration.FileConfiguration(
            self, main_module_file)
        file_configuration_list = [configuration_name]
        pj_file_key = file_configuration.GetRootKeyPath()
        # update file configuration list
        utils.profile_set(pj_file_key + "/ConfigurationList",
                          file_configuration_list)
        args = {
            runconfiguration.StartupConfiguration.CONFIGURATION_NAME: runconfiguration.StartupConfiguration(self, main_module_file, 0, ''),
            runconfiguration.AugumentsConfiguration.CONFIGURATION_NAME: runconfiguration.AugumentsConfiguration(self, main_module_file, '', build_args),
            runconfiguration.InterpreterConfiguration.CONFIGURATION_NAME: runconfiguration.InterpreterConfiguration(self, main_module_file, interpreter_name),
            runconfiguration.EnvironmentConfiguration.CONFIGURATION_NAME: runconfiguration.EnvironmentConfiguration(self, main_module_file, {}),
        }

        run_configuration = runconfiguration.RunConfiguration(
            configuration_name, **args)
        run_configuration.SaveConfiguration()
        run_configuration_name = "setup.py/" + configuration_name
        utils.profile_set(self.GetKey() + "/ConfigurationList",
                          [run_configuration_name])
        utils.profile_set(
            self.GetKey() + "/RunConfigurationName", run_configuration_name)


class NovalPluginProjectDocument(PyPIProjectDocument):

    @staticmethod
    def GetProjectModel():
        return NovalPluginProject()


class PyPIProjectTemplate(PythonProjectTemplate):
    @staticmethod
    def CreateProjectTemplate():
        project_template = PyPIProjectTemplate(
            get_app().GetDocumentManager(),
            _("Project File"),
            "*%s" % PYTHON_PROJECT_EXTENSION,
            os.getcwd(),
            PYTHON_PROJECT_EXTENSION,
            "PyPIProject Document",
            _("PyPIProject Viewer"),
            PyPIProjectDocument,
            PythonProjectView,
            icon=imageutils.python_project_icon())
        get_app().GetDocumentManager().DisassociateTemplate(project_template)
        return project_template

    def GetPropertiPages(self):
        return PythonProjectTemplate.GetPropertiPages(self) + [
            ("PyPI option", "file", "pypi.pypi.PyPIOptionPanel"),
            ("PyPI option", "root", "pypi.pypi.PyPIOptionPanel"),
        ]


class NovalPluginProjectTemplate(PyPIProjectTemplate):
    @staticmethod
    def CreateProjectTemplate():
        project_template = NovalPluginProjectTemplate(get_app().GetDocumentManager(),
                                                      _("Project File"),
                                                      "*%s" % PYTHON_PROJECT_EXTENSION,
                                                      os.getcwd(),
                                                      PYTHON_PROJECT_EXTENSION,
                                                      "NovalPluginProject Document",
                                                      _("NovalPluginProject Viewer"),
                                                      NovalPluginProjectDocument,
                                                      PythonProjectView,
                                                      icon=imageutils.python_project_icon())
        get_app().GetDocumentManager().DisassociateTemplate(project_template)
        return project_template

    def GetPropertiPages(self):
        return PythonProjectTemplate.GetPropertiPages(self) + [
            ("PyPI option", "file", "pypi.pypi.NovalPluginOptionPanel"),
            ("PyPI option", "root", "pypi.pypi.NovalPluginOptionPanel")
        ]


class PypiProjectNameLocationPage(BasePythonProjectNameLocationPage):

    def __init__(self, master, **kwargs):
        BasePythonProjectNameLocationPage.__init__(self, master, **kwargs)
        self.can_finish = False

    def GetProjectTemplate(self):
        return PyPIProjectTemplate.CreateProjectTemplate()


class NovalPluginProjectNameLocationPage(PypiProjectNameLocationPage):

    def GetProjectTemplate(self):
        return NovalPluginProjectTemplate.CreateProjectTemplate()


class PypiPackageInformationPage(BitmapTitledContainerWizardPage):
    """
    Creates the pypi interface
    @todo: Dissable << and >> when floating values are present
    @todo: When integer values overflow display convert to scientific notation
    @todo: Keybindings to numpad and enter key
    """

    def __init__(self, parent):
        """Initialiases the calculators main interface"""
        BitmapTitledContainerWizardPage.__init__(self, parent, ("PyPI Project Wizard"), _(
            "PyPI Package Information\nPlease Set Base Information of PyPI Package"), "python_logo.png")
        self.can_finish = True
        self.template_file = 'package_template.tar.bz2'

    def CreateContent(self, content_box, **kwargs):
        content_box.setAlignment(Qt.AlignTop)
        sizer_grid_layout = QGridLayout()
        content_box.addLayout(sizer_grid_layout)

        sizer_grid_layout.addWidget(QLabel(_('Package Name') + ":"), 0, 0)
        self.name_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.name_entry, 0, 1)

        sizer_grid_layout.addWidget(QLabel(_('Package Version') + ":"), 1, 0)
        self.version_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.version_entry, 1, 1)

        sizer_grid_layout.addWidget(
            QLabel(_('Package Description') + ":"), 2, 0)
        self.description_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.description_entry, 2, 1)

        sizer_grid_layout.addWidget(QLabel(_('Package Author') + ":"), 3, 0)
        self.author_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.author_entry, 3, 1)

        sizer_grid_layout.addWidget(QLabel(_('Author Email') + ":"), 4, 0)
        self.email_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.email_entry, 4, 1)

        sizer_grid_layout.addWidget(QLabel(_('Package Website') + ":"), 5, 0)
        self.website_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.website_entry, 5, 1)
        return sizer_grid_layout

    def Validate(self):
        if self.name_entry.text().strip() == "":
            QMessageBox.critical(self, get_app().GetAppName(), _(
                "Please provide a package name."))
            return False

        if self.version_entry.text().strip() == "":
            QMessageBox.critical(self, get_app().GetAppName(), _(
                "Please provide a package version."))
            return False
        return True

    def ReplaceLine(self, line, variable_name, variable_value):
        if line.find(variable_name) != -1:
            line = line.replace(variable_name, variable_value)
        return line

    def ReplaceVariableLine(self, line):
        next_page = self.GetNext()
        line = self.ReplaceLine(line, '{name}', self.name_entry.text())
        line = self.ReplaceLine(line, '{version}', self.version_entry.text())
        line = self.ReplaceLine(
            line, '{description}', self.description_entry.text())
        line = self.ReplaceLine(line, '{author}', self.author_entry.text())
        line = self.ReplaceLine(line, '{email}', self.email_entry.text())
        line = self.ReplaceLine(line, '{url}', self.email_entry.text())
        if next_page is not None:
            if isinstance(next_page, PypiOptionPage):
                line = self.ReplaceLine(
                    line, '{license}', next_page.license_entry.currentText())
                line = self.ReplaceLine(
                    line, '{keywords}', next_page.GetKeywords())
            line = self.ReplaceLine(
                line, '{install_requires}', next_page.GetInstallRequires())
            line = self.ReplaceLine(
                line, '{classifiers}', next_page.GetClassifiers())
        return line

    def GetBuildArgs(self):
        return 'sdist'

    def GetRunConfigurationName(self):
        return self.GetBuildArgs()

    def Finish(self):
        path = resource_filename(__name__, '')
        content_zip_path = os.path.join(path, self.template_file)
        prev_page = self.GetPrev()
        project_path = prev_page.GetProjectLocation()
        setup_path = prev_page.get_startup_file()
        view = get_app().MainFrame.projectview.GetView()
        doc = view.GetDocument()
        try:
            with open(setup_path, "w") as fp:
                try:
                    with BZ2File(content_zip_path, "r") as f:
                        for i, line in enumerate(f):
                            if i == 0:
                                continue
                            line = compat.ensure_string(line)
                            line = self.ReplaceVariableLine(line)
                            # 去除行尾符号,,统一替换成\n
                            fp.write(line.rstrip('\0').rstrip(
                                '\r\n').rstrip('\r').rstrip('\n'))
                            fp.write('\n')
                except Exception as e:
                    utils.get_logger().exception('')
                    QMessageBox.critical(self, get_app().GetAppName(), _(
                        "Load File Template Content Error.%s") % e)
                    return False
            folder_path = self.name_entry.text().lower()
            destpackage_path = os.path.join(project_path, folder_path)
            fileutils.makedirs(destpackage_path)
            doc.GetCommandProcessor().Submit(
                pythoncommand.ProjectAddPackagefolderCommand(view, doc, folder_path))
            self.destpackageFile = os.path.join(
                destpackage_path, PACKAGE_INIT_FILE)
            with open(self.destpackageFile, "w") as f:
                doc.GetCommandProcessor().Submit(command.ProjectAddFilesCommand(
                    doc, [self.destpackageFile], folder_path))
            doc.GetCommandProcessor().Submit(
                command.ProjectAddFilesCommand(doc, [setup_path], None))
            main_module_file = doc.GetModel().FindFile(setup_path)
            doc.SaveBuildConfiguration(
                main_module_file,
                self.GetRunConfigurationName(),
                self.GetBuildArgs(),
                prev_page.interpreter_combo.currentText()
            )
        except Exception as e:
            utils.get_logger().exception('')
            QMessageBox.critical(self, get_app().GetAppName(),
                                 _("New File Error.%s") % e)
            return False
        view.SetProjectStartupFile()
        return True


class PypiPackageToolInformationPage(PypiPackageInformationPage):

    def __init__(self, parent):
        PypiPackageInformationPage.__init__(self, parent)
        self.template_file = 'package_tool_template.tar.bz2'

    def CreateContent(self, content_box, **kwargs):
        sizer_grid_layout = PypiPackageInformationPage.CreateContent(
            self, content_box, **kwargs)
        sizer_grid_layout.addWidget(QLabel(_('Environment') + ":"), 6, 0)
        environments = ('Console', 'GUI')
        self.environment_entry = QComboBox()
        self.environment_entry.addItems(environments)
        sizer_grid_layout.addWidget(self.environment_entry, 6, 1)

        sizer_grid_layout.addWidget(QLabel(_('Tool Name') + ":"), 7, 0)
        self.tool_entry = QLineEdit()
        self.tool_entry.setToolTip(_('The executable name of package tool'))
        sizer_grid_layout.addWidget(self.tool_entry, 7, 1)

    def ReplaceVariableLine(self, line):
        line = PypiPackageInformationPage.ReplaceVariableLine(self, line)
        if self.environment_entry.currentText() == 'Console':
            entry_point = "console_scripts"
        else:
            entry_point = "gui_scripts"
        line = self.ReplaceLine(line, '{entry_point}', entry_point)
        line = self.ReplaceLine(line, '{tool_name}', self.tool_entry.text())
        line = self.ReplaceLine(
            line, '{module_name}', self.name_entry.text().lower())
        line = self.ReplaceLine(line, '{module_func}', "main")
        return line

    def Validate(self):
        if not PypiPackageInformationPage.Validate(self):
            return False
        if self.tool_entry.text().strip() == "":
            QMessageBox.critical(self, get_app().GetAppName(), _(
                "Please provide a package tool name."))
            return False
        return True


class NovalPluginInformationPage(PypiPackageInformationPage):

    plugin_template_content = '''from novalapp import _,get_app,newid,prog_lang
import novalapp.plugin.iface as iface
import novalapp.plugin.plugin as plugin
import novalapp.util.utils as utils
import novalapp.constants as constants


class {PluginName}Plugin(plugin.Plugin):
    """plugin description here..."""
    plugin.Implements(iface.MainWindowI)
    def PlugIt(self, parent):
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing {PluginName} plugin")

    def GetMinVersion(self):
        """Override in subclasses to return the minimum version of novalide that
        the plugin is compatible with. By default it will return the current
        version of novalide.
        @return: version str
        """
        return "{app_version}"

    def InstallHook(self):
        """Override in subclasses to allow the plugin to be loaded
        dynamically.
        @return: None

        """
        pass

    def UninstallHook(self):
        pass

    def EnableHook(self):
        pass

    def DisableHook(self):
        pass

    def get_prog_lang(self):
        return prog_lang.LANGUAGE_NOTSET

    def required_packages(self):
        return {install_requires}
    '''

    def __init__(self, parent):
        """Initialiases the calculators main interface"""
        BitmapTitledContainerWizardPage.__init__(self, parent, ("Noval Plugin Wizard"), _(
            "Noval Plugin Information\nPlease Set Base Information of Noval Plugin"), "python_logo.png")
        self.can_finish = True
        self.template_file = 'package_tool_template.tar.bz2'

    def CreateContent(self, content_box, **kwargs):
        content_box.setAlignment(Qt.AlignTop)
        sizer_grid_layout = QGridLayout()
        content_box.addLayout(sizer_grid_layout)

        sizer_grid_layout.addWidget(QLabel(_('Plugin Name') + ":"), 0, 0)
        self.name_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.name_entry, 0, 1)

        sizer_grid_layout.addWidget(QLabel(_('Plugin Version') + ":"), 1, 0)
        self.version_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.version_entry, 1, 1)

        sizer_grid_layout.addWidget(
            QLabel(_('Plugin Description') + ":"), 2, 0)
        self.description_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.description_entry, 2, 1)

        sizer_grid_layout.addWidget(QLabel(_('Plugin Author') + ":"), 3, 0)
        self.author_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.author_entry, 3, 1)

        sizer_grid_layout.addWidget(QLabel(_('Author Email') + ":"), 4, 0)
        self.email_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.email_entry, 4, 1)

        sizer_grid_layout.addWidget(QLabel(_('Plugin Website') + ":"), 5, 0)
        self.website_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.website_entry, 5, 1)
        return sizer_grid_layout

    def ReplaceVariableLine(self, line):
        line = PypiPackageInformationPage.ReplaceVariableLine(self, line)
        line = self.ReplaceLine(line, '{license}', 'Mulan')
        line = self.ReplaceLine(line, '{keywords}', '')
        line = self.ReplaceLine(line, '{entry_point}', 'Noval.plugins')
        line = self.ReplaceLine(
            line, '{tool_name}', self.name_entry.text().strip())
        line = self.ReplaceLine(
            line, '{module_name}', self.name_entry.text().strip().lower())
        line = self.ReplaceLine(
            line, '{module_func}', self.name_entry.text().strip() + "Plugin")
        return line

    def Finish(self):
        PypiPackageInformationPage.Finish(self)
        with open(self.destpackageFile, "w") as f:
            content = self.plugin_template_content.format(
                PluginName=self.name_entry.text().strip(),
                app_version=utils.get_app_version(),
                install_requires=self.GetNext().GetInstallRequires()
            )
            f.write(content)
        return True

    def GetBuildArgs(self):
        return 'bdist_egg'

    def GetRunConfigurationName(self):
        return "bdist_novalplugin_egg"


class CommonOptionPage:

    def GetInstallRequires(self):
        require_packages = self.install_requires_entry.text().strip()
        return str([name for name in require_packages.split(',') if name != ''])

    def GetOperatingSystem(self):
        op_strs = []
        for i in range(self.platform_listbox.count()):
            listitem = self.platform_listbox.item(i)
            if listitem.checkState() == Qt.Checked:
                op_str = 'Operating System :: %s' % listitem.text()
                op_strs.append(op_str)
        return op_strs

    def GetPythonVersions(self):
        version_strs = []
        for i in range(self.version_listbox.count()):
            listitem = self.version_listbox.item(i)
            if listitem.checkState() == Qt.Checked:
                ver_str = 'Programming Language :: Python :: %s' % listitem.text().replace('Python ', "")
                version_strs.append(ver_str)
        return version_strs

    def GetClassifiers(self):
        classifiers = [
            'Development Status :: 4 - Beta',
            'Programming Language :: Python',
            'Topic :: Software Development :: Libraries :: Python Modules',
            'Programming Language :: Python :: Implementation :: CPython',
            'Programming Language :: Python :: Implementation :: PyPy'
        ]
        classifiers.extend(self.GetOperatingSystem())
        classifiers.extend(self.GetPythonVersions())
        output = cStringIO.StringIO()
        json.dump(classifiers, output, indent=12)
        return output.getvalue().lstrip('[').rstrip(']').strip()


class NovalPluginOptionPage(BitmapTitledContainerWizardPage, CommonOptionPage):
    """
    Creates the calculators interface
    @todo: Dissable << and >> when floating values are present
    @todo: When integer values overflow display convert to scientific notation
    @todo: Keybindings to numpad and enter key
    """

    def __init__(self, parent):
        """Initialiases the calculators main interface"""
        BitmapTitledContainerWizardPage.__init__(self, parent, ("Noval Plugin Wizard"), _(
            "Setup Options\nPlease Specify option of your plugin setup"), "python_logo.png")
        self.can_finish = True

    def CreateContent(self, content_box, **kwargs):
        sizer_grid_layout = QGridLayout()
        content_box.addLayout(sizer_grid_layout)

        sizer_grid_layout.addWidget(QLabel(_('Require Packages') + ":"), 0, 0)
        self.install_requires_entry = QLineEdit()
        self.install_requires_entry.setPlaceholderText("xx==0.1.1,yy")
        self.install_requires_entry.setToolTip(
            _('Multi packages seperated by comma'))
        sizer_grid_layout.addWidget(self.install_requires_entry, 0, 1)

        sizer_grid_layout.addWidget(QLabel(_('Python Version') + ":"), 1, 0)
        versions = ('3.11',)
        self.version_listbox = QListWidget()
        for i, version in enumerate(versions):
            self.version_listbox.addItem('Python ' + version)
            listitem = self.version_listbox.item(i)
            listitem.setCheckState(Qt.Checked)

        sizer_grid_layout.addWidget(self.version_listbox, 1, 1)

        sizer_grid_layout.addWidget(QLabel(_('Os Platform') + ":"), 2, 0)
        platforms = ('OS Independent', 'Windows', 'MacOS', 'Linux')
        self.platform_listbox = QListWidget()
        self.platform_listbox.addItems(platforms)
        sizer_grid_layout.addWidget(self.platform_listbox, 2, 1)

        sizer_grid_layout.addWidget(QLabel(_('Prog Language') + ":"), 3, 0)
        self.prog_lang_combo = QComboBox()
        self.prog_lang_combo.addItems(
            [prog_lang.LANGUAGE_NOTSET, prog_lang.LANGUAGE_PYTHON])
        sizer_grid_layout.addWidget(self.prog_lang_combo, 3, 1)

    def Finish(self):
        return True


class NovalFileExtensionPluginInformationPage(NovalPluginInformationPage):
    plugin_template_content = NovalPluginInformationPage.plugin_template_content + '''
    def GetFileExtension(self):
        return '{file_extension}'
    '''

    def CreateContent(self, content_box, **kwargs):
        sizer_grid_layout = NovalPluginInformationPage.CreateContent(
            self, content_box, **kwargs)
        sizer_grid_layout.addWidget(QLabel(_('File Extension') + ":"), 6, 0)
        self.file_extension_entry = QLineEdit()
        sizer_grid_layout.addWidget(self.file_extension_entry, 6, 1)

    def Finish(self):
        PypiPackageInformationPage.Finish(self)
        with open(self.destpackageFile, "w") as f:
            content = self.plugin_template_content.format(PluginName=self.name_var.get(
            ).strip(), file_extension=self.file_extension_var.get().strip())
            f.write(content)
        return True


class PypiOptionPage(BitmapTitledContainerWizardPage, CommonOptionPage):
    """
    Creates the calculators interface
    @todo: Dissable << and >> when floating values are present
    @todo: When integer values overflow display convert to scientific notation
    @todo: Keybindings to numpad and enter key
    """

    def __init__(self, parent):
        """Initialiases the calculators main interface"""
        BitmapTitledContainerWizardPage.__init__(self, parent, ("PyPI Project Wizard"), _(
            "Setup Options\nPlease Specify option of your package setup"), "python_logo.png")
        self.can_finish = True

    def CreateContent(self, content_box, **kwargs):
        sizer_grid_layout = QGridLayout()
        content_box.addLayout(sizer_grid_layout)

        sizer_grid_layout.addWidget(QLabel(_('Keywords') + ":"), 0, 0)
        self.keyword_entry = QLineEdit()
        self.keyword_entry.setToolTip(_('multi keywords seperated by comma'))
        sizer_grid_layout.addWidget(self.keyword_entry, 0, 1)

        sizer_grid_layout.addWidget(QLabel(_('Require Packages') + ":"), 1, 0)
        self.install_requires_entry = QLineEdit()
        self.install_requires_entry.setToolTip(
            _('multi packages seperated by comma'))
        sizer_grid_layout.addWidget(self.install_requires_entry, 1, 1)

        sizer_grid_layout.addWidget(QLabel(_('License') + ":"), 2, 0)
        licenses = ('GPL', 'LGPL', 'AGPL', 'Apache',
                    'MIT', 'BSD', 'EPL', 'MPL', 'Mulan')
        self.license_entry = QComboBox()
        self.license_entry.addItems(licenses)
        sizer_grid_layout.addWidget(self.license_entry, 2, 1)

        sizer_grid_layout.addWidget(QLabel(_('Python Version') + ":"), 3, 0)
        versions = ('3', '3.5', '3.6', '3.7', '3.8', '3.9', '3.10', '3.11')
        self.version_listbox = QListWidget()
        for i, version in enumerate(versions):
            self.version_listbox.addItem('Python ' + version)
            listitem = self.version_listbox.item(i)
            listitem.setCheckState(Qt.Unchecked)

        sizer_grid_layout.addWidget(self.version_listbox, 3, 1)

        sizer_grid_layout.addWidget(QLabel(_('Os Platform') + ":"), 4, 0)
        platforms = ('OS Independent', 'Windows', 'MacOS', 'Linux')
        self.platform_listbox = QListWidget()
        self.platform_listbox.addItems(platforms)
        sizer_grid_layout.addWidget(self.platform_listbox, 4, 1)

        sizer_grid_layout.addWidget(
            QLabel(_('Package Long Description') + ":"), 5, 0)
        self.description_text = QTextEdit()
        sizer_grid_layout.addWidget(self.description_text, 5, 1)

    def Finish(self):
        return True

    def GetKeywords(self):
        return ' '.join(self.keyword_entry.text().split(','))
