# -*- coding: utf-8 -*-
###############################################################################
# Name: __init__.py                                                           #
# Purpose: Simple Calculator Plugin                                           #
# Author: Cody Precord <cprecord@editra.org>                                  #

"""Simple Programmer's Calculator"""
__author__ = "Cody Precord"
__version__ = "0.6"

# -----------------------------------------------------------------------------#
import sys
import shutil
import os
from novalapp.plugin import plugin
from novalapp.util import utils
from novalapp.util import urlutils
from novalapp import constants
from novalapp.project.wizard.templatemanager import WizardtemplateManager
from novalapp.python.debugger.output import *
from novalapp.project.config import *
import novalapp.python.debugger.debugger as pythondebugger
from novalapp.util import fileutils
from novalapp.api.errors import OK, PLUGIN_EGG_FILE_EXISTS
import novalapp.python.project.configuration as runconfiguration
from novalapp.plugin import iface
from novalapp import _, get_app, newid
from novalapp.lib.pyqt import QMessageBox
from novalapp.util import terminal
from novalapp.util import ui_utils
from novalapp.analytics.userdb import UserdataDb
from novalapp.bars.menubar import find_menu, NewQMenu, MenuItem
from novalapp.python import utility
from novalapp import prog_lang
from novalapp.api.api import ApiServer
from pypi import pypi


# Local imports
# -----------------------------------------------------------------------------#

# Try and add this plugins message catalogs to the app


# -----------------------------------------------------------------------------#

pypyrc_template = '''[distutils]
index-servers = pypi

[pypi]
repository: https://pypi.python.org/pypi
username: {username}
password: {password}
'''

PLUGIN_REQUIRED_PYTHON_VERSION = "3.11"


class PypiAccountDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent):
        ui_utils.CommonAccountDialog.__init__(self, parent, _(
            "PyPI Account"), _("Please input PyPI account:"))


class PyPi(plugin.Plugin):
    """Simple pypi package tool"""
    plugin.Implements(iface.MainWindowI)
    ID_PUBLISH_SERVER = newid()
    ID_PUBLISH_LOCAL = newid()

    def PlugIt(self, parent):
        self.parent = parent
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing PyPi plugin")
        WizardtemplateManager.get_manager().AddProjectTemplate(
            "Python/PyPI",
            "PyPiPackage",
            _("PyPI Package"),
            [
                (pypi.PypiProjectNameLocationPage, {'startup_path': '${ProjectDir}/setup.py'}),
                pypi.PypiPackageInformationPage, pypi.PypiOptionPage
            ]
        )
        WizardtemplateManager.get_manager().AddProjectTemplate(
            "Python/PyPI",
            "PyPiPackageTool",
            _("PyPI Package Tool"),
            [
                (pypi.PypiProjectNameLocationPage, {'startup_path': '${ProjectDir}/setup.py'}),
                pypi.PypiPackageToolInformationPage, pypi.PypiOptionPage
            ]
        )
        if get_app().GetDebug():
            WizardtemplateManager.get_manager().AddProjectTemplate(
                "Python/PyPI",
                "NovalPlugin",
                _("Noval Plugin"),
                [
                    (pypi.PypiProjectNameLocationPage, {'startup_path': '${ProjectDir}/setup.py'}),
                    pypi.NovalPluginInformationPage,
                    pypi.NovalPluginOptionPage
                ]
            )
            WizardtemplateManager.get_manager().AddProjectTemplate(
                "Python/PyPI",
                "NovalFileExtensionPlugin",
                _("Noval FileExtension Plugin"),
                [
                    (pypi.PypiProjectNameLocationPage, {'startup_path': '${ProjectDir}/setup.py'}),
                    pypi.NovalFileExtensionPluginInformationPage
                ]
            )
       # GetApp().bind(constants.PROJECTVIEW_POPUP_FILE_MENU_EVT, self.AppenFileMenu,True)
        self.project_browser = get_app().MainFrame.projectview
       # 项目文件节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_FILE_MENU.connect(
            self.AppenFileMenu)
        get_app().add_message_catalog('pypi', __name__)
        # 项目根节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_ROOT_MENU.connect(
            self.AppenRootMenu)
       # GetApp().bind(constants.PROJECTVIEW_POPUP_ROOT_MENU_EVT, self.AppenRootMenu,True)

    def AppenRootMenu(self, menu, item):
        if self.GetProjectDocument() is None:
            return
        project_document_class_name = self.GetProjectDocument().__class__.__name__
        if project_document_class_name != "PyPIProjectDocument":
            submenu = menu.GetMenuByname(_("Convert to"))
            if not submenu:
                menu.add_separator()
                submenu = NewQMenu(_("Convert to"))
                menu.AppendMenu(newid(), submenu)
            submenu.Append(newid(), _("PyPI Project"),
                           handler=lambda: self.Convertto(False))

        elif project_document_class_name != "NovalPluginProjectDocument":
            submenu = menu.GetMenuByname(_("Convert to"))
            if not submenu:
                menu.add_separator()
                submenu = NewQMenu(_("Convert to"))
                menu.AppendMenu(newid(), submenu)
            submenu.Append(newid(), _("Noval Plugin Project"),
                           handler=lambda: self.Convertto(True))
        else:
            pass

    def get_prog_lang(self):
        return prog_lang.LANGUAGE_PYTHON

    def Convertto(self, is_plugin=False):
        project_doc = self.GetProjectDocument()
        if not is_plugin:
            project_doc.GetModel()._runinfo.DocumentTemplate = "pypi.pypi.PyPIProjectTemplate"
        else:
            project_doc.GetModel()._runinfo.DocumentTemplate = "pypi.pypi.NovalPluginProjectTemplate"
        project_doc.Modify(True)
        project_doc.Save()
        assert (project_doc.NeedConvertto(project_doc.GetModel()))
        newdoc = project_doc.convert_to(project_doc.GetModel(),
                               project_doc.GetFilename())
        assert(project_doc not in get_app().GetDocumentManager().GetDocuments())
        assert(newdoc in get_app().GetDocumentManager().GetDocuments())
        self.GetProjectFrame().GetView().SetDocument(newdoc)

    def GetProjectDocument(self):
        project_browser = self.GetProjectFrame()
        return project_browser.GetView().GetDocument()

    def GetProjectFrame(self):
        return self.project_browser

    def AppenFileMenu(self, menu, tree_item):
        view = self.project_browser.GetView()
        filePath = view._GetItemFilePath(tree_item)
        if view._IsItemFile(tree_item) and utility.is_python_file(filePath):
            item_file = view.GetDocument().GetModel().FindFile(filePath)
            file_configuration = runconfiguration.FileConfiguration(
                view.GetDocument(), item_file)
            file_configuration_list = file_configuration.LoadConfigurationNames()
            if file_configuration_list:
                if file_configuration_list[0] == 'bdist_novalplugin_egg':
                    menu.add_separator()
                    menu.Append(self.ID_PUBLISH_LOCAL, _(
                        "&Publish to Application Install Path"), handler=self.PublishToInstallPath)
                    menu.Append(self.ID_PUBLISH_SERVER, _(
                        "&Publish to Web Server"), handler=self.PublishToServer)
                elif file_configuration_list[0] in ['sdist', 'bdist_egg', 'bdist_wheel']:
                    menu.add_separator()
                    menu.Append(self.ID_PUBLISH_LOCAL, _(
                        "&Publish to Local site-packages"), handler=self.PublishToSitePackages)
                    menu.Append(self.ID_PUBLISH_SERVER, _(
                        "&Publish to PyPI Server"), handler=self.PublishToPypi)

    def GetInstallPluginPath(self, plugin_name):
        dist = get_app().GetPluginManager().GetPluginDistro(plugin_name)
        # 如果插件未安装则选择2种插件目录中的一种
        if not dist:
            # 软件安装目录
            plugin_path = utils.profile_get(
                "PluginInstallPath", utils.get_sys_plugin_path())
        else:
            plugin_path = os.path.dirname(dist.location)
        utils.get_logger().info("plugin %s install path is %s", plugin_name, plugin_path)
        fileutils.makedirs(plugin_path)
        return plugin_path

    def PublishToServer(self):
        '''
            发布并上传插件到web服务器
        '''
        def get_key_value(line, key, flag, data):
            if line.find(flag) != -1:
                data[key] = line.replace(flag, "").strip()
        interpreter = self.GetProjectDocument().GetProjectDocInterpreter()
        if not interpreter:
            return
        startup_file = self.GetProjectDocument().GetProjectStartupFile()
        project_path = self.GetProjectPath()
        args1 = "%s egg_info --egg-base %s" % (
            startup_file.filePath, project_path)
        utility.create_python_process(interpreter.path, args1)
        egg_path, plugin_name, version = self.GetProjectDocument().GetEgg()
        if not os.path.exists(egg_path):
            QMessageBox.critical(get_app().GetTopWindow(), _(
                'Pulish to server'), _("egg file %s is not exist") % egg_path)
            return
        pkg_file_path = os.path.join(
            project_path, "%s.egg-info/PKG-INFO" % (plugin_name))
        if not os.path.exists(pkg_file_path):
            QMessageBox.critical(get_app().GetTopWindow(), _(
                'Pulish to server'), _("pkg file %s is not exist") % pkg_file_path)
            return

        data = {}
        dist_path = self.GetProjectDocument().GetDistPath()
        # 获取插件源数据信息,必须先实例化插件
        dist_env = get_app().GetPluginManager().CreateEnvironment([dist_path])
        for name in dist_env:
            egg = dist_env[name][0]  # egg is of type Distribution
            if egg.version != version or egg.project_name != plugin_name:
                continue
            if egg.py_version != PLUGIN_REQUIRED_PYTHON_VERSION:
                QMessageBox.critical(
                    get_app().GetTopWindow(),
                    _('Pulish to server'),
                    _("plugin '%s' python version is %s but required python version is %s") % (
                        plugin_name, egg.py_version, PLUGIN_REQUIRED_PYTHON_VERSION)
                )
                return
            egg.activate()
            for name in egg.get_entry_map(plugin.ENTRYPOINT):
                entry_point = egg.get_entry_info(plugin.ENTRYPOINT, name)
                cls = entry_point.load()
                # 实例化插件对象
                instance = cls(get_app().GetPluginManager())
                # 是否禁止插件卸载
                data['disable_uninstall'] = int(
                    not int(instance.CanUninstall()))
                data['match_platform'] = int(instance.MatchPlatform())
                # 操作系统名称,防止插件区分操作系统
                data['os_name'] = sys.platform
                data['app_version'] = instance.GetMinVersion()
                if hasattr(instance, "GetFileExtension"):
                    data['file_extension'] = instance.GetFileExtension()

        with open(pkg_file_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                get_key_value(line, 'name', "Name:", data)
                get_key_value(line, 'version', "Version:", data)
                get_key_value(line, "summary", "Summary:", data)
                get_key_value(line, "homepage", "Home-page:", data)
                get_key_value(line, "author", "Author:", data)
                get_key_value(line, "author_mail", "Author-email:", data)
          #      get_key_value(line,"Platform:",data)
        api_addr = '%s/member/publish' % (ApiServer.HOST_SERVER_ADDR)
        # 如果版本已经存在,先不要强制替换
        data['force_update'] = 0
        user_id = UserdataDb.get_db().GetUserId()
        if user_id is None:
            UserdataDb.get_db().GetUser()
            user_id = UserdataDb.get_db().GetUserId()
        data['member_id'] = user_id
        data['egg_name'] = os.path.basename(egg_path)
        ret = urlutils.upload_file(api_addr, file=egg_path, arg=data)
        if not ret:
            utils.get_logger().error('upload plugin %s fail', data['name'])
            QMessageBox.critical(_('Publish to server'), _(
                "Publish fail"), parent=self.parent)
            return
        utils.get_logger().debug('ret is %s', ret)
        # 已有版本已经存在,提示用户是否强制替换
        if ret['code'] == PLUGIN_EGG_FILE_EXISTS:
            result = QMessageBox.question(
                get_app().GetTopWindow(),
                _('Publish to server'),
                ret['message'].format(
                    version=data['version'], name=data['name'])
            )
            if result == QMessageBox.No:
                return
            # 强制更新版本
            data['force_update'] = 1
            ret = urlutils.upload_file(api_addr, file=egg_path, arg=data)
            if not ret:
                utils.get_logger().error('upload plugin %s fail', data['name'])
                QMessageBox.critical(_('Publish to server'), _(
                    "Publish fail"), parent=self.parent)
                return
        if ret['code'] == OK:
            QMessageBox.information(get_app().GetTopWindow(), _(
                'Publish to server'), _("Publish success"))
        else:
            QMessageBox.critical(get_app().GetTopWindow(), _(
                'Publish to server'), _("Publish fail"))

    def PublishToInstallPath(self):
        '''
            发布插件到本地
        '''
        egg_path, plugin_name, _v = self.GetProjectDocument().GetEgg()
        if egg_path is None:
            return
        if not os.path.exists(egg_path):
            QMessageBox.critical(get_app().GetTopWindow(), _(
                'Publish to local'), _("egg file %s is not exist") % egg_path)
        else:
            try:
                plugin_path = self.GetInstallPluginPath(plugin_name)
                shutil.copy(egg_path, plugin_path)
            except Exception as e:
                utils.get_logger().error("%s", e)
                QMessageBox.critical(get_app().GetTopWindow(), _(
                    'Publish to local'), _("Publish fail:%s") % e)
                return
            get_app().GetPluginManager().EnablePlugin(plugin_name)
            QMessageBox.information(get_app().GetTopWindow(), _(
                'Publish to local'), _("Publish success"))

    def GetProjectPath(self):
        doc = self.project_browser.GetView().GetDocument()
        return os.path.dirname(doc.GetFilename())

    def PublishToSitePackages(self):
        '''
            发布pypi包到本地解释器
        '''
        view = self.project_browser.GetView()
        dist_path = self.GetProjectDocument().GetDistPath()
        filePath = view.GetSelectedFile()
        interpreter = self.GetProjectDocument().GetProjectDocInterpreter()
        command = "%s \"%s\" install" % (interpreter.path, filePath)
        utils.get_logger().info("start run setup install command: %s in terminal", command)
        terminal.run_in_terminal(command, self.GetProjectPath(
        ), keep_open=False, pause=True, title="abc", overwrite_env=False)

    def PublishToPypi(self):
        '''
            发布pypi包到pypi服务器
        '''
        ret = messagebox.askyesno(GetApp().GetAppName(), _(
            "Are you sure to publish to PyPI?"), parent=self.parent)
        if ret == False:
            return
        view = self.project_browser.GetView()
        dist_path = self.GetProjectDocument().GetDistPath()
        filePath = view.GetSelectedFile()
        interpreter = self.GetProjectDocument().GetProjectDocInterpreter()
        if not interpreter:
            return
        cmd = "%s %s --help --fullname" % (interpreter.Path, filePath)
        output = utils.GetCommandOutput(cmd)
        fullname = output.strip()

        zip_path = "%s/%s.zip" % (dist_path, fullname)
        gz_path = "%s/%s.tar.gz" % (dist_path, fullname)
        if os.path.exists(zip_path):
            upload_path = zip_path
        elif os.path.exists(gz_path):
            upload_path = gz_path
        else:
            messagebox.showerror(GetApp().GetAppName(), _(
                "zip file '%s' or gz file '%s' are not exist") % (zip_path, gz_path), parent=self.parent)
            return

        home_path = utils.get_home_dir()
        pypirc_filepath = os.path.join(home_path, ".pypirc")
        utils.get_logger().info("pypirc path is %s", pypirc_filepath)
        if not interpreter.GetInstallPackage("twine"):
            messagebox.showinfo(GetApp().GetAppName(), _(
                "interpreter %s need to install package \"twine\"") % interpreter.Name, parent=self.parent)
            dlg = pythonpackages.InstallPackagesDialog(
                self.parent, interpreter, pkg_name='twine', install_args='--user twine', autorun=True)
            status = dlg.ShowModal()
            if status == constants.ID_CANCEL:
                return
        if not os.path.exists(pypirc_filepath):
            account_dlg = PypiAccountDialog(self.parent)
            if constants.ID_OK == account_dlg.ShowModal():
                with open(pypirc_filepath, "w") as f:
                    content = pypyrc_template.format(
                        username=account_dlg.name_var.get(), password=account_dlg.password_var.get())
                    f.write(content)
            else:
                return
        if utils.is_windows():
            interpreter_path = interpreter.InstallPath
            twine_tool_path = os.path.join(
                interpreter_path, "Scripts", "twine.exe")
            command = "%s upload %s" % (twine_tool_path, upload_path)
        else:
            command = "twine upload %s" % (upload_path)
        utils.get_logger().info("start run twine upload command: %s in terminal", command)
        terminal.run_in_terminal(command, self.GetProjectPath(
        ), keep_open=False, pause=True, title="abc", overwrite_env=False)

    def GetMinVersion(self):
        return '1.2.6'
