import os.path
import os
from collections import defaultdict
import json
from ..prog_lang_ext import PYTHON_CODE_FILE_EXT
from ... import _, get_app
from ...project import command as projectcommand
from ..interpreter.interpreter import BuiltinPythonInterpreter
from ..interpreter.interpretermanager import InterpreterManager
from ..parser.objtypes import CLASS_DEF
from ...util import ui_utils, fileutils, strutils, utils
from ..apis import memberkeys
from ...lib.pyqt import (
    QHBoxLayout,
    QLabel,
    Qt,
    QSizePolicy,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QLineEdit,
    QCheckBox,
    QComboBox,
    QFileDialog
)
from ...widgets import simpledialog
from ...project.resolver.model import ProjectFile

CLASS_DEFS_FILENAME = "classes.json"

FIXED_LABEL_WIDTH = 250

ADD_CLASS_TEMPLATE = """
{DefinedClass}:
    '''{Docstr}'''

    def __init__(self):
        # TODO: {TodoText}
        pass
"""


class AddClassDialog(ui_utils.BaseModalDialog):
    """添加类"""

    def __init__(self, parent, project_doc, module_doc=None):
        super().__init__('', parent)
        self._module_doc = module_doc
        self._project_doc = project_doc
        # 去除标题栏和边框
        self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)
        heading_label = QLabel(_("Add Class"))
        heading_label.setStyleSheet("font-size:40px;font-weight:bold;")
        self.layout.addWidget(heading_label)
        self.layout.addWidget(QLabel(''))

        vbox = QVBoxLayout()
        hbox = QHBoxLayout()

        classname_box = QVBoxLayout()
        classname_box.addWidget(QLabel(_('Class Name') + "(L)"))
        self.class_name_entry = QLineEdit()
        self.class_name_entry.textChanged.connect(self.change_module_name)
        self.class_name_entry.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.class_name_entry.setFixedWidth(FIXED_LABEL_WIDTH)  # 固定宽度像素
        classname_box.addWidget(self.class_name_entry)
        hbox.addLayout(classname_box)

        module_file_box = QVBoxLayout()
        module_file_box.addWidget(QLabel("." + PYTHON_CODE_FILE_EXT[0] + " " + _('File') + "(P)"))
        h_module_box = QHBoxLayout()
        self.module_file_entry = QLineEdit()
        self.module_file_entry.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.module_file_entry.setFixedWidth(FIXED_LABEL_WIDTH)
        browse_btn = QPushButton("...")
        browse_btn.clicked.connect(self.open_class_file)
        h_module_box.addWidget(self.module_file_entry)
        h_module_box.addWidget(browse_btn)
        module_file_box.addLayout(h_module_box)
        hbox.addLayout(module_file_box)

        vbox.addLayout(hbox)

        base_class_box = QVBoxLayout()
        base_class_box.setContentsMargins(0, 10, 0, 0)
        base_class_box.addWidget(QLabel(_('Base Class') + "(B)"))
        self.base_class_entry = QComboBox()
        self.base_class_entry.setEditable(True)
        self.base_class_entry.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.base_class_entry.setFixedWidth(FIXED_LABEL_WIDTH)
        base_class_box.addWidget(self.base_class_entry)
        vbox.addLayout(base_class_box)

        docstr_box = QVBoxLayout()
        docstr_box.setContentsMargins(0, 20, 0, 0)
        docstr_box.addWidget(QLabel(_('Docstr') + "(M)"))
        self.docstr_entry = QLineEdit()
        self.docstr_entry.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        docstr_box.addWidget(self.docstr_entry)
        vbox.addLayout(docstr_box)

        self.snake_case_chkbox = QCheckBox(_('Module name use snake case style'))
        self.snake_case_chkbox.setChecked(True)
        vbox.addWidget(self.snake_case_chkbox)
        vbox.addWidget(QLabel(''))
        vbox.addWidget(QLabel(''))
        vbox.addWidget(QLabel(''))

        self.layout.addLayout(vbox)
        self.create_standard_buttons()
        self.load_all_class_bases()

    def open_class_file(self):
        descrs = _("All files") + " (*.*)"
        path, _filetype = QFileDialog.getOpenFileName(
            self,
            _('Select file path'),
            None,
            descrs
        )
        if not path:
            return
        filename = fileutils.get_filename_from_path(fileutils.opj(path))
        self.module_file_entry.setText(filename)

    def load_class_defs(self, class_def_filepath):
        if os.path.exists(class_def_filepath):
            with open(class_def_filepath) as f:
                class_dict = json.load(f)
                self.base_class_entry.addItems(sorted(class_dict.keys()))
                class_dict.clear()

    def get_class_mod_list(self, classname):
        class_def_filepath = os.path.join(utils.get_cache_path(), CLASS_DEFS_FILENAME)
        if os.path.exists(class_def_filepath):
            with open(class_def_filepath) as f:
                class_dict = json.load(f)
                return class_dict.get(classname, [])
        return []

    def load_all_class_bases(self):
        class_def_filepath = os.path.join(utils.get_cache_path(), CLASS_DEFS_FILENAME)
        if os.path.exists(class_def_filepath):
            self.load_class_defs(class_def_filepath)
        else:
            self.gen_all_classes()
            self.load_class_defs(class_def_filepath)

    def change_module_name(self, *args):
        classname = self.class_name_entry.text().strip()
        if classname == "":
            return
        if self.snake_case_chkbox.isChecked():
            classname = classname.lower()
        self.module_file_entry.setText(classname + "." + PYTHON_CODE_FILE_EXT[0])

    def pop_empty_error(self, label_text):
        QMessageBox.critical(self, _('Error'), label_text + " " + _("Can't be empty."))

    def gen_all_classes(self):
        interpreter = InterpreterManager.manager().GetInterpreterByName(
            BuiltinPythonInterpreter.BUILTIN_INTERPRETER_NAME
        )
        class_def_filepath = os.path.join(utils.get_cache_path(), CLASS_DEFS_FILENAME)
        class_dict: defaultdict[str, list[str]] = defaultdict(list)
        get_app().intellisence_mananger.load_intellisence_data(interpreter, async_load=False)
        for mdloader in get_app().intellisence_mananger.load_modules():
            mdloader.load()
            class_def_childs = mdloader.find_childs_with_object_type(CLASS_DEF)
            for class_def_child in class_def_childs:
                class_dict[class_def_child[memberkeys.NAME_KEY_NAME]].append(
                    class_def_child[memberkeys.MODNAME_KEY_NAME]
                )
        with open(class_def_filepath, "w") as f:
            json.dump(class_dict, f)
        class_dict.clear()
        get_app().intellisence_mananger.load_intellisence_data(get_app().GetCurrentInterpreter())

    def _ok(self):
        class_name = self.class_name_entry.text().strip()
        if class_name == "":
            self.pop_empty_error(_('Class Name'))
            return
        module_file_path = self.module_file_entry.text().strip()
        if module_file_path == "":
            self.pop_empty_error("." + PYTHON_CODE_FILE_EXT[0] + " " + _('File'))
            return
        file_extension = strutils.get_file_extension(module_file_path)
        if file_extension not in PYTHON_CODE_FILE_EXT[0:2]:
            QMessageBox.critical(
                self,
                _('Error'),
                _('Invalid Python file') + ':' + strutils.emphasis_path(module_file_path)
            )
            return
        project_root_path = self._project_doc.GetPath()
        if os.path.isabs(module_file_path):
            module_doc_path = fileutils.opj(module_file_path)
        else:
            module_doc_path = fileutils.opj(os.path.join(project_root_path, module_file_path))
        if not os.path.exists(module_doc_path):
            fileutils.create_empty_file(module_doc_path)
        folderpath = ProjectFile(filepath=module_doc_path).get_relative_folder(project_root_path)
        add_files_command = projectcommand.ProjectAddFilesCommand(
            self._project_doc,
            [module_doc_path],
            folderPath=folderpath
        )
        self._project_doc.GetCommandProcessor().Submit(add_files_command)
        treectrl = self._project_doc.GetFirstView()._treeCtrl
        item = treectrl.FindItem(module_doc_path)
        treectrl.setCurrentItem(item)
        codeview = get_app().GotoView(module_doc_path)
        codemodule = codeview.Module
        if codemodule is None:
            return
        todo_text = _("Add the implementation code here") + "."
        base_class_name = self.base_class_entry.currentText().strip()
        if base_class_name == "":
            define_class_text = f"class {class_name}"
        else:
            define_class_text = f"class {class_name}({base_class_name})"
        mod_path_list = self.get_class_mod_list(base_class_name)
        if mod_path_list:
            if len(mod_path_list) == 1:
                sel = 0
            else:
                sel = simpledialog.asklist(
                    _("Multiple Class Definition"),
                    _("Please choose one base class import module"),
                    mod_path_list,
                    selection=0,
                    master=self
                )
                if sel == -1:
                    return
            modpaths = mod_path_list[sel].split(".")
            codeview.AddText(
                'from ' + '.'.join(modpaths[0:-1]) + ' import ' + base_class_name
            )
        add_class_text = ADD_CLASS_TEMPLATE.format(
            DefinedClass=define_class_text,
            Docstr=self.docstr_entry.text().strip(),
            TodoText=todo_text
        )
        codeview.AddText(add_class_text)
        super()._ok()
