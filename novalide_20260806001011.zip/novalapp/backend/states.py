from enum import Enum


class BackendState(Enum):
    STARTING = "starting"
    RUNNING = "running"
    WAITING_DEBUGGER_COMMAND = "waiting_debugger_command"
    WAITING_TOPLEVEL_COMMAND = "waiting_toplevel_command"
