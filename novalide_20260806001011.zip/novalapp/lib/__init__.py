import threading

_lock = threading.Lock()
_ID_COUNTER = 1000
_APP_INSTANCE = None


def newid():
    global _ID_COUNTER
    with _lock:
        _ID_COUNTER += 1
    return _ID_COUNTER


def get_app():
    assert _APP_INSTANCE is not None
    return _APP_INSTANCE


def set_app(app_obj):
    global _APP_INSTANCE
    assert _APP_INSTANCE is None
    _APP_INSTANCE = app_obj


def _get_translation(raw_text):
    if _APP_INSTANCE is None:
        return raw_text
    return _APP_INSTANCE.GetLocale().get_text(raw_text)


_ = _get_translation
