from dataclasses import dataclass
from typing import Optional
from astroid import nodes
from . import memberkeys
from ..parser import node_utils


@dataclass(frozen=True)
class Member:
    """
    代码语法节点的子成员,相当于NamedTuple类型,但是NamedTuple不支持继承.
    所以dataclass(frozen=True),其中frozen表示成员数据类型不可更改,dataclass
    成员数据类型默认可修改
    """
    name: str
    modname: str
    member_tpe: str
    node: nodes.NodeNG
    # childs默认类型不能赋值为空列表[],默认初始值为None,通过传递列表初始化
    childs: Optional[list] = None

    def to_dict(self):
        name = self.modname
        nodetype = self.member_tpe
        node = self.node
        data = {
            memberkeys.QUALNAME_KEY_NAME: name,
            memberkeys.NAME_KEY_NAME: name.split(".")[-1],
            memberkeys.OBJTYPE_KEY_NAME: nodetype
        }
        lineno, col_offset = node_utils.get_node_line_col(node)
        if lineno is not None and col_offset is not None:
            data.update(
                {
                    memberkeys.LINE_KEY_NAME: lineno,
                    memberkeys.COL_KEY_NAME: col_offset
                }
            )
        doc = node_utils.get_node_doc(node)
        if doc is not None:
            data.update({memberkeys.DOC_KEY_NAME: doc})
        return data


@dataclass(frozen=True)
class ReferMember(Member):
    '''从其它模块中导入的成员引用作为自己的成员,继承自Member,只有dataclass类型才支持继承'''
    refer_mod_path: str = ''
    path: str = ''

    def to_dict(self):
        dict_data = super().to_dict()
        dict_data.update({memberkeys.REFER_MODULE_NAME: self.refer_mod_path})
        return dict_data
