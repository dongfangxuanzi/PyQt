# -*- coding: utf-8 -*-
import astroid
from .codebase import CodebaseParser
from ...util import strutils


class CodeParser(CodebaseParser):
    """description of class"""

    def __init__(self, outlineview=None):
        super().__init__(None)
        self.filepath = None
        self._module_node = None
        self._outlineview = outlineview

    def parse_file(self, filepath, encoding="utf-8"):
        module_name = strutils.get_filename_without_ext(filepath)
        return self.ast_from_file(filepath, module_name, use_cache=False)

    def parse_content(self, filepath, content, encoding=None):
        module_name = strutils.get_filename_without_ext(filepath)
        self._module_node = astroid.parse(
            content, path=filepath, module_name=module_name)
        return self._module_node

    def prepare_visitors(self):
        self._visitors.append(self._outlineview.visit_functiondef)
        self._visitors.append(self._outlineview.leave_functiondef)
        self._visitors.append(self._outlineview.visit_classdef)
        self._visitors.append(self._outlineview.leave_classdef)
        self._visitors.append(self._outlineview.visit_assign)
        self._visitors.append(self._outlineview.visit_annassign)
        self._visitors.append(self._outlineview.visit_import)
        self._visitors.append(self._outlineview.visit_importfrom)
        self._visitors.append(self._outlineview.visit_if)
        self._visitors.append(self._outlineview.visit_asyncfunctiondef)
        self._visitors.append(self._outlineview.visit_try)
        return self._visitors

    def add_module_visitor(self):
        """
        Context manager for checking ASTs.
        The value in the context is callable accepting AST as its only argument.
        """
        _visitors = self.prepare_visitors()
        if not _visitors:
            raise RuntimeError('empty node visitors')
        # notify global begin
        for visitor in _visitors:
            self.walker.add_visitor(visitor)

    def fix_import_node(self, importnode):
        if importnode.level is not None:
            filepath = importnode.root().file
            full_import_path = self.relative_path_to_abs(
                filepath,
                importnode.modname,
                importnode.level
            )
            if full_import_path is not None:
                importnode.level = None
                importnode.modname = full_import_path
