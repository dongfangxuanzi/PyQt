# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2020  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""replace support"""
import os
import logging
from ....util.cmp_func import py_sorted
from .... import get_app
from ..searchsupport import ItemToSearchIn, Match
from .replacesymbol import ReplaceRange
log = logging.getLogger(__name__)


class ItemtoReplaceIn(ItemToSearchIn):
    """Stores information about one item to replace in"""

    def __init__(self, fname, replacestr, editor_view=None):
        super().__init__(fname, editor_view)
        self.replacestr = replacestr
        self.replaces = []

    @staticmethod
    def compare_match_line_column(left, right):
        '''
        按匹配行号进行排序,如果左边行号小于右边行号,或者行号相等,
        左边列号小于右边列号,返回正值表示倒叙,
        否则表示正序,此排序函数表示按行列号进行倒叙排序
        '''
        if left.line < right.line:
            return 1
        if left.line == right.line:
            if left.start < right.start:
                return 1
        return -1

    @staticmethod
    def ensure_open_doc(filepath):
        filedoc = get_app().GetDocumentManager().GetDocument(filepath)
        if filedoc is None:
            fileview = get_app().GotoView(
                filepath,
                lineNum=0,
                colno=0,
                trace_track=False
            )
        else:
            fileview = filedoc.GetFirstView()
            filedoc.OnOpenDocument(filepath)
        return fileview

    @staticmethod
    def check_replace_available(match, replace_matches):
        for rep_match in replace_matches:
            if rep_match.line == match.line and rep_match.start < match.finish:
                return False
        return True

    def replace(self):
        """Perform replace within this item"""
        textview = self.view
        is_item_already_openend = False
        if textview is None:
            if not os.path.exists(self.fileName):
                return
            textview = self.ensure_open_doc(self.fileName)
            self.set_view(textview)
        else:
            is_item_already_openend = True
        # 按行列排倒叙
        sorted_matches = py_sorted(self.matches, self.compare_match_line_column)
        sorted_replaces = []
        for match in sorted_matches:
            line = match.line
            start = match.start
            end = match.finish
            if not self.check_replace_available(match, sorted_replaces):
                log.warning(
                    "replace text `%s` on match line %d, start %d, end %d fail",
                    self.replacestr,
                    match.line,
                    match.start,
                    match.finish
                )
                continue
            reprange = ReplaceRange(line, start, line, end)
            reprange.replace_with_text(textview, self.replacestr)
            rep_match = Match(match.line,
                              match.start,
                              match.start + len(self.replacestr),
                              match.symbol_type
                              )
            rep_match.text = match.text[0:start] + self.replacestr + match.text[end:]
            sorted_replaces.append(rep_match)
        # 恢复顺序
        for match in self.matches:
            for rep_match in sorted_replaces:
                if match.line == rep_match.line and (
                    match.start == rep_match.start and match.symbol_type == rep_match.symbol_type
                ):
                    self.replaces.append(rep_match)
                    break
        assert (len(self.matches) == len(self.replaces))
        content = self.get_file_content().splitlines()
        totallines = len(content)
        for match in self.replaces:
            self.rebuild_tooltip(content, totallines, match)
        itemdoc = textview.GetDocument()
        itemdoc.Save()
        if not is_item_already_openend:
            itemdoc.DeleteAllViews()
