import os.path
import os
from pkg_resources import resource_filename
from novalapp.plugin import plugin
from novalapp.util import utils
from novalapp.sidebar.sidebar import SideBar
from novalapp import _, get_app, prog_lang
from novalapp.plugin import iface
from .hierarchy_viewer import ClassHierarchyViewer
from .pkgutils import get_pkg_res_path

CLASS_HIERARCHY_VIEW_NAME = 'ClassHierarchyViewer'


def get_hierarchy_icon_path():
    pkg_dest_res_path = get_pkg_res_path()
    hierarchy_icon_path = os.path.join(pkg_dest_res_path, "hierarchy.png")
    return hierarchy_icon_path


class DrawClassPlugin(plugin.Plugin):
    """plugin description here..."""
    plugin.Implements(iface.MainWindowI)

    def plugit(self, parent):
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing DrawClass plugin")
        view = get_app().MainFrame.AddView(
            CLASS_HIERARCHY_VIEW_NAME,
            ClassHierarchyViewer,
            _("Classes Hierarchy"),
            SideBar.South,
            create=True,
            image_file=get_hierarchy_icon_path(),
            visible_in_menu=True,
            **{'plugin': self}
        )
        self.classes_hierarchy_viewer = view['instance']

    def GetMinVersion(self):
        """
        Override in subclasses to return the minimum version of novalide that
        the plugin is compatible with. By default it will return the current
        version of novalide.
        @return: version str
        """
        return "1.3.0"

    def InstallHook(self):
        """
        Override in subclasses to allow the plugin to be loaded
        dynamically.
        @return: None
        """

    def UninstallHook(self):
        pass

    def EnableHook(self):
        pass

    def DisableHook(self):
        pass

    def get_prog_lang(self):
        return prog_lang.LANGUAGE_NOTSET

    def required_packages(self):
        return ['matplotlib==3.11.1', 'networkx==3.6.1', 'pygraphviz']
