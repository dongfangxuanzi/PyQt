import os.path
import os
from pkg_resources import resource_filename


def get_pkg_res_path():
    # 调用resource_filename会解压插件包含的所有文件,覆盖到插件目的目录下的所有文件
    pkg_dest_path = resource_filename(__name__, '')
    return os.path.join(pkg_dest_path, "res")
