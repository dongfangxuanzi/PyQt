'''
Name:        render.py
Purpose:     使用matplotlib渲染生成类层次图
Author:      wukan
Created:     2026-07-25
Copyright:   (c) wukan 2026
Licence:     Mulan
'''
import argparse
import os
import logging
import json
import networkx as nx
import matplotlib.pyplot as plt


PLOT_IMAGE_NAME = 'plot.png'


def draw_fig(g, parent_class_name, base_classes):

    for base_class_info in base_classes:
        base_class_name = list(base_class_info.keys())[0]
        base_base_classes = base_class_info[base_class_name]
        # 添加边
        g.add_edge(parent_class_name, base_class_name)
        draw_fig(g, base_class_name, base_base_classes)


def main(class_file, outpath, node_size, arrow_size, show_fig=False):
    # 创建一个有向图
    g = nx.DiGraph()
    with open(class_file, encoding="ascii") as file:
        class_mro_info = json.load(file)
        class_name = list(class_mro_info.keys())[0]
        base_classes = class_mro_info[class_name]
        # 添加根节点
        g.add_node(class_name)
        draw_fig(g, class_name, base_classes)
    # 绘制图形
    pos = nx.nx_agraph.graphviz_layout(g, prog='dot')  # 使用Graphviz的布局算法
    nx.draw(
        g,
        pos,
        with_labels=True,
        arrows=True,
        node_color='lightblue',
        node_size=node_size,
        arrowstyle='-|>',
        arrowsize=arrow_size
    )
    if show_fig:
        plt.show()
    else:
        plt.savefig(os.path.join(outpath, PLOT_IMAGE_NAME))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--class-file",
        type=str,
        dest="class_file",
        help='class hierarchy file',
        required=True
    )
    parser.add_argument(
        "--nodesize",
        type=int,
        dest="nodesize",
        help='fig node size',
        default=3000,
        required=False
    )
    parser.add_argument(
        "--arrowsize",
        type=int,
        dest="arrowsize",
        help='fig arrow size',
        default=20,
        required=False
    )
    parser.add_argument(
        "-o",
        "--outpath",
        type=str,
        dest="out_path",
        help='fig save to path',
        required=True
    )
    parser.add_argument(
        "--show",
        action='store_true',
        dest="show_fig",
        help='show plot fig or not',
        default=False
    )
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)
    main(args.class_file, args.out_path, args.nodesize, args.arrowsize, args.show_fig)
