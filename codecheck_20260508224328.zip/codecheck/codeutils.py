import re
import enum
import os
import platformdirs
from astroid import nodes
from novalapp import constants, get_app, _
from novalapp.util import fileutils
from novalapp.python.symbol.replacesymbol.replacesymbol import ReplaceRange, ReplaceNode
from .strings import CODECHECK_TOOL_NANE


class FilesregType(enum.Enum):
    INCLUDE_FILES = 1
    EXCLUDE_FILES = 2


class ScanMode(enum.Enum):
    CHANGED_FILES_MODE = 1
    FULL_FILES_MODE = 2
    TIME_SECTION_FILES_MODE = 3


class AfterTimeSpan(enum.Enum):
    AFTER_CREATED_TIME = 1
    AFTER_MODIFIED_TIME = 2


def get_file_excludes_reg(text):
    regs = text.split("|")
    regstrs = [re.escape(regtext) for regtext in regs]
    regstr = "|".join(regstrs)
    return regstr


def get_codecheck_data_path():
    return os.path.dirname(platformdirs.user_data_path(CODECHECK_TOOL_NANE))


def get_tools_data_path():
    return os.path.join(get_codecheck_data_path(), "tools")


class FixRange(ReplaceRange):
    '''
    替换范围内的文本
    '''


def get_node_range(node):
    return FixRange.node_range(node)


def get_add_range(line, col):
    return FixRange.add_range(line, col)


DEFAULT_TAB_BLANKS = ' ' * constants.DEFAULT_TAB_WIDTH


class ImportNodes:
    def __init__(self, module, textview):
        self._module = module
        self._textview = textview

    def is_import_exist(self, modname):
        for child in self._module.body:
            if isinstance(child, nodes.Import):
                names = [name[0] for name in child.names]
                if modname in names:
                    return True
        return False

    def is_fromimport_exist(self, modname, import_name):
        for child in self._module.body:
            if isinstance(child, nodes.ImportFrom):
                if child.modname == modname:
                    return import_name in [name[0] for name in child.names]
        return False

    def get_import_nodes(self):
        '''
        获取模块范围内的所有导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, (nodes.Import, nodes.ImportFrom)):
                import_nodes.append(child)
        return import_nodes

    def get_top_import_nodes(self):
        '''
        获取模块开头的导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, nodes.Assign):
                valid_targets = [
                    isinstance(target, nodes.AssignName)
                    and target.name.startswith("__")
                    and target.name.endswith("__")
                    for target in child.targets
                ]
                if all(valid_targets):
                    continue
            if not isinstance(child, (nodes.Import, nodes.ImportFrom)):
                break
            import_nodes.append(child)
        return import_nodes

    def get_lastimport_node(self, top_imports):
        if top_imports:
            import_nodes = self.get_top_import_nodes()
        else:
            import_nodes = self.get_import_nodes()
        if not import_nodes:
            return None
        return import_nodes[-1]

    def get_import_line(self, top_imports=False):
        last_node = self.get_lastimport_node(top_imports)
        if last_node is not None:
            return last_node.lineno
        if self._module.doc_node is None:
            shebang_or_encoding_line = self._textview.get_shebang_encoding_line()
            return shebang_or_encoding_line
        return self.get_docstring_line()

    def get_docstring_line(self):
        return self._module.doc_node.end_lineno


def check_git_plugin_installed():
    plugin_name = 'gitcli'
    if get_app().GetPluginManager().GetPlugin(plugin_name) is None:
        raise RuntimeError(
            _('Plugin `%s` must be intalled if you use git tool') % plugin_name
        )


def get_file_linetext(filepath, lineindex):
    content = fileutils.get_file_content(filepath, allow_exception=False)
    if content is None:
        return None
    linetext = content.splitlines()[lineindex]
    return linetext


def get_file_lines(filepath, lineindex, endindex):
    content = fileutils.get_file_content(filepath, allow_exception=False)
    if content is None:
        return []
    return content.splitlines()[lineindex:endindex]


class FixNode(ReplaceNode):
    '''
    替换节点文本
    '''


def get_node_line_text(node):
    linetext = get_file_linetext(node.root().file, node.lineno - 1)
    return linetext


def get_node_col_offset_whitespaces_count(node):
    linetext = get_node_line_text(node)
    col_offset = node.col_offset - 1
    tabs_count = 0
    blanks_count = 0
    while col_offset >= 0:
        if linetext[col_offset] == '\t':
            tabs_count += 1
        else:
            blanks_count += 1
        col_offset -= 1
    return blanks_count, tabs_count


def get_node_col_offset_blanks(node):
    blanks_count, tabs_count = get_node_col_offset_whitespaces_count(node)
    if tabs_count > 0:
        return ' ' * blanks_count + '\t' * tabs_count
    return ' ' * node.col_offset


def get_node_col_offset(node):
    blanks_count, tabs_count = get_node_col_offset_whitespaces_count(node)
    if tabs_count > 0:
        return node.col_offset - tabs_count + tabs_count * constants.DEFAULT_TAB_WIDTH
    return node.col_offset
