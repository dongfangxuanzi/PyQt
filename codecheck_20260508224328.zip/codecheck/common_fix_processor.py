from novalapp import get_app, _
from novalapp.util import utils
from novalapp import globalkeys
from novalapp.lib.pyqt import QMessageBox
from novalapp.editor.textview import TextView
from .common_processor import CommonProcessor
from . import configkeys
from .codeutils import check_git_plugin_installed
from .exceptions import ProjectFileNotCommitError


class CommonFixProcessor(CommonProcessor):
    def __init__(self, parent, statusbar, processor_name):
        # 代码修复器默认禁止启动,只有在启动修复时才启用
        super().__init__(parent, statusbar, processor_name, False)
        # 被修复的文件数量
        self.fixed_file_count = 0
        # 是否是修复单个文件
        self.fix_one_file = False
        self._configs = {}

    def save_configs(self):
        check_mixed_eol = utils.profile_get_int(
            globalkeys.CHECK_EOL_KEY, False)
        self._configs[globalkeys.CHECK_EOL_KEY] = check_mixed_eol
        replace_tabs = utils.profile_get_int(
            globalkeys.CHECK_CODE_EDITOR_TABS_KEY, True)
        self._configs[globalkeys.CHECK_CODE_EDITOR_TABS_KEY] = replace_tabs
        check_file_modify = utils.profile_get_int(
            globalkeys.CHECK_FILE_MODIFY_KEY, True)
        self._configs[globalkeys.CHECK_FILE_MODIFY_KEY] = check_file_modify
        fix_import_nodes = utils.profile_get_int(globalkeys.FIX_IMPORT_NODES_KEY, False)
        self._configs[globalkeys.FIX_IMPORT_NODES_KEY] = fix_import_nodes
        self._configs[configkeys.CLOSE_OPENDOC_KEY] = utils.profile_get_int(
            configkeys.CLOSE_OPENDOC_KEY, True)

        TextView.FILE_MODIFY_ANSWER = QMessageBox.YesToAll
        get_app().MainFrame.reset_filechanged_answer = False

    def check_doc_commit_status(self, doc):
        if not utils.profile_get_int(
            configkeys.PROJECT_FILES_MUSTBE_COMMITED_KEY,
            True
        ):
            return
        check_git_plugin_installed()
        from git.repo import Repo, RepofileState
        from git.exceptions import UnmergeError
        repo = Repo(doc.GetPath())
        has_unmerged, commit_files = repo.status()
        if has_unmerged:
            raise UnmergeError(_('Repo has unmerged files!'))
        for commit_file in commit_files:
            if commit_file.file_state in [
                RepofileState.FILE_MODIFIED_UNSTAGED,
                RepofileState.FILE_MODIFIED_STAGED,
                RepofileState.FILE_NEW_STAGED
            ]:
                utils.get_logger().info(
                    "doc file %s is ready to commit",
                    commit_file.fullpath
                )
                raise ProjectFileNotCommitError(
                    _('Please commit repo files before fix codes')
                )

    def init(self, doc):
        super().init(doc)
        self.save_configs()
        # 修复单个文件时修复完成后不要关闭文件
        if self.fix_one_file:
            utils.profile_set(configkeys.CLOSE_OPENDOC_KEY, False)
        utils.profile_set(globalkeys.CHECK_CODE_EDITOR_TABS_KEY, False)
        utils.profile_set(globalkeys.CHECK_EOL_KEY, False)
        utils.profile_set(globalkeys.FIX_IMPORT_NODES_KEY, False)
        self.fixed_file_count = 0
        self.check_doc_commit_status(doc)
        utils.get_logger().debug('check doc `%s` repo commit status success', doc.GetFilename())
        # 修复文件时禁止一些耗时的操作,以便加快修复速度
        projectview = get_app().MainFrame.projectview
        outlineview = get_app().MainFrame.outlineview
        try:
            utils.get_logger().debug('start disconnect notebook and projectview pyqt5 signal')
            projectview.sigFileUpdated.disconnect(
                projectview.update_analysis_data)
            get_app().MainFrame.GetNotebook().currentChanged.disconnect(
                outlineview._update_frame_contents)
            utils.get_logger().debug('disconnect notebook and projectview pyqt5 signal success')
            utils.get_logger().debug('start stop outline view show syntax tree')
            outlineview.SIG_SHOW_NONE_LABEL.emit(
                True,
                _('Fix processor running, Outline view is temporary disabled.')
            )
            outlineview.stop_outline_show(stop=True)
            utils.get_logger().debug('stop outline view show syntax tree success.')
        except TypeError:
            utils.get_logger().exception('init fix processor exception:')

    def end(self, doc):
        # 恢复被禁止的操作
        projectview = get_app().MainFrame.projectview
        projectview.sigFileUpdated.connect(projectview.update_analysis_data)
        outlineview = get_app().MainFrame.outlineview
        get_app().MainFrame.GetNotebook().currentChanged.connect(
            outlineview._update_frame_contents)
        outlineview.SIG_SHOW_NONE_LABEL.emit(False, "")
        outlineview.stop_outline_show(stop=False)
        self.fix_one_file = False
        super().end(doc)

    def restore_configs(self):
        for config_key, value in self._configs.items():
            utils.profile_set(config_key, value)
        get_app().MainFrame.reset_filechanged_answer = True
