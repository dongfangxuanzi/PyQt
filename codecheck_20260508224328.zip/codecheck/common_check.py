import re
import os
from novalapp.util import timeutils
from novalapp import _
from novalapp.lib.pyqt import QMessageBox
from novalapp.util import utils
from . import configkeys
from .codeutils import get_file_excludes_reg, FilesregType, ScanMode


class CommonChecker:
    """description of class"""

    def __init__(self):
        self.scan_mode = ScanMode.FULL_FILES_MODE.value
        self.changed_files = []
        self.base_timestamp = -1

    def get_changed_files(self, doc):
        '''
        检测项目仓库修改待提交文件
        '''
        changed_files = []
        try:
            from git.repo import Repo, RepofileState
            from git.exceptions import UnmergeError
            repo = Repo(doc.GetPath())
            has_unmerged, commit_files = repo.status()
            if has_unmerged:
                raise UnmergeError(_('Repo has unmerged files!'))
            for commit_file in commit_files:
                if commit_file.file_state in [
                    RepofileState.FILE_MODIFIED_UNSTAGED,
                    RepofileState.FILE_MODIFIED_STAGED,
                    RepofileState.FILE_NEW_STAGED
                ]:
                    changed_files.append(commit_file.fullpath)
            # 如果本次文件没有变更,则获取最近一次提交的文件变更
            if not changed_files:
                current_branch = repo.branch()
                commit_ids = repo.logs(current_branch, 10)
                last_commit_id = commit_ids[0]
                changed_files = repo.list_status_files(last_commit_id, fullpath=True)
                utils.get_logger().debug(
                    'get project doc %s branch %s recent commit id is:%s,changed files count is:%d',
                    doc.GetModel().name,
                    current_branch,
                    last_commit_id,
                    len(changed_files)
                )
        except Exception as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(doc.GetFirstView().GetFrame(), _("Error"), str(ex))
        return changed_files

    def init_checker(self, doc):
        self.scan_mode = utils.profile_get_int(
            doc.GetKey(configkeys.SCAN_MODE_KEY),
            ScanMode.FULL_FILES_MODE.value
        )
        utils.get_logger().debug(
            'project %s codecheck mode is %d',
            doc.GetModel().name,
            self.scan_mode
        )
        if self.scan_mode == ScanMode.CHANGED_FILES_MODE.value:
            self.changed_files = self.get_changed_files(doc)
            utils.get_logger().info(
                'codecheck mode is changed files mode and collect project %s changed files count is %d',
                doc.GetModel().name,
                len(self.changed_files)
            )

        elif self.scan_mode == ScanMode.TIME_SECTION_FILES_MODE.value:
            self.base_timestamp = utils.profile_get_int(
                doc.GetKey(configkeys.BASE_TIMESTAMP_KEY),
                -1
            )

    @staticmethod
    def is_filepath_excluded(doc, filepath):
        is_file_excluded = False
        file_reg_type = utils.profile_get_int(
            doc.GetKey(configkeys.FILES_REGTYPE_KEY), -1)
        if file_reg_type == FilesregType.EXCLUDE_FILES.value:
            regtext = utils.profile_get(doc.GetKey(
                configkeys.CODECHECK_EXCLUDE_FILES_KEY), "")
            if regtext:
                regstr = get_file_excludes_reg(regtext)
                if re.search(regstr, filepath, re.I):
                    is_file_excluded = True
        elif file_reg_type == FilesregType.INCLUDE_FILES.value:
            regtext = utils.profile_get(doc.GetKey(
                configkeys.CODECHECK_INCLUDE_FILES_KEY), "")
            if regtext:
                regstr = get_file_excludes_reg(regtext)
                if not re.search(regstr, filepath, re.I):
                    is_file_excluded = True
        return is_file_excluded

    def check_enabled(self, doc, filepath):
        is_file_excluded = self.is_filepath_excluded(doc, filepath)
        if is_file_excluded:
            utils.get_logger().info("file %s is excluded...", filepath)
            super().update_progress(filepath)
            return False
        if self.scan_mode == ScanMode.CHANGED_FILES_MODE.value:
            if filepath not in self.changed_files:
                utils.get_logger().info("file %s is not in changed files......", filepath)
                return False
            utils.get_logger().debug("file %s is in changed files......", filepath)
        elif self.scan_mode == ScanMode.TIME_SECTION_FILES_MODE.value:
            file_mktime = os.path.getmtime(filepath)
            utils.get_logger().debug(
                "file %s modify datetime is :%s, timespan mode base datetime is:%s",
                filepath,
                timeutils.timestamp_to_timestr(file_mktime),
                timeutils.timestamp_to_timestr(self.base_timestamp)
            )
            if file_mktime > self.base_timestamp:
                return True
            utils.get_logger().info(
                "file %s modify datetime less then timespan mode base datetime",
                filepath
            )
            return False
        return True
