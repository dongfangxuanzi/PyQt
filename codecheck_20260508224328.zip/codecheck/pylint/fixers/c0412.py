import os
import re
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import ImportNodes, get_add_range, FixNode


class PylintC0412Fixer(PylintFixer):
    '''
    规则说明: 顶层父模块相同的导入语句要分组集中在一起
    '''

    def __init__(self):
        super().__init__('C0412', True)

    @staticmethod
    def match_package_import_name(package_name, import_node):
        import_node_name = import_node.as_string()
        return re.search(
            rf"from\s+{package_name}\.|import\s+{package_name}\.|import\s+{package_name}|from\s+{package_name}\s+import\s+",
            import_node_name)

    @classmethod
    def find_nogroup_import_nodes(cls, package_name, import_nodes, before_import_node):
        in_group = False
        nogroup_nodes = []
        for import_node in import_nodes:
            if cls.match_package_import_name(package_name, import_node):
                in_group = True
            if in_group and not cls.match_package_import_name(package_name, import_node):
                nogroup_nodes.append(import_node)
            if import_node == before_import_node:
                break
        return nogroup_nodes

    @classmethod
    def find_insert_import_node(cls, package_name, import_nodes):
        for import_node in import_nodes:
            if cls.match_package_import_name(package_name, import_node):
                return import_node
        return None

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        res = re.search(
            r"Imports from package (\w+) are not grouped \(ungrouped-imports\)",
            msg.msg
        )
        if not res:
            return False
        package_name = res.groups()[0]
        visitor = ImportNodes(textview.ModuleAnalyzer.Module, textview)
        import_node = self.find_msg_node(textview, msg)
        import_nodes = visitor.get_import_nodes()
        nogroup_nodes = self.find_nogroup_import_nodes(package_name, import_nodes, import_node)
        insert_import_node = self.find_insert_import_node(package_name, import_nodes)
        if not insert_import_node:
            return False
        if nogroup_nodes:
            fix_node = nogroup_nodes[-1]
        else:
            fix_node = import_node
        fixvalue = FixNode(fix_node, textview)
        fixvalue.replace_node_with_text("")
        add_range = get_add_range(insert_import_node.lineno, 0)
        add_range.add_text(textview, fix_node.as_string() + os.linesep)
        return True
