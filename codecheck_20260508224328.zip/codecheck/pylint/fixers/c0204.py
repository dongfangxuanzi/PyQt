import re
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode
from ...pylint_fix import PylintFixer


class PylintC0204Fixer(PylintFixer):
    '''
    规则说明:类元方法以mcs作为第一个参数名
    '''

    def __init__(self):
        super().__init__('C0204', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        res = re.search(
            r"Metaclass class method (.*) should have 'mcs' as first argument \(bad-mcs-classmethod-argument\)",
            msg.msg
        )
        nodename = res.groups()[0]
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and nodename == node.name:
            if node.parent.args.args:
                first_arg = node.parent.args.args[0]
                if isinstance(first_arg, nodes.AssignName) and first_arg.name == 'mcs':
                    return False
                fix_args_node = FixNode(first_arg, textview)
                fix_args_node.replace_node_with_text("mcs")
                return True
        return False
