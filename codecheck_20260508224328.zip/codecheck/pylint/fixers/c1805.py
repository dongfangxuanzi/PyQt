import re
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode


class PylintC1805Fixer(PylintFixer):
    '''
    规则说明: 判断列表是否未空,不能用列表长度为0判断,使用逻辑表达式即可
    '''

    def __init__(self):
        super().__init__('C1805', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg, use_column=True)
        if not node:
            return False
        res = re.search(
            r'"(.*)" can be simplified to "(.*)", if it is strictly an int, as 0 is falsey \(use-implicit-booleaness-not-comparison-to-zero\)',
            msg.msg
        )
        pnode = node.parent
        if isinstance(pnode, nodes.Compare) and res:
            nodestr = res.groups()[1]
            if pnode.ops and pnode.ops[0] and nodestr.find('len(') != -1:
                repname = re.search(r"len\((.*)\)", nodestr).groups()[0]
                nodestr = nodestr.replace("len(", "").replace(")", "")
                if pnode.ops[0][0] == '==':
                    fixnode = FixNode(pnode, textview)
                    fixnode.replace_node_with_text(f'not {repname}')
                    return True
                if pnode.ops[0][0] == '!=':
                    fixnode = FixNode(pnode, textview)
                    fixnode.replace_node_with_text(f'{repname}')
                    return True
        return False
