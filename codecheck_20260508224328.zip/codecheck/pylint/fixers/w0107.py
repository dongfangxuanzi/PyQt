from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg


class PylintW0107Fixer(PylintFixer):
    '''
    规则说明:多余的pass语句
    '''

    def __init__(self):
        super().__init__('W0107', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        node = textview.ModuleAnalyzer.find_line_node(line, scope)
        if node is None or not isinstance(node, nodes.Pass):
            return False
        textview.delete_line(line - 1)
        return True
