import re
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg


class PylintW0511Fixer(PylintFixer):
    '''
    规则说明:fixme/todo注释
    '''

    def __init__(self):
        super().__init__('W0511', False)

    @classmethod
    def is_todo_line(cls, textctrl, msg):
        line_text = cls.get_msg_line_text(msg, textctrl)
        if not re.search(r'#\s*(todo|fixme|XXX)', line_text, re.I):
            return False
        return True

    @classmethod
    def delete_comment_msg_line(cls, textview, textctrl, msg):
        '''
        删除注释行,如果注释在行首则删除整行,如果注释在行尾,则删除行尾注释,不影响代码
        '''
        cls.delete_comment_line(textview, textctrl, msg.line - 1)

    @classmethod
    def delete_comment_line(cls, textview, textctrl, line):
        '''
        删除注释行,如果注释在行首则删除整行,如果注释在行尾,则删除行尾注释,不影响代码
        '''
        line_text = textctrl.get_line_text(line)
        msg_line = line
        if line_text.lstrip().startswith('#'):
            textview.delete_line(msg_line)
        else:
            comment_index = line_text.find('#')
            start_pos = textctrl.position_from_linecol(
                msg_line, comment_index)
            end_pos = textctrl.position_from_linecol(msg_line, len(line_text))
            textctrl.replace_target(start_pos, end_pos, '')

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        if not self.is_todo_line(textctrl, msg):
            return False
        self.delete_comment_msg_line(textview, textctrl, msg)
        return True
