# -*- coding: utf-8 -*-
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode
from ...pylint_fix import PylintFixer


class PylintW0104Fixer(PylintFixer):
    '''
    规则说明:无效的语句
    '''

    def __init__(self):
        super().__init__('W0104', False)

    @staticmethod
    def get_fix_node(node):
        parent_node = node
        lineno = parent_node.lineno
        fixnode = parent_node
        while parent_node.lineno == lineno:
            parent_node = parent_node.parent
            if parent_node.lineno == lineno:
                fixnode = parent_node
        return fixnode

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg, use_column=True)
        fixnode = self.get_fix_node(node)
        if not isinstance(fixnode, nodes.Expr):
            return False
        exprnode = FixNode(fixnode, textview)
        exprnode.replace_node_with_text('')
        return True
