import os
from astroid import nodes
from novalapp.python.parser.node_utils import get_builtin_type, safe_infer
from novalapp.util import strutils
from ...basefix import fix_code_file_msg
from ...pylint_fix import PylintFixer
from ...codeutils import ImportNodes, get_add_range, FixNode


class PylintW0102Fixer(PylintFixer):
    '''
    规则说明:参数默认值不能使用字典列表作为默认值
    '''
    KNOWN_VAR_TYPES = {
        nodes.List: 'list',
        nodes.Set: 'set',
        nodes.Dict: 'dict'
    }

    def __init__(self):
        super().__init__('W0102', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef):
            return self.fix_dangerous_default_value(node.parent, textview)
        if isinstance(node, nodes.AssignName) and (
            isinstance(node.parent, nodes.Arguments) and isinstance(node.parent.parent, nodes.FunctionDef)
        ):
            return self.fix_dangerous_default_value(node.parent.parent, textview)
        return False

    def fix_dangerous_default_value(self, node, textview):
        danger_index = -1
        default_args = node.args.defaults or node.args.kw_defaults
        defaults_num = len(default_args)
        for i, default_val in enumerate(default_args):
            if isinstance(default_val, (nodes.List, nodes.Dict)):
                danger_index = i - defaults_num
                break
        if node.args.defaults:
            default_arg = node.args.args[danger_index]
        elif node.args.kw_defaults:
            default_arg = node.args.kwonlyargs[danger_index]
        default_val = default_args[danger_index]

        fixvalue = FixNode(default_val, textview)
        fixvalue.replace_node_with_text("None")

        fixarg = FixNode(default_arg, textview)
        optional_name = 'Optional'
        try:
            builtin_type_name = get_builtin_type(default_val)
        except AttributeError:
            infer_default_val = safe_infer(default_val)
            builtin_type_name = self.KNOWN_VAR_TYPES.get(type(infer_default_val))
            if strutils.is_none_empty(builtin_type_name):
                return False
        reptext = default_arg.name + f": {optional_name}[{builtin_type_name}]"
        fixarg.replace_node_with_text(reptext)

        first_body = node.body[0]
        insert_line = first_body.lineno
        blanks = first_body.col_offset * ' '
        add_range = get_add_range(insert_line, 0)
        add_range.add_text(
            textview,
            blanks + f'{default_arg.name}={default_arg.name} or {default_val.as_string()}' + os.linesep
        )

        visitor = ImportNodes(
            textview.ModuleAnalyzer.Module, textview)
        if not visitor.is_fromimport_exist('typing', optional_name):
            insert_line = visitor.get_import_line()
            add_range = get_add_range(insert_line + 1, 0)
            add_range.add_text(textview, f"from typing import {optional_name}" + os.linesep)
        return True
