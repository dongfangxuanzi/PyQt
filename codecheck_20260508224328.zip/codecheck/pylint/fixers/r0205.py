import re
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixRange


class PylintR0205Fixer(PylintFixer):
    '''
    规则说明:类显式继承object多余
    '''

    def __init__(self):
        super().__init__('R0205', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        line = msg.line
        line_text = self.get_msg_line_text(msg, textctrl)
        regstr = r'\(\s*object\s*\)'
        if re.search(regstr, line_text):
            fix_range = FixRange(line)
            replace_text = re.sub(regstr, '', line_text)
            fix_range.replace_line(textview, replace_text)
            return True
        return False
