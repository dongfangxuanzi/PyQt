import re
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixRange


class PylintR1725Fixer(PylintFixer):
    '''
    规则说明:使用super关键字来调用父类构造函数
    '''

    def __init__(self):
        super().__init__('R1725', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        line = msg.line
        line_text = self.get_msg_line_text(msg, textctrl)
        regstr = r'super\s*\(.*\)\.'
        if re.search(regstr, line_text):
            fix_range = FixRange(line)
            replace_text = re.sub(regstr, "super().", line_text)
            fix_range.replace_line(textview, replace_text)
            return True
        return False


class PylintE1003Fixer(PylintR1725Fixer):

    def __init__(self):
        PylintFixer.__init__(self, 'E1003', True)
