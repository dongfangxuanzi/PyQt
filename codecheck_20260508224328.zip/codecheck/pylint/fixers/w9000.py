from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg


class PylintW9000Fixer(PylintFixer):
    '''
    规则说明: 注释无效/废弃代码
    '''

    def __init__(self):
        super().__init__('W9000', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        linetext = self.get_msg_line_text(msg, textctrl)
        if not linetext.lstrip().startswith('#'):
            return False
        textview.delete_line(msg.line - 1)
        return True
