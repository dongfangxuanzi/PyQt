import re
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode
from ...pylint_fix import PylintFixer


class PylintR1729Fixer(PylintFixer):
    '''
    规则说明:any表达式参数用生成式代替列表表达式
    '''

    def __init__(self):
        super().__init__('R1729', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg, use_column=True)
        res = re.search(r"Use a generator instead '(.*)' \(use-a-generator\)", msg.msg)
        if not res:
            return False
        pnode = node.parent
        if isinstance(node, nodes.Name) and node.name == "any" and (
            isinstance(pnode, nodes.Call) and isinstance(pnode.args[0], nodes.ListComp)
        ):
            repstr = res.groups()[0]
            fixnode = FixNode(pnode, textview)
            fixnode.replace_node_with_text(repstr)
            return True
        return False
