import re
import os
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import get_add_range
from ...pylint_fix import PylintFixer


class PylintW0613Fixer(PylintFixer):
    '''
    规则说明:未使用的参数
    '''

    def __init__(self):
        super().__init__('W0613', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg, use_column=True)
        res = re.search(
            r"Unused argument '(\w+)' \(unused-argument\)", msg.msg)
        if not node or not res:
            return False
        unused_arg = res.groups()[0]
        if isinstance(node, nodes.AssignName) and (
            isinstance(node.parent, nodes.Arguments) and node.name == unused_arg
        ):
            funcnode = node.parent.parent
            first_body = funcnode.body[0]
            insert_line = first_body.lineno
            blanks = first_body.col_offset * ' '
            add_range = get_add_range(insert_line, 0)
            add_range.add_text(
                textview,
                blanks + f"del {unused_arg}" + os.linesep
            )
            return True
        return False
