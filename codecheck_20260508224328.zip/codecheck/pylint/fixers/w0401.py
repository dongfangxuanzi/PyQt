from ...pylint_fix import PylintFixer


class PylintW0401Fixer(PylintFixer):
    '''
    规则说明: 导入语句使用`from module import *`
    '''

    def __init__(self):
        super().__init__('W0401', False)
