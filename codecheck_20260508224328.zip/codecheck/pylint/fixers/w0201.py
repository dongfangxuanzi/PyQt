import os
import re
from astroid import nodes
from novalapp.widgets import simpledialog
from novalapp.python.parser.define import SELF_ARG_NAME, CLASS_INIT_METHOD
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp import _
from novalapp.lib.pyqt import QRadioButton
from .e0601 import PylintE0601Fixer
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import get_add_range, FixNode


class AttributeInitDialog(simpledialog.SingleChoiceDialog):
    def __init__(self, attrname, choices, master):
        title = "Init self attribute name"
        descrption = "Please choose attribute '%s' one initial value" % attrname
        super().__init__(
            title,
            descrption,
            choices,
            0,
            master
        )
        self.rb_remove_attr = QRadioButton(_('Remove attribute node'))
        self.layout.insertWidget(2, self.rb_remove_attr)


class PylintW0201Fixer(PylintFixer):
    '''
    规则说明:在__init__方法外初始化类属性
    '''

    def __init__(self):
        super().__init__('W0201', False)

    @staticmethod
    def get_class_func(funcname, classnode):
        for childnode in classnode.body:
            if isinstance(childnode, nodes.FunctionDef) and childnode.name == funcname:
                return childnode
        return None

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg, use_column=True)
        res = re.search(
            r"Attribute '(.*)' defined outside __init__ \(attribute-defined-outside-init\)",
            msg.msg
        )
        classnode = ScopeFinder(textview.ModuleAnalyzer.Module).get_class_scope(node)
        if not node or not res or not classnode:
            return False
        attrname = res.groups()[0]
        if isinstance(node, nodes.Name) and node.name == SELF_ARG_NAME and (
            isinstance(node.parent, nodes.AssignAttr) and attrname == node.parent.attrname
        ):
            init_method_node = self.get_class_func(CLASS_INIT_METHOD, classnode)
            if init_method_node is None:
                return False
            init_values = PylintE0601Fixer.get_init_values()
            choices = init_values.values()
            dlg = AttributeInitDialog(attrname, choices, master=text_ctrl)
            dlg.exec_()
            sel = dlg.selection
            if sel == -1:
                return False
            remove_attr = dlg.rb_remove_attr.isChecked()
            if remove_attr:
                fixvalue = FixNode(node.parent.parent, textview)
                fixvalue.replace_node_with_text("")
            end_body = init_method_node.body[-1]
            insert_line = init_method_node.end_lineno
            blanks = end_body.col_offset * ' '
            add_range = get_add_range(insert_line + 1, 0)
            init_atr_value = list(init_values.keys())[sel]
            add_range.add_text(
                textview,
                blanks + f"{node.parent.as_string()}={init_atr_value}" + os.linesep
            )
            return True
        return False
