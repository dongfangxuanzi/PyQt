import re
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode


class PylintW0238Fixer(PylintFixer):
    '''
    规则说明: 私有方法/属性未被使用
    '''

    def __init__(self):
        super().__init__('W0238', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        regstr = r"Unused private member `(.*)` \(unused-private-member\)"
        res = re.search(regstr, msg.msg)
        node = self.find_msg_node(textview, msg)
        if not res or not node:
            return False
        result = res.groups()[0]
        results = result.split('.')
        str_parts = re.split('[(,)]', results[1])
        if isinstance(node, nodes.Name) and (
            isinstance(node.parent, nodes.FunctionDef) and str_parts[0] == node.name
        ):
            fixnode = FixNode(node.parent, textview)
            fixnode.replace_node_with_text('')
            return True

        if isinstance(node, nodes.Assign):
            target = node.targets[0]
            if isinstance(target, nodes.AssignAttr) and str_parts[0] == target.attrname:
                fixnode = FixNode(node, textview)
                fixnode.replace_node_with_text('')
                return True
        return False
