# -*- coding: utf-8 -*-
import re
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode


class PylintW0602Fixer(PylintFixer):
    '''
    规则说明:仅使用全局变量未赋值,不需要使用global申明
    '''

    def __init__(self):
        super().__init__('W0602', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        res = re.search(
            r"Using global for '(.*)' but no assignment is done \(global-variable-not-assigned\)",
            msg.msg
        )

        if not res:
            return False
        globalname = res.groups()[0]
        node = self.find_msg_node(textview, msg, use_column=True)
        if isinstance(node, nodes.Global) and globalname in node.names:
            node.names.remove(globalname)
            fixnode = FixNode(node, textview)
            if not node.names:
                fixnode.replace_node_with_text('')
            else:
                fixnode.replace_node_with_text(node.as_string())
            return True
        return False
