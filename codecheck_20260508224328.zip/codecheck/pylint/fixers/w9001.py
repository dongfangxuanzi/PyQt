from novalapp import constants
from ...basefix import fix_code_file_msg
from ...codeutils import FixRange
from ...pylint_fix import PylintFixer


class PylintW9001Fixer(PylintFixer):
    '''
    规则说明: 代码中包含tab键
    '''

    def __init__(self):
        super().__init__('W9001', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        linetext = self.get_msg_line_text(msg, textctrl)
        if linetext.find('\t') == -1:
            return False
        fix_range = FixRange(msg.line)
        newtext = linetext.expandtabs(constants.DEFAULT_TAB_INDENTATION_WIDTH)
        fix_range.replace_line(textview, newtext)
        return True
