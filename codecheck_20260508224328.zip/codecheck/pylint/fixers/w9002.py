from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode


class PylintW9002Fixer(PylintFixer):
    '''
    规则说明: 发布代码中使用断言
    '''

    def __init__(self):
        super().__init__('W9002', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.Assert):
            FixNode(node, textview).replace_node_with_text('')
            return True
        return False
