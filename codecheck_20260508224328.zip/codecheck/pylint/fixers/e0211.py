import re
from novalapp.python.parser.define import CLASS_METHOD_NAME
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import FixRange, get_node_col_offset_blanks
from ...pylint_fix import SarifFixer


class PylintE0211Fixer(SarifFixer):
    '''
    规则说明:类成员方法参数为空,至少需要有1个self参数
    '''

    def __init__(self):
        super().__init__('E0211', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        res = re.search(
            r"Method '(.*)' has no argument \(no-method-argument\)",
            msg.msg
        )
        nodename = res.groups()[0]
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and nodename == node.name:
            if CLASS_METHOD_NAME == node.parent.type:
                start_line = node.lineno
                if not node.parent.args.args:
                    fix_range = FixRange(start_line)
                    newtext = get_node_col_offset_blanks(node.parent) + f"def {node.name}(cls):"
                    fix_range.replace_line(textview, newtext)
                return True
        return False
