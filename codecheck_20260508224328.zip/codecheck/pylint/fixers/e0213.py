import re
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import FixRange
from ...pylint_fix import SarifFixer


class PylintE0213Fixer(SarifFixer):
    '''
    规则说明:类成员方法必须用self作为第一个参数
    '''

    def __init__(self):
        super().__init__('E0213', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        res = re.search(
            r"Method '(.*)' should have \"self\" as first argument \(no-self-argument\)",
            msg.msg
        )
        nodename = res.groups()[0]
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and nodename == node.name:
            start_line = node.lineno
            if node.parent.args.args:
                first_arg = node.parent.args.args[0]
                if isinstance(first_arg, nodes.AssignName) and first_arg.name == 'self':
                    return False
                start_column = first_arg.col_offset
                fix_args_node = FixRange(start_line, start_column)
                fix_args_node.add_text(textview, "self,")
                return True
        return False
