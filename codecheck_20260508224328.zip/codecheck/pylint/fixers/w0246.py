from astroid import nodes
from novalapp.python.parser.define import CLASS_INIT_METHOD
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode


class PylintW0246Fixer(PylintFixer):
    '''
    规则说明:显式继承父类__init__方法多余,调用父类__init__方法后没有其它操作,
    可以删除显式继承的__init__方法
    '''

    def __init__(self):
        super().__init__('W0246', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.Name) and (
            isinstance(node.parent, nodes.FunctionDef) and node.parent.name == CLASS_INIT_METHOD
        ):
            fixvalue = FixNode(node.parent, textview)
            fixvalue.replace_node_with_text("")
            return True
        return False
