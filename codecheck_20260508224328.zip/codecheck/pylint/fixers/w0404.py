import re
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg


class PylintW0404Fixer(PylintFixer):
    '''
    规则说明:重复导入模块
    '''

    def __init__(self):
        super().__init__('W0404', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(line)
        if node is None:
            return False
        res = re.search(
            r"Reimport '(\w+)' \(imported line (\d+)\) \(reimported\)", msg.msg)
        if res is None:
            return False
        import_name, import_line = res.groups()
        if isinstance(node, (nodes.Import, nodes.ImportFrom)):
            return self.delete_import_name(node, import_name, textview)
        return False
