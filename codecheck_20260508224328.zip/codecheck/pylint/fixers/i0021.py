import re
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixRange
from .w0511 import PylintW0511Fixer


class PylintI0021Fixer(PylintFixer):
    '''
    规则说明:无用的抑制规则格式语句,抑制的规则可能不存在或者已经失效过期
    '''

    def __init__(self):
        super().__init__('I0021', True)

    @staticmethod
    def is_rule_id(ruletext):
        return re.search(r'\w{1}\d{3,}', ruletext)

    @classmethod
    def search_suppressed_line(cls, textctrl, line):
        linetext = textctrl.get_line_text(line)
        return cls.search_suppressed_linetext(linetext)

    @staticmethod
    def search_suppressed_linetext(linetext):
        regtext = r'#\s*pylint:\s*disable=\s*(.*)'
        res = re.search(regtext, linetext)
        return res

    @classmethod
    def search_suppressed_ruleid(cls, linetext):
        res = cls.search_suppressed_linetext(linetext)
        return res.groups()[0]

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        line_text = self.get_msg_line_text(msg, textctrl)
        if line_text is None:
            return False
        res = self.search_suppressed_linetext(line_text)
        if res:
            ruletext = res.groups()[0]
            msgres = re.search(
                r"Useless suppression of '(.*)' \(useless-suppression\)", msg.msg)
            msg_rulename = msgres.groups()[0]
            if ruletext != msg_rulename:
                fix_range = FixRange(msg.line)
                newtext = line_text.replace(ruletext, msg_rulename)
                fix_range.replace_line(textview, newtext)
            else:
                PylintW0511Fixer.delete_comment_msg_line(textview, textctrl, msg)
            return True
        return False


class PylintI0020Fixer(PylintI0021Fixer):
    '''
    规则说明: pylint抑制规则格式语句
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'I0020', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        res = re.search(
            r"Suppressed '(.*)' \(from line (\d+)\) \(suppressed-message\)", msg.msg)
        suppressed_line = int(res.groups()[1])
        res = self.search_suppressed_line(textctrl, suppressed_line - 1)
        if res:
            PylintW0511Fixer.delete_comment_line(textview, textctrl, suppressed_line - 1)
            return True
        return False


class PylintI0023Fixer(PylintI0021Fixer):
    '''
    规则说明:抑制规则不要使用比较模糊的规则编号,应使用规则名称
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'I0023', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        line_text = self.get_msg_line_text(msg, textctrl)
        if line_text is None:
            return False
        res = self.search_suppressed_linetext(line_text)
        if not res:
            return False
        ruleid = res.groups()[0]
        res = re.search(
            r"'(.*)' is cryptic: use '(.*)' instead \(use-symbolic-message-instead\)",
            msg.msg
        )
        msg_ruleid, suppressed_text = res.groups()
        if ruleid == msg_ruleid:
            msg_rulename = self.search_suppressed_ruleid(suppressed_text)
            fix_range = FixRange(msg.line)
            newtext = line_text.replace(ruleid, msg_rulename)
            fix_range.replace_line(textview, newtext)
            return True
        return False
