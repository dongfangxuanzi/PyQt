from ...pylint_fix import SarifFixer


class PylintW0718Fixer(SarifFixer):
    '''
    规则说明:捕获Exception异常,太宽泛了
    '''

    def __init__(self):
        super().__init__('W0718', False)
