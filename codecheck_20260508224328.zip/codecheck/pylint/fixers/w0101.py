from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode


class PylintW0101Fixer(PylintFixer):
    '''
    规则说明:永远不能执行或到达的代码段
    '''

    def __init__(self):
        super().__init__('W0101', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        prev_node = node.previous_sibling()
        if not isinstance(prev_node, (nodes.Return, nodes.Raise)):
            return False
        fixnode = FixNode(node, textview)
        fixnode.replace_node_with_text('')
        return True
