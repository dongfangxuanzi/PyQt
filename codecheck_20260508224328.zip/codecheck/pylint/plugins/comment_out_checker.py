# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/PyCQA/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/PyCQA/pylint/blob/main/CONTRIBUTORS.txt
"""comment out code checker"""
from __future__ import annotations
from typing import TYPE_CHECKING
from astroid import nodes
from pylint.checkers import BaseRawFileChecker
from pylint.checkers.utils import only_required_for_messages
import astroid
from astroid.exceptions import AstroidError
from eradicate import Eradicator
if TYPE_CHECKING:
    from pylint.lint import PyLinter


class CommentOutChecker(BaseRawFileChecker):
    name = "comment-out"
    msgs = {
        "W9000": (
            "Comment out unnecessary code without delete them",
            "code-commented-out",
            "Delete unnecessary code segments, Dont't comment out them.",
        )
    }

    def __init__(self, linter: PyLinter) -> None:
        super().__init__(linter)
        self._eradicator = Eradicator()

    @only_required_for_messages("code-commented-out")
    def process_module(self, node: nodes.Module) -> None:
        """Process a module.
        The module's content is accessible via ``astroid.stream``
        """
        filepath = node.file
        content = ''
        try:
            with open(filepath, encoding="utf-8") as freader:
                content = freader.read()
                lines = self._eradicator.commented_out_code_line_numbers(
                    content,
                    aggressive=False
                )
                content_lines = content.splitlines()
                for lineindex in lines:
                    linetext = content_lines[lineindex - 1].strip().lstrip('#')
                    try:
                        linenode = astroid.extract_node(linetext)
                        # 有些文档注释包括姓名,作者,版权以及其它一些特殊信息被误认为注释代码,
                        # 这里排除掉这些有用的注释信息
                        if isinstance(linenode, nodes.AnnAssign) and linenode.value is None:
                            continue
                    except AstroidError:
                        pass
                    self.add_message("code-commented-out", line=lineindex)
        except:
            pass


def register(linter: PyLinter) -> None:
    linter.register_checker(CommentOutChecker(linter))
