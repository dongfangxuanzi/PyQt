from dataclasses import dataclass


@dataclass
class Metric:
    """description of class"""
    blank_lines_count: int
    comment_lines_count: int
    code_lines_count: int
    file_lines_count: int
    filepath: str
    language: str


@dataclass
class TotalMetric(Metric):
    files_count: int
