from html.parser import HTMLParser
import json
import re
import os
from novalapp.util import fileutils
from novalapp.util.urlutils import request_data


class Flak8RulesHtmlParser(HTMLParser):
    a_text = False
    rules = {}
    current_ruleid = None

    def handle_starttag(self, tag, attr):
        if tag == 'a':
            self.a_text = True

    def handle_endtag(self, tag):
        if tag == 'a':
            self.a_text = False

    def handle_data(self, data):
        if self.a_text:
            result = re.match(r'^\w{1}\d{3}$', data)
            if result:
                ruleid = data
                self.current_ruleid = ruleid
            else:
                if self.current_ruleid is not None:
                    if self.current_ruleid not in self.rules:
                        self.rules[self.current_ruleid] = data


def scan_flake8_rules():
    contents_file = 'contents.html'
    contents = fileutils.get_file_content(contents_file)
    if contents is None:
        pip_source = "https://www.flake8rules.com/"
        contents = request_data(pip_source, to_json=False)
        if contents is not None:
            if not os.path.exists(contents_file):
                with open(contents_file, "w") as f:
                    f.write(contents)

    html_parser = Flak8RulesHtmlParser()
    html_parser.feed(contents)
    html_parser.close()
    msgs = []
    for key, desc in html_parser.rules.items():
        msgs.append([key, desc])
    with open("flake8_rules.json", "w") as writer:
        json.dump(msgs, writer)


if __name__ == "__main__":
    scan_flake8_rules()
