# -*- coding: utf-8 -*-

import subprocess
import os

# -p后面第一个路径为输出翻译文件路径, 第二个路径为源文件路径
curdir = os.getcwd()
plugin_name = 'codecheck'
# 生成插件pot文件
cmd = r"C:\Users\HongYunVM\AppData\Local\Programs\Python\Python311\Scripts\pybabel.exe extract {0}/{1} --output-file {0}/{1}/locale/{1}.pot".format(
    curdir, plugin_name)
subprocess.call(cmd)

# po文件需要从pot文件更新,菜单Catalogue/Update from POT file
os.system(r'"C:\Program Files (x86)\Poedit\poedit.exe" {0}\{1}\locale\zh_CN.po'.format(
    curdir, plugin_name))
