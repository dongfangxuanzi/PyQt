import tempfile
import subprocess
import json
import re
from novalapp.common import compat
from novalapp.util import utils


def main():
    command = r'D:\env\codimension\venv\Scripts\pylint.exe --list-msgs'
    temp_file = tempfile.SpooledTemporaryFile(buffering=100 * 1000)
    fileno = temp_file.fileno()
    # 这里不能用管道,PIPE本身可容纳的量比较小,所以程序会卡死，所以一大堆内容输出过来的时候,会导致PIPE不足够处理这些内容,
    # 因此需要将输出内容定位到其他地方,例如临时文件等
    proc = subprocess.Popen(command, shell=True, stdout=fileno, stderr=fileno)
    # 读取临时文件的内容,打印错误输出信息
    # 从头读取,和一般文件对象不同,seek方法的执行不能少
    proc.wait()
    temp_file.seek(0)
    lines = []
    for line in temp_file:
        try:
            linestr = compat.ensure_string(line)
        except UnicodeDecodeError:
            linestr = compat.ensure_string(
                line, encoding=utils.get_default_locale_encoding())
        lines.append(linestr)
    msgs = []
    for i, linestr in enumerate(lines):
        regstr = r":(.*) \((\w+)\)"
        res = re.search(regstr, linestr)
        if res:
            msgid, msgname = res.groups()
            k = 1
            msg_description = ''
            while k < 5:
                msg_line = lines[i + k]
                if re.search(regstr, msg_line):
                    break
                msg_description += msg_line
                k += 1
            msgs.append([msgid, msgname, msg_description])
    with open("pylint_rules.json", "w") as writer:
        json.dump(msgs, writer)


if __name__ == "__main__":
    main()
