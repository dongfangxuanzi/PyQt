import re
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg


class PylintW0221Fixer(PylintFixer):
    '''
    规则说明: 继承方法的参数个数改变了
    '''

    def __init__(self):
        super().__init__('W0221', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        regstr = r"was (\d+) in '(.*)' and is now (\d+) in (.*) method"
        res = re.search(regstr, msg.msg)
        results = res.groups()
        print(res,results)
        node = self.find_msg_node(textview,msg)
        print(node,"--------------------------")
        if isinstance(node, nodes.FunctionDef):
            self.replace_variable_name_in_scope(
                textview, node, results[1], results[0])
            return True
        return False
