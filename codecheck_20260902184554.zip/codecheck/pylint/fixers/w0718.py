'''
Name:        w0718.py
Purpose:
异常捕获范围Exception/BaseException太宽泛,需要捕获具体类型的子异常
修复方法:
弹出所有内建异常类型,用户选择捕获某个异常类型
Author:      wukan
Created:     2026-08-09
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from novalapp.python.utility import get_builtin_exceptions
from ...multifixer import MultiOptionsFixer
from ...pylint_fix import PylintFixer


class PylintW0718Fixer(PylintFixer, MultiOptionsFixer):
    '''
    规则说明:捕获Exception异常,太宽泛了
    '''

    def __init__(self):
        super().__init__('W0718', False)
        MultiOptionsFixer.__init__(
            self,
            title='Fix bare except',
            descr="Please choose one exception type"
        )

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if not isinstance(node, nodes.ExceptHandler) or not (
            isinstance(node.type, nodes.Name) and node.type.name in ['Exception', 'BaseException']
        ):
            return False
        if not self._options:
            # 搜集所有内建异常类型
            get_builtin_exceptions(self._options)
        self.get_selection()
        if len(self.selections) == 1:
            self._sel = self.selections[0]
            self.fix_node_text(node.type, self._options[self.selection])
        else:
            exceptions = ",".join(self._options[selection] for selection in self.selections)
            self.fix_node_text(node.type, "(" + exceptions + ")")
        return True
