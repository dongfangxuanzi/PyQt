from typing import Optional, List
import logging
import keyboard
from slugify import slugify
from .exceptions import InvalidOptionIndexError
from .constants import USER_CANCEL_OPTION, USER_EXIT_PROG
log = logging.getLogger(__name__)


class MultiOptionFixer:
    """
    多个选择修复器
    返回其中一个修复器
    """
    IS_ESC_PRESSED = False
    INVAID_SEL_INDEX = -1

    def __init__(self, init_sel=0, title='', descr='', init_options: Optional[List]=None):
        init_options = init_options or []
        self._sel = init_sel
        self._options = init_options
        self._title = title
        self._descr = descr

    @property
    def selection(self):
        return self._sel

    @selection.setter
    def selection(self, sel):
        self._sel = sel

    @property
    def title(self):
        return self._title

    @property
    def description(self):
        return self._descr

    @property
    def options(self):
        return self._options

    @options.setter
    def options(self, options):
        self._options = options

    @staticmethod
    def slugify_str(txt):
        '''
        将含大写的命名风格转换为全部小写+下划线的命名风格
        '''
        chars = ''
        for i, ch in enumerate(txt):
            if i > 0 and ch.isupper() and not txt[i - 1].isupper():
                chars += ' '
            chars += ch
        r = slugify(chars, separator='_')
        if txt.startswith('__'):
            r = "__" + r
        elif txt.startswith('_'):
            r = "_" + r
        return r

    def set_title(self, title):
        self._title = title

    def set_description(self, descr):
        self._descr = descr

    def get_default_option_text(self):
        return self._title + "\n" + self.description + ":" + "\n"

    def get_selection(self):
        def on_esc(event):
            if event.name == "esc":
                self.IS_ESC_PRESSED = True
                # 模拟输入回车键,触发input返回
                keyboard.press_and_release('enter')
        if self.fix_only_autofix():
            return
        sel = self.INVAID_SEL_INDEX
        choices = self._options
        options_text = self.get_default_option_text()
        indexes = [str(i + 1) + ":" + choices[i] for i in range(len(choices))]
        indexes.append('Press [Enter] to choose default fix option')
        indexes.append('Press [Esc] to skip fix this warning')
        indexes.append('Press [exit] to exit the program')
        indexs_texts = "\n".join(indexes) + "\n"
        keyboard.on_press(on_esc)
        option_index_text = input(options_text + indexs_texts)
        if option_index_text.strip() == "exit":
            raise InvalidOptionIndexError(USER_EXIT_PROG)
        if not self.IS_ESC_PRESSED:
            if option_index_text:
                try:
                    sel = int(option_index_text)
                    if sel > len(choices):
                        raise ValueError
                    sel -= 1
                except ValueError as exc:
                    raise InvalidOptionIndexError('invalid option index') from exc
            else:
                sel = self._sel
                log.info(str(sel + 1))
        if sel == self.INVAID_SEL_INDEX:
            raise InvalidOptionIndexError(USER_CANCEL_OPTION)
        self.IS_ESC_PRESSED = False
        self._sel = sel

    def get_valid_identifier_name(self, varname, upper=False):
        if upper:
            self.options = ['slugify-uppercase', 'uppercase']
        else:
            self.options = ['slugify-lowercase', 'lowercase']
        self.get_selection()
        if self.selection == 1:
            if not upper:
                return varname.lower()
            return varname.upper()
        if not self.selection:
            slugify_name = self.slugify_str(varname)
            if not upper:
                return slugify_name
            return slugify_name.upper()
        raise InvalidOptionIndexError('invalid option index')

    def set_selection(self, sel):
        self._sel = sel


class MultiOptionsFixer(MultiOptionFixer):
    """
    多个选择修复器
    返回其中多个修复器
    """

    def __init__(self, title='', descr='', init_options: Optional[List]=None):
        super().__init__(-1, title, descr, init_options)
        self._selections = []

    @property
    def selections(self):
        return self._selections

    def get_selection(self):
        if self.fix_only_autofix():
            return
        choices = self._options
        self._selections = simpledialog.ask_list_many(
            self.title,
            self.description,
            choices,
            master=self._textctrl
        )
        if not self._selections:
            raise InvalidOptionIndexError('invalid options')
