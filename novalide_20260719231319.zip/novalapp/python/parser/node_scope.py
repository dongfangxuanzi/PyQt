import logging
from typing import List
from astroid import nodes
import astroid
from .definition import Definition
from . import node_utils
from .define import SUPER_CALL_METHOD_NAME, CLASS_INIT_METHOD, SELF_ARG_NAME, PROPERTY_METHOD_NAME
from .exceptions import OutofPythonPathError
from .node_utils import get_node_doc
from ... import get_app
log = logging.getLogger(__name__)


class ScopeFinder:
    def __init__(self, scope):
        self._scope = scope
        self._module = self._scope.root()

    @staticmethod
    def locate_in_scope(scope, line):
        if isinstance(scope, nodes.Module):
            return True
        if scope.lineno <= line <= scope.end_lineno:
            return True
        return False

    @staticmethod
    def is_scope(scope):
        '''
        常量节点有body属性,但是不是scope
        '''
        return hasattr(scope, 'body') and not isinstance(scope, nodes.Const)

    @staticmethod
    def is_class_funcdef_scope(scope):
        '''
        是否class/function scope
        '''
        return isinstance(scope, (nodes.ClassDef, nodes.FunctionDef))

    @staticmethod
    def is_parent_node_classtypes(
        node,
        parent_node_classes: List[nodes.NodeNG]
    ):
        '''
        判断多级父节点是否是某个类型
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if any(isinstance(parent_node, parent_node_class) for parent_node_class in parent_node_classes):
                return True
            parent_node = parent_node.parent
        return False

    @staticmethod
    def get_class_method_node(classnode, method_name):
        for childnode in classnode.body:
            if isinstance(childnode, nodes.FunctionDef) and childnode.name == method_name:
                return childnode
        return None

    @staticmethod
    def get_class_function_property_node(classnode, method_name):
        '''
        类属性get,set节点,方法名称都一样
        '''
        property_get_node = None
        property_set_node = None
        for childnode in classnode.body:
            if isinstance(childnode, nodes.FunctionDef) and childnode.name == method_name:
                decorators = childnode.decorators
                if decorators is not None:
                    for deco in decorators.nodes:
                        if isinstance(deco, nodes.Name) and deco.name == PROPERTY_METHOD_NAME:
                            property_get_node = childnode
                        elif isinstance(deco, nodes.Attribute) and deco.attrname == "setter":
                            property_set_node = childnode
        return property_get_node, property_set_node

    @staticmethod
    def get_parent_node_by_classtype(
        node,
        parent_node_classes: List[nodes.NodeNG]
    ):
        '''
        获取是某个类型的父节点
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if any(isinstance(parent_node, parent_node_class) for parent_node_class in parent_node_classes):
                return parent_node
            parent_node = parent_node.parent
        return None

    @staticmethod
    def get_parent_scope(
        node
    ):
        '''
        获取第一个有body属性的父节点,即范围节点
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None:
                break
            if hasattr(parent_node, 'body'):
                return parent_node
            parent_node = parent_node.parent
        return None

    @staticmethod
    def get_parent_nodes_by_classtype(
        node,
        parent_node_class: nodes.NodeNG
    ):
        '''
        获取是某个类型的父节点集合
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if isinstance(parent_node, parent_node_class):
                yield parent_node
            parent_node = parent_node.parent

    @classmethod
    def get_class_scope(cls, node):
        return cls.get_parent_node_by_classtype(
            node,
            [nodes.ClassDef]
        )

    @classmethod
    def get_function_scope(cls, node):
        return cls.get_parent_node_by_classtype(
            node,
            [nodes.FunctionDef]
        )

    @classmethod
    def get_parent_node_by_nodeclass(cls, node, node_class_type):
        return cls.get_parent_node_by_classtype(
            node,
            [node_class_type]
        )

    @classmethod
    def is_parent_node_classtype(
        cls,
        node,
        parent_node_class: nodes.NodeNG
    ):
        return cls.is_parent_node_classtypes(node, [parent_node_class])

    @classmethod
    def get_parent_class_node(cls, node):
        return cls.get_parent_node_by_classtype(node, [nodes.ClassDef])

    @classmethod
    def get_parent_scope_node(cls, node):
        parent_node = cls.get_parent_node_by_classtype(
            node, [nodes.ClassDef, nodes.FunctionDef]
        )
        if parent_node is not None:
            return parent_node
        return node.root()

    @classmethod
    def is_class_range(cls, node):
        return cls.is_parent_node_classtype(node, nodes.ClassDef)

    @classmethod
    def is_module_range(cls, node):
        parent_scope = cls.get_parent_scope_node(node)
        if not isinstance(parent_scope, nodes.Module):
            return False
        if cls.is_parent_node_classtype(node, nodes.If):
            pnode = cls.get_parent_node_by_classtype(node, [nodes.If])
            if node_utils.is_main_statement(pnode):
                return False
        return True

    def get_definitions(self, node, code_parser):
        # 为了防止出现重复的定义,用集合表示多个定义数据,可以保证定义数据的唯一性
        definitions = set()
        try:
            for infered in node.infer():
                # 找到节点定义,但是未能推断出类型
                if infered == astroid.Uninferable:
                    log.info(
                        'node:%s of file %s uninferable,find definition in intellisence data files',
                        node,
                        self._module.file
                    )
                    datas = self.find_definitions(node, code_parser)
                    definitions.update(datas)
                elif isinstance(infered, astroid.UnboundMethod) and infered.name == CLASS_INIT_METHOD:
                    datas = self.find_definitions(node, code_parser)
                    definitions.update(datas)
                # 推断的节点类型非法
                elif isinstance(infered, nodes.Module) and infered.file == '<?>':
                    raise astroid.InferenceError(
                        "unknown infered module %s file %s" % (infered.name, infered.file))
                else:
                    # 成功推断出节点类型
                    infered_module = infered.root()
                    if isinstance(infered_module, nodes.Module):
                        codepath = infered_module.file
                        lineno, col_offset = node_utils.get_node_line_col(
                            infered)
                        log.debug(
                            'node:%s infer type node is %s, code file:%s,line:%d,col:%d',
                            node,
                            infered,
                            codepath,
                            lineno,
                            col_offset
                        )
                        definitions.add(
                            Definition(
                                lineno,
                                col_offset,
                                codepath,
                                infered.__class__.__name__.lower(),
                                node.as_string(),
                                infered_module.name,
                                get_node_doc(infered)
                            )
                        )
                    else:
                        log.info(
                            'node:%s of file %s infer type node is %s has no root module',
                            node,
                            self._module.file,
                            infered_module
                        )
                        datas = self.find_definitions(node, code_parser)
                        definitions.update(datas)
        # 推断节点类型过程中发生错误,比如节点名称定义不存在等
        except (astroid.InferenceError, astroid.AstroidError) as ex:
            log.error(str(ex))
            log.info(
                'find definitions of node:%s of file %s in intellisence data files',
                node,
                self._module.file
            )
            datas = self.find_definitions(node, code_parser)
            definitions.update(datas)
        except Exception:
            log.exception('node refer exception:')
        return list(definitions)

    def find_definitions(self, node, code_parser):
        # 调用super语句
        if (
            isinstance(node, nodes.Attribute) and isinstance(
                node.expr, nodes.Call)
        ) and (
            isinstance(
                node.expr.func, nodes.Name) and node.expr.func.name == SUPER_CALL_METHOD_NAME
        ):
            node_scope = self.get_class_scope(node)
            if isinstance(node_scope, nodes.ClassDef):
                return self.find_base_definitions(node_scope, node.attrname, code_parser)
        # 调用self语句
        elif (
            isinstance(node, nodes.Attribute) and isinstance(
                node.expr, nodes.Name)
        ) and node.expr.name in [SELF_ARG_NAME, 'cls']:
            definitions = self.find_import_definitions(node, code_parser)
            if not definitions:
                node_scope = self.get_class_scope(node)
                if isinstance(node_scope, nodes.ClassDef):
                    definitions = self.find_base_definitions(
                        node_scope, node.attrname, code_parser)
            return definitions
        else:
            # 本模块未找到的变量或函数等,需要通过外部导入语句去导入模块中寻找
            return self.find_import_definitions(node, code_parser)

    def find_base_definitions(self, class_node, atrrname, code_parser):
        class_file = class_node.root().file
        try:
            class_mod_path = code_parser.analyzer.get_relative_path(
                class_file)
        except OutofPythonPathError as ex:
            log.error("code file:%s is outof pythonpath:%s", class_file, str(ex))
            return set()
        if class_mod_path is None:
            return set()
        class_mod_name = code_parser.modname_to_path(
            class_mod_path, class_node.name)
        log.info(
            "class name %s modpath %s to modname %s",
            class_node.name,
            class_mod_path,
            class_mod_name
        )
        base_mod_names = get_app().intellisence_mananger.load_module_class_bases(class_mod_name)
        log.info("get class modname %s bases %s", class_mod_name, base_mod_names)
        definitions = set()
        for base_mod_name in base_mod_names:
            log.info('find member name %s in base class %s', atrrname, base_mod_name)
            get_app().intellisence_mananger.fin_class_member_definitions(
                base_mod_name, atrrname, definitions)
        if not definitions:
            log.error('could not find member name %s in class %s', atrrname, class_mod_name)
        return definitions

    def get_import_definitions(self, importnode, alias=None):
        attrname = None
        if isinstance(importnode, nodes.ImportFrom):
            importname = importnode.modname
            if alias is not None:
                attrname = alias.name
        else:
            importname = alias.name
        import_modname = importname
        if attrname:
            defname = import_modname + "." + attrname
        else:
            defname = import_modname
        log.info('find defname %s of module %s definitions', defname, import_modname)
        definitions = get_app().intellisence_mananger.get_definitions(defname)
        return definitions

    def find_node_import_name(self, node, importname, code_parser):
        '''
        查找节点名称所导入的模块名称(从哪个模块导入的该成员名称)
        '''
        import_modname = None
        # 先从函数范围内的导入语句中搜索导入名称
        func_scope = self.get_function_scope(node)
        if func_scope is not None:
            import_modname = code_parser.find_import_modname(func_scope, importname)
            if import_modname is not None:
                log.info('find import name %s in funcdef scope:%s', importname, func_scope.name)
            else:
                log.warning(
                    'could not find import name %s in funcdef scope:%s',
                    importname,
                    func_scope.name
                )
        if import_modname is None:
            # 再从类范围内的导入语句中搜索导入名称
            class_scope = self.get_class_scope(node)
            if class_scope is not None:
                import_modname = code_parser.find_import_modname(class_scope, importname)
                if import_modname is not None:
                    log.info(
                        'find import name %s in classdef scope:%s',
                        importname,
                        class_scope.name
                    )
                else:
                    log.warning(
                        'could not find import name %s in classdef scope:%s',
                        importname,
                        class_scope.name
                    )
        if import_modname is None:
            # 再从模块范围内的导入语句中搜索导入名称
            import_modname = code_parser.find_import_modname(self._module, importname)
            if import_modname is not None:
                log.info(
                    'find import name %s in module scope:%s',
                    importname,
                    self._module.name
                )
            else:
                log.warning(
                    'could not find import name %s in module scope:%s',
                    importname,
                    self._module.name
                )
        return import_modname

    def find_import_definitions(self, node, code_parser, attrname=None):
        '''去导入模块中寻找定义的名称,包括import和from import语句'''
        nodestr = node.as_string()
        nodenames = nodestr.split('.')
        importname = nodenames[0]
        if attrname is None:
            attrname = nodenames[1:]
        import_modname = self.find_node_import_name(node, importname, code_parser)
        log.info('find name %s of full import name is %s', importname, import_modname)
        if import_modname is not None:
            if attrname:
                defname = import_modname + "." + ".".join(attrname)
            else:
                defname = import_modname
            definitions = get_app().intellisence_mananger.get_definitions(defname)
        else:
            definitions = get_app().intellisence_mananger.get_definitions(nodestr)
        return definitions

    def find_scope(self, line):
        if not self.locate_in_scope(self._scope, line):
            return None
        for child in self._scope.body:
            if self.locate_in_scope(child, line):
                if self.is_scope(child):
                    found_scope = ScopeFinder(child).find_scope(line)
                    return found_scope
                break
        return self._scope

    def find_class_funcdef_scope(self, line):
        locate_scope = self.find_scope(line)
        if self.is_class_funcdef_scope(locate_scope):
            return locate_scope
        parent_scope = self.get_parent_node_by_classtype(
            locate_scope,
            [nodes.ClassDef, nodes.FunctionDef]
        )
        if parent_scope:
            return parent_scope
        return self._module

    def find_classdef_scope(self, line):
        locate_scope = self.find_scope(line)
        if isinstance(locate_scope, nodes.ClassDef):
            return locate_scope
        parent_scope = self.get_parent_node_by_classtype(
            locate_scope,
            [nodes.ClassDef]
        )
        if parent_scope:
            return parent_scope
        return None

    def find_funcdef_scope(self, line):
        locate_scope = self.find_scope(line)
        if isinstance(locate_scope, nodes.FunctionDef):
            return locate_scope
        parent_scope = self.get_parent_node_by_classtype(
            locate_scope,
            [nodes.FunctionDef]
        )
        if parent_scope:
            return parent_scope
        return None
