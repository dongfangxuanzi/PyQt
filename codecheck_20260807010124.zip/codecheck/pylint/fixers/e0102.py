import re
from astroid import nodes
from novalapp.widgets import simpledialog
from novalapp import _
from novalapp.python.parser.node_scope import ScopeFinder
from ...multifixer import MultiOptionFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode, get_node_range
from ...pylint_fix import PylintFixer


class PylintE0102Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明: 同一个模块内重复名称的函数或同一个类里面的方法
    '''

    def __init__(self):
        super().__init__('E0102', False)
        MultiOptionFixer.__init__(
            self,
            1,
            title='Process Redefined Function/Method',
            descr="Please choose one fix option",
            init_options=self.init_fix_options()
        )

    def init_fix_options(self):
        options = [
            'Delete {} name-{}-line-{}',
            'Modify {} name-{}-line-{}',
            'Delete {} name-{}-line-{}',
            'Modify {} name-{}-line-{}'
        ]
        self._options = options

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg)
        class_scope = ScopeFinder.get_class_scope(node)
        if isinstance(node, nodes.Name):
            func_method_nodes = []
            redefined_func_method_line = -1
            node_type_name = ''
            if class_scope:
                node_type_name = 'method'
                res = re.search(rf'{node_type_name} already defined line (\d+) \(function-redefined\)', msg.msg)
                func_method_nodes = ScopeFinder.get_func_method_nodes(class_scope, node.name)
            else:
                node_type_name = 'function'
                res = re.search(rf'{node_type_name} already defined line (\d+) \(function-redefined\)', msg.msg)
                func_method_nodes = ScopeFinder.get_func_method_nodes(
                    textview.ModuleAnalyzer.Module,
                    node.name
                )
            if len(func_method_nodes) < 2:
                return False
            redefined_func_method_line = int(res.groups()[0])
            for func_method_node in func_method_nodes:
                if redefined_func_method_line in (func_method_node.lineno, func_method_node.position.lineno):
                    self.init_fix_options()
                    options_top = self.options[0:2]
                    for i, option_text in enumerate(options_top):
                        self.options[i] = option_text.format(
                            node_type_name,
                            node.name,
                            redefined_func_method_line
                        )
                    options_bottom = self.options[2:4]
                    for i, option_text in enumerate(options_bottom):
                        self.options[i + 2] = option_text.format(
                            node_type_name,
                            node.name,
                            node.lineno
                        )
                    self.get_selection(textctrl)
                    if self.selection != self.INVAID_SEL_INDEX:
                        if self.selection == 0:
                            FixNode(func_method_node, textview).replace_node_with_text('')
                        elif self.selection == 2:
                            FixNode(node.parent, textview).replace_node_with_text('')
                        else:
                            ok, newname = simpledialog.askstring(
                                _('Rename %s name') % node_type_name,
                                _('Input new %s name') % node_type_name,
                                initialvalue=node.name,
                                master=textctrl
                            )
                            if not ok or newname == node.name:
                                return False
                            if self.selection == 1:
                                childs = list(
                                    textview.ModuleAnalyzer.iter_scope_children(func_method_node)
                                )
                                fix_range = get_node_range(childs[0])
                            elif self.selection == 3:
                                fix_range = get_node_range(node)
                            fix_range.replace_with_text(textview, newname)
                        return True
        return False
