import os
from astroid import nodes
from novalapp.python.syspath import append_to_syspath, remove_syspath
from novalapp.python.parser.node_utils import infer_all
from novalapp.util import utils
from novalapp import globalkeys
from ...codeutils import get_node_range
from ...basefix import fix_code_file_msg
from ...pylint_fix import PylintFixer


class PylintW1505Fixer(PylintFixer):
    '''
    规则说明: 过期的函数和方法
    '''
    REPLACE_DEPRECATED_METHODS = {
        "logging.warn": "logging.warning",
        "logging.Logger.warn": "logging.Logger.warning",
        "logging.LoggerAdapter.warn": "logging.LoggerAdapter.warning",
        "base64.encodestring": "base64.encodebytes",
        "base64.decodestring": "base64.decodebytes"
    }

    def __init__(self):
        super().__init__('W1505', True)

    @staticmethod
    def append_interpreter_lib_to_syspath(interpreter):
        os_module_path = interpreter.find_module('os')
        interpreter_lib_path = os.path.dirname(os_module_path)
        append_to_syspath(interpreter_lib_path)
        return interpreter_lib_path

    def restore_fix_imports(self, textview, msg, reload=False):
        '''
        恢复相对导入设置
        '''
        if not reload:
            return
        utils.profile_set(globalkeys.FIX_IMPORT_NODES_KEY, False)
        self.load_module(textview, msg.filepath, reload=True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        fix_import_nodes = utils.profile_get_int(globalkeys.FIX_IMPORT_NODES_KEY, False)
        reload = False
        if not fix_import_nodes:
            # 修复此告警时,使用相对导入推导可能找不到模块路径,需要临时转换为绝对导入,修复完成后恢复相对导入
            utils.profile_set(globalkeys.FIX_IMPORT_NODES_KEY, True)
            reload = True
        self.load_module(textview, msg.filepath, reload=reload)
        node = textview.ModuleAnalyzer.find_line_node(line)
        if isinstance(node, nodes.Expr):
            if isinstance(node.value.func, nodes.Attribute):
                func_name = node.value.func.attrname
            elif isinstance(node.value.func, nodes.Name):
                func_name = node.value.func.name
            else:
                # 恢复相对导入
                self.restore_fix_imports(textview, msg, reload)
                return False
            interpreter = doc.GetModel().interpreter
            interpreter_lib_path = self.append_interpreter_lib_to_syspath(interpreter)
            results = infer_all(node.value.func)
            for inferred in results:
                qnames = {inferred.qname(), func_name}
                for qname in qnames:
                    if qname in self.REPLACE_DEPRECATED_METHODS:
                        replace_qname = self.REPLACE_DEPRECATED_METHODS[qname]
                        replace_func_name = replace_qname.split(".")[-1]
                        fixrange = get_node_range(node.value.func)
                        fixstr = node.value.func.expr.as_string() + "." + replace_func_name
                        fixrange.replace_with_text(textview, fixstr)
                        remove_syspath(interpreter_lib_path)
                        # 恢复相对导入
                        self.restore_fix_imports(textview, msg, reload)
                        return True
            remove_syspath(interpreter_lib_path)
        # 恢复相对导入
        self.restore_fix_imports(textview, msg, reload)
        return False


class PylintW4902Fixer(PylintW1505Fixer):

    def __init__(self):
        PylintFixer.__init__(self, 'W4902', True)
