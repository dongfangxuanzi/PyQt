from novalapp.lib.pyqt import (
    Qt,
    QFrame,
    pyqtSignal,
    QSizePolicy,
    QVBoxLayout,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView
)
from novalapp.util import fileutils
from novalapp import _
from .metrics import Metric, TotalMetric


class MetricsViewer(QFrame):
    """description of class"""
    SIG_APPEND_METRIC_ITEM = pyqtSignal(Metric)
    SIG_INIT_PROCESSOR = pyqtSignal()
    SIG_END_PROCESSOR = pyqtSignal(TotalMetric)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout()
        self.setLayout(layout)
        columns = [
            _('Filepath'),
            _('Blank Lines'),
            _('Comment Lines'),
            _('Code Lines'),
            _('File Lines'),
            _('Program Language')
        ]
        self._updated = False
        self.table = QTableWidget(0, len(columns), self)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setColumnWidth(0, 710)
        self.table.setColumnWidth(1, 120)
        self.table.setColumnWidth(2, 120)
        self.table.setColumnWidth(3, 120)
        self.table.setColumnWidth(4, 140)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table.setHorizontalHeaderLabels(columns)
        self.show_verticalheader(True)
        layout.addWidget(self.table)
        self.SIG_APPEND_METRIC_ITEM.connect(self.append_metric_item)
        self.SIG_INIT_PROCESSOR.connect(self.init_processor)
        self.SIG_END_PROCESSOR.connect(self.end_processor)

    @property
    def updated(self):
        return self._updated

    @updated.setter
    def updated(self, is_update):
        self._updated = is_update

    def init_processor(self):
        if not self._updated:
            self.clear_messages()

    def end_processor(self, total_metric):
        total_metric.filepath = _('{files_count} files, total').format(files_count=total_metric.files_count) + ":"
        self.append_metric_item(total_metric)

    def append_metric_item(self, metric):
        if isinstance(metric, TotalMetric):
            self.insert_metric_item(metric)
            return
        row = self.find_file_metric_row(metric.filepath)
        if row == -1:
            insertrow = 0
            if self.table.rowCount() != 0:
                filepath_item = self.table.item(0, 0)
                filepath = filepath_item.text()
                if filepath.find(":") != -1:
                    insertrow = 1
                    self.update_total_metric_item(-1)
            self.insert_metric_item(metric, insertrow)
        else:
            self.update_total_metric_item(row)
            self.update_metric_item(metric, row)

    def update_metric_item(self, metric, row):
        pathitem = self.table.item(row, 0)
        pathitem.setData(Qt.UserRole, metric)
        blank_lines_item = self.table.item(row, 1)
        blank_lines_item.setText(str(metric.blank_lines_count))
        comment_lines_item = self.table.item(row, 2)
        comment_lines_item.setText(str(metric.comment_lines_count))
        code_lines_item = self.table.item(row, 3)
        code_lines_item.setText(str(metric.code_lines_count))
        file_lines_item = self.table.item(row, 4)
        file_lines_item.setText(str(metric.file_lines_count))

    def update_total_metric_item(self, row):
        total_path_item = self.table.item(0, 0)
        total_metric = total_path_item.data(Qt.UserRole)
        if not isinstance(total_metric, TotalMetric):
            return
        if row != -1:
            path_item = self.table.item(row, 0)
            old_row_metric = path_item.data(Qt.UserRole)
            # 处理器中已新增更新文件代码量
            total_metric.blank_lines_count -= old_row_metric.blank_lines_count
            total_metric.comment_lines_count -= old_row_metric.comment_lines_count
            total_metric.code_lines_count -= old_row_metric.code_lines_count
            total_metric.file_lines_count -= old_row_metric.file_lines_count
            total_metric.files_count -= 1
        else:
            pathitem = self.table.item(0, 0)
            total_filepath = _('{files_count} files, total').format(files_count=total_metric.files_count) + ":"
            total_metric.filepath = total_filepath
            pathitem.setText(total_filepath)
        self.update_metric_item(total_metric, 0)

    def insert_metric_item(self, metric, insertrow=0):
        self.table.insertRow(insertrow)
        pathitem = QTableWidgetItem(str(metric.filepath))
        self.table.setItem(insertrow, 0, pathitem)
        pathitem.setData(Qt.UserRole, metric)

        blank_lines_item = QTableWidgetItem(str(metric.blank_lines_count))
        blank_lines_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 1, blank_lines_item)

        comment_lines_item = QTableWidgetItem(str(metric.comment_lines_count))
        comment_lines_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 2, comment_lines_item)

        code_lines_item = QTableWidgetItem(str(metric.code_lines_count))
        code_lines_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 3, code_lines_item)

        file_lines_item = QTableWidgetItem(str(metric.file_lines_count))
        file_lines_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 4, file_lines_item)

        language_item = QTableWidgetItem(metric.language)
        language_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 5, language_item)

    def show_verticalheader(self, visible):
        if visible:
            self.table.verticalHeader().show()
        else:
            self.table.verticalHeader().hide()

    def clear_messages(self):
        # 清空表格所有内容
        self.table.clearContents()
        while self.table.rowCount():
            self.table.removeRow(0)

    def find_file_metric_row(self, filepath):
        row_count = self.table.rowCount()
        for i in range(row_count - 1, -1, -1):
            cell_path = self.table.item(i, 0).text()
            if fileutils.ComparePath(cell_path, filepath):
                return i
        return -1
