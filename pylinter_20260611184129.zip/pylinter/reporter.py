from __future__ import annotations
from typing import TextIO
from pylint.message import Message
from pylint.reporters import BaseReporter


class QuietReport(BaseReporter):
    """Version of checker that does not print."""

    def __init__(self, output: TextIO | None = None) -> None:
        super().__init__(output)
        self.__full_error_results = []

    def handle_message(self, msg: Message) -> None:
        """Collect errors."""
        super().handle_message(msg)
        self.__full_error_results.append(
            {'id': msg.msg_id,
             'line': msg.line,
             'column': msg.column,
             'info': msg.msg + f" ({msg.symbol})"})

    def _display(self, layout) -> None:
        """Display the layout."""

    def full_error_results(self):
        """Return error results in detail.

        Results are in the form of a list of dictionaries. Each
        dictionary contains 'id', 'line', 'column', and 'info'.

        """
        return self.__full_error_results
