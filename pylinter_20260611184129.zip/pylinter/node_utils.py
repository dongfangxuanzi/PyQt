from __future__ import annotations
from astroid import nodes
import astroid
from astroid.exceptions import AstroidError
from .constants import BUILTMODULE_NAME


class ImportNodes:
    def __init__(self, module, formatter):
        self._module = module
        self._formatter = formatter

    def is_import_exist(self, modname):
        for child in self._module.body:
            if isinstance(child, nodes.Import):
                names = [name[0] for name in child.names]
                if modname in names:
                    return True
        return False

    def is_fromimport_exist(self, modname, import_name):
        for child in self._module.body:
            if isinstance(child, nodes.ImportFrom):
                if child.modname == modname:
                    return import_name in [name[0] for name in child.names]
        return False

    def get_import_nodes(self):
        '''
        获取模块范围内的所有导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, (nodes.Import, nodes.ImportFrom)):
                import_nodes.append(child)
        return import_nodes

    def get_top_import_nodes(self):
        '''
        获取模块开头的导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, nodes.Assign):
                valid_targets = [
                    isinstance(target, nodes.AssignName)
                    and target.name.startswith("__")
                    and target.name.endswith("__")
                    for target in child.targets
                ]
                if all(valid_targets):
                    continue
            if not isinstance(child, (nodes.Import, nodes.ImportFrom)):
                break
            import_nodes.append(child)
        return import_nodes

    def get_lastimport_node(self, top_imports):
        if top_imports:
            import_nodes = self.get_top_import_nodes()
        else:
            import_nodes = self.get_import_nodes()
        if not import_nodes:
            return None
        return import_nodes[-1]

    def get_import_line(self, top_imports=False):
        last_node = self.get_lastimport_node(top_imports)
        if last_node is not None:
            return last_node.lineno
        if self._module.doc_node is None:
            shebang_or_encoding_line = self._formatter.get_shebang_encoding_line()
            return shebang_or_encoding_line
        return self.get_docstring_line()

    def get_docstring_line(self):
        return self._module.doc_node.end_lineno


def is_const_type(node, valtype):
    return isinstance(node, nodes.Const) and isinstance(node.value, valtype)


def get_node_childs(node, childs: list, max_recursion_size=10000):
    for child in node.get_children():
        if len(childs) < max_recursion_size:
            childs.append(child)
        get_node_childs(child, childs, max_recursion_size)


def get_builtin_type(typevalue):
    return typevalue.pytype().replace(f'{BUILTMODULE_NAME}.', '')


def _get_python_type_of_node(node: nodes.NodeNG) -> str | None:
    pytype: Callable[[], str] | None = getattr(node, "pytype", None)
    if callable(pytype):
        return pytype()
    return None


def safe_infer(node: nodes.NodeNG):
    """Return the inferred value for the given node.

    Return None if inference failed or if there is some ambiguity (more than
    one node has been inferred of different types).

    If compare_constants is True and if multiple constants are inferred,
    unequal inferred values are also considered ambiguous and return None.
    """
    inferred_types: set[str | None] = set()
    try:
        infer_gen = node.infer()
        value = next(infer_gen)
    except astroid.InferenceError:
        return None
    except Exception as e:
        raise AstroidError from e

    if value is not astroid.Uninferable:
        inferred_types.add(_get_python_type_of_node(value))

    try:
        for inferred in infer_gen:
            inferred_type = _get_python_type_of_node(inferred)
            if inferred_type not in inferred_types:
                return None  # If there is ambiguity on the inferred node.
            if (
                compare_constants
                and isinstance(inferred, nodes.Const)
                and isinstance(value, nodes.Const)
                and inferred.value != value.value
            ):
                return None
            if (
                isinstance(inferred, nodes.FunctionDef)
                and inferred.args.args is not None
                and isinstance(value, nodes.FunctionDef)
                and value.args.args is not None
                and len(inferred.args.args) != len(value.args.args)
            ):
                return None  # Different number of arguments indicates ambiguity
    except astroid.InferenceError:
        return None  # There is some kind of ambiguity
    except StopIteration:
        return value
    except Exception as e:  # pragma: no cover
        raise AstroidError from e
    return value if len(inferred_types) <= 1 else None
