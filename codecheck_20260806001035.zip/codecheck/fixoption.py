'''
Name:        fixoption.py
Purpose:
Author:      wukan
Created:     2026-04-11
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from novalapp.util import ui_utils, utils
from novalapp.lib.pyqt import QLabel, QHBoxLayout, QCheckBox, Qt, QSpinBox, QMessageBox, QGroupBox
from novalapp import _, get_app
from . import configkeys
from .strings import PYLINT_TOOL_NAME
from .toolmanager import CodecheckToolManager
from .pylint.fixers.w0401 import PylintW0401Fixer


class CodeFixOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    代码修复配置面板
    """

    def __init__(self, parent, **kwargs):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.layout.setAlignment(Qt.AlignTop)

        fix_depth_hbox = QHBoxLayout()
        fix_depth_hbox.setAlignment(Qt.AlignLeft)
        fix_depth_hbox.addWidget(
            QLabel(_("Please set autopep8 fix depth") + ":"))
        fix_depth = utils.profile_get_int(configkeys.AUTOPEP8_FIXDEPTH_KEY, 0)
        self.fix_depth_spin = QSpinBox(
            value=fix_depth,
            maximum=3,
            minimum=0,
            singleStep=1
        )
        fix_depth_hbox.addWidget(self.fix_depth_spin)
        self.layout.addLayout(fix_depth_hbox)

        wildcard_import_hbox = QHBoxLayout()
        wildcard_import_hbox.setAlignment(Qt.AlignLeft)
        wildcard_import_hbox.addWidget(
            QLabel(_("Wildcard import max members count") + ":"))
        wildcard_import_members_count = utils.profile_get_int(
            configkeys.WILDCARD_IMPORT_COUNT_KEY,
            PylintW0401Fixer.MAX_MEMBERS_COUNT
        )
        self.wildcard_import_spin = QSpinBox(
            value=wildcard_import_members_count,
            maximum=50,
            minimum=10,
            singleStep=5
        )
        wildcard_import_hbox.addWidget(self.wildcard_import_spin)
        self.layout.addLayout(wildcard_import_hbox)

        self.convert_tabs_spaces_chkbox = QCheckBox(
            _("Convert all tabs to spaces"))
        self.convert_tabs_spaces_chkbox.setChecked(utils.profile_get_int(
            configkeys.CONVERT_TABS_SPACES_KEY, False))
        self.layout.addWidget(self.convert_tabs_spaces_chkbox)

        self.delete_comment_out_codes_chkbox = QCheckBox(
            _("Delete comment out codes"))
        self.delete_comment_out_codes_chkbox.setChecked(utils.profile_get_int(
            configkeys.DELETE_COMMENT_OUT_CODES_KEY, False))
        self.layout.addWidget(self.delete_comment_out_codes_chkbox)

        self.delete_todo_chkbox = QCheckBox(
            _("Delete todo/fixme tasks"))
        self.delete_todo_chkbox.setChecked(utils.profile_get_int(
            configkeys.DELETE_TODO_KEY, False))
        self.layout.addWidget(self.delete_todo_chkbox)

        self.delete_assert_chkbox = QCheckBox(
            _("Delete all `assert` statements"))
        self.delete_assert_chkbox.setChecked(utils.profile_get_int(
            configkeys.DELETE_ASSERT_KEY, False))
        self.layout.addWidget(self.delete_assert_chkbox)

        self.delete_suppressed_messages_chkbox = QCheckBox(
            _("Delete all pylint suppressed messages"))
        self.delete_suppressed_messages_chkbox.setChecked(utils.profile_get_int(
            configkeys.DELETE_SUPPRESSED_MESSAGE_KEY, False))
        self.layout.addWidget(self.delete_suppressed_messages_chkbox)

        self.remove_print_statement_chkbox = QCheckBox(
            _("Remove all `print` statements after fix one file"))
        self.remove_print_statement_chkbox.setChecked(utils.profile_get_int(
            configkeys.REMOVE_PRINT_STATEMENT_KEY, False))
        self.layout.addWidget(self.remove_print_statement_chkbox)

        self.format_docstr_chkbox = QCheckBox(
            _("Format document str(Module,Class,Function/Method)"))
        self.format_docstr_chkbox.setChecked(utils.profile_get_int(
            configkeys.FORMAT_DOCSTR_KEY, False))
        self.layout.addWidget(self.format_docstr_chkbox)

        sbox = QGroupBox(_("Standardize the naming style of identifiers"))
        hbox = QHBoxLayout()
        hbox.setAlignment(Qt.AlignLeft)
        self.local_variables_naming_style_chkbox = QCheckBox(_("Local variables"))
        self.local_variables_naming_style_chkbox.setChecked(utils.profile_get_int(
            configkeys.STANDARDIZE_LOCAL_VARIABLE_NAME_STYLE_KEY, False))
        hbox.addWidget(self.local_variables_naming_style_chkbox)

        self.class_attribute_naming_style_chkbox = QCheckBox(_("Class attributes"))
        self.class_attribute_naming_style_chkbox.setChecked(utils.profile_get_int(
            configkeys.STANDARDIZE_CLASS_ATTR_NAME_STYLE_KEY, False))
        hbox.addWidget(self.class_attribute_naming_style_chkbox)

        self.function_arg_naming_style_chkbox = QCheckBox(_("Function args"))
        self.function_arg_naming_style_chkbox.setChecked(utils.profile_get_int(
            configkeys.STANDARDIZE_FUNCTION_ARG_NAME_STYLE_KEY, False))
        hbox.addWidget(self.function_arg_naming_style_chkbox)

        self.module_naming_style_chkbox = QCheckBox(_("Modules"))
        self.module_naming_style_chkbox.setChecked(utils.profile_get_int(
            configkeys.STANDARDIZE_MODULE_NAME_STYLE_KEY, False))
        hbox.addWidget(self.module_naming_style_chkbox)
        sbox.setLayout(hbox)
        self.layout.addWidget(sbox)

        self.fix_wildcard_imports_chkbox = QCheckBox(_("Fix wildcard imports"))
        self.fix_wildcard_imports_chkbox.setChecked(utils.profile_get_int(
            configkeys.FIX_WILDCARD_IMPORTS_KEY, False))
        self.layout.addWidget(self.fix_wildcard_imports_chkbox)

        self.fix_format_codefile_chkbox = QCheckBox(_("Format code file before fix warnings"))
        self.fix_format_codefile_chkbox.setChecked(utils.profile_get_int(
            configkeys.FORMAT_CODEFILE_BEFORE_FIX_KEY, False))
        self.layout.addWidget(self.fix_format_codefile_chkbox)

    def enable_rule_autofixed(self, options_dialog, ruleid, autofix_enabled):
        pylint_option_panel = options_dialog.GetOptionPanel(_("CodeCheck"), "Pylint")
        if autofix_enabled and not pylint_option_panel.is_rule_checked(ruleid):
            raise RuntimeError(
                _('Please start using `%s` rule of tool `%s` first.') % (ruleid, PYLINT_TOOL_NAME)
            )
        autofix_key = configkeys.TOOL_RULES_AUTOFIX_KEY % (
            PYLINT_TOOL_NAME, ruleid)
        utils.profile_set(autofix_key, autofix_enabled)
        fix_tool = CodecheckToolManager.manager().find_tool(PYLINT_TOOL_NAME)
        pylint_option_panel.set_autofix_checked(ruleid, autofix_enabled)
        fixer = fix_tool.find_fixer(ruleid)
        fixer.autofix = autofix_enabled

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        utils.profile_set(configkeys.AUTOPEP8_FIXDEPTH_KEY,
                          int(self.fix_depth_spin.value()))
        utils.profile_set(configkeys.WILDCARD_IMPORT_COUNT_KEY,
                          int(self.wildcard_import_spin.value()))

        utils.profile_set(configkeys.CONVERT_TABS_SPACES_KEY,
                          self.convert_tabs_spaces_chkbox.isChecked())
        utils.profile_set(configkeys.DELETE_COMMENT_OUT_CODES_KEY,
                          self.delete_comment_out_codes_chkbox.isChecked())
        utils.profile_set(configkeys.DELETE_TODO_KEY,
                          self.delete_todo_chkbox.isChecked())
        utils.profile_set(configkeys.DELETE_ASSERT_KEY,
                          self.delete_assert_chkbox.isChecked())
        utils.profile_set(configkeys.DELETE_SUPPRESSED_MESSAGE_KEY,
                          self.delete_suppressed_messages_chkbox.isChecked())
        utils.profile_set(configkeys.REMOVE_PRINT_STATEMENT_KEY,
                          self.remove_print_statement_chkbox.isChecked())
        utils.profile_set(configkeys.FORMAT_DOCSTR_KEY,
                          self.format_docstr_chkbox.isChecked())
        utils.profile_set(configkeys.STANDARDIZE_LOCAL_VARIABLE_NAME_STYLE_KEY,
                          self.local_variables_naming_style_chkbox.isChecked())
        utils.profile_set(configkeys.STANDARDIZE_MODULE_NAME_STYLE_KEY,
                          self.module_naming_style_chkbox.isChecked())
        utils.profile_set(configkeys.STANDARDIZE_CLASS_ATTR_NAME_STYLE_KEY,
                          self.class_attribute_naming_style_chkbox.isChecked())
        utils.profile_set(configkeys.STANDARDIZE_FUNCTION_ARG_NAME_STYLE_KEY,
                          self.function_arg_naming_style_chkbox.isChecked())
        utils.profile_set(configkeys.FIX_WILDCARD_IMPORTS_KEY,
                          self.fix_wildcard_imports_chkbox.isChecked())
        utils.profile_set(configkeys.FORMAT_CODEFILE_BEFORE_FIX_KEY,
                          self.fix_format_codefile_chkbox.isChecked())
        try:
            self.enable_rule_autofixed(
                options_dialog,
                'W9000',
                self.delete_comment_out_codes_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'W0511',
                self.delete_todo_chkbox.isChecked()
            )

            self.enable_rule_autofixed(
                options_dialog,
                'W9002',
                self.delete_assert_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'I0020',
                self.delete_suppressed_messages_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'C0103',
                self.class_attribute_naming_style_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'C0103',
                self.module_naming_style_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'C0103',
                self.function_arg_naming_style_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'C0103',
                self.local_variables_naming_style_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'W0401',
                self.fix_wildcard_imports_chkbox.isChecked()
            )
        except RuntimeError as ex:
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                str(ex)
            )
            return False
        return True
