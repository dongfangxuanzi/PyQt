'''
Name:        r1710.py
Purpose:
Author:      wukan
Created:     2026-04-07
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import os
from astroid import nodes
import astroid
from novalapp.python.parser import node_utils
from ....multifixer import MultiOptionFixer
from ....pylint_fix import PylintFixer


class PylintR1710Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明: 函数不能有隐式返回,确保函数所有分支均有显式返回语句,
    除非函数任何分支均没有返回值
    '''

    def __init__(self):
        super().__init__('R1710', self.FixKind.SEMI_AUTOFIX)
        MultiOptionFixer.__init__(
            self,
            title='Fix implicit return',
            descr="Please choose one fix option",
        )

    @staticmethod
    def get_proposal_return_values(funcnode):
        '''推断函数可能返回值类型'''
        return_nodes = list(
            funcnode.nodes_of_class(nodes.Return, skip_klass=nodes.FunctionDef)
        )
        ret_values = []
        for return_node in return_nodes:
            node_value_type_d = node_utils.get_node_value_type(return_node.value)
            if not node_value_type_d:
                ret_infer_val = node_utils.safe_infer(return_node.value)
                if ret_infer_val is not None:
                    node_value_type_d = node_utils.get_node_value_type(ret_infer_val)
                if not node_value_type_d:
                    continue
            value_kind_name = node_value_type_d['value_kind']
            default_values = node_utils.get_builtintype_default_values(value_kind_name)
            for default_value in default_values:
                default_value_str = str(default_value)
                if default_value_str not in ret_values:
                    ret_values.append(default_value_str)
        return ret_values

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef):
            funcnode = node.parent
            if funcnode.body and isinstance(funcnode.body[-1], (nodes.Raise, nodes.Return)):
                return False
            if self.fix_implicit_returns(funcnode):
                return True
            if self.fix_else_return_raise_statement(funcnode):
                return True
            ret_values = self.get_proposal_return_values(funcnode)
            retval_num = len(ret_values)
            end_body = funcnode.body[-1]
            insert_line = funcnode.end_lineno
            blanks = end_body.col_offset * ' '
            if not retval_num:
                ret_values.append('None')
                retval_num = len(ret_values)
            # 只有1个可能返回值的时候不要弹框
            if retval_num == 1 and self.fix_only_autofix():
                self.selection = 0
            else:
                # 下面的修复操作不支持自动修复
                if self.fix_only_autofix():
                    return False
                if 'None' not in ret_values:
                    ret_values.append('None')
                retval_num = len(ret_values)
                choices = ['return ' + retval for retval in ret_values]
                choices.append('Raise Exception')
                self._options = choices
                self.get_selection()
            if self.selection == retval_num:
                self.add_range_text(insert_line + 1, 0, blanks + "raise" + os.linesep)
                return True
            self.add_range_text(
                insert_line + 1,
                0,
                blanks + f'return {ret_values[self.selection]}' + os.linesep
            )
            return True
        return False

    def fix_implicit_returns(self, funcnode):
        '''修复return语句后面没有返回值'''
        return_nodes = list(
            funcnode.nodes_of_class(nodes.Return, skip_klass=nodes.FunctionDef)
        )
        explicit_returns = [retnode for retnode in return_nodes if retnode.value is not None]
        if not explicit_returns:
            return False
        if len(return_nodes) == len(explicit_returns):
            return False
        implicit_returns = [retnode for retnode in return_nodes if retnode.value is None]
        for implicit_return_node in implicit_returns:
            implicit_return_node.value = astroid.extract_node('None')
            self.fix_node_text(implicit_return_node, implicit_return_node.as_string())
        return True

    def fix_else_return_raise_statement(self, funcnode):
        '''修复函数最后else返回/异常语句,可以去掉else,将返回语句移至函数最后'''
        elif_node = None
        if funcnode.body and isinstance(funcnode.body[-1], nodes.If):
            elif_node = funcnode.body[-1].orelse[0]
            while isinstance(elif_node, nodes.If) and elif_node.orelse:
                if elif_node.orelse:
                    elif_node = elif_node.orelse[-1]
                else:
                    break
            if isinstance(elif_node, (nodes.Raise, nodes.Return)):
                self.back_text_tab(elif_node.lineno - 1, elif_node.col_offset)
                ifnode = elif_node.parent
                if len(ifnode.orelse) == 1:
                    else_line = self.get_else_line(elif_node.lineno - 1)
                    if else_line > 1:
                        # 删除else语句
                        self.delete_text_line(else_line)
                return True
        return False
