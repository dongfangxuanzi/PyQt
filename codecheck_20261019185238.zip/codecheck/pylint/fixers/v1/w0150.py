import os
from astroid import nodes
from novalapp import constants
from ....pylint_fix import PylintFixer


class PylintW0150Fixer(PylintFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('W0150', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        return False


class PylintW0134Fixer(PylintFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('W0134', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        return False
