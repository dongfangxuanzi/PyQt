import sys
import os
import subprocess
from PyQt5.QtWidgets import (
    QWidget,
    QApplication,
    QLabel,
    QLineEdit,
    QHBoxLayout,
    QVBoxLayout,
    QDialogButtonBox,
    QRadioButton
)
from PyQt5.QtCore import Qt

password_txt = os.path.join(os.path.expanduser("~"), "pass.txt")


def remove_password():
    try:
        os.remove(password_txt)
    except:
        pass


class AuthMainWindow(QWidget):

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Verify")
        # 禁止窗口改变大小
        self.setFixedSize(-1, -1)
        frame_box = QVBoxLayout()
        frame_box.setContentsMargins(30, 30, 30, 30)
        name_hbox = QHBoxLayout()
        name_hbox.setAlignment(Qt.AlignLeft)
        name_hbox.addWidget(QLabel('Username' + ":"))
        self.user_name_entry = QLineEdit()
        name_hbox.addWidget(self.user_name_entry)
        frame_box.addLayout(name_hbox)

        pass_hbox = QHBoxLayout()
        pass_hbox.setAlignment(Qt.AlignLeft)
        pass_hbox.addWidget(QLabel('Password' + ":"))
        self.password_entry = QLineEdit()
        # 设置输入模式为密码模式
        self.password_entry.setEchoMode(QLineEdit.Password)
        pass_hbox.addWidget(self.password_entry)
        frame_box.addLayout(pass_hbox)

        self.store_secure_btn = QRadioButton('Store in Secure Store')
        frame_box.addWidget(self.store_secure_btn)

        buttonbox = self.create_standard_buttons_box()
        frame_box.addWidget(buttonbox)
        self.setLayout(frame_box)

    def create_standard_buttons_box(self):
        buttonbox = QDialogButtonBox(self)
        buttonbox.layout().setAlignment(Qt.AlignCenter)
        buttonbox.setOrientation(Qt.Horizontal)
        buttonbox.setStandardButtons(QDialogButtonBox.Ok |
                                     QDialogButtonBox.Cancel)
        self.ok_button = buttonbox.button(QDialogButtonBox.Ok)
        self.ok_button.setDefault(True)
        self.ok_button.setText("&Login")
        buttonbox.setCenterButtons(True)
        buttonbox.button(QDialogButtonBox.Cancel).setText("Cancel")
        buttonbox.accepted.connect(self._ok)
        buttonbox.rejected.connect(self._cancel)
        return buttonbox

    def _ok(self):
        if self.store_secure_btn.isChecked():
            subprocess.call("git config --global credential.helper store")
        # 打印用户名,通过管道传递给git客户端
        print(self.user_name_entry.text().strip(),)
        # 临时存储密码,以便下次弹出时传递给git客户端
        with open(password_txt, "w") as f:
            f.write(self.password_entry.text().strip())
        self.close()

    def _cancel(self):
        print("+++++")
        with open(password_txt, "w") as f:
            f.write("===========")
        self.close()


if __name__ == "__main__":
    args = sys.argv
    if len(args) > 1:
        first_arg = args[1]
        if first_arg.find("Username for") != -1:
            remove_password()
            app = QApplication(args)
            w = AuthMainWindow()
            w.show()
            sys.exit(app.exec_())
        elif first_arg.find("Password for") != -1:
            with open(password_txt) as f:
                # 打印密码,通过管道传递给git客户端
                print(f.read().strip(),)
            # 删除临时存储密码
            remove_password()
