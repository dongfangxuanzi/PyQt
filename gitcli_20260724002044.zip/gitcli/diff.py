from novalapp.util import ui_utils
from novalapp.util import strutils, utils
from novalapp.lib.qsci import QsciScintilla, DEFAULT_MARGIN_INDEX
from novalapp.lib.pyqt import Qt, QColor, pyqtSignal, QTimer, QDialog
from novalapp import _, constants
from novalapp.common.encodings import UTF8_FILE_ENCODING
from git.repo import RepofileState
from .textctrl import StyledTextCtrl
from .async_cmd import AsyncCmd, AsyncOutputThread


class FileDiffDialog(ui_utils.BaseModalDialog):

    DEL_TEXT_STYLE = 1
    ADD_TEXT_STYLE = 2
    DIFF_POSITION_STYLE = 3
    META_TEXT_STYLE = 4
    DEFAULT_DIFF_FONTSIZE = 9
    SIG_APPEND_TEXT = pyqtSignal(str)
    SIG_COMMAND_EXIT = pyqtSignal(int, str)
    BLOCK_FLAG = '@@'

    def __init__(self, master, face_ui, filepath, filestate, diff_with_rule=False):
        super().__init__(_('Diff-%s') % filepath, master)
        self.ui = face_ui
        self.__filepath = filepath
        self.contents = StyledTextCtrl()
        self.contents.setMarginWidth(DEFAULT_MARGIN_INDEX, 0)
        # 文字和文本框背景色为白色
        paper_background_color = QColor(Qt.white)
        # 设置文本框背景色
        self.contents.setPaper(paper_background_color)
        self.set_style_spec(
            constants.DEFAULT_FONT_FAMILY,
            QColor('#FF0000'),
            paper_background_color,
            self.DEFAULT_DIFF_FONTSIZE,
            self.DEL_TEXT_STYLE
        )
        self.set_style_spec(
            constants.DEFAULT_FONT_FAMILY,
            QColor('#00FF00'),
            paper_background_color,
            self.DEFAULT_DIFF_FONTSIZE,
            self.ADD_TEXT_STYLE
        )
        self.set_style_spec(
            constants.DEFAULT_FONT_FAMILY,
            QColor(Qt.darkCyan),
            paper_background_color,
            self.DEFAULT_DIFF_FONTSIZE,
            self.DIFF_POSITION_STYLE
        )
        self.contents.SendScintilla(
            QsciScintilla.SCI_STYLESETBOLD,
            self.DIFF_POSITION_STYLE,
            True
        )
        self.set_style_spec(
            constants.DEFAULT_FONT_FAMILY,
            QColor(Qt.black),
            paper_background_color,
            self.DEFAULT_DIFF_FONTSIZE,
            self.META_TEXT_STYLE
        )
        self.contents.SendScintilla(
            QsciScintilla.SCI_STYLESETBOLD,
            self.META_TEXT_STYLE,
            True
        )
        self.SIG_APPEND_TEXT.connect(self.filter_output_msg)
        self.SIG_COMMAND_EXIT.connect(self.command_exit)
        self.layout.addWidget(self.contents)
        self.create_standard_buttons()
        self.ok_button.setText(_("Checkout File"))
        self.setWindowFlags(Qt.Dialog | Qt.WindowMinMaxButtonsHint | Qt.WindowCloseButtonHint)
        self._line_index = 0
        self._filestate = filestate
        command = "diff"
        if diff_with_rule:
            command += " -w"
        if self._filestate in [
            RepofileState.FILE_MODIFIED_STAGED,
            RepofileState.FILE_DELETED_STAGED,
            RepofileState.FILE_NEW_STAGED
        ]:
            command += " --cached --"
        elif self._filestate == RepofileState.FILE_DELETED_UNSTAGED:
            command += " --"
        command += " %s" % (strutils.emphasis_path(filepath))

        gitcmd = AsyncCmd(
            self.ui.GetProjectDocument().GetPath(),
            self,
            output_thread_class=AsyncOutputThread,
            show_progress_dlg=False
        )
        gitcmd.call(command)

    def exec_(self):
        """Execute the dialog"""

    def command_exit(self, exitcode, errmsg):
        utils.get_logger().info('exec git command exitcode is %d', exitcode)
        if exitcode != 0:
            utils.get_logger().error("exec git command error:%s", errmsg)
        QTimer.singleShot(2000, self.end_diff_file)
        QDialog.exec_(self)

    def end_diff_file(self):
        self.contents.setReadOnly(True)

    def filter_output_msg(self, line):
        if self._line_index < 10:
            if line.find('diff --git ') != -1:
                return
            if line.find('index ') != -1:
                return
            if line.find('--- ') != -1:
                return
            if line.find('+++ ') != -1:
                return
            if (self._filestate in (RepofileState.FILE_DELETED_UNSTAGED, RepofileState.FILE_DELETED_STAGED)
                ) and (
                line.find('deleted file mode ') != -1
            ):
                self.color_diff_text(line)
                self._line_index += 1
                return
            if self._filestate == RepofileState.FILE_NEW_STAGED and (
                line.find('new file mode ') != -1
            ):
                self.color_diff_text(line)
                self._line_index += 1
                return
        self.color_diff_text(line)
        self._line_index += 1

    def set_style_spec(self, family, foregroud, backgroud, size, style):
        # 设置文字字体
        self.contents.SendScintilla(QsciScintilla.SCI_STYLESETFONT,
                                    style, family.encode(UTF8_FILE_ENCODING))
        # 设置文字前景色
        self.contents.SendScintilla(QsciScintilla.SCI_STYLESETFORE, style, foregroud)
        # 设置文字背景色,一般和文本框背景色保持一致
        self.contents.SendScintilla(QsciScintilla.SCI_STYLESETBACK, style, backgroud)
        # 设置文字大小
        self.contents.SendScintilla(QsciScintilla.SCI_STYLESETSIZE, style, size)

    def start_styling(self, pos):
        self.contents.SendScintilla(QsciScintilla.SCI_STARTSTYLING, pos, 1)

    def set_styling(self, textlen, style):
        self.contents.SendScintilla(QsciScintilla.SCI_SETSTYLING, textlen, style)

    def color_diff_text(self, linetext):
        self.contents.append_text(linetext)
        line_position = self.contents.SendScintilla(
            QsciScintilla.SCI_POSITIONFROMLINE,
            self._line_index
        )
        utils.get_logger().debug('line %d postion is %d', self._line_index, line_position)
        line_bytes = linetext.encode(UTF8_FILE_ENCODING)
        if linetext.startswith(self.BLOCK_FLAG):
            index = linetext.rfind(self.BLOCK_FLAG)
            self.start_styling(line_position)
            start_style_bold_index = index + len(self.BLOCK_FLAG)
            self.set_styling(start_style_bold_index, self.DIFF_POSITION_STYLE)

            start_style_bold_pos = line_position + start_style_bold_index
            self.start_styling(start_style_bold_pos)
            utils.get_logger().debug(
                "line %d, block stying length is:%d,bold start styling pos is :%d, bold styling length:%d",
                self._line_index,
                start_style_bold_index,
                start_style_bold_pos,
                len(line_bytes) - start_style_bold_index
            )
            self.set_styling(len(line_bytes) - start_style_bold_index, self.META_TEXT_STYLE)
        elif linetext.startswith('-'):
            self.start_styling(line_position)
            self.set_styling(len(line_bytes), self.DEL_TEXT_STYLE)
        elif linetext.startswith('+'):
            self.start_styling(line_position)
            self.set_styling(len(line_bytes), self.ADD_TEXT_STYLE)

    def _ok(self):
        self.ui.checkout_files([self.__filepath])
        super()._ok()
