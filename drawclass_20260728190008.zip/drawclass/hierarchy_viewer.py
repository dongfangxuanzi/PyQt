from collections import defaultdict
import json
import os
from pkg_resources import resource_filename
from novalapp.util import utils
from novalapp.python.project import additem
from novalapp.editor.imageview import PixmapWidget
from novalapp import _, get_app
from novalapp.python.interpreter.interpretermanager import InterpreterManager
from novalapp.python.interpreter.interpreter import BuiltinPythonInterpreter
from novalapp.lib.pyqt import (
    QLabel,
    QHBoxLayout,
    QVBoxLayout,
    Qt,
    QFrame,
    QSizePolicy,
    QComboBox,
    QPushButton,
    QMessageBox
)
from novalapp.widgets import simpledialog
from novalapp.executable import Executable

PLOT_IMAGE_NAME = 'plot.png'


class ClassHierarchyViewer(QFrame):
    """description of class"""

    def __init__(self, parent=None, plugin=None):
        super().__init__(parent)
        self._plugin = plugin

        frame_layout = QVBoxLayout()

        class_box = QHBoxLayout()
        class_box.setAlignment(Qt.AlignLeft)
        class_box.setContentsMargins(0, 10, 0, 0)

        class_box.addWidget(QLabel(_('Classes') + ":"))
        self.class_entry = QComboBox()
        self.class_entry.setEditable(True)
        self.class_entry.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.class_entry.setFixedWidth(additem.FIXED_LABEL_WIDTH)
        class_box.addWidget(self.class_entry)

        class_box.addWidget(QLabel(_('Interpreter') + ":"))
        self.interpreter_list_combxo = QComboBox()
        self.scan_all_interpreters()
        class_box.addWidget(self.interpreter_list_combxo)

        self.render_button = QPushButton(_('Render Hierarchy'))
        self.render_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.render_button.clicked.connect(self.render)
        class_box.addWidget(self.render_button)
        frame_layout.addLayout(class_box)

        self._image_viewer = PixmapWidget(self)
        frame_layout.addWidget(self._image_viewer)
        self.load_all_classes()
        self.setLayout(frame_layout)
        self.outputview = None

    def scan_all_interpreters(self):
        for interpreter in InterpreterManager.manager().interpreters:
            self.interpreter_list_combxo.addItem(interpreter.name)

    def render(self):
        index = self.interpreter_list_combxo.currentIndex()
        choose_interpreter = InterpreterManager.manager().interpreters[index]
        if not choose_interpreter.GetInstallPackage('matplotlib'):
            required_package_names = os.linesep.join(self._plugin.required_packages())
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Interpreter must install required packages below:%s')%required_package_names
            )
            return
        class_name = self.class_entry.currentText().strip()
        mod_path_list = self.get_class_mod_list(class_name)
        if mod_path_list:
            if len(mod_path_list) == 1:
                sel = 0
            else:
                sel = simpledialog.asklist(
                    _("Multiple Class Definition"),
                    _("Please choose one base class import module"),
                    mod_path_list,
                    selection=0,
                    master=self
                )
                if sel == -1:
                    return
        else:
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Class name %s is not exist') % class_name
            )
            return
        modpath = mod_path_list[sel]
        interpreter = InterpreterManager.manager().GetInterpreterByName(
            BuiltinPythonInterpreter.BUILTIN_INTERPRETER_NAME
        )
        get_app().intellisence_mananger.load_intellisence_data(interpreter, async_load=False)
        names = modpath.split(".")
        modname = ".".join(names[0:-1])
        class_dict: defaultdict[str, list[str]] = defaultdict(list)
        self.load_module_class(modname, names[-1], class_dict)
        class_hierarchy_filepath = os.path.join(utils.get_cache_path(), 'class_hierarchy.json')
        with open(class_hierarchy_filepath, 'w', encoding="ascii") as f:
            json.dump(class_dict, f)

        pkg_dest_path = resource_filename(__name__, '')
        render_script_path = os.path.join(pkg_dest_path, "render.py")
        interpreter_path = choose_interpreter.path
        args = [
            render_script_path,
            "--class-file",
            class_hierarchy_filepath,
            "-o",
            utils.get_cache_path()
        ]
        executable = Executable(interpreter_path, None, args=args)
        if self.outputview is None:
            self.outputview = get_app().MainFrame.GetView("Output")
            self.outputview.SIG_EXECUTE_FINISHED.connect(self.executor_finished)
        self.outputview.run(
            executable.path,
            executable.args,
            executable.workdir
        )

    def executor_finished(self, exitcode, stopped=True):
        if exitcode == 0:
            plot_png_name = os.path.join(utils.get_cache_path(), PLOT_IMAGE_NAME)
            self._image_viewer.load_from_file(plot_png_name)
        else:
            QMessageBox.critical(self, _('Error'), _('Render fail') + "...")

    def load_module_class(self, modname, classname, class_dict):
        modloader = get_app().intellisence_mananger.GetModule(modname)
        modloader.load()
        child_data = modloader.find_child(classname)
        if not child_data:
            return
        class_dict[classname] = []
        bases = child_data.get('bases', [])
        for base in bases:
            base_modname = base['modname']
            base_names = base_modname.split(".")
            base_class_module = ".".join(base_names[0:-1])
            base_class_name = base_names[-1]
            base_class_dict: defaultdict[str, list[str]] = defaultdict(list)
            class_dict[classname].append(base_class_dict)
            self.load_module_class(base_class_module, base_class_name, base_class_dict)

    def load_all_classes(self):
        class_def_filepath = os.path.join(utils.get_cache_path(), additem.CLASS_DEFS_FILENAME)
        if os.path.exists(class_def_filepath):
            self.load_class_defs(class_def_filepath)

    def load_class_defs(self, class_def_filepath):
        if os.path.exists(class_def_filepath):
            with open(class_def_filepath, encoding="ascii") as f:
                class_dict = json.load(f)
                self.class_entry.addItems(sorted(class_dict.keys()))
                class_dict.clear()

    def get_class_mod_list(self, classname):
        class_def_filepath = os.path.join(utils.get_cache_path(), additem.CLASS_DEFS_FILENAME)
        if os.path.exists(class_def_filepath):
            with open(class_def_filepath, encoding="ascii") as f:
                class_dict = json.load(f)
                return class_dict.get(classname, [])
        return []
