'''
Name:        w9003.py
Purpose:     类方法排序规则
Author:      wukan
Created:     2026-05-26
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp import constants
from novalapp.python.parser import node_utils
from ...codeutils import get_node_range, get_scope_range, get_add_range
from ...multifixer import MultiOptionFixer
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg


class PylintW9003Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:类方法按规则排序
    '''

    def __init__(self):
        super().__init__('W9003', True)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Adjust function order',
            descr='Choose one order position',
            init_options=[
                'Reverse function node position',
                'Insert bottom function node position',
                'Insert top function node position'
            ]
        )

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg)
        res = re.search(r'`(.*)` should be after `(.*)` \(class-method-order\)', msg.msg)
        method_quaname, after_method_quaname = res.groups()
        class_name, method_name = method_quaname.split(".")
        class_name, after_method_name = after_method_quaname.split(".")
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and (
            node.parent.name == method_name and node.parent.parent.name == class_name
        ):
            self.get_selection(textctrl)
            if self.selection == self.INVAID_SEL_INDEX:
                return False
            top_function = node.parent
            bottom_function = ScopeFinder.get_class_method_node(
                top_function.parent,
                after_method_name
            )
            if node_utils.is_function_property(bottom_function):
                property_get_func, property_set_func = ScopeFinder.get_class_function_property_node(
                    top_function.parent,
                    after_method_name
                )
                if property_get_func.lineno <= top_function.lineno:
                    bottom_function = property_set_func
                else:
                    bottom_function = property_get_func
            # after后面的函数必须处于下方
            if bottom_function is None or bottom_function.lineno <= top_function.lineno:
                return False
            if 0 == self.selection:
                return self.reserve_nodes_position(textview, top_function, bottom_function)
            if 1 == self.selection:
                return self.insert_top_position(textview, top_function, bottom_function)
            if 2 == self.selection:
                return self.insert_bottom_position(textview, top_function, bottom_function)
        return False

    @classmethod
    def reserve_nodes_position(cls, textview, top_node, bottom_node):
        '''
        调换2个节点的位置
        '''
        top_line_texts = cls.get_scope_range_texts(top_node, textview.GetCtrl())
        bottom_line_texts = cls.get_scope_range_texts(bottom_node, textview.GetCtrl())
        exchange_fix_range = get_scope_range(bottom_node)
        exchange_fix_range.replace_with_text(
            textview, top_line_texts + constants.LF)
        fix_range = get_scope_range(top_node)
        fix_range.replace_with_text(
            textview, bottom_line_texts + constants.LF)
        return True

    @classmethod
    def insert_top_position(cls, textview, top_node, bottom_node):
        '''
        将底部的节点插入顶部节点的上方
        '''
        bottom_line_texts = cls.get_scope_range_texts(bottom_node, textview.GetCtrl())
        delele_range = get_node_range(bottom_node)
        delele_range.replace_with_text(
            textview, '')
        textview.delete_line(bottom_node.lineno - 1)

        add_range = get_add_range(top_node.lineno, 0)
        add_range.add_text(
            textview, bottom_line_texts + constants.LF)
        return True

    @classmethod
    def insert_bottom_position(cls, textview, top_node, bottom_node):
        '''
        将上方的节点插入底部节点的下方
        '''
        top_line_texts = cls.get_scope_range_texts(top_node, textview.GetCtrl())
        add_range = get_add_range(bottom_node.end_lineno + 1, 0)
        add_range.add_text(
            textview, constants.LF + top_line_texts + constants.LF, end=True)

        delele_range = get_node_range(top_node)
        delele_range.replace_with_text(
            textview, '')
        textview.delete_line(top_node.lineno - 1)
        return True
