import os
from novalapp import _, constants
from novalapp.widgets import simpledialog
from novalapp.util import fileutils
from novalapp.lib.pyqt import (
    QPushButton,
    QVBoxLayout,
    Qt,
    QHBoxLayout,
    QListWidgetItem,
    QMessageBox
)

IGNORE_FILE_NAME = ".gitignore"


class AddIgnoreDlg(simpledialog.SingleChoiceDialog):
    """description of class"""

    def __init__(self, project_doc, master=None):
        self.pjdoc = project_doc
        ignore_file_path = os.path.join(self.pjdoc.GetPath(), IGNORE_FILE_NAME)
        choices = []
        if os.path.exists(ignore_file_path):
            content = fileutils.get_file_content(ignore_file_path)
            choices = content.splitlines()
        super().__init__(
            _('Ignore Files'),
            _('Files or File types below will be ignored') + ":",
            choices,
            -1,
            master
        )
        self.layout.removeWidget(self.listbox)
        self.listbox.itemDoubleClicked.disconnect(self.selectionitem)
        hbox = QHBoxLayout()
        hbox.addWidget(self.listbox)
        vbox = QVBoxLayout()

        addbtn = QPushButton(_('Add'))
        vbox.addWidget(addbtn)
        addbtn.clicked.connect(self.add_ignore)
        rmvbtn = QPushButton(_('Remove'))
        rmvbtn.clicked.connect(self.remove_ignore)
        vbox.addWidget(rmvbtn)
        vbox.setAlignment(Qt.AlignTop)
        hbox.addLayout(vbox)
        self.layout.addLayout(hbox)
        super().create_standard_buttons()

    def remove_ignore(self):
        current_index = self.listbox.currentRow()
        if current_index < 0:
            return
        self.listbox.takeItem(current_index)

    def add_ignore(self):
        self.add_to_ignore()

    def add_to_ignore(self, text=''):
        listitem = QListWidgetItem(text)
        self.listbox.addItem(listitem)
        self.listbox.setCurrentItem(listitem)
        listitem.setFlags(listitem.flags() | Qt.ItemIsEditable)

    def create_standard_buttons(self, button_layout=None):
        pass

    def _ok(self):
        ignore_file_path = os.path.join(self.pjdoc.GetPath(), IGNORE_FILE_NAME)
        itemtexts = []
        for i in range(self.listbox.count()):
            itemtext = self.listbox.item(i).text().strip()
            itemtexts.append(itemtext + constants.LF)
        if itemtexts:
            try:
                with open(ignore_file_path, "w", encoding="utf-8") as fw:
                    fw.writelines(itemtexts)
            except PermissionError as ex:
                QMessageBox.critical(self, _('Error'), str(ex))
                return
        super()._ok()
