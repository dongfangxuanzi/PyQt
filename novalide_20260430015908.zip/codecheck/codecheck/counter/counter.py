import abc
from novalapp.util import fileutils
from novalapp.project.processor import Processor
from novalapp import _
from novalapp.util import utils,strutils
from .. import configkeys
from ..common_check import CommonChecker
import novalapp.syntax.syntax as syntax
import novalapp.syntax.lang as lang
from novalapp.common.encodings import UTF8_FILE_ENCODING, BINARY
from .metrics import Metric

def isCommentLine(line,lineCommentFlag):
    
    if lineCommentFlag == None:
        return False
    
    if line.startswith(lineCommentFlag):
        return True
    return False

def isBlockCommentStart(line,blockCommentStartFlag):
    if blockCommentStartFlag == None:
        return False

    return isCommentLine(line,blockCommentStartFlag)

def isBlockCommentEnd(line,blockCommentEndFlag):
    if blockCommentEndFlag == None:
        return False

    line = line.rstrip()
    if line.endswith(blockCommentEndFlag):
        return True
    return False
    
class CodeMetricsProcessor(Processor, CommonChecker):
    """description of class"""

    def __init__(self, parent, statusbar):
        self.metrics_viewer = parent
        super().__init__(statusbar, 'CodeMetrics', True)
        CommonChecker.__init__(self)


    def stop(self, reason):
        super().stop(reason)
        self.message_viewer.SIG_STOP_PROCESSOR.emit(reason)

    def run(self, doc, filepath):
        super().run(doc, filepath)
        ext = strutils.get_file_extension(filepath)
        if not syntax.SyntaxThemeManager().IsExtSupported(ext):
            return False
        if not self.check_enabled(doc, filepath):
            return False
        if self.stopped:
            utils.get_logger().debug('codecheck is stopped when running')
            return False
        if not self.use_codecheck(doc):
            utils.get_logger().error('codecheck function is disabled')
            return False
        encoding = UTF8_FILE_ENCODING
        try:
            encoding = fileutils.detect_file_encoding(filepath)
            utils.get_logger().debug("detect file %s encoding is %s", filename, encoding)
        except Exception:
            utils.get_logger().error("get file %s encoding error", filename)
            return False
        if encoding == BINARY:
            return False
        file_lexer=syntax.SyntaxThemeManager().GetLangLexerFromExt(ext)
        langId=file_lexer.GetLangId()
        with open(filepath, encoding=encoding) as freader:
            lines = freader.readlines()
            line_count = len(lines)
            if (langId==lang.ID_LANG_TXT):
                blanks_line_count = sum([linetext.strip() == "" for linetext in lines])
                Metric(blanks_line_count,0,0,line_count,filepath)
            else:
                patterns=file_lexer.GetCommentPatterns()
                if(len(patterns)==1):# 前三位分别是单行注释、多行注释开始、多行注释结束
                    if(len(patterns[0])==1):
                        lineCommentFlag= patterns[0][0]
                    else:
                        blockCommentStartFlag= patterns[0][0]
                        blockCommentEndFlag = patterns[0][1]
                elif(len(patterns)==2):
                    if(len(patterns[0])==1):
                        lineCommentFlag= patterns[0][1]
                        blockCommentStartFlag=patterns[1][0]
                        blockCommentEndFlag=patterns[1][1]
                    else:
                        blockCommentStartFlag= patterns[0][0],
                        blockCommentEndFlag=patterns[0][1],
                        lineCommentFlag=patterns[1][0]
                else:
                    raise
                isInBlockComment = False
                count = 0
                valid_lines_count=0
                comment_lines_count=0
                blank_lines_count=0
                for line in lines: # 一行一行的扫描文件内部。
                    count += 1
                    line = line.strip()
                    if line == "":
                        blank_lines_count+=1
                        continue
                    
                    if isInBlockComment==True:
                        commentLinesCount+=1
                        if isBlockCommentEnd(line,blockCommentEndFlag):#如果是注释结束，就将标识符置为否
                            isInBlockComment = False
                            continue  
                        else:
                            continue    
                    else:         
                        if isBlockCommentStart(line,blockCommentStartFlag):#如果是注释开始，就将标识符置为是
                            isInBlockComment = True
                            commentLinesCount+=1
                            continue
                       
             
                    if isCommentLine(line,lineCommentFlag):#如果是注释行，那么就跳转。
                        commentLinesCount+=1
                        continue      
                    
                    valid_lines_count+=1
                
        return True


    def init(self, doc):
        super().init(doc)
        self.init_checker(doc)
        self.enabled = True
        self.metrics_viewer.SIG_INIT_PROCESSOR.emit()

    def end(self, doc):
        if self.stopped:
            utils.get_logger().error('codecheck is stopped with some reason')
        super().end(doc)
        self.enabled = False
        self.message_viewer.SIG_END_PROCESSOR.emit(self.name)




