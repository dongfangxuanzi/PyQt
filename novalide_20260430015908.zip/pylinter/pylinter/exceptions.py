class FixfileError(Exception):
    '''修复文件错误'''


class Autopep8NotInstalledError(RuntimeError):
    '''
    autopep8工具未安装或者正确安装
    '''


class Flake8EradicateNotInstalledError(RuntimeError):
    '''
    flake8-eradicate工具/模块未安装
    '''
