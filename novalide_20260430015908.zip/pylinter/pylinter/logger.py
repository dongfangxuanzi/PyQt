import logging
import sys
from typing import Union

LOG_INITIALIZED = False
DEBUG_IDE_LOG_NAME = "debugger"
DEFAULT_IDE_LOG_NAME = DEBUG_IDE_LOG_NAME


def get_log_level_names(level, level_to_names: list):
    levelname = logging.getLevelName(level)
    level_to_names.append(levelname)
    level_to_names.append(levelname.lower())


def available_log_levels():
    log_level_names = []
    get_log_level_names(logging.DEBUG, log_level_names)
    get_log_level_names(logging.CRITICAL, log_level_names)
    get_log_level_names(logging.ERROR, log_level_names)
    get_log_level_names(logging.WARNING, log_level_names)
    get_log_level_names(logging.INFO, log_level_names)
    return log_level_names


def init_logging(init_level: Union[str, int]=logging.INFO):
    global default_ide_logger, LOG_INITIALIZED, DEFAULT_IDE_LOG_NAME
    if not LOG_INITIALIZED:
        LOG_INITIALIZED = True
        log_level = init_level
        default_stream = sys.stderr
        DEFAULT_IDE_LOG_NAME = DEBUG_IDE_LOG_NAME
        handler = logging.StreamHandler(default_stream)
        handler.setLevel(log_level)
        handler.setFormatter(logging.Formatter("%(message)s"))
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(log_level)
        default_ide_logger = logging.getLogger(DEFAULT_IDE_LOG_NAME)
        default_ide_logger.setLevel(log_level)


default_ide_logger = logging.getLogger(DEFAULT_IDE_LOG_NAME)


def get_logger(logger_name=""):
    if logger_name in ('', 'root'):
        return default_ide_logger
    return logging.getLogger(logger_name)
