#!/usr/bin/env python

"""Automatically formats Python code to conform to the PEP 8 style guide.

Fixes that only need be done once can be added by adding a function of the form
"fix_<code>(source)" to this module. They should return the fixed source code.
These fixes are picked up by apply_global_fixes().

Fixes that depend on pycodestyle should be added as methods to FixPEP8. See the
class documentation for more information.

"""
import collections
import copy
import inspect
import io
import itertools
import os
import re
import sys
import textwrap
import token
import tokenize
import warnings
import ast
from configparser import ConfigParser as SafeConfigParser, Error
import logging
from .node_utils import ImportNodes
from .constants import CRLF, LF, CR, PYLINT_TOOL_NAME
from .reporter import QuietReport
from .formatter import ModuleFormatter
from .fixers import *
from .message import Message
from .fileutils import (
    readlines_from_file,
    read_from_file,
    detect_encoding,
    make_tempfile,
    open_with_encoding
)
from .utils import compute_run_time
from .strutils import normalize_line_endings
log = logging.getLogger(__name__)


LAMBDA_REGEX = re.compile(r'([\w.]+)\s=\slambda\s*([)(=\w,\s.]*):')
COMPARE_NEGATIVE_REGEX = re.compile(r'\b(not)\s+([^][)(}{]+?)\s+(in|is)\s')
COMPARE_NEGATIVE_REGEX_THROUGH = re.compile(r'\b(not\s+in|is\s+not)\s')
BARE_EXCEPT_REGEX = re.compile(r'except\s*:')
STARTSWITH_DEF_REGEX = re.compile(r'^(async\s+def|def)\s.*\):')
DOCSTRING_START_REGEX = re.compile(r'^u?r?(?P<kind>["\']{3})')
ENABLE_REGEX = re.compile(r'# *(fmt|autopep8): *on')
DISABLE_REGEX = re.compile(r'# *(fmt|autopep8): *off')

COMPARE_TYPE_REGEX = re.compile(
    r'([=!]=)\s+type(?:\s*\(\s*([^)]*[^ )])\s*\))'
    r'|\btype(?:\s*\(\s*([^)]*[^ )])\s*\))\s+([=!]=)'
)
TYPE_REGEX = re.compile(r'(type\s*\(\s*[^)]*?[^\s)]\s*\))')


# For generating line shortening candidates.
SHORTEN_OPERATOR_GROUPS = frozenset([
    frozenset([',']),
    frozenset(['%']),
    frozenset([',', '(', '[', '{']),
    frozenset(['%', '(', '[', '{']),
    frozenset([',', '(', '[', '{', '%', '+', '-', '*', '/', '//']),
    frozenset(['%', '+', '-', '*', '/', '//']),
])


# these fixes conflict with each other, if the `--ignore` setting causes both
# to be enabled, disable both of them
CONFLICTING_CODES = ('W503', 'W504')


PROJECT_CONFIG = ('setup.cfg', 'tox.ini', '.pep8', '.flake8')


IS_SUPPORT_TOKEN_FSTRING = False
if sys.version_info >= (3, 12):  # pgrama: no cover
    IS_SUPPORT_TOKEN_FSTRING = True


def extended_blank_lines(logical_line,
                         blank_lines,
                         blank_before,
                         indent_level,
                         previous_logical):
    """Check for missing blank lines after class declaration."""
    if previous_logical.startswith(('def ', 'async def ')):
        if blank_lines and pycodestyle.DOCSTRING_REGEX.match(logical_line):
            yield (0, 'E303 too many blank lines ({})'.format(blank_lines))
    elif pycodestyle.DOCSTRING_REGEX.match(previous_logical):
        # Missing blank line between class docstring and method declaration.
        if (
            indent_level and
            not blank_lines and
            not blank_before and
            logical_line.startswith(('def ', 'async def ')) and
            '(self' in logical_line
        ):
            yield (0, 'E301 expected 1 blank line, found 0')


def continued_indentation(logical_line, tokens, indent_level, hang_closing,
                          indent_char, noqa):
    """Override pycodestyle's function to provide indentation information."""
    first_row = tokens[0][2][0]
    nrows = 1 + tokens[-1][2][0] - first_row
    if noqa or nrows == 1:
        return

    # indent_next tells us whether the next block is indented. Assuming
    # that it is indented by 4 spaces, then we should not allow 4-space
    # indents on the final continuation line. In turn, some other
    # indents are allowed to have an extra 4 spaces.
    indent_next = logical_line.endswith(':')

    row = depth = 0
    valid_hangs = (
        (DEFAULT_INDENT_SIZE,)
        if indent_char != '\t' else (DEFAULT_INDENT_SIZE,
                                     2 * DEFAULT_INDENT_SIZE)
    )

    # Remember how many brackets were opened on each line.
    parens = [0] * nrows

    # Relative indents of physical lines.
    rel_indent = [0] * nrows

    # For each depth, collect a list of opening rows.
    open_rows = [[0]]
    # For each depth, memorize the hanging indentation.
    hangs = [None]

    # Visual indents.
    indent_chances = {}
    last_indent = tokens[0][2]
    indent = [last_indent[1]]

    last_token_multiline = None
    line = None
    last_line = ''
    last_line_begins_with_multiline = False
    for token_type, text, start, end, line in tokens:

        newline = row < start[0] - first_row
        if newline:
            row = start[0] - first_row
            newline = (not last_token_multiline and
                       token_type not in (tokenize.NL, tokenize.NEWLINE))
            last_line_begins_with_multiline = last_token_multiline

        if newline:
            # This is the beginning of a continuation line.
            last_indent = start

            # Record the initial indent.
            rel_indent[row] = pycodestyle.expand_indent(line) - indent_level

            # Identify closing bracket.
            close_bracket = (token_type == tokenize.OP and text in ']})')

            # Is the indent relative to an opening bracket line?
            for open_row in reversed(open_rows[depth]):
                hang = rel_indent[row] - rel_indent[open_row]
                hanging_indent = hang in valid_hangs
                if hanging_indent:
                    break
            if hangs[depth]:
                hanging_indent = hang == hangs[depth]

            visual_indent = (not close_bracket and hang > 0 and
                             indent_chances.get(start[1]))

            if close_bracket and indent[depth]:
                # Closing bracket for visual indent.
                if start[1] != indent[depth]:
                    yield (start, 'E124 {}'.format(indent[depth]))
            elif close_bracket and not hang:
                # closing bracket matches indentation of opening bracket's line
                if hang_closing:
                    yield (start, 'E133 {}'.format(indent[depth]))
            elif indent[depth] and start[1] < indent[depth]:
                if visual_indent is not True:
                    # Visual indent is broken.
                    yield (start, 'E128 {}'.format(indent[depth]))
            elif (hanging_indent or
                  (indent_next and
                   rel_indent[row] == 2 * DEFAULT_INDENT_SIZE)):
                # Hanging indent is verified.
                if close_bracket and not hang_closing:
                    yield (start, 'E123 {}'.format(indent_level +
                                                   rel_indent[open_row]))
                hangs[depth] = hang
            elif visual_indent is True:
                # Visual indent is verified.
                indent[depth] = start[1]
            elif visual_indent in (text, str):
                # Ignore token lined up with matching one from a previous line.
                pass
            else:
                one_indented = (indent_level + rel_indent[open_row] +
                                DEFAULT_INDENT_SIZE)
                # Indent is broken.
                if hang <= 0:
                    error = ('E122', one_indented)
                elif indent[depth]:
                    error = ('E127', indent[depth])
                elif not close_bracket and hangs[depth]:
                    error = ('E131', one_indented)
                elif hang > DEFAULT_INDENT_SIZE:
                    error = ('E126', one_indented)
                else:
                    hangs[depth] = hang
                    error = ('E121', one_indented)

                yield (start, '{} {}'.format(*error))

        # Look for visual indenting.
        if (
            parens[row] and
            token_type not in (tokenize.NL, tokenize.COMMENT) and
            not indent[depth]
        ):
            indent[depth] = start[1]
            indent_chances[start[1]] = True
        # Deal with implicit string concatenation.
        elif (token_type in (tokenize.STRING, tokenize.COMMENT) or
              text in ('u', 'ur', 'b', 'br')):
            indent_chances[start[1]] = str
        # Special case for the "if" statement because len("if (") is equal to
        # 4.
        elif not indent_chances and not row and not depth and text == 'if':
            indent_chances[end[1] + 1] = True
        elif text == ':' and line[end[1]:].isspace():
            open_rows[depth].append(row)

        # Keep track of bracket depth.
        if token_type == tokenize.OP:
            if text in '([{':
                depth += 1
                indent.append(0)
                hangs.append(None)
                if len(open_rows) == depth:
                    open_rows.append([])
                open_rows[depth].append(row)
                parens[row] += 1
            elif text in ')]}' and depth > 0:
                # Parent indents should not be more than this one.
                prev_indent = indent.pop() or last_indent[1]
                hangs.pop()
                for d in range(depth):
                    if indent[d] > prev_indent:
                        indent[d] = 0
                for ind in list(indent_chances):
                    if ind >= prev_indent:
                        del indent_chances[ind]
                del open_rows[depth + 1:]
                depth -= 1
                if depth:
                    indent_chances[indent[depth]] = True
                for idx in range(row, -1, -1):
                    if parens[idx]:
                        parens[idx] -= 1
                        break
            assert len(indent) == depth + 1
            if (
                start[1] not in indent_chances and
                # This is for purposes of speeding up E121 (GitHub #90).
                not last_line.rstrip().endswith(',')
            ):
                # Allow to line up tokens.
                indent_chances[start[1]] = text

        last_token_multiline = start[0] != end[0]
        if last_token_multiline:
            rel_indent[end[0] - first_row] = rel_indent[row]

        last_line = line

    if (
        indent_next and
        not last_line_begins_with_multiline and
        pycodestyle.expand_indent(line) == indent_level + DEFAULT_INDENT_SIZE
    ):
        pos = (start[0], indent[0] + 4)
        desired_indent = indent_level + 2 * DEFAULT_INDENT_SIZE
        if visual_indent:
            yield (pos, 'E129 {}'.format(desired_indent))
        else:
            yield (pos, 'E125 {}'.format(desired_indent))


# NOTE: need reload with runpy and call twice
#   see: https://github.com/hhatto/autopep8/issues/625


class FixPylintWarnings:
    """Fix invalid code.

    Fixer methods are prefixed "fix_". The _fix_source() method looks for these
    automatically.

    The fixer method can take either one or two arguments (in addition to
    self). The first argument is "result", which is the error information from
    pycodestyle. The second argument, "logical", is required only for
    logical-line fixes.

    The fixer method can return the list of modified lines or None. An empty
    list would mean that no changes were made. None would mean that only the
    line reported in the pycodestyle error was modified. Note that the modified
    line numbers that are returned are indexed at 1. This typically would
    correspond with the line number reported in the pycodestyle error
    information.

    [fixed method list]
    """

    def __init__(self, filename,
                 options,
                 contents=None,
                 long_line_ignore_cache=None):
        self.filename = filename
        if contents is None:
            self._contents_from_file = True
            self.source = readlines_from_file(filename)
        else:
            self._contents_from_file = False
            sio = io.StringIO(contents)
            self.source = sio.readlines()
        self.options = options
        self.name = PYLINT_TOOL_NAME
        self.__fixed_count = 0
        self.original_source = copy.copy(self.source)
        self._formatter = ModuleFormatter(self.source, self.filename)
        self._fixers = []

        # collect imports line
        self.imports = {}
        for i, line in enumerate(self.source):
            if (line.find("import ") == 0 or line.find("from ") == 0) and \
                    line not in self.imports:
                # collect only import statements that first appeared
                self.imports[line] = i

        self.long_line_ignore_cache = (
            set() if long_line_ignore_cache is None
            else long_line_ignore_cache)

        # Many fixers are the same even though pycodestyle categorizes them
        # differently.
        self.add_fixer(PylintR0205Fixer(self._formatter))
        self.add_fixer(PylintW0612Fixer(self._formatter))
        self.add_fixer(PylintW0611Fixer(self._formatter))
        self.add_fixer(PylintC0410Fixer(self._formatter))
        self.add_fixer(PylintC0411Fixer(self._formatter))
        self.add_fixer(PylintC0200Fixer(self._formatter))
        self.add_fixer(PylintC0301Fixer(self._formatter))
        self.add_fixer(PylintW0102Fixer(self._formatter))

    @property
    def fixers(self):
        return self._fixers

    @property
    def fixed_count(self):
        return self.__fixed_count

    def add_fixer(self, fixer):
        if self.find_fixer(fixer.ruleid):
            raise RuntimeError(f'rule id: {fixer.ruleid} is already in fixers')
        assert fixer.toolname == self.name
        fixer.check_tool = self
        self._fixers.append(fixer)

    def is_rule_fixable(self, rule_id):
        for fixer in self._fixers:
            if fixer.ruleid == rule_id and fixer.toolname == self.name:
                return True
        return False

    def find_fixer(self, rule_id):
        for fixer in self._fixers:
            if fixer.ruleid == rule_id and fixer.toolname == self.name:
                return fixer
        return None

    def _check_affected_anothers(self, result) -> bool:
        """Check if the fix affects the number of lines of another remark."""
        line_index = result['line'] - 1
        target = self.source[line_index]
        original_target = self.original_source[line_index]
        return target != original_target

    def _fix_source(self, results):
        # except (SyntaxError, tokenize.TokenError):  # pragma: no cover

        completed_lines = set()
        for result in sorted(results, key=lambda x: x['line'], reverse=True):
            result_id = result['id']
            fixer = self.find_fixer(result_id)
            if fixer is not None:
                msg = Message(
                    result['line'],
                    result['column'],
                    result_id,
                    self.filename,
                    result['info'],
                    PYLINT_TOOL_NAME
                )
                log.debug('--->  {}:{}:{}:{}'.format(self.filename,
                                                     result['line'],
                                                     result['column'],
                                                     msg.msg)
                          )
                suc = fixer.auto_fix_msg(msg)
                if suc:
                    log.info(
                        'fix rule %s on line %d column %d success',
                        result_id,
                        result['line'],
                        result['column']
                    )
                    self.__fixed_count += 1
                else:
                    log.info(
                        'fix rule %s on line %d column %d fail',
                        result_id,
                        result['line'],
                        result['column']
                    )
            fixed_methodname = 'fix_' + result_id.lower()
            if hasattr(self, fixed_methodname):
                fix = getattr(self, fixed_methodname)

                line_index = result['line'] - 1
                original_line = self.source[line_index]

                is_logical_fix = len(_get_parameters(fix)) > 2
                if is_logical_fix:
                    logical = None
                    if logical_support:
                        logical = _get_logical(self.source,
                                               result,
                                               logical_start,
                                               logical_end)
                        if logical and set(range(
                            logical[0][0] + 1,
                            logical[1][0] + 1)).intersection(
                                completed_lines):
                            continue

                    if self._check_affected_anothers(result):
                        continue
                    modified_lines = fix(result, logical)
                else:
                    if self._check_affected_anothers(result):
                        continue
                    modified_lines = fix(result)

                if modified_lines is None:
                    # Force logical fixes to report what they modified.
                    assert not is_logical_fix

                    if self.source[line_index] == original_line:
                        modified_lines = []

                if modified_lines:
                    completed_lines.update(modified_lines)
                elif modified_lines == []:  # Empty list means no fix
                    if self.options.verbose >= 2:
                        print(
                            '--->  Not fixing {error} on line {line}'.format(
                                error=result['id'], line=result['line']),
                            file=sys.stderr)
                else:  # We assume one-line fix when None.
                    completed_lines.add(result['line'])
            else:
                log.debug("--->  rule '{}' can't be fixed.".format(result_id))
                info = result['info'].strip()
                log.debug('--->  {}:{}:{}:{}'.format(self.filename,
                                                     result['line'],
                                                     result['column'],
                                                     info)
                          )

    def fix(self):
        """Return a version of the source code with PEP 8 violations fixed."""
        if self._contents_from_file:
            pylint_args = [self.filename]
        else:
            source_content = ''.join(normalize_line_endings(self.source, LF))
            temp_py_filename = make_tempfile(source_content)
            pylint_args = [temp_py_filename]
        results = _execute_pylint(pylint_args, self.source)
        log.info('check total %d pylint issues', len(results))
# if self.options.verbose:
# for r in results:
# if r['id'] not in progress:
# print('--->  {n} issue(s) to fix {progress}'.format(
# n=len(results), progress=progress), file=sys.stderr)

        if self.options.line_range:
            start, end = self.options.line_range
            results = [r for r in results
                       if start <= r['line'] <= end]

        self._fix_source(filter_results(source=''.join(self.source),
                                        results=results,
                                        ))

        if self.options.line_range:
            # If number of lines has changed then change line_range.
            count = sum(sline.count('\n')
                        for sline in self.source[start - 1:end])
            self.options.line_range[1] = start + count - 1
        self.fix_module_imports_blank_line()
        return ''.join(self.source)

    def fix_module_imports_blank_line(self):
        if self._formatter.module is None:
            self._formatter.parse_module()
        if self._formatter.module is not None:
            importutils = ImportNodes(self._formatter.module, self._formatter)
            top_import_nodes = importutils.get_top_import_nodes()
            if not top_import_nodes:
                return
            start_line = top_import_nodes[0].lineno
            end_line = top_import_nodes[-1].lineno
            del_lines = []
            for i in range(start_line - 1, end_line):
                line_text = self._formatter.get_line_text(i)
                if line_text.strip() == '':
                    del_lines.append(i)
            del_lines.sort(reverse=True)
            for del_line_index in del_lines:
                del self.source[del_line_index]


def get_module_imports_on_top_of_file(source, import_line_index):
    """return import or from keyword position

    example:
      > 0: import sys
        1: import os
        2:
        3: def function():
    """
    def is_string_literal(line):
        if line[0] in 'uUbB':
            line = line[1:]
        if line and line[0] in 'rR':
            line = line[1:]
        return line and (line[0] == '"' or line[0] == "'")

    def is_future_import(line):
        nodes = ast.parse(line)
        for n in nodes.body:
            if isinstance(n, ast.ImportFrom) and n.module == '__future__':
                return True
        return False

    def has_future_import(source):
        offset = 0
        line = ''
        for _, next_line in source:
            for line_part in next_line.strip().splitlines(True):
                line = line + line_part
                try:
                    return is_future_import(line), offset
                except SyntaxError:
                    continue
            offset += 1
        return False, offset

    allowed_try_keywords = ('try', 'except', 'else', 'finally')
    in_docstring = False
    docstring_kind = '"""'
    source_stream = iter(enumerate(source))
    for cnt, line in source_stream:
        if not in_docstring:
            m = DOCSTRING_START_REGEX.match(line.lstrip())
            if m is not None:
                in_docstring = True
                docstring_kind = m.group('kind')
                remain = line[m.end(): m.endpos].rstrip()
                if remain[-3:] == docstring_kind:  # one line doc
                    in_docstring = False
                continue
        if in_docstring:
            if line.rstrip()[-3:] == docstring_kind:
                in_docstring = False
            continue

        if not line.rstrip():
            continue
        elif line.startswith('#'):
            continue

        if line.startswith('import '):
            if cnt == import_line_index:
                continue
            return cnt
        if line.startswith('from '):
            if cnt == import_line_index:
                continue
            hit, offset = has_future_import(
                itertools.chain([(cnt, line)], source_stream)
            )
            if hit:
                # move to the back
                return cnt + offset + 1
            return cnt
        if pycodestyle.DUNDER_REGEX.match(line):
            return cnt
        if any(line.startswith(kw) for kw in allowed_try_keywords):
            continue
        elif is_string_literal(line):
            return cnt
        else:
            return cnt
    return 0


def reindent(source, indent_size, leave_tabs=False):
    """Reindent all lines."""
    reindenter = Reindenter(source, leave_tabs)
    return reindenter.run(indent_size)


def code_almost_equal(a, b):
    """Return True if code is similar.

    Ignore whitespace when comparing specific line.

    """
    split_a = split_and_strip_non_empty_lines(a)
    split_b = split_and_strip_non_empty_lines(b)

    if len(split_a) != len(split_b):
        return False

    for (index, _) in enumerate(split_a):
        if ''.join(split_a[index].split()) != ''.join(split_b[index].split()):
            return False

    return True


# A convenient way to handle tokens.
Token = collections.namedtuple('Token', ['token_type', 'token_string',
                                         'spos', 'epos', 'line'])


def _parse_container(tokens, index, for_or_if=None):
    """Parse a high-level container, such as a list, tuple, etc."""

    # Store the opening bracket.
    items = [Atom(Token(*tokens[index]))]
    index += 1

    num_tokens = len(tokens)
    while index < num_tokens:
        tok = Token(*tokens[index])

        if tok.token_string in ',)]}':
            # First check if we're at the end of a list comprehension or
            # if-expression. Don't add the ending token as part of the list
            # comprehension or if-expression, because they aren't part of those
            # constructs.
            if for_or_if == 'for':
                return (ListComprehension(items), index - 1)

            if for_or_if == 'if':
                return (IfExpression(items), index - 1)

            # We've reached the end of a container.
            items.append(Atom(tok))

            # If not, then we are at the end of a container.
            if tok.token_string == ')':
                # The end of a tuple.
                return (Tuple(items), index)

            if tok.token_string == ']':
                # The end of a list.
                return (List(items), index)

            if tok.token_string == '}':
                # The end of a dictionary or set.
                return (DictOrSet(items), index)

        elif tok.token_string in '([{':
            # A sub-container is being defined.
            (container, index) = _parse_container(tokens, index)
            items.append(container)

        elif tok.token_string == 'for':
            (container, index) = _parse_container(tokens, index, 'for')
            items.append(container)

        elif tok.token_string == 'if':
            (container, index) = _parse_container(tokens, index, 'if')
            items.append(container)

        else:
            items.append(Atom(tok))

        index += 1

    return (None, None)


def _parse_tokens(tokens):
    """Parse the tokens.

    This converts the tokens into a form where we can manipulate them
    more easily.

    """

    index = 0
    parsed_tokens = []

    num_tokens = len(tokens)
    while index < num_tokens:
        tok = Token(*tokens[index])

        assert tok.token_type != token.INDENT
        if tok.token_type == tokenize.NEWLINE:
            # There's only one newline and it's at the end.
            break

        if tok.token_string in '([{':
            (container, index) = _parse_container(tokens, index)
            if not container:
                return None
            parsed_tokens.append(container)
        else:
            parsed_tokens.append(Atom(tok))

        index += 1

    return parsed_tokens


def _reflow_lines(parsed_tokens, indentation, max_line_length,
                  start_on_prefix_line):
    """Reflow the lines so that it looks nice."""

    if str(parsed_tokens[0]) == 'def':
        # A function definition gets indented a bit more.
        continued_indent = indentation + ' ' * 2 * DEFAULT_INDENT_SIZE
    else:
        continued_indent = indentation + ' ' * DEFAULT_INDENT_SIZE

    break_after_open_bracket = not start_on_prefix_line

    lines = ReformattedLines(max_line_length)
    lines.add_indent(len(indentation.lstrip('\r\n')))

    if not start_on_prefix_line:
        # If splitting after the opening bracket will cause the first element
        # to be aligned weirdly, don't try it.
        first_token = get_item(parsed_tokens, 0)
        second_token = get_item(parsed_tokens, 1)

        if (
            first_token and second_token and
            str(second_token)[0] == '(' and
            len(indentation) + len(first_token) + 1 == len(continued_indent)
        ):
            return None

    for item in parsed_tokens:
        lines.add_space_if_needed(str(item), equal=True)

        save_continued_indent = continued_indent
        if start_on_prefix_line and isinstance(item, Container):
            start_on_prefix_line = False
            continued_indent = ' ' * (lines.current_size() + 1)

        item.reflow(lines, continued_indent, break_after_open_bracket)
        continued_indent = save_continued_indent

    return lines.emit()


def _shorten_line_at_tokens_new(tokens, source, indentation,
                                max_line_length):
    """Shorten the line taking its length into account.

    The input is expected to be free of newlines except for inside
    multiline strings and at the end.

    """
    # Yield the original source so to see if it's a better choice than the
    # shortened candidate lines we generate here.
    yield indentation + source

    parsed_tokens = _parse_tokens(tokens)

    if parsed_tokens:
        # Perform two reflows. The first one starts on the same line as the
        # prefix. The second starts on the line after the prefix.
        fixed = _reflow_lines(parsed_tokens, indentation, max_line_length,
                              start_on_prefix_line=True)
        if fixed and check_syntax(normalize_multiline(fixed.lstrip())):
            yield fixed

        fixed = _reflow_lines(parsed_tokens, indentation, max_line_length,
                              start_on_prefix_line=False)
        if fixed and check_syntax(normalize_multiline(fixed.lstrip())):
            yield fixed


def _shorten_line_at_tokens(tokens, source, indentation, indent_word,
                            key_token_strings, aggressive):
    """Separate line by breaking at tokens in key_token_strings.

    The input is expected to be free of newlines except for inside
    multiline strings and at the end.

    """
    offsets = []
    for (index, _t) in enumerate(token_offsets(tokens)):
        (token_type,
         token_string,
         start_offset,
         end_offset) = _t

        assert token_type != token.INDENT

        if token_string in key_token_strings:
            # Do not break in containers with zero or one items.
            unwanted_next_token = {
                '(': ')',
                '[': ']',
                '{': '}'}.get(token_string)
            if unwanted_next_token:
                if (
                    unwanted_next_token in (
                        get_item(tokens, index + 1, default=[None, None])[1], get_item(tokens, index + 2, default=[None, None])[1])
                ):
                    continue

            if (
                index > 2 and token_string == '(' and
                tokens[index - 1][1] in ',(%['
            ):
                # Don't split after a tuple start, or before a tuple start if
                # the tuple is in a list.
                continue

            if end_offset < len(source) - 1:
                # Don't split right before newline.
                offsets.append(end_offset)
        else:
            # Break at adjacent strings. These were probably meant to be on
            # separate lines in the first place.
            previous_token = get_item(tokens, index - 1)
            if (
                token_type == tokenize.STRING and
                previous_token and previous_token[0] == tokenize.STRING
            ):
                offsets.append(start_offset)

    current_indent = None
    fixed = None
    for line in split_at_offsets(source, offsets):
        if fixed:
            fixed += '\n' + current_indent + line

            for symbol in '([{':
                if line.endswith(symbol):
                    current_indent += indent_word
        else:
            # First line.
            fixed = line
            assert not current_indent
            current_indent = indent_word

    assert fixed is not None

    if check_syntax(normalize_multiline(fixed)
                    if aggressive > 1 else fixed):
        return indentation + fixed

    return None


def token_offsets(tokens):
    """Yield tokens and offsets."""
    end_offset = 0
    previous_end_row = 0
    previous_end_column = 0
    for t in tokens:
        token_type = t[0]
        token_string = t[1]
        (start_row, start_column) = t[2]
        (end_row, end_column) = t[3]

        # Account for the whitespace between tokens.
        end_offset += start_column
        if previous_end_row == start_row:
            end_offset -= previous_end_column

        # Record the start offset of the token.
        start_offset = end_offset

        # Account for the length of the token itself.
        end_offset += len(token_string)

        yield (token_type,
               token_string,
               start_offset,
               end_offset)

        previous_end_row = end_row
        previous_end_column = end_column


def normalize_multiline(line):
    """Normalize multiline-related code that will cause syntax error.

    This is for purposes of checking syntax.

    """
    if line.startswith(('def ', 'async def ')) and line.rstrip().endswith(':'):
        return line + ' pass'
    if line.startswith('return '):
        return 'def _(): ' + line
    if line.startswith('@'):
        return line + 'def _(): pass'
    if line.startswith('class '):
        return line + ' pass'
    elif line.startswith(('if ', 'elif ', 'for ', 'while ')):
        return line + ' pass'

    return line


def fix_whitespace(line, offset, replacement):
    """Replace whitespace at offset and return fixed line."""
    # Replace escaped newlines too
    left = line[:offset].rstrip('\n\r \t\\')
    right = line[offset:].lstrip('\n\r \t\\')
    if right.startswith('#'):
        return line

    return left + replacement + right


def _execute_pylint(args, source):
    """Execute pycodestyle via python method calls."""
    from pylint.lint import Run as PylintRun
    from pylint.lint.pylinter import MANAGER
    MANAGER.clear_cache()
    runner = PylintRun(args, reporter=QuietReport(), exit=False)
    return runner.linter.reporter.full_error_results()


def _remove_leading_and_normalize(line, with_rstrip=True):
    # ignore FF in first lstrip()
    if with_rstrip:
        return line.lstrip(' \t\v').rstrip(CR + LF) + '\n'
    return line.lstrip(' \t\v')


def _reindent_stats(tokens):
    """Return list of (lineno, indentlevel) pairs.

    One for each stmt and comment line. indentlevel is -1 for comment
    lines, as a signal that tokenize doesn't know what to do about them;
    indeed, they're our headache!

    """
    find_stmt = 1  # Next token begins a fresh stmt?
    level = 0  # Current indent level.
    stats = []

    for t in tokens:
        token_type = t[0]
        sline = t[2][0]
        line = t[4]

        if token_type == tokenize.NEWLINE:
            # A program statement, or ENDMARKER, will eventually follow,
            # after some (possibly empty) run of tokens of the form
            #     (NL | COMMENT)* (INDENT | DEDENT+)?
            find_stmt = 1

        elif token_type == tokenize.INDENT:
            find_stmt = 1
            level += 1

        elif token_type == tokenize.DEDENT:
            find_stmt = 1
            level -= 1

        elif token_type == tokenize.COMMENT:
            if find_stmt:
                stats.append((sline, -1))
                # But we're still looking for a new stmt, so leave
                # find_stmt alone.

        elif token_type == tokenize.NL:
            pass

        elif find_stmt:
            # This is the first "real token" following a NEWLINE, so it
            # must be the first token of the next program statement, or an
            # ENDMARKER.
            find_stmt = 0
            if line:   # Not endmarker.
                stats.append((sline, level))

    return stats


def _leading_space_count(line):
    """Return number of leading spaces in line."""
    i = 0
    while i < len(line) and line[i] == ' ':
        i += 1
    return i


def check_syntax(code):
    """Return True if syntax is okay."""
    try:
        return compile(code, '<string>', 'exec', dont_inherit=True)
    except (SyntaxError, TypeError, ValueError):
        return False


def find_with_line_numbers(pattern, contents):
    """A wrapper around 're.finditer' to find line numbers.

    Returns a list of line numbers where pattern was found in contents.
    """
    matches = list(re.finditer(pattern, contents))
    if not matches:
        return []

    end = matches[-1].start()

    # -1 so a failed `rfind` maps to the first line.
    newline_offsets = {
        -1: 0
    }
    for line_num, m in enumerate(re.finditer(r'\n', contents), 1):
        offset = m.start()
        if offset > end:
            break
        newline_offsets[offset] = line_num

    def get_line_num(match, contents):
        """Get the line number of string in a files contents.

        Failing to find the newline is OK, -1 maps to 0

        """
        newline_offset = contents.rfind('\n', 0, match.start())
        return newline_offsets[newline_offset]

    return [get_line_num(match, contents) + 1 for match in matches]


def get_disabled_ranges(source):
    """Returns a list of tuples representing the disabled ranges.

    If disabled and no re-enable will disable for rest of file.

    """
    enable_line_nums = find_with_line_numbers(ENABLE_REGEX, source)
    disable_line_nums = find_with_line_numbers(DISABLE_REGEX, source)
    total_lines = len(re.findall("\n", source)) + 1

    enable_commands = {}
    for num in enable_line_nums:
        enable_commands[num] = True
    for num in disable_line_nums:
        enable_commands[num] = False

    disabled_ranges = []
    currently_enabled = True
    disabled_start = None

    for line, commanded_enabled in sorted(enable_commands.items()):
        if commanded_enabled is False and currently_enabled is True:
            disabled_start = line
            currently_enabled = False
        elif commanded_enabled is True and currently_enabled is False:
            disabled_ranges.append((disabled_start, line))
            currently_enabled = True

    if currently_enabled is False:
        disabled_ranges.append((disabled_start, total_lines))

    return disabled_ranges


def filter_disabled_results(result, disabled_ranges):
    """Filter out reports based on tuple of disabled ranges.

    """
    line = result['line']
    for disabled_range in disabled_ranges:
        if disabled_range[0] <= line <= disabled_range[1]:
            return False
    return True


def filter_results(source, results):
    """Filter out spurious reports from pycodestyle.

    If aggressive is True, we allow possibly unsafe fixes (E711, E712).

    """
    for r in results:
        yield r


def multiline_string_lines(source, include_docstrings=False):
    """Return line numbers that are within multiline strings.

    The line numbers are indexed at 1.

    Docstrings are ignored.

    """
    line_numbers = set()
    previous_token_type = ''
    _check_target_tokens = [tokenize.STRING]
    if IS_SUPPORT_TOKEN_FSTRING:
        _check_target_tokens.extend([
            tokenize.FSTRING_START,
            tokenize.FSTRING_MIDDLE,
            tokenize.FSTRING_END,
        ])
    try:
        for t in generate_tokens(source):
            token_type = t[0]
            start_row = t[2][0]
            end_row = t[3][0]

            if token_type in _check_target_tokens and start_row != end_row:
                if (
                    include_docstrings or
                    previous_token_type != tokenize.INDENT
                ):
                    # We increment by one since we want the contents of the
                    # string.
                    line_numbers |= set(range(1 + start_row, 1 + end_row))

            previous_token_type = token_type
    except (SyntaxError, tokenize.TokenError):
        pass

    return line_numbers


def commented_out_code_lines(source):
    """Return line numbers of comments that are likely code.

    Commented-out code is bad practice, but modifying it just adds even
    more clutter.

    """
    line_numbers = []
    try:
        for t in generate_tokens(source):
            token_type = t[0]
            token_string = t[1]
            start_row = t[2][0]
            line = t[4]

            # Ignore inline comments.
            if not line.lstrip().startswith('#'):
                continue

            if token_type == tokenize.COMMENT:
                stripped_line = token_string.lstrip('#').strip()
                with warnings.catch_warnings():
                    # ignore SyntaxWarning in Python3.8+
                    # refs:
                    #   https://bugs.python.org/issue15248
                    #   https://docs.python.org/3.8/whatsnew/3.8.html#other-language-changes
                    warnings.filterwarnings("ignore", category=SyntaxWarning)
                    if (
                        ' ' in stripped_line and
                        '#' not in stripped_line and
                        check_syntax(stripped_line)
                    ):
                        line_numbers.append(start_row)
    except (SyntaxError, tokenize.TokenError):
        pass

    return line_numbers


def shorten_comment(line, max_line_length, last_comment=False):
    """Return trimmed or split long comment line.

    If there are no comments immediately following it, do a text wrap.
    Doing this wrapping on all comments in general would lead to jagged
    comment text.

    """
    assert len(line) > max_line_length
    line = line.rstrip()

    # PEP 8 recommends 72 characters for comment text.
    indentation = _get_indentation(line) + '# '
    max_line_length = min(max_line_length,
                          len(indentation) + 72)

    MIN_CHARACTER_REPEAT = 5
    if (
        len(line) - len(line.rstrip(line[-1])) >= MIN_CHARACTER_REPEAT and
        not line[-1].isalnum()
    ):
        # Trim comments that end with things like ---------
        return line[:max_line_length] + '\n'
    if last_comment and re.match(r'\s*#+\s*\w+', line):
        split_lines = textwrap.wrap(line.lstrip(' \t#'),
                                    initial_indent=indentation,
                                    subsequent_indent=indentation,
                                    width=max_line_length,
                                    break_long_words=False,
                                    break_on_hyphens=False)
        return '\n'.join(split_lines) + '\n'

    return line + '\n'


def mutual_startswith(a, b):
    return b.startswith(a) or a.startswith(b)


def code_match(code, select, ignore):
    if ignore:
        assert not isinstance(ignore, str)
        for ignored_code in [c.strip() for c in ignore]:
            if mutual_startswith(code.lower(), ignored_code.lower()):
                return False

    if select:
        assert not isinstance(select, str)
        for selected_code in [c.strip() for c in select]:
            if mutual_startswith(code.lower(), selected_code.lower()):
                return True
        return False

    return True


def fix_code(source, options=None, encoding=None, apply_config=False):
    """Return fixed source code.

    "encoding" will be used to decode "source" if it is a byte string.

    """
    options = _get_options(options, apply_config)
    # normalize
    options.ignore = [opt.upper() for opt in options.ignore]
    options.select = [opt.upper() for opt in options.select]

    # check ignore args
    # NOTE: If W50x is not included, add W50x because the code
    #       correction result is indefinite.
    ignore_opt = options.ignore
    if not {"W50", "W503", "W504"} & set(ignore_opt):
        options.ignore.append("W50")

    if not isinstance(source, str):
        source = source.decode(encoding or get_encoding())

    sio = io.StringIO(source)
    return fix_lines(source, options=options)


def _get_options(raw_options, apply_config):
    """Return parsed options."""
    if not raw_options:
        return parse_args([''], apply_config=apply_config)

    if isinstance(raw_options, dict):
        options = parse_args([''], apply_config=apply_config)
        for name, value in raw_options.items():
            if not hasattr(options, name):
                raise ValueError("No such option '{}'".format(name))

            # Check for very basic type errors.
            expected_type = type(getattr(options, name))
            if not isinstance(expected_type, (str, )):
                if isinstance(value, (str, )):
                    raise ValueError(
                        "Option '{}' should not be a string".format(name))
            setattr(options, name, value)
    else:
        options = raw_options

    return options


def find_newline(source):
    """Return type of newline used in source.

    Input is a list of lines.

    """
    assert not isinstance(source, str)

    counter = collections.defaultdict(int)
    for line in source:
        if line.endswith(CRLF):
            counter[CRLF] += 1
        elif line.endswith(CR):
            counter[CR] += 1
        elif line.endswith(LF):
            counter[LF] += 1

    return (sorted(counter, key=counter.get, reverse=True) or [LF])[0]


def fix_lines(content, options, filename=''):
    """Return fixed source code."""
    # Transform everything to line feed. Then change them back to original
    # before returning fixed source code.
##
# Keep a history to break out of cycles.
# if options.line_range:
# Disable "apply_local_fixes()" for now due to issue #175.
# Apply global fixes only once (for efficiency).
# fixed_source = apply_global_fixes(tmp_source,
# options,
# filename=filename)

    fixed_warnings = 0
    long_line_ignore_cache = set()
    fix = FixPylintWarnings(
        filename,
        options,
        contents=content,
        long_line_ignore_cache=long_line_ignore_cache
    )
    fixed_source = fix.fix()
    fixed_warnings = fix.fixed_count
    sio = io.StringIO(fixed_source)
    return ''.join(normalize_line_endings(sio.readlines(), LF)), fixed_warnings


@compute_run_time
def fix_file(filename, options=None, output=None, source=None, apply_config=False):
    if not options:
        options = parse_args([filename], apply_config=apply_config)

    if source is None:
        fixed_source = None
        original_source = read_from_file(filename)
    else:
        fixed_source = source
        original_source = source

    if options.in_place or output:
        encoding = detect_encoding(filename)

#    if output:
 #       output = LineEndingWrapper(wrap_output(output, encoding=encoding))
    log.info('start fix file `%s`', filename)
    fixed_source, fixed_count = fix_lines(fixed_source, options, filename=filename)
    if options.in_place:
        original = original_source.splitlines(keepends=True)
        fixed = fixed_source.splitlines(keepends=True)
        original_source_last_line = (
            original[-1].split("\n")[-1] if original else ""
        )
        fixed_source_last_line = fixed_source.split("\n")[-1]
        if original != fixed or (
            original_source_last_line != fixed_source_last_line
        ):
            with open_with_encoding(filename, 'w', encoding=encoding) as fp:
                fp.write(fixed_source)
            return fixed_source, fixed_count
        return None, fixed_count
    else:
        if output:
            output.write(fixed_source)
            output.flush()
    return fixed_source, fixed_count


def global_fixes():
    """Yield multiple (code, function) tuples."""
    for function in list(globals().values()):
        if inspect.isfunction(function):
            arguments = _get_parameters(function)
            if arguments[:1] != ['source']:
                continue

            code = extract_code_from_function(function)
            if code:
                yield (code, function)


def _get_parameters(function):
    if sys.version_info.major >= 3:
        # We need to match "getargspec()", which includes "self" as the first
        # value for methods.
        # https://bugs.python.org/issue17481#msg209469
        if inspect.ismethod(function):
            function = function.__func__

        return list(inspect.signature(function).parameters)
    return inspect.getargspec(function)[0]


def apply_global_fixes(source, options, where='global', filename='',
                       codes=None):
    """Run global fixes on source code.

    These are fixes that only need be done once (unlike those in
    FixPEP8, which are dependent on pycodestyle).

    """
    if codes is None:
        codes = []
    if any(code_match(code, select=options.select, ignore=options.ignore)
           for code in ['E101', 'E111']):
        source = reindent(
            source,
            indent_size=options.indent_size,
            leave_tabs=not (
                code_match(
                    'W191',
                    select=options.select,
                    ignore=options.ignore
                )
            )
        )

    for (code, function) in global_fixes():
        if code_match(code, select=options.select, ignore=options.ignore):
            if options.verbose:
                print('--->  Applying {} fix for {}'.format(where,
                                                            code.upper()),
                      file=sys.stderr)
            source = function(source,
                              aggressive=options.aggressive)

    return source


def extract_code_from_function(function):
    """Return code handled by function."""
    if not function.__name__.startswith('fix_'):
        return None

    code = re.sub('^fix_', '', function.__name__)
    if not code:
        return None

    try:
        int(code[1:])
    except ValueError:
        return None

    return code


def _expand_codes(codes, ignore_codes):
    """expand to individual E/W codes"""
    ret = set()

    is_conflict = False
    if all(
            any(
                conflicting_code.startswith(code)
                for code in codes
            )
            for conflicting_code in CONFLICTING_CODES
    ):
        is_conflict = True

    is_ignore_w503 = "W503" in ignore_codes
    is_ignore_w504 = "W504" in ignore_codes

    for code in codes:
        if code == "W":
            if is_ignore_w503 and is_ignore_w504:
                ret.update({"W1", "W2", "W3", "W505", "W6"})
            elif is_ignore_w503:
                ret.update({"W1", "W2", "W3", "W504", "W505", "W6"})
            else:
                ret.update({"W1", "W2", "W3", "W503", "W505", "W6"})
        elif code in ("W5", "W50"):
            if is_ignore_w503 and is_ignore_w504:
                ret.update({"W505"})
            elif is_ignore_w503:
                ret.update({"W504", "W505"})
            else:
                ret.update({"W503", "W505"})
        elif not (code in ("W503", "W504") and is_conflict):
            ret.add(code)

    return ret


def _get_normalize_options(args, config, section, option_list):
    for (k, v) in config.items(section):
        norm_opt = k.lstrip('-').replace('-', '_')
        if not option_list.get(norm_opt):
            continue
        opt_type = option_list[norm_opt]
        if opt_type is int:
            if v.strip() == "auto":
                # skip to special case
                if args.verbose:
                    print(f"ignore config: {k}={v}")
                continue
            value = config.getint(section, k)
        elif opt_type is bool:
            value = config.getboolean(section, k)
        else:
            value = config.get(section, k)
        yield norm_opt, k, value


def read_config(args, parser):
    """Read both user configuration and local configuration."""
    config = SafeConfigParser()

    try:
        if args.verbose and os.path.exists(args.global_config):
            print("read config path: {}".format(args.global_config))
        config.read(args.global_config)

        if not args.ignore_local_config:
            parent = tail = args.files and os.path.abspath(
                os.path.commonprefix(args.files))
            while tail:
                if config.read([os.path.join(parent, fn)
                                for fn in PROJECT_CONFIG]):
                    if args.verbose:
                        for fn in PROJECT_CONFIG:
                            config_file = os.path.join(parent, fn)
                            if not os.path.exists(config_file):
                                continue
                            print(
                                "read config path: {}".format(
                                    os.path.join(parent, fn)
                                )
                            )
                    break
                (parent, tail) = os.path.split(parent)

        defaults = {}
        option_list = {o.dest: o.type or type(o.default)
                       for o in parser._actions}

        for section in ['pep8', 'pycodestyle', 'flake8']:
            if not config.has_section(section):
                continue
            for norm_opt, k, value in _get_normalize_options(
                args, config, section, option_list
            ):
                if args.verbose:
                    print("enable config: section={}, key={}, value={}".format(
                        section, k, value))
                defaults[norm_opt] = value

        parser.set_defaults(**defaults)
    except Error:
        # Ignore for now.
        pass

    return parser


def read_pyproject_toml(args, parser):
    """Read pyproject.toml and load configuration."""
    if sys.version_info >= (3, 11):
        import tomllib
    else:
        import tomli as tomllib

    config = None

    if os.path.exists(args.global_config):
        with open(args.global_config, "rb") as fp:
            config = tomllib.load(fp)

    if not args.ignore_local_config:
        parent = tail = args.files and os.path.abspath(
            os.path.commonprefix(args.files))
        while tail:
            pyproject_toml = os.path.join(parent, "pyproject.toml")
            if os.path.exists(pyproject_toml):
                with open(pyproject_toml, "rb") as fp:
                    config = tomllib.load(fp)
                    break
            (parent, tail) = os.path.split(parent)

    if not config:
        return None

    if config.get("tool", {}).get("autopep8") is None:
        return None

    config = config.get("tool", {}).get("autopep8")

    defaults = {}
    option_list = {o.dest: o.type or type(o.default)
                   for o in parser._actions}

    TUPLED_OPTIONS = ("ignore", "select")
    for (k, v) in config.items():
        norm_opt = k.lstrip('-').replace('-', '_')
        if not option_list.get(norm_opt):
            continue
        if type(v) in (list, tuple) and norm_opt in TUPLED_OPTIONS:
            value = ",".join(v)
        else:
            value = v
        if args.verbose:
            print("enable pyproject.toml config: "
                  "key={}, value={}".format(k, value))
        defaults[norm_opt] = value

    if defaults:
        # set value when exists key-value in defaults dict
        parser.set_defaults(**defaults)

    return parser


def supported_fixes():
    """Yield pep8 error codes that autopep8 fixes.

    Each item we yield is a tuple of the code followed by its
    description.

    """
   # yield ('E101', docstring_summary(reindent.__doc__))

    instance = FixPylintWarnings(filename=None, options=None, contents='')
    for fixer in instance.fixers:
        yield (
            fixer.ruleid,
            re.sub(r'\s+', ' ',
                   fixer.__doc__)
        )

# for (code, function) in sorted(global_fixes()):
# yield (code.upper() + (4 - len(code)) * ' ',
# re.sub(r'\s+', ' ', docstring_summary(function.__doc__)))


def standard_deviation(numbers):
    """Return standard deviation."""
    numbers = list(numbers)
    if not numbers:
        return 0
    mean = sum(numbers) / len(numbers)
    return (sum((n - mean) ** 2 for n in numbers) /
            len(numbers)) ** .5


def has_arithmetic_operator(line):
    """Return True if line contains any arithmetic operators."""
    for operator in pycodestyle.ARITHMETIC_OP:
        if operator in line:
            return True

    return False


def count_unbalanced_brackets(line):
    """Return number of unmatched open/close brackets."""
    count = 0
    for opening, closing in ['()', '[]', '{}']:
        count += abs(line.count(opening) - line.count(closing))

    return count


def split_at_offsets(line, offsets):
    """Split line at offsets.

    Return list of strings.

    """
    result = []

    previous_offset = 0
    current_offset = 0
    for current_offset in sorted(offsets):
        if current_offset < len(line) and previous_offset != current_offset:
            result.append(line[previous_offset:current_offset].strip())
        previous_offset = current_offset

    result.append(line[current_offset:])

    return result
