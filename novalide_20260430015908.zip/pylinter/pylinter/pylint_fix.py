import os
from astroid import nodes
from .basefix import BasePythonFixer
from .constants import PYLINT_TOOL_NAME
from .replace import get_node_range, FixNode


class PylintFixer(BasePythonFixer):
    def __init__(self, ruleid, formatter):
        super().__init__(ruleid, PYLINT_TOOL_NAME, formatter)

    def delete_import_name(self, node, import_name, asname):
        if isinstance(node, (nodes.Import, nodes.ImportFrom)):
            import_names = [name[0] for name in node.names]
            if import_name not in import_names:
                return False
            node.names.remove((import_name, asname))
            replacenode = FixNode(node, self.formatter)
            if node.names == []:
                replacenode.replace_node_with_text('')
            else:
                replacenode.replace_node_with_text(node.as_string())
            return True
        return False

    @classmethod
    def replace_variable_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.Name, nodes.AssignName)) and child.name == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, newname)
            else:
                cls.replace_variable_name_in_scope(
                    textview, child, name, newname)

    @classmethod
    def replace_attribute_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.AssignAttr, nodes.Attribute)) and child.attrname == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, "self." + newname)
            else:
                cls.replace_attribute_name_in_scope(
                    textview, child, name, newname)

    @staticmethod
    def replace_module_name(doc, oldpath, new_module_name):
        ext = strutils.get_file_extension(oldpath, keepdot=True)
        newname = os.path.join(
            fileutils.get_filepath_from_path(oldpath), new_module_name)
        newfilepath = strutils.MakeNameEndInExtension(newname, ext)
        return doc.GetCommandProcessor().Submit(
            projectcommand.ProjectRenameFileCommand(doc, oldpath, newfilepath)
        )
