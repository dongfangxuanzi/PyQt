import re
import tempfile
import io
import os
import os.path
from .constants import MAX_PYTHON_FILE_DETECTION_BYTES

ENCODING_MAGIC_COMMENT = re.compile(
    r'^[ \t\f]*#.*?coding[:=][ \t]*([-_.a-zA-Z0-9]+)'
)

PYTHON_SHEBANG_REGEX = re.compile(r'^#!.*\bpython[23]?\b\s*$')


def get_file_content(filename, allow_exception=True, enc='utf-8'):
    """Provides the file content"""
    try:
        with open(filename, 'r', encoding=enc) as diskfile:
            content = diskfile.read()
        return content
    except Exception:
        if allow_exception:
            raise
        return None


def readlines_from_file(filename):
    """Return contents of file."""
    with open_with_encoding(filename) as input_file:
        return input_file.readlines()


def read_from_file(filename):
    """Return contents of file."""
    with open_with_encoding(filename) as input_file:
        return input_file.read()


def open_with_encoding(filename, mode='r', encoding=None, limit_byte_check=-1):
    """Return opened file with a specific encoding."""
    if not encoding:
        encoding = detect_encoding(filename, limit_byte_check=limit_byte_check)

    return io.open(filename, mode=mode, encoding=encoding,
                   newline='')  # Preserve line endings


def _detect_encoding_from_file(filename: str):
    try:
        with open(filename) as input_file:
            for idx, line in enumerate(input_file):
                if idx == 0 and line[0] == '\ufeff':
                    return "utf-8-sig"
                if idx >= 2:
                    break
                match = ENCODING_MAGIC_COMMENT.search(line)
                if match:
                    return match.groups()[0]
    except Exception:
        pass
    # Python3's default encoding
    return 'utf-8'


def detect_encoding(filename, limit_byte_check=-1):
    """Return file encoding."""
    encoding = _detect_encoding_from_file(filename)
    if encoding == "utf-8-sig":
        return encoding
    try:
        with open_with_encoding(filename, encoding=encoding) as test_file:
            test_file.read(limit_byte_check)
        return encoding
    except (LookupError, SyntaxError, UnicodeDecodeError):
        return 'latin-1'


def make_tempfile(content, encoding="utf-8", ext=".py"):
    _, newfname = tempfile.mkstemp(suffix=ext, text=True)
    with open(newfname, 'w', encoding=encoding) as f:
        f.write(content)
    return newfname


def is_python_file(filename):
    """Return True if filename is Python file."""
    if filename.endswith('.py'):
        return True

    try:
        with open_with_encoding(
                filename,
                limit_byte_check=MAX_PYTHON_FILE_DETECTION_BYTES) as f:
            text = f.read(MAX_PYTHON_FILE_DETECTION_BYTES)
            if not text:
                return False
            first_line = text.splitlines()[0]
    except (IOError, IndexError):
        return False

    if not PYTHON_SHEBANG_REGEX.match(first_line):
        return False
    return True


def match_file(filename, exclude):
    """Return True if file is okay for modifying/recursing."""
    base_name = os.path.basename(filename)

    if base_name.startswith('.'):
        return False

    for pattern in exclude:
        if fnmatch.fnmatch(base_name, pattern):
            return False
        if fnmatch.fnmatch(filename, pattern):
            return False

    if not os.path.isdir(filename) and not is_python_file(filename):
        return False

    return True
