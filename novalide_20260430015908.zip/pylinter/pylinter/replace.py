

class FixRange:
    def __init__(self, start_line, start_col=None, end_line=None, end_col=None):
        self.start_line = start_line or 1
        self.start_col = start_col or 0
        self.end_line = end_line or self.start_line
        self.end_col = end_col or self.start_col
        self.start_line -= 1
        self.end_line -= 1

    def replace_with_text(self, formatter, text):
        head, tail, chars, lines = formatter.get_region(
            self.start_line,
            self.start_col,
            self.end_line,
            self.end_col
        )
        formatter.set_region(head, tail, chars, text.split("\n"))

    def replace_line(self, formatter, text):
        linetext = formatter.encode_string(formatter.get_line_text(self.start_line))
        end_col = len(linetext)
        head, tail, chars, lines = formatter.get_region(
            self.start_line,
            0,
            self.end_line,
            end_col
        )
        formatter.set_region(head, tail, chars, text.split("\n"))

    def add_text(self, formatter, inserted_content, end=False):
        if not end:
            insert_pos = formatter.position_from_linecol(
                self.start_line, self.start_col)
        else:
            insert_pos = formatter.position_from_linecol(
                self.end_line, self.end_col)
        formatter.insert_text(insert_pos, inserted_content)

    @staticmethod
    def node_range(node):
        return FixRange(
            node.lineno,
            node.col_offset,
            node.end_lineno,
            node.end_col_offset
        )

    @staticmethod
    def add_range(line, col):
        return FixRange(line, col, line, col)


class FixNode:
    def __init__(self, node, formatter):
        self._node = node
        self._formatter = formatter

    def replace_node_with_text(self, reptext):
        replace_range = FixRange.node_range(self._node)
        replace_range.replace_with_text(self._formatter, reptext)


def get_node_range(node):
    return FixRange.node_range(node)


def get_add_range(line, col):
    return FixRange.add_range(line, col)
