import abc
import logging
from .exceptions import FixfileError
from .node_scope import ScopeFinder
log = logging.getLogger(__name__)


class BaseFixer(abc.ABC):
    """description of class"""

    def __init__(self, ruleid, toolname, formatter):
        self._ruleid = ruleid
        self._toolname = toolname
        self.fix_tool = None
        self._formatter = formatter

    @property
    def formatter(self):
        return self._formatter

    @property
    def ruleid(self):
        return self._ruleid

    @property
    def toolname(self):
        return self._toolname

    @abc.abstractmethod
    def fix_message(self, msg):
        raise NotImplementedError('You must implemented it in derived class')

    def auto_fix_msg(self, msg):
        result: bool = self.fix_message(msg)
        assert isinstance(result, bool)
        return result

    def get_msg_line_text(self, msg):
        return self.formatter.get_line_text(msg.line - 1)


class BasePythonFixer(BaseFixer):
    ''''''

    def load_module(self, filepath):
        if self.formatter.module is None:
            self.formatter.parse_module()
            assert self.formatter.module is not None

    def find_msg_node(self, msg, use_column=False):
        self.load_module(msg.filepath)
        line = msg.line
        scope = ScopeFinder(self.formatter.module).find_scope(line)
        if use_column:
            node = self.formatter.find_line_col_node(line, msg.column, scope)
        else:
            node = self.formatter.find_line_node(line, scope)
        return node

    def auto_fix_msg(self, msg):
        result: bool = super().auto_fix_msg(msg)
        # 告警修复成功,表示文件内容有变动, 需要重新解析并加载语法树
        if result:
            # 重新解析并加载语法树
            self.formatter.parse_module()
            if self.formatter.module is None:
                log.error(
                    'fix rule %s on line %d column %d occur exception.',
                    msg.ruleid,
                    msg.line,
                    msg.column
                )
                self.formatter.dump(filename="d:\\test.py")
                raise FixfileError(f"Fix file {msg.filepath} Error:{self.formatter.syntax_error_msg}")
        return result
