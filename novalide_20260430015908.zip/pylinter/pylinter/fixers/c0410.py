import re
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..replace import get_node_range


class PylintC0410Fixer(PylintFixer):
    '''
    规则说明: 一行导入多个模块
    '''

    def __init__(self, formatter):
        super().__init__('C0410', formatter)

    def fix_message(self, msg):
        self.load_module(msg.filepath)
        node = self.formatter.find_line_node(msg.line)
        if isinstance(node, nodes.Import):
            res = re.search(
                r'Multiple imports on one line \((.*)\) \(multiple-imports\)', msg.msg)
            if not res:
                return False
            matched_names = [name.strip()
                             for name in res.groups()[0].strip().split(',')]
            names = [name[0] for name in node.names]
            if len(names) >= 2 and matched_names == names:
                fix_range = get_node_range(node)
                imports = []
                for name in names:
                    imports.append("import %s" % name)
                fix_range.replace_with_text(self.formatter, '\n'.join(imports))
                return True
        return False
