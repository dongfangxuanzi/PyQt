import os
import re
from astroid import nodes
from .. import strutils
from .. import node_utils
from ..node_scope import ScopeFinder
from ..constants import DEFAULT_TAB_BLANKS, LF
from ..replace import (
    get_node_range,
    FixRange,
    FixNode
)
from ..pylint_fix import PylintFixer


class PylintC0301Fixer(PylintFixer):
    '''
    规则说明:代码行语句过长
    '''

    SINGLE_TRIPLE_QUOTE = "'''"
    DOUBLE_TRIPLE_QUOTE = '"""'

    def __init__(self, formatter):
        super().__init__('C0301', formatter)

    @staticmethod
    def locate_in_docstr(scope_node, line):
        if scope_node.doc_node is None:
            return False
        return scope_node.doc_node.lineno <= line <= scope_node.doc_node.end_lineno

    @classmethod
    def docstr_line_startswith_triple_quote(cls, docstr):
        '''
        文档说明字符串开头是否和3引号同一行
        '''
        linestr = docstr.lstrip()
        return linestr.startswith(cls.SINGLE_TRIPLE_QUOTE) or linestr.startswith(cls.DOUBLE_TRIPLE_QUOTE)

    @classmethod
    def docstr_line_endswith_triple_quote(cls, docstr):
        '''
        文档说明字符串结尾是否和3引号同一行
        '''
        linestr = docstr.rstrip()
        return linestr.endswith(cls.SINGLE_TRIPLE_QUOTE) or linestr.endswith(cls.DOUBLE_TRIPLE_QUOTE)

    @staticmethod
    def split_line_text(linetext, max_line_length, use_re=False):
        '''
        代码行过长,按限制最大行长度进行分割
        '''
        if use_re:
            # 使用正则按空格分割行文本可以保持原生字符串的内容,尤其是空格的数量
            line_texts = re.split(r'[\s]', linetext)
        else:
            line_texts = linetext.split()
        splitline_text_length = 0
        fix_line_texts = []
        for text in line_texts:
            fix_line_texts.append(text)
            splitline_text_length += len(text)
            splitline_text_length += 1
            # 代码行过长,截断换行,行长度不能超过最大行长度
            if splitline_text_length > max_line_length:
                del fix_line_texts[-1]
                break
        trim_line_text_num = len(fix_line_texts)
        return fix_line_texts, line_texts[trim_line_text_num:]

    def fix_message(self, msg):
        line = msg.line
        res = re.search(r"Line too long \((\d+)/(\d+)\)", msg.msg)
        if not res:
            return False
        linetext = self.get_msg_line_text(msg)
# utils.get_logger().debug(
# line,
# msg.filepath,
# linetext,
        # 行号内容发生改变,停止修复
        fix_linetext_length = int(res.groups()[0])
        if len(linetext) != fix_linetext_length:
            # utils.get_logger().warning(
            # line,
            # msg.filepath,
            # msg.ruleid
            return False
        linenode = self.find_msg_node(msg)
        comment_index = linetext.find('#')
        max_line_length = int(res.groups()[1])
        if comment_index != -1:
            # 注释在代码右边
            if linenode:
                if isinstance(linenode, nodes.JoinedStr) or node_utils.is_const_type(linenode, str):
                    return False
                line_offset_blanks = linenode.col_offset * ' '
                fixrange = FixRange(line)
                comment_text = linetext[comment_index:]
                fixrange.replace_line(self.formatter, linetext[0:comment_index])
                fixrange.add_text(
                    self.formatter, line_offset_blanks + comment_text + os.linesep)
                return True
            # 注释在代码上方
            else:
                line_offset_blanks = comment_index * ' '
                # 注释行过长,截断换行,行长度不能超过最大行长度减5
                line_comment_texts, remain_comment_texts = self.split_line_text(
                    linetext[comment_index + 1:],
                    max_line_length - comment_index - 5
                )
                if not line_comment_texts:
                    return False
                head_comment_text = '# '
                fixrange = FixRange(line)
                trim_comment_text = linetext[0:comment_index] + head_comment_text + ' '.join(line_comment_texts)
                fixrange.replace_line(self.formatter, trim_comment_text)
                if remain_comment_texts:
                    last_comment_text = head_comment_text + ' '.join(remain_comment_texts)
                    if not last_comment_text.endswith("."):
                        last_comment_text += "."
                    fixrange = FixRange(line + 1)
                    fixrange.add_text(
                        self.formatter, line_offset_blanks + last_comment_text + os.linesep)
                return True
        if not linenode:
            # 文档说明行太长
            scope = ScopeFinder(self.formatter.module).find_class_funcdef_scope(line)
            if self.locate_in_docstr(scope, line):
                if self.docstr_line_startswith_triple_quote(
                        linetext) or self.docstr_line_endswith_triple_quote(linetext):
                    return self.fix_docstr_position(scope.doc_node)
                docstr_offset_index = -1
                for i, c in enumerate(linetext):
                    if c in [' ', '\t']:
                        continue
                    docstr_offset_index = i
                    break
                line_offset_blanks = docstr_offset_index * ' '
                # 文档说明行过长,截断换行,行长度不能超过最大行长度减2
                fix_docline_texts, remain_docline_texts = self.split_line_text(
                    linetext[docstr_offset_index:],
                    max_line_length - docstr_offset_index - 2
                )
                fixrange = FixRange(line)
                trim_docline_text = linetext[0:docstr_offset_index] + ' '.join(fix_docline_texts)
                fixrange.replace_line(self.formatter, trim_docline_text)
                if remain_docline_texts:
                    last_docline_text = ' '.join(remain_docline_texts)
                    if not last_docline_text.endswith("."):
                        last_docline_text += "."
                    fixrange = FixRange(line + 1)
                    fixrange.add_text(
                        self.formatter, line_offset_blanks + last_docline_text + os.linesep)
                return True
            return False
        line_offset_blanks = linenode.col_offset * ' '
        if isinstance(linenode, nodes.ImportFrom):
            modname = linenode.modname
            if linenode.level is not None:
                # 如果相对导入全是dot符合,则包或模块名称为空字符串
                level_name = "." * linenode.level
                if not strutils.is_none_empty(modname):
                    modname = level_name + modname
                else:
                    modname = level_name
            fix_str = 'from %s import (\n' % modname
            for name, asname in linenode.names[0:-1]:
                import_name = "%s%s,\n" % (DEFAULT_TAB_BLANKS, name)
                fix_str += import_name
            fix_str += "%s%s\n" % (DEFAULT_TAB_BLANKS, linenode.names[-1][0])
            fix_str += ")"
            fix_range = get_node_range(linenode)
            fix_range.replace_with_text(self.formatter, fix_str)
            return True
        if isinstance(linenode, nodes.Name) and isinstance(linenode.parent, nodes.FunctionDef):
            funcnode = linenode.parent
            line_offset_blanks = funcnode.col_offset * ' '
            args = funcnode.args
            args.lineno = args.args[0].lineno
            args.col_offset = args.args[0].col_offset
            args.end_lineno = args.args[-1].end_lineno
            args.end_col_offset = args.args[-1].end_col_offset
            default_args = args.defaults or [] + args.kw_defaults or []
            if default_args:
                args.end_lineno = default_args[-1].end_lineno
                args.end_col_offset = default_args[-1].end_col_offset
            argstr = args.as_string()
            arglist = argstr.split(',')
            if args.kwarg is not None:
                arglist = arglist[0:-1]
            argnum = len(arglist)
            fix_range = get_node_range(args)
            fix_line_head = line_offset_blanks + DEFAULT_TAB_BLANKS
            fix_str = ''
            fix_str += os.linesep
            for i, arg in enumerate(arglist):
                fix_str += fix_line_head
                fix_str += arg.strip()
                if i < argnum - 1:
                    fix_str += ","
                fix_str += os.linesep
                if i == argnum - 1:
                    fix_str += fix_line_head
            fix_range.replace_with_text(self.formatter, fix_str)
            return True
        if isinstance(linenode, nodes.Assign):
            if isinstance(linenode.value, (nodes.List, nodes.Tuple)):
                has_comment_in_lines = self.has_comment_in_node_lines(linenode.value)
# utils.get_logger().info(
# linenode.value,
# linenode.value.lineno,
# linenode.value.end_lineno,
                if has_comment_in_lines:
                    return False
                fixrange = get_node_range(linenode.value)
                fixstr = '[' if isinstance(linenode.value, nodes.List) else '('
                fixstr += os.linesep
                fix_line_head = line_offset_blanks + DEFAULT_TAB_BLANKS
                elts = linenode.value.elts
                eltnum = len(elts)
                for i, elt in enumerate(elts):
                    fixstr += fix_line_head
                    # 这里必须使用原始字符串,使用as_string会对原始字符串进行转义,
                    # 从而改变原始字符串内容
                    if node_utils.is_const_type(elt, str):
                        try:
                            fixstr += self.get_fix_const_str(elt, msg)
                        except RuntimeError:
                            return False
                    else:
                        fixstr += elt.as_string()
                    if i < eltnum - 1:
                        fixstr += ","
                    fixstr += os.linesep
                fixstr += line_offset_blanks
                fixstr += "]" if isinstance(linenode.value,
                                            nodes.List) else ')'
                fixstr += os.linesep
                fixrange.replace_with_text(self.formatter, fixstr)
                return True
            if isinstance(linenode.value, nodes.Call):
                return self.fix_call_line_length(
                    linenode.value,
                    line_offset_blanks,
                    msg,
                    max_line_length
                )
            # 赋值常量字符串太长
            if node_utils.is_const_type(linenode.value, str):
                if self.is_cannot_fix_const_node(linenode.value) or self.is_escape_string(linetext):
                    return False
                line_offset_blanks = self.formatter.get_node_col_offset_blanks(linenode.value)
                split_line_texts, remain_line_texts = self.split_line_text(
                    linenode.value.value,
                    max_line_length - self.formatter.get_node_col_offset(linenode.value) - 5,
                    use_re=True
                )
                fixrange = FixRange(line)
                quote_char = self.get_line_str_quote(linenode.value)
                trim_line_text = linetext[0:linenode.value.col_offset] + \
                    "(" + quote_char + ' '.join(split_line_texts) + ' ' + quote_char
                fixrange.replace_line(self.formatter, trim_line_text)
                if remain_line_texts:
                    last_line_text = quote_char + ' '.join(remain_line_texts) + quote_char + ")"
                    fixrange = FixRange(line + 1)
                    fixrange.add_text(
                        self.formatter, line_offset_blanks + last_line_text + os.linesep)
                return True
        if isinstance(linenode, nodes.Expr) and isinstance(linenode.value, nodes.Call):
            return self.fix_call_line_length(
                linenode.value,
                line_offset_blanks,
                msg,
                max_line_length
            )
        if isinstance(linenode.parent, nodes.Call) and linenode in linenode.parent.args:
            if linenode.parent.parent.lineno == linenode.parent.lineno:
                line_offset_blanks = linenode.parent.parent.col_offset * ' '
            else:
                line_offset_blanks = linenode.parent.col_offset * ' '
            return self.fix_call_line_length(
                linenode.parent,
                line_offset_blanks,
                msg,
                max_line_length,
                append_line_end=False
            )
        return False

    def get_fix_const_str(self, const_node, msg):
        const_node_str = ''
        str_quote = self.get_line_str_quote(const_node)
# utils.get_logger().debug(
# const_node.lineno,
# str_quote
        # 字符串被r包裹
        if str_quote == "r":
            const_node_str += "r"
            # 字符串引号在r字符右移1位
            const_node.col_offset += 1
            str_quote = self.get_line_str_quote(const_node)
            const_node.col_offset -= 1
        if str_quote not in ("'", '"'):
            # utils.get_logger().error(
            # const_node.lineno,
            # msg.filepath
            raise RuntimeError(f'fix const str node in line {const_node.lineno} error')
        const_node_str += (str_quote + const_node.value + str_quote)
        return const_node_str

    def has_comment_in_node_lines(self, node):
        '''
        检查节点开始结束行之间是否有注释
        '''
        start_line = node.lineno
        end_line = node.end_lineno
# utils.get_logger().debug(
# node,
# start_line,
# end_line
# if content is None:
        for line in self.formatter.lines[start_line:end_line]:
            if line.strip().startswith('#'):
                # utils.get_logger().info(
                # root_file,
                # start_line + i
                return True
        return False

    def get_line_str_quote(self, node):
        '''
        获取行字符串是用单引号还是双引号裹起来
        '''
        linetext = self.formatter.get_node_line_text(node)
        if linetext is None:
            return '"'
        return linetext[node.col_offset]

    def fix_docstr_position(self, docnode):
        docstr = docnode.value
        doclines = docstr.split(LF)
        quote_char = self.get_line_str_quote(docnode)
        triple_quotes = quote_char * 3
        blanks = ' ' * docnode.col_offset
        fix_doc_str = triple_quotes + os.linesep
        for docline in doclines:
            if docline.strip() == '':
                continue
            fix_docline = blanks + docline.strip() + os.linesep
            fix_doc_str += fix_docline
        fix_doc_str += blanks
        fix_doc_str += triple_quotes
        fixnode = FixNode(docnode, self.formatter)
        fixnode.replace_node_with_text(fix_doc_str)
        return True

    def fix_call_line_length(
        self,
        callnode,
        line_offset_blanks,
        msg,
        max_line_length,
        append_line_end=True
    ):
        '''
        调用语句过长,按调用参数分行减少调用语句长度
        '''
        fixrange = get_node_range(callnode)
        fixstr = callnode.func.as_string() + '('
        if callnode.col_offset + len(fixstr) >= max_line_length:
            return False
        fixstr += os.linesep
        fix_line_head = line_offset_blanks + DEFAULT_TAB_BLANKS
        args = callnode.args
        argnum = len(args)
        key_num = len(callnode.keywords)
        if 0 == argnum and key_num == 0:
            return False
        for i, arg in enumerate(args):
            if self.is_cannot_fix_node(arg):
                return False
            fixstr += fix_line_head
            # 这里必须使用原始字符串,使用as_string会对原始字符串进行转义,
            # 从而改变原始字符串内容
            if node_utils.is_const_type(arg, str):
                try:
                    fixstr += self.get_fix_const_str(arg, msg)
                except RuntimeError:
                    return False
            else:
                fixstr += arg.as_string()
            if len(fix_line_head) + len(arg.as_string()) >= max_line_length:
                return False
            if i < argnum - 1 or key_num > 0:
                fixstr += ","
            fixstr += os.linesep
        for i, keyword in enumerate(callnode.keywords):
            fixstr += fix_line_head
            fixstr += keyword.as_string()
            if i < key_num - 1:
                fixstr += ","
            fixstr += os.linesep
        fixstr += line_offset_blanks
        fixstr += ')'
        if append_line_end:
            fixstr += os.linesep
        fixrange.replace_with_text(self.formatter, fixstr)
        return True

    @staticmethod
    def is_cannot_fix_node(node):
        if node_utils.is_const_type(node, str) and (
            '\n' in node.value or '\r' in node.value or '\t' in node.value
        ):
            return True
        if isinstance(node, nodes.JoinedStr) and node.as_string().find('\\') != -1:
            return True
        return False

    def is_cannot_fix_const_node(self, node):
        if self.is_cannot_fix_node(node):
            return True
        # 多行字符串不能修复
        if node.lineno != node.end_lineno:
            return True
        quote_char = self.get_line_str_quote(node)
        if quote_char == 'r':
            return True
        return False

    @staticmethod
    def is_escape_string(linestr):
        if '\\"' in linestr or "\\'" in linestr:
            return True
        return False
