import re
from astroid import nodes
from ..pylint_fix import PylintFixer
from ..replace import FixNode, FixRange


class PylintW0612Fixer(PylintFixer):
    '''
    规则说明:未使用的变量
    '''

    def __init__(self, formatter):
        super().__init__('W0612', formatter)

    @staticmethod
    def get_node_scope(node):
        parent_node = node
        while parent_node:
            if hasattr(parent_node, 'body') and not isinstance(parent_node, nodes.Tuple):
                return parent_node
            parent_node = parent_node.parent
        return None

    @staticmethod
    def is_parent_one_statement(node):
        parent = node.parent
        if not hasattr(parent, "body"):
            return False
        if isinstance(parent, nodes.FunctionDef):
            if len(parent.body) == 1 and node == parent.body[0]:
                return True
        elif isinstance(parent, nodes.If):
            if len(parent.body) == 1 and node == parent.body[0]:
                return True
            if len(parent.orelse) == 1 and node == parent.orelse[0]:
                return True
        return False

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r"Unused variable '(\w+)' \(unused-variable\)", msg.msg)
        if not node or not res:
            return False
        unused_name = res.groups()[0]
        parent_scope = self.get_node_scope(node)
        if isinstance(parent_scope, nodes.For) and (
            isinstance(parent_scope.iter, nodes.Call) and (
                isinstance(parent_scope.iter.func, nodes.Name) and parent_scope.iter.func.name == "enumerate"
            )
        ):
            loop_index, loop_name = parent_scope.target.elts
            if node != loop_index:
                return False
            assert unused_name == loop_index.as_string()
            fix_func_node = FixNode(parent_scope.iter, self.formatter)
            arg_names = ",".join([arg.as_string() for arg in parent_scope.iter.args])
            fix_func_node.replace_node_with_text(arg_names)
            fix_target_node = FixNode(parent_scope.target, self.formatter)
            fix_target_node.replace_node_with_text(loop_name.as_string())
            return True
        if isinstance(node, nodes.AssignName) and (
            isinstance(node.parent, nodes.ExceptHandler) and node.name == unused_name
        ):
            return self.get_fix_exception(node.parent)
        return False

    def get_fix_exception(self, node):
        fixrange = FixRange(node.lineno)
        fixstr = self.formatter.get_node_col_offset_blanks(node) + 'except %s:' % node.type.as_string()
        fixrange.replace_line(self.formatter, fixstr)
        return True
