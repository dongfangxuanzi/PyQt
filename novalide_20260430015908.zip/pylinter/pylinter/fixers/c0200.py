from astroid import nodes
from ..node_utils import get_node_childs
from ..node_scope import ScopeFinder
from ..pylint_fix import PylintFixer
from ..replace import FixNode


class PylintC0200Fixer(PylintFixer):
    '''
    规则说明:不用使用range(len),使用for xx in enumerate代替
    '''

    def __init__(self, formatter):
        super().__init__('C0200', formatter)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        parent_scope = ScopeFinder.get_parent_node_by_classtype(node, [nodes.For])
        if not node:
            return False
        if isinstance(parent_scope, nodes.For) and isinstance(parent_scope.iter, nodes.Call) and (
            isinstance(parent_scope.iter.func, nodes.Name) and parent_scope.iter.func.name == "range"
        ):
            loop_index = parent_scope.target
            if node != loop_index:
                return False
            fix_call_node = FixNode(parent_scope.iter, self.formatter)
            parent_scope.iter.func.name = 'enumerate'
            first_arg = parent_scope.iter.args[0]
            if isinstance(first_arg, nodes.Call) and (
                isinstance(first_arg.func, nodes.Name) and first_arg.func.name == "len"
            ):
                first_len_arg = first_arg.args[0]
                parent_scope.iter.args[0] = first_len_arg
                fix_call_node.replace_node_with_text(parent_scope.iter.as_string())
                child_nodes = []
                get_node_childs(parent_scope, child_nodes)
                for child in child_nodes:
                    if isinstance(child, nodes.Assign) and isinstance(child.value, nodes.Subscript) and (
                        first_len_arg.as_string() == child.value.value.as_string() and loop_index.name == child.value.slice.name
                    ):
                        fix_target_node = FixNode(parent_scope.target, self.formatter)
                        fix_target_node.replace_node_with_text(
                            f'{loop_index.name},{child.targets[0].name}'
                        )
                        remove_assign_node = FixNode(child, self.formatter)
                        remove_assign_node.replace_node_with_text("")
                        return True
        return False
