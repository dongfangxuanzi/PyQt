import re
from astroid import nodes
from ..replace import get_node_range
from ..pylint_fix import PylintFixer


class PylintW0611Fixer(PylintFixer):
    '''
    规则说明:未被使用的导入模块
    '''

    def __init__(self, formatter):
        super().__init__('W0611', formatter)

    def fix_message(self, msg):
        line = msg.line
        self.load_module(msg.filepath)
        node = self.formatter.find_line_node(line)
        if node is None:
            return False
        if not self.can_delete_node(node):
            utils.get_logger().error("%s node could not be deleted", node.__class__.__name__)
            return False
        asname = None
        if isinstance(node, nodes.Import):
            res = re.search(
                r"Unused import (\w+(.\w+)?) \(unused-import\)", msg.msg)
            if not res:
                res = re.search(
                    r"Unused (.*) imported as (\w+) \(unused-import\)", msg.msg)
                if not res:
                    return False
                import_name, asname = res.groups()
                return self.delete_import_name(node, import_name, asname)
# if import_name == node.names[0][0] and asname == node.names[0][1]:
            import_name = res.groups()[0]
            return self.delete_import_name(node, import_name, asname)
# if import_name in (node.names[0][0], node.names[0][1]):
        if isinstance(node, nodes.ImportFrom):
            res = re.search(
                r"Unused (\w+) imported from (.*) as (.*) \(unused-import\)", msg.msg)
            if res is not None:
                import_name, import_module, asname = res.groups()[0:3]
                if import_module != node.modname:
                    return False
            else:
                res = re.search(
                    r"Unused (\w+) imported from (.*) \(unused-import\)", msg.msg)
                if res is None:
                    res = re.search(
                        r"Unused import (\w+) \(unused-import\)", msg.msg)
                    if not res:
                        return False
                    import_name = res.groups()[0]
                    if node.modname != '':
                        return False
                else:
                    import_name, import_module = res.groups()
                    if import_module != node.modname:
                        return False
            # 检查from xx improt xx节点是否以反斜杆结尾,如果以反斜杆结尾则需要先进行格式化
            # 去掉反斜杆
            if self.is_fromimport_node_endswith_slash(node):
                # utils.get_logger().debug(
                # node,
                # msg.filepath
                # 如果from xx improt xx节点以反斜杆结尾,则先不要修复,而是先进行代码标准化,
                # 去掉反斜杆
                fixrange = get_node_range(node)
                names = [name for (name, asname) in node.names]
                fromimport_modname = node_utils.get_fromimport_modname(node)
                fixstr = "from %s import %s" % (fromimport_modname, ",".join(names))
                fixrange.replace_with_text(textview, fixstr)
                return True
                # if 1 == len(node.names):
            return self.delete_import_name(node, import_name, asname)
        return False

    @staticmethod
    def can_delete_node(node):
        parent_node = node.parent
        if not isinstance(parent_node, nodes.Module) and (
            hasattr(parent_node, 'body') and len(parent_node.body) == 1
        ):
            return False
        return True

    def is_fromimport_node_endswith_slash(self, fromimport_node):
        '''
        检查from xx improt xx节点是否以反斜杆结尾
        '''
# if content is None:
        line_text = self.formatter.lines[fromimport_node.lineno - 1]
        if line_text[-1] == '\\':
            return True
        return False
