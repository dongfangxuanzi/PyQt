import re
from ..pylint_fix import PylintFixer
from ..replace import FixRange


class PylintR0205Fixer(PylintFixer):
    '''
    规则说明:类显式继承object多余
    '''

    def __init__(self, formatter):
        super().__init__('R0205', formatter)

    def fix_message(self, msg):
        line = msg.line
        line_text = self.get_msg_line_text(msg)
        regstr = r'\(\s*object\s*\)'
        if re.search(regstr, line_text):
            fix_range = FixRange(line)
            replace_text = re.sub(regstr, '', line_text)
            fix_range.replace_line(self.formatter, replace_text)
            return True
        return False
