import time
import logging
log = logging.getLogger(__name__)


def compute_run_time(func):
    '''
    统计函数执行时间的装饰函数
    '''
    def wrapped_func(*args, **kwargs):
        start = time.perf_counter()
        ret = func(*args, **kwargs)
        end = time.perf_counter()
        elapse = end - start
        if isinstance(args[0], list):
            log.info("\ntotal elapse %.3f seconds", elapse)
        else:
            log.info("\nelapse %.3f seconds", elapse)
        return ret
    return wrapped_func
