from distutils.core import setup
from setuptools import find_packages


setup(name='pylinter',
      version='1.0',
      description='''fix pylint warnings''',
      author='wukan',
      author_email='wekay102200@sohu.com',
      url='wekay102200@sohu.com',
      license='GPL',
      packages=find_packages(),
      install_requires=[],
      zip_safe=False,
      package_data={},
      data_files=[],
      classifiers=[
          "Development Status :: 4 - Beta",
          "Programming Language :: Python",
          "Topic :: Software Development :: Libraries :: Python Modules",
          "Programming Language :: Python :: Implementation :: CPython",
          "Programming Language :: Python :: Implementation :: PyPy",
          "Programming Language :: Python :: 3.10",
          "Programming Language :: Python :: 3.11"
      ],
      keywords='',
      entry_points="""
        [console_scripts]
        pylinter = pylinter:main
        """
      )
