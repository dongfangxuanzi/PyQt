from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg

class PylintW0401Fixer(PylintFixer):
    '''
    规则说明: 导入语句使用`from module import *`
    '''

    def __init__(self):
        super().__init__('W0401', False)


    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)