from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import get_node_range


class PylintW1514Fixer(PylintFixer):
    '''
    规则说明: open函数参数缺乏encoding参数
    '''

    def __init__(self):
        super().__init__('W1514', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(msg.line)
        if isinstance(node, nodes.ImportFrom):
            class_name = node.modname + "." + node.names[0][0]
            if class_name in self.REPLACE_DEPRECATED_CLASSES:
                replace_class_name = self.REPLACE_DEPRECATED_CLASSES[class_name]
                strs = replace_class_name.split(".")
                fixrange = get_node_range(node)
                replace_modname = ".".join(strs[0:-1])
                fixstr = "from %s import %s" % (replace_modname, strs[-1])
                fixrange.replace_with_text(textview, fixstr)
                return True
        return False
