import abc
import logging
from astroid import nodes
from .node_scope import ScopeFinder
from .replace import get_node_range, FixRange, get_add_range
from .codeutils import FixChoice, get_func_args_range
from .node_utils import ImportNodes
from .exceptions import LineEmptyNodeError, DeleteNodeError, CodeSyntaxError
from .constants import USER_CANCEL_OPTION
from .exceptions import FixfileError, InvalidOptionIndexError
log = logging.getLogger(__name__)


class BaseFixer(abc.ABC):
    """description of class"""
    FIX_MSG_OPTION = FixChoice.FIX_ALL

    def __init__(self, ruleid, toolname, autofix=False):
        self._ruleid = ruleid
        self._toolname = toolname
        self.fix_tool = None
        self._formatter = None
        self._autofix = autofix

    @property
    def autofix(self):
        return self._autofix

    @autofix.setter
    def autofix(self, value):
        self._autofix = value

    @property
    def formatter(self):
        return self._formatter

    @property
    def ruleid(self):
        return self._ruleid

    @property
    def toolname(self):
        return self._toolname

    @classmethod
    def fix_only_autofix(cls):
        '''是否只修复可自动化修复的规则'''
        return cls.FIX_MSG_OPTION == FixChoice.FIX_AUTOFIX

    @abc.abstractmethod
    def fix_message(self, msg):
        raise NotImplementedError('You must implemented it in derived class')

    def set_formatter(self, formatter):
        self._formatter = formatter

    def auto_fix_msg(self, msg):
        if not self.autofix:
            log.warning(
                "rule %s in tool %s could not autofix code message",
                msg.ruleid,
                self.toolname
            )
            return False
        result: bool = self.fix_message(msg)
        assert isinstance(result, bool)
        return result

    def get_msg_line_text(self, msg):
        return self.formatter.get_line_text(msg.line - 1)

    def delete_text_line(self, lineno):
        self.formatter.delete_line(lineno)

    def replace_line_text(self, line, replace_line_text):
        fix_range = FixRange(line)
        fix_range.replace_line(self.formatter, replace_line_text)

    def add_range_text(self, line, col, add_content):
        add_range = get_add_range(line, col)
        add_range.add_text(self._formatter, add_content)

    def get_line_text(self, lineno):
        return self.formatter.get_line_text(lineno)


class BasePythonFixer(BaseFixer):
    ''''''

    @staticmethod
    def is_node_could_deleted(node):
        pnode = node.parent
        if isinstance(pnode, (nodes.If, nodes.For, nodes.While)) and (
            node in pnode.orelse and len(pnode.orelse) == 1
        ):
            return False
        body_nodes = (nodes.If, nodes.ExceptHandler, nodes.Try, nodes.For, nodes.While, nodes.With)
        if isinstance(pnode, body_nodes) and node in pnode.body and len(pnode.body) == 1:
            return False
        if isinstance(pnode, nodes.Try) and node in pnode.finalbody and len(pnode.finalbody) == 1:
            return False
        class_def_nodes = (nodes.ClassDef, nodes.FunctionDef)
        if isinstance(pnode, class_def_nodes) and node in pnode.body and (
            len(pnode.body) == 1 and pnode.doc_node is None
        ):
            return False
        return True

    def find_msg_node(self, msg, *, use_column=False, raise_node_exception=True):
        self.load_msg_module(msg)
        line = msg.line
        scope = ScopeFinder(self.formatter.module).find_scope(line)
        if use_column:
            node = self.formatter.find_line_col_node(line, msg.column, scope)
        else:
            node = self.formatter.find_line_node(line, scope)
        if raise_node_exception and node is None:
            raise LineEmptyNodeError('line %d node is empty' % line)
        return node

    def auto_fix_msg(self, msg):
        try:
            result: bool = super().auto_fix_msg(msg)
        except (LineEmptyNodeError, FixfileError) as ex:
            log.error(
                "fix line %d msg of code file %s error:%s",
                msg.line,
                msg.filepath,
                str(ex)
            )
            return False
        except InvalidOptionIndexError as exp:
            if str(exp) == USER_CANCEL_OPTION:
                return False
        # 告警修复成功,表示文件内容有变动, 需要重新解析并加载语法树
        if result:
            # 重新解析并加载语法树
            self.formatter.parse_module()
            if self.formatter.module is None:
                log.error(
                    'fix rule %s on line %d column %d occur exception.',
                    msg.ruleid,
                    msg.line,
                    msg.column
                )
                self.formatter.dump(filename="d:\\test.py")
                err = f"Fix file {msg.filepath} Error:{self.formatter.syntax_error_msg}"
                raise FixfileError(err)
        return result

    def fix_node_text(self, node, fixstr):
        fixrange = get_node_range(node)
        fixrange.replace_with_text(self.formatter, fixstr)

    def delete_node(self, node, delete_node_line=False, check_deleteable=False):
        if check_deleteable and not self.is_node_could_deleted(node):
            err_msg = 'delete node on line %d error: node cannot to be deleted' % node.lineno
            raise DeleteNodeError(err_msg)
        self.fix_node_text(node, "")
        if delete_node_line:
            self.delete_text_line(node.lineno - 1)
        return True

    def load_module(self, filepath, reload=False):
        if self.formatter.module is None or reload:
            self.formatter.parse_module()
            if self.formatter.module is None:
                err = "file:%s has syntax error:%s" % (filepath, self.formatter.syntax_error_msg)
                raise CodeSyntaxError(err)

    def load_msg_module(self, msg):
        self.load_module(msg.filepath)

    def get_module(self):
        return self.formatter.module

    def find_node_on_line(self, line):
        return self.formatter.find_line_node(line)

    def get_import_nodes_visitor(self):
        return ImportNodes(self.formatter.module, self.formatter)

    def fix_funcdef_args(self, funcnode, argstr):
        arg_node_range = get_func_args_range(funcnode)
        arg_node_range.replace_with_text(
            self.formatter,
            argstr
        )

    def add_node_text(self, node, add_content, end=False):
        node_range = FixRange.node_range(node)
        node_range.add_text(self.formatter, add_content, end)
