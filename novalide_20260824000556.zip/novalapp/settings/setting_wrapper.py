# -*- coding: utf-8 -*-
"""novalide settings"""
import os
import os.path
import json
import logging
from copy import deepcopy
from json import JSONDecodeError
from ..constants import CONFIG_DIR
from .setting_keys import LAST_OPEN_DOCUMENT_KEY, SHELL_TTY_MODE_KEY
from ..common.encodings import UTF8_FILE_ENCODING
from ..lib.pyqt import QDir
from ..util import fileutils
logger = logging.getLogger(__name__)


SETTINGS_DIR = os.path.join(os.path.realpath(QDir.homePath()),
                            CONFIG_DIR) + os.path.sep


_DEFAULT_SETTINGS = {
    # general
    LAST_OPEN_DOCUMENT_KEY: '',
    SHELL_TTY_MODE_KEY: True
}


class SettingsWrapper:
    """Provides settings singleton facility"""

    def __init__(self):
        self.__values = deepcopy(_DEFAULT_SETTINGS)
        # make sure that the directory exists
        if not os.path.exists(SETTINGS_DIR):
            fileutils.makedirs(SETTINGS_DIR)
        # Save the config file name
        self.__full_filename = os.path.join(SETTINGS_DIR, "settings.json")
        # Create file if does not exist
        if not os.path.exists(self.__full_filename):
            # Save to file
            self.flush()
            return
        logger.debug('ide settings filename is %s', self.__full_filename)
        # Load the previous session settings
        try:
            with open(self.__full_filename, "r", encoding=UTF8_FILE_ENCODING) as diskfile:
                disk_values = json.load(diskfile)
        except (OSError, RuntimeError, JSONDecodeError) as exc:
            # Bad error - save default
            logger.error(
                'Could not read setting from %s: %s, Overwriting with the default settings...',
                self.__full_filename,
                str(exc)
            )
            self.flush()
            return
        for item, val in disk_values.items():
            if item in self.__values:
                if not isinstance(self.__values[item], type(val)):
                    self.log_item_type_mismatch(item)
            else:
                logger.warning(
                    'Disk file: %s contains extra key `%s`.',
                    self.__full_filename,
                    item
                )
            self.__values[item] = val

    def __setitem__(self, key, value):
        self.set(key, value)

    def __getitem__(self, key):
        return self.get(key)

    def set(self, key, value, save_to_file=False):
        '''设置key的值'''
        if key in self.__values:
            logger.debug('update key %s in settings file', key)
        else:
            logger.warning('key %s is not exist in settings file', key)
        self.__values[key] = value
        if save_to_file:
            self.flush()

    def get(self, key):
        '''获取已经存在key的值'''
        return self.__values[key]

    def get_default(self, key, default_val):
        '''获取key的值,如果不存在,取默认值'''
        if key in self.__values:
            return self.__values[key]
        return default_val

    def log_item_type_mismatch(self, item):
        logger.warning(
            "Key '%s' type from the disk file %s does not match the expected one,Use default value",
            item,
            self.__full_filename
        )

    def flush(self):
        """Writes the settings to the disk"""
        try:
            with open(self.__full_filename, 'w', encoding=UTF8_FILE_ENCODING) as diskfile:
                json.dump(self.__values, diskfile)
        except (OSError, ValueError, TypeError) as exc:
            logging.error('Error saving setting (to %s): %s',
                          self.__full_filename, str(exc))

    def save(self):
        '''save the settings to file'''
        self.flush()


SETTINGS_SINGLETON = SettingsWrapper()


def settings():
    """Settings singleton access"""
    return SETTINGS_SINGLETON
