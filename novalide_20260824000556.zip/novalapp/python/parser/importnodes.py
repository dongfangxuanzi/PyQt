from astroid import nodes


class ImportsVisitor:
    def __init__(self, module, textview):
        self._module = module
        self._textview = textview

    def is_import_exist(self, modname):
        for child in self._module.body:
            if isinstance(child, nodes.Import):
                names = [name[0] for name in child.names]
                if modname in names:
                    return True
        return False

    def is_fromimport_exist(self, modname, import_name):
        for child in self._module.body:
            if isinstance(child, nodes.ImportFrom):
                if child.modname == modname:
                    return import_name in [name[0] for name in child.names]
        return False

    def get_import_nodes(self):
        '''
        获取模块范围内的所有导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, (nodes.Import, nodes.ImportFrom)):
                import_nodes.append(child)
        return import_nodes

    def get_top_import_nodes(self):
        '''
        获取模块开头的导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, nodes.Assign):
                valid_targets = [
                    isinstance(target, nodes.AssignName)
                    and target.name.startswith("__")
                    and target.name.endswith("__")
                    for target in child.targets
                ]
                if all(valid_targets):
                    continue
            if not isinstance(child, (nodes.Import, nodes.ImportFrom)):
                break
            import_nodes.append(child)
        return import_nodes

    def get_lastimport_node(self, top_imports):
        if top_imports:
            import_nodes = self.get_top_import_nodes()
        else:
            import_nodes = self.get_import_nodes()
        if not import_nodes:
            return None
        return import_nodes[-1]

    def get_import_line(self, top_imports=False):
        last_node = self.get_lastimport_node(top_imports)
        if last_node is not None:
            return last_node.lineno
        if self._module.doc_node is None:
            shebang_or_encoding_line = self._textview.get_shebang_encoding_line()
            return shebang_or_encoding_line
        return self.get_docstring_line()

    def get_docstring_line(self):
        return self._module.doc_node.end_lineno
