# 文本默认编码
ASCII_ENCODING = "ascii"
UTF8_ENCODING = "utf-8"
UTF8_SIG_ENCODING = "utf-8-sig"
ANSI_ENCODING = "cp936"
GBK_ENCODING = "gbk"


def is_utf8(encoding):
    return encoding.find(UTF8_ENCODING) != -1
