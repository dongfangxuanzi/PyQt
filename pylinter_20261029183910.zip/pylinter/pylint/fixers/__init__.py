# v1: pylint规则定制修复器v1版本,对应pylint3.0.3版本
from .w9000 import PylintW9000Fixer
from .w9001 import PylintW9001Fixer
from .w9002 import PylintW9002Fixer
from .w9005 import PylintW9005Fixer
from .w9003 import PylintW9003Fixer
