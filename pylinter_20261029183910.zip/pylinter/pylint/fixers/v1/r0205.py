'''
Name:        r0205.py
Purpose:
Author:      wukan
Created:     2026-10-23
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR0205Fixer(PylintFixer):
    '''
    规则说明:类显式继承object多余
    '''

    def __init__(self):
        super().__init__('R0205', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        res = re.search(
            "Class '(.*)' inherits from object, can be safely removed from bases in python3",
            msg.msg
        )
        classname = res.groups()[0]
        if isinstance(node, nodes.Name) and node.name == classname and isinstance(node.parent, nodes.ClassDef):
            line = msg.line
            regstr = r'\(\s*object\s*\)'
            regstr_2 = r'object\s*,'
            line_text = self.get_msg_line_text(msg)
            if re.search(regstr, line_text):
                replace_text = re.sub(regstr, '', line_text)
                self.replace_line_text(line, replace_text)
                return True
            if re.search(regstr_2, line_text):
                replace_text = re.sub(regstr_2, '', line_text)
                self.replace_line_text(line, replace_text)
                return True
        return False
