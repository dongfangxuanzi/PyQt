from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintW0150Fixer(PylintFixer):
    '''
    规则说明:
    1.finally块里面不能有return语句,会抑制except块里面抛出的异常
    2.循环的finally块里面不能有break语句,会抑制except块里面抛出的异常
    '''

    def __init__(self):
        super().__init__('W0150', self.FixKind.AUTOFIX)

    def fix_return_in_finally(self, node):
        return self.fix_lost_exception(node, nodes.Return)

    def fix_lost_exception(self, node, node_class):
        prev_node = node.previous_sibling()
        if isinstance(node, node_class) and isinstance(node.parent, nodes.Try) and not isinstance(prev_node, nodes.Try):
            try_scope = node.parent
            if not try_scope.handlers and len(try_scope.finalbody) == 1:
                return False
            self.back_text_tab(node.lineno - 1, node.col_offset)
            if len(try_scope.finalbody) == 1 and node in try_scope.finalbody:
                finally_line = self.get_finally_line(node.lineno - 1)
                if finally_line > 1:
                    # 删除finally语句
                    self.delete_text_line(finally_line)
            return True
        return False

    def fix_break_in_finally(self, node):
        return self.fix_lost_exception(node, nodes.Break)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        if msg.msg == 'return statement in finally block may swallow exception (lost-exception)':
            return self.fix_return_in_finally(node)
        if msg.msg == 'break statement in finally block may swallow exception (lost-exception)':
            return self.fix_break_in_finally(node)
        return False


class PylintW0134Fixer(PylintW0150Fixer):
    '''
    规则说明:finally块里面不能有return语句,会抑制except块里面抛出的异常
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'W0134', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        return self.fix_return_in_finally(node)
