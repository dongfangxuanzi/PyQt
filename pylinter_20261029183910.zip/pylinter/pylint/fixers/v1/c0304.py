from ....pylint_fix import PylintFixer


class PylintC0304Fixer(PylintFixer):
    '''
    规则说明:代码文件最后一行没有换行,最后一行不是空白行
    '''

    def __init__(self):
        super().__init__('C0304', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        line = msg.line
        lines_count = self.get_line_count()
        line_text = self.get_line_text(line - 1)
        if line == lines_count and line_text.strip():
            self.add_range_text(line + 1, 0, '')
            return True
        return False


class PylintC0305Fixer(PylintFixer):
    '''
    规则说明:代码文件最后几行是连续空白行,只能最后一行是空白行
    '''

    def __init__(self):
        super().__init__('C0305', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        line = msg.line
        lines_count = self.get_line_count()
        line_text = self.get_line_text(line - 1)
        if line == (lines_count - 1) and not line_text.strip():
            while line > 0:
                self.delete_text_line(line - 1)
                line -= 1
                line_text = self.get_line_text(line - 1)
                if line_text.strip():
                    break
            return True
        return False
