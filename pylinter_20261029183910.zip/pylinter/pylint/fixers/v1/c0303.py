from ....pylint_fix import PylintFixer


class PylintC0303Fixer(PylintFixer):
    '''
    规则说明:代码行以空白字符串结尾
    '''

    def __init__(self):
        super().__init__('C0303', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        return self.do_rstrip_line(msg.line - 1)
