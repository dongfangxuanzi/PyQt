import re
from typing import cast
from astroid import nodes
from ....pylint_fix import PylintFixer
from ....multifixer import MultiOptionFixer


class PylintR6301Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:扩展规则,
    成员方法没有引用类成员,
    可以转换为staticmethod,classmethod或者abstractmethod
    '''

    def __init__(self):
        super().__init__('R6301', self.FixKind.SINGLEFIX)
        MultiOptionFixer.__init__(
            self,
            1,
            'Convert self method',
            'Please choose one method type',
            ['Convert to abstractmethod', 'Convert to staticmethod', 'Convert to classmethod']
        )

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef):
            scope = cast(nodes.FunctionDef, node.parent)
            self.get_selection()
            blanks = scope.position.col_offset * ' '
            if not self._sel:
                visitor = self.get_import_nodes_visitor()
                if visitor.is_import_exist('abc'):
                    self.add_range_text(
                        scope.position.lineno,
                        0,
                        blanks + '@abc.abstractmethod' + '\n'
                    )
                elif visitor.is_fromimport_exist('abc', 'abstractmethod'):
                    self.add_range_text(scope.position.lineno, 0, blanks + "@abstractmethod" + "\n")
                else:
                    insert_line = visitor.get_import_line()
                    self.add_range_text(
                        scope.position.lineno,
                        0,
                        blanks + '@abc.abstractmethod' + '\n'
                    )
                    self.add_range_text(insert_line + 1, 0, "import abc" + "\n")
                return True
            args = scope.args
            argstr = args.as_string()
            if self._sel == 1:
                replace_argstr = re.sub(r"self\s*,*", "", argstr).strip()
                self.fix_funcdef_args(scope, replace_argstr)
                self.add_range_text(scope.position.lineno, 0, blanks + "@staticmethod" + "\n")
            elif self._sel == 2:
                replace_argstr = re.sub(r"self\s*", "cls", argstr).strip()
                self.fix_funcdef_args(scope, replace_argstr)
                self.add_range_text(scope.position.lineno, 0, blanks + "@classmethod" + "\n")
            return True
        return False
