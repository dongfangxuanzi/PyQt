from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintW4901Fixer(PylintFixer):
    '''
    规则说明: 过期的模块
    '''
    REPLACE_DEPRECATED_MODULES = {
        'optparse': 'argparse',
        'xml.etree.cElementTree': 'xml.etree.ElementTree',
        'imp': 'importlib',
        'tkinter.tix': 'tkinter.ttk'
    }

    def __init__(self):
        super().__init__('W4901', self.FixKind.SINGLEFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Import):
            for i, (name, _asname) in enumerate(node.names):
                if name in self.REPLACE_DEPRECATED_MODULES:
                    node.names[i] = (self.REPLACE_DEPRECATED_MODULES[name], _asname)
                    self.fix_node(node)
                    return True
        return False


class PylintW4904Fixer(PylintFixer):
    '''
    规则说明: 过期的类
    '''
    REPLACE_DEPRECATED_CLASSES = {
        "collections.Awaitable": "collections.abc.Awaitable",
        "collections.Coroutine": "collections.abc.Coroutine",
        "collections.AsyncIterable": "collections.abc.AsyncIterable",
        "collections.AsyncIterator": "collections.abc.AsyncIterator",
        "collections.AsyncGenerator": "collections.abc.AsyncGenerator",
        "collections.Hashable": "collections.abc.Hashable",
        "collections.Iterable": "collections.abc.Iterable",
        "collections.Iterator": "collections.abc.Iterator",
        "collections.Generator": "collections.abc.Generator",
        "collections.Reversible": "collections.abc.Reversible",
        "collections.Sized": "collections.abc.Sized",
        "collections.Container": "collections.abc.Container",
        "collections.Callable": "collections.abc.Callable",
        "collections.Collection": "collections.abc.Collection",
        "collections.Set": "collections.abc.Set",
        "collections.MutableSet": "collections.abc.MutableSet",
        "collections.Mapping": "collections.abc.Mapping",
        "collections.MutableMapping": "collections.abc.MutableMapping",
        "collections.MappingView": "collections.abc.MappingView",
        "collections.KeysView": "collections.abc.KeysView",
        "collections.ItemsView": "collections.abc.ItemsView",
        "collections.ValuesView": "collections.abc.ValuesView",
        "collections.Sequence": "collections.abc.Sequence",
        "collections.MutableSequence": "collections.abc.MutableSequence",
        "collections.ByteString": "collections.abc.ByteString",
        "importlib.abc.Finder": "importlib.Finder"
    }

    def __init__(self):
        super().__init__('W4904', self.FixKind.SINGLEFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.ImportFrom):
            class_name = node.modname + "." + node.names[0][0]
            if class_name in self.REPLACE_DEPRECATED_CLASSES:
                replace_class_name = self.REPLACE_DEPRECATED_CLASSES[class_name]
                replace_modname = ".".join(replace_class_name.split('.')[0:-1])
                node.modname = replace_modname
                self.fix_node(node)
                return True
        return False
