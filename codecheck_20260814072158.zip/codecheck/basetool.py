import logging
import os
import subprocess
import abc
import json
from novalapp.executable import Executable
from novalapp.syntax.syntax import SyntaxThemeManager
from novalapp.util import strutils
from novalapp.util import utils
from novalapp.util import fileutils
from novalapp.common.md5 import get_str_md5
from novalapp.python.interpreter.interpreter import BuiltinPythonInterpreter
from novalapp.python.project.configuration import ProjectConfiguration
from novalapp.python import pythonenv
from novalapp.python.interpreter.exceptions import InterpreterSyntaxError
from novalapp.common.configparser import ConfigWriter, ConfigReader
from novalapp.syntax import lang
from .pkgres import get_rule_options_path
from .strings import CODECHECK_TOOL_NANE
from . import configkeys

logger = logging.getLogger(__name__)


class BaseCheckTool(abc.ABC):
    """description of class"""
    PLAIN_TEXT_FORMAT = 1
    JSON_OUTPUT_FORMAT = 2

    def __init__(self, name, lang_id, path='', command='', is_format_tool=False):
        self._name = name
        self._lang_id = lang_id
        self._path = path
        self._enabled = True
        self.exts = SyntaxThemeManager.manager().GetLexer(self._lang_id).Exts
        self._command = command
        self._command_args = []
        self._output_format = self.PLAIN_TEXT_FORMAT
        self._version = BuiltinPythonInterpreter.UNKNOWN_VERSION_NAME
        self._enable_rules = []
        # 定制规则修复器列表
        self._fixers = []
        # 通用静态规则修复器列表
        self._sarif_fixers = []
        self._cfg_file_path = None
        self._is_format_tool = is_format_tool

    @property
    def is_format_tool(self):
        return self._is_format_tool

    @property
    def cfg_file_path(self):
        return self._cfg_file_path

    @property
    def lang_id(self):
        return self._lang_id

    @property
    def fixers(self):
        return self._fixers

    @property
    def sarif_fixers(self):
        return self._sarif_fixers

    @property
    def enable_rules(self):
        return self._enable_rules

    @property
    def version(self):
        return self._version

    @property
    def output_format(self):
        return self._output_format

    @property
    def command_args(self):
        return self._command_args

    @command_args.setter
    def command_args(self, args):
        self._command_args = args

    @property
    def command(self):
        return self._command

    @property
    def name(self):
        return self._name

    @property
    def enabled(self):
        return self._enabled

    @enabled.setter
    def enabled(self, value):
        self._enabled = value

    @property
    def path(self):
        return self._path

    @staticmethod
    def use_doc_workpath(doc):
        return utils.profile_get_int(doc.GetKey(configkeys.CODECHECK_WORKDIR_PROJECT_KEY), True)

    @classmethod
    def get_work_path(cls, doc):
        workpath = None
        if cls.use_doc_workpath(doc):
            workpath = doc.GetPath()
        else:
            app_path = utils.get_app_path()
            # python代码检测工具启动工作目录为None时,默认为程序当前路径
            # 程序当前路径为程序安装路径,程序安装路径下的解释器环境会和代码检测工具的解释器环境会有冲突,
            # 所以必须改变工作目录
            if fileutils.ComparePath(os.getcwd(), app_path):
                workpath = os.path.dirname(app_path)
        return workpath

    def find_in_fixers(self, rule_id, fixers: list):
        for fixer in fixers:
            if fixer.ruleid == rule_id and fixer.toolname == self.name:
                return fixer
        return None

    def get_key_section(self, key):
        self.check_cofig_file()
        cfg_reader = ConfigReader(self._cfg_file_path)
        sections = cfg_reader.sections()
        for section in sections:
            if cfg_reader.has_option_key(section, key):
                return section
        return None

    def get_key_sections(self, key):
        self.check_cofig_file()
        cfg_reader = ConfigReader(self._cfg_file_path)
        sections = cfg_reader.sections()
        for section in sections:
            if cfg_reader.has_option_key(section, key):
                return section, sections
        return None, sections

    def write_key_value(self, key, value):
        section = self.get_key_section(key)
        self.write_key_section_value(section, key, value)

    def write_key_section_value(self, section, key, value):
        self.check_cofig_file()
        # space_around_delimiters为False,表示配置文件等于号前后没有空格
        cfg_writer = ConfigWriter(
            self._cfg_file_path, space_around_delimiters=False)
        cfg_writer.write_cofig(section, key, value)

    def is_cfg_key_value_changed(self, section, key, value):
        self.check_cofig_file()
        cfg_reader = ConfigReader(self._cfg_file_path)
        key_value = cfg_reader.get_config(section, key)
        if key_value == value:
            return False
        return True

    def get_section_key_value(self, section, key):
        self.check_cofig_file()
        cfg_reader = ConfigReader(self._cfg_file_path)
        key_value = cfg_reader.get_config(section, key)
        return key_value

    def get_key_value(self, key):
        section = self.get_key_section(key)
        return self.get_section_key_value(section, key)

    def update_cfg_file(self, cfg_file_path):
        self._cfg_file_path = cfg_file_path

    def check_cofig_file(self):
        if self._cfg_file_path is None:
            raise RuntimeError('tool %s has no config file path' % self.name)
        if not os.path.exists(self._cfg_file_path):
            raise RuntimeError('tool %s config file path %s is not exist' % (self.name, self._cfg_file_path))

    def is_filetool_enabled(self, filepath):
        is_file_contained = self.contain_file_extension(filepath)
        if not is_file_contained:
            utils.get_logger().warning(
                "file %s is not a valid file extension of tool %s", filepath, self.name)
        return self.enabled and is_file_contained

    def parse_file(self, doc, filepath):
        '''
        调用某个代码检测工具检测项目文件告警
        '''
        return self.parse_syntax_file(doc, filepath)

    def parse_syntax_file(self, doc, filepath):
        '''
        调用具体的可执行工具路径和命令参数,生成规则告警信息文件
        '''
        command = self._command
        command += " "
        command += strutils.emphasis_path(filepath)
        utils.get_logger().debug('tool %s run command is %s', self.name, command)
        return self.run_command(doc, command, filepath)

    def get_file_log_path(self, doc, filepath):
        data_out_path = self.get_cache_path(doc)
        file_log_name = get_str_md5(filepath)
        log_file_path = os.path.join(data_out_path, f"{file_log_name}.log")
        return log_file_path

    def update_enable_rules(self, rules):
        self._enable_rules = rules

    def contain_file_extension(self, filepath):
        ext = strutils.get_file_extension(filepath)
        return ext in self.exts

    def run_command(self, doc, command, filepath):
        if utils.is_windows():
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
        else:
            startupinfo = None
        log_file_path = self.get_file_log_path(doc, filepath)
        data_out_path = os.path.dirname(log_file_path)
        fileutils.makedirs(data_out_path)
        utils.get_logger().debug('file %s checktool %s log path is %s',
                                 filepath, self.name, log_file_path)
        stdout_log = open(log_file_path, "w")
        stderr_log = open(log_file_path, "a")
        workpath = self.get_work_path(doc)
        process_obj = subprocess.Popen(
            command,
            shell=True,
            startupinfo=startupinfo,
            cwd=workpath,
            stdout=stdout_log,
            stderr=stderr_log,
            env=self.get_env(doc)
        )
        process_obj.wait()
        utils.get_logger().debug("tool %s exec command %s returncode is %d",
                                 self.name, command, process_obj.returncode)
        return log_file_path

    def get_cache_path(self, doc):
        dock_cache_path = doc.get_doc_cache_path()
        return os.path.join(dock_cache_path, CODECHECK_TOOL_NANE, self.name)

    def parse_line_msg(self, linetext):
        raise NotImplementedError('You must implemented it in derived class')

    def add_fixer(self, fixer):
        ruleid = fixer.ruleid
        if not strutils.is_none_empty(ruleid) and self.find_in_fixers(ruleid, self._fixers):
            raise RuntimeError(f'rule id: {ruleid} is already in custom fixers of tool {fixer.toolname}')
        assert fixer.toolname == self.name
        fixer.check_tool = self
        self._fixers.append(fixer)

    def add_sarif_fixer(self, fixer):
        ruleid = fixer.ruleid
        if not strutils.is_none_empty(ruleid) and self.find_in_fixers(ruleid, self._sarif_fixers):
            raise RuntimeError(f'rule id: {ruleid} is already in sarif fixers of tool {fixer.toolname}')
        assert fixer.toolname == self.name
        fixer.check_tool = self
        self._sarif_fixers.append(fixer)

    def is_rule_fixable(self, rule_id):
        return self.find_in_fixers(rule_id, self._fixers) or self.find_in_fixers(rule_id, self._sarif_fixers)

    def get_tool_rule_option(self, rule):
        tool_options_file = get_rule_options_path()
        logger.debug('tool options filepath is %s', tool_options_file)
        tool_options = []
        with open(tool_options_file) as f:
            tool_options = json.load(f)
        for tool_option in tool_options:
            if tool_option['tool'] == self.name:
                options = tool_option['options']
                for option in options:
                    if option['rule'] == rule:
                        return option
        return {}

    def find_fixer(self, rule_id):
        # 先从定制规则列表中查找修复器,如果找到则直接返回
        fixer = self.find_in_fixers(rule_id, self._fixers)
        if not fixer:
            # 如果未找到,则从sarif静态修复列表中去查找
            fixer = self.find_in_fixers(rule_id, self._sarif_fixers)
        return fixer

    def find_fixers(self, rule_id):
        '''
        从定制规则列表中和sarif静态修复列表中查找多个规则修复器
        '''
        fixers = []
        fixer = self.find_in_fixers(rule_id, self._fixers)
        if fixer:
            fixers.append(fixer)
        sarif_fixer = self.find_in_fixers(rule_id, self._sarif_fixers)
        if sarif_fixer:
            fixers.append(sarif_fixer)
        return fixers

    def fix_file(self, processor, doc, filepath):
        return False

    @abc.abstractmethod
    def build_version(self):
        raise NotImplementedError('You must implemented it in derived class')

    def get_env(self, doc):
        return None


class BasePythonCheckTool(BaseCheckTool):

    def __init__(self, name, interpreter=None, is_format_tool=False):
        super().__init__(name, lang.ID_LANG_PYTHON, is_format_tool=is_format_tool)
        self._interpreter = interpreter
        if self._interpreter is not None:
            self.update(self._interpreter)

    @property
    def interpreter(self):
        return self._interpreter

    def get_version_output(self):
        args = ["-m", self.name, "--version"]
        exectable = Executable(self._interpreter.path)
        exectable_path = fileutils.get_filepath_from_path(
            self._interpreter.path)
        output = exectable.exec_command_output(args, cwd=exectable_path)
        return output

    def update_command(self):
        if self._interpreter is None:
            return
        exectable = Executable(self._interpreter.path, args=[
                               "-m", self.name] + self.command_args)
        command = exectable.get_cmd()
        logger.info('tool %s codecheck command is %s', self.name, command)
        self._command = command

    def update(self, interpreter):
        self._interpreter = interpreter
        self.enabled = utils.profile_get_int(
            "%s%s" % (self.name, configkeys.TOOL_STATUS_KEY), True)
        if not self.enabled:
            return
        toolpath = self._interpreter.find_tool(self.name)
        logger.info('find tool %s path is %s', self.name, toolpath)
        self.update_command()
        self._path = toolpath
        self.build_version()

    def get_env(self, doc):
        '''
        将项目配置的其它路径作为PYTHONPATH环境变量,以便在代码检测时找到导入外部模块
        '''
        env = os.environ.copy()
        project_configuration = ProjectConfiguration(doc)
        python_path_list = project_configuration.LoadPythonPath()
        env_python_path_list = python_path_list + self._interpreter.python_path_list
        env[pythonenv.PYTHON_PATH_NAME] = os.pathsep.join(env_python_path_list)
        return env

    def check_file_syntax(self, filepath):
        try:
            ok, errorfile, _lineno, msg = self._interpreter.check_syntax(
                filepath)
            if errorfile == "":
                errorfile = filepath
            if not ok:
                utils.get_logger().error("check fix file %s syntax error:%s", errorfile, msg)
                raise InterpreterSyntaxError(msg)
        except ValueError as ex:
            utils.get_logger().error("check file %s syntax error:%s", filepath, str(ex))
            ok = False
        return ok
