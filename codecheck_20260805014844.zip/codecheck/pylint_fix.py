import re
import base64
import os
import astroid
from astroid import AstroidSyntaxError
from astroid import nodes
from novalapp import get_app, _
from novalapp.widgets import simpledialog
from novalapp.lib.pyqt import QMessageBox
from novalapp.project import command as projectcommand
from novalapp.util import fileutils, strutils, utils
from novalapp import constants
from novalapp.python.parser.define import SELF_ARG_NAME, CLASS_INIT_METHOD
from .strings import PYLINT_TOOL_NAME, COMMON_PYLINT_MESSAGE_ID
from .codeutils import (
    get_node_range,
    ImportNodes,
    FixNode,
    get_node_line_text,
    get_node_col_offset_blanks,
    FixRange,
    get_scope_range
)
from . import configkeys
from .basefix import BasePythonFixer, fix_code_file_msg
from .sarif_loader import SarifLoader


class PylintFixer(BasePythonFixer):

    SINGLE_TRIPLE_QUOTE = "'''"
    DOUBLE_TRIPLE_QUOTE = '"""'
    DOUBLE_QUOTE = '"'
    SINGLE_QUOTE = "'"

    def __init__(self, ruleid, autofix=False, open_file=True):
        super().__init__(ruleid, PYLINT_TOOL_NAME, autofix, open_file)

    @staticmethod
    def is_node_could_deleted(node):
        pnode = node.parent
        if isinstance(pnode, nodes.If) and node in pnode.orelse and len(pnode.orelse) == 1:
            return False
        body_nodes = (nodes.If, nodes.ExceptHandler, nodes.Try)
        if isinstance(pnode, body_nodes) and node in pnode.body and len(pnode.body) == 1:
            return False
        if isinstance(pnode, nodes.Try) and node in pnode.finalbody and len(pnode.finalbody) == 1:
            return False
        class_def_nodes = (nodes.ClassDef, nodes.FunctionDef)
        if isinstance(pnode, class_def_nodes) and node in pnode.body and (
            len(pnode.body) == 1 and pnode.doc_node is None
        ):
            return False
        return True

    @staticmethod
    def is_init_call_node(node):
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call) and (
            isinstance(node.value.func, nodes.Attribute)
        ) and node.value.func.attrname == CLASS_INIT_METHOD:
            return True
        return False

    @staticmethod
    def extract_node_with_text(nodetext):
        try:
            node = astroid.extract_node(nodetext)
            return node
        except AstroidSyntaxError as ex:
            utils.get_logger().error(str(ex))
        return None

    @staticmethod
    def fix_exception_name(node, textview, asname):
        '''
        except Exception as xxx
        xxx节点是多行节点,不能用as_string,只能修改行内容
        '''
        fixrange = FixRange(node.lineno)
        offset_blanks = get_node_col_offset_blanks(node)
        fixstr = offset_blanks + 'except %s as %s:' % (node.type.as_string(), asname)
        fixrange.replace_line(textview, fixstr)

    @staticmethod
    def replace_module_name(doc, oldpath, new_module_name):
        ext = strutils.get_file_extension(oldpath, keepdot=True)
        newname = os.path.join(
            fileutils.get_filepath_from_path(oldpath), new_module_name)
        newfilepath = strutils.MakeNameEndInExtension(newname, ext)
        ret = doc.GetCommandProcessor().Submit(
            projectcommand.ProjectRenameFileCommand(doc, oldpath, newfilepath)
        )
        if ret:
            doc.Save()
        return ret

    @staticmethod
    def get_line_str_quote(node):
        '''
        获取行字符串是用单引号还是双引号裹起来
        '''
        linetext = get_node_line_text(node)
        if linetext is None:
            return '"'
        return linetext[node.col_offset]

    @classmethod
    def delete_import_name(cls, node, import_name, textview):
        if not cls.is_node_could_deleted(node):
            utils.get_logger().error("%s node could not be deleted", node.__class__.__name__)
            return False
        for i, (name, asname) in enumerate(node.names):
            if import_name in (name, asname):
                del node.names[i]
                break
        else:
            return False
        if not node.names:
            fixrange = get_node_range(node)
            fixrange.replace_with_text(textview, '')
        else:
            fixrange = get_node_range(node)
            fixrange.replace_with_text(textview, node.as_string())
        return True

    @classmethod
    def replace_variable_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.Name, nodes.AssignName)) and child.name == name:
                if isinstance(child.parent, nodes.ExceptHandler):
                    cls.fix_exception_name(child.parent, textview, newname)
                else:
                    fix_range = get_node_range(child)
                    fix_range.replace_with_text(textview, newname)
            else:
                cls.replace_variable_name_in_scope(
                    textview, child, name, newname)

    @classmethod
    def replace_method_name_in_scope(
        cls,
        textview,
        scope,
        methodname,
        new_methodname,
        is_class_method,
        classname
    ):
        childs = list(textview.ModuleAnalyzer.iter_scope_children(scope))
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, nodes.Name) and (
                isinstance(child.parent, nodes.FunctionDef) and child.name == methodname
            ):
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, new_methodname)
            elif isinstance(child, nodes.Attribute) and child.attrname == methodname:
                if is_class_method:
                    if isinstance(child.expr, nodes.Name):
                        if child.expr.name == 'cls':
                            fix_range = get_node_range(child)
                            fix_range.replace_with_text(textview, "cls." + new_methodname)
                            continue
                        elif child.expr.name == classname:
                            fix_range = get_node_range(child)
                            fix_range.replace_with_text(textview, f"{classname}." + new_methodname)
                            continue
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, f"{SELF_ARG_NAME}." + new_methodname)
            else:
                cls.replace_method_name_in_scope(
                    textview, child, methodname, new_methodname, is_class_method, classname)

    @classmethod
    def replace_attribute_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.AssignAttr, nodes.Attribute)) and child.attrname == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, f"{SELF_ARG_NAME}." + newname)
            else:
                cls.replace_attribute_name_in_scope(
                    textview, child, name, newname)

    @classmethod
    def get_line_str_r_quote(cls, node):
        '''
        获取行字符串是否被r包裹起来,如果有r,获取r后面的引号字符
        '''
        str_quote = cls.get_line_str_quote(node)
        utils.get_logger().debug(
            "str quote of line %d is %s",
            node.lineno,
            str_quote
        )
        # 字符串被r包裹
        if str_quote == "r":
            # 字符串引号在r字符右移1位
            node.col_offset += 1
            str_quote = cls.get_line_str_quote(node)
            node.col_offset -= 1
            return True, str_quote
        return False, str_quote

    @classmethod
    def fix_docstr_position(cls, textview, docnode):
        docstr = docnode.value
        is_r_quote, quote_char = cls.get_line_str_r_quote(docnode)
        if quote_char not in [cls.DOUBLE_QUOTE, cls.SINGLE_QUOTE]:
            utils.get_logger().error("doc node on line %s has not quote char", docnode.lineno)
            return False
        triple_quotes = quote_char * 3
        if is_r_quote:
            start_triple_quotes = 'r' + triple_quotes
        else:
            if docstr.find('\\') != -1:
                docstr = docstr.replace('\\', '\\\\')
            start_triple_quotes = triple_quotes
        if docnode.lineno == docnode.end_lineno:
            if docstr.strip() == docstr:
                return False
            fixnode = FixNode(docnode, textview)
            fixnode.replace_node_with_text(start_triple_quotes + docstr.strip() + triple_quotes)
            return True
        doclines = docstr.split(constants.LF)
        blanks = get_node_col_offset_blanks(docnode)
        fix_doc_str = start_triple_quotes + constants.LF
        for docline in doclines:
            trim_docline = docline.strip()
            if trim_docline == '':
                continue
            fix_docline = blanks + trim_docline + constants.LF
            fix_doc_str += fix_docline
        fix_doc_str += blanks
        fix_doc_str += triple_quotes
        if fix_doc_str == (start_triple_quotes + constants.LF.join(doclines) + triple_quotes):
            return False
        fixnode = FixNode(docnode, textview)
        fixnode.replace_node_with_text(fix_doc_str)
        return True

    @classmethod
    def get_function_scope_range(cls, textctrl, scope):
        scope_range = get_scope_range(scope)
        # 包含函数上方的注释行
        top_comment_lines = cls.get_function_top_comment_lines(textctrl, scope)
        if top_comment_lines:
            scope_range.start_line = top_comment_lines[-1]
        return scope_range


class SarifFixer(PylintFixer):
    '''
    通用sarif格式修复器
    '''

    def __init__(self, ruleid, autofix=False, open_file=True):
        PylintFixer.__init__(self, ruleid, autofix, open_file)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        if self.check_tool.output_format != self.check_tool.JSON_OUTPUT_FORMAT:
            return False
        fix_options = msg.fixers
        if not fix_options:
            return False
        if len(fix_options) > 1 and not self.is_autofix_msg:
            choices = [fix_option['description']['text'] for fix_option in fix_options]
            sel = simpledialog.asklist(
                "Fix code",
                "Please choose one fixer option",
                choices,
                selection=0,
                master=text_ctrl
            )
            if sel == -1:
                return False
        else:
            # sarif自动修复有多个修复选项时默认选第一个作为修复方案
            sel = 0
        fix_option = fix_options[sel]
        chan = fix_option['artifactChanges'][0]
        fixuri = chan['artifactLocation']['uri']
        fixpath = SarifLoader.uri_to_path(fixuri)
        if not fileutils.ComparePath(msg.filepath, fixpath):
            textview = get_app().GotoView(
                fixpath,
                lineNum=msg.line,
                colno=msg.column,
                trace_track=False
            )
            if not textview:
                return False
            text_ctrl = textview.GetCtrl()
        replacements = chan['replacements']
        title = fix_option['description']['text']
        if not self.check_input_replacements(title, text_ctrl, replacements):
            return False
        if textview.IsModified() and not self.is_autofix_msg:
            QMessageBox.critical(text_ctrl, _('Error'), _(
                'Please save your file before fix warnings'))
            return False
        for replacement in replacements:
            if "deletedRegion" in replacement:
                deleted_region = replacement["deletedRegion"]
                if 'byteOffset' in deleted_region:
                    base64_text = bytearray(
                        replacement["insertedContent"]['binary'], encoding="ascii")
                    inserted_content = base64.b64decode(base64_text)
                    byte_offset = deleted_region['byteOffset']
                    byte_len = deleted_region['byteLength']
                    newbytes = b''
                    with open(fixpath, "rb") as fp:
                        byte_content = fp.read()
                        newbytes = byte_content[0:byte_offset] + bytearray(
                            inserted_content) + byte_content[byte_offset + byte_len:]
                    with open(fixpath, "wb") as fw:
                        fw.write(newbytes)
                elif 'charOffset' in deleted_region:
                    char_offset = deleted_region['charOffset']
                    char_len = deleted_region['charLength']
                    inserted_content = replacement["insertedContent"]["text"]
                    if char_len == 0:
                        text_ctrl.insert_text(char_offset, inserted_content)
                    else:
                        content = text_ctrl._encodeString(text_ctrl.text())
                        chars = content[char_offset:char_offset + char_len]
                        textview.set_region(char_offset, char_offset + char_len, chars,
                                            inserted_content.split("\n"), selrep=False)
                else:
                    start_line = deleted_region["startLine"] - 1
                    start_column = deleted_region["startColumn"] - 1
                    end_column = deleted_region["endColumn"] - 1
                    end_line = deleted_region["endLine"] - 1
                    inserted_content = replacement["insertedContent"]["text"]
                    if start_line == end_line and start_column == end_column:
                        insert_pos = text_ctrl.position_from_linecol(
                            start_line, start_column)
                        text_ctrl.insert_text(insert_pos, inserted_content)
                    else:
                        head, tail, chars, _lines = textview.get_region(
                            start_line, start_column, end_line, end_column)
                        textview.set_region(head, tail, chars,
                                            inserted_content.split("\n"), selrep=False)
            elif "newModule" in replacement:
                replacement_content = replacement["newModule"]
                new_module_name = replacement_content['text']
                oldfilepath = fixpath
                return self.replace_module_name(doc, oldfilepath, new_module_name)

        return True

    def check_input_replacements(
        self,
        title,
        text_ctrl,
        replacements,
        initialvalue=''
    ):
        def parse_arg_text(text):
            res = re.search("'(.*)'", text)
            return res.groups()[0]

        replacement = replacements[0]
        replacement_content = {}
        if "insertedContent" in replacement:
            replacement_content = replacement["insertedContent"]
        elif "newModule" in replacement:
            replacement_content = replacement["newModule"]
        else:
            assert False
        replace_txt = replacement_content.get("text", None)
        if replace_txt is None:
            return True
        res = re.search(r"\$input\((.*)\)", replace_txt)
        if res:
            args_text = res.groups()[0]
            args = re.split(r',\s*', args_text)
            input_prompt_text = parse_arg_text(args[0])
            default_ret = ''
            if len(args) == 3:
                initialvalue = parse_arg_text(args[1])
                default_ret = parse_arg_text(args[2])
            elif len(args) == 2:
                initialvalue = parse_arg_text(args[1])
            if self.is_autofix_msg:
                newname = default_ret
                ok = len(newname) > 0
            else:
                ok, newname = simpledialog.askstring(
                    title,
                    input_prompt_text,
                    initialvalue=initialvalue,
                    master=text_ctrl
                )
            if not ok:
                return False
            for replacement in replacements:
                replacement_content = {}
                if "insertedContent" in replacement:
                    replacement_content = replacement["insertedContent"]
                elif "newModule" in replacement:
                    replacement_content = replacement["newModule"]
                else:
                    assert False
                replacement_content["text"] = newname
        return True


class PylintCommonFixer(PylintFixer):
    '''
    修复pylint告警之外的一些常见问题
    '''

    def __init__(self):
        PylintFixer.__init__(self, COMMON_PYLINT_MESSAGE_ID, True, True)

    @classmethod
    def format_doc_str(cls, textview):
        '''
        格式化(模块/类/函数/方法)的文档字符串,对齐边界,保持整齐好看的排列方式
        '''
        module = textview.ModuleAnalyzer.Module
        if module is None:
            return False
        fix_docs = 0
        fix_docnodes = []
        cls.get_fix_docnodes(module, fix_docnodes)
        fix_docnodes.append(module.doc_node)
        for docnode in fix_docnodes:
            fix_docs += cls.fix_doc_node(docnode, textview)
        utils.get_logger().debug('fix docstr nodes count is %d', fix_docs)
        return fix_docs > 0

    @classmethod
    def get_fix_docnodes(cls, scope, doc_nodes: list):
        for bodynode in scope.body[::-1]:
            if isinstance(bodynode, nodes.FunctionDef):
                for child in bodynode.body[::-1]:
                    if isinstance(child, nodes.FunctionDef):
                        doc_nodes.append(child.doc_node)
                doc_nodes.append(bodynode.doc_node)
            elif isinstance(bodynode, nodes.ClassDef):
                for child in bodynode.body[::-1]:
                    if isinstance(child, nodes.FunctionDef):
                        doc_nodes.append(child.doc_node)
                    elif hasattr(child, 'body'):
                        cls.get_fix_docnodes(child, doc_nodes)
                doc_nodes.append(bodynode.doc_node)
            elif hasattr(bodynode, 'body'):
                cls.get_fix_docnodes(bodynode, doc_nodes)

    @classmethod
    def fix_doc_node(cls, docnode, textview):
        if docnode is None:
            return 0
        return int(cls.fix_docstr_position(textview, docnode))

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        try:
            self.load_module(textview, msg.filepath, reload=True)
        except RuntimeError as ex:
            utils.get_logger().error(str(ex))
            return False
        ret = False
        if utils.profile_get_int(configkeys.FORMAT_DOCSTR_KEY, False):
            suc = self.format_doc_str(textview)
            if suc:
                ret = suc
                self.load_module(textview, msg.filepath, reload=True)
        if self.fix_module_imports_blank_line(textview, textctrl):
            ret = True
            self.load_module(textview, msg.filepath, reload=True)
        if utils.profile_get_int(configkeys.REMOVE_PRINT_STATEMENT_KEY, False):
            rem_suc = self.remove_print_statements(textview, textctrl)
            if rem_suc:
                ret = rem_suc
                try:
                    self.load_module(textview, msg.filepath, reload=True)
                except RuntimeError as ex:
                    utils.get_logger().error("remove print statements error:%s", str(ex))
        if utils.profile_get_int(configkeys.CONVERT_TABS_SPACES_KEY, False):
            suc = self.convert_tabs_to_spaces(textview, textctrl)
            if suc:
                ret = suc
        return ret

    def fix_module_imports_blank_line(self, textview, textctrl):
        '''
        清除导入语句之间的空行
        '''
        importutils = ImportNodes(textview.ModuleAnalyzer.Module, textview)
        top_import_nodes = importutils.get_top_import_nodes()
        if not top_import_nodes:
            return False
        start_line = top_import_nodes[0].lineno
        end_line = top_import_nodes[-1].lineno
        del_lines = []
        for i in range(start_line - 1, end_line):
            line_text = textctrl.get_line_text(i)
            if line_text.strip() == '':
                del_lines.append(i)
        if not del_lines:
            return False
        del_lines.sort(reverse=True)
        for del_line_index in del_lines:
            textview.delete_line(del_line_index)
        return True

    def remove_print_statements(self, textview, textctrl):
        line_count = textctrl.get_line_count()
        remove_print_nodes = []
        for i in range(line_count):
            node = textview.ModuleAnalyzer.find_line_node(i + 1)
            if node is None:
                line_text = textctrl.get_line_text(i)
                utils.get_logger().error(
                    'could not find ast node on line %d with line text `%s`',
                    i + 1,
                    line_text
                )
                continue
            if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call) and (
                isinstance(node.value.func, nodes.Name) and node.value.func.name == "print"
            ):
                remove_print_nodes.append(node)
        if not remove_print_nodes:
            return False
        remove_print_nodes.sort(key=lambda x: x.lineno, reverse=True)
        for printnode in remove_print_nodes:
            rm_node = FixNode(printnode, textview)
            rm_node.replace_node_with_text('')
            textview.delete_line(printnode.lineno - 1)
        return True

    def convert_tabs_to_spaces(self, textview, textctrl):
        '''
        检查文本是否包含制表符, 并替换制表符为4个空格
        '''
        chars = textctrl.text()
        tab_count = chars.count("\t")
        if tab_count == 0:
            return False
        newchars = textview.expandtabs(chars)
        textctrl.clearall()
        textctrl.insert_text(0, newchars)
        return True
