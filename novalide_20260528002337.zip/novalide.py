# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        novalide.py
Purpose:     程序主入口文件
Author:      wukan
Created:     2019-01-08
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import sys
import logging
from novalapp.launcher import run
from novalapp import prog_lang

log = logging.getLogger(__name__)

# 设置软件运行的语言,默认为Python
if __name__ == "__main__":
    ret = run(prog_lang.LANGUAGE_DEFAULT)
    log.info('application exit code is %d', ret)
    sys.exit(ret)
