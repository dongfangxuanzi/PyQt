

def ensure_bytes(s, encoding='utf-8', errors='strict'):
    '''
    The error handling scheme to use for encoding errors.
    The default is 'strict' meaning that encoding errors raise a
    UnicodeEncodeError.  Other possible values are 'ignore', 'replace' and
    'xmlcharrefreplace' as well as any other name registered with
    codecs.register_error that can handle UnicodeEncodeErrors.
    '''
    if isinstance(s, str):
        return bytes(s, encoding=encoding, errors=errors)
    if isinstance(s, bytes):
        return s
    if isinstance(s, bytearray):
        return bytes(s)
    raise ValueError(
        "Expected str or bytes or bytearray, received %s." %
        type(s))


def ensure_string(s, encoding='utf-8', errors='strict'):
    '''
    The error handling scheme to use for the handling of decoding errors.
    The default is 'strict' meaning that decoding errors raise a
    UnicodeDecodeError. Other possible values are 'ignore' and 'replace'
    as well as any other name registered with codecs.register_error that
    can handle UnicodeDecodeErrors.
    '''
    if isinstance(s, str):
        return s
    if isinstance(s, (bytes, bytearray)):
        return str(s, encoding=encoding, errors=errors)
    raise ValueError(
        "Expected str or bytes or bytearray, received %s." %
        type(s))
