'''
----------------------------------------------------------------------------
Name:         logger.py
Purpose:      Utilities to help with logging
Author:       Jeff Norton
Created:      01/04/05
CVS-ID:       $Id$
Copyright:    (c) 2005 novalide, Inc.
License:      wxWindows License
----------------------------------------------------------------------------
'''
import logging
import sys
import multiprocessing as mp

LOG_INITIALIZED = False
MAIN_PROCESS_NAME = 'MainProcess'
IDE_LOG_NAME = "ide.run"
DEBUG_IDE_LOG_NAME = "ide.debug"
DEFAULT_IDE_LOG_NAME = IDE_LOG_NAME


def init_logging(debug=False):
    global default_ide_logger, LOG_INITIALIZED, DEFAULT_IDE_LOG_NAME
    if not LOG_INITIALIZED:
        LOG_INITIALIZED = True
        log_level = logging.INFO
        default_stream = sys.stdout
        if debug:
            log_level = logging.DEBUG
            DEFAULT_IDE_LOG_NAME = DEBUG_IDE_LOG_NAME
        handler = logging.StreamHandler(default_stream)
        handler.setLevel(log_level)
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(name)s %(levelname)s [%(processName)s]: %(message)s"))
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(log_level)
        default_ide_logger = logging.getLogger(DEFAULT_IDE_LOG_NAME)
        default_ide_logger.setLevel(log_level)


default_ide_logger = logging.getLogger(DEFAULT_IDE_LOG_NAME)


def get_logger(logger_name=""):
    if logger_name in ('', 'root'):
        return default_ide_logger
    return logging.getLogger(logger_name)


def get_mp_logger(logger_name=""):
    '''
    启动多进程的日志对象
    '''
    # 在每个子进程中初始化日志,在主进程中已初始化日志,没必要重复初始化
    if mp.current_process().name != MAIN_PROCESS_NAME:
        init_logging()
    if logger_name in ('', 'root'):
        return logging.getLogger('ide.multiprocess')
    return logging.getLogger(logger_name)
