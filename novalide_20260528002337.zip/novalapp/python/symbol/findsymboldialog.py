# -*- coding: utf-8 -*-
'''
Name:        findsymbol.py
Purpose:
Author:      wukan
Created:     2026-01-11
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import os
import types
import re
import keyword
from ...findrep import findui
from ...findrep import findindir
from ..editor import PythonView
from .searchsupport import ItemToSearchIn
from .. import utility
from ...widgets.labels import FitPathLabel
from ... import constants
from ... import _, get_app
from .parameter import FindSymbolParameter, FindSymbolIn
from ...util import utils, fileutils, ui_utils, strutils
from ...lib.pyqt import (
    QDialog,
    QLabel,
    QGridLayout,
    QHBoxLayout,
    QCheckBox,
    Qt,
    QPushButton,
    QFileDialog,
    QComboBox,
    QSizePolicy,
    QGroupBox,
    QRadioButton,
    QApplication,
    QCursor,
    QProgressBar,
    QTimer
)


SYMBOL_FILE_RANGE = "CurrentFileRange"
SYMBOL_PROJECT_RANGE = "CurrentProjectRange"
SYMBOL_OPEN_FILES_RANGE = "OpenFilesRange"
SYMBOL_DIR_RANGE = "DirRange"
SYMBOL_TYPE = "SymbolType"


class FindSymbolLabel(QLabel):
    def __init__(self):
        super().__init__(_("Symbol Name") + ":")


class FindSymbolCombo(findui.FindtextCombo):
    def set_find_text(self, findstr):
        super().set_find_text(findstr)
        strip_find_text = self.get_text()
        text_parts = re.split(r"[\s(,)=:]", strip_find_text)
        for text in text_parts:
            if strutils.is_none_empty(text) or text in keyword.kwlist:
                continue
            self.set_text(text)
            break


class FindSymbolDialog(ui_utils.BaseModalDialog):

    SYMBOL_NAME_LIST = [
        _('Classes'),
        _('Functions'),
        _('Imports'),
        _('Calls'),
        _('Variables'),
        _('All Types')
    ]
    MATCHES_PARAM = 'matches'

    def __init__(self, master, results_view, findString="", parameter=None):
        super().__init__("", master)
        self.setWindowTitle(_("Find Symbol"))
        self.resize(600, 300)
        self.setSizeGripEnabled(True)

        self.__cancel_request = False
        self._in_progress = False
        self.__new_search = True
        # 初始化参数,重新搜索功能时有用
        self._parameter = parameter
        self.file_label = None
        self.pb = None
        self.searchResults = []
        findui.init_find_option()
        self._results_view = results_view
        # Find text label
        find_box_layout = QHBoxLayout()
        find_label = FindSymbolLabel()
        find_box_layout.addWidget(find_label)
        # Find text field
        self.find_entry_combo = FindSymbolCombo(self)
        findstring = findui.FindDialog.get_find_str(findString)
        findindir.FindIndirDialog.tune_combo(self.find_entry_combo)
        find_box_layout.addWidget(self.find_entry_combo, 1)
        self.layout.addLayout(find_box_layout)
        self._history = findui.getFindHistory()

        symbol_types_box_layout = QHBoxLayout()
        symbol_types_box_layout.addWidget(QLabel(_('Symbol Types') + ":"))
        self.find_symbol_range_combox = QComboBox()
        self.find_symbol_range_combox.addItems(self.SYMBOL_NAME_LIST)
        self.find_symbol_range_combox.setCurrentIndex(utils.profile_get_int(SYMBOL_TYPE, 0))
        self.find_symbol_range_combox.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        symbol_types_box_layout.addWidget(self.find_symbol_range_combox)
        self.layout.addLayout(symbol_types_box_layout)
        self.create_replace_widget()

        horizontalcb_layout = QHBoxLayout()
        # Case checkbox
        self.case_checkbutton = QCheckBox(_("Case sensitive"))
        self.case_checkbutton.setChecked(findui.CURERNT_FIND_OPTION.match_case)
        horizontalcb_layout.addWidget(self.case_checkbutton)

        self.wholeword_checkbutton = QCheckBox(_("Match whole symbol"))
        self.wholeword_checkbutton.setChecked(
            findui.CURERNT_FIND_OPTION.match_whole_word)
        horizontalcb_layout.addWidget(self.wholeword_checkbutton)

        self.layout.addLayout(horizontalcb_layout)

        files_groupbox = QGroupBox(self)
        files_groupbox.setTitle(_("Find in"))
        size_policy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        size_policy.setHorizontalStretch(0)
        size_policy.setVerticalStretch(0)
        size_policy.setHeightForWidth(
            files_groupbox.sizePolicy().hasHeightForWidth())
        files_groupbox.setSizePolicy(size_policy)

        gridlayout_fg = QGridLayout(files_groupbox)

        self.file_rbutton = QRadioButton(files_groupbox)
        self.file_rbutton.setText(_("&Current file"))
        gridlayout_fg.addWidget(self.file_rbutton, 0, 0)
        self.file_rbutton.clicked.connect(self.__file_clicked)

        self.project_rbutton = QRadioButton(files_groupbox)
        self.project_rbutton.setText(_("&Current project"))
        gridlayout_fg.addWidget(self.project_rbutton, 1, 0)
        self.project_rbutton.clicked.connect(self.__project_clicked)

        self.openfiles_rbutton = QRadioButton(files_groupbox)
        self.openfiles_rbutton.setText(_("&Opened files only"))
        gridlayout_fg.addWidget(self.openfiles_rbutton, 2, 0)
        self.openfiles_rbutton.clicked.connect(self.__openfilesonly_clicked)

        self.dir_rbutton = QRadioButton(files_groupbox)
        self.dir_rbutton.setText(_("&Directory tree"))
        gridlayout_fg.addWidget(self.dir_rbutton, 3, 0)
        self.dir_rbutton.clicked.connect(self.__dir_clicked)

        self.dir_edit_combo = QComboBox(files_groupbox)
        findindir.FindIndirDialog.tune_combo(self.dir_edit_combo)
        self.dir_edit_combo.lineEdit().setToolTip(_("Directory to search in"))
        gridlayout_fg.addWidget(self.dir_edit_combo, 3, 1)
        self.dir_edit_combo.editTextChanged.connect(self.__sometext_changed)

        self.dir_select_button = QPushButton(files_groupbox)
        self.dir_select_button.setText("...")
        gridlayout_fg.addWidget(self.dir_select_button, 3, 2)
        self.dir_select_button.clicked.connect(self.__selectdir_clicked)

        self.layout.addWidget(files_groupbox)
        self.create_progress()
        self.button_box = self.create_standard_buttons()
        self.find_button = self.ok_button
        self.find_button.setText(_("Find"))
        self.button_box.accepted.disconnect(self._ok)
        self.find_button.clicked.connect(self._perfom_find)
        self.__test_searchability()
        if self.file_rbutton.isEnabled():
            self.file_rbutton.setChecked(True)
            self.__file_clicked()
        elif self.project_rbutton.isEnabled():
            self.project_rbutton.setChecked(True)
        elif self.openfiles_rbutton.isEnabled():
            self.openfiles_rbutton.setChecked(True)
        else:
            self.dir_rbutton.setChecked(True)
        self.check_rb_status()

        if self._parameter is not None:
            self.__new_search = False
            self.setWindowTitle(_("Find Symbol") + ": " + _("Search again"))
            self.__populate_searchagain(self._parameter)
        self.find_entry_combo.editTextChanged.connect(self.__sometext_changed)
        self.set_find_text(findstring)

    def set_find_text(self, findstr):
        self.find_entry_combo.set_find_text(findstr)

    def check_rb_status(self):
        if self.file_rbutton.isEnabled():
            self.file_rbutton.setChecked(utils.profile_get_int(SYMBOL_FILE_RANGE, 1))
        if self.project_rbutton.isEnabled():
            self.project_rbutton.setChecked(utils.profile_get_int(SYMBOL_PROJECT_RANGE, 0))
        if self.openfiles_rbutton.isEnabled():
            self.openfiles_rbutton.setChecked(utils.profile_get_int(SYMBOL_OPEN_FILES_RANGE, 0))
        self.dir_rbutton.setChecked(utils.profile_get_int(SYMBOL_DIR_RANGE, 0))
        if self.dir_rbutton.isChecked():
            self.dir_edit_combo.setEditText(utils.profile_get(findindir.FIND_MATCHDIR, ""))

    def create_replace_widget(self):
        '''
        create replace widget for replace dialog
        '''
        self._populate_history(True)

    def _populate_history(self, only_find):
        """Populates the history"""
        del only_find
        index = 0
        for props in self._history:
            if not isinstance(props, dict):
                continue
            self.find_entry_combo.addItem(props[findui.FIND_MATCHPATTERN], index)
            index += 1

    def __populate_searchagain(self, parameter):
        """Populates the search parameters to do the same search"""
        self.find_entry_combo.setEditText(parameter.findstr)
        self.find_entry_combo.setEnabled(False)
        self.find_symbol_range_combox.setCurrentIndex(parameter.symbol)
        self.case_checkbutton.setChecked(parameter.match_case)
        self.case_checkbutton.setEnabled(False)
        self.wholeword_checkbutton.setChecked(parameter.match_whole_word)
        self.wholeword_checkbutton.setEnabled(False)

        if parameter.find_in == FindSymbolIn.IN_PROJECT:
            self.project_rbutton.setChecked(True)
        elif parameter.find_in == FindSymbolIn.IN_OPEN_FILES:
            self.openfiles_rbutton.setChecked(True)
        elif parameter.find_in == FindSymbolIn.IN_FILE:
            self.file_rbutton.setChecked(True)
        else:
            self.dir_rbutton.setChecked(True)

        self.file_rbutton.setEnabled(False)
        self.project_rbutton.setEnabled(False)
        self.openfiles_rbutton.setEnabled(False)
        self.dir_rbutton.setEnabled(False)

        self.dir_edit_combo.setEditText(parameter.path)
        self.dir_edit_combo.setEnabled(False)
        self.dir_select_button.setEnabled(False)

    def get_parameter(self):
        findwhere = -1
        path = ''
        if self.file_rbutton.isChecked():
            findwhere = FindSymbolIn.IN_FILE
        elif self.openfiles_rbutton.isChecked():
            findwhere = FindSymbolIn.IN_OPEN_FILES
        elif self.project_rbutton.isChecked():
            findwhere = FindSymbolIn.IN_PROJECT
        elif self.dir_rbutton.isChecked():
            findwhere = FindSymbolIn.IN_DIRECTORY
            path = self.dir_edit_combo.currentText()

        return FindSymbolParameter(
            findui.CURERNT_FIND_OPTION.findstr,
            findwhere,
            self.find_symbol_range_combox.currentIndex(),
            findui.CURERNT_FIND_OPTION.match_case,
            findui.CURERNT_FIND_OPTION.match_whole_word,
            path
        )

    def __sometext_changed(self, text):
        """Text to search, filter or dir name has been changed"""
        del text    # unused argument
        self.__test_searchability()

    def __file_clicked(self):
        """project radio button clicked"""
        self.dir_edit_combo.setEnabled(False)
        self.dir_select_button.setEnabled(False)
        self.__test_searchability()

    def __project_clicked(self):
        """project radio button clicked"""
        self.dir_edit_combo.setEnabled(False)
        self.dir_select_button.setEnabled(False)
        self.__test_searchability()

    def __openfilesonly_clicked(self):
        """open files only radio button clicked"""
        self.dir_edit_combo.setEnabled(False)
        self.dir_select_button.setEnabled(False)
        self.__test_searchability()

    def __dir_clicked(self):
        """dir radio button clicked"""
        self.dir_edit_combo.setEnabled(True)
        self.dir_select_button.setEnabled(True)
        self.dir_edit_combo.setFocus()
        self.__test_searchability()

    def exec_(self):
        """Execute the dialog"""
        if not self.__new_search:
            QTimer.singleShot(1, self._process)
        QDialog.exec_(self)

    def __selectdir_clicked(self):
        """The user selects a directory"""
        options = QFileDialog.Options()
        options |= QFileDialog.ShowDirsOnly | QFileDialog.DontUseNativeDialog
        dirname = QFileDialog.getExistingDirectory(
            self,
            _('Select directory to search in'),
            self.dir_edit_combo.currentText(),
            options
        )
        if dirname:
            self.dir_edit_combo.setEditText(os.path.normpath(dirname))
        self.__test_searchability()

    def __test_searchability(self):
        """Tests the searchability and sets the Find button status"""
        if self.find_entry_combo.currentText().strip() == "":
            self.find_button.setEnabled(False)
            self.find_button.setToolTip(_("No text to search"))
            return

        self.find_button.setEnabled(True)
        if self.dir_rbutton.isChecked():
            dirname = self.dir_edit_combo.currentText().strip()
            if dirname == "":
                self.find_button.setEnabled(False)
                self.find_button.setToolTip(_("No directory path"))
                return
            if not os.path.isdir(dirname):
                self.find_button.setEnabled(False)
                self.find_button.setToolTip(_("Path is not a directory"))
                return
        has_open_code_documents = self.__has_opened_files()
        if has_open_code_documents:
            self.openfiles_rbutton.setEnabled(True)
        else:
            self.openfiles_rbutton.setEnabled(False)
        cur_opencode_doc = self.__has_opened_files(curr_file_only=True)
        if cur_opencode_doc:
            self.file_rbutton.setEnabled(True)
        else:
            self.file_rbutton.setEnabled(False)
        in_project = get_app().get_current_project() is not None
        self.project_rbutton.setEnabled(in_project)

    def __has_opened_files(self, curr_file_only=False):
        if curr_file_only:
            current_docview = get_app().MainFrame.GetNotebook().get_current_view()
            if isinstance(current_docview, PythonView):
                return True
            return False
        open_docs = get_app().MainFrame.GetNotebook().open_code_documents()
        for open_doc in open_docs:
            if isinstance(open_doc.GetFirstView(), PythonView):
                return True
        return False

    def __opened_files(self, curr_file_only=False):
        if curr_file_only:
            current_docview = get_app().MainFrame.GetNotebook().get_current_view()
            if isinstance(current_docview, PythonView):
                return [self.build_item(
                    current_docview.GetDocument().GetFilename(),
                    current_docview
                )]
            return []
        open_docs = get_app().MainFrame.GetNotebook().open_code_documents()
        open_python_docs = []
        for open_doc in open_docs:
            if isinstance(open_doc.GetFirstView(), PythonView):
                open_python_docs.append(
                    self.build_item(open_doc.GetFilename(), open_doc.GetFirstView())
                )
            QApplication.processEvents()
            if self.__cancel_request:
                raise Exception("Cancel request")
        return open_python_docs

    def is_find_available(self):
        '''
        按回车键执行查找时检测按钮是否可用
        '''
        return self.find_button.isEnabled() and self.find_entry_combo.get_text().strip() != ''

    def _cancel(self):
        """Triggered when the close button is clicked"""
        self.__cancel_request = True
        if not self._in_progress:
            self.close()

    def _serialize(self):
        """Serializes the current search parameters"""
        termtext = self.find_entry_combo.currentText().strip()
        dirtext = ''
        if self.dir_rbutton.isChecked():
            dirtext = self.dir_edit_combo.currentText().strip()

        return {findui.FIND_MATCHPATTERN: termtext}, {
            findui.FIND_MATCHPATTERN: termtext,
            findindir.FIND_MATCHDIR: dirtext,
            findui.FIND_MATCHCASE: self.case_checkbutton.isChecked(),
            findui.FIND_MATCHWHOLEWORD: self.wholeword_checkbutton.isChecked(),
            SYMBOL_PROJECT_RANGE: self.project_rbutton.isChecked(),
            SYMBOL_OPEN_FILES_RANGE: self.openfiles_rbutton.isChecked(),
            SYMBOL_DIR_RANGE: self.dir_rbutton.isChecked(),
            SYMBOL_FILE_RANGE: self.file_rbutton.isChecked(),
            SYMBOL_TYPE: self.find_symbol_range_combox.currentIndex()
        }

    def clear_combo_items(self, only_find):
        self.find_entry_combo.clear()

    def _update_history(self, only_find=True):
        """Updates history if needed"""
        current_text = self.find_entry_combo.currentText().strip()
        history_item, params = self._serialize()
        combo_index, history_index = self.find_entry_combo.historyindex_by_findtext(current_text)
        if history_index is not None:
            self._history[history_index] = history_item
        else:
            self._history.insert(0, history_item)
            if len(self._history) > findui.MAX_LIST_STR_NUM:
                self._history = self._history[:findui.MAX_LIST_STR_NUM]

        self.clear_combo_items(only_find)
        self._populate_history(only_find)
        combo_index, history_index = self.find_entry_combo.historyindex_by_findtext(current_text)
        self.find_entry_combo.setCurrentIndex(combo_index)
        # Save the combo values for further usage
        findui.setFindHistory(self._history, params)

    def _perfom_find(self):
        self._update_history()
        self._process()

    def _process(self):
        """Search process"""
        if not self.is_find_available():
            return
        self.init_findtext_option()
        findprog = findindir.FindInfileDialog.get_find_prog(self)
        if not findprog:
            return
        param = self.init_process()
        QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        self.file_label.setPath(_('Building list of files to search in...'))
        QApplication.processEvents()
        try:
            files = self.__build_files_list()
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            if 'Cancel request' not in str(exc):
                utils.get_logger().error(str(exc))
            self.close()
            return
        QApplication.restoreOverrideCursor()
        QApplication.processEvents()
        if not files:
            self.file_label.setPath(_('No files to search in'))
            self.find_button.setEnabled(True)
            return
        if isinstance(files, types.GeneratorType):
            # 计算生成器的长度
            files_num = sum(1 for _ in files)
            # 上面计算长度时耗尽了生成器,需要重新生成生成器
            files = self.__build_files_list()
        else:
            files_num = len(files)
        utils.get_logger().info('search symbol in total %d files', files_num)
        self.pb.setRange(0, files_num)
        utils.get_logger().debug('total progress value is %d', files_num)
        self.show_progress()
        index = 1
        for item in files:
            if self.__cancel_request:
                self._in_progress = False
                break
            self.process_item(index, findprog, param, item)
            index += 1
            QApplication.processEvents()
        self.finish_process(param, files_num)

    def create_progress(self):
        self.file_label = FitPathLabel(parent=self)
        self.file_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        self.layout.addWidget(self.file_label)
        self.pb = QProgressBar(self)
        self.pb.setValue(0)
        self.pb.setOrientation(Qt.Horizontal)
        self.pb.setVisible(False)
        self.layout.addWidget(self.pb)

    def init_process(self):
        self._in_progress = True
        self.find_button.setEnabled(False)
        self.searchResults = []
        return {
            self.MATCHES_PARAM: 0,
        }

    def build_item(self, filepath, code_view=None):
        return ItemToSearchIn(filepath, code_view)

    def process_item(self, index, findprog, param, item):
        self.update_progress(
            index,
            _('Matches') + ': ' + str(param[self.MATCHES_PARAM]) + ' ' + _('Processing') + ': ' + item.fileName
        )

        item.search(
            findprog, self.find_symbol_range_combox.currentIndex()
        )
        found = len(item.matches)
        if found > 0:
            param[self.MATCHES_PARAM] += found
            self.searchResults.append(item)

    def finish_process(self, param, files_num):
        self._in_progress = False
        number_of_matches = param[self.MATCHES_PARAM]
        utils.get_logger().debug(
            'search total %d results in %d files',
            number_of_matches,
            files_num
        )

        if number_of_matches > 0 or self.__new_search == False:
            # If it is redo then close the dialog anyway
            self.close()
        else:
            msg = _('No matches in') + ' ' + str(files_num) + ' '
            if files_num > 1:
                msg += _('files')
            else:
                msg += _('file')
            self.file_label.setPath(msg)
            self.find_button.setEnabled(True)

    @ui_utils.call_after_with_time(3000)
    def show_progress(self):
        # 如果搜索文本操作已经完成,则不会显示进度条对话框
        if self._in_progress:
            self.pb.setVisible(True)

    def update_progress(self, curval, label_msg):
        utils.get_logger().debug('cur progress value is %d', curval)
        self.pb.setValue(curval)
        self.file_label.setPath(label_msg)

    def __project_files(self):
        project_browser = get_app().MainFrame.projectview
        project_filenames = project_browser.GetFilesFromCurrentProject()
        # 先查找在编辑器中打开的文本,因为这些文本内容可能已经和实际存储的文件不一致了
        open_docs = get_app().GetDocumentManager().GetDocuments()
        # python3 filter不返回列表,返回filter对象,需要手动转换成list
        opendocs_in_project = list(
            filter(lambda opendoc: opendoc.GetFilename() in project_filenames, open_docs))
        project_open_docs = []
        for project_file_name in project_filenames:
            if not utility.is_python_file(project_file_name):
                continue
            found_open_doc = None
            for open_doc_project in opendocs_in_project:
                if fileutils.ComparePath(project_file_name, open_doc_project.GetFilename()):
                    found_open_doc = open_doc_project
                    break
            if found_open_doc is None:
                project_open_docs.append(self.build_item(project_file_name))
            else:
                project_open_docs.append(
                    self.build_item(project_file_name, found_open_doc.GetFirstView())
                )
            QApplication.processEvents()
            if self.__cancel_request:
                raise Exception("Cancel request")
        return project_open_docs

    def __build_files_list(self):
        """Builds the list of files to search in"""
        if self.file_rbutton.isChecked():
            return self.__opened_files(curr_file_only=True)

        if self.project_rbutton.isChecked():
            return self.__project_files()

        if self.openfiles_rbutton.isChecked():
            return self.__opened_files()
        dirname = os.path.realpath(self.dir_edit_combo.currentText().strip())
        return self.__dir_files(dirname)

    def __dir_files(self, path):
        '''
        遍历目录,返回文件生成器,减少内存消耗
        '''
        open_docs = get_app().GetDocumentManager().GetDocuments()
        for root, dirs, files in os.walk(path):
            QApplication.processEvents()
            if self.__cancel_request:
                raise Exception("Cancel request")
            # 忽略版本控制生成的目录
            for r_dir in constants.REVISION_CONTROL_DIRS:
                if r_dir in dirs:
                    dirs.remove(r_dir)
                    utils.get_logger().debug(
                        'revision control dir %s is ignored...',
                        r_dir
                    )
                    break
            for file in files:
                if not utility.is_python_file(file):
                    continue
                filepath = os.path.join(root, file)
                open_edit_view = None
                for opendoc in open_docs:
                    if fileutils.ComparePath(opendoc.GetFilename(), filepath):
                        open_edit_view = opendoc.GetFirstView()
                        break
                if open_edit_view is not None:
                    yield self.build_item(filepath, open_edit_view)
                else:
                    yield self.build_item(filepath)

    def init_findtext_option(self):
        findui.CURERNT_FIND_OPTION.findstr = self.find_entry_combo.currentText()
        findui.CURERNT_FIND_OPTION.match_case = self.case_checkbutton.isChecked()
        findui.CURERNT_FIND_OPTION.match_whole_word = self.wholeword_checkbutton.isChecked()

    def closeEvent(self, event):
        """Called when the window is closed. responsible for handling all cleanup."""
        del event
        self.reject()
