import abc
from novalapp.util import fileutils
from novalapp.python.project.processor import PythonProcessor
from novalapp import _
from novalapp.util import utils
from . import configkeys
from .sarif_loader import SarifLoader
from .toolmanager import CodecheckToolManager
from .codeutils import ScanMode, check_git_plugin_installed
from .common_check import CommonChecker


class CommonProcessor(PythonProcessor, CommonChecker):
    """description of class"""

    def __init__(self, parent, statusbar, processor_name, enabled):
        self.message_viewer = parent
        super().__init__(statusbar, processor_name, enabled)
        CommonChecker.__init__(self)

    @staticmethod
    def use_codecheck(doc):
        return doc.get_int(configkeys.USE_CODECHECK_PROJECT_KEY, True)

    @staticmethod
    def get_file_content(filepath):
        filecontent = fileutils.get_file_content(
            filepath, allow_exception=False, enc=utils.get_default_locale_encoding())
        if filecontent is None:
            filecontent = fileutils.get_file_content(
                filepath, allow_exception=False)
        return filecontent

    @staticmethod
    def find_tool(tool_name):
        tool = CodecheckToolManager.manager().find_tool(tool_name)
        if not tool.enabled:
            utils.get_logger().error('tool %s is disabled', tool_name)
            return None
        return tool

    @classmethod
    def load_file_messages(cls, check_tool, message_file):
        messages = []
        if check_tool.output_format == check_tool.PLAIN_TEXT_FORMAT:
            filecontent = cls.get_file_content(message_file)
            for linemsg in filecontent.splitlines():
                msg = check_tool.parse_line_msg(linemsg)
                if msg is None:
                    utils.get_logger().debug('line text %s is not a valid message line', linemsg)
                    continue
                messages.append(msg)
        elif check_tool.output_format == check_tool.JSON_OUTPUT_FORMAT:
            messages = SarifLoader(message_file, check_tool.name).load()
        return messages

    def stop(self, reason):
        super().stop(reason)
        self.message_viewer.SIG_STOP_PROCESSOR.emit(reason)

    def run(self, doc, filepath):
        super().run(doc, filepath)
        if not self.check_enabled(doc, filepath):
            super().update_progress(filepath)
            return False
        if self.stopped:
            utils.get_logger().debug('codecheck is stopped when running')
            return False
        if not self.use_codecheck(doc):
            utils.get_logger().error('codecheck function is disabled')
            return False
        return True

    def check_docrepo_branch(self, doc):
        '''
        检测项目目录是否是git仓库
        '''
        if not utils.profile_get_int(
            configkeys.CODECHECK_PROJECT_MUSTBE_REPOSITORY_KEY,
            True
        ) and self.scan_mode != ScanMode.CHANGED_FILES_MODE.value:
            return
        check_git_plugin_installed()
        from git.repo import Repo
        repo = Repo(doc.GetPath())
        repo.branch()

    def init_tools(self):
        if self.interpreter is not None:
            CodecheckToolManager.manager().register_python_tools(self.interpreter)
        for checktool in CodecheckToolManager.manager().CHECK_TOOLS:
            # 工具初始化默认启用所有规则,为None既表示启用所有规则
            toolrules = utils.profile_get(
                configkeys.TOOL_RULES_KEY % checktool.name, None)
            try:
                checktool.update_enable_rules(toolrules)
            except Exception as ex:
                utils.get_logger().error(
                    "tool %s update rules %s fail",
                    checktool.name,
                    toolrules
                )
                raise ex
        return True

    def init(self, doc):
        self.message_viewer.doc = doc
        super().init(doc)
        if not self.init_tools():
            return
        self.init_checker(doc)
        self.enabled = True
        self.check_docrepo_branch(doc)
        utils.get_logger().debug('check doc `%s` repo branch success', doc.GetFilename())
        self.message_viewer.SIG_INIT_PROCESSOR.emit()

    def end(self, doc):
        if self.stopped:
            utils.get_logger().error('codecheck is stopped with some reason')
        super().end(doc)
        self.enabled = False
        self.message_viewer.SIG_END_PROCESSOR.emit(self.name)

    def load_message_file(self, doc, check_tool, message_file):
        messages = self.load_messages(check_tool, message_file)
        for msg in messages:
            self.handle_message(doc, check_tool, msg)

    def load_messages(self, check_tool, message_file):
        messages = []
        try:
            messages = self.load_file_messages(check_tool, message_file)
        except Exception as ex:
            self.stop(_("load message file %s error:%s") %
                      (message_file, str(ex)))
        return messages

    @abc.abstractmethod
    def handle_message(self, doc, check_tool, msg):
        raise NotImplementedError('You must implemented it in derived class')

    def update_progress(self, filepath):
        self.message_viewer.SIG_UPDATE_PROGRESS.emit(self.updated_file_count)
        super().update_progress(filepath)
