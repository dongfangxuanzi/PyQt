# -*- coding: utf-8 -*-
import os
import re
import functools
import json
import logging
import requests
from .. import get_app, _
from ..analytics.userdb import UserdataDb
from . import appdirs, fileutils, ui_utils
from .. import constants
from ..lib.pyqt import QProgressDialog, QThread, pyqtSignal

log = logging.getLogger(__name__)


class DownloadProgressDialog(QProgressDialog):
    '''
    下载进度显示对话框
    '''
    update_progress_signal = pyqtSignal(int, str)
    INIT_DOWNLOAD_INFO_SIGNAL = pyqtSignal(int, str)

    def __init__(self, parent, file_size, file_name):
        welcome_msg = _("Please wait for a moment for until the download complete")
        QProgressDialog.__init__(self, welcome_msg, _(
            "Cancel"), 0, file_size, parent)
        if file_name is None:
            self.setWindowTitle(_("Downloading"))
        else:
            self.setWindowTitle(_("Downloading %s") % file_name)
        self.update_progress_signal.connect(self.update_progress)
        self.INIT_DOWNLOAD_INFO_SIGNAL.connect(self.init_download_info)

    def init_download_info(self, content_size, content_file_name):
        self.setWindowTitle(_("Downloading %s") % content_file_name)
        self.setMaximum(content_size)

    def update_progress(self, curval, msg):
        # 下载完成后关闭进度条
        if msg == constants.PROGRESS_END:
            self.setValue(self.maximum())
            log.info(
                'progress dialog closed and end value is %d,max value is %d',
                curval,
                self.maximum()
            )
            self.close()
        else:
            # 当进度数等于或超过最大进度值时,将会关闭进度条对话框,故不能让进度值超过最大进度值
            if curval >= self.maximum():
                raw_curval = curval
                curval = self.maximum() - 1
                log.warning(
                    'cur value %d greater or equal max progress value %d, minus 1 to %d',
                    raw_curval,
                    self.maximum(),
                    curval
                )
            self.setValue(curval)
            if msg:
                self.setLabelText(msg)


class FileDownloader(QThread):
    '''
    下载文件公用类
    '''

    def __init__(
        self,
        service,
        parent,
        file_name,
        download_url,
        req_param,
        call_back=None,
        err_callback=None
    ):
        super().__init__(parent)
        self._file_name = file_name
        self._file_size = 0
        self._download_service = service
        self._file_url = download_url
        self._params = req_param
        self.req = None
        self._call_back = call_back
        self._err_callback = err_callback

    @staticmethod
    def get_dest_filename(filename):
        # 文件下载到临时目录
        download_tmp_path = os.path.join(appdirs.get_cache_path(), "download")
        log.debug("tmp download cache path is %s", download_tmp_path)
        if not os.path.exists(download_tmp_path):
            fileutils.makedirs(download_tmp_path)
        return os.path.join(download_tmp_path, filename)

    def run(self):
        self.startdownload()

    def get_user_id(self):
        user_id = UserdataDb.get_db().GetUserId()
        if not user_id:
            UserdataDb.get_db().GetUser()
            user_id = UserdataDb.get_db().GetUserId()
        if user_id:
            self._params.update({'member_id': user_id})

    def request_url(self):
        '''
        请求连接url,获取请求头部信息,有时候连接url的时间可能比下载文件的时间还要长
        '''
        self._params['timeout'] = constants.DEFAULT_URL_REQUEST_TIMEOUT
        kwargs = {'stream': True}
        if self._file_url.startswith("https:"):
            kwargs.update({'verify': False})
        try:
            log.debug(
                "payload params is %s, kwargs is %s",
                json.dumps(self._params),
                json.dumps(kwargs)
            )
            self.req = requests.get(self._file_url, params=self._params, **kwargs)
            self.req.raise_for_status()
        except Exception as ex:
            log.error("download file url %s error:%s", self._file_url, ex)
            self._err_callback(str(ex))
            return
        log.debug('request response headers is %s', str(self.req.headers))
        if 'Content-Length' not in self.req.headers:
            # 在未知文件大小的情况下下载
            log.warning('could not get content length in response headers')
        else:
            # 字典头部是字符串类型, 转换成整数
            try:
                # 下载文件大小
                self._file_size = int(self.req.headers['Content-Length'])
                # 头部包含的文件名
                content_disposition = self.req.headers['Content-Disposition']
            except KeyError as ex:
                log.error("download file url %s keyerror:%s", self._file_url, ex)
                reason = self.log_fail_reason(self.req)
                self._err_callback("header:keyerror:%s:%s" % (ex, reason))
                return
            # 通过正则匹配头部包含的文件名
            res = re.search("filename=\"(.*)\"", content_disposition)
            if res is None:
                log.error("fetch filename error in head content %s",
                          content_disposition)
                self._err_callback("fetch filename error")
                return
            content_file_name = res.groups()[0]
            if self._file_name is None:
                self._file_name = content_file_name
            log.info(
                'start download content filename %s to dest filename %s',
                content_file_name,
                self._file_name
            )
            self.init_download_info(content_file_name)

    def check_download_file_exist(self):
        '''检查下载本地文件是否已经存在'''
        dest_filename = self.get_dest_filename(self._file_name)
        if not self._download_service.force_download and os.path.exists(dest_filename):
            log.warning(
                'dest download filename %s already exists, give up download again...',
                dest_filename
            )
            return True
        return False

    def startdownload(self):
        self._download_service.is_downloading = True
        self.get_user_id()
        self.request_url()
        if self.req is None:
            log.error('request url:%s fail', self._file_url)
            self.update_download_progress(self._file_size, constants.PROGRESS_END)
            return
        if self.check_download_file_exist():
            self.update_download_progress(self._file_size, constants.PROGRESS_END)
            return
        download_file_path = self.get_dest_filename(self._file_name)
        self.downloadfile(download_file_path)

    def is_canceled(self):
        if self._download_service.progress_dlg is None:
            return False
        return self._download_service.progress_dlg.wasCanceled()

    def init_download_info(self, filename=None):
        '''更新下载进度文件大小和文件名'''
        if self._download_service.progress_dlg is None:
            return
        if filename is None:
            filename = self._file_name
        self._download_service.progress_dlg.INIT_DOWNLOAD_INFO_SIGNAL.emit(
            self._file_size, filename)

    def update_download_progress(self, amount, msg):
        '''更新下载进度条值,如果没有出现进度条对话框则不更新'''
        if self._download_service.progress_dlg is None:
            return
        self._download_service.progress_dlg.update_progress_signal.emit(
            amount, msg)

    def cancel_download_progress(self):
        '''因下载文件失败,主动中断下载进度条'''
        if self._download_service.progress_dlg is None:
            return
        # 模拟点击取消键时,发出取消信号
        self._download_service.progress_dlg.canceled.emit()

    def downloadfile(self, download_file_path):
        f = open(download_file_path, "wb")
        try:
            ammount = 0
            # 分块下载
            for chunk in self.req.iter_content(chunk_size=512):
                if chunk:
                    if self.is_canceled():
                        break
                    f.write(chunk)
                    ammount += len(chunk)
                    self.update_download_progress(ammount, "")
        except Exception as e:
            # 下载失败中断进度条对话框
            self.cancel_download_progress()
            log.error(
                "download file url %s error:%s,download progress was canceled", self.req.url, e)
            # 错误回调函数
            if self._err_callback:
                self._err_callback(str(e))
            f.close()
            self._download_service.is_downloading = False
            return
        f.close()
        # 这里需要设置下载结束标致,否则会导致下载完成后弹出进度条
        self._download_service.is_downloading = False
        log.info('download end...')
        self.update_download_progress(ammount, _("Installing") + "...")
        # 下载完成调用回调函数
        if self._call_back is not None and not self.is_canceled():
            log.info('call callback function after download')
            self._call_back(download_file_path, self.parent())
        self.update_download_progress(ammount, constants.PROGRESS_END)


class FiledownloadSerivce:
    def __init__(self, force_download=True):
        # 是否正则下载文件,用来表示是否显示进度条对话框
        self.is_downloading = False
        # 进度条对话框
        self.progress_dlg = None
        # 在下载文件已经存在的时候,是否强制重新下载
        self._force_download = force_download

    @property
    def force_download(self):
        return self._force_download

    def download_file(
            self,
            download_url,
            filename=None,
            call_back=None,
            parent=None,
            err_callback=None, **payload):
        '''
        下载文件公用函数
        download_url:下载地址
        call_back:下载完成后回调函数
        payload:url参数
        '''
        log.info('start download file url:%s', download_url)
        if parent is None:
            parent = get_app().GetTopWindow()
        if err_callback is None:
            err_callback = functools.partial(
                self.download_error_callback, parent)
        # 这里的filename是下载完成后本地文件名和头部包含的文件名可能不一样
        # 如果指定了文件名,则下载后的文件名以用户指定为主,如果未指定文件名,则以请求头部包含的文件名为主
        file_downloader = FileDownloader(
            self, parent, filename, download_url, payload, call_back, err_callback)
        file_downloader.start()
        self.show_downloadprogress_dialog(parent, filename)

    @ui_utils.call_after_with_time(1000)
    def show_downloadprogress_dialog(self, parent, filename):
        log.info('show download progress dialog when downloading is:%s', self.is_downloading)
        # 如果下载操作已经完成,则不会显示下载进度条对话框
        if self.is_downloading:
            # 初始下载文件大小为0
            self.progress_dlg = DownloadProgressDialog(
                parent, 0, filename)
            self.progress_dlg.exec_()

    def download_error_callback(self, parent, msg):
        parent.SIG_DOWNLOAD_ERROR.emit(msg)

    def log_fail_reason(self, req):
        reason = ''
        try:
            # api接口返回json数据
            data = req.json()
            reason = json.dumps(data)
            log.error("download file url %s error:%s", req.url, reason)
        except json.decoder.JSONDecodeError as ex:
            # api接口返回html文本数据
            log.error(
                "download file url %s decode response text error:%s", req.url, ex)
            reason = str(ex)
        return reason
