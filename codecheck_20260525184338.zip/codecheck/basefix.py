import abc
from novalapp import get_app
from novalapp.util import utils, strutils
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp.python.parser.exceptions import CodeSyntaxError
from .configkeys import TOOL_RULES_AUTOFIX_KEY,FIX_MODULE_NAME_STYLE_KEY
from .exceptions import FixfileError
import os


class BaseFixer(abc.ABC):
    """description of class"""

    def __init__(self, ruleid, toolname, autofix=False, open_file=True):
        self._ruleid = ruleid
        self._toolname = toolname
        autofix_key = TOOL_RULES_AUTOFIX_KEY % (toolname, ruleid)
        self._autofix = bool(utils.profile_get_int(autofix_key, autofix))
        self._openfile = open_file
        self.fix_tool = None
        self.is_autofix_msg = False

    @property
    def ruleid(self):
        return self._ruleid

    @property
    def toolname(self):
        return self._toolname

    @property
    def openfile(self):
        return self._openfile

    @openfile.setter
    def openfile(self, isopen):
        self._openfile = isopen

    @property
    def autofix(self):
        return self._autofix

    @autofix.setter
    def autofix(self, value):
        self._autofix = value

    def open_doc_file(self, doc, msg, is_auto_fix=False):
        del doc
        filepath = msg.filepath
        fix_module_name = utils.profile_get_int(FIX_MODULE_NAME_STYLE_KEY, False)
        if fix_module_name and not os.path.exists(filepath):
            return None, None
        if self._openfile:
            if is_auto_fix:
                filedoc = get_app().GetDocumentManager().GetDocument(filepath)
                if filedoc is None:
                    fileview = get_app().GotoView(
                        filepath,
                        lineNum=msg.line,
                        colno=msg.column,
                        load_outline=False,
                        trace_track=False
                    )
                else:
                    fileview = filedoc.GetFirstView()
                    filedoc.reload()
            else:
                fileview = get_app().GotoView(
                    filepath,
                    lineNum=msg.line,
                    colno=msg.column,
                    load_outline=False,
                    trace_track=False
                )
            if fileview is None:
                return None, None
            textctrl = fileview.GetCtrl()
            return fileview, textctrl
        return None, None

    @abc.abstractmethod
    def fix_message(self, doc, msg, **kwargs):
        raise NotImplementedError('You must implemented it in derived class')

    def auto_fix_msg(self, doc, msg):
        textview = self.open_doc_file(doc, msg, is_auto_fix=True)[0]
        if not self.autofix:
            utils.get_logger().warning(
                "rule %s in tool %s could not autofix code message", msg.ruleid, self.toolname)
            return textview, False
        if textview is None:
            utils.get_logger().error("open document file %s error", msg.filepath)
            return textview, False
        self.is_autofix_msg = True
        result: bool = self.fix_message(doc, msg)
        utils.get_logger().info(
            'fix msgid:%s in line %d, column %d of tool %s in filename %s,result:%s',
            msg.ruleid,
            msg.line,
            msg.column,
            msg.toolname,
            msg.filepath,
            strutils.bool_to_str(result)
        )
        assert isinstance(result, bool)
        textdoc = textview.GetDocument()
        textdoc.Save()
        self.is_autofix_msg = False
        return textview, result

    @staticmethod
    def get_msg_line_text(msg, textctrl):
        return textctrl.get_line_text(msg.line - 1)


def fix_code_file_msg(func):
    def wrapper(self, *args):
        textview, textctrl = self.open_doc_file(*args)
        if textview is None:
            utils.get_logger().error(
                "open document file %s error", args[1].filepath)
            return False
        return func(self, *args, **{'textview': textview, 'textctrl': textctrl})
    return wrapper


class BasePythonFixer(BaseFixer):
    ''''''

    def load_module(self, textview, filepath, reload=False):
        if textview.ModuleAnalyzer.Module is None or reload:
            textview.ModuleAnalyzer.parse_module(filepath)
            if textview.ModuleAnalyzer.Module is None:
                raise CodeSyntaxError(textview.ModuleAnalyzer.SyntaxError)

    def find_msg_node(self, textview, msg, use_column=False):
        self.load_module(textview, msg.filepath)
        line = msg.line
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        if use_column:
            node = textview.ModuleAnalyzer.find_line_col_node(line, msg.column, scope)
        else:
            node = textview.ModuleAnalyzer.find_line_node(line, scope)
        return node

    def auto_fix_msg(self, doc, msg):
        textview, result = super().auto_fix_msg(doc, msg)
        # 告警修复成功,表示文件内容有变动, 需要重新解析并加载语法树
        if result:
            # 重新解析并加载语法树
            utils.get_logger().info(
                "file %s parse and reload ast tree again",
                msg.filepath
            )
            try:
                self.load_module(textview, msg.filepath, reload=True)
            except CodeSyntaxError as ex:
                utils.get_logger().error(
                    "fix message file %s may occur syntax eror:%s on rule %s of tool %s",
                    msg.filepath,
                    textview.ModuleAnalyzer.SyntaxError,
                    msg.ruleid,
                    msg.toolname
                )
                raise FixfileError(f'Fix file {msg.filepath} Error:{textview.ModuleAnalyzer.SyntaxError}') from ex
        return textview, result

    @staticmethod
    def get_node_line_text(node, textctrl):
        return textctrl.get_line_text(node.line - 1)


    @staticmethod
    def get_scope_range_texts(scope, textctrl):
        line_range_texts = []
        for i in range(scope.lineno-1, scope.end_lineno):
            line_range_texts.append(textctrl.get_line_text(i))
        return os.linesep.join(line_range_texts)
