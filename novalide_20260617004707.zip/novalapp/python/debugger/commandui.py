# -*- coding: utf-8 -*-
import pickle
import bz2
from xml.dom.minidom import parseString
import threading
import os
from xmlrpc.server import SimpleXMLRPCServer
import queue as Queue
import xmlrpc.client as xmlrpclib
import time
from novalapp.python.debugger import debuggerharness
from ... import _, get_app, newid
from .output import DebugOutputView
from .executor import PythonExecutor
from ...lib.pyqt import Qt, QMessageBox, QAction, QTimer, QDialog, pyqtSignal
from ...util import utils, ui_utils, fileutils
from ...common.compat import ensure_string
from . import watchs
from ...bars.menubar import find_menu, MenubarMixin
from ... import constants, menuitems
from . import debugcfg as debugconfig
from ...debugger.debugger import CommonRunCommandUI
from ...lib.docmanager import DOC_SILENT
from .executor import PythonDebuggerExecutor
from .. import utility


# VERBOSE mode will invoke threading.Thread _VERBOSE,which will print a lot of thread debug text
# on screen.
_VERBOSE = False
_WATCHES_ON = True


def show_breakdebug_views(show=True):
    if show:
        for tabname in [
            constants.INTERACTCONSOLE_TAB_NAME, constants.BREAKPOINTS_TAB_NAME,
            constants.STACKFRAME_TAB_NAME, constants.WATCH_TAB_NAME
        ]:
            if get_app().MainFrame.is_tab_active(tabname):
                break
        else:
            get_app().MainFrame.activateTab(constants.STACKFRAME_TAB_NAME)
    else:
        get_app().MainFrame.right_sidebar.shrink()


class RunCommandUI(CommonRunCommandUI):
    SIG_DEBUG_INTERNAL = pyqtSignal()
    TERMINATE_ALL_PROCESS_ID = newid()

    def __init__(
        self,
        parent,
        debugger,
        run_parameter,
        append_runner=True,
        toolbar_orient=Qt.Vertical
    ):
        # toolbar使用垂直布局
        CommonRunCommandUI.__init__(
            self,
            parent,
            debugger,
            run_parameter,
            append_runner,
            toolbar_orient=toolbar_orient
        )
        self._notebook = parent

    @staticmethod
    def ShutdownAllRunners():
        # See comment on PythonDebuggerUI.StopExecution
        for runner in RunCommandUI.runners:
            if not isinstance(runner, RunCommandUI):
                continue
            try:
                runner.StopExecution()
                runner.UpdateAllRunnerTerminateAllUI()
            except Exception as ex:
                utils.get_logger().error(
                    "shutdown all runners error:%s",
                    str(ex)
                )

    @staticmethod
    def StopAndRemoveAllUI():
        return get_app().GetDebugger().close_all_ui()

    def GetOutputviewClass(self):
        return DebugOutputView

    def destroy(self):
        # See comment on PythonDebuggerUI.StopExecution
        RunCommandUI.runners.remove(self)
        CommonRunCommandUI.destroy(self)

    def GetExecutorClass(self):
        # python执行器
        return PythonExecutor

    def IsProcessRunning(self):
        process_runners = [
            runner
            for runner in self.runners
            if isinstance(runner, RunCommandUI) and not runner.Stopped
        ]
        return len(process_runners) > 0

    def UpdateAllRunnerTerminateAllUI(self):
        for runner in self.runners:
            if isinstance(runner, RunCommandUI):
                runner.UpdateTerminateAllUI()

    def UpdateTerminateAllUI(self):
        self._tb.EnableTool(self.TERMINATE_ALL_PROCESS_ID,
                            self.IsProcessRunning())

    # 进程退出回调函数延迟1秒执行, 可以充分保证输出文本完成,防止进程已经退出异步输出文本仍在执行
    @ui_utils.call_after_with_time(1000)
    def ExecutorFinished(self, exitcode, stopped=True):
        self.UpdateFinishedPagePaneText()
        CommonRunCommandUI.ExecutorFinished(self, exitcode, stopped=stopped)
        self.UpdateAllRunnerTerminateAllUI()

    def UpdateViewLabel(self, src_text, to_text):
        '''
        更新调式视图刚开始的标签文本,否则在最大化和恢复文档窗口时,调式窗口显示的标签文本不准确
        '''
        for view_name in GetApp().MainFrame._views:
            view = GetApp().MainFrame._views[view_name]
            if 'instance' not in view:
                utils.get_logger().error(
                    'view %s is not valid view instance when update label', view_name)
                continue
            instance = view["instance"]
            if instance == self:
                old_label = view['label']
                newlabel = old_label.replace(src_text, to_text)
                view['label'] = newlabel
                break

    # when process finished,update tag page text
    def UpdateFinishedPagePaneText(self):
        self.UpdatePagePaneText(_("Running"), _("Finished Running"))

    def EnableToolbar(self):
        super().EnableToolbar()
        self._tb.EnableTool(
            self.TERMINATE_ALL_PROCESS_ID,
            enable=not (self._executor is None)
        )

    def OnToolClicked(self, id):
        super().OnToolClicked(id)
        if id == self.TERMINATE_ALL_PROCESS_ID:
            self.ShutdownAllRunners()

    def CreateToolbarButtons(self):
        super().CreateToolbarButtons()
        self.terminate_all_image = get_app().GetImage(
            "python/debugger/terminate_all.png")
        stopall_tb_button = QAction(
            self.terminate_all_image, _("Stop all the run."), self)
        stopall_tb_button.triggered.connect(
            lambda: self.OnToolClicked(self.TERMINATE_ALL_PROCESS_ID))
        self._tb.AddButton(self.TERMINATE_ALL_PROCESS_ID, stopall_tb_button)

    def remove_page(self):
        super().remove_page()
        # 务必从视图列表中移除
        views = get_app().MainFrame.GetViews()
        for view_name in views:
            view = views[view_name]
            if 'instance' not in view:
                utils.get_logger().error(
                    'view %s is not valid view instance when remove it',
                    view_name
                )

                continue
            instance = view["instance"]
            if instance == self:
                del views[view_name]
                break
        return True

    def RestartRunProcess(self):
        self._tb.EnableTool(self.TERMINATE_ALL_PROCESS_ID, True)
        CommonRunCommandUI.RestartRunProcess(self)
        self.UpdateRestartPagePaneText()

    def UpdatePagePaneText(self, src_text, to_text):
        nb = self.bottomTab()
        widget = self
        page_tab_text = nb.tabText(widget)
        newtext = page_tab_text.replace(src_text, to_text)
        nb.setTabText(widget, newtext)

    # when restart process,update tag page text
    def UpdateRestartPagePaneText(self):
        self.UpdatePagePaneText(_("Finished Running"), _("Running"))

    def SaveProjectFiles(self):
        '''
        调式运行python时保存文件策略,由于运行python文件时有多个调式页面,而且还可以运行单个文件,故保存文件策略比较复杂
        '''
        # 如果调式运行的文件属于这个项目,则保存项目所有文件
        if self._debugger.GetCurrentProject().GetModel().FindFile(self._run_parameter.FilePath):
            self._debugger.GetCurrentProject().PromptToSaveFiles()
        else:
            # 如果调式运行的文件不属于这个项目,则只保存该文件
            opendoc = get_app().GetDocumentManager().GetDocument(self._run_parameter.FilePath)
            if opendoc:
                opendoc.Save()


class AGXMLRPCServer(SimpleXMLRPCServer):
    def __init__(self, address, logRequests=0):
        # enable request method return None value
        SimpleXMLRPCServer.__init__(
            self, address, logRequests=logRequests, allow_none=1)


class BaseDebuggerUI(RunCommandUI):
    debuggers = []
    KILL_PROCESS_ID = newid()
    CLOSE_WINDOW_ID = newid()
    CLEAR_ID = newid()

    def __init__(self, parent, debugger, run_parameter):
        RunCommandUI.__init__(self, parent, debugger, run_parameter,
                              append_runner=False, toolbar_orient=Qt.Horizontal)
        self._executor = None
        self._callback = None
        self._restarted = False
        BaseDebuggerUI.debuggers.append(self)
        self._stopped = True
        self.run_menu = find_menu(_("&Run"), get_app().Menubar)
        self._toolEnabled = True
        self.framestab = self.MakeFramesUI()
        self.DisableWhileDebuggerRunning()
        utils.update_statusbar(_("Starting debug..."))

    @staticmethod
    def NotifyDebuggersOfBreakpointChange():
        for debugger in BaseDebuggerUI.debuggers:
            debugger.BreakPointChange()

    @staticmethod
    def DebuggerRunning():
        for debugger in BaseDebuggerUI.debuggers:
            if not debugger.Stopped:
                return True
        return False

    @staticmethod
    def DebuggerInWait():
        for debugger in BaseDebuggerUI.debuggers:
            if not debugger.Stopped:
                if debugger._callback._waiting:
                    return True
        return False

    @staticmethod
    def DebuggerPastAutoContinue():
        for debugger in BaseDebuggerUI.debuggers:
            if not debugger.Stopped:
                if debugger._callback._waiting and not debugger._callback._autoContinue:
                    return True
        return False

    @staticmethod
    def ShutdownAllDebuggers():
        for debugger in BaseDebuggerUI.debuggers:
            try:
                debugger.StopExecution(None)
            except wx._core.PyDeadObjectError:
                pass
        BaseDebuggerUI.debuggers = []

    def CreateToolbarButtons(self):

        self.close_bmp = get_app().GetImage("python/debugger/close.png")

        close_tb_button = QAction(self.close_bmp, _("Close window"), self)
        close_tb_button.triggered.connect(self.StopAndRemoveUI)
        self._tb.AddButton(self.CLOSE_WINDOW_ID, close_tb_button)
        self._tb.AddSeparator()

        self.continue_bmp = get_app().GetImage("python/debugger/step_continue.png")
        continue_tb_button = QAction(
            self.continue_bmp, _("Continue execution"), self)
        continue_tb_button.triggered.connect(self.OnContinue)
        self._tb.AddButton(menuitems.ID_STEP_CONTINUE, continue_tb_button)
        self.SIG_DEBUG_INTERNAL.connect(self.OnContinue)

        self.break_bmp = get_app().GetImage("python/debugger/break_into.png")
        break_tb_button = QAction(
            self.break_bmp, _("Break into debugger"), self)
        break_tb_button.triggered.connect(self.BreakExecution)
        self._tb.AddButton(menuitems.ID_BREAK_INTO_DEBUGGER, break_tb_button)

        self.stop_bmp = get_app().GetImage("python/debugger/stop.png")
        stop_tb_button = QAction(self.stop_bmp, _("Stop debugging"), self)
        stop_tb_button.triggered.connect(self.StopExecution)
        self._tb.AddButton(self.KILL_PROCESS_ID, stop_tb_button)

        self.restart_bmp = get_app().GetImage("python/debugger/restart_debugger.png")
        restart_tb_button = QAction(
            self.restart_bmp, _("Restart debugging"), self)
        restart_tb_button.triggered.connect(self.RestartDebugger)
        self._tb.AddButton(menuitems.ID_RESTART_DEBUGGER, restart_tb_button)

        self._tb.AddSeparator()
        # 表示运行下一行代码,快捷键为F10
        self.next_bmp = get_app().GetImage("python/debugger/step_next.png")
        step_next_tb_button = QAction(
            self.next_bmp, _("Step to next line"), self)
        step_next_tb_button.triggered.connect(self.OnNext)
        step_next_tb_button.setShortcut(
            MenubarMixin.KEY_BINDER.GetBinding(menuitems.ID_STEP_NEXT))
        self._tb.AddButton(menuitems.ID_STEP_NEXT, step_next_tb_button)

        self.step_bmp = get_app().GetImage("python/debugger/step_into.png")
        step_into_tb_button = QAction(self.step_bmp, _("Step in"), self)
        step_into_tb_button.triggered.connect(self.OnSingleStep)
        # 表示进入当前方法,快捷键为F11
        step_into_tb_button.setShortcut(
            MenubarMixin.KEY_BINDER.GetBinding(menuitems.ID_STEP_INTO))
        self._tb.AddButton(menuitems.ID_STEP_INTO, step_into_tb_button)
        # 表示退出当前方法,返回到调用层,快捷键为
        self.stepout_bmp = get_app().GetImage("python/debugger/step_return.png")
        step_return_tb_button = QAction(
            self.stepout_bmp, _("Stop at function return"), self)
        step_return_tb_button.triggered.connect(self.OnStepOut)
        self._tb.AddButton(menuitems.ID_STEP_OUT, step_return_tb_button)

        self._tb.AddSeparator()
        if _WATCHES_ON:
            self.quick_watch_bmp = watchs.getQuickAddWatchBitmap()
            quick_watch_tb_button = QAction(
                self.quick_watch_bmp, _("Quick add a watch"), self)
            quick_watch_tb_button.triggered.connect(self.OnQuickAddWatch)
            self._tb.AddButton(menuitems.ID_QUICK_ADD_WATCH,
                               quick_watch_tb_button)

            self.watch_bmp = watchs.getAddWatchBitmap()
            watch_tb_button = QAction(self.watch_bmp, _("Add a watch"), self)
            watch_tb_button.triggered.connect(self.OnAddWatch)
            self._tb.AddButton(menuitems.ID_ADD_WATCH, watch_tb_button)
            self._tb.AddSeparator()

        self.clear_bmp = get_app().GetImage("python/debugger/clear_output.png")
        clear_output_tb_button = QAction(
            self.clear_bmp, _("Clear output pane"), self)
        clear_output_tb_button.triggered.connect(self.OnClearOutput)
        self._tb.AddButton(self.CLEAR_ID, clear_output_tb_button)

    def OnSingleStep(self, callback=None):
        self._callback.SingleStep(callback)

    def OnContinue(self, event=None):
        self._callback.Continue()

    def OnStepOut(self, callback=None):
        self._callback.Return(callback)

    def OnNext(self, callback=None):
        self._callback.Next(callback)

    def BreakPointChange(self):
        if not self._stopped:
            # 更改断点时,重新发送断点信息给服务器
            self._callback.PushBreakpoints()

    def destroy(self):
        # See comment on PythonDebuggerUI.StopExecution
        self.StopExecution()
        BaseDebuggerUI.debuggers.remove(self)
        ttk.Frame.destroy(self)

    def DisableWhileDebuggerRunning(self):
        '''
        调试器运行时需要禁止的菜单
        '''
        if self._toolEnabled:
            self._tb.EnableTool(menuitems.ID_STEP_INTO, False)
            self._tb.EnableTool(menuitems.ID_STEP_CONTINUE, False)
            if self.run_menu.FindMenuItem(menuitems.ID_STEP_CONTINUE):
                self.run_menu.Enable(menuitems.ID_STEP_CONTINUE, False)
            self._tb.EnableTool(menuitems.ID_STEP_OUT, False)
            if self.run_menu.FindMenuItem(menuitems.ID_STEP_OUT):
                self.run_menu.Enable(menuitems.ID_STEP_OUT, False)
            self._tb.EnableTool(menuitems.ID_STEP_NEXT, False)
            self._tb.EnableTool(menuitems.ID_BREAK_INTO_DEBUGGER, True)
            if self.run_menu.FindMenuItem(menuitems.ID_BREAK_INTO_DEBUGGER):
                self.run_menu.Enable(menuitems.ID_BREAK_INTO_DEBUGGER, True)

            if _WATCHES_ON:
                self._tb.EnableTool(menuitems.ID_ADD_WATCH, False)
                self._tb.EnableTool(menuitems.ID_QUICK_ADD_WATCH, False)

            self.DeleteCurrentLineMarkers()

            if self.framestab:
                self.framestab.ClearWhileRunning()

            self._toolEnabled = False

    def EnableWhileDebuggerStopped(self):
        '''
        调试器中断时需要允许使用的菜单
        '''
        self._tb.EnableTool(menuitems.ID_STEP_INTO, True)
        self._tb.EnableTool(menuitems.ID_STEP_CONTINUE, True)
        if self.run_menu.FindMenuItem(menuitems.ID_STEP_CONTINUE):
            self.run_menu.Enable(menuitems.ID_STEP_CONTINUE, True)
        self._tb.EnableTool(menuitems.ID_STEP_OUT, True)
        if self.run_menu.FindMenuItem(menuitems.ID_STEP_OUT):
            self.run_menu.Enable(menuitems.ID_STEP_OUT, True)
        self._tb.EnableTool(menuitems.ID_STEP_NEXT, True)
        self._tb.EnableTool(menuitems.ID_BREAK_INTO_DEBUGGER, False)
        if self.run_menu.FindMenuItem(menuitems.ID_BREAK_INTO_DEBUGGER):
            self.run_menu.Enable(menuitems.ID_BREAK_INTO_DEBUGGER, False)
        self._tb.EnableTool(self.KILL_PROCESS_ID, True)
        if self.run_menu.FindMenuItem(menuitems.ID_TERMINATE_DEBUGGER):
            self.run_menu.Enable(menuitems.ID_TERMINATE_DEBUGGER, True)

        if _WATCHES_ON:
            self._tb.EnableTool(menuitems.ID_ADD_WATCH, True)
            self._tb.EnableTool(menuitems.ID_QUICK_ADD_WATCH, True)

        self._toolEnabled = True

    def DisableAfterStop(self):
        '''
        调试器停止时需要禁止的菜单
        '''
        if self._toolEnabled:
            self.DisableWhileDebuggerRunning()
            self._tb.EnableTool(menuitems.ID_BREAK_INTO_DEBUGGER, False)
            if self.run_menu.FindMenuItem(menuitems.ID_BREAK_INTO_DEBUGGER):
                self.run_menu.Enable(menuitems.ID_BREAK_INTO_DEBUGGER, False)
            self._tb.EnableTool(self.KILL_PROCESS_ID, False)
            if self.run_menu.FindMenuItem(menuitems.ID_TERMINATE_DEBUGGER):
                self.run_menu.Enable(menuitems.ID_TERMINATE_DEBUGGER, False)

    def ExecutorFinished(self, exitcode):
        if _VERBOSE:
            print("In ExectorFinished")
        try:
            self.DisableAfterStop()
            self.UpdatePagePaneText(_("Debugging"), _("Finished Debugging"))
            self._tb.EnableTool(self.KILL_PROCESS_ID, False)
            self.update_proc_exitcode(exitcode)
        except Exception:
            utils.get_logger().exception("finish debug executor exception:")
            # 关闭断点调式窗口,隐藏断点调式有关的菜单
            self._debugger.ShowHideDebuggerMenu(False)
            return
        if self._restarted:
            self.after(250, self.DoRestartDebugger)
        else:
            # 调式完成并且不是重启调试器的话,隐藏断点调式有关的菜单
            self._debugger.ShowHideDebuggerMenu(False)

    def DoRestartDebugger(self):
        self.RestartDebuggerProcess()
        self._restarted = False

    def SetStatusText(self, text):
        utils.update_statusbar(text)

    def BreakExecution(self):
        if not BaseDebuggerUI.DebuggerRunning():
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _("Debugger has been stopped.")
            )
            return
        self._callback.BreakExecution()

    def StopExecution(self):
        self._callback.ShutdownServer()

    def Execute(self, initialArgs, startIn, environment, onWebServer=False):
        assert False, "Execute not overridden"

    def SynchCurrentLine(self, filename, linenum, noArrow=False):
        self.DeleteCurrentLineMarkers()

        # Filename will be <string> if we're in a bit of code that was executed from
        # a string (rather than a file). I haven't been able to get the original string
        # for display.
        if filename == '<string>':
            return
        foundview = None
        opendocs = get_app().GetDocumentManager().GetDocuments()
        for opendoc in opendocs:
            # This ugliness to prevent comparison failing because the drive letter
            # gets lowercased occasionally. Don't know why that happens or why  it
            # only happens occasionally.
            if fileutils.ComparePath(opendoc.GetFilename(), filename):
                foundview = opendoc.GetFirstView()
                break

        if not foundview:
            if _VERBOSE:
                print("filename=", filename)
            docs = get_app().GetDocumentManager().CreateDocument(filename, DOC_SILENT)
            if not docs:
                return
            doc = docs[0]
            foundview = doc.GetFirstView()

        if foundview:
            foundview.GetFrame().SetFocus()
            foundview.Activate()
            foundview.GotoLine(linenum)

        if not noArrow:
            # 标记并高亮断点调试所在的行
            foundview.GetCtrl().MarkerAdd(linenum)

    def IsPythonDocument(self, opendoc):
        return utility.is_python_file(opendoc.GetFilename())

    def DeleteCurrentLineMarkers(self):
        open_docs = get_app().GetDocumentManager().GetDocuments()
        for open_doc in open_docs:
            if self.IsPythonDocument(open_doc):
                open_doc.GetFirstView().GetCtrl().ClearCurrentLineMarkers()

    def StopAndRemoveUI(self):
        if not self._stopped and self._executor is not None:
            ret = QMessageBox.question(
                self,
                _("Debugger running.."),
                _("Debugger is still running,Do you want to kill the debugger and remove it?")
            )
            if ret == QMessageBox.No:
                return False
        self.StopExecution()
        self.remove_page()
        if self._callback.IsWait():
            utils.get_logger().warn(
                "debugger callback is still wait for rpc when debugger stoped.will stop manualy")
            self._callback.StopWait()
        return True

    def OnAddWatch(self):
        self.framestab.AddWatchExpression("", "", False)

    def OnQuickAddWatch(self):
        self.framestab.AddWatchExpression("", "", True)

    def MakeFramesUI(self):
        assert False, "MakeFramesUI not overridden"

    def OnClearOutput(self):
        self.ClearOutput()

    def ClearOutput(self):
        self._textctrl.ClearOutput()

    def RestartDebugger(self):
        assert False, "RestartDebugger not overridden"


class PythonDebuggerUI(BaseDebuggerUI):
    debuggerPortList = None

    def __init__(self, parent, debugger, run_parameter, autoContinue=True):
        # Check for ports before creating the panel.
        if not PythonDebuggerUI.debuggerPortList:
            PythonDebuggerUI.NewPortRange()
        try:
            self._debuggerPort = str(PythonDebuggerUI.GetAvailablePort())
            self._guiPort = str(PythonDebuggerUI.GetAvailablePort())
            self._debuggerBreakPort = str(PythonDebuggerUI.GetAvailablePort())
        except RuntimeError:
            self._debuggerPort = '0'
            self._guiPort = '0'
            self._debuggerBreakPort = '0'
        self._debuggerHost = self._guiHost = utils.profile_get(
            "DebuggerHostName",
            debugconfig.DEFAULT_HOST
        )
        BaseDebuggerUI.__init__(self, parent, debugger, run_parameter)
        self._run_parameter = run_parameter
        self._autoContinue = autoContinue
        self._callback = None

        self.CreateCallBack()
        self.CreateExecutor()
        self._stopped = False

    @staticmethod
    def GetAvailablePort():
        for index in range(0, len(PythonDebuggerUI.debuggerPortList)):
            port = PythonDebuggerUI.debuggerPortList[index]
            if PythonDebuggerUI.PortAvailable(port):
                PythonDebuggerUI.debuggerPortList.pop(index)
                return port
        QMessageBox.critical(
            get_app().MainFrame,
            _("Out of Ports"),
            _("Out of ports for debugging! Please restart the application builder.\nIf that does not work, check for your debugger host address or the debugger server is running.")
        )
        raise RuntimeError("Out of ports for debugger.")

    @staticmethod
    def ReturnPortToPool(port):
        config = wx.ConfigBase_Get()
        starting_port = config.ReadInt("DebuggerStartingPort", DEFAULT_PORT)
        val = int(starting_port) + int(PORT_COUNT)
        if int(port) >= starting_port and (int(port) <= val):
            PythonDebuggerUI.debuggerPortList.append(int(port))

    @staticmethod
    def PortAvailable(port):
        hostname = utils.profile_get(
            "DebuggerHostName", debugconfig.DEFAULT_HOST)
        try:
            server = AGXMLRPCServer((hostname, port))
            server.server_close()
            if _VERBOSE:
                print("Port ", str(port), " available.")
            return True
        except:
            utils.get_logger().exception('')
            if _VERBOSE:
                print("Port ", str(port), " unavailable.")
            return False

    @staticmethod
    def NewPortRange():
        starting_port = utils.profile_get_int(
            "DebuggerStartingPort", debugconfig.DEFAULT_PORT)
        PythonDebuggerUI.debuggerPortList = list(
            range(starting_port, starting_port + debugconfig.PORT_COUNT)
        )

    def CreateExecutor(self):
        script_path = os.path.dirname(debuggerharness.__file__)
        if debuggerharness.__file__.find('.pyc') == -1:
            utils.get_logger().info("Starting debugger on these ports: %s, %s, %s",
                                    self._debuggerPort, self._guiPort, self._debuggerBreakPort)
        path = os.path.join(script_path, "debuggerharness.py")
        if int(self._debuggerPort) != 0:
            self._executor = PythonDebuggerExecutor(
                path,
                self._run_parameter,
                self,
                self._debuggerHost,
                self._debuggerPort,
                self._debuggerBreakPort,
                self._guiHost,
                self._guiPort,
                self._run_parameter.FilePath
            )
        # 在多线程中以信号的方式发送标准输出
        self.SIG_UPDATE_STDTEXT.connect(self.AppendStdoutText)
        # 在多线程中以信号的方式发送错误输出
        self.SIG_UPDATE_ERRTEXT.connect(self.AppendStdErrorText)
        # 在多线程中以信号的方式发送进程结束消息
        self.SIG_EXECUTE_FINISHED.connect(self.ExecutorFinished)

    def LoadPythonFramesList(self, framesxml):
        self.framestab.LoadFramesList(framesxml)
        # 进入断掉调试,更新监视的值
        self.framestab.UpdateWatchs()

    def Execute(self, onWebServer=False):
        self._callback.Start()
        if self._executor is not None:
            self._executor.Execute()
            self.update_startup_command()
            self._callback.WaitForRPC()

    def StopExecution(self):
        # This is a general comment on shutdown for the running and debugged processes.
        # Basically, the.
        # current state of this is the result of trial and error coding. The common problems
        # were memory.
        # access violations and threads that would not exit. Making the OutputReaderThreads
        # daemons seems.
        # to have side-stepped the hung thread issue. Being very careful not to touch things
        # after calling.
        # process.py:ProcessOpen.kill() also seems to have fixed the memory access violations,
        # but if there.
        # were more ugliness discovered I would not be surprised. If anyone has any help/advice,
        # please send.
        # it on to mfryer@activegrid.com.
        if not self._stopped:
            self.DisableAfterStop()
            try:
                self._callback.ShutdownServer()
            except:
                utils.get_logger().exception('')

            try:
                self.DeleteCurrentLineMarkers()
            except:
                pass
            try:
                PythonDebuggerUI.ReturnPortToPool(self._debuggerPort)
                PythonDebuggerUI.ReturnPortToPool(self._guiPort)
                PythonDebuggerUI.ReturnPortToPool(self._debuggerBreakPort)
            except:
                pass
            try:
                if self._executor:
                    self._executor.DoStopExecution()
                    self.framestab.ResetWatchs()
            except:
                utils.get_logger().exception('')
            self._stopped = True

    def MakeFramesUI(self):
        panel = PythonFramesUI(self)
        return panel

    def UpdateWatch(self, watch_obj, item):
        self.framestab.UpdateWatch(watch_obj, item)

    def UpdateWatchs(self, reset=False):
        self.framestab.UpdateWatchs(reset)

    def OnSingleStep(self):
        # 进入方法之后更新监视值
        BaseDebuggerUI.OnSingleStep(self, callback=self.UpdateWatchs)

    def OnContinue(self, event=None):
        BaseDebuggerUI.OnContinue(self, event)

    def OnStepOut(self):
        # 退出方法之后更新监视值
        BaseDebuggerUI.OnStepOut(self, callback=self.UpdateWatchs)

    def OnNext(self):
        # 单步调试之后更新监视值
        BaseDebuggerUI.OnNext(self, callback=self.UpdateWatchs)

    def DisableWhileDebuggerRunning(self):
        BaseDebuggerUI.DisableWhileDebuggerRunning(self)
        # 运行调试器,在执行下一步调试的空隙,这个时间段调试器是没有运行的,故需要重置监视值
        self.UpdateWatchs(reset=True)

    def CreateCallBack(self):
        url = 'http://' + self._debuggerHost + ':' + self._debuggerPort + '/'
        self._breakURL = 'http://' + self._debuggerHost + \
            ':' + self._debuggerBreakPort + '/'
        self._callback = PythonDebuggerCallback(
            self._guiHost, self._guiPort, url, self._breakURL, self, self._autoContinue)

    def RestartDebugger(self):
        currentproj = self._debugger.GetCurrentProject()
        if currentproj is not None and currentproj.GetModel().FindFile(self._run_parameter.FilePath):
            currentproj.PromptToSaveFiles()
        else:
            openview = utils.GetOpenView(self._run_parameter.FilePath)
            if openview:
                opendoc = openview.GetDocument()
                opendoc.Save()

        if not self._stopped:
            self._restarted = True
            self.StopExecution()
        else:
            self.RestartDebuggerProcess()

    def RestartDebuggerProcess(self):

        if BaseDebuggerUI.DebuggerRunning():
            messagebox.showinfo(_("Debugger Running"), _(
                "A debugger is already running. Please shut down the other debugger first."))
            return

        self.OnClearOutput()
        self._tb.EnableTool(self.KILL_PROCESS_ID, True)
        self._stopped = False
        self.CheckPortAvailable()
        self.CreateCallBack()
        self.CreateExecutor()
        self.UpdatePagePaneText(_("Finished Debugging"), _("Debugging"))
        self.Execute()

    def CheckPortAvailable(self):

        if not PythonDebuggerUI.PortAvailable(int(self._debuggerBreakPort)):
            old_debuggerbreak_port = self._debuggerBreakPort
            self._debuggerPort = str(PythonDebuggerUI.GetAvailablePort())
            utils.get_logger().warn(
                "debugger break server port %s is not available,will use new port %s",
                old_debuggerbreak_port,
                self._debuggerPort
            )

        else:
            utils.get_logger().debug(
                "when restart debugger ,break server port %s is still available",
                self._debuggerBreakPort
            )

        if not PythonDebuggerUI.PortAvailable(int(self._guiPort)):
            old_gui_port = self._guiPort
            self._guiPort = str(PythonDebuggerUI.GetAvailablePort())
            utils.get_logger().warn(
                "debugger gui server port %s is not available,will use new port %s",
                old_gui_port,
                self._guiPort
            )

        else:
            utils.get_logger().debug(
                "when restart debugger ,gui server port %s is still available", self._guiPort)

        if not PythonDebuggerUI.PortAvailable(int(self._debuggerPort)):
            old_debugger_port = self._debuggerPort
            self._debuggerPort = str(PythonDebuggerUI.GetAvailablePort())
            utils.get_logger().warn("debugger server port %s is not available,will use new port %s",
                                    old_debugger_port, self._debuggerPort)
        else:
            utils.get_logger().debug(
                "when restart debugger ,debugger server port %s is still available",
                self._debuggerPort
            )


class BaseFramesUI:

    THING_COLUMN_WIDTH = 175

    def __init__(self, output):
        self._output = output
        self._debugger = self._output._debugger

    def ExecuteCommand(self, command):
        assert False, "ExecuteCommand not overridden"

    def ClearWhileRunning(self):
        self.stackFrameTab.frames_choice_ctrl.clear()
        self.stackFrameTab.frames_choice_ctrl.setEnabled(False)
        root = self.stackFrameTab._root
        self.stackFrameTab.DeleteChildren(root)
        self.inspectConsoleTab.inputctrl.setEnabled(False)
        self.inspectConsoleTab.outputctrl.setEnabled(False)

    def LoadFramesList(self, frames_xml):
        assert False, "LoadFramesList not overridden"

    def AppendText(self, event):
        self._output.AppendText(event)

    def AppendErrorText(self, event):
        self._output.AppendErrorText(event)


class PythonFramesUI(BaseFramesUI):
    def __init__(self, output):
        BaseFramesUI.__init__(self, output)
        # 强制显示断点调式有关的视图
        self.breakPointsTab = get_app().MainFrame.GetView(constants.BREAKPOINTS_TAB_NAME)
        self.stackFrameTab = get_app().MainFrame.GetView(constants.STACKFRAME_TAB_NAME)
        self.inspectConsoleTab = get_app().MainFrame.GetView(
            constants.INTERACTCONSOLE_TAB_NAME)
        self.watchsTab = get_app().MainFrame.GetView(constants.WATCH_TAB_NAME)

    def SetExecutor(self, executor):
        self._textCtrl.SetExecutor(executor)

    def ExecuteCommand(self, command):
        '''
        在交互窗口中执行解释器命令,并将执行的结果反馈到堆栈窗口中
        '''
        self.inspectConsoleTab.append_command(">>> " + command)

        frame_value = self.stackFrameTab.get_frame_value()
        retval = self._output._callback._debuggerServer.execute_in_frame(
            frame_value,
            command
        )
        self.inspectConsoleTab.append_output(str(retval))
        # Refresh the tree view in case this command resulted in changes there. TODO: Need to
        # reopen tree items.
        self.stackFrameTab.PopulateTreeFromFrameMessage(frame_value)

    def AddWatchExpression(self, name, expression, quick_watch):
        if quick_watch:
            title = _("Quick add a watch")
        else:
            title = _("Add a watch")
        watch_obj = watchs.Watch.CreateWatch(name, expression)
        if hasattr(self.stackFrameTab, '_parentChain'):
            wd = watchs.WatchDialog(
                get_app().GetTopWindow(),
                title,
                self.stackFrameTab._parentChain,
                watch_obj=watch_obj,
                is_quick_watch=quick_watch
            )
        else:
            wd = watchs.WatchDialog(
                get_app().GetTopWindow(),
                title,
                None,
                watch_obj=watch_obj,
                is_quick_watch=quick_watch
            )
        if wd.exec_() == QDialog.Accepted:
            watch_obj = wd.GetSettings()
            self.AddtoWatchExpression(watch_obj.Name, watch_obj.Expression)

    def AddtoWatchExpression(self, name, expression):
        watch_obj = watchs.Watch.CreateWatch(name, expression)
        if not BaseDebuggerUI.DebuggerRunning() or not self.stackFrameTab.HasStack():
            self.watchsTab.AppendErrorWatch(
                watch_obj, self.watchsTab.GetRootItem())
        else:
            nodelist = self.stackFrameTab.GetWatchList(watch_obj)
            if len(nodelist) == 1:
                self.watchsTab.AddWatch(
                    nodelist[0].childNodes[0], watch_obj, self.watchsTab.GetRootItem())

    # when step next,into,out action,will update watchs value
    def UpdateWatch(self, watch_obj, item):
        nodelist = self.stackFrameTab.GetWatchList(watch_obj)
        if len(nodelist) == 1:
            self.watchsTab.UpdateWatch(
                nodelist[0].childNodes[0], watch_obj, item)

    def UpdateWatchs(self, reset=False):
        if not reset:
            self.watchsTab.UpdateWatchs()
        else:
            self.ResetWatchs()

    def ResetWatchs(self):
        self.watchsTab.ResetWatchs()

    def SynchCurrentLine(self, file, line):
        self._output.SynchCurrentLine(file, int(line))

    @ui_utils.wait_cursor
    def LoadFramesList(self, framesXML):
        self.inspectConsoleTab.inputctrl.setEnabled(True)
        self.inspectConsoleTab.outputctrl.setEnabled(True)
        try:
            dom_doc = parseString(framesXML)
            self.stackFrameTab.LoadFrame(dom_doc)
        except:
            utils.get_logger().exception('load frames')

    def attempt_introspection(self, message, chain):
        return self._output._callback._debuggerServer.attempt_introspection(message, chain)

    def request_frame_document(self, message):
        return self._output._callback._debuggerServer.request_frame_document(message)

    def add_watch(self, message, watch_data):
        return self._output._callback._debuggerServer.add_watch(watch_data.Name, watch_data.Expression, message, watch_data.IsRunOnce())


class Interaction:
    def __init__(self, message, framesXML, info=None, quit=False):
        self._framesXML = framesXML
        self._message = message
        self._info = info
        self._quit = quit

    def getFramesXML(self):
        return self._framesXML

    def getMessage(self):
        return self._message

    def getInfo(self):
        return self._info

    def getQuit(self):
        return self._quit


class RequestHandlerThread(threading.Thread):
    def __init__(self, debuggerUI, queue, address):
        threading.Thread.__init__(self)
        self._keep_going = True
        self._queue = queue
        self._address = address
        self._server = None
        # 连接rpc调试服务器
        try:
            self._server = AGXMLRPCServer(self._address, logRequests=0)
        except Exception as e:
            # 连接调试服务器失败
            QMessageBox.critical(
                get_app().GetTopWindow(),
                _('Error'),
                _('Connect Debugger server fail.%s') % str(e)
            )
            return
        self._server.register_function(self.interaction)
        self._server.register_function(self.quit)
        self._server.register_function(self.dummyOperation)
        self._server.register_function(self.request_input)
        self._debuggerUI = debuggerUI
        self._input_text = ""
        if _VERBOSE:
            print("RequestHandlerThread on fileno %s" %
                  str(self._server.fileno()))

    def run(self):
        while self._keep_going and self._server:
            try:
                self._server.handle_request()
            except:
                utils.get_logger().exception('')
                self._keep_going = False
        if _VERBOSE:
            print("Exiting Request Handler Thread.")

    def interaction(self, message, framexml, info):
        if _VERBOSE:
            print("In RequestHandlerThread.interaction -- adding to queue")
        interaction = Interaction(message, framexml, info)
        self._queue.put(interaction)
        return ""

    def quit(self):
        interaction = Interaction(None, None, info=None, quit=True)
        self._queue.put(interaction)
        return ""

    def dummyOperation(self):
        return ""

    def request_input(self):
        # create a thread event
        self.input_evt = threading.Event()
        self.get_input_text()
        # block until the event activated
        self.input_evt.wait()
        return self._input_text

#    @utils.call_after
    def get_input_text(self):
        text = tkSimpleDialog.askstring(
            _("Enter input"),
            _("Enter the input text:")
        )
        if text:
            self._input_text = text
            self._debuggerUI._textCtrl.AddInputText(self._input_text)
        else:
            # simulate the keyboard interrupt when cancel button is pressed
            self._input_text = None
        # activated the event,then the input will return
        self.input_evt.set()

    def AskToStop(self):
        if self._server is not None:
            try:
                # This is a really ugly way to make sure this thread isn't blocked in
                # handle_request.
                url = 'http://' + self._address[0] + \
                    ':' + str(self._address[1]) + '/'
                temp_server = xmlrpclib.ServerProxy(url, allow_none=1)
                temp_server.dummyOperation()
                self._keep_going = False
            except:
                utils.get_logger().exception('')
            self._server.server_close()


class RequestBreakThread(threading.Thread):
    def __init__(self, server, interrupt=False, pushBreakpoints=False, breakDict=None, kill=False):
        threading.Thread.__init__(self)
        self._server = server

        self._interrupt = interrupt
        self._pushBreakpoints = pushBreakpoints
        self._breakDict = breakDict
        self._kill = kill

    def run(self):
        try:
            if _VERBOSE:
                print("RequestBreakThread, before call")
            if self._interrupt:
                self._server.break_requested()
            if self._pushBreakpoints:
                self._server.update_breakpoints(
                    xmlrpclib.Binary(pickle.dumps(self._breakDict)))
            if self._kill:
                try:
                    self._server.die()
                except:
                    pass
            if _VERBOSE:
                print("RequestBreakThread, after call")
        except:
            utils.get_logger().exception('')


class DebuggerOperationThread(threading.Thread):
    def __init__(self, function):
        threading.Thread.__init__(self)
        self._function = function

    def run(self):
        if _VERBOSE:
            print("In DOT, before call")
        try:
            self._function()
        except:
            utils.get_logger().exception('')
        if _VERBOSE:
            print("In DOT, after call")


class BaseDebuggerCallback:

    def Start(self):
        assert False, "Start not overridden"

    def ShutdownServer(self):
        assert False, "ShutdownServer not overridden"

    def BreakExecution(self):
        assert False, "BreakExecution not overridden"

    def SingleStep(self, callback=None):
        assert False, "SingleStep not overridden"

    def Next(self, callback=None):
        assert False, "Next not overridden"

    def Continue(self):
        assert False, "Start not overridden"

    def Return(self, callback=None):
        assert False, "Return not overridden"

    def PushBreakpoints(self):
        assert False, "PushBreakpoints not overridden"


class PythonDebuggerCallback(BaseDebuggerCallback):

    def __init__(self, host, port, debugger_url, break_url, debugger_ui, auto_continue=False):
        if _VERBOSE:
            print("+++++++ Creating server on port, ", str(port))
        self._timer = None
        self._queue = Queue.Queue(50)
        self._host = host
        self._port = int(port)
        threading._VERBOSE = _VERBOSE
        self._serverHandlerThread = RequestHandlerThread(
            debugger_ui, self._queue, (self._host, self._port))

        self._debugger_url = debugger_url
        self._debuggerServer = None
        self._waiting = False
        self._debuggerUI = debugger_ui
        self._break_url = break_url
        self._breakServer = None
        self._firstInteraction = True
        self._pendingBreak = False
        self._autoContinue = auto_continue

    def Start(self):
        self._serverHandlerThread.start()

    def ShutdownServer(self):
        self._waiting = False
        if self._serverHandlerThread:
            self._serverHandlerThread.AskToStop()
            self._serverHandlerThread = None

    def CheckBreakServer(self):
        if self._breakServer is None:
            QMessageBox.critical(
                get_app().GetTopWindow(),
                get_app().GetAppName(),
                _("Could not connect to break server!")
            )
            return False
        return True

    def BreakExecution(self):
        if not self.CheckBreakServer():
            return
        rbt = RequestBreakThread(self._breakServer, interrupt=True)
        rbt.start()

    def SingleStep(self, callback):
        '''
        进入当前方法
        '''
        # 执行下一步调试之前,在没有返回之前需要先禁止一些东西
        self._debuggerUI.DisableWhileDebuggerRunning()
        self._debuggerServer.set_step()  # Figure out where to set allowNone
        self.WaitForRPC(callback)

    def Next(self, callback):
        '''
        运行下一行代码
        '''
        # 执行下一步调试之前,在没有返回之前需要先禁止一些东西
        self._debuggerUI.DisableWhileDebuggerRunning()
        self._debuggerServer.set_next()
        self.WaitForRPC(callback)

    def Continue(self):
        self._debuggerUI.DisableWhileDebuggerRunning()
        self._debuggerServer.set_continue()
        self.WaitForRPC()

    def Return(self, callback):
        '''
        退出当前方法，返回到调用层
        '''
        # 执行下一步调试之前,在没有返回之前需要先禁止一些东西
        self._debuggerUI.DisableWhileDebuggerRunning()
        self._debuggerServer.set_return()
        self.WaitForRPC(callback)

    def ReadQueue(self):
        if self._queue.qsize():
            try:
                item = self._queue.get_nowait()
                if item.getQuit():
                    self.interaction(None, None, None, True)
                else:
                    data = bz2.decompress(item.getFramesXML().data)
                    self.interaction(item.getMessage().data,
                                     data, item.getInfo(), False)
            except Queue.Empty:
                pass

    def PushBreakpoints(self):

        if not self.CheckBreakServer():
            return

        rbt = RequestBreakThread(self._breakServer, pushBreakpoints=True,
                                 breakDict=self._debuggerUI.framestab.breakPointsTab.GetMasterBreakpointDict())
        rbt.start()

    def PushExceptionBreakpoints(self):
        '''
        添加异常中断
        '''
        self._debuggerServer.set_all_exceptions(
            self._debuggerUI._debugger.GetExceptions())

    def WaitForRPC(self, callback=None):
        self._waiting = True
        self.RotateForRpc(callback)

    def RotateForRpc(self, callback):
        if not self._waiting:
            utils.get_logger().debug("Exiting WaitForRPC.")
            if callback:
                utils.get_logger().debug("After exit rpc,callback.....")
                callback()
            return
        # 1000毫秒设置的正好,不能设置得太长也不能设置得太短,设置太短程序会很卡
        QTimer.singleShot(1000, lambda: self.RotateForRpc(callback))
        try:
            self.ReadQueue()
            time.sleep(0.02)
        except:
            utils.get_logger().exception('')

    def interaction(self, message, frameXML, info, quit):

        # This method should be hit as the debugger starts.
        # if the debugger starts.then show the debugger menu
        if self._firstInteraction:
            # 断点调试时显示断点调式有关的菜单
            self._debuggerUI._debugger.ShowHideDebuggerMenu()
            self._firstInteraction = False
            self._debuggerServer = xmlrpclib.ServerProxy(
                self._debugger_url, allow_none=1)
            self._breakServer = xmlrpclib.ServerProxy(
                self._break_url, allow_none=1)
            self.PushBreakpoints()
            if self._debuggerUI._debugger.GetExceptions():
                self.PushExceptionBreakpoints()
        self._waiting = False
        if _VERBOSE:
            print("+" * 40)
        # quit gui server
        if quit:
            # whhen quit gui server stop the debugger execution
            self._debuggerUI.StopExecution()
            return ""
        if info != '':
            utils.get_logger().error("Hit interaction with exception")
            self._debuggerUI.SetStatusText("Got exception: " + str(info))
        else:
            if _VERBOSE:
                print("Hit interaction no exception")
        # if not self._autoContinue:
        if isinstance(message, bytes):
            message = ensure_string(message)
        self._debuggerUI.SetStatusText(message)
        if not self._autoContinue:
            self._debuggerUI.LoadPythonFramesList(frameXML)
            self._debuggerUI.EnableWhileDebuggerStopped()

        if self._autoContinue:
            self._timer = QTimer(self._debuggerUI)
            self._timer.setSingleShot(True)
            self._timer.timeout.connect(self.DoContinue)
            self._autoContinue = False
            self._timer.start(250)
        if _VERBOSE:
            print("+" * 40)

    def DoContinue(self):
        self._timer.stop()
        self._debuggerUI.SIG_DEBUG_INTERNAL.emit()
        if _VERBOSE:
            print("Event Continue posted")

    def SendRunEvent(self):
        class SendEventThread(threading.Thread):
            def __init__(self):
                threading.Thread.__init__(self)

            def run(self):
                dbg_service = wx.GetApp().GetService(DebuggerService)
                evt = DebugInternalWebServer()
                evt.SetId(DebuggerService.DEBUG_WEBSERVER_NOW_RUN_PROJECT_ID)
                wx.PostEvent(dbg_service._frame, evt)
                print("Event posted")
        set = SendEventThread()
        set.start()

    def IsWait(self):
        return self._waiting

    def StopWait(self):
        assert self._waiting
        self.ShutdownServer()
