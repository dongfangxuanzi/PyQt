from .. import _
from ..lib.pyqt import QCheckBox, Qt
from ..util import ui_utils, utils
from .. import globalkeys


class SearchTextOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    """

    def __init__(self, master):
        """
        Initializes the panel by adding an "Options" folder tab to the parent notebook and
        populating the panel with the generic properties of a pydocview application.
        """
        super().__init__(master)
        self.inspect_file_encoding_checkbox = QCheckBox(
            _("Inspect file encoding(Default utf8) When search text in files"))
        self.layout.addWidget(self.inspect_file_encoding_checkbox)
        self.inspect_file_encoding_checkbox.setChecked(
            utils.profile_get_int(globalkeys.INSPECT_FILEENCODING_KEY, True))

        self.skip_binary_files_checkbox = QCheckBox(
            _("Skip binary files"))
        self.layout.addWidget(self.skip_binary_files_checkbox)
        self.skip_binary_files_checkbox.setChecked(
            utils.profile_get_int(globalkeys.SKIP_BINARY_FILES_KEY, True))
        self.inspect_file_encoding_checkbox.clicked.connect(self.__inspect_checkbox_clicked)
        self.__inspect_checkbox_clicked()
        self.layout.setAlignment(Qt.AlignTop)

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        utils.profile_set(globalkeys.INSPECT_FILEENCODING_KEY,
                          self.inspect_file_encoding_checkbox.isChecked())

        utils.profile_set(globalkeys.SKIP_BINARY_FILES_KEY,
                          self.skip_binary_files_checkbox.isChecked())
        return True

    def __inspect_checkbox_clicked(self):
        if self.inspect_file_encoding_checkbox.isChecked():
            self.skip_binary_files_checkbox.setEnabled(True)
        else:
            self.skip_binary_files_checkbox.setEnabled(False)
