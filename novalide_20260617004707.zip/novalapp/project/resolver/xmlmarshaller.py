'''
-------------------------------------------------------------------------------
Name:        xmlmarshaller.py
Purpose:
Author:      wukan
Created:     2019-02-15
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
from __future__ import print_function
import sys
from types import *
import logging
import xml.sax
import xml.sax.handler
import xml.sax.saxutils
import datetime
from . import utillang
from . import objutils

MODULE_PATH = "__main__"


"""
Special attributes that we recognize:

name: __xmlname__
type: string
description: the name of the xml element for the marshalled object

name: __xmlattributes__
type: tuple or list
description: the name(s) of the Lang string attribute(s) to be
marshalled as xml attributes instead of nested xml elements. currently
these can only be strings since there"s not a way to get the type
information back when unmarshalling.

name: __xmlexclude__
type: tuple or list
description: the name(s) of the lang attribute(s) to skip when
marshalling.

name: __xmlrename__
type: dict
description: describes an alternate Lang <-> XML name mapping.
Normally the name mapping is the identity function.  __xmlrename__
overrides that.  The keys are the Lang names, the values are their
associated XML names.

name: __xmlflattensequence__
type: dict, tuple, or list
description: the name(s) of the Lang sequence attribute(s) whose
items are to be marshalled as a series of xml elements (with an
optional keyword argument that specifies the element name to use) as
opposed to containing them in a separate sequence element, e.g.:

myseq = (1, 2)
<!-- normal way of marshalling -->
<myseq>
  <item objtype="int">1</item>
  <item objtype="int">2</item>
</myseq>
<!-- with __xmlflattensequence__ set to {"myseq": "squish"} -->
<squish objtype="int">1</squish>
<squish objtype="int">2</squish>

name: __xmlnamespaces__
type: dict
description: a dict of the namespaces that the object uses.  Each item
in the dict should consist of a prefix,url combination where the key is
the prefix and url is the value, e.g.:

__xmlnamespaces__ = { "xsd":"http://www.w3c.org/foo.xsd" }

name: __xmldefaultnamespace__
type: String
description: the prefix of a namespace defined in __xmlnamespaces__ that
should be used as the default namespace for the object.

name: __xmlattrnamespaces__
type: dict
description: a dict assigning the Lang object"s attributes to the namespaces
defined in __xmlnamespaces__.  Each item in the dict should consist of a
prefix,attributeList combination where the key is the prefix and the value is
a list of the Lang attribute names.  e.g.:

__xmlattrnamespaces__ = { "ag":["firstName", "lastName", "addressLine1", "city"] }

name: __xmlattrgroups__
type: dict
description: a dict specifying groups of attributes to be wrapped in an enclosing tag.
The key is the name of the enclosing tag; the value is a list of attributes to include
within it. e.g.

__xmlattrgroups__ = {"name": ["firstName", "lastName"], "address": ["addressLine1", "city", "state", "zip"]}

name: __xmlcdatacontent__
type: string
description: value is the name of a string attribute that should be assigned CDATA content from the
source document and that should be marshalled as CDATA.

__xmlcdatacontent__ = "messyContent"

"""
try:
    long
    unicode
    basestring
except:
    long = int
    unicode = str
    basestring = str

global xmlMarshallerLogger
xmlMarshallerLogger = logging.getLogger("novalide.util.xmlmarshaller.marshal")


def ag_className(obj):
    return obj.__class__.__name__


class Error(Exception):
    """Base class for errors in this module."""


class UnhandledTypeException(Error):
    """
    Exception raised when attempting to marshal an unsupported
    type.
    """

    def __init__(self, typename):
        self.typename = typename

    def __str__(self):
        return "%s is not supported for marshalling." % str(self.typename)


class XMLAttributeIsNotStringType(Error):
    """
    Exception raised when an object"s attribute is specified to be
    marshalled as an XML attribute of the enclosing object instead of
    a nested element.
    """

    def __init__(self, attrname, typename):
        self.attrname = attrname
        self.typename = typename

    def __str__(self):
        return """%s was set to be marshalled as an XML attribute
        instead of a nested element, but the object"s type is %s, not
        string.""" % (self.attrname, self.typename)


class MarshallerException(Exception):
    pass


class UnmarshallerException(Exception):
    pass

################################################################################
#
# constants and such
#
################################################################################


XMLNS = "xmlns"
XMLNS_PREFIX = XMLNS + ":"
XMLNS_PREFIX_LENGTH = len(XMLNS_PREFIX)
DEFAULT_NAMESPACE_KEY = "__DEFAULTNS__"
TYPE_QNAME = "QName"
XMLSCHEMA_XSD_URL = "http://www.w3.org/2001/XMLSchema"
AG_URL = "http://www.activegrid.com/ag.xsd"

BASETYPE_ELEMENT_NAME = "item"
DICT_ITEM_NAME = "qqDictItem"
DICT_ITEM_KEY_NAME = "key"
DICT_ITEM_VALUE_NAME = "value"

# This list doesn"t seem to be used.
#   Internal documentation or useless? You make the call!
# MEMBERS_TO_SKIP = ("__module__", "__doc__", "__xmlname__", "__xmlattributes__",
# "__xmlexclude__", "__xmlflattensequence__", "__xmlnamespaces__",
# "__xmldefaultnamespace__", "__xmlattrnamespaces__",
# "__xmlattrgroups__")

################################################################################
#
# classes and functions
#
################################################################################


def setattrignorecase(object, name, value):
    if name not in object.__dict__:
        namelow = name.lower()
        for attr in object.__dict__:
            if attr.lower() == namelow:
                object.__dict__[attr] = value
                return
    object.__dict__[name] = value


def getComplexType(obj):
    if hasattr(obj, '_instancexsdcomplextype'):
        return obj._instancexsdcomplextype
    if hasattr(obj, '__xsdcomplextype__'):
        return obj.__xsdcomplextype__
    return None


def _objectfactory(objtype, objargs=None, objclass=None):
    "dynamically create an object based on the objtype and return it."
    if not isinstance(objargs, list):
        objargs = [objargs]
    if objclass is not None:
        obj = None
        if len(objargs) > 0:
            if hasattr(objclass, '__xmlcdatacontent__'):
                obj = objclass()
                content_attr = obj.__xmlcdatacontent__
                obj.__dict__[content_attr] = str(objargs[0])
            else:
                obj = objclass(*objargs)
        else:
            obj = objclass()
        if ((obj is not None) and (hasattr(obj, 'postUnmarshal'))):
            obj.postUnmarshal()
        return obj
    return objutils.newInstance(objtype, objargs)


class GenericXMLObject:
    def __init__(self, content=None):
        if content is not None:
            self._content = content
            self.__xmlcontent__ = '_content'

    def __str__(self):
        return "GenericXMLObject(%s)" % objutils.toDiffableString(self.__dict__)

    def setXMLAttributes(self, xmlname, attrs=None, children=None, nsmap=None, defaultns=None):
        if xmlname is not None:
            i = xmlname.rfind(':')
            if i < 0:
                self.__xmlname__ = xmlname
                if defaultns is not None:
                    self.__xmldefaultnamespace__ = str(defaultns)
            else:
                self.__xmlname__ = xmlname[i + 1:]
                prefix = xmlname[:i]
                if prefix in nsmap:
                    self.__xmldefaultnamespace__ = str(nsmap[prefix])
        if attrs is not None:
            for attrname, attr in attrs.items():
                attrname = str(attrname)
                if attrname == XMLNS or attrname.startswith(XMLNS_PREFIX):
                    pass
                elif attrname == "objtype":
                    pass
                else:
                    if not hasattr(self, '__xmlattributes__'):
                        self.__xmlattributes__ = []
                    i = attrname.rfind(':')
                    if i >= 0:
                        prefix = attrname[:i]
                        attrname = attrname[i + 1:]
                        if not hasattr(self, '__xmlattrnamespaces__'):
                            self.__xmlattrnamespaces__ = {}
                        if self.__xmlattrnamespaces__.has_key(prefix):
                            alist = self.__xmlattrnamespaces__[prefix]
                        else:
                            alist = []
                        alist.append(attrname)
                        self.__xmlattrnamespaces__[prefix] = alist
                    self.__xmlattributes__.append(attrname)
            if hasattr(self, '__xmlattributes__'):
                self.__xmlattributes__.sort()
        if children is not None and len(children) > 0:
            childlist = []
            flattenlist = {}
            for childname, child in children:
                childstr = str(childname)
                if childstr in childlist:
                    if childstr not in flattenlist:
                        flattenlist[childstr] = (childstr,)
                else:
                    childlist.append(childstr)
            if len(flattenlist) > 0:
                self.__xmlflattensequence__ = flattenlist

    def initialize(self, arg1=None):
        pass


class Element:
    def __init__(self, name, attrs=None, xsname=None):
        self.name = name
        self.attrs = attrs
        self.content = ""
        self.children = []
        self.objclass = None
        self.xsname = xsname
        self.objtype = None

    def getobjtype(self):
        objtype = self.objtype
        if objtype is None:
            if len(self.children) > 0:
                objtype = "dict"
            else:
                objtype = "str"
        return objtype


class NsElement:
    def __init__(self):
        self.nsMap = {}
        self.targetNS = None
        self.defaultNS = None
        self.prefix = None

    def __str__(self):
        if self.prefix is None:
            strval = 'prefix = None; '
        else:
            strval = 'prefix = "%s"; ' % (self.prefix)
        if self.targetNS is None:
            strval += 'targetNS = None; '
        else:
            strval += 'targetNS = "%s"; ' % (self.targetNS)
        if self.defaultNS is None:
            strval += 'defaultNS = None; '
        else:
            strval += 'defaultNS = "%s"; ' % (self.defaultNS)
        if not self.nsMap:
            strval += 'nsMap = None; '
        else:
            strval += 'nsMap = {'
            for ik, iv in self.nsMap.iteritems():
                strval += '%s=%s; ' % (ik, iv)
            strval += '}'
        return strval

    def setKnownTypes(self, masterKnownTypes, masterKnownNamespaces, parentNSE):
        # if we're a nested element, extend our parent element's mapping
        if parentNSE is not None:
            self.knownTypes = parentNSE.knownTypes.copy()
            # but if we have a different default namespace, replace the parent's default mappings
            if self.defaultNS not in (None, parentNSE.defaultNS):
                new_kt = self.knownTypes.copy()
                for tag in new_kt:
                    if tag.find(':') < 0:
                        del self.knownTypes[tag]
            new_map = parentNSE.nsMap.copy()
            if self.nsMap != {}:
                for k, v in self.nsMap.iteritems():
                    new_map[k] = v
            self.nsMap = new_map
        else:
            self.knownTypes = {}
        reversed_kns = {}
        for long, short in masterKnownNamespaces.iteritems():
            reversed_kns[short] = long
        map_longs = self.nsMap.values()
        for tag, map_class in masterKnownTypes.iteritems():
            i = tag.rfind(':')
            if i >= 0:                                      # e.g. "wsdl:description"
                known_tag_short = tag[:i]                     # "wsdl"
                known_tag_name = tag[i + 1:]                    # "description"
                # e.g. "http://schemas.xmlsoap.org/wsdl"
                known_tag_long = reversed_kns[known_tag_short]
                if known_tag_long in map_longs:
                    for m_short, m_long in self.nsMap.iteritems():
                        if m_long == known_tag_long:
                            actual_short = m_short  # e.g. "ws"
                            actualtag = '%s:%s' % (actual_short, known_tag_name)
                            self.knownTypes[actualtag] = map_class
                            break
                if self.defaultNS == known_tag_long:
                    self.knownTypes[known_tag_name] = map_class
            else:                                           # e.g. "ItemSearchRequest"
                self.knownTypes[tag] = map_class

    def expandQName(self, eName, attrName, attrValue):
        big_value = attrValue
        i = attrValue.rfind(':')
        if i < 0:
            if self.defaultNS is not None:
                big_value = '%s:%s' % (self.defaultNS, attrValue)
        else:
            attr_ns = attrValue[:i]
            attr_ncname = attrValue[i + 1:]
            for short_ns, long_ns in self.nsMap.iteritems():
                if short_ns == attr_ns:
                    big_value = '%s:%s' % (long_ns, attr_ncname)
                    break
        return big_value


class XMLObjectFactory(xml.sax.ContentHandler):
    def __init__(self, knownTypes=None, knownNamespaces=None, xmlSource=None, createGenerics=False):
        self.rootelement = None
        if xmlSource is None:
            self.xmlSource = "unknown"
        else:
            self.xmlSource = xmlSource
        self.createGenerics = createGenerics
        self.skipper = False
        self.elementstack = []
        self.nsstack = []
        self.collectContent = None
        if knownNamespaces is None:
            self.knownNamespaces = {}
        else:
            self.knownNamespaces = knownNamespaces
        self.reversedNamespaces = {}
        for longns, shortns in self.knownNamespaces.items():
            self.reversedNamespaces[shortns] = longns
        self.knownTypes = {}
        if knownTypes is not None:
            for tag, cls in knownTypes.items():
                i = tag.rfind(':')
                if i >= 0:
                    shortns = tag[:i]
                    tag = tag[i + 1:]
                    if shortns not in self.reversedNamespaces:
                        error_string = 'Error unmarshalling XML document from source "%s": knownTypes specifies an unmapped short namespace "%s" for element "%s"' % (
                            self.xmlSource, shortns, tag)
                        raise UnmarshallerException(error_string)
                    longns = self.reversedNamespaces[shortns]
                    tag = '%s:%s' % (longns, tag)
                self.knownTypes[tag] = cls
        xml.sax.handler.ContentHandler.__init__(self)

    def appendElementStack(self, newElement, newNS):
        self.elementstack.append(newElement)
        if len(self.nsstack) > 0:
            oldns = self.nsstack[-1]
            if newNS.defaultNS is None:
                newNS.defaultNS = oldns.defaultNS
            if newNS.targetNS is None:
                newNS.targetNS = oldns.targetNS
            if not newNS.nsMap:
                newNS.nsMap = oldns.nsMap
            elif len(oldns.nsMap) > 0:
                map = oldns.nsMap.copy()
                map.update(newNS.nsMap)
                newNS.nsMap = map
        self.nsstack.append(newNS)
        return newNS

    def popElementStack(self):
        element = self.elementstack.pop()
        nse = self.nsstack.pop()
        return element, nse

    # ContentHandler methods
    def startElement(self, name, attrs):
        if name in ('xs:annotation', 'xsd:annotation'):  # should use namespace mapping here
            self.skipper = True
            self.appendElementStack(Element(name, attrs.copy()), NsElement())
        if self.skipper:
            return
        if self.collectContent is not None:
            str_val = '<%s' % (name)
            for a_key, a_val in attrs.items():
                str_val += (' %s="%s"' % (a_key, a_val))
            str_val += '>'
            self.collectContent.content += str_val
        xsname = name
        i = name.rfind(':')
        if i >= 0:
            nsname = name[:i]
            name = name[i + 1:]
        else:
            nsname = None
        element = Element(name, attrs.copy(), xsname=xsname)
        # if the element has namespace attributes, process them and add them to our stack
        nse = NsElement()
        objtype = None
        for k in attrs.getNames():
            if k.startswith('xmlns'):
                long_ns = attrs[k]
                e_long_ns = long_ns + '/'
                if str(e_long_ns) in self.knownNamespaces:
                    long_ns = e_long_ns
                if k == 'xmlns':
                    nse.defaultNS = long_ns
                else:
                    short_ns = k[6:]
                    nse.nsMap[short_ns] = long_ns
            elif k == 'targetNamespace':
                nse.targetNS = attrs.getValue(k)
            elif k == 'objtype':
                objtype = attrs.getValue(k)
        nse = self.appendElementStack(element, nse)
        if nsname is not None:
            if nsname in nse.nsMap:
                longname = '%s:%s' % (nse.nsMap[nsname], name)
            elif self.reversedNamespaces.has_key(nsname):
                longname = '%s:%s' % (self.reversedNamespaces[nsname], name)
            else:
                longname = xsname
        elif nse.defaultNS is not None:
            longname = '%s:%s' % (nse.defaultNS, name)
        else:
            longname = name
        element.objtype = objtype
        element.objclass = self.knownTypes.get(longname)
        if element.objclass == None and not self.knownNamespaces:
            # handles common case where tags are unqualified and knownTypes are too, but there's
            # a defaultNS.
            element.objclass = self.knownTypes.get(name)
        if hasattr(element.objclass, '__xmlcontent__'):
            self.collectContent = element

    def characters(self, content):
        if content is not None:
            if self.collectContent is not None:
                self.collectContent.content += content
            else:
                self.elementstack[-1].content += content

    def endElement(self, name):
        xsname = name
        i = name.rfind(':')
        if i >= 0:  # Strip namespace prefixes for now until actually looking them up in xsd
            name = name[i + 1:]
        if self.skipper:
            if xsname in ('xs:annotation', 'xsd:annotation'):     # here too
                self.skipper = False
                self.popElementStack()
            return
        if self.collectContent is not None:
            if xsname != self.collectContent.xsname:
                self.collectContent.content += ('</%s>' % (xsname))
                self.popElementStack()
                return
            self.collectContent = None
        old_children = self.elementstack[-1].children
        element, nse = self.popElementStack()
        if ((len(self.elementstack) > 1) and (self.elementstack[-1].getobjtype() == "None")):
            parent_element = self.elementstack[-2]
        elif len(self.elementstack) > 0:
            parent_element = self.elementstack[-1]
        objtype = element.getobjtype()
        if objtype == 'None':
            return
        constructorarglist = []
        if len(element.content) > 0:
            stripped_element_content = element.content.strip()
            if len(stripped_element_content) > 0:
                constructorarglist.append(element.content)
        # If the element requires an object, but none is known, use the GenericXMLObject class
        if ((element.objclass == None) and (element.attrs.get("objtype") == None) and ((len(element.attrs) > 0) or (len(element.children) > 0))):
            if self.createGenerics:
                element.objclass = GenericXMLObject
        obj = _objectfactory(objtype, constructorarglist, element.objclass)
        if element.objclass == GenericXMLObject:
            obj.setXMLAttributes(str(xsname), element.attrs,
                                 element.children, nse.nsMap, nse.defaultNS)
        complex_type = getComplexType(obj)
        if obj is not None:
            if (hasattr(obj, "__xmlname__") and getattr(obj, "__xmlname__") == "sequence"):
                self.elementstack[-1].children = old_children
                return
        if (len(element.attrs) > 0) and not isinstance(obj, list):
            for attrname, attr in element.attrs.items():
                if attrname == XMLNS or attrname.startswith(XMLNS_PREFIX):
                    if attrname.startswith(XMLNS_PREFIX):
                        ns = attrname[XMLNS_PREFIX_LENGTH:]
                    else:
                        ns = ""
                    if complex_type is not None or element.objclass == GenericXMLObject:
                        if not hasattr(obj, "__xmlnamespaces__"):
                            obj.__xmlnamespaces__ = {ns: attr}
                        elif ns not in obj.__xmlnamespaces__:
                            if (hasattr(obj.__class__, "__xmlnamespaces__")
                                    and (obj.__xmlnamespaces__ is obj.__class__.__xmlnamespaces__)):
                                obj.__xmlnamespaces__ = dict(
                                    obj.__xmlnamespaces__)
                            obj.__xmlnamespaces__[ns] = attr
                elif not attrname == "objtype":
                    # Strip namespace prefixes for now until actually looking them up in xsd
                    if attrname.find(":") > -1:
                        attrname = attrname[attrname.find(":") + 1:]
                    if complex_type is not None:
                        xsd_element = complex_type.findElement(attrname)
                        if xsd_element is not None:
                            type = xsd_element.type
                            if type is not None:
                                if type == TYPE_QNAME:
                                    attr = nse.expandQName(
                                        name, attrname, attr)
                                type = xsdToLangType(type)
                                if attrname == "maxOccurs" and attr == "unbounded":
                                    attr = "-1"
                                try:
                                    attr = _objectfactory(type, attr)
                                except Exception as except_data:
                                    error_string = 'Error unmarshalling attribute "%s" at line %d, column %d in XML document from source "%s": %s' % (
                                        attrname, self._locator.getLineNumber(), self._locator.getColumnNumber(), self.xmlSource, str(except_data))
                                    raise UnmarshallerException(error_string) from except_data
                    try:
                        setattrignorecase(
                            obj, _toAttrName(obj, attrname), attr)
                    except AttributeError as exc:
                        error_string = 'Error setting value of attribute "%s" at line %d, column %d in XML document from source "%s": object type of XML element "%s" is not specified or known' % (
                            attrname, self._locator.getLineNumber(), self._locator.getColumnNumber(), self.xmlSource, name)
                        raise UnmarshallerException(error_string) from exc
        # stuff any child attributes meant to be in a sequence via the __xmlflattensequence__
        flatten_dict = {}
        if hasattr(obj, "__xmlflattensequence__"):
            flatten = obj.__xmlflattensequence__
            if isinstance(flatten, dict):
                for sequencename, xmlnametuple in flatten.items():
                    if xmlnametuple is None:
                        flatten_dict[sequencename] = sequencename
                    elif (not isinstance(xmlnametuple, (tuple, list))):
                        flatten_dict[str(xmlnametuple)] = sequencename
                    else:
                        for xmlname in xmlnametuple:
                            flatten_dict[xmlname] = sequencename
            else:
                raise Exception(
                    "Invalid type for __xmlflattensequence___ : it must be a dict")

        # reattach an object"s attributes to it
        for childname, child in element.children:
            if childname in flatten_dict:
                sequencename = _toAttrName(obj, flatten_dict[childname])
                if not hasattr(obj, sequencename):
                    obj.__dict__[sequencename] = []
                sequencevalue = getattr(obj, sequencename)
                if sequencevalue is None:
                    obj.__dict__[sequencename] = []
                    sequencevalue = getattr(obj, sequencename)
                sequencevalue.append(child)
            elif objtype == 'list':
                obj.append(child)
            elif isinstance(obj, dict):
                if childname == DICT_ITEM_NAME:
                    obj[child[DICT_ITEM_KEY_NAME]] = child[DICT_ITEM_VALUE_NAME]
                else:
                    obj[childname] = child
            else:
                # don't replace a good attribute value with a bad one
                child_attr_name = _toAttrName(obj, childname)
                if (not hasattr(obj, child_attr_name)) or (getattr(obj, child_attr_name) == None) or (getattr(obj, child_attr_name) == []) or (not isinstance(child, GenericXMLObject)):
                    try:
                        setattrignorecase(obj, child_attr_name, child)
                    except AttributeError as exc:
                        raise MarshallerException(
                            'Error unmarshalling child element "%s" of XML element "%s": object type not specified or known' % (childname, name)) from exc

        if complex_type is not None:
            for element in complex_type.elements:
                if element.default:
                    element_name = _toAttrName(obj, element.name)
                    if ((element_name not in obj.__dict__) or (obj.__dict__[element_name] == None)):
                        lang_type = xsdToLangType(element.type)
                        default_value = _objectfactory(
                            lang_type, element.default)
                        obj.__dict__[element_name] = default_value

        if isinstance(obj, list):
            if ((element.attrs.has_key("mutable")) and (element.attrs.getValue("mutable") == "false")):
                obj = tuple(obj)

        if len(self.elementstack) > 0:
            parent_element.children.append((name, obj))
        else:
            self.rootelement = obj

    def getRootObject(self):
        return self.rootelement


def _toAttrName(obj, name):
    if hasattr(obj, '__xmlrename__'):
        for key, val in obj.__xmlrename__.items():
            if name == val:
                name = key
                break
# if (name.startswith("__") and not name.endswith("__")):
    return str(name)


def printKnownTypes(kt, where):
    print('KnownTypes from %s' % (where))
    for tag, cls in kt.iteritems():
        print('%s => %s' % (tag, str(cls)))


__typeMappingXsdToLang = {
    "string": "str",
    "char": "str",
    "varchar": "str",
    "date": "str",
    "boolean": "bool",
    "decimal": "float",
    "int": "int",
    "integer": "int",
    "long": "long",
    "float": "float",
    "bool": "bool",
    "str": "str",
    "unicode": "unicode",
    "short": "int",
    "duration": "str",  # see above (date)
    "datetime": "str",  # see above (date)
    "time": "str",  # see above (date)
    "double": "float",
    "QName": "str",
    "blob": "str",         # ag:blob
    "currency": "str",     # ag:currency
}


def xsdToLangType(xsdType):
    if xsdType.startswith(XMLSCHEMA_XSD_URL):
        xsdType = xsdType[len(XMLSCHEMA_XSD_URL) + 1:]
    elif xsdType.startswith(AG_URL):
        xsdType = xsdType[len(AG_URL) + 1:]
    lang_type = __typeMappingXsdToLang.get(xsdType)
    if lang_type is None:
        raise Exception("Unknown xsd type %s" % xsdType)
    return lang_type


def langToXsdType(langType):
    if langType in asDict(__typeMappingXsdToLang):
        return '%s:%s' % (XMLSCHEMA_XSD_URL, langType)
    return langType


def _getXmlValue(langValue):
    if isinstance(langValue, bool):
        return str(langValue).lower()
    if isinstance(langValue, unicode):
        return langValue.encode()
    return str(langValue)


def unmarshal(xmlstr, knownTypes=None, knownNamespaces=None, xmlSource=None, createGenerics=False):
    objectfactory = XMLObjectFactory(
        knownTypes, knownNamespaces, xmlSource, createGenerics)
    # on Linux, pyXML's sax.parseString fails when passed unicode
    if sys.platform != 'win32':
        xmlstr = str(xmlstr)
    try:
        xml.sax.parseString(xmlstr, objectfactory)
    except xml.sax.SAXParseException as error_data:
        if xmlSource is None:
            xmlSource = 'unknown'
        error_string = 'SAXParseException ("%s") detected at line %d, column %d in XML document from source "%s" ' % (
            error_data.getMessage(), error_data.getLineNumber(), error_data.getColumnNumber(), xmlSource)
        raise UnmarshallerException(error_string) from error_data
    return objectfactory.getRootObject()


def marshal(
    obj,
    elementName=None,
    prettyPrint=False,
    marshalType=True,
    indent=0,
    knownTypes=None,
    knownNamespaces=None,
    encoding=-1
):
    worker = XMLMarshalWorker(prettyPrint=prettyPrint, marshalType=marshalType,
                              knownTypes=knownTypes, knownNamespaces=knownNamespaces)
    if obj is not None and hasattr(obj, '__xmldeepexclude__'):
        worker.xmldeepexclude = obj.__xmldeepexclude__
    xmlstr = "".join(worker._marshal(obj, elementName, indent=indent))
    xmlMarshallerLogger.info(
        "marshal produced string of type %s", type(xmlstr))
    if encoding is None:
        return xmlstr
    if not isinstance(encoding, basestring):
        encoding = sys.getdefaultencoding()
    if not isinstance(xmlstr, unicode):
        xmlstr = xmlstr.decode()
    xmlstr = '<?xml version="1.0" encoding="%s"?>\n%s' % (encoding, xmlstr)
    return xmlstr.encode(encoding)


class XMLMarshalWorker:
    def __init__(self, marshalType=True, prettyPrint=False, knownTypes=None, knownNamespaces=None):
        if knownTypes is None:
            self.knownTypes = {}
        else:
            self.knownTypes = knownTypes
        if knownNamespaces is None:
            self.knownNamespaces = {}
        else:
            self.knownNamespaces = knownNamespaces
        self.prettyPrint = prettyPrint
        self.marshalType = marshalType
        self.xmldeepexclude = []
        self.nsstack = []

    def getNSPrefix(self):
        if len(self.nsstack) > 0:
            return self.nsstack[-1].prefix
        return ''

    def isKnownType(self, element_name):
        tag_long_ns = None
        nse = self.nsstack[-1]
        i = element_name.rfind(':')
        if i > 0:
            prefix = element_name[:i]
            name = element_name[i + 1:]
        else:
            prefix = DEFAULT_NAMESPACE_KEY
            name = element_name
        for short_ns, long_ns in nse.nameSpaces.items():
            if short_ns == prefix:
                tag_long_ns = long_ns
                break
        if tag_long_ns is None:
            known_tag_name = element_name
        else:
            known_short_ns = self.knownNamespaces[tag_long_ns]
            known_tag_name = known_short_ns + ':' + name
        if known_tag_name in self.knownTypes:
            knownclass = self.knownTypes[known_tag_name]
            return True
        return False

    def popNSStack(self):
        self.nsstack.pop()

    def appendNSStack(self, obj):
        name_spaces = {}
        default_long_ns = None
        for nse in self.nsstack:
            for k, v in nse.nsMap.items():
                name_spaces[k] = v
                if k == DEFAULT_NAMESPACE_KEY:
                    default_long_ns = v
        new_ns = NsElement()
        namespace_attrs = ""
        if hasattr(obj, "__xmlnamespaces__"):
            ns = getattr(obj, "__xmlnamespaces__")
            keys = list(ns.keys())
            keys.sort()
            for namespace_key in keys:
                name_space_url = ns[namespace_key]
                if name_space_url in name_spaces.values():
                    for k, v in name_spaces.iteritems():
                        if v == name_space_url:
                            namespace_key = k
                            break
                else:
                    if namespace_key == "":
                        default_long_ns = name_space_url
                        name_spaces[DEFAULT_NAMESPACE_KEY] = name_space_url
                        new_ns.nsMap[DEFAULT_NAMESPACE_KEY] = name_space_url
                        namespace_attrs += ' xmlns="%s" ' % (name_space_url)
                    else:
                        name_spaces[namespace_key] = name_space_url
                        new_ns.nsMap[namespace_key] = name_space_url
                        namespace_attrs += ' xmlns:%s="%s" ' % (
                            namespace_key, name_space_url)
            namespace_attrs = namespace_attrs.rstrip()
        if len(self.nsstack) > 0:
            new_ns.prefix = self.nsstack[-1].prefix
        else:
            new_ns.prefix = ''
        if obj is not None and hasattr(obj, "__xmldefaultnamespace__"):
            long_prefix_ns = getattr(obj, "__xmldefaultnamespace__")
            if long_prefix_ns == default_long_ns:
                new_ns.prefix = ''
            else:
                try:
                    for k, v in name_spaces.items():
                        if v == long_prefix_ns:
                            new_ns.prefix = k + ':'
                            break
                except:
                    if long_prefix_ns in self.knownNamespaces:
                        new_ns.prefix = self.knownNamespaces[long_prefix_ns] + ':'
                    else:
                        raise MarshallerException(
                            'Error marshalling __xmldefaultnamespace__ ("%s") not defined in namespace stack' % (long_prefix_ns))
        if obj is not None and hasattr(obj, "targetNamespace"):
            new_ns.targetNS = obj.targetNamespace
        elif len(self.nsstack) > 0:
            new_ns.targetNS = self.nsstack[-1].targetNS
        new_ns.nameSpaces = name_spaces
        self.nsstack.append(new_ns)
        return namespace_attrs

    def contractQName(self, value, obj, attr):
        value = langToXsdType(value)
        i = value.rfind(':')
        if i >= 0:
            long_ns = value[:i]
        else:
            # the value doesn't have a namespace and we couldn't map it to an XSD type...what to do?
            # (a) just write it, as is, and hope it's in the default namespace (for now)
            # (b) throw an exception so we can track down the bad code (later)
            return value
        if long_ns in self.nsstack[-1].nameSpaces.values():
            for k_short, v_long in self.nsstack[-1].nameSpaces.iteritems():
                if v_long == long_ns:
                    short_ns = k_short
                    break
        else:
            short_ns = long_ns    # if we can't find the long->short mappping, just use longNS
        if short_ns == DEFAULT_NAMESPACE_KEY:
            value = value[i + 1:]
        else:
            value = short_ns + ':' + value[i + 1:]
        return value

    def _genObjTypeStr(self, typeString):
        if self.marshalType:
            return ' objtype="%s"' % typeString
        return ""

    def _marshal(self, obj, elementName=None, nameSpacePrefix="", indent=0):
        if obj is not None:
            xmlMarshallerLogger.debug("--> _marshal: elementName=%s%s, type=%s, obj=%s, indent=%d",
                                      nameSpacePrefix, elementName, type(obj), str(obj), indent)
        else:
            xmlMarshallerLogger.debug(
                "--> _marshal: elementName=%s%s, obj is None, indent=%d",
                nameSpacePrefix,
                elementName,
                indent
            )
        if ((obj is not None) and (hasattr(obj, 'preMarshal'))):
            obj.preMarshal()
        exclude_attrs = []
        exclude_attrs.extend(self.xmldeepexclude)
        if hasattr(obj, "__xmlexclude__"):
            exclude_attrs.extend(obj.__xmlexclude__)
        pretty_print = self.prettyPrint
        knowntypes = self.knownTypes
        xmlstring = None
        if self.prettyPrint or indent:
            prefix = " " * indent
            newline = "\n"
            increment = 2
        else:
            prefix = ""
            newline = ""
            increment = 0
        # Determine the XML element name. If it isn"t specified in the
        # parameter list, look for it in the __xmlname__ attribute,
        # else use the default generic BASETYPE_ELEMENT_NAME.
        name_space_attrs = self.appendNSStack(obj)
        nameSpacePrefix = self.getNSPrefix()
        if not elementName:
            if hasattr(obj, "__xmlname__"):
                elementName = nameSpacePrefix + obj.__xmlname__
            else:
                elementName = nameSpacePrefix + BASETYPE_ELEMENT_NAME
        else:
            elementName = nameSpacePrefix + elementName

        if (hasattr(obj, "__xmlsequencer__")) and (obj.__xmlsequencer__ != None):
            if XMLSCHEMA_XSD_URL in self.nsstack[-1].nameSpaces.values():
                for kshort, vlong in self.nsstack[-1].nameSpaces.iteritems():
                    if vlong == XMLSCHEMA_XSD_URL:
                        if kshort != DEFAULT_NAMESPACE_KEY:
                            xsd_prefix = kshort + ':'
                        else:
                            xsd_prefix = ''
                        break
            else:
                xsd_prefix = 'xs:'
            element_add = xsd_prefix + obj.__xmlsequencer__
        else:
            element_add = None

        members_to_skip = []
        # Add more members_to_skip based on ones the user has selected
        # via the __xmlexclude__ and __xmldeepexclude__ attributes.
        members_to_skip.extend(exclude_attrs)
        # Marshal the attributes that are selected to be XML attributes.
        objattrs = ""
        class_name = ag_className(obj)
        classname_prefix = "_" + class_name
        if hasattr(obj, "__xmlattributes__"):
            xmlattributes = obj.__xmlattributes__
            members_to_skip.extend(xmlattributes)
            for attr in xmlattributes:
                internal_attr_name = attr
                if (attr.startswith("__") and not attr.endswith("__")):
                    internal_attr_name = classname_prefix + attr
                # Fail silently if a python attribute is specified to be
                # an XML attribute but is missing.
                attr_name_space_prefix = ""
                if hasattr(obj, "__xmlattrnamespaces__"):
                    for name_space_key, name_space_attributes in getattr(obj, "__xmlattrnamespaces__").items():
                        # Don't need to specify attribute namespace if it is the same as its element
                        if name_space_key == nameSpacePrefix[:-1]:
                            continue
                        if attr in name_space_attributes:
                            attr_name_space_prefix = name_space_key + ":"
                            break
                attrs = obj.__dict__
                value = attrs.get(internal_attr_name)
                if (hasattr(obj, "__xmlrename__") and attr in obj.__xmlrename__):
                    attr = obj.__xmlrename__[attr]
                xsd_element = None
                complex_type = getComplexType(obj)
                if complex_type is not None:
                    xsd_element = complex_type.findElement(attr)
                if xsd_element is not None:
                    default = xsd_element.default
                    if default is not None:
                        if ((default == value) or (default == _getXmlValue(value))):
                            continue
                    else:
                        if value is None:
                            continue
                        elif xsd_element.type == TYPE_QNAME:
                            value = self.contractQName(value, obj, attr)
                elif value is None:
                    continue

                if attr == "maxOccurs" and value == -1:
                    value = "unbounded"

                if isinstance(value, bool):
                    if value == True:
                        value = "true"
                    else:
                        value = "false"
                else:
                    value = objutils.toDiffableRepr(value)

                objattrs += ' %s%s="%s"' % (attr_name_space_prefix,
                                            attr, utillang.escape(value))
        if obj is None:
            xmlstring = [""]
        elif isinstance(obj, bool):
            objtypestr = self._genObjTypeStr("bool")
            xmlstring = ['%s<%s%s>%s</%s>%s' %
                         (prefix, elementName, objtypestr, obj, elementName, newline)]
        elif isinstance(obj, int):
            objtypestr = self._genObjTypeStr("int")
            xmlstring = ['%s<%s%s>%s</%s>%s' %
                         (prefix, elementName, objtypestr, str(obj), elementName, newline)]
        elif isinstance(obj, long):
            objtypestr = self._genObjTypeStr("long")
            xmlstring = ['%s<%s%s>%s</%s>%s' %
                         (prefix, elementName, objtypestr, str(obj), elementName, newline)]
        elif isinstance(obj, float):
            objtypestr = self._genObjTypeStr("float")
            xmlstring = ['%s<%s%s>%s</%s>%s' %
                         (prefix, elementName, objtypestr, str(obj), elementName, newline)]
        # have to check before basestring - unicode is instance of base string
        elif isinstance(obj, unicode):
            xmlstring = ['%s<%s>%s</%s>%s' %
                         (prefix, elementName, utillang.escape(obj), elementName, newline)]
        elif isinstance(obj, basestring):
            xmlstring = ['%s<%s>%s</%s>%s' %
                         (prefix, elementName, utillang.escape(obj.encode()), elementName, newline)]
        elif isinstance(obj, datetime.datetime):
            objtypestr = self._genObjTypeStr("datetime")
            xmlstring = ['%s<%s%s>%s</%s>%s' %
                         (prefix, elementName, objtypestr, str(obj), elementName, newline)]
        elif isinstance(obj, datetime.date):
            objtypestr = self._genObjTypeStr("date")
            xmlstring = ['%s<%s%s>%s</%s>%s' %
                         (prefix, elementName, objtypestr, str(obj), elementName, newline)]
        elif isinstance(obj, datetime.time):
            objtypestr = self._genObjTypeStr("time")
            xmlstring = ['%s<%s%s>%s</%s>%s' %
                         (prefix, elementName, objtypestr, str(obj), elementName, newline)]
        elif isinstance(obj, list):
            if len(obj) < 1:
                xmlstring = ""
            else:
                objtypestr = self._genObjTypeStr("list")
                xmlstring = ['%s<%s%s>%s' %
                             (prefix, elementName, objtypestr, newline)]
                for item in obj:
                    xmlstring.extend(self._marshal(
                        item, indent=indent + increment))
                xmlstring.append("%s</%s>%s" % (prefix, elementName, newline))
        elif isinstance(obj, tuple):
            if len(obj) < 1:
                xmlstring = ""
            else:
                objtypestr = self._genObjTypeStr("list")
                xmlstring = ['%s<%s%s mutable="false">%s' %
                             (prefix, elementName, objtypestr, newline)]
                for item in obj:
                    xmlstring.extend(self._marshal(
                        item, indent=indent + increment))
                xmlstring.append("%s</%s>%s" % (prefix, elementName, newline))
        elif isinstance(obj, dict):
            objtypestr = self._genObjTypeStr("dict")
            xmlstring = ['%s<%s%s>%s' %
                         (prefix, elementName, objtypestr, newline)]
            subprefix = prefix + " " * increment
            subindent = indent + 2 * increment
            keys = list(obj.keys())
            keys.sort()
            for key in keys:
                xmlstring.append("%s<%s>%s" %
                                 (subprefix, DICT_ITEM_NAME, newline))
                xmlstring.extend(self._marshal(
                    key, elementName=DICT_ITEM_KEY_NAME, indent=subindent))
                xmlstring.extend(self._marshal(
                    obj[key], elementName=DICT_ITEM_VALUE_NAME, indent=subindent))
                xmlstring.append("%s</%s>%s" %
                                 (subprefix, DICT_ITEM_NAME, newline))
            xmlstring.append("%s</%s>%s" % (prefix, elementName, newline))
        elif hasattr(obj, "__xmlcontent__"):
            content_value = getattr(obj, obj.__xmlcontent__)
            if content_value is None:
                xmlstring = ["%s<%s%s%s/>%s" %
                             (prefix, elementName, name_space_attrs, objattrs, newline)]
            else:
                content_value = utillang.escape(content_value)
                xmlstring = ["%s<%s%s%s>%s</%s>%s" % (
                    prefix, elementName, name_space_attrs, objattrs, content_value, elementName, newline)]
        else:
            # Only add the objtype if the element tag is unknown to us.
            if isinstance(obj, GenericXMLObject):
                objtypestr = ""
            elif self.isKnownType(elementName) == True:
                objtypestr = ""
            else:
                objtypestr = self._genObjTypeStr(
                    "%s.%s" % (obj.__class__.__module__, class_name))
            xmlstring = ['%s<%s%s%s%s' % (
                prefix, elementName, name_space_attrs, objattrs, objtypestr)]
            # get the member, value pairs for the object, filtering out the types we don"t support
            if element_add is not None:
                prefix += increment * " "
                indent += increment
            xml_member_string = []
            if hasattr(obj, "__xmlbody__"):
                xmlbody = getattr(obj, obj.__xmlbody__)
                if xmlbody is not None:
                    xml_member_string.append(utillang.escape(xmlbody))
            else:
                if hasattr(obj, "__xmlattrgroups__"):
                    attr_groups = obj.__xmlattrgroups__.copy()
                    if not isinstance(attr_groups, dict):
                        raise Exception(
                            "__xmlattrgroups__ is not a dict, but must be")
                    for n in attr_groups.iterkeys():
                        members_to_skip.extend(attr_groups[n])
                else:
                    attr_groups = {}
                # add the list of all attributes to attrGroups
                elist = list(obj.__dict__.keys())
                elist.sort()
                attr_groups["__nogroup__"] = elist

                for ename, elist in attr_groups.items():
                    if ename != '__nogroup__':
                        prefix += increment * " "
                        indent += increment
                        objtypestr = self._genObjTypeStr("None")
                        xml_member_string.append('%s<%s%s>%s' % (
                            prefix, ename, objtypestr, newline))
                    for name in elist:
                        value = obj.__dict__[name]
                        if ename == "__nogroup__" and name in members_to_skip:
                            continue
                        if name.startswith("__") and name.endswith("__"):
                            continue
                        if (hasattr(obj, "__xmlcdatacontent__") and (obj.__xmlcdatacontent__ == name)):
                            continue
                        sub_element_name_space_prefix = nameSpacePrefix
                        if hasattr(obj, "__xmlattrnamespaces__"):
                            for name_space_key, name_space_values in getattr(obj, "__xmlattrnamespaces__").items():
                                if name in name_space_values:
                                    sub_element_name_space_prefix = name_space_key + ":"
                                    break
                        # handle sequences listed in __xmlflattensequence__
                        # specially: instead of listing the contained items inside
                        # of a separate list, as God intended, list them inside
                        # the object containing the sequence.
                        if (hasattr(obj, "__xmlflattensequence__") and (value is not None) and (name in obj.__xmlflattensequence__)):
                            xmlnametuple = obj.__xmlflattensequence__[name]
                            if xmlnametuple is None:
                                xmlnametuple = [name]
                            elif (not isinstance(xmlnametuple, (tuple, list))):
                                xmlnametuple = [str(xmlnametuple)]
                            xmlname = None
                            if len(xmlnametuple) == 1:
                                xmlname = xmlnametuple[0]
                            if not isinstance(value, (list, tuple)):
                                value = [value]
                            for seqitem in value:
                                xml_member_string.extend(self._marshal(
                                    seqitem,
                                    xmlname,
                                    sub_element_name_space_prefix,
                                    indent=indent + increment
                                ))
                        else:
                            if (hasattr(obj, "__xmlrename__") and name in obj.__xmlrename__):
                                xmlname = obj.__xmlrename__[name]
                            else:
                                xmlname = name
                            if value is not None:
                                xml_member_string.extend(self._marshal(
                                    value,
                                    xmlname,
                                    sub_element_name_space_prefix,
                                    indent=indent + increment
                                ))
                    if ename != '__nogroup__':
                        xml_member_string.append(
                            "%s</%s>%s" % (prefix, ename, newline))
                        prefix = prefix[:-increment]
                        indent -= increment

            # if we have nested elements, add them here, otherwise close the element tag
            # immediately.
            newlist = []
            for s in xml_member_string:
                if len(s) > 0:
                    newlist.append(s)
            xml_member_string = newlist
            if len(xml_member_string) > 0:
                xmlstring.append(">")
                if hasattr(obj, "__xmlbody__"):
                    xmlstring.extend(xml_member_string)
                    xmlstring.append("</%s>%s" % (elementName, newline))
                else:
                    xmlstring.append(newline)
                    if element_add is not None:
                        xmlstring.append("%s<%s>%s" %
                                         (prefix, element_add, newline))
                    xmlstring.extend(xml_member_string)
                    if element_add is not None:
                        xmlstring.append("%s</%s>%s" %
                                         (prefix, element_add, newline))
                        prefix = prefix[:-increment]
                        indent -= increment
                    xmlstring.append("%s</%s>%s" %
                                     (prefix, elementName, newline))
            else:
                if hasattr(obj, "__xmlcdatacontent__"):
                    cdata_attr = obj.__xmlcdatacontent__
                    cdata_content = obj.__dict__[cdata_attr]
                    xmlstring.append("><![CDATA[%s]]></%s>%s" %
                                     (cdata_content, elementName, newline))
                else:
                    xmlstring.append("/>%s" % newline)
        xmlMarshallerLogger.debug(
            "<-- _marshal: %s", objutils.toDiffableString(xmlstring))
        self.popNSStack()
        return xmlstring

# A simple test, to be executed when the xmlmarshaller is run standalone


class MarshallerPerson:
    __xmlname__ = "person"
    __xmlexclude__ = ["fabulousness", ]
    __xmlattributes__ = ("nonSmoker",)
    __xmlrename__ = {"_phoneNumber": "telephone"}
    __xmlflattensequence__ = {"favoriteWords": ("vocabulary",)}
    __xmlattrgroups__ = {"name": ["firstName", "lastName"], "address": [
        "addressLine1", "city", "state", "zip"]}

    def setPerson(self):
        self.firstName = "Albert"
        self.lastName = "Camus"
        self.addressLine1 = "23 Absurd St."
        self.city = "Ennui"
        self.state = "MO"
        self.zip = "54321"
        self._phoneNumber = "808-303-2323"
        self.favoriteWords = ["angst", "ennui", "existence"]
        self.phobias = ["war", "tuberculosis", "cars"]
        self.weight = 150
        self.fabulousness = "tres tres"
        self.nonSmoker = False


if __name__ == "__main__":
    p1 = MarshallerPerson()
    p1.setPerson()
    xmlP1 = marshal(p1, prettyPrint=True, encoding="utf-8")
    print("\n########################")
    print("# testPerson test case #")
    print("########################")
    print(xmlP1)
    p2 = unmarshal(xmlP1)
    xmlP2 = marshal(p2, prettyPrint=True, encoding="utf-8")
    if xmlP1 == xmlP2:
        print("Success: repeated marshalling yields identical results")
    else:
        print("Failure: repeated marshalling yields different results")
        print(xmlP2)
