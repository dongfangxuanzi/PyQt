import os
import os.path
from typing import Optional
from . import fileutils


def get_filename_without_ext(file_path_name):
    filename = os.path.basename(file_path_name)
    return os.path.splitext(filename)[0]


def get_file_linetext(filepath, lineindex):
    content = fileutils.get_file_content(filepath, allow_exception=False)
    if content is None:
        return None
    linetext = content.splitlines()[lineindex]
    return linetext


def is_none_empty(value: Optional[str]):
    '''
    判断字符串为None或者空
    '''
    if value is None:
        return True
    if value == "":
        return True
    return False


def normalize_line_endings(lines, newline):
    """
    Return fixed line endings.
    All lines will be modified to use the most common line ending.
    """
    line = [line.rstrip('\n\r') + newline for line in lines]
    if line and lines[-1] == lines[-1].rstrip('\n\r'):
        line[-1] = line[-1].rstrip('\n\r')
    return line


def docstring_summary(docstring):
    """Return summary of docstring."""
    return docstring.split('\n')[0] if docstring else ''


def ensure_string(s, encoding='utf-8', errors='strict'):
    if isinstance(s, str):
        return s
    if isinstance(s, (bytes, bytearray)):
        return str(s, encoding=encoding)
    raise ValueError(
        "Expected str or bytes or bytearray, received %s." %
        type(s))


def bool_to_str(b_val):
    return "true" if b_val else "false"
