import enum
from . import fileutils
from .constants import DEFAULT_INDENT_SIZE
from .replace import get_node_range
DEFAULT_TAB_BLANKS = ' ' * DEFAULT_INDENT_SIZE


class FixChoice(enum.Enum):
    FIX_ALL = 'all'  # 修复所有可修复规则,包括单点修复规则,自动化修复规则
    FIX_AUTOFIX = 'autofix'  # 只修复可自动化修复规则


def get_file_linetext(filepath, lineindex):
    content = fileutils.get_file_content(filepath, allow_exception=False)
    if content is None:
        return None
    linetext = content.splitlines()[lineindex]
    return linetext


def get_node_line_text(node):
    '''
    获取语法节点在文件所在行的文本,需要注意ide文本控件内容发生变更导致节点行号发生改变,
    但是控件文本内容还未更新到文件中,此时行号在文件内获取的行文本是错误的,需要避免此类情况发生
    '''
    linetext = get_file_linetext(node.root().file, node.lineno - 1)
    return linetext


def get_node_col_offset_whitespaces_count(node):
    linetext = get_node_line_text(node)
    col_offset = node.col_offset - 1
    tabs_count = 0
    blanks_count = 0
    while col_offset >= 0:
        if linetext[col_offset] == '\t':
            tabs_count += 1
        else:
            blanks_count += 1
        col_offset -= 1
    return blanks_count, tabs_count


def get_node_col_offset_blanks(node):
    blanks_count, tabs_count = get_node_col_offset_whitespaces_count(node)
    if tabs_count > 0:
        return ' ' * blanks_count + '\t' * tabs_count
    return ' ' * node.col_offset


def get_node_col_offset(node):
    _blanks_count, tabs_count = get_node_col_offset_whitespaces_count(node)
    if tabs_count > 0:
        return node.col_offset - tabs_count + tabs_count * constants.DEFAULT_TAB_WIDTH
    return node.col_offset


def get_func_args_range(funcnode):
    args = funcnode.args
    args.lineno = args.args[0].lineno
    args.col_offset = args.args[0].col_offset
    args.end_lineno = args.args[-1].end_lineno
    args.end_col_offset = args.args[-1].end_col_offset
    default_args = args.defaults or [] + args.kw_defaults or []
    if default_args:
        args.end_lineno = default_args[-1].end_lineno
        args.end_col_offset = default_args[-1].end_col_offset
    return get_node_range(args)
