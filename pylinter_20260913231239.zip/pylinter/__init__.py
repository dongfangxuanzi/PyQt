import sys
import argparse
import logging
import os
import pylint
from .fileutils import readlines_from_file, match_file
from .strutils import docstring_summary
from .constants import MAX_FIX_TRY_TIMES
from .logger import init_logging, available_log_levels
from .utils import compute_run_time
from .autofix import fix_file, supported_fixes
from .codeutils import FixChoice
from .basefix import BaseFixer
log = logging.getLogger(__name__)

__version__ = '1.1.1'


EXIT_CODE_OK = 0
EXIT_CODE_ERROR = 1
EXIT_CODE_EXISTS_DIFF = 2
EXIT_CODE_ARGPARSE_ERROR = 99


def _get_package_version():
    packages = ["pylint: {}".format(pylint.__version__)]
    return ", ".join(packages)


if sys.platform == 'win32':  # pragma: no cover
    DEFAULT_CONFIG = os.path.expanduser(r'~\.pylintrc')
else:
    DEFAULT_CONFIG = os.path.join(os.getenv('PYLINTRC') or
                                  os.path.expanduser('~/.config'),
                                  'pylintrc')
# fallback, use .pep8
if not os.path.exists(DEFAULT_CONFIG):  # pragma: no cover
    if sys.platform == 'win32':
        DEFAULT_CONFIG = os.path.expanduser(r'~\.pep8')
    else:
        DEFAULT_CONFIG = os.path.join(os.path.expanduser('~/.config'), 'pep8')

DEFAULT_IGNORE = 'E226,E24,W50,W690'    # TODO: use pycodestyle.DEFAULT_IGNORE


def create_parser():
    """Return command-line parser."""
    parser = argparse.ArgumentParser(description=docstring_summary(__doc__),
                                     prog='pylinter')
    parser.add_argument('-v', '--version', action='version',
                        version='%(prog)s {} ({})'.format(
                            __version__, _get_package_version()))
    parser.add_argument('-l', '--log-level', dest='log_level', type=str,
                        default=logging.getLevelName(logging.INFO), choices=available_log_levels(), help='')
    parser.add_argument('-d', '--debug', action='store_true',
                        help='')
    parser.add_argument('-i', '--in-place', action='store_true',
                        help='make changes to files in place')
    parser.add_argument('--global-config', metavar='filename',
                        default=DEFAULT_CONFIG,
                        help='path to a global pep8 config file; if this file '
                             'does not exist then this is ignored '
                             '(default: {})'.format(DEFAULT_CONFIG))
    parser.add_argument('--ignore-local-config', action='store_true',
                        help="don't look for and apply local config files; "
                             'if not passed, defaults are updated with any '
                             "config files in the project's root directory")
    parser.add_argument('-r', '--recursive', action='store_true',
                        help='run recursively over directories; '
                             'must be used with --in-place')
    parser.add_argument('-j', '--jobs', type=int, metavar='n', default=1,
                        help='number of parallel jobs; '
                             'match CPU count if value is less than 1')
    parser.add_argument('-p', '--pep8-passes', metavar='n',
                        default=-1, type=int,
                        help='maximum number of additional pep8 passes '
                             '(default: infinite)')
    parser.add_argument('--repeat', action='store_true', help='')
    parser.add_argument('--exclude', metavar='globs',
                        help='exclude file/directory names that match these '
                             'comma-separated globs')
    parser.add_argument('--list-fixes', action='store_true',
                        help='list codes for fixes; '
                        'used by --ignore and --select')
    parser.add_argument('--ignore', metavar='errors', default='',
                        help='do not fix these errors/warnings '
                             '(default: {})'.format(DEFAULT_IGNORE))
    parser.add_argument('--select', metavar='errors', default='',
                        help='fix only these errors/warnings (e.g. E4,W)')
    parser.add_argument('--max-line-length', metavar='n', default=79, type=int,
                        help='set maximum allowed line length '
                             '(default: %(default)s)')
    parser.add_argument('--line-range', '--range', metavar='line',
                        default=None, type=int, nargs=2,
                        help='only fix errors found within this inclusive '
                             'range of line numbers (e.g. 1 99); '
                             'line numbers are indexed at 1')
    parser.add_argument(
        '-f',
        '--fix',
        type=str,
        dest='fix_choice',
        help='choices to fix',
        default=FixChoice.FIX_AUTOFIX.value,
        choices=[FixChoice.FIX_AUTOFIX.value, FixChoice.FIX_ALL.value]
    )

    parser.add_argument('--hang-closing', action='store_true',
                        help='hang-closing option passed to pycodestyle')
    parser.add_argument('--exit-code', action='store_true',
                        help='change to behavior of exit code.'
                             ' default behavior of return value, 0 is no '
                             'differences, 1 is error exit. return 2 when'
                             ' add this option. 2 is exists differences.')
    parser.add_argument('files', nargs='*',
                        help="files to format or '-' for standard in")

    return parser


def _parser_error_with_code(
    parser: argparse.ArgumentParser, code: int, msg: str,
) -> None:
    """wrap parser.error with exit code"""
    parser.print_usage(sys.stderr)
    parser.exit(code, f"{msg}\n")


def decode_filename(filename):
    """Return Unicode filename."""
    if isinstance(filename, str):
        return filename

    return filename.decode(sys.getfilesystemencoding())


def _split_comma_separated(string):
    """Return a set of strings."""
    return {text.strip() for text in string.split(',') if text.strip()}


def find_files(filenames, recursive, exclude):
    """Yield filenames."""
    while filenames:
        name = filenames.pop(0)
        if recursive and os.path.isdir(name):
            for root, directories, children in os.walk(name):
                filenames += [os.path.join(root, f) for f in children
                              if match_file(os.path.join(root, f),
                                            exclude)]
                directories[:] = [d for d in directories
                                  if match_file(os.path.join(root, d),
                                                exclude)]
        else:
            is_exclude_match = False
            for pattern in exclude:
                if fnmatch.fnmatch(name, pattern):
                    is_exclude_match = True
                    break
            if not is_exclude_match:
                yield name


def _fix_file(parameters):
    """Helper function for optionally running fix_file() in parallel."""
    try:
        source = None
        if parameters[1].repeat:
            for i in range(MAX_FIX_TRY_TIMES):
                fixed_source, fixed_count = fix_file(source=source, *parameters)
                if not parameters[1].in_place:
                    source = fixed_source
                if not fixed_count:
                    break
                log.info('fix total %d warnings in %d try times', fixed_count, i + 1)
        else:
            fixed_source, fixed_count = fix_file(*parameters)
            log.info('fix %d warnings.', fixed_count)
        return fixed_source, fixed_count
    except IOError as error:
        log.error(str(error))
        raise error


@compute_run_time
def fix_multiple_files(filenames, options, output=None):
    """Fix list of files.

    Optionally fix files recursively.

    """
    results = []
    total_fixed_count = 0
    filenames = find_files(filenames, options.recursive, options.exclude)
    if options.jobs > 1:
        import multiprocessing
        pool = multiprocessing.Pool(options.jobs)
        rets = []
        for name in filenames:
            ret = pool.apply_async(_fix_file, ((name, options),))
            rets.append(ret)
        pool.close()
        pool.join()
        results.extend([x.get()[0] for x in rets if x is not None])
        total_fixed_count = sum(x.get()[1] for x in rets if x is not None)
    else:
        for name in filenames:
            ret, fixed_count = _fix_file((name, options, output))
            total_fixed_count += fixed_count
            if ret is None:
                continue
            if options.in_place:
                results.append(ret)
            else:
                original_source = readlines_from_file(name)
                if "".join(original_source).splitlines() != ret.splitlines():
                    results.append(ret)
    return results, total_fixed_count


def parse_args(arguments, apply_config=False):
    """Parse command-line options."""
    parser = create_parser()
    args = parser.parse_args(arguments)

    BaseFixer.FIX_MSG_OPTION = FixChoice(args.fix_choice)

    if not args.files and not args.list_fixes:
        _parser_error_with_code(
            parser, EXIT_CODE_ARGPARSE_ERROR, 'incorrect number of arguments',
        )

    args.files = [decode_filename(name) for name in args.files]

    if apply_config:
        parser = read_config(args, parser)
        args = parser.parse_args(arguments)
        args.files = [decode_filename(name) for name in args.files]

    if len(args.files) > 1 and not args.in_place:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            'pylinter only takes one filename as argument '
            'unless the "--in-place" args are used',
        )

    if args.recursive and not args.in_place:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            '--recursive must be used with --in-place',
        )

    if args.max_line_length <= 0:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            '--max-line-length must be greater than 0',
        )
    if args.debug:
        init_logging(args.log_level.upper())

    if args.select:
        args.select = _expand_codes(
            _split_comma_separated(args.select),
            (_split_comma_separated(args.ignore) if args.ignore else [])
        )

    if args.ignore:
        args.ignore = _split_comma_separated(args.ignore)
        if all(
                not any(
                    conflicting_code.startswith(ignore_code)
                    for ignore_code in args.ignore
                )
                for conflicting_code in CONFLICTING_CODES
        ):
            args.ignore.update(CONFLICTING_CODES)

    if args.exclude:
        args.exclude = _split_comma_separated(args.exclude)
    else:
        args.exclude = {}

    if args.jobs < 1:
        # Do not import multiprocessing globally in case it is not supported
        # on the platform.
        import multiprocessing
        args.jobs = multiprocessing.cpu_count()

    if args.jobs > 1 and not args.in_place:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            'parallel jobs requires --in-place',
        )
    if args.jobs > 1 and BaseFixer.FIX_MSG_OPTION != FixChoice.FIX_AUTOFIX:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            'parallel jobs disable --fix all',
        )

    if args.line_range:
        if args.line_range[0] <= 0:
            _parser_error_with_code(
                parser,
                EXIT_CODE_ARGPARSE_ERROR,
                '--range must be positive numbers',
            )
        if args.line_range[0] > args.line_range[1]:
            _parser_error_with_code(
                parser,
                EXIT_CODE_ARGPARSE_ERROR,
                'First value of --range should be less than or equal '
                'to the second',
            )
    return args


def main(argv=None, apply_config=False):
    """Command-line entry."""
    if argv is None:
        argv = sys.argv
    try:
        args = parse_args(argv[1:], apply_config=apply_config)

        if args.list_fixes:
            for code, description in sorted(supported_fixes()):
                print('{code} - {description}'.format(
                    code=code, description=description))
            return EXIT_CODE_OK
        if args.in_place:
            args.files = list(set(args.files))
        else:
            assert len(args.files) == 1
            assert not args.recursive
        results, fixed_count = fix_multiple_files(args.files, args, sys.stdout)
        log.info('total fix %d warnings.', fixed_count)
        # with in-place option
        ret = any(ret is not None for ret in results)
        if args.exit_code and ret:
            return EXIT_CODE_EXISTS_DIFF
    except IOError:
        return EXIT_CODE_ERROR
    except KeyboardInterrupt:
        return EXIT_CODE_ERROR  # pragma: no cover
