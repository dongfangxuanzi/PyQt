#!/usr/bin/env python
"""
Automatically formats Python code to conform to the PEP 8 style guide.
Fixes that only need be done once can be added by adding a function of the form
"fix_<code>(source)" to this module. They should return the fixed source code.
These fixes are picked up by apply_global_fixes().
Fixes that depend on pycodestyle should be added as methods to FixPEP8. See the
class documentation for more information.
"""
import copy
import inspect
import io
import re
import sys
import logging
import pylint
from pylint.lint.pylinter import MANAGER
from pylint.lint import Run as PylintRun
from .formatter import ModuleFormatter
from .message import Message
from .fileutils import (
    readlines_from_file,
    read_from_file,
    detect_encoding,
    make_tempfile,
    open_with_encoding
)
from .utils import compute_run_time
from .strutils import normalize_line_endings
from .exceptions import NoFixerError
from .reporter import QuietReport
from .constants import LF, PYLINT_TOOL_NAME
from .node_utils import ImportNodes
log = logging.getLogger(__name__)


# these fixes conflict with each other, if the `--ignore` setting causes both
# to be enabled, disable both of them
CONFLICTING_CODES = ('W503', 'W504')


class FixPylintWarnings:
    """
    Fix invalid code.
    Fixer methods are prefixed "fix_". The _fix_source() method looks for these
    automatically.
    The fixer method can take either one or two arguments (in addition to
    self). The first argument is "result", which is the error information from
    pycodestyle. The second argument, "logical", is required only for
    logical-line fixes.
    The fixer method can return the list of modified lines or None. An empty
    list would mean that no changes were made. None would mean that only the
    line reported in the pycodestyle error was modified. Note that the modified
    line numbers that are returned are indexed at 1. This typically would
    correspond with the line number reported in the pycodestyle error
    information.
    [fixed method list]
    """
    FIXVER_V1 = "v1"

    def __init__(self, filename,
                 options,
                 contents=None,
                 long_line_ignore_cache=None):
        self.filename = filename
        if contents is None:
            self._contents_from_file = True
            self.source = readlines_from_file(filename)
        else:
            self._contents_from_file = False
            sio = io.StringIO(contents)
            self.source = sio.readlines()
        self.options = options
        self.name = PYLINT_TOOL_NAME
        self.__fixed_count = 0
        self.original_source = copy.copy(self.source)
        self._formatter = ModuleFormatter(self.source, self.filename)
        self._fixers = []

        # collect imports line
        self.imports = {}
        for i, line in enumerate(self.source):
            if (line.find("import ") == 0 or line.find("from ") == 0) and \
                    line not in self.imports:
                # collect only import statements that first appeared
                self.imports[line] = i

        self.long_line_ignore_cache = (
            set() if long_line_ignore_cache is None
            else long_line_ignore_cache)

        # Many fixers are the same even though pycodestyle categorizes them
        # differently.
        self.add_fixers()

    @property
    def fixer_version(self):
        return self.get_fixer_version(pylint.__version__)

    @property
    def fixed_count(self):
        return self.__fixed_count

    @property
    def fixers(self):
        return self._fixers

    @classmethod
    def get_fixer_version(cls, version_str):
        if version_str.find('3.0.3') != -1:
            return cls.FIXVER_V1
        return None

    def has_empty_fixer(self, ver=None):
        if not self._fixers:
            return True
        if len(self._fixers) <= 5:
            return True
        last_fixer = self._fixers[-2]
        fixer_module_name = last_fixer.__module__
        mods = fixer_module_name.split(".")
        if ver and ver != mods[3]:
            return True
        return False

    def add_fixers(self):
        # pylint3.0.3版本的定制规则修复器对应v1版本
        if self.is_fixer_ver_v1() and self.has_empty_fixer(self.FIXVER_V1):
            from .pylint.fixers import v1
            self.add_fixer(v1.PylintR0205Fixer())
            self.add_fixer(v1.PylintW0612Fixer())
            self.add_fixer(v1.PylintW0611Fixer())
            self.add_fixer(v1.PylintC0410Fixer())
            self.add_fixer(v1.PylintC0411Fixer())
            self.add_fixer(v1.PylintC0200Fixer())
            self.add_fixer(v1.PylintC0301Fixer())
            self.add_fixer(v1.PylintW0102Fixer())

        if self.has_empty_fixer():
            raise NoFixerError

    def is_fixer_ver_v1(self):
        return self.fixer_version == self.FIXVER_V1

    def add_fixer(self, fixer):
        if self.find_fixer(fixer.ruleid):
            raise RuntimeError(f'rule id: {fixer.ruleid} is already in fixers')
        assert fixer.toolname == self.name
        fixer.check_tool = self
        fixer.set_formatter(self._formatter)
        self._fixers.append(fixer)

    def is_rule_fixable(self, rule_id):
        for fixer in self._fixers:
            if fixer.ruleid == rule_id and fixer.toolname == self.name:
                return True
        return False

    def find_fixer(self, rule_id):
        for fixer in self._fixers:
            if fixer.ruleid == rule_id and fixer.toolname == self.name:
                return fixer
        return None

    def fix_module_imports_blank_line(self):
        if self._formatter.module is None:
            self._formatter.parse_module()
        if self._formatter.module is not None:
            importutils = ImportNodes(self._formatter.module, self._formatter)
            top_import_nodes = importutils.get_top_import_nodes()
            if not top_import_nodes:
                return
            start_line = top_import_nodes[0].lineno
            end_line = top_import_nodes[-1].lineno
            del_lines = []
            for i in range(start_line - 1, end_line):
                line_text = self._formatter.get_line_text(i)
                if not line_text.strip():
                    del_lines.append(i)
            del_lines.sort(reverse=True)
            for del_line_index in del_lines:
                del self.source[del_line_index]

    def fix(self):
        """Return a version of the source code with PEP 8 violations fixed."""
        if self._contents_from_file:
            pylint_args = [self.filename]
        else:
            source_content = ''.join(normalize_line_endings(self.source, LF))
            temp_py_filename = make_tempfile(source_content)
            pylint_args = [temp_py_filename]
        results = _execute_pylint(pylint_args, self.source)
        log.info('check total %d pylint issues', len(results))
        if self.options.line_range:
            start, end = self.options.line_range
            results = [r for r in results
                       if start <= r['line'] <= end]

        self._fix_source(filter_results(source=''.join(self.source),
                                        results=results,
                                        ))

        if self.options.line_range:
            # If number of lines has changed then change line_range.
            count = sum(sline.count('\n')
                        for sline in self.source[start - 1:end])
            self.options.line_range[1] = start + count - 1
        self.fix_module_imports_blank_line()
        return ''.join(self.source)

    def _fix_source(self, results):
        for result in sorted(results, key=lambda x: x['line'], reverse=True):
            result_id = result['id']
            fixer = self.find_fixer(result_id)
            if fixer is not None:
                msg = Message(
                    result['line'],
                    result['column'],
                    result_id,
                    self.filename,
                    result['info'],
                    PYLINT_TOOL_NAME
                )
                log.debug(
                    '--->  %s:%s:%s:%s',
                    self.filename,
                    result['line'],
                    result['column'],
                    msg.msg
                )
                suc = fixer.auto_fix_msg(msg)
                if suc:
                    log.info(
                        'fix rule %s on line %d column %d success',
                        result_id,
                        result['line'],
                        result['column']
                    )
                    self.__fixed_count += 1
                else:
                    log.info(
                        'fix rule %s on line %d column %d fail',
                        result_id,
                        result['line'],
                        result['column']
                    )
            else:
                log.debug("--->  rule '%s' can't be fixed.", result_id)
                info = result['info'].strip()
                log.debug('--->  %s:%s:%s:%s', self.filename, result['line'], result['column'], info
                          )


def _execute_pylint(args, source):
    """Execute pycodestyle via python method calls."""
    MANAGER.clear_cache()
    runner = PylintRun(args, reporter=QuietReport(), exit=False)
    return runner.linter.reporter.full_error_results()


def filter_results(source, results):
    """
    Filter out spurious reports from pycodestyle.
    If aggressive is True, we allow possibly unsafe fixes (E711, E712).
    """
    for r in results:
        yield r


def fix_lines(content, options, filename=''):
    """Return fixed source code."""
    fixed_warnings = 0
    long_line_ignore_cache = set()
    fix = FixPylintWarnings(
        filename,
        options,
        contents=content,
        long_line_ignore_cache=long_line_ignore_cache
    )
    fixed_source = fix.fix()
    fixed_warnings = fix.fixed_count
    sio = io.StringIO(fixed_source)
    return ''.join(normalize_line_endings(sio.readlines(), LF)), fixed_warnings


@compute_run_time
def fix_file(filename, options=None, output=None, source=None, apply_config=False):
    if not options:
        options = parse_args([filename], apply_config=apply_config)

    if source is None:
        fixed_source = None
        original_source = read_from_file(filename)
    else:
        fixed_source = source
        original_source = source

    if options.in_place or output:
        encoding = detect_encoding(filename)
    log.info('start fix file `%s`', filename)
    fixed_source, fixed_count = fix_lines(fixed_source, options, filename=filename)
    if options.in_place:
        original = original_source.splitlines(keepends=True)
        fixed = fixed_source.splitlines(keepends=True)
        original_source_last_line = (
            original[-1].split("\n")[-1] if original else ""
        )
        fixed_source_last_line = fixed_source.split("\n")[-1]
        if original != fixed or (
            original_source_last_line != fixed_source_last_line
        ):
            with open_with_encoding(filename, 'w', encoding=encoding) as fp:
                fp.write(fixed_source)
            return fixed_source, fixed_count
        return None, fixed_count
    else:
        if output:
            output.write(fixed_source)
            output.flush()
    return fixed_source, fixed_count


def _get_parameters(function):
    if sys.version_info.major >= 3:
        # We need to match "getargspec()", which includes "self" as the first
        # value for methods.
        # https://bugs.python.org/issue17481#msg209469
        if inspect.ismethod(function):
            function = function.__func__

        return list(inspect.signature(function).parameters)
    return inspect.getargspec(function)[0]


def _expand_codes(codes, ignore_codes):
    """expand to individual E/W codes"""
    ret = set()

    is_conflict = False
    if all(
            any(
                conflicting_code.startswith(code)
                for code in codes
            )
            for conflicting_code in CONFLICTING_CODES
    ):
        is_conflict = True

    is_ignore_w503 = "W503" in ignore_codes
    is_ignore_w504 = "W504" in ignore_codes

    for code in codes:
        if code == "W":
            if is_ignore_w503 and is_ignore_w504:
                ret.update({"W1", "W2", "W3", "W505", "W6"})
            elif is_ignore_w503:
                ret.update({"W1", "W2", "W3", "W504", "W505", "W6"})
            else:
                ret.update({"W1", "W2", "W3", "W503", "W505", "W6"})
        elif code in ("W5", "W50"):
            if is_ignore_w503 and is_ignore_w504:
                ret.update({"W505"})
            elif is_ignore_w503:
                ret.update({"W504", "W505"})
            else:
                ret.update({"W503", "W505"})
        elif not (code in ("W503", "W504") and is_conflict):
            ret.add(code)

    return ret


def supported_fixes():
    """
    Yield pep8 error codes that autopep8 fixes.
    Each item we yield is a tuple of the code followed by its
    description.
    """
   # yield ('E101', docstring_summary(reindent.__doc__))

    instance = FixPylintWarnings(filename=None, options=None, contents='')
    for fixer in instance.fixers:
        yield (
            fixer.ruleid,
            re.sub(r'\s+', ' ',
                   fixer.__doc__)
        )
