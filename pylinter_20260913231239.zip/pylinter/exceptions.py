class FixfileError(Exception):
    '''修复文件错误'''


class LineEmptyNodeError(Exception):
    '''行列语法节点为空'''


class InvalidOptionIndexError(Exception):
    '''非法选项值'''


class DeleteNodeError(FixfileError):
    '''修复文件时删除语法节点失败'''


class NoFixerError(RuntimeError):
    '''定制规则修复器列表为空'''


class CodeSyntaxError(RuntimeError):
    '''代码语法错误'''
