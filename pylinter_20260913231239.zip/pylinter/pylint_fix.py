import os
import logging
from astroid import nodes
from .constants import PYLINT_TOOL_NAME
from .replace import get_node_range
from .codeutils import get_node_line_text
from .node_scope import ScopeFinder
from .basefix import BasePythonFixer
log = logging.getLogger(__name__)


class PylintFixer(BasePythonFixer):
    DOUBLE_QUOTE = '"'
    SINGLE_QUOTE = "'"

    def __init__(self, ruleid, autofix=True):
        super().__init__(ruleid, PYLINT_TOOL_NAME, autofix)

    @staticmethod
    def get_line_str_quote(node):
        '''
        获取行字符串是用单引号还是双引号裹起来
        '''
        linetext = get_node_line_text(node)
        if linetext is None:
            return '"'
        return linetext[node.col_offset]

    @staticmethod
    def get_classtype_parent_node(node, nodeclass, include_node_self=True):
        if include_node_self and isinstance(node, nodeclass):
            return node
        return ScopeFinder.get_parent_node_by_nodeclass(node, nodeclass)

    @staticmethod
    def replace_module_name(doc, oldpath, new_module_name):
        ext = strutils.get_file_extension(oldpath, keepdot=True)
        newname = os.path.join(
            fileutils.get_filepath_from_path(oldpath), new_module_name)
        newfilepath = strutils.MakeNameEndInExtension(newname, ext)
        return doc.GetCommandProcessor().Submit(
            projectcommand.ProjectRenameFileCommand(doc, oldpath, newfilepath)
        )

    @classmethod
    def get_line_str_r_quote(cls, node):
        '''
        获取行字符串是否被r包裹起来,如果有r,获取r后面的引号字符
        '''
        str_quote = cls.get_line_str_quote(node)
        log.debug(
            "str quote of line %d is %s",
            node.lineno,
            str_quote
        )
        # 字符串被r包裹
        if str_quote == "r":
            # 字符串引号在r字符右移1位
            node.col_offset += 1
            str_quote = cls.get_line_str_quote(node)
            node.col_offset -= 1
            return True, str_quote
        return False, str_quote

    @classmethod
    def replace_variable_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.Name, nodes.AssignName)) and child.name == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, newname)
            else:
                cls.replace_variable_name_in_scope(
                    textview, child, name, newname)

    @classmethod
    def replace_attribute_name_in_scope(cls, textview, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.AssignAttr, nodes.Attribute)) and child.attrname == name:
                fix_range = get_node_range(child)
                fix_range.replace_with_text(textview, "self." + newname)
            else:
                cls.replace_attribute_name_in_scope(
                    textview, child, name, newname)

    def delete_import_name(self, node, import_name):
        if not self.is_node_could_deleted(node):
            log.error("%s node could not be deleted", node.__class__.__name__)
            return False
        for i, (name, asname) in enumerate(node.names):
            if import_name in (name, asname):
                del node.names[i]
                break
        else:
            return False
        if not node.names:
            return self.delete_node(node)
        self.fix_node_text(node, node.as_string())
        return True
