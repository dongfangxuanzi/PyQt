from novalapp import get_app
from novalapp.lib.pyqt import QThread, QMessageBox
from novalapp.util import utils
from novalapp.util.exceptions import ProcessordocNotmatchedErrror
from novalapp.editor.textview import TextView
from novalapp import globalkeys
from .fix_processor import FixerProcessor
from . import configkeys
from .sched_processor import CodecheckProcessor


class FileProcessor(QThread):
    """文件保存时用线程检查单个文件"""

    def __init__(self, parent, processor, metrics_processor, doc, filepath):
        super().__init__(parent)
        self._parent = parent
        self._processor = processor
        self._metrics_processor = metrics_processor
        self._doc = doc
        self._filepath = filepath
        self._is_fixprocessor = False
        self._configs = {}
        self.save_configs()

    def save_configs(self):
        if isinstance(self._processor, FixerProcessor) and utils.profile_get_int(
                configkeys.AUTOFIX_FILE_SAVE_KEY, False):
            self._is_fixprocessor = True
            self._configs[configkeys.CLOSE_OPENDOC_KEY] = utils.profile_get_int(
                configkeys.CLOSE_OPENDOC_KEY, True)
            self._configs[globalkeys.FIX_IMPORT_NODES_KEY] = utils.profile_get_int(
                globalkeys.FIX_IMPORT_NODES_KEY, False)
            TextView.FILE_MODIFY_ANSWER = QMessageBox.YesToAll
            get_app().MainFrame.reset_filechanged_answer = False

    def run(self):
        if self._processor.is_filepath_excluded(self._doc, self._filepath):
            utils.get_logger().info(
                'saved file %s is excluded in project `%s`',
                self._filepath,
                self._doc.GetModel().name
            )
            return
        self._processor.set_running()
        if self._is_fixprocessor:
            utils.profile_set(configkeys.CLOSE_OPENDOC_KEY, False)
            utils.profile_set(globalkeys.FIX_IMPORT_NODES_KEY, False)
            utils.get_logger().info('processor %s fixing update file %s',
                                    self._processor.name, self._filepath)
            self._processor.fix_single_file(self._doc, self._filepath)
            self.restore_configs()
        else:
            utils.get_logger().info('processor %s checking update file %s',
                                    self._processor.name, self._filepath)
            if isinstance(self._processor, CodecheckProcessor):
                self._processor.check_single_file(self._doc, self._filepath)
            else:
                self._parent._plugin._check_processor.check_single_file(
                    self._doc, self._filepath)

        if utils.profile_get_int(configkeys.CHECK_CODE_METRICS_KEY, False):
            self._metrics_processor.set_running()
            try:
                self._metrics_processor.run(self._doc, self._filepath)
            except ProcessordocNotmatchedErrror as ex:
                utils.get_logger().error(str(ex))
            self._metrics_processor.set_stopped()
            # 处理器完成后手动禁止
            self._metrics_processor.enabled = False
        self._processor.set_stopped()
        # 处理器完成后手动禁止
        self._processor.enabled = False

    def restore_configs(self):
        for config_key, value in self._configs.items():
            utils.profile_set(config_key, value)
        get_app().MainFrame.reset_filechanged_answer = True
