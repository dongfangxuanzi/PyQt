import re
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode


class PylintR1701Fixer(PylintFixer):
    '''
    规则说明:2个isinstance calls(isinstance(x) or isinstance(y))
    可以合并为1个isinstance call (isinstance(x,y))
    '''

    def __init__(self):
        super().__init__('R1701', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg, use_column=True)
        if not node:
            return False
        res = re.search(
            r"Consider merging these isinstance calls to (.*) \(consider-merging-isinstance\)",
            msg.msg
        )
        if isinstance(node, nodes.Name) and node.name == "isinstance" and (
            isinstance(node.parent.parent, nodes.BoolOp) and node.parent.parent.op == 'or'
        ):
            fixnode = FixNode(node.parent.parent, textview)
            newtext = res.groups()[0]
            fixnode.replace_node_with_text(newtext)
            return True
        return False
