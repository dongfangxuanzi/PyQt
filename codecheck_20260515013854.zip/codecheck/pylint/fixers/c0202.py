import re
from novalapp.python.parser.define import CLASS_METHOD_NAME
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import FixRange, FixNode
from ...pylint_fix import SarifFixer


class PylintC0202Fixer(SarifFixer):
    '''
    规则说明:类方法必须用cls作为第一个参数名
    '''

    def __init__(self):
        super().__init__('C0202', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        res = re.search(
            r"Class method (.*) should have 'cls' as first argument \(bad-classmethod-argument\)",
            msg.msg
        )
        nodename = res.groups()[0]
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and nodename == node.name:
            if CLASS_METHOD_NAME == node.parent.type:
                start_line = node.lineno
                if node.parent.args.args:
                    first_arg = node.parent.args.args[0]
                    if isinstance(first_arg, nodes.AssignName):
                        if first_arg.name == 'cls':
                            return False
                        if first_arg.name == 'self':
                            fix_arg_node = FixNode(first_arg, textview)
                            fix_arg_node.replace_node_with_text('cls')
                            return True
                    start_column = first_arg.col_offset
                    fix_args_node = FixRange(start_line, start_column)
                    fix_args_node.add_text(textview, "cls,")
                    return True
        return False
