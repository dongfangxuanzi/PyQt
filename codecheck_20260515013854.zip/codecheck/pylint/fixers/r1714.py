import re
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import get_node_range


class PylintR1714Fixer(PylintFixer):
    '''
    规则说明:or/and条件表达式可以使用in/not in代替
    '''

    def __init__(self):
        super().__init__('R1714', True)

    @classmethod
    def get_fix_bool_op(cls, op, node: nodes.BoolOp):
        values = node.values
        if node.op == op and isinstance(values[0], nodes.Compare) and isinstance(values[1], nodes.Compare):
            return node
        if isinstance(node.values[0], nodes.BoolOp):
            return cls.get_fix_bool_op(op, node.values[0])
        return None

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        # 老版本告警格式
        res = re.search(
            r'Consider merging these comparisons with "in" to (\'.*\'|".*") \(consider-using-in\)',
            msg.msg
        )
        if not res:
            # 新版本pylint3.0.3告警格式
            res = re.search(
                r"Consider merging these comparisons with 'in' by using '(.*)'. Use a set instead if elements are hashable. \(consider-using-in\)",
                msg.msg
            )
            if not res:
                return False
            fixstr = res.groups()[0]
        else:
            fixstr = res.groups()[0][1:-1]
        if not isinstance(node, nodes.BoolOp):
            return False
        if 'not ' in fixstr:
            op = 'and'
        else:
            op = 'or'
        bool_op_node = self.get_fix_bool_op(op, node)
        if bool_op_node is None:
            return False
        single_quote_str = "\\'"
        if fixstr.find(single_quote_str) != -1:
            fixstr = fixstr.replace(single_quote_str, "'")
        iftest = get_node_range(bool_op_node)
        iftest.replace_with_text(textview, fixstr)
        return True
