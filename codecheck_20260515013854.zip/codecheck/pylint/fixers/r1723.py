import re
from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import FixRange
from ...pylint_fix import PylintFixer


class PylintR1723Fixer(PylintFixer):
    '''
    规则说明:break表达式后多余的else和elif语句
    '''

    def __init__(self):
        super().__init__('R1723', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        line = msg.line
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        if isinstance(scope, nodes.If):
            orelse = scope.orelse
            if not orelse:
                return False
            if msg.msg.find('Unnecessary "else" after "break"') != -1:
                for statement in orelse:
                    # 如果else块内部有复杂的缩进语句,不要自动修复,
                    # 让用户手动修复,防止修复出错
                    if hasattr(statement, 'body'):
                        return False
                for statement in orelse:
                    textview.GotoPos(statement.lineno - 1,
                                     statement.col_offset)
                    # 将else块内的语句退格
                    textview.backtab()
                else_line = self.get_else_line(text_ctrl, orelse[0].lineno - 1)
                if else_line == -1:
                    return False
                # 删除else语句
                textview.delete_line(else_line)
                return True
            if msg.msg.find('Unnecessary "elif" after "break"') != -1:
                self.replace_elif_with_if(orelse, text_ctrl, textview)
                return True
        return False

    @staticmethod
    def replace_elif_with_if(orelse, textctrl, textview):
        statement = orelse[0]
        fix_range = FixRange(statement.lineno)
        linetext = textctrl.get_line_text(statement.lineno - 1)
        newtext = linetext.replace("elif", "if", 1)
        if linetext != newtext:
            fix_range.replace_line(textview, newtext)
            return True
        return False

    @staticmethod
    def get_else_line(text_ctrl, line):
        i = line
        while i > 0:
            line_text = text_ctrl.get_line_text(i)
            if re.search(r"else\s*:", line_text):
                return i
            i -= 1
        return -1


class PylintR1724Fixer(PylintFixer):
    '''
    规则说明:continue表达式后多余的else和elif语句
    '''

    def __init__(self):
        super().__init__('R1724', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        if isinstance(node.parent, nodes.If):
            orelse = node.parent.orelse
            if not orelse:
                return False
            if msg.msg.find('Unnecessary "elif" after "continue"') != -1:
                return PylintR1723Fixer.replace_elif_with_if(orelse, text_ctrl, textview)
        return False
