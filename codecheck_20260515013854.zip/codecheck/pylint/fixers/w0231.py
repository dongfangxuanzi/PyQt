'''
Name:        w0231.py
Purpose:

Author:      wukan

Created:     2026-05-13
Copyright:   (c) wukan 2026
Licence:     Mulan
'''
import os
import re
import astroid
from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp.python.parser.define import CLASS_INIT_METHOD, SELF_ARG_NAME
from novalapp.python.parser import node_utils
from ...basefix import fix_code_file_msg
from ...codeutils import get_add_range
from ...pylint_fix import PylintFixer


class PylintW0231Fixer(PylintFixer):
    '''
    规则说明: 子类继承父类时没有调用父类的__init__方法
    '''

    def __init__(self):
        super().__init__('W0231', True)

    @staticmethod
    def get_method_init_args(derived_init_method_node):
        init_args = derived_init_method_node.args.args
        derived_class = derived_init_method_node.parent
        class_bases = derived_class.bases
        arg_names = []
        for base_class_name_node in class_bases:
            infer_base_class = node_utils.safe_infer(base_class_name_node)
            if infer_base_class is None or infer_base_class is astroid.Uninferable:
                continue
            base_init_method_node = ScopeFinder.get_class_method_node(
                infer_base_class,
                CLASS_INIT_METHOD
            )
            base_init_argnames = [arg.as_string() for arg in base_init_method_node.args.args]
            for derived_init_arg in init_args:
                init_arg_name = derived_init_arg.as_string()
                if init_arg_name in base_init_argnames and init_arg_name != SELF_ARG_NAME:
                    arg_names.append(init_arg_name)
        return arg_names

    @staticmethod
    def is_name_in_bases(classnode, classname):
        for basename in classnode.bases:
            if classname == basename.as_string():
                return True
        return False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        res = re.search(
            r"__init__ method from base class '(.*)' is not called \(super-init-not-called\)",
            msg.msg
        )
        if isinstance(node, nodes.Name) and node.name == CLASS_INIT_METHOD:
            func_node = node.parent
            derived_cls_name = res.groups()[0]
            func_pnode = func_node.parent
            if isinstance(func_pnode, nodes.ClassDef) and (
                self.is_name_in_bases(func_pnode, derived_cls_name) and not self.is_init_called(func_node)
            ):
                first_body = func_node.body[0]
                init_arg_names = self.get_method_init_args(func_node)
                init_arg_str = ",".join(init_arg_names)
                insert_line = first_body.lineno
                blanks = first_body.col_offset * ' '
                add_range = get_add_range(insert_line, 0)
                add_range.add_text(
                    textview,
                    blanks + f'super().{node.name}({init_arg_str})' + os.linesep
                )
                return True
        return False

    @staticmethod
    def is_init_called(init_func_node):
        for child in init_func_node.body:
            if isinstance(child, nodes.Expr) and isinstance(child.value, nodes.Call) and (
                isinstance(child.value.func, nodes.Attribute)
            ) and child.value.func.attrname == CLASS_INIT_METHOD:
                return True
        return False
