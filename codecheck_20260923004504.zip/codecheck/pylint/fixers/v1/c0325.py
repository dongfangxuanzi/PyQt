import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintC0325Fixer(PylintFixer):
    '''
    规则说明: assert/if/赋值/表达式无需用括号包裹起来
    '''

    def __init__(self):
        super().__init__('C0325', True)

    @staticmethod
    def get_msg_keyword(msg):
        res = re.search(r"Unnecessary parens after '(\w+)' keyword", msg.msg)
        if not res:
            return None
        keyword_name = res.groups()[0]
        return keyword_name

    def fix_message(self, msg):
        linestr = self.get_msg_line_text(msg)
        result = re.search(r'\(.*\)', linestr)
        if not result:
            return False
        node = self.find_msg_node(msg)
        keyword_name = self.get_msg_keyword(msg)
        if isinstance(node, nodes.Assert) or (
            isinstance(node, nodes.UnaryOp) and keyword_name == "not"
        ):
            nodestr = node.as_string()
            self.fix_node_text(node, nodestr)
            return True
        if isinstance(node, (nodes.Return, nodes.Assign)):
            nodestr = node.as_string()
            self.fix_node_text(node, nodestr)
            return True
        if isinstance(node.parent, (nodes.If, nodes.While)) and not isinstance(node, nodes.If):
            pnode = node.parent
            return self.fix_if_while_test(pnode, keyword_name)
        if isinstance(node, nodes.If):
            return self.fix_if_while_test(node, keyword_name)
        return False

    def fix_if_while_test(self, node, keyword_name):
        teststr = node.test.as_string()
        is_ifnode = isinstance(node, nodes.If)
        if is_ifnode:
            if keyword_name not in ['if', 'elif']:
                return False
            nodestr = ' ' * node.col_offset + f"{keyword_name} {teststr}:"
        else:
            nodestr = ' ' * node.col_offset + f"while {teststr}:"
        test_node_line_text = self.get_line_text(node.test.lineno - 1)
        colon_pos = test_node_line_text.find(':', node.test.end_col_offset)
        self.replace_range_text(node.test.lineno, nodestr, 0, node.test.lineno, colon_pos + 1)
        return True
