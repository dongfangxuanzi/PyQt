# -*- coding: utf-8 -*-
import copy
import datetime
import logging
import os
from ... import get_app
from ...util import appdirs, utils, fileutils
from ...enums import InterpreterUpdateInterval
from ..interpreter.interpretermanager import InterpreterManager
from ..parser.parser_checker import FileupdateTimeChecker
from .dataload import IntellisencedataLoader
from .datagen import IntellisencedataGen
from . import objtypes
from ..analysis.moduleloader import ModuleLoader
from ..apis import iconid, memberkeys
from ..project.processor import CODEPARSE_RPROCESSOR_NAME
from .definition import Definition
from . import define

log = logging.getLogger(__name__)


class IntellisenceManager:
    def __init__(self):
        self.data_root_path = os.path.join(
            appdirs.get_user_data_path(), "intellisence")
        self.module_dicts = {}
        self.statubar = get_app().MainFrame.GetStatusBar()
        self._loader = IntellisencedataLoader(
            self.data_root_path, self, self.statubar)
        self._running = False
        self._process_obj = None
        self._is_stopped = False
        self.unfinish_files = {}

    @property
    def dataloader(self):
        return self._loader

    @property
    def datapath(self):
        return self.data_root_path

    @property
    def stopped(self):
        return self._is_stopped

    @property
    def running(self):
        return self._running

    @running.setter
    def running(self, value: bool):
        self._running = value

    def Stop(self):
        self._is_stopped = True

    def GetInterpreterDatabasePath(self, interpreter):
        '''
        解释器内建模块,标准模块,第三方模块语法数据存放的总目录
        '''
        if interpreter.IsBuiltIn:
            # 内建解释器的语法数据存放在程序data子目录下
            return fileutils.opj(os.path.join(utils.get_app_path(), "novalapp/data"))
        return os.path.join(self.data_root_path, str(interpreter.Id))

    def get_interpreter_intellisence_data_path(self, interpreter):
        '''
        解释器标准模块,第三方模块语法数据存放位置,和内建模块语法数据存放位置分开
        '''
        if interpreter.IsBuiltIn:
            # 内建解释器的所有语法数据都存放在一个目录下
            return self.get_interpreter_builtin_intellisence_data_path(interpreter)
        return os.path.join(self.GetInterpreterDatabasePath(interpreter), interpreter.MinorVersion)

    def get_interpreter_builtin_intellisence_data_path(self, interpreter):
        '''解释器内建模块语法数据存放位置'''
        return os.path.join(
            self.GetInterpreterDatabasePath(interpreter),
            define.BUILTINS_DATA_FOLDER
        )

    def get_last_updatetime(self, database_location):
        return FileupdateTimeChecker(database_location).load_last_timestamp()

    def is_interpreter_need_update_database(self, interpreter):
        update_interval_option = utils.profile_get_int(
            "DatabaseUpdateInterval", InterpreterUpdateInterval.UPDATE_ONCE_STARTUP.value)
        if update_interval_option == InterpreterUpdateInterval.UPDATE_ONCE_STARTUP.value:
            return True
        try:
            # if could not find last update time,update database force
            intellisence_data_path = self.get_interpreter_intellisence_data_path(
                interpreter)
            last_update_time = self.get_last_updatetime(intellisence_data_path)
            last_datetime = datetime.datetime.fromtimestamp(last_update_time)
            log.info('interpreter %s last update time %s',
                     interpreter.name, last_datetime)
        except Exception:
            log.exception('load intellisence last update time exception:')
            return True
        now_datetime = datetime.datetime.now()
        if update_interval_option == InterpreterUpdateInterval.UPDATE_ONCE_DAY.value:
            return now_datetime > last_datetime + datetime.timedelta(hours=24)
        if update_interval_option == InterpreterUpdateInterval.UPDATE_ONCE_WEEK.value:
            return now_datetime > last_datetime + datetime.timedelta(days=7)
        if update_interval_option == InterpreterUpdateInterval.UPDATE_ONCE_MONTH.value:
            return now_datetime > last_datetime + datetime.timedelta(days=30)
        if update_interval_option == InterpreterUpdateInterval.NEVER_UPDATE_ONCE.value:
            return False

    def generate_default_intellisence_data(self):
        current_interpreter = InterpreterManager.manager().GetCurrentInterpreter()
        if current_interpreter is None:
            return
        self.load_intellisence_data(current_interpreter)
        if not self.is_interpreter_need_update_database(current_interpreter):
            log.info('interpreter %s is no need to update database',
                     current_interpreter.name)
            return
        log.info('interpreter %s is need to update database',
                 current_interpreter.name)
        log.info('start generate interpreter %s intellisence data',
                 current_interpreter.name)
        IntellisencedataGen(self, current_interpreter, self.statubar).start()

    def generate_intellisence_data(self, interpreter, progress_dlg):
        IntellisencedataGen(self, interpreter,
                            self.statubar, progress_dlg).start()

    def load_intellisence_data(self, interpreter, async_load=True):
        self._loader.Load(interpreter, async_load)

    def GetImportList(self):
        def _add_icon_id(name):
            return name + "?%d" % iconid.MODULE_ID
        # 全局加载的导入模块列表
        import_list = self._loader.ImportList
        current_project = get_app().get_current_project()
        if current_project is not None:
            # 当前项目里面的导入模块列表
            processor = self.get_codeparser_processor()
            imports = copy.copy(processor.importlist)
            imports.extend(import_list)
            import_list = sorted(imports)
        icon_import_list = list(map(_add_icon_id, import_list))
        return icon_import_list

    def GetBuiltinModule(self):
        return self._loader.BuiltinModule

    def GetModule(self, name):
        d = self.GetModules()
        if name in d:
            return ModuleLoader(name, d[name]['members'], d[name]['apis'], self)
        return None

    def load_modules(self):
        modules = self.GetModules()
        for modname in modules:
            d = modules[modname]
            yield ModuleLoader(modname, d['members'], d['apis'], self)

    def get_codeparser_processor(self):
        return get_app().MainFrame.projectview.get_processor(CODEPARSE_RPROCESSOR_NAME)

    def get_members(self, modname):
        mdloader = self.GetModule(modname)
        if not mdloader:
            return []
        mdloader.load()
        members = []
        temp = set()
        modlen = len(modname.split("."))
        for child in mdloader.data.get(memberkeys.CHILD_KEY_NAME):
            child_modname = child[memberkeys.QUALNAME_KEY_NAME]
            assert child_modname.startswith(modname + ".")
            name = child[memberkeys.NAME_KEY_NAME]
            # 只获取模块顶层的成员信息
            if len(child_modname.split(".")) == modlen + 1:
                icon_id = iconid.get_icon_id(
                    child[memberkeys.OBJTYPE_KEY_NAME],
                    name
                )
                # 防止重复添加相同的子成员名称
                if name not in temp:
                    if icon_id is None:
                        members.append(name)
                    else:
                        members.append(name + "?%d" % icon_id)
                    temp.add(name)
        return members

    def GetModules(self):
        # 所有模块为当前项目的所有模块加上全局模块
        current_project = get_app().get_current_project()
        if current_project is None:
            return self._loader.module_dicts
        processor = self.get_codeparser_processor()
        d = copy.copy(self._loader.module_dicts)
        d.update(processor.module_dicts)
        return d

    def get_definitions(self, defname):
        names = defname.split(".")
        namelen = len(names)
        mdloader = None
        find_module_name = None
        for i in range(1, namelen + 1):
            modnames = names[0:i]
            module_name = ".".join(modnames)
            module = self.GetModule(module_name)
            if module is None:
                break
            mdloader = module
            find_module_name = module_name
        if mdloader is None:
            log.error(
                'could not find defname %s in total %d members file',
                defname,
                len(self.GetModules())
            )
            return set()
        mdloader.load()
        log.info(
            'find module name %s of defname %s in members file:%s',
            find_module_name,
            defname,
            mdloader.membersfile
        )
        definitions = set()
        data = mdloader.data
        if data is None:
            return set()
        codepath = data.get(memberkeys.PATH_KEY_NAME, None)
        if codepath is None:
            log.warning(
                'defname %s in members file %s code path is null',
                defname,
                mdloader.membersfile
            )
        modname = data[memberkeys.QUALNAME_KEY_NAME]
        # 定位到模块
        if defname == modname:
            definitions.add(
                Definition(
                    0, 0,
                    codepath,
                    objtypes.MODULE,
                    defname,
                    modname,
                    data.get(memberkeys.DOC_KEY_NAME, '')
                ))
        else:
            # 定义到模块中的子成员
            for child in data.get(memberkeys.CHILD_KEY_NAME):
                mod_name = child[memberkeys.QUALNAME_KEY_NAME]
                if defname == mod_name:
                    ref_codepath = child.get(memberkeys.PATH_KEY_NAME, None)
                    if ref_codepath is not None:
                        codepath = ref_codepath
                    definitions.add(
                        Definition(
                            child.get(memberkeys.LINE_KEY_NAME, None),
                            child.get(memberkeys.COL_KEY_NAME, None),
                            codepath,
                            child[memberkeys.OBJTYPE_KEY_NAME],
                            defname,
                            mod_name,
                            child.get(memberkeys.DOC_KEY_NAME, '')
                        ))
                elif defname.startswith(mod_name):
                    child_members = []
                    # 引用自其它模块的类
                    if memberkeys.REFER_MODULE_NAME in child:
                        refer_module_name = child[memberkeys.REFER_MODULE_NAME]
                        # 加载引用类的模块
                        ref_mdloader = self.GetModule(refer_module_name)
                        ref_mdloader.load()
                        child_modname = refer_module_name + '.' + child[memberkeys.NAME_KEY_NAME]
                        ref_child = ref_mdloader.find_child(child[memberkeys.NAME_KEY_NAME])
                        if ref_child:
                            # 从引用模块或子模块范围中去寻找
                            if ref_child[memberkeys.OBJTYPE_KEY_NAME] == objtypes.MODULE:
                                submodule_ref_mdloader = self.GetModule(
                                    ref_child[memberkeys.QUALNAME_KEY_NAME]
                                )
                                submodule_ref_mdloader.load()
                                sub_ref_child = submodule_ref_mdloader.find_child(names[-1])
                                if sub_ref_child:
                                    codepath = submodule_ref_mdloader.path
                                    child_members.append(sub_ref_child)
                            # 从引用模块的类范围中去寻找
                            elif ref_child[memberkeys.OBJTYPE_KEY_NAME] == objtypes.CLASS_DEF:
                                ref_defname = child_modname + "." + names[-1]
                                class_member = ref_mdloader.find_member_in_classdef(
                                    ref_child,
                                    ref_defname
                                )
                                if class_member:
                                    codepath = ref_mdloader.path
                                    child_members.append(class_member)
                        else:
                            log.error(
                                'could not find ref child class %s in db file %s',
                                ref_defname,
                                ref_mdloader.membersfile
                            )
                    else:
                        # 模块中定义的类
                        class_member = mdloader.find_member_in_classdef(child, defname)
                        if class_member:
                            child_members.append(class_member)
                    self.find_member_in_classdef_bases(child, names[-1], definitions)
                    for child_member in child_members:
                        definitions.add(
                            Definition(
                                child_member.get(memberkeys.LINE_KEY_NAME, None),
                                child_member.get(memberkeys.COL_KEY_NAME, None),
                                codepath,
                                child_member[memberkeys.OBJTYPE_KEY_NAME],
                                defname,
                                mod_name,
                                child_member.get(memberkeys.DOC_KEY_NAME, '')
                            ))
        if not definitions:
            log.error('could not find defname %s in members file:%s', defname, mdloader.membersfile)
        return definitions

    def load_module_class_bases(self, class_mod_name):
        names = class_mod_name.split(".")
        namelen = len(names)
        mdloader = None
        for i in range(1, namelen + 1):
            modnames = names[0:i]
            module_name = ".".join(modnames)
            module = self.GetModule(module_name)
            if module is None:
                break
            mdloader = module
        if mdloader is None:
            return []
        mdloader.load()
        data = mdloader.data
        for child in data.get(memberkeys.CHILD_KEY_NAME):
            mod_name = child[memberkeys.QUALNAME_KEY_NAME]
            if class_mod_name == mod_name:
                assert child[memberkeys.OBJTYPE_KEY_NAME] == objtypes.CLASS_DEF
                bases = child.get('bases', [])
                base_mod_names = [base[memberkeys.QUALNAME_KEY_NAME]
                                  for base in bases]
                return base_mod_names
        return []

    def fin_class_member_definitions(self, class_mod_name, membername, definitions: set):
        names = class_mod_name.split(".")
        module_name = ".".join(names[0:-1])
        mdloader = self.GetModule(module_name)
        if mdloader is None:
            return
        mdloader.load()
        log.info(
            "try to find member name %s of class module %s in members file %s",
            membername,
            class_mod_name,
            mdloader.membersfile
        )
        data = mdloader.data
        codepath = data.get(memberkeys.PATH_KEY_NAME, None)
        member_mod_name = class_mod_name + "." + membername
        for child in data.get(memberkeys.CHILD_KEY_NAME):
            mod_name = child[memberkeys.QUALNAME_KEY_NAME]
            # 先找到类
            if mod_name == class_mod_name:
                log.info(
                    "find class member %s in members file %s",
                    class_mod_name,
                    mdloader.membersfile
                )
                # 从基类成员中去查找
                self.find_member_in_classdef_bases(child, membername, definitions)
                # 从当前类成员中查找
                class_child = mdloader.find_member_in_classdef(child, member_mod_name)
                if class_child:
                    definitions.add(
                        Definition(
                            class_child.get(memberkeys.LINE_KEY_NAME, None),
                            class_child.get(memberkeys.COL_KEY_NAME, None),
                            codepath,
                            class_child[memberkeys.OBJTYPE_KEY_NAME],
                            member_mod_name,
                            mod_name,
                            class_child.get(memberkeys.DOC_KEY_NAME, '')
                        ))

    def find_member_in_classdef_bases(self, class_data, membername, definitions):
        if class_data[memberkeys.OBJTYPE_KEY_NAME] == objtypes.CLASS_DEF:
            for base in class_data.get(memberkeys.BASES_KEY_NAME, []):
                base_mod_name = base[memberkeys.QUALNAME_KEY_NAME]
                self.fin_class_member_definitions(
                    base_mod_name, membername, definitions)
