# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/PyCQA/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/PyCQA/pylint/blob/main/CONTRIBUTORS.txt

"""tabs checker for Python code."""
from __future__ import annotations
from typing import TYPE_CHECKING
from astroid import nodes
from pylint.checkers import BaseRawFileChecker
from pylint.checkers.utils import only_required_for_messages
if TYPE_CHECKING:
    from pylint.lint import PyLinter


class TabsChecker(BaseRawFileChecker):
    name = "tabs"
    msgs = {
        "W9001": (
            "Tabs detected in code",
            "tabs-detected",
            "Do not use the Tab key in code.",
        )
    }

    @only_required_for_messages("tabs-detected")
    def process_module(self, node: nodes.Module) -> None:
        """
        Process a module.
        The module's content is accessible via ``astroid.stream``
        """
        filepath = node.file
        try:
            with open(filepath, encoding="utf-8") as freader:
                for i, linetext in enumerate(freader):
                    tab_count = linetext.count("\t")
                    if tab_count > 0:
                        self.add_message(
                            "tabs-detected",
                            line=i + 1,
                            col_offset=linetext.find('\t') + 1
                        )

        except Exception:
            pass


def register(linter: PyLinter) -> None:
    linter.register_checker(TabsChecker(linter))
