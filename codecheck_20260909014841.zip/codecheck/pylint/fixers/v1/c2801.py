'''
Name:        c2801.py
Purpose:
Author:      wukan
Created:     2026-05-10
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ....pylint_fix import PylintFixer


DUNDER_METHODS = {
    "__init__": "Instantiate class directly",
    "__del__": "Use del keyword",
    "__repr__": "Use repr built-in function",
    "__str__": "Use str built-in function",
    "__bytes__": "Use bytes built-in function",
    "__format__": "Use format built-in function, format string method, or f-string",
    "__lt__": "Use < operator",
    "__le__": "Use <= operator",
    "__eq__": "Use == operator",
    "__ne__": "Use != operator",
    "__gt__": "Use > operator",
    "__ge__": "Use >= operator",
    "__hash__": "Use hash built-in function",
    "__bool__": "Use bool built-in function",
    "__getattr__": "Access attribute directly or use getattr built-in function",
    "__getattribute__": "Access attribute directly or use getattr built-in function",
    "__setattr__": "Set attribute directly or use setattr built-in function",
    "__delattr__": "Use del keyword",
    "__dir__": "Use dir built-in function",
    "__get__": "Use get method",
    "__set__": "Use set method",
    "__delete__": "Use del keyword",
    "__instancecheck__": "Use isinstance built-in function",
    "__subclasscheck__": "Use issubclass built-in function",
    "__call__": "Invoke instance directly",
    "__len__": "Use len built-in function",
    "__length_hint__": "Use length_hint method",
    "__getitem__": "Access item via subscript",
    "__setitem__": "Set item via subscript",
    "__delitem__": "Use del keyword",
    "__iter__": "Use iter built-in function",
    "__next__": "Use next built-in function",
    "__reversed__": "Use reversed built-in function",
    "__contains__": "Use in keyword",
    "__add__": "Use + operator",
    "__sub__": "Use - operator",
    "__mul__": "Use * operator",
    "__matmul__": "Use @ operator",
    "__truediv__": "Use / operator",
    "__floordiv__": "Use // operator",
    "__mod__": "Use % operator",
    "__divmod__": "Use divmod built-in function",
    "__pow__": "Use ** operator or pow built-in function",
    "__lshift__": "Use << operator",
    "__rshift__": "Use >> operator",
    "__and__": "Use & operator",
    "__xor__": "Use ^ operator",
    "__or__": "Use | operator",
    "__radd__": "Use + operator",
    "__rsub__": "Use - operator",
    "__rmul__": "Use * operator",
    "__rmatmul__": "Use @ operator",
    "__rtruediv__": "Use / operator",
    "__rfloordiv__": "Use // operator",
    "__rmod__": "Use % operator",
    "__rdivmod__": "Use divmod built-in function",
    "__rpow__": "Use ** operator or pow built-in function",
    "__rlshift__": "Use << operator",
    "__rrshift__": "Use >> operator",
    "__rand__": "Use & operator",
    "__rxor__": "Use ^ operator",
    "__ror__": "Use | operator",
    "__iadd__": "Use += operator",
    "__isub__": "Use -= operator",
    "__imul__": "Use *= operator",
    "__imatmul__": "Use @= operator",
    "__itruediv__": "Use /= operator",
    "__ifloordiv__": "Use //= operator",
    "__imod__": "Use %= operator",
    "__ipow__": "Use **= operator",
    "__ilshift__": "Use <<= operator",
    "__irshift__": "Use >>= operator",
    "__iand__": "Use &= operator",
    "__ixor__": "Use ^= operator",
    "__ior__": "Use |= operator",
    "__neg__": "Multiply by -1 instead",
    "__pos__": "Multiply by +1 instead",
    "__abs__": "Use abs built-in function",
    "__invert__": "Use ~ operator",
    "__complex__": "Use complex built-in function",
    "__int__": "Use int built-in function",
    "__float__": "Use float built-in function",
    "__round__": "Use round built-in function",
    "__trunc__": "Use math.trunc function",
    "__floor__": "Use math.floor function",
    "__ceil__": "Use math.ceil function",
    "__enter__": "Invoke context manager directly",
    "__aenter__": "Invoke context manager directly",
    "__copy__": "Use copy.copy function",
    "__deepcopy__": "Use copy.deepcopy function",
    "__fspath__": "Use os.fspath function instead",
    "__aiter__": "Use aiter built-in function",
    "__anext__": "Use anext built-in function"
}


class PylintC2801Fixer(PylintFixer):
    '''
    规则说明:调用对象的魔鬼方法,可以使用内建函数或者关键字代替
    '''

    def __init__(self):
        super().__init__('C2801', True)

    def fix_message(self, msg):
        msgnode = self.find_msg_node(msg, use_column=False)
        msg_column_node = self.find_msg_node(msg, use_column=True)
        if not msgnode:
            return False
        res = re.search(
            r"Unnecessarily calls dunder method (.*)\. (.*)\. \(unnecessary-dunder-call\)",
            msg.msg
        )
        call_func_name, reptext = res.groups()
        if call_func_name not in DUNDER_METHODS or DUNDER_METHODS[call_func_name] != reptext:
            return False
        parent_call_node = ScopeFinder.get_parent_node_by_nodeclass(msg_column_node, nodes.Call)
        if parent_call_node is not None:
            msgnode = parent_call_node
        if isinstance(msgnode, nodes.Call):
            if call_func_name == "__contains__":
                repnode_text = "%s in %s" % (
                    msgnode.args[0].as_string(),
                    msgnode.func.expr.as_string()
                )
                self.fix_node_text(msgnode, repnode_text)
                return True
            if reptext.find('built-in function') != -1:
                res = re.search(r'Use\s+(.*)\s+built-in\sfunction', reptext, flags=re.I)
                builtin_func_name = res.groups()[0]
                func_expr_str = msgnode.func.expr.as_string()
                if msgnode.args:
                    argstr = ",".join([arg.as_string() for arg in msgnode.args])
                    repnode_text = "%s(%s,%s)" % (builtin_func_name, func_expr_str, argstr)
                else:
                    repnode_text = "%s(%s)" % (builtin_func_name, func_expr_str)
                self.fix_node_text(msgnode, repnode_text)
                return True
        return False
