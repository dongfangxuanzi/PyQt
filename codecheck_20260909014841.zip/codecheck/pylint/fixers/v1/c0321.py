'''
Name:        c0321.py
Purpose:
Author:      wukan
Created:     2026-05-14
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from ....pylint_fix import PylintFixer
from ....codeutils import get_node_col_offset_blanks


class PylintC0321Fixer(PylintFixer):
    '''
    规则说明: 多个语句写在一行
    '''

    def __init__(self):
        super().__init__('C0321', True)

    @staticmethod
    def get_oneline_parent_node(node):
        '''
        获取和当前节点同行号的最顶层父节点
        '''
        pnode = node.parent
        nodelist = []
        while pnode.statement().fromlineno == node.fromlineno:
            nodelist.append(pnode)
            pnode = pnode.parent
            if not pnode.is_statement:
                break
        return nodelist[-1]

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        prev_sibl = node.previous_sibling()
        if prev_sibl is not None:
            prev_line = prev_sibl.fromlineno
        elif isinstance(node.parent, nodes.Module):
            prev_line = 0
        else:
            prev_line = node.parent.statement().fromlineno
        line = node.fromlineno
        if prev_line == line:
            pnode = self.get_oneline_parent_node(node)
            nodestr = pnode.as_string()
            lines = nodestr.splitlines(keepends=True)
            for i, line in enumerate(lines[1:]):
                lines[i + 1] = get_node_col_offset_blanks(pnode) + line
            newstr = ''.join(lines)
            self.fix_node_text(pnode, newstr)
            return True
        return False
