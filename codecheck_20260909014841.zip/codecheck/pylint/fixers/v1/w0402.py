from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintW0402Fixer(PylintFixer):
    '''
    规则说明: 过期的模块
    '''
    REPLACE_DEPRECATED_MODULES = {
        "optparse": "argparse",
        "tkinter.tix": "tkinter.ttk",
        "xml.etree.cElementTree": "xml.etree.ElementTree",
        "imp": "importlib",
        "distutils": "setuptools"
    }

    def __init__(self):
        super().__init__('W0402', False)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Import):
            modname = node.names[0][0]
            if modname in self.REPLACE_DEPRECATED_MODULES:
                replace_modname = self.REPLACE_DEPRECATED_MODULES[modname]
                fixstr = "import %s" % replace_modname
                self.fix_node_text(node, fixstr)
                return True
        return False
