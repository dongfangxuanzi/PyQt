from astroid import nodes
from ....pylint_fix import PylintFixer
from ....codeutils import DEFAULT_TAB_BLANKS


class PylintR1735Fixer(PylintFixer):
    '''
    规则说明: 赋值空字典不要使用dict(),应使用{}
    '''

    def __init__(self):
        super().__init__('R1735', True)

    @staticmethod
    def _dict_literal_suggestion(node: nodes.Call) -> str:
        """Return a suggestion of reasonable length."""
        elements: list[str] = []
        for keyword in node.keywords:
            if keyword not in node.kwargs:
                elements.append(
                    f'"{keyword.arg}": {keyword.value.as_string()}')
        for keyword in node.kwargs:
            if len(", ".join(elements)) >= 64:
                break
            elements.append(f"**{keyword.value.as_string()}")
        suggestion = ", ".join(elements)
        return suggestion

    @staticmethod
    def _get_dict_literal_fixes(node: nodes.Call) -> str:
        """Return a suggestion of reasonable length."""
        target = node.parent.targets[0]
        blanks = DEFAULT_TAB_BLANKS + target.col_offset * ' '
        elements: list[str] = ["{"]
        for keyword in node.keywords:
            if keyword not in node.kwargs:
                elements.append(
                    blanks + f'"{keyword.arg}": {keyword.value.as_string()},')
        elements[-1] = elements[-1].rstrip(',')
        elements.append(target.col_offset * ' ' + "}")
        suggestion = "\n".join(elements)
        return suggestion

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        pnode = node.parent
        if isinstance(node, nodes.Name) and node.name == 'dict' and isinstance(pnode, nodes.Call):
            if pnode.as_string() == "dict()":
                nodestr = '{}'
                self.fix_node_text(pnode, nodestr)
                return True
            fixstr = "{%s}" % self._dict_literal_suggestion(pnode)
            if len(fixstr) > 80:
                fixstr = self._get_dict_literal_fixes(pnode)
            self.fix_node_text(pnode, fixstr)
            return True
        return False
