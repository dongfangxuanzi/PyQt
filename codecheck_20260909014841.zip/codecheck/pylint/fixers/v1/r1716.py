from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR1716Fixer(PylintFixer):
    '''
    规则说明: 使用1个连等比较表达式代替2个比较表达式
    '''

    def __init__(self):
        super().__init__('R1716', True)

    def fix_boolop_node(self, node):
        left_compare, right_compare = node.values
        left_compare_ops = left_compare.ops[0]
        chain_compare_str = left_compare_ops[1].as_string()
        chain_compare_str += left_compare_ops[0].replace('>', '<')
        chain_compare_str += left_compare.left.as_string()
        assert (left_compare.left.as_string() ==
                right_compare.left.as_string())
        right_compare_ops = right_compare.ops[0]
        chain_compare_str += right_compare_ops[0]
        chain_compare_str += right_compare_ops[1].as_string()
        self.fix_node_text(node, chain_compare_str)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node.parent, nodes.If) and (
            isinstance(node, nodes.BoolOp) and node.op == "and"
        ):
            self.fix_boolop_node(node)
            return True
        if isinstance(node, nodes.Assert) and (
            isinstance(node.test, nodes.BoolOp) and node.test.op == "and"
        ):
            self.fix_boolop_node(node.test)
            return True
        return False
