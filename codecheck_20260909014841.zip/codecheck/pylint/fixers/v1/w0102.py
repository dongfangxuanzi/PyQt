import os
from astroid import nodes
from novalapp.python.parser.node_utils import get_builtin_type, safe_infer
from ....pylint_fix import PylintFixer


class PylintW0102Fixer(PylintFixer):
    '''
    规则说明:参数默认值不能使用字典列表作为默认值
    '''
    KNOWN_VAR_TYPES = {
        nodes.List: 'list',
        nodes.Set: 'set',
        nodes.Dict: 'dict'
    }

    def __init__(self):
        super().__init__('W0102', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef):
            return self.fix_dangerous_default_value(node.parent)
        if isinstance(node, nodes.AssignName) and (
            isinstance(node.parent, nodes.Arguments) and isinstance(node.parent.parent, nodes.FunctionDef)
        ):
            return self.fix_dangerous_default_value(node.parent.parent)
        return False

    def fix_dangerous_default_value(self, node):
        danger_index = -1
        default_args = node.args.defaults or node.args.kw_defaults
        defaults_num = len(default_args)
        for i, default_val in enumerate(default_args):
            if isinstance(default_val, (nodes.List, nodes.Dict)):
                danger_index = i - defaults_num
                break
        if node.args.defaults:
            default_arg = node.args.args[danger_index]
        elif node.args.kw_defaults:
            default_arg = node.args.kwonlyargs[danger_index]
        default_val = default_args[danger_index]
        self.fix_node_text(default_val, "None")
        optional_name = 'Optional'
        try:
            builtin_type_name = get_builtin_type(default_val)
        except AttributeError:
            infer_default_val = safe_infer(default_val)
            builtin_type_name = self.KNOWN_VAR_TYPES.get(type(infer_default_val), None)
            if builtin_type_name is None:
                return False
        reptext = default_arg.name + f": {optional_name}[{builtin_type_name}]"
        self.fix_node_text(default_arg, reptext)

        first_body = node.body[0]
        insert_line = first_body.lineno
        blanks = first_body.col_offset * ' '
        fix_default_arg_str = f'{default_arg.name}={default_arg.name} or {default_val.as_string()}'
        self.add_range_text(
            insert_line,
            0,
            blanks + fix_default_arg_str + os.linesep
        )
        visitor = self.get_import_nodes_visitor()
        if not visitor.is_fromimport_exist('typing', optional_name):
            insert_line = visitor.get_import_line()
            self.add_range_text(
                insert_line + 1,
                0,
                f'from typing import {optional_name}' + os.linesep
            )
        return True
