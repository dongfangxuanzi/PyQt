import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintC1804Fixer(PylintFixer):
    '''
    规则说明:
    1.如果字符串为空,不用与空字符串比较,直接用not逻辑表达式即可(此处修复方案有点风险,
    不能使用自动修复,需要用户自行确认是否修复)
    '''

    def __init__(self):
        super().__init__('C1804', False)

    def fix_compare_node(self, compare_node, fixstr):
        if compare_node.ops and compare_node.ops[0]:
            if fixstr.find('not ') != -1:
                repname = fixstr.replace("not", "").strip()
            else:
                repname = fixstr
            if compare_node.ops[0][0] == '==':
                self.fix_node_text(compare_node, f'not {repname}')
                return True
            if compare_node.ops[0][0] == '!=':
                self.fix_node_text(compare_node, f'{repname}')
                return True
        return False

    def fix_message(self, msg):
        res = re.search(
            r'"(.*)" can be simplified to "(.*)", if it is striclty a string',
            msg.msg
        )
        nodestr = res.groups()[1]
        node = self.find_msg_node(msg, use_column=True)
        compare_node = self.get_classtype_parent_node(node, nodes.Compare)
        if compare_node and isinstance(compare_node, nodes.Compare):
            if self.fix_only_autofix():
                return False
            return self.fix_compare_node(compare_node, nodestr)
        return False
