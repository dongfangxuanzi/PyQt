# -*- coding: utf-8 -*-
import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintW0602Fixer(PylintFixer):
    '''
    规则说明:仅使用全局变量未赋值,不需要使用global申明
    '''

    def __init__(self):
        super().__init__('W0602', True)

    def fix_message(self, msg):
        res = re.search(
            r"Using global for '(.*)' but no assignment is done \(global-variable-not-assigned\)",
            msg.msg
        )
        if not res:
            return False
        globalname = res.groups()[0]
        node = self.find_msg_node(msg, use_column=True)
        if isinstance(node, nodes.Global) and globalname in node.names:
            node.names.remove(globalname)
            if not node.names:
                return self.delete_node(node)
            self.fix_node(node)
            return True
        return False
