'''
Name:        r1711.py
Purpose:
Author:      wukan
Created:     2026-09-05
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from typing import cast
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR1711Fixer(PylintFixer):
    '''
    规则说明: 函数最后的返回return语句多余
    '''

    def __init__(self):
        super().__init__('R1711', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef):
            funcnode = cast(nodes.FunctionDef, node.parent)
            end_node = funcnode.body[-1]
            if isinstance(end_node, nodes.Return) and end_node.as_string() == "return":
                return self.delete_node(end_node, delete_node_line=True)
        return False
