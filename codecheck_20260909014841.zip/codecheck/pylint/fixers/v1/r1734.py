from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR1734Fixer(PylintFixer):
    '''
    规则说明: 赋值空列表不要使用list(),应使用[]
    '''

    def __init__(self):
        super().__init__('R1734', True)

    def fix_list_node(self, value_node):
        nodestr = '[]'
        self.fix_node_text(value_node, nodestr)
        return True

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        pnode = node.parent
        if isinstance(node, nodes.Name) and node.name == 'list' and isinstance(pnode, nodes.Call):
            if pnode.as_string() == "list()":
                return self.fix_list_node(pnode)
        return False
