import logging
from astroid import nodes
import astroid
from ....pylint_fix import PylintFixer


log = logging.getLogger(__name__)


class PylintE0710Fixer(PylintFixer):
    '''
    规则说明:异常类没有继承自Exception
    '''

    def __init__(self):
        super().__init__('E0710', True)

    def is_raise_node_line(self, line):
        node = self.find_node_on_line(line)
        if not isinstance(node, nodes.Raise):
            return False
        return True

    def fix_message(self, msg):
        line = msg.line
        self.load_msg_module(msg)
        if not self.is_raise_node_line(line):
            return False
        node = self.find_node_on_line(line)
        try:
            for infered in node.exc.func.infer():
                if infered == astroid.Uninferable:
                    continue
                if isinstance(infered, nodes.ClassDef):
                    position = infered.position
                    if not infered.bases:
                        self.add_range_text(position.lineno, position.end_col_offset, "(Exception)")
                    else:
                        base_class_node = infered.bases[0]
                        self.fix_node_text(base_class_node, "Exception")
                    return True
        except astroid.InferenceError as ex:
            log.error(str(ex))
        return False
