import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR0402Fixer(PylintFixer):
    '''
    规则说明:使用from import语句代替import as语句
    '''

    def __init__(self):
        super().__init__('R0402', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Import):
            res = re.search(
                r"Use '(.*)' instead \(consider-using-from-import\)", msg.msg)
            if res is not None:
                fixstr = res.groups()[0]
                module_name, import_name = re.search(
                    r"from (.*) import (\w+)", fixstr).groups()
                full_import_name = "%s.%s" % (module_name, import_name)
                if full_import_name == node.names[0][0]:
                    self.fix_node_text(node, fixstr)
                    return True
        return False
