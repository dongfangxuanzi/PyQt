from ....pylint_fix import PylintFixer


class PylintC0303Fixer(PylintFixer):
    '''
    规则说明:代码行以空白字符串结尾
    '''

    def __init__(self):
        super().__init__('C0303', True)

    def fix_message(self, msg):
        self.do_rstrip_line(msg.line)
        return True
