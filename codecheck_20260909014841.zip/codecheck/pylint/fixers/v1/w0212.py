from ....pylint_fix import SarifFixer


class PylintW0212Fixer(SarifFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('W0212', False)

    def fix_message(self, msg):
        self.load_module(msg.filepath)
