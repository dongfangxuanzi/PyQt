from ....pylint_fix import PylintFixer


class PylintW9000Fixer(PylintFixer):
    '''
    规则说明: 注释无效/废弃代码
    '''

    def __init__(self):
        super().__init__('W9000', False)

    def fix_message(self, msg):
        linetext = self.get_msg_line_text(msg)
        if not linetext.lstrip().startswith('#'):
            return False
        self.delete_text_line(msg.line - 1)
        return True
