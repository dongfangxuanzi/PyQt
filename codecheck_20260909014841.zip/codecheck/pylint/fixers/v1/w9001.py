from novalapp import constants
from ....pylint_fix import PylintFixer


class PylintW9001Fixer(PylintFixer):
    '''
    规则说明: 代码中包含tab键
    '''

    def __init__(self):
        super().__init__('W9001', False)

    def fix_message(self, msg):
        linetext = self.get_msg_line_text(msg)
        if linetext.find('\t') == -1:
            return False
        newtext = linetext.expandtabs(constants.DEFAULT_TAB_INDENTATION_WIDTH)
        self.replace_line_text(msg.line, newtext)
        return True
