from ....pylint_fix import PylintFixer


class PylintC0327Fixer(PylintFixer):
    '''
    规则说明:混合行尾
    '''

    def __init__(self):
        super().__init__('C0327', True)

    def fix_message(self, msg):
        return self.replace_text_eol()
