from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintC0123Fixer(PylintFixer):
    '''
    规则说明:用isinstance代替type判断变量类型
    '''

    def __init__(self):
        super().__init__('C0123', True)

    @staticmethod
    def is_type_extr(node):
        '''
        :param node:判断节点是否包含type节点
        :type node:
        :return:
        :rtype: bool
        '''
        if isinstance(node, nodes.Compare):
            left = node.left
            if isinstance(left, nodes.Call) and isinstance(left.func, nodes.Name) \
                    and left.func.name == 'type':
                return True
        return False

    @classmethod
    def find_type_extr(cls, node):
        if cls.is_type_extr(node):
            return node
        for child in node.get_children():
            if isinstance(child, nodes.Compare):
                if cls.is_type_extr(child):
                    return child
            else:
                expr = cls.find_type_extr(child)
                if expr:
                    return expr
        return None

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        type_expr = self.find_type_extr(node)
        if not type_expr:
            return False
        type_name = type_expr.left.args[0]
        oprand = type_expr.ops[0][0]
        target = type_expr.ops[0][1]
        fixstr = ""
        if oprand == "!=":
            fixstr += "not "
        fixstr += f"isinstance({type_name.as_string()}, {target.as_string()})"
        self.fix_node_text(type_expr, fixstr)
        return True
