from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintE0711Fixer(PylintFixer):
    '''
    规则说明: 抛出未实现方法异常要用raise NotImplementedError而不是raise NotImplemented
    '''

    def __init__(self):
        super().__init__('E0711', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Raise):
            nodestr = node.as_string()
            fixstr = nodestr.replace("NotImplemented", "NotImplementedError")
            self.fix_node_text(node, fixstr)
            return True
        return False
