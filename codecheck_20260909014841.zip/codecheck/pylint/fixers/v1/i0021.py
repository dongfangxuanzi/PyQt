import re
from ....pylint_fix import PylintFixer
from .w0511 import PylintW0511Fixer


class PylintI0021Fixer(PylintW0511Fixer):
    '''
    规则说明:无用的抑制规则格式语句,抑制的规则编号可能不存在或者已经失效过期
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'I0021', True)

    @staticmethod
    def is_rule_id(ruletext):
        return re.search(r'\w{1}\d{3,}', ruletext)

    @staticmethod
    def search_suppressed_linetext(linetext):
        regtext = r'#\s*pylint:\s*disable\s*=\s*(.*)'
        res = re.search(regtext, linetext)
        return res

    @classmethod
    def search_suppressed_ruleid(cls, linetext):
        res = cls.search_suppressed_linetext(linetext)
        return res.groups()[0]

    def search_suppressed_line(self, line):
        linetext = self.get_line_text(line)
        return self.search_suppressed_linetext(linetext)

    def fix_message(self, msg):
        line_text = self.get_msg_line_text(msg)
        if line_text is None:
            return False
        res = self.search_suppressed_linetext(line_text)
        if res:
            ruletext = res.groups()[0]
            msgres = re.search(
                r"Useless suppression of '(.*)' \(useless-suppression\)", msg.msg)
            msg_rulename = msgres.groups()[0]
            if ruletext != msg_rulename:
                newtext = line_text.replace(ruletext, msg_rulename)
                self.replace_line_text(msg.line, newtext)
            else:
                self.delete_comment_msg_line(msg)
            return True
        return False


class PylintI0020Fixer(PylintI0021Fixer):
    '''
    规则说明: pylint抑制规则格式语句
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'I0020', False)

    def fix_message(self, msg):
        res = re.search(
            r"Suppressed '(.*)' \(from line (\d+)\) \(suppressed-message\)", msg.msg)
        suppressed_line = int(res.groups()[1])
        res = self.search_suppressed_line(suppressed_line - 1)
        if res:
            self.delete_comment_line(suppressed_line - 1)
            return True
        return False


class PylintI0023Fixer(PylintI0021Fixer):
    '''
    规则说明:抑制规则不要使用比较模糊的规则编号,应使用规则名称
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'I0023', True)

    def fix_message(self, msg):
        line_text = self.get_msg_line_text(msg)
        if line_text is None:
            return False
        res = self.search_suppressed_linetext(line_text)
        if not res:
            return False
        ruleid = res.groups()[0]
        res = re.search(
            r"'(.*)' is cryptic: use '(.*)' instead \(use-symbolic-message-instead\)",
            msg.msg
        )
        msg_ruleid, suppressed_text = res.groups()
        if ruleid == msg_ruleid:
            msg_rulename = self.search_suppressed_ruleid(suppressed_text)
            newtext = line_text.replace(ruleid, msg_rulename)
            self.replace_line_text(msg.line, newtext)
            return True
        return False


class PylintW0012Fixer(PylintW0511Fixer):
    '''
    规则说明:无用的抑制规则格式语句,抑制的规则名称可能不存在或者已经失效过期
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'W0012', True)

    def fix_message(self, msg):
        line_text = self.get_msg_line_text(msg)
        if line_text is None:
            return False
        res = PylintI0021Fixer.search_suppressed_linetext(line_text)
        if res:
            ruletext = res.groups()[0]
            msgres = re.search(
                r"Unknown option value for 'disable', expected a valid pylint message and got '(.*)' \(unknown-option-value\)",
                msg.msg
            )
            msg_rulename = msgres.groups()[0]
            if ruletext == msg_rulename:
                self.delete_comment_msg_line(msg)
                return True
        return False
