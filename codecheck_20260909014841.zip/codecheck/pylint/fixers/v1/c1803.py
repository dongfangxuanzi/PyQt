'''
Name:        c1803.py
Purpose:     修复隐式表达式
Author:      wukan
Created:     2026-09-16
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintC1803Fixer(PylintFixer):
    '''
    规则说明: 与空列表比较不要使用!=[],使用列表隐式表达式判断bool值
    '''

    def __init__(self):
        super().__init__('C1803', False)

    def fix_compare_node(self, compare_node, fixstr):
        if compare_node.ops and compare_node.ops[0]:
            if fixstr.find('not ') != -1:
                repname = fixstr.replace("not", "").strip()
            else:
                repname = fixstr
            if compare_node.ops[0][0] == '==':
                self.fix_node_text(compare_node, f'not {repname}')
                return True
            if compare_node.ops[0][0] == '!=':
                self.fix_node_text(compare_node, f'{repname}')
                return True
        return False

    def fix_message(self, msg):
        res = re.search(
            r'"(.*)" can be simplified to "(.*)", if it is strictly a sequence',
            msg.msg
        )
        nodestr = res.groups()[1]
        node = self.find_msg_node(msg, use_column=True)
        compare_node = self.get_classtype_parent_node(node, nodes.Compare)
        if compare_node and isinstance(compare_node, nodes.Compare):
            if self.fix_only_autofix():
                return False
            return self.fix_compare_node(compare_node, nodestr)
        return False
