import re
from ....pylint_fix import PylintFixer


class PylintE0001Fixer(PylintFixer):
    '''
    规则说明:包含制表符以及print用法的语法错误修复
    '''

    def __init__(self):
        super().__init__('E0001', True)

    def fix_message(self, msg):
        line = msg.line
        tab_error_msg = r"inconsistent use of tabs and spaces in indentation \(<unknown>, line (\d+)\) \(syntax-error\)"
        newtab_error_msg = r"'inconsistent use of tabs and spaces in indentation \(<unknown>, line (\d+)\)' \(syntax-error\)"
        print_error_msg = r"Missing parentheses in call to 'print'. Did you mean print\(.*\)? \(<unknown>, line (\d+)\) \(syntax-error\)"
        tab_error_res = re.search(tab_error_msg, msg.msg)
        newtab_error_res = re.search(newtab_error_msg, msg.msg)
        print_error_res = re.search(print_error_msg, msg.msg)
        if tab_error_res or newtab_error_res:
            self.convert_tabs_to_spaces()
            return True
        if print_error_res:
            error_line = int(print_error_res.groups()[0])
            assert error_line == line + 1
            line_text = self.get_msg_line_text(msg)
            print_keyword = "print"
            i = line_text.find(print_keyword)
            i += len(print_keyword)
            newline = line_text[0:i] + "(" + line_text[i:] + ")"
            self.replace_text_line(line, newline)
            return True
        return False
