from novalapp.sidebar.todo import TodoProcessor
from ....pylint_fix import PylintFixer


class PylintW0511Fixer(PylintFixer):
    '''
    规则说明:fixme/todo注释
    '''

    def __init__(self):
        super().__init__('W0511', False)

    @staticmethod
    def is_todo_line_text(line_text):
        return TodoProcessor.is_todo_line_text(line_text)

    def is_todo_line(self, line):
        line_text = self.get_line_text(line)
        return self.is_todo_line_text(line_text)

    def is_msg_todo_line(self, msg):
        line_text = self.get_msg_line_text(msg)
        return self.is_todo_line_text(line_text)

    def get_todo_lines(self, line):
        '''
        todo注释可能有多行,如果删除todo则多行todo注释都要删除
        '''
        todo_line_indexes = [line]
        while True:
            line += 1
            if not self.is_comment_line(line) or self.is_todo_line(line):
                break
            todo_line_indexes.append(line)
        return todo_line_indexes

    def delete_comment_msg_line(self, msg, is_todo_msg=False):
        '''
        删除注释行,如果注释在行首则删除整行,如果注释在行尾,则删除行尾注释,不影响代码
        '''
        self.delete_comment_line(msg.line - 1, is_todo_msg)

    def delete_comment_line(self, line, is_todo_msg=False):
        '''
        删除注释行,如果注释在行首则删除整行,如果注释在行尾,则删除行尾注释,不影响代码
        '''
        msg_line = line
        if self.is_comment_line(msg_line):
            # 如果是todo注释,则需要删除todo行之后的连续几行注释,
            # 这些多行注释内容均作为todo注释内容
            if is_todo_msg:
                todo_lines = self.get_todo_lines(msg_line)
                for todo_line in todo_lines[::-1]:
                    self.delete_text_line(todo_line)
            else:
                self.delete_text_line(msg_line)
        else:
            line_text = self.get_line_text(line)
            comment_index = line_text.find('#')
            textlen = self.get_linetext_len(line)
            line += 1
            self.replace_range_text(line, "", comment_index, line, textlen)

    def fix_message(self, msg):
        if not self.is_msg_todo_line(msg):
            return False
        self.delete_comment_msg_line(msg, is_todo_msg=True)
        return True
