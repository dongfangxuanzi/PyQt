import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintC1805Fixer(PylintFixer):
    '''
    规则说明:
    1.判断列表是否未空,不能用列表长度为0判断,使用逻辑表达式即可
    2.如果整数为0,不用和0比较,直接用not逻辑表达式即可(此处修复方案有点风险,
    不能使用自动修复,需要用户自行确认是否修复)
    '''

    def __init__(self):
        super().__init__('C1805', True)

    def fix_compare_node(self, compare_node, fixstr):
        if compare_node.ops and compare_node.ops[0]:
            if fixstr.find('len(') != -1:
                repname = re.search(r"len\((.*)\)", fixstr).groups()[0]
                if not self.extract_node_with_text(repname):
                    return False
            elif fixstr.find('not ') != -1:
                if self.fix_only_autofix():
                    return False
                repname = fixstr.replace("not", "").strip()
            else:
                if self.fix_only_autofix():
                    return False
                repname = fixstr
            if compare_node.ops[0][0] == '==':
                self.fix_node_text(compare_node, f'not {repname}')
                return True
            if compare_node.ops[0][0] == '!=':
                self.fix_node_text(compare_node, f'{repname}')
                return True
        return False

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r'"(.*)" can be simplified to "(.*)", if it is strictly an int, as 0 is falsey',
            msg.msg
        )
        nodestr = res.groups()[1]
        compare_node = self.get_classtype_parent_node(node, nodes.Compare)
        if not compare_node:
            return False
        return self.fix_compare_node(compare_node, nodestr)
