from astroid import nodes
from novalapp.python.parser import node_utils
from ....pylint_fix import PylintFixer


class PylintC0121Fixer(PylintFixer):
    '''
    规则说明: 使用is和None,True,False比较,而不是使用==
    '''

    def __init__(self):
        # 支持自动修复
        super().__init__('C0121', True)

    def fix_compare_node(self, node):
        '''
        修复比较语句==None为is None
        修复比较语句==False为is False
        修复比较语句==True为is True
        :param node:
        :type node: astroid.nodes
        :return: 是否修复成功
        :rtype: bool
        '''
        ops = node.ops
        if ops and ops[0][0] in ['==', '!=']:
            if isinstance(ops[0][1], nodes.Const) and ops[0][1].value is None:
                if ops[0][0] == "==":
                    fixtext = f"{node.left.as_string()} is None"
                else:
                    fixtext = f"{node.left.as_string()} is not None"
                self.fix_node_text(node, fixtext)
                return True
            if isinstance(node.left, nodes.Const) and node.left.value is None:
                if ops[0][0] == "==":
                    fixtext = f"{ops[0][1].as_string()} is None"
                else:
                    fixtext = f"{ops[0][1].as_string()} is not None"
                self.fix_node_text(node, fixtext)
                return True

            if node_utils.is_const_type(ops[0][1], bool):
                const_value = ops[0][1].value
                if ops[0][0] == "==":
                    fixtext = f"{node.left.as_string()} is {const_value}"
                else:
                    not_const_value = not const_value
                    fixtext = f"{node.left.as_string()} is {not_const_value}"
                self.fix_node_text(node, fixtext)
                return True
            if node_utils.is_const_type(node.left, bool):
                const_value = ops[0][1].value
                if ops[0][0] == "==":
                    fixtext = f"{ops[0][1].as_string()} is {const_value}"
                else:
                    not_const_value = not const_value
                    fixtext = f"{ops[0][1].as_string()} is {not_const_value}"
                self.fix_node_text(node, fixtext)
                return True
        return False

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        compare_node = self.get_classtype_parent_node(node, nodes.Compare)
        if compare_node and isinstance(compare_node, nodes.Compare):
            return self.fix_compare_node(compare_node)
        return False
