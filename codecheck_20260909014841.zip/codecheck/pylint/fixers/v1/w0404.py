'''
Name:        w0404.py
Purpose:     修复重复导入模块
Author:      wukan
Created:     2026-08-22
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintW0404Fixer(PylintFixer):
    '''
    规则说明:重复导入模块
    '''

    def __init__(self):
        super().__init__('W0404', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if node is None:
            return False
        res = re.search(
            r"Reimport '(\w+)' \(imported line (\d+)\) \(reimported\)", msg.msg)
        if res is None:
            return False
        import_name, _import_line = res.groups()
        if isinstance(node, (nodes.Import, nodes.ImportFrom)):
            return self.delete_import_name(node, import_name)
        return False
