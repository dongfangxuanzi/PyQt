import re
from astroid import nodes
from ....pylint_fix import PylintFixer
from ....multifixer import MultiOptionFixer


class PylintW0109Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:字典重复键
    '''

    def __init__(self):
        super().__init__('W0109', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Fix duplicate key',
            descr="Please choose one delete key option"
        )

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Assign) and isinstance(node.value, nodes.Dict):
            res = re.search(
                r"Duplicate key '(.*)' in dictionary \(duplicate-key\)", msg.msg)
            dup_key = res.groups()[0]
            dup_indexes = []
            items = node.value.items
            for i, (k, _v) in enumerate(items):
                if isinstance(k, nodes.Const):
                    key_name = k.value
                elif isinstance(k, nodes.Attribute):
                    key_name = k.as_string()
                else:
                    continue
                if dup_key == key_name:
                    dup_indexes.append(i)
            if len(dup_indexes) >= 2:
                choices = []
                for index in dup_indexes:
                    item = items[index]
                    choices.append("delete duplicate key-%s:%s" %
                                   (item[0].as_string(), item[1].as_string()))

                self._options = choices
                self.get_selection()
                selindex = dup_indexes[self.selection]
                del items[selindex]
                self.fix_node(node)
                return True
        return False
