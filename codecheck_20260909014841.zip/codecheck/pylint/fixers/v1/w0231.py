'''
Name:        w0231.py
Purpose:
Author:      wukan
Created:     2026-05-13
Copyright:   (c) wukan 2026
Licence:     Mulan
'''
import os
import re
import logging
from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp.python.parser.define import CLASS_INIT_METHOD, SELF_ARG_NAME
from novalapp.python.parser import node_utils
import astroid
from ....pylint_fix import PylintFixer
log = logging.getLogger(__name__)


class PylintW0231Fixer(PylintFixer):
    '''
    规则说明: 子类继承父类时没有调用父类的__init__方法
    '''

    def __init__(self):
        super().__init__('W0231', True)

    @staticmethod
    def get_method_init_args(derived_init_method_node):
        '''
        获取基类__init__方法和派生__init__方法的共同参数
        '''
        init_args = derived_init_method_node.args.args
        derived_class = derived_init_method_node.parent
        class_bases = derived_class.bases
        arg_names = []
        for base_class_name_node in class_bases:
            infer_base_class = node_utils.safe_infer(base_class_name_node)
            if infer_base_class is None or infer_base_class is astroid.Uninferable:
                continue
            base_init_method_node = ScopeFinder.get_class_method_node(
                infer_base_class,
                CLASS_INIT_METHOD
            )
            base_init_argnames = [arg.as_string() for arg in base_init_method_node.args.args]
            for derived_init_arg in init_args:
                init_arg_name = derived_init_arg.as_string()
                if init_arg_name in base_init_argnames and init_arg_name != SELF_ARG_NAME:
                    arg_names.append(init_arg_name)
        return arg_names

    @staticmethod
    def is_call_func_in_class(class_node, call_func_node):
        if not isinstance(call_func_node, nodes.Attribute):
            return False
        call_expr = call_func_node.expr
        if isinstance(call_expr, nodes.Name) and call_expr.name == SELF_ARG_NAME:
            call_func_name = call_func_node.attrname
            for class_child_node in class_node.body:
                if isinstance(class_child_node, nodes.FunctionDef) and class_child_node.name == call_func_name:
                    return True
        return False

    @staticmethod
    def is_name_in_bases(classnode, classname):
        '''
        告警描述里面的基类名是否在真实节点的基类里面
        '''
        for basename in classnode.bases:
            if classname == basename.as_string():
                return True
        return False

    @classmethod
    def is_init_called(cls, init_func_node):
        '''
        派生__init__方法中是否调用了__init__方法
        '''
        for child in init_func_node.body:
            if cls.is_init_call_node(child):
                return True
        return False

    @classmethod
    def get_call_methods_in_init(cls, class_node, init_method_node, call_methods: list):
        init_child_nodes = []
        node_utils.get_node_childs(init_method_node, init_child_nodes)
        for child_node in init_child_nodes:
            if isinstance(child_node, nodes.Expr) and isinstance(child_node.value, nodes.Call):
                if cls.is_call_func_in_class(class_node, child_node.value.func):
                    call_methods.append(child_node.value.func)

    @classmethod
    def can_call_base_init(cls, derived_init_method_node):
        '''
        如果父类和派生类__init__方法中有调用相同名称的重载方法,则派生类不能调用父类__init__
        '''
        def is_call_funcname_in_methods(call_func_name, call_methods):
            for call_method in call_methods:
                if call_func_name == call_method.attrname:
                    return True
            return False
        # Functions stubs with ``Ellipsis`` as body are exempted.
        if derived_init_method_node.body:
            childnode = derived_init_method_node.body[0]
            if isinstance(childnode, nodes.Expr) and isinstance(childnode.value, nodes.Const) and (
                childnode.value.value is Ellipsis
            ):
                return False
        derived_init_call_methods = []
        cls.get_call_methods_in_init(
            derived_init_method_node.parent,
            derived_init_method_node,
            derived_init_call_methods
        )
        derived_class = derived_init_method_node.parent
        class_bases = derived_class.bases
        for base_class_name_node in class_bases:
            infer_base_class = node_utils.safe_infer(base_class_name_node)
            if infer_base_class is None or infer_base_class is astroid.Uninferable:
                continue
            base_init_method_node = ScopeFinder.get_class_method_node(
                infer_base_class,
                CLASS_INIT_METHOD
            )
            base_init_call_methods = []
            cls.get_call_methods_in_init(
                infer_base_class,
                base_init_method_node,
                base_init_call_methods
            )
            for base_init_call_method in base_init_call_methods:
                if not is_call_funcname_in_methods(base_init_call_method.attrname, derived_init_call_methods):
                    continue
                log.warning(
                    'method name `%s` both called in %s method of base class `%s` and derived class `%s`',
                    base_init_call_method.attrname,
                    CLASS_INIT_METHOD,
                    infer_base_class.name,
                    derived_init_method_node.parent.name
                )
                return False
        return True

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        res = re.search(
            r"__init__ method from base class '(.*)' is not called \(super-init-not-called\)",
            msg.msg
        )
        if isinstance(node, nodes.Name) and node.name == CLASS_INIT_METHOD:
            func_node = node.parent
            if not self.can_call_base_init(func_node):
                return False
            base_cls_name = res.groups()[0]
            is_base_name = self.is_name_in_bases(func_node.parent, base_cls_name)
            if isinstance(func_node.parent, nodes.ClassDef) and (
               is_base_name and not self.is_init_called(func_node)
               ):
                first_body = func_node.body[0]
                init_arg_names = self.get_method_init_args(func_node)
                init_arg_str = ",".join(init_arg_names)
                blanks = first_body.col_offset * ' '
                self.add_range_text(
                    first_body.lineno,
                    0,
                    blanks + f'super().{node.name}({init_arg_str})' + os.linesep
                )
                return True
        return False
