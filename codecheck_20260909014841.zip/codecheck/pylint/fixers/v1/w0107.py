from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintW0107Fixer(PylintFixer):
    '''
    规则说明:多余的pass语句
    '''

    def __init__(self):
        super().__init__('W0107', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if node is None or not isinstance(node, nodes.Pass):
            return False
        self.delete_text_line(msg.line - 1)
        return True
