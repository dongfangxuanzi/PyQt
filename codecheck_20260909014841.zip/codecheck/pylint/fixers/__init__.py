# v1: pylint规则定制修复器v1版本,对应pylint3.0.3版本
