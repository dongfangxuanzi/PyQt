from threading import Event
import os
import json
from collections import Counter, defaultdict
from novalapp import _, get_app
from novalapp.python.interpreter.exceptions import InterpretertoolNotExistError
from novalapp.util import utils
from novalapp.python.interpreter.exceptions import InterpreterSyntaxError
from .toolmanager import CodecheckToolManager
from .exceptions import FixfileError
from .strings import FIX_PROCESSER_NAME
from . import configkeys
from .common_fix_processor import CommonFixProcessor


class FixerProcessor(CommonFixProcessor):
    """description of class"""

    def __init__(self, parent, statusbar):
        super().__init__(parent, statusbar, FIX_PROCESSER_NAME)
        self.fixed_warnings = 0
        self._diff_warnings_info = {}
        self.event = Event()

    @staticmethod
    def diff_tool_mesages_info(message_counter_before, message_counter_after):
        diff_info = {}
        for ruleid, count in message_counter_before.items():
            after_fixed_count = message_counter_after[ruleid]
            diff_count = count - after_fixed_count
            diff_info[ruleid] = diff_count

        for ruleid, count in message_counter_after.items():
            if ruleid not in message_counter_before:
                diff_info[ruleid] = -count
        return diff_info

    @staticmethod
    def get_tool_message_counters(tool_messages):
        rules = [tool_msg.ruleid for tool_msg in tool_messages]
        cnt = Counter(rules)
        return cnt

    def run(self, doc, filepath):
        if not super().run(doc, filepath):
            utils.get_logger().debug('fixer is stopped')
            return
        utils.get_logger().debug('fix code file %s', filepath)
        self.update_progress(filepath)
        self.fix_single_file(doc, filepath)

    def end(self, doc):
        super().end(doc)
        self.message_viewer._plugin._check_processor.end(doc)
        utils.get_logger().info(
            'fix total %d code files, %d warnings',
            self.fixed_file_count,
            self.fixed_warnings
        )
        if get_app().GetDebug():
            total_diff_count = sum(self._diff_warnings_info.values())
            utils.get_logger().debug(
                'fix total warnings count %d, detail info is %s:',
                total_diff_count,
                json.dumps(self._diff_warnings_info, indent=4)
            )
        utils.get_logger().debug('end fix project %s files', doc.GetFilename())
        doc_name = doc.GetModel().name
        self.restore_configs()
        self._statusbar.emit_statusbar_messgae(
            _('Finish fix project "%s" code files') % doc_name)

    def init(self, doc):
        self.fixed_warnings = 0
        self._diff_warnings_info.clear()
        utils.get_logger().debug('start fix project %s files', doc.GetFilename())
        try:
            self.message_viewer._plugin._check_processor.init(doc)
        except Exception as ex:
            utils.get_logger().error(str(ex))
        super().init(doc)

    def update_diff_info(self, diff_info):
        for rule_id, diff_count in diff_info.items():
            if rule_id not in self._diff_warnings_info:
                self._diff_warnings_info[rule_id] = diff_count
            else:
                self._diff_warnings_info[rule_id] += diff_count

    def fix_single_file(self, doc, filepath):
        if not CodecheckToolManager.manager().CHECK_TOOLS:
            utils.get_logger().error('there is not codecheck tools to check code file %s', filepath)
        messages_count: defaultdict[str: dict[str, int]] = defaultdict(dict)
        count_key = "count"
        ruls_count_key = "ruls_count_info"
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            if check_tool.is_filetool_enabled(filepath):
                toolname = check_tool.name
                message_file = check_tool.get_file_log_path(doc, filepath)
                if not os.path.exists(message_file):
                    self.message_viewer._plugin._check_processor.check_single_file(
                        doc, filepath, load_messages=False)
                tool_messages = self.load_messages(check_tool, message_file)
                # 总的告警数量
                count = len(tool_messages)
                messages_count[toolname][count_key] = count
                if get_app().GetDebug():
                    # 统计修复之前每个规则的告警数量信息
                    counter = self.get_tool_message_counters(tool_messages)
                    messages_count[toolname][ruls_count_key] = counter
                try:
                    check_tool.fix_file(self, doc, filepath)
                except (InterpreterSyntaxError, InterpretertoolNotExistError, FixfileError) as ex:
                    self.stop(str(ex))
        self.message_viewer._plugin._check_processor.check_single_file(
            doc, filepath)
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            if check_tool.is_filetool_enabled(filepath):
                tool_name = check_tool.name
                message_file = check_tool.get_file_log_path(doc, filepath)
                tool_messages = self.load_messages(check_tool, message_file)
                count = len(tool_messages)
                diff = messages_count[tool_name][count_key] - count
                if get_app().GetDebug():
                    # 统计修复之后每个规则的告警数量信息
                    counter = self.get_tool_message_counters(tool_messages)
                    # 比对修复前后每个规则的修复数量
                    diff_info = self.diff_tool_mesages_info(
                        messages_count[tool_name][ruls_count_key],
                        counter
                    )
                    diff_count = sum(diff_info.values())
                    self.update_diff_info(diff_info)
                    utils.get_logger().debug(
                        "code file %s tool %s messages count diff %d,rules diff count:%d,info:%s",
                        filepath,
                        tool_name,
                        diff,
                        diff_count,
                        json.dumps(diff_info)
                    )
                else:
                    utils.get_logger().debug(
                        "code file %s tool %s messages count diff %d",
                        filepath,
                        tool_name,
                        diff
                    )
                self.fixed_warnings += diff
        self.fixed_file_count += 1
        if utils.profile_get_int(configkeys.CLOSE_OPENDOC_KEY, True):
            self.message_viewer.SIG_CLOSE_FILEDOC.emit(filepath)
        else:
            self.message_viewer.SIG_RELOAD_FILEDOC.emit(filepath)

    def handle_message(self, doc, check_tool, msg):
        rule_id = msg.ruleid
        can_fix = check_tool.is_rule_fixable(rule_id)
        if can_fix and not self.stopped:
            fixer = check_tool.find_fixer(rule_id)
            if not fixer.autofix:
                utils.get_logger().debug(
                    "Rule `%s` in tool %s is not able to use autofix...", rule_id, fixer.toolname)
                return
            self.message_viewer.SIG_FIX_MESSAGE_ITEM.emit(fixer, doc, msg)
            self.event.wait()
            self.event.clear()
            if fixer.autofix and utils.profile_get_int(configkeys.CHECK_FILE_SYNTAX_KEY, True):
                check_tool.check_file_syntax(msg.filepath)

    def update_progress(self, filepath):
        self._statusbar.emit_statusbar_permanent_messgae(
            _('Fixing code file:%s') % filepath)
        super().update_progress(filepath)
