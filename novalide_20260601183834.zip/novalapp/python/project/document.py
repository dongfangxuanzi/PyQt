# -*- coding: utf-8 -*-
import os
import uuid
from ... import _
from ...project.document import ProjectDocument
from ..interpreter.interpretermanager import InterpreterManager
from .. import prog_lang_ext
from ..debugger.executor import *
from ..debugger.commandproperty import CommandPropertiesDialog
from .model import PythonProject
from ...lib.pyqt import QMessageBox
from .. import pythonenv, utility
from ... import globalkeys
from ... import constants
from ..debugger.commandui import RunCommandUI, BaseDebuggerUI, PythonDebuggerUI
from . import configuration
from ..debugger import debugcfg as debugconfig
from ...util import utils, strutils
from ...sidebar.sidebar import SideBar
'''
    运行python文件或者项目
    按运行模式分为运行:单个文件和项目
'''


class PythonProjectDocument(ProjectDocument):

    # pyc和pyo二进制文件类型禁止添加到项目中
    BAN_FILE_EXTS = prog_lang_ext.PYTHON_COMPILE_FILE_EXT

    def __init__(self, model=None):
        ProjectDocument.__init__(self, model)

    @staticmethod
    def GetProjectModel():
        return PythonProject()

    def OnOpenDocument(self, filename):
        if not ProjectDocument.OnOpenDocument(self, filename):
            return False
        # 加载项目文档后分析并加载智能提示数据,软件启动加载项目时不要分析
        # 如果项目需要转换为其他项目,不需要检查否则会重复检查2次
        if not self.NeedConvertto(self.GetModel()):
            self.GetandSetProjectDocInterpreter()
        return True
        
    def reload(self):
        super().reload()
        self.GetandSetProjectDocInterpreter()

    def GetandSetProjectStartupfile(self):
        '''
        项目启动文件为空时弹出设置界面
        '''
        startup_file = self.GetStartupFile()
        if startup_file is None:
            QMessageBox.critical(
                self.GetFirstView().GetFrame(),
                get_app().GetAppName(),
                _("Your project needs a Python script marked as startup file to perform this action")
            )
            # show the property dialog to remind user to set the startup file
            get_app().MainFrame.projectview.OnProjectProperties(item_name=_("Debug/Run"))
            return None
        return startup_file

    def GetandSetProjectDocInterpreter(self):
        '''
        项目解释器不存在时弹出设置界面并回写到项目文件中
        '''
        interpreter_info = self.GetModel()._interpreter
        interpreter_name = interpreter_info.name
        interpreter_path = interpreter_info.path
        if interpreter_path is None:
            if utils.profile_get_int(globalkeys.DETECT_PROJECT_INTERPRETER_KEY, False):
                return self.choose_andset_project_interprter()
            return None
        name_interpreter = InterpreterManager.manager(
        ).GetInterpreterByName(interpreter_name)
        path_interpreter = InterpreterManager.manager(
        ).GetInterpreterByPath(interpreter_path)
        if name_interpreter is None or path_interpreter is None:
            if utils.profile_get_int(globalkeys.DETECT_PROJECT_INTERPRETER_KEY, False):
                QMessageBox.warning(
                    self.GetDocumentWindow(),
                    _('Interpreter not exist'),
                    _("Project \"%s\" interpreter %s is not exist,please choose one interpreter") % (
                        self.GetModel().name, interpreter_name)
                )
                return self.choose_andset_project_interprter()
        else:
            self.GetModel().interpreter = name_interpreter
            return name_interpreter

    def choose_andset_project_interprter(self):
        interpreter = InterpreterManager.manager(
        ).ShowChooseInterpreterDlg(self.GetDocumentWindow())
        if interpreter:
            self.GetModel().update_interpreter_info(interpreter)
            self.GetModel().interpreter = interpreter
            self.Modify(True)
        return interpreter

    def GetFileRunConfiguration(self, run_file):
        '''
        获取单个文件的运行配置,单个文件有多个运行配置,每个运行配置的运行方式是不同的
        '''
        file_key = self.GetFileKey(run_file)
        run_configuration_name = utils.profile_get(
            file_key + "/RunConfigurationName", "")
        return run_configuration_name

    def GetRunfileParameter(self, run_file):
        '''
        获取项目要运行单个python文件的运行参数
        '''
        # 优先查找运行文件的运行配置,如果存在,则使用运行配置里面的运行文件参数
        run_configuration_name = self.GetFileRunConfiguration(run_file)
        if run_configuration_name:
            file_configuration = configuration.FileConfiguration(
                self, run_file)
            run_configuration = file_configuration.LoadConfiguration(
                run_configuration_name)
            return run_configuration.GetRunParameter()
        # 再获取通过运行菜单->配置参数和环境变量显示的对话框里面设置的运行文件参数
        use_argument = utils.profile_get_int(
            self.GetFileKey(run_file, "UseArgument"), True)
        if use_argument:
            initial_args = utils.profile_get(
                self.GetFileKey(run_file, "RunArguments"), "")
        else:
            initial_args = ''
        python_path = utils.profile_get(
            self.GetFileKey(run_file, "PythonPath"), "")
        startin = utils.profile_get(
            self.GetFileKey(run_file, "RunStartIn"), "")
        if startin == '':
            startin = os.path.dirname(self.GetFilename())
        env = {}
        paths = set()
        path_post_end = utils.profile_get_int(
            self.GetKey("PythonPathPostpend"), True)
        if path_post_end:
            paths.add(str(os.path.dirname(self.GetFilename())))
        # should avoid environment contain unicode string,such as u'xxx'
        if len(python_path) > 0:
            paths.add(str(python_path))
        env[pythonenv.PYTHON_PATH_NAME] = os.pathsep.join(list(paths))
        # 获取项目的运行配置类
        return self.GetRunconfigClass()(get_app().GetCurrentInterpreter(), run_file.filePath, initial_args, env, startin, project=self)

    def SaveRunParameter(self, run_parameter):
        project_name = os.path.basename(self.GetFilename())
        utils.profile_set(self.GetKey("LastRunProject"), project_name)
        utils.profile_set(self.GetKey("LastRunFile"), run_parameter.FilePath)
        # Don't update the arguments or starting directory unless we're runing python.
        utils.profile_set(self.GetKey("LastRunArguments"), run_parameter.Arg)
        utils.profile_set(self.GetKey("LastRunStartIn"),
                          run_parameter.StartupPath)
        if run_parameter.Environment is not None and pythonenv.PYTHON_PATH_NAME in run_parameter.Environment:
            utils.profile_set(self.GetKey("LastPythonPath"),
                              run_parameter.Environment[pythonenv.PYTHON_PATH_NAME])

    def DebugRunBuiltin(self, run_parameter):
        fileToRun = run_parameter.FilePath
        GetApp().MainFrame.ShowView(
            consts.PYTHON_INTERPRETER_VIEW_NAME, toogle_visibility_flag=True)
        python_interpreter_view = GetApp().MainFrame.GetCommonView(
            consts.PYTHON_INTERPRETER_VIEW_NAME)
        old_argv = sys.argv
        environment, initialArgs = run_parameter.Environment, run_parameter.Arg
        sys.argv = [fileToRun]
        command = 'execfile(r"%s")' % fileToRun
        python_interpreter_view.Runner.send_command(
            ToplevelCommand("execute_source", source=command))
        sys.argv = old_argv

    def GetRunConfiguration(self, start_up_file=None, is_debug=False):
        '''
        获取项目的当前运行配置,也就是默认启动文件的运行配置
        '''
        if start_up_file is None:
            run_configuration_key = self.GetKey()
        else:
            run_configuration_key = self.GetFileKey(start_up_file)
        run_configuration_name = utils.profile_get(
            run_configuration_key + "/RunConfigurationName", "")
        return run_configuration_name

    def GetFileRunParameter(self, filetorun=None, is_break_debug=False):
        # when there is not project or run file is not in current project
        # run one single python file
        # 在项目中运行其他项目的文件,则不能获取当前项目的运行配置,以及当前项目为空时,都按运行单个python文件模式来处理
        if self.GetModel().Id == ProjectDocument.UNPROJECT_MODEL_ID or (filetorun is not None and self.GetModel().FindFile(filetorun) is None):
            doc_view = self.GetDebugger().GetActiveView()
            if doc_view:
                document = doc_view.GetDocument()
                if not document.Save() or document.IsNewDocument:
                    return None
                if self.GetDebugger().IsFileContainBreakPoints(document) or is_break_debug:
                    QMessageBox.warning(
                        doc_view.GetFrame(),
                        get_app().GetAppName(),
                        _("Debugger can only run in active project")
                    )
            else:
                return None
            run_parameter = document.GetRunParameter()
        # 获取当前项目的运行配置
        else:
            # run project
            if filetorun is None:
                # default run project start up file
                run_file = self.GetandSetProjectStartupfile()
            else:
                run_file = self.GetModel().FindFile(filetorun)
            if not run_file:
                return None
            self.PromptToSaveFiles()
            # 获取启动文件的运行参数
            run_parameter = self.GetRunfileParameter(run_file)
        return run_parameter

    def IsProjectContainBreakPoints(self):
        master_bp_dict = get_app().MainFrame.GetView(
            constants.BREAKPOINTS_TAB_NAME).GetMasterBreakpointDict()
        for key in master_bp_dict:
            if self.GetModel().FindFile(key) and len(master_bp_dict[key]) > 0:
                return True
        return False

    def GetRunParameter(self, file_to_run=None, is_break_debug=False, is_debug=False):
        '''
        @is_break_debug:user force to debug breakpoint or not
        '''
        if not PythonExecutor.GetPythonExecutablePath():
            return None
        is_debug_breakpoint = False
        # load project configuration first,if have one run configuration,the run it
        run_configuration_name = self.GetRunConfiguration(is_debug=is_debug)
        # if user force run one project file ,then will not run configuration from config
        if file_to_run is None and run_configuration_name:
            project_configuration = configuration.ProjectConfiguration(self)
            run_configuration = project_configuration.LoadConfiguration(
                run_configuration_name)
            # if run configuration name does not exist,then run in normal
            if not run_configuration:
                run_parameter = self.GetFileRunParameter(
                    file_to_run, is_break_debug)
            else:
                run_parameter = run_configuration.GetRunParameter()
        else:
            run_parameter = self.GetFileRunParameter(
                file_to_run, is_break_debug)

        # invalid run parameter
        if run_parameter is None:
            return None

        # check project files has breakpoint,if has one breakpoint,then run in debugger mode
        if self.IsProjectContainBreakPoints():
            is_debug_breakpoint = True

        run_parameter = utility.get_override_runparameter(run_parameter)
        run_parameter.IsBreakPointDebug = is_debug_breakpoint
        return run_parameter

    def Debug(self):
        run_parameter = self.GetRunParameter(is_debug=True)
        if run_parameter is None:
            return
        if not run_parameter.IsBreakPointDebug:
            self.DebugRunScript(run_parameter)
        else:
            self.DebugrunBreakpoint(run_parameter)
        self.GetDebugger().AppendRunParameter(run_parameter)

    def DebugRunScript(self, run_parameter):
        if run_parameter.Interpreter.IsBuiltIn:
            self.DebugRunBuiltin(run_parameter)
            return
        file_to_run = run_parameter.FilePath
        shortfile = os.path.basename(file_to_run)
        if strutils.get_file_extension(shortfile) == prog_lang_ext.PYTHON_PYI_FILE_EXT:
            QMessageBox.information(
                self.GetDocumentWindow(),
                get_app().GetAppName(),
                _("Python `%s` file is not runnable") % prog_lang_ext.PYTHON_PYI_FILE_EXT
            )
            return
        view = get_app().MainFrame.AddView(
            "Debugger" + str(uuid.uuid1()).lower(),
            RunCommandUI,
            _("Running: ") + shortfile,
            SideBar.South,
            create=True,
            image_file="python/debugger/debug.ico",
            debugger=self.GetDebugger(),
            run_parameter=run_parameter,
            visible_in_menu=False
        )
        page = view['instance']
        # 激活运行窗口
        get_app().MainFrame.activateBottomTab(page)
        page.Execute()
        get_app().GetDocumentManager().ActivateView(self.GetDebugger().GetView())

    def RunWithoutDebug(self, file_to_run=None):
        run_parameter = self.GetRunParameter(file_to_run, is_debug=True)
        if run_parameter is None:
            return
        run_parameter.IsBreakPointDebug = False
        self.DebugRunScript(run_parameter)
        self.GetDebugger().AppendRunParameter(run_parameter)

    def Run(self, filetoRun=None):
        run_parameter = self.GetRunParameter(filetoRun)
        if run_parameter is None:
            return
        self.RunScript(run_parameter)
        self.GetDebugger().AppendRunParameter(run_parameter)

    def RunScript(self, run_parameter):
        interpreter = run_parameter.Interpreter
        # 内建解释器只能调试代码,不能在终端中运行
        if interpreter.IsBuiltIn:
            return
        executor = PythonrunExecutor(run_parameter)
        executor.Execute()

    def GetLastRunParameter(self, is_debug):
        if not PythonExecutor.GetPythonExecutablePath():
            return None
        dlg_title = _('Run File')
        btn_name = _("Run")
        if is_debug:
            dlg_title = _('Debug File')
            btn_name = _("Debug")
        dlg = CommandPropertiesDialog(GetApp().GetTopWindow(
        ), dlg_title, self, okButtonName=btn_name, debugging=is_debug, is_last_config=True)
        showdialog = dlg.MustShowDialog()
        is_parameter_save = False
        if showdialog and dlg.ShowModal() == constants.ID_OK:
            projectdocument, file_to_debug, initial_args, startin, ispython, environment = dlg.GetSettings()
            # when show run dialog first,need to save parameter
            is_parameter_save = True
        # 直接从配置中读取运行参数,不显示对话框
        elif not showdialog:
            # 隐藏窗口
            dlg.withdraw()
            projectdocument, file_to_debug, initial_args, startin, ispython, environment = dlg.GetSettings()
            dlg.destroy()
        # 取消
        else:
            dlg.destroy()
            return None
        if self.GetFilename() != consts.NOT_IN_ANY_PROJECT and self.IsProjectContainBreakPoints():
            is_debug_breakpoint = True
        else:
            is_debug_breakpoint = False
        run_parameter = runconfig.PythonRunconfig(
            GetApp().GetCurrentInterpreter(),
            file_to_debug,
            initial_args,
            environment,
            startin,
            is_debug_breakpoint
        )
        if is_parameter_save:
            self.SaveRunParameter(run_parameter)
        return run_parameter

    def DebugRunLast(self):
        run_parameter = self.GetLastRunParameter(True)
        if run_parameter is None:
            return
        run_parameter = pyutils.get_override_runparameter(run_parameter)
        if not run_parameter.IsBreakPointDebug:
            self.DebugRunScript(run_parameter)
        else:
            self.DebugRunScriptBreakPoint(run_parameter)

    def RunLast(self):
        run_parameter = self.GetLastRunParameter(False)
        if run_parameter is None:
            return
        run_parameter = pyutils.get_override_runparameter(run_parameter)
        self.RunScript(run_parameter)

    def SetParameterAndEnvironment(self):
        dlg = CommandPropertiesDialog(get_app().GetTopWindow(), _(
            'Set param and environment'), self, okButtonName=_("&OK"))
        dlg.exec_()

    def BreakintoDebugger(self, file_to_run=None):
        run_parameter = self.GetRunParameter(
            file_to_run, is_break_debug=True, is_debug=True)
        # debugger must run in project
        if run_parameter is None or run_parameter.Project is None:
            return
        run_parameter.IsBreakPointDebug = True
        self.DebugrunBreakpoint(run_parameter, auto_continue=False)

    def DebugrunBreakpoint(self, run_parameter, auto_continue=True):
        '''
        autoContinue可以让断点调式是否会在开始中断
        '''
        if BaseDebuggerUI.DebuggerRunning():
            QMessageBox.information(
                self.GetDocumentWindow(),
                _("Debugger Running"),
                _("A debugger is already running. Please shut down the other debugger first.")
            )
            return
        # 内建解释器不支持断点调试
        if run_parameter.Interpreter.IsBuiltIn:
            QMessageBox.information(
                self.GetDocumentWindow(),
                get_app().GetAppName(),
                _("Builtin interpreter does not support this operation.")
            )
            return
        host = utils.profile_get("DebuggerHostName", debugconfig.DEFAULT_HOST)
        if not host:
            QMessageBox.information(
                self.GetDocumentWindow(),
                _("No Debugger Host"),
                _("No debugger host set. Please go to Tools->Options->Debugger and set one.")
            )
            return
        file_to_run = run_parameter.FilePath
        shortfile = os.path.basename(file_to_run)
        view = get_app().MainFrame.AddView(
            "Debugger" + str(uuid.uuid1()).lower(),
            PythonDebuggerUI,
            _("Debugging: ") + shortfile,
            SideBar.South,
            create=True,
            image_file="python/debugger/debugger.png",
            debugger=self.GetDebugger(),
            run_parameter=run_parameter,
            visible_in_menu=False,
            autoContinue=auto_continue
        )
        page = view['instance']
        page.Execute()
        get_app().MainFrame.activateBottomTab(page)
        self.GetDebugger().SetDebuggerUI(page)
        get_app().GetDocumentManager().ActivateView(self.GetDebugger().GetView())

    def GetDataPath(self):
        metadata_path = os.path.join(self.GetPath(), ".metadata")
        return metadata_path
        # def UpdateData(self,md):
