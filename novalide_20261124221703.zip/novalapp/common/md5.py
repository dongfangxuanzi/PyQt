# coding:utf-8
'''
Name:        md5.py
Purpose:     检测文件或字符串的MD5 hash值
Author:      wukan
Created:     2024-01-26
Copyright:   (c) wukan 2024
Licence:     <your licence>
'''
import hashlib
import os


def get_str_md5(content):
    '''
    将字符串用MD5加密
    '''
    m0 = hashlib.md5()
    m0.update(content.encode('utf-8'))
    return m0.hexdigest()


def get_huge_file_md5(filename):
    '''
    大文件的MD5值
    '''
    myhash = hashlib.md5()
    with open(filename, 'rb') as f:
        while True:
            b = f.read(8096)
            if not b:
                break
            myhash.update(b)
    return myhash.hexdigest()


def calc_sha1(filepath):
    with open(filepath, 'rb') as f:
        sha1obj = hashlib.sha1()
        sha1obj.update(f.read())
        _hash = sha1obj.hexdigest()
        return _hash


def get_normal_file_md5(filepath):
    with open(filepath, 'rb') as f:
        md5obj = hashlib.md5()
        md5obj.update(f.read())
        _hash = md5obj.hexdigest()
        return _hash


# 大文件的临界值
LIMIT_HUGE_SIZE = 1024 * 1024 * 1024


def get_file_md5(file_path):
    file_size = os.path.getsize(file_path)
    if file_size > LIMIT_HUGE_SIZE:
        return get_huge_file_md5(file_path)
    return get_normal_file_md5(file_path)
