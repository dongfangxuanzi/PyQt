'''
Name:        pylint_fix.py
Purpose:     pylint规则修复器
Author:      wukan
Created:     2026-08-24
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import base64
import os
import logging
from astroid import AstroidSyntaxError
from astroid import nodes
from novalapp import _
from novalapp.lib.pyqt import QMessageBox
from novalapp.project import command as projectcommand
from novalapp.util import fileutils, strutils, utils
from novalapp import constants
from novalapp.python.parser.define import SELF_ARG_NAME, CLASS_INIT_METHOD
from novalapp.python.parser.node_scope import ScopeFinder
import astroid
from . import configkeys
from .basefix import BasePythonFixer
from .sarif_loader import SarifLoader
from .strings import PYLINT_TOOL_NAME, COMMON_PYLINT_MESSAGE_ID
from .codeutils import get_node_line_text, get_node_col_offset_blanks, get_scope_range
from .exceptions import InvalidOptionIndexError
log = logging.getLogger(__name__)


class PylintFixer(BasePythonFixer):

    SINGLE_TRIPLE_QUOTE = "'''"
    DOUBLE_TRIPLE_QUOTE = '"""'
    DOUBLE_QUOTE = '"'
    SINGLE_QUOTE = "'"
    # 使用*导入模块成员时允许导入的最大成员数量
    DEFAULT_MAX_MEMBERS_COUNT = 30

    def __init__(self, ruleid, autofix=False, open_file=True):
        super().__init__(ruleid, PYLINT_TOOL_NAME, autofix, open_file)

    @staticmethod
    def is_init_call_node(node):
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call) and (
            isinstance(node.value.func, nodes.Attribute)
        ) and node.value.func.attrname == CLASS_INIT_METHOD:
            return True
        return False

    @staticmethod
    def extract_node_with_text(nodetext):
        try:
            node = astroid.extract_node(nodetext)
            return node
        except AstroidSyntaxError as ex:
            log.error(str(ex))
        return None

    @staticmethod
    def get_classtype_parent_node(node, nodeclass, include_node_self=True):
        if include_node_self and isinstance(node, nodeclass):
            return node
        return ScopeFinder.get_parent_node_by_nodeclass(node, nodeclass)

    @staticmethod
    def get_line_str_quote(node):
        '''
        获取行字符串是用单引号还是双引号裹起来
        '''
        linetext = get_node_line_text(node)
        if linetext is None:
            return '"'
        return linetext[node.col_offset]

    @classmethod
    def get_line_str_r_quote(cls, node):
        '''
        获取行字符串是否被r包裹起来,如果有r,获取r后面的引号字符
        '''
        str_quote = cls.get_line_str_quote(node)
        log.debug(
            "str quote of line %d is %s",
            node.lineno,
            str_quote
        )
        # 字符串被r包裹
        if str_quote == "r":
            # 字符串引号在r字符右移1位
            node.col_offset += 1
            str_quote = cls.get_line_str_quote(node)
            node.col_offset -= 1
            return True, str_quote
        return False, str_quote

    def replace_module_name(self, oldpath, new_module_name):
        ext = strutils.get_file_extension(oldpath, keepdot=True)
        newname = os.path.join(
            fileutils.get_filepath_from_path(oldpath), new_module_name)
        newfilepath = strutils.make_name_end_in_extension(newname, ext)
        ret = self._doc.GetCommandProcessor().Submit(
            projectcommand.ProjectRenameFileCommand(self._doc, oldpath, newfilepath)
        )
        if ret:
            self._doc.Save()
        return ret

    def fix_docstr_position(self, docnode):
        docstr = docnode.value
        is_r_quote, quote_char = self.get_line_str_r_quote(docnode)
        if quote_char not in [self.DOUBLE_QUOTE, self.SINGLE_QUOTE]:
            log.error("doc node on line %s has not quote char", docnode.lineno)
            return False
        triple_quotes = quote_char * 3
        if is_r_quote:
            start_triple_quotes = 'r' + triple_quotes
        else:
            if docstr.find('\\') != -1:
                docstr = docstr.replace('\\', '\\\\')
            start_triple_quotes = triple_quotes
        if docnode.lineno == docnode.end_lineno:
            if docstr.strip() == docstr:
                return False
            self.fix_node_text(docnode, start_triple_quotes + docstr.strip() + triple_quotes)
            return True
        doclines = docstr.split(constants.LF)
        blanks = get_node_col_offset_blanks(docnode)
        fix_doc_str = start_triple_quotes + constants.LF
        for docline in doclines:
            trim_docline = docline.strip()
            if not trim_docline:
                continue
            fix_docline = blanks + trim_docline + constants.LF
            fix_doc_str += fix_docline
        fix_doc_str += blanks
        fix_doc_str += triple_quotes
        if fix_doc_str == (start_triple_quotes + constants.LF.join(doclines) + triple_quotes):
            return False
        self.fix_node_text(docnode, fix_doc_str)
        return True

    def replace_function_scope_range(self, scope, texts):
        scope_range = self.get_function_scope_range(scope)
        scope_range.replace_with_text(self._textview, texts)

    def get_function_scope_range(self, scope):
        scope_range = get_scope_range(scope)
        # 包含函数上方的注释行
        top_comment_lines = self.get_function_top_comment_lines(scope)
        if top_comment_lines:
            scope_range.start_line = top_comment_lines[-1]
        return scope_range

    def delete_import_name(self, node, import_name):
        if not self.is_node_could_deleted(node):
            log.error("%s node could not be deleted", node.__class__.__name__)
            return False
        for i, (name, asname) in enumerate(node.names):
            if import_name in (name, asname):
                del node.names[i]
                break
        else:
            return False
        if not node.names:
            return self.delete_node(node)
        self.fix_node_text(node, node.as_string())
        return True

    def replace_attribute_name_in_scope(self, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.AssignAttr, nodes.Attribute)) and child.attrname == name:
                self.fix_node_text(child, f"{SELF_ARG_NAME}." + newname)
            else:
                self.replace_attribute_name_in_scope(child, name, newname)

    def replace_method_name_in_scope(
        self,
        scope,
        methodname,
        new_methodname,
        is_class_method,
        classname
    ):
        childs = list(self.iter_scope_childs(scope))
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, nodes.Name) and (
                isinstance(child.parent, nodes.FunctionDef) and child.name == methodname
            ):
                self.fix_node_text(child, new_methodname)
            elif isinstance(child, nodes.Attribute) and child.attrname == methodname:
                if is_class_method:
                    if isinstance(child.expr, nodes.Name):
                        if child.expr.name == 'cls':
                            self.fix_node_text(child, "cls." + new_methodname)
                            continue
                        elif child.expr.name == classname:
                            self.fix_node_text(child, f"{classname}." + new_methodname)
                            continue
                self.fix_node_text(child, f"{SELF_ARG_NAME}." + new_methodname)
            else:
                self.replace_method_name_in_scope(
                    child, methodname, new_methodname, is_class_method, classname)

    def fix_exception_name(self, node, asname):
        '''
        except Exception as xxx
        xxx节点是多行节点,不能用as_string,只能修改行内容
        '''
        offset_blanks = get_node_col_offset_blanks(node)
        fixstr = offset_blanks + 'except %s as %s:' % (node.type.as_string(), asname)
        self.replace_line_text(node.lineno, fixstr)

    def replace_variable_name_in_scope(self, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.Name, nodes.AssignName)) and child.name == name:
                if isinstance(child.parent, nodes.ExceptHandler):
                    self.fix_exception_name(child.parent, newname)
                else:
                    self.fix_node_text(child, newname)
            else:
                self.replace_variable_name_in_scope(child, name, newname)


class SarifFixer(PylintFixer):
    '''
    通用sarif格式修复器
    '''

    def __init__(self, ruleid, autofix=False, open_file=True):
        PylintFixer.__init__(self, ruleid, autofix, open_file)

    def fix_message(self, msg):
        if self.check_tool.output_format != self.check_tool.JSON_OUTPUT_FORMAT:
            return False
        fix_options = msg.fixers
        if not fix_options:
            return False
        if len(fix_options) > 1 and not self.fix_only_autofix():
            choices = [fix_option['description']['text'] for fix_option in fix_options]
            sel = self.ask_input_list(
                "Fix code",
                "Please choose one fixer option",
                choices,
                selection=0
            )
            if sel == -1:
                raise InvalidOptionIndexError('cancel option')
        else:
            # sarif自动修复有多个修复选项时默认选第一个作为修复方案
            sel = 0
        fix_option = fix_options[sel]
        chan = fix_option['artifactChanges'][0]
        fixuri = chan['artifactLocation']['uri']
        fixpath = SarifLoader.uri_to_path(fixuri)
        if not fileutils.ComparePath(msg.filepath, fixpath):
            log.error('sarif fix path %s is not source path:%s', fixpath, msg.filepath)
            return False
        replacements = chan['replacements']
        if self.is_text_modified() and not self.fix_only_autofix():
            QMessageBox.critical(self._textctrl, _('Error'), _(
                'Please save your file before fix warnings'))
            return False
        replace_flag = False
        for replacement in replacements:
            if "deletedRegion" in replacement:
                deleted_region = replacement["deletedRegion"]
                if 'byteOffset' in deleted_region:
                    base64_text = bytearray(
                        replacement["insertedContent"]['binary'], encoding="ascii")
                    inserted_content = base64.b64decode(base64_text)
                    byte_offset = deleted_region['byteOffset']
                    byte_len = deleted_region['byteLength']
                    newbytes = b''
                    with open(fixpath, "rb") as fp:
                        byte_content = fp.read()
                        newbytes = byte_content[0:byte_offset] + bytearray(
                            inserted_content) + byte_content[byte_offset + byte_len:]
                    with open(fixpath, "wb") as fw:
                        fw.write(newbytes)
                    self.reload_text_doc()
                elif 'charOffset' in deleted_region:
                    char_offset = deleted_region['charOffset']
                    char_len = deleted_region['charLength']
                    inserted_content = replacement["insertedContent"]["text"]
                    self.replace_offset_range_text(char_offset, char_len, inserted_content)
                else:
                    start_line = deleted_region["startLine"]
                    start_column = deleted_region["startColumn"] - 1
                    end_column = deleted_region["endColumn"] - 1
                    end_line = deleted_region["endLine"]
                    inserted_content = replacement["insertedContent"]["text"]
                    if start_line == end_line and start_column == end_column:
                        self.add_range_text(start_line, start_column, inserted_content)
                    else:
                        self.replace_range_text(
                            start_line,
                            inserted_content,
                            start_column,
                            end_line,
                            end_column
                        )
                replace_flag = True
        return replace_flag


class PylintCommonFixer(PylintFixer):
    '''
    修复pylint告警之外的一些常见问题
    '''

    def __init__(self):
        PylintFixer.__init__(self, COMMON_PYLINT_MESSAGE_ID, True, True)

    @classmethod
    def get_fix_docnodes(cls, scope, doc_nodes: list):
        for bodynode in scope.body[::-1]:
            if isinstance(bodynode, nodes.FunctionDef):
                for child in bodynode.body[::-1]:
                    if isinstance(child, nodes.FunctionDef):
                        doc_nodes.append(child.doc_node)
                doc_nodes.append(bodynode.doc_node)
            elif isinstance(bodynode, nodes.ClassDef):
                for child in bodynode.body[::-1]:
                    if isinstance(child, nodes.FunctionDef):
                        doc_nodes.append(child.doc_node)
                    elif hasattr(child, 'body'):
                        cls.get_fix_docnodes(child, doc_nodes)
                doc_nodes.append(bodynode.doc_node)
            elif hasattr(bodynode, 'body'):
                cls.get_fix_docnodes(bodynode, doc_nodes)

    def format_doc_str(self):
        '''
        格式化(模块/类/函数/方法)的文档字符串,对齐边界,保持整齐好看的排列方式
        '''
        module = self.get_module()
        if module is None:
            return False
        fix_docs = 0
        fix_docnodes = []
        self.get_fix_docnodes(module, fix_docnodes)
        fix_docnodes.append(module.doc_node)
        for docnode in fix_docnodes:
            fix_docs += self.fix_doc_node(docnode)
        log.debug('fix docstr nodes count is %d', fix_docs)
        return fix_docs > 0

    def fix_doc_node(self, docnode):
        if docnode is None:
            return 0
        return int(self.fix_docstr_position(docnode))

    def fix_message(self, msg):
        try:
            self.load_module(msg.filepath, reload=True)
        except RuntimeError as ex:
            log.error(str(ex))
            return False
        ret = False
        if utils.profile_get_int(configkeys.FORMAT_DOCSTR_KEY, False):
            suc = self.format_doc_str()
            if suc:
                ret = suc
                self.load_module(msg.filepath, reload=True)
        if self.fix_module_imports_blank_line():
            ret = True
            self.load_module(msg.filepath, reload=True)
        if utils.profile_get_int(configkeys.REMOVE_PRINT_STATEMENT_KEY, False):
            rem_suc = self.remove_print_statements()
            if rem_suc:
                ret = rem_suc
                try:
                    self.load_module(msg.filepath, reload=True)
                except RuntimeError as ex:
                    log.error("remove print statements error:%s", str(ex))
        if utils.profile_get_int(configkeys.CONVERT_TABS_SPACES_KEY, False):
            suc = self.convert_tabs_to_spaces()
            if suc:
                ret = suc
        return ret

    def fix_module_imports_blank_line(self):
        '''
        清除导入语句之间的空行
        '''
        importutils = self.get_import_nodes_visitor()
        top_import_nodes = importutils.get_top_import_nodes()
        if not top_import_nodes:
            return False
        start_line = top_import_nodes[0].lineno
        end_line = top_import_nodes[-1].lineno
        del_lines = []
        for i in range(start_line - 1, end_line):
            line_text = self.get_line_text(i)
            if not line_text.strip():
                del_lines.append(i)
        if not del_lines:
            return False
        del_lines.sort(reverse=True)
        for del_line_index in del_lines:
            self.delete_text_line(del_line_index)
        return True

    def remove_print_statements(self):
        line_count = self.get_line_count()
        remove_print_nodes = []
        for i in range(line_count):
            node = self.find_node_on_line(i + 1)
            if node is None:
                line_text = self.get_line_text(i)
                log.error(
                    'could not find ast node on line %d with line text `%s`',
                    i + 1,
                    line_text
                )
                continue
            if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call) and (
                isinstance(node.value.func, nodes.Name) and node.value.func.name == "print"
            ):
                remove_print_nodes.append(node)
        if not remove_print_nodes:
            return False
        remove_print_nodes.sort(key=lambda x: x.lineno, reverse=True)
        for printnode in remove_print_nodes:
            ret = self.delete_node(printnode, delete_node_line=True, check_deleteable=True)
        return ret
