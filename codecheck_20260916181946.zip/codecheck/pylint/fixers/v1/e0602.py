# -*- coding: utf-8 -*-
'''
Name:        e0602.py
Purpose:     E0602:未定义的变量规则修复器
修复方法:
导入未识别的模块或从模块中导入未识别成员
Author:      wukan
Created:     2023-11-16
Copyright:   (c) wukan 2023
Licence:     <your licence>
'''
import re
import os
import logging
from novalapp import get_app
from novalapp.python.apis import memberkeys
from ....pylint_fix import PylintFixer
log = logging.getLogger(__name__)

KNOWN_2_TO_3_TYPES = {
    'basestring': 'str',
    'long': 'int',
    'TupleType': 'tuple',
    'DictType': 'dict',
    'ListType': 'list',
    'FloatType': 'float',
    'LongType': 'int',
    'IntType': 'int',
    'BooleanType': 'bool',
    'UnicodeType': 'str',
    'TypeType': 'type',
    'unicode': 'str'
}


class PylintE0602Fixer(PylintFixer):
    '''
    规则说明: 未定义的变量
    '''

    def __init__(self):
        super().__init__('E0602', False)

    @staticmethod
    def get_level_path(file_path, import_file_path):
        level = 1
        module_dir_path = os.path.dirname(file_path)
        parent_dir_path = module_dir_path
        while True:
            if level >= 5:
                break
            if import_file_path.find(parent_dir_path) != -1:
                break
            parent_dir_path = os.path.dirname(parent_dir_path)
            level += 1
        return level * '.'

    @staticmethod
    def trim_import_paths(paths, import_paths):
        trim_index = -1
        path_len = len(import_paths)
        for i, import_name in enumerate(paths):
            if i >= path_len or import_name != import_paths[i]:
                trim_index = i
                break
        return ".".join(import_paths[trim_index:])

    def path_to_relativepath(self, file_path, import_module_path, import_file_path):
        module_path = self._textview.ModuleAnalyzer.codeparser.analyzer.get_relative_path(file_path)
        paths = module_path.split(".")
        import_paths = import_module_path.split(".")
        if paths[0] == import_paths[0]:
            level = self.get_level_path(file_path, import_file_path)
            import_module_path = level + self.trim_import_paths(paths, import_paths)
        return import_module_path

    def fix_message(self, msg):
        self.load_msg_module(msg)
        res = re.search("Undefined variable '(.*)'", msg.msg)
        undefined_name = res.groups()[0]
        if undefined_name in KNOWN_2_TO_3_TYPES:
            node = self.find_msg_node(msg, use_column=True)
            rep_name = KNOWN_2_TO_3_TYPES[undefined_name]
            self.fix_node_text(node, rep_name)
            return True
        mdloader = get_app().intellisence_mananger.GetModule(
            undefined_name
        )
        visitor = self.get_import_nodes_visitor()
        if mdloader:
            if not visitor.is_import_exist(undefined_name):
                insert_line = visitor.get_import_line()
                self.add_range_text(insert_line + 1, 0, "import %s" % undefined_name + "\n")
                return True
            return False
        all_modules = get_app().intellisence_mananger.load_modules()
        import_names = []
        import_files = []
        for mdloader in all_modules:
            modname = mdloader.Name + "." + undefined_name
            try:
                with open(mdloader.apifile, encoding="ascii") as freader:
                    for line in freader:
                        regstr = r"%s\?\d" % modname
                        if re.search(regstr, line):
                            member_data = mdloader.get_member(undefined_name)
                            if (member_data and memberkeys.PATH_KEY_NAME not in member_data) or mdloader.is_package():
                                import_names.append(mdloader.Name)
                                import_files.append(mdloader.path)
            except OSError as ex:
                log.error(str(ex))
        if import_names:
            if len(import_names) == 1:
                sel = 0
            elif len(import_names) > 1:
                sel = self.ask_input_list(
                    "Find undefined variable",
                    "Please choose one import module of undefined variable",
                    import_names,
                    selection=0
                )
                if sel == -1:
                    return False
            insert_line = visitor.get_import_line()
            import_module_path = import_names[sel]
            import_module_path = self.path_to_relativepath(
                msg.filepath,
                import_module_path,
                import_files[sel]
            )
            self.add_range_text(
                insert_line + 1,
                0,
                'from %s import %s' % (import_module_path, undefined_name) + '\n'
            )
            return True
        return False
