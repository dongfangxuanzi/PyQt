import re
import os
import logging
from astroid import nodes
from ....pylint_fix import PylintFixer
log = logging.getLogger(__name__)


class PylintC0413Fixer(PylintFixer):
    '''
    规则说明:导入语句必须位于文件顶部,导入语句之间不能有其它语句,个别特殊语句除外
    '''

    def __init__(self):
        super().__init__('C0413', True)

    @staticmethod
    def get_noimport_nodes(import_node):
        '''
        获取2个导入语句之间所有非导入语句
        '''
        module = import_node.parent
        noimport_nodes = []
        for childnode in module.body:
            if not isinstance(childnode, (nodes.Import, nodes.ImportFrom)):
                noimport_nodes.append(childnode)
            if childnode == import_node:
                break
        return noimport_nodes

    @staticmethod
    def check_statement_moveable(statements):
        for statement in statements:
            if isinstance(statement, nodes.Expr) and isinstance(statement.value, nodes.Call):
                return False
        return True

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        res = re.search(
            r'Import "(.*)" should be placed at the top of the module \(wrong-import-position\)',
            msg.msg
        )
        if not isinstance(node, (nodes.Import, nodes.ImportFrom)) or not res:
            return False
        if res.groups()[0] == node.as_string():
            not_import_nodes = self.get_noimport_nodes(node)
            if not self.check_statement_moveable(not_import_nodes):
                return False
            if not not_import_nodes:
                log.warning(
                    'there are all import nodes before line %d import statment:%s',
                    node.lineno,
                    node.as_string()
                )
                return False
            nonimport_node = not_import_nodes[0]
            visitor = self.get_import_nodes_visitor()
            if nonimport_node.lineno == nonimport_node.end_lineno:
                insert_line = visitor.get_import_line()
                self.add_range_text(insert_line + 1, 0, nonimport_node.as_string() + os.linesep)
                return self.delete_node(nonimport_node)
            self.delete_node(node)
            insert_line = visitor.get_import_line(top_imports=True)
            self.add_range_text(insert_line + 1, 0, node.as_string() + os.linesep)
            return True
        return False
