# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/PyCQA/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/PyCQA/pylint/blob/main/CONTRIBUTORS.txt
"""property decorator checker for property method."""
from astroid import nodes
from pylint.checkers import BaseChecker
from pylint.checkers.utils import only_required_for_messages


class PropertyDecoratorChecker(BaseChecker):
    name = "property-decorator"
    msgs = {
        "W9005": (
            "Consider using a decorator instead of calling property method",
            "no-property-decorator",
            "Used when a property method is defined without using the decorator syntax.",
        )
    }

    @only_required_for_messages("no-property-decorator")
    def visit_assign(self, assign_node: nodes.Assign) -> None:
        """
        Process a module.
        The module's content is accessible via ``astroid.stream``
        """
        self._check_property_method_declaration(assign_node)

    def _check_property_method_declaration(self, node: nodes.Assign) -> None:
        """
        Checks for uses of property().
        When a @property decorator should be used instead.
        A message will be emitted only if the assignment is at a class scope
        and only if the property method's argument belongs to the class where it
        is defined.
        `node` is an assign node.
        """
        if not isinstance(node.value, nodes.Call):
            return

        # check the function called is "property method"
        func = node.value.func
        if not isinstance(func, nodes.Name) or func.name != "property":
            return
        # assignment must be at a class scope
        parent_class = node.scope()
        if not isinstance(parent_class, nodes.ClassDef):
            return

        # Check if the arg passed to classmethod is a class member
        classmeth_arg = node.value.args[0]
        if not isinstance(classmeth_arg, nodes.Name):
            return

        method_name = classmeth_arg.name
        if any(method_name == member.name for member in parent_class.mymethods()):
            self.add_message("no-property-decorator", node=node.targets[0])


def register(linter) -> None:
    linter.register_checker(PropertyDecoratorChecker(linter))
