'''
Name:        __main__.py
Purpose:
Author:      Module allowing for `python -m pylinter ...`
Created:     2026-11-13
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from pylinter import linter
linter.main()
