from typing import List
from astroid import nodes
from .define import PROPERTY_METHOD_NAME


class ScopeFinder:
    def __init__(self, scope):
        self._scope = scope
        self._module = self._scope.root()

    @staticmethod
    def is_class_funcdef_scope(scope):
        '''
        是否class/function scope
        '''
        return isinstance(scope, (nodes.ClassDef, nodes.FunctionDef))

    @staticmethod
    def locate_in_scope(scope, line):
        if isinstance(scope, nodes.Module):
            return True
        if scope.lineno <= line <= scope.end_lineno:
            return True
        return False

    @staticmethod
    def is_scope(scope):
        '''
        常量节点有body属性,但是不是scope
        '''
        return hasattr(scope, 'body') and not isinstance(scope, nodes.Const)

    @staticmethod
    def is_parent_node_classtypes(
        node,
        parent_node_classes: List[nodes.NodeNG]
    ):
        '''
        判断多级父节点是否是某个类型
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if any(isinstance(parent_node, parent_node_class) for parent_node_class in parent_node_classes):
                return True
            parent_node = parent_node.parent
        return False

    @staticmethod
    def get_parent_node_by_classtype(
        node,
        parent_node_classes: List[nodes.NodeNG]
    ):
        '''
        获取是某个类型的父节点
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if any(isinstance(parent_node, parent_node_class) for parent_node_class in parent_node_classes):
                return parent_node
            parent_node = parent_node.parent
        return None

    @staticmethod
    def get_class_method_node(classnode, method_name):
        for childnode in classnode.body:
            if isinstance(childnode, nodes.FunctionDef) and childnode.name == method_name:
                return childnode
        return None

    @staticmethod
    def get_parent_nodes_by_classtype(
        node,
        parent_node_class: nodes.NodeNG
    ):
        '''
        获取是某个类型的父节点集合
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None or isinstance(parent_node, nodes.Module):
                break
            if isinstance(parent_node, parent_node_class):
                yield parent_node
            parent_node = parent_node.parent

    @staticmethod
    def get_parent_scope(
        node
    ):
        '''
        获取第一个有body属性的父节点,即范围节点
        '''
        parent_node = node.parent
        while parent_node:
            if parent_node is None:
                break
            if hasattr(parent_node, 'body'):
                return parent_node
            parent_node = parent_node.parent
        return None

    @staticmethod
    def get_class_function_property_node(classnode, method_name):
        '''
        类属性get,set节点,方法名称都一样
        '''
        property_get_node = None
        property_set_node = None
        for childnode in classnode.body:
            if isinstance(childnode, nodes.FunctionDef) and childnode.name == method_name:
                decorators = childnode.decorators
                if decorators is not None:
                    for deco in decorators.nodes:
                        if isinstance(deco, nodes.Name) and deco.name == PROPERTY_METHOD_NAME:
                            property_get_node = childnode
                        elif isinstance(deco, nodes.Attribute) and deco.attrname == "setter":
                            property_set_node = childnode
        return property_get_node, property_set_node

    @classmethod
    def get_parent_class_node(cls, node):
        return cls.get_parent_node_by_classtype(node, [nodes.ClassDef])

    @classmethod
    def get_parent_node_by_nodeclass(cls, node, node_class_type):
        return cls.get_parent_node_by_classtype(
            node,
            [node_class_type]
        )

    @classmethod
    def get_parent_scope_node(cls, node):
        parent_node = cls.get_parent_node_by_classtype(
            node, [nodes.ClassDef, nodes.FunctionDef]
        )
        if parent_node is not None:
            return parent_node
        return node.root()

    @classmethod
    def get_class_scope(cls, node):
        return cls.get_parent_node_by_classtype(
            node,
            [nodes.ClassDef]
        )

    @classmethod
    def is_parent_node_classtype(
        cls,
        node,
        parent_node_class: nodes.NodeNG
    ):
        return cls.is_parent_node_classtypes(node, [parent_node_class])

    @classmethod
    def get_function_scope(cls, node):
        return cls.get_parent_node_by_classtype(
            node,
            [nodes.FunctionDef]
        )

    @classmethod
    def is_module_range(cls, node):
        parent_scope = cls.get_parent_scope_node(node)
        if not isinstance(parent_scope, nodes.Module):
            return False
        if cls.is_parent_node_classtype(node, nodes.If):
            pnode = cls.get_parent_node_by_classtype(node, [nodes.If])
            if node_utils.is_main_statement(pnode):
                return False
        return True

    @classmethod
    def is_class_range(cls, node):
        return cls.is_parent_node_classtype(node, nodes.ClassDef)

    def find_scope(self, line):
        if not self.locate_in_scope(self._scope, line):
            return None
        for child in self._scope.body:
            if self.locate_in_scope(child, line):
                if self.is_scope(child):
                    found_scope = ScopeFinder(child).find_scope(line)
                    return found_scope
                break
        return self._scope

    def find_funcdef_scope(self, line):
        locate_scope = self.find_scope(line)
        if isinstance(locate_scope, nodes.FunctionDef):
            return locate_scope
        parent_scope = self.get_parent_node_by_classtype(
            locate_scope,
            [nodes.FunctionDef]
        )
        if parent_scope:
            return parent_scope
        return None

    def find_classdef_scope(self, line):
        locate_scope = self.find_scope(line)
        if isinstance(locate_scope, nodes.ClassDef):
            return locate_scope
        parent_scope = self.get_parent_node_by_classtype(
            locate_scope,
            [nodes.ClassDef]
        )
        if parent_scope:
            return parent_scope
        return None

    def find_class_funcdef_scope(self, line):
        locate_scope = self.find_scope(line)
        if self.is_class_funcdef_scope(locate_scope):
            return locate_scope
        parent_scope = self.get_parent_node_by_classtype(
            locate_scope,
            [nodes.ClassDef, nodes.FunctionDef]
        )
        if parent_scope:
            return parent_scope
        return self._module
