import abc
import logging
import enum
import os
import re
from astroid import nodes
import astroid
from .node_utils import ImportNodes
from .exceptions import LineEmptyNodeError, DeleteNodeError, CodeSyntaxError
from .constants import USER_CANCEL_OPTION, DEFAULT_TAB_INDENTATION_WIDTH, LF, DEFAULT_TAB_WIDTH
from .exceptions import FixfileError, InvalidOptionIndexError
from .node_scope import ScopeFinder
from .replace import get_node_range, FixRange, get_add_range
from .codeutils import FixChoice, get_func_args_range
log = logging.getLogger(__name__)


class BaseFixer(abc.ABC):
    """description of class"""
    class FixKind(enum.Enum):
        AUTOFIX = 'autofix'  # 可自动修复所有场景的规则
        SEMI_AUTOFIX = 'semiautofix'  # 可自动修复部分场景,部分场景只能单点修复的规则
        SINGLEFIX = 'singlefix'  # 只能单点修复的规则

    FIX_MSG_OPTION = FixChoice.FIX_ALL

    def __init__(self, ruleid, toolname, kind: FixKind):
        self._ruleid = ruleid
        self._toolname = toolname
        self.fix_tool = None
        self._formatter = None
        self._fixkind = kind

    @property
    def kind(self):
        return self._fixkind

    @property
    def autofix(self):
        '''判断规则是否可自动修复'''
        return self._fixkind in [self.FixKind.AUTOFIX, self.FixKind.SEMI_AUTOFIX]

    @autofix.setter
    def autofix(self, value):
        if value:
            self._fixkind = self.FixKind.AUTOFIX
        else:
            self._fixkind = self.FixKind.SINGLEFIX

    @property
    def formatter(self):
        return self._formatter

    @property
    def ruleid(self):
        return self._ruleid

    @property
    def toolname(self):
        return self._toolname

    @classmethod
    def fix_only_autofix(cls):
        '''是否只修复可自动化修复的规则'''
        return cls.FIX_MSG_OPTION == FixChoice.FIX_AUTOFIX

    @classmethod
    def fix_all(cls):
        '''是否修复所有可修复的规则,包括单点修复规则'''
        return cls.FIX_MSG_OPTION == FixChoice.FIX_ALL

    @abc.abstractmethod
    def fix_message(self, msg):
        raise NotImplementedError('You must implemented it in derived class')

    def get_kind(self):
        if self._fixkind == self.FixKind.AUTOFIX:
            return 'autofix'
        if self._fixkind == self.FixKind.SEMI_AUTOFIX:
            return 'semiautofix'
        if self._fixkind == self.FixKind.SINGLEFIX:
            return 'singlefix'
        raise RuntimeError('invalid fix type name')

    def set_formatter(self, formatter):
        self._formatter = formatter

    def auto_fix_msg(self, msg):
        if not self.autofix and not self.fix_all():
            log.warning(
                "rule %s in tool %s could not autofix code message",
                msg.ruleid,
                self.toolname
            )
            return False
        result: bool = self.fix_message(msg)
        assert isinstance(result, bool)
        return result

    def get_msg_line_text(self, msg):
        return self.formatter.get_line_text(msg.line - 1)

    def delete_text_line(self, lineno):
        self.formatter.delete_line(lineno)

    def replace_line_text(self, line, replace_line_text):
        fix_range = FixRange(line)
        fix_range.replace_line(self.formatter, replace_line_text)

    def add_range_text(self, line, col, add_content):
        line_count = self.get_line_count()
        # 如果插入文件最后一行,且最后一行没有换行符,需要在插入内容前面添加换行符
        if line > line_count:
            log.warning(
                'add line num %d greater then doc lines count:%d',
                line,
                line_count
            )
            add_content = '\n' + add_content
        add_range = get_add_range(line, col)
        add_range.add_text(self._formatter, add_content)

    def get_line_text(self, lineno):
        # 文本总行数
        line_num = self.formatter.get_line_count()
        # 超过文本总行数
        if lineno >= line_num:
            raise FixfileError(f'get line {lineno} text exceed max file lines:{line_num - 1}')
        return self.formatter.get_line_text(lineno)

    def get_linetext_len(self, lineno):
        linetext = self.get_line_text(lineno)
        return len(self.formatter.encode_string(linetext))

    def do_rstrip_line(self, line):
        '''
        清除单行尾的空白字符
        '''
        return self.formatter.do_rstrip_line(line)

    def ask_input_string(self, title, label, initialvalue=None):
        label_text = title + "\n" + label
        if initialvalue:
            label_text += ",Default("
            label_text += initialvalue
            label_text += ")"
        label_text += ":"
        label_text += "\n"
        ask_text = input(label_text)
        if not ask_text:
            ok = False
        else:
            ok = True
        return ok, ask_text

    def ask_question(self, title, label):
        ask_text = title + "\n" + label + ":" + "\n"
        answer_text = input(ask_text)
        if answer_text.lower() in ['y', 'yes']:
            return True
        if answer_text.lower() in ['n', 'no']:
            return False
        raise InvalidOptionIndexError

    def get_line_count(self):
        return self.formatter.get_line_count()

    def convert_tabs_to_spaces(self):
        '''
        检查文本是否包含制表符, 并替换制表符为4个空格
        '''
        chars = self.formatter.text()
        tab_count = chars.count("\t")
        if not tab_count:
            return False
        newchars = self.formatter.expandtabs(chars)
        self.formatter.set_text(newchars)
        return True

    def replace_range_text(
        self,
        start_line,
        replace_text,
        start_col=None,
        end_line=None,
        end_col=None
    ):
        fixrange = FixRange(start_line, start_col, end_line, end_col)
        self.replace_fix_range_text(fixrange, replace_text)

    def replace_fix_range_text(self, fixrange, replace_text):
        fixrange.replace_with_text(self.formatter, replace_text)

    def back_text_tab(self, lineno, col=-1):
        linetext = self.get_line_text(lineno)
        if col == -1:
            blanks = linetext[0:DEFAULT_TAB_INDENTATION_WIDTH]
            if blanks.strip() != '':
                raise FixfileError('line %d back tab text not startwith 4 blanks' % lineno)
            line_back_text = linetext[DEFAULT_TAB_INDENTATION_WIDTH:]
            self.replace_line_text(lineno + 1, line_back_text)
        else:
            # 将块内的行语句退格
            blanks = linetext[0:col][0:-DEFAULT_TAB_INDENTATION_WIDTH]
            line_back_text = blanks + linetext[col:]
            self.replace_line_text(lineno + 1, line_back_text)

    def replace_text_eol(self):
        eol, mixed = self.formatter.check_eol_mixed()
        if mixed:
            return self.formatter.replace_eol(eol)
        return False


class BasePythonFixer(BaseFixer):
    ''''''

    @staticmethod
    def is_node_could_deleted(node):
        pnode = node.parent
        if isinstance(pnode, (nodes.If, nodes.For, nodes.While)) and (
            node in pnode.orelse and len(pnode.orelse) == 1
        ):
            return False
        body_nodes = (nodes.If, nodes.ExceptHandler, nodes.Try, nodes.For, nodes.While, nodes.With)
        if isinstance(pnode, body_nodes) and node in pnode.body and len(pnode.body) == 1:
            return False
        if isinstance(pnode, nodes.Try) and node in pnode.finalbody and len(pnode.finalbody) == 1:
            return False
        class_def_nodes = (nodes.ClassDef, nodes.FunctionDef)
        if isinstance(pnode, class_def_nodes) and node in pnode.body and (
            len(pnode.body) == 1 and pnode.doc_node is None
        ):
            return False
        return True

    def find_msg_node(self, msg, *, use_column=False, raise_node_exception=True):
        self.load_msg_module(msg)
        line = msg.line
        scope = ScopeFinder(self.formatter.module).find_scope(line)
        if use_column:
            node = self.formatter.find_line_col_node(line, msg.column, scope)
        else:
            node = self.formatter.find_line_node(line, scope)
        if raise_node_exception and node is None:
            raise LineEmptyNodeError('line %d node is empty' % line)
        return node

    def auto_fix_msg(self, msg):
        try:
            result: bool = super().auto_fix_msg(msg)
        except (LineEmptyNodeError, FixfileError) as ex:
            log.error(
                "fix line %d msg of code file %s error:%s",
                msg.line,
                msg.filepath,
                str(ex)
            )
            return False
        except InvalidOptionIndexError as exp:
            if str(exp) == USER_CANCEL_OPTION:
                return False
            raise exp
        # 告警修复成功,表示文件内容有变动, 需要重新解析并加载语法树
        if result:
            # 重新解析并加载语法树
            self.formatter.parse_module()
            if self.formatter.module is None:
                log.error(
                    'fix rule %s on line %d column %d occur exception.',
                    msg.ruleid,
                    msg.line,
                    msg.column
                )
                self.formatter.dump(filename="test.py")
                err = f"Fix file {msg.filepath} Error:{self.formatter.syntax_error_msg}"
                raise FixfileError(err)
        return result

    def fix_node_text(self, node, fixstr):
        fixrange = get_node_range(node)
        fixrange.replace_with_text(self.formatter, fixstr)

    def delete_node(self, node, delete_node_line=False, check_deleteable=False):
        if check_deleteable and not self.is_node_could_deleted(node):
            err_msg = 'delete node on line %d error: node cannot to be deleted' % node.lineno
            raise DeleteNodeError(err_msg)
        self.fix_node_text(node, "")
        if delete_node_line:
            self.delete_text_line(node.lineno - 1)
        return True

    def load_module(self, filepath, reload=False):
        if self.formatter.module is None or reload:
            self.formatter.parse_module()
            if self.formatter.module is None:
                err = "file:%s has syntax error:%s" % (filepath, self.formatter.syntax_error_msg)
                raise CodeSyntaxError(err)

    def load_msg_module(self, msg):
        try:
            self.load_module(msg.filepath)
        except CodeSyntaxError:
            if not self.module_has_syntax_error():
                ast_error = self.formatter.syntax_error_msg
                raise FixfileError('module file %s has ast error:%s' % (msg.filepath, ast_error))

    def get_module(self):
        return self.formatter.module

    def find_node_on_line(self, line):
        return self.formatter.find_line_node(line)

    def get_import_nodes_visitor(self):
        return ImportNodes(self.formatter.module, self.formatter)

    def fix_funcdef_args(self, funcnode, argstr):
        arg_node_range = get_func_args_range(funcnode)
        arg_node_range.replace_with_text(
            self.formatter,
            argstr
        )

    def add_node_text(self, node, add_content, end=False):
        node_range = FixRange.node_range(node)
        node_range.add_text(self.formatter, add_content, end)

    def get_function_top_comment_lines(self, funcnode):
        '''获取函数上方的注释信息'''
        top_comment_lines = []
        lineno = funcnode.lineno - 1
        while lineno >= 0:
            lineno -= 1
            if lineno >= 0 and self.is_comment_line(lineno):
                top_comment_lines.append(lineno)
            else:
                break
        return top_comment_lines

    def is_comment_line(self, line):
        line_text = self.get_line_text(line)
        if line_text.lstrip().startswith('#'):
            return True
        return False

    def insert_comment_template(self):
        self.formatter.InsertCommentTemplate()

    def get_shebang_encoding_line(self):
        return self.formatter.get_shebang_encoding_line()

    def is_position_in_comment(self, line, comment_col_offset):
        linenodes = self.find_nodes_on_line(line)
        end_linenode = linenodes[-1]
        if end_linenode.lineno == end_linenode.end_lineno:
            return comment_col_offset > end_linenode.end_col_offset
        childs = self.formatter.get_child_nodes_with_line(end_linenode, line)
        end_colnode = childs[-1]
        return comment_col_offset > end_colnode.end_col_offset

    def find_nodes_on_line(self, line):
        line_nodes = []
        self.formatter.find_line_nodes(line, line_nodes)
        return line_nodes

    def find_line_range_nodes(self, lineno, end_lineno=-1, scope=None):
        return self.formatter.find_line_range_nodes(lineno, end_lineno, scope)

    def insert_declare_encoding(self):
        self.formatter.insert_declare_encoding()

    def find_msg_scope(self, msg):
        self.load_msg_module(msg)
        scope = ScopeFinder(self.get_module()).find_scope(msg.line)
        return scope

    def add_import_node(self, importname):
        '''加入导入语句'''
        visitor = self.get_import_nodes_visitor()
        if not visitor.is_import_exist(importname):
            insert_line = visitor.get_import_line()
            self.add_range_text(insert_line + 1, 0, f"import {importname}" + os.linesep)
            return True
        return False

    def fix_node(self, node):
        self.fix_node_text(node, node.as_string())

    def get_else_line(self, end_line, start_line=None):
        '''获取else语句所在的行,用来删除else行'''
        return self.get_feature_word_line(end_line, 'else', start_line)

    def get_feature_word_line(self, end_line, word, start_line=None):
        '''获取特征单词所在的行,用来删除else行'''
        i = end_line
        start_line = 0 if start_line is None else start_line
        while i > start_line:
            line_text = self.get_line_text(i)
            if re.search(rf"{word}\s*:", line_text):
                return i
            i -= 1
        return -1

    def get_finally_line(self, line):
        '''获取finally语句所在的行,用来删除finally行'''
        return self.get_feature_word_line(line, 'finally')

    def get_scope_range_texts(self, scope):
        '''获取函数起使至结束行的文本范围信息,同时包含函数上方的注释信息'''
        line_range_texts = []
        top_comment_lines = self.get_function_top_comment_lines(scope)
        if top_comment_lines:
            for top_comment_line in top_comment_lines[::-1]:
                line_range_texts.append(self.get_line_text(top_comment_line))
        for i in range(scope.lineno - 1, scope.end_lineno):
            line_range_texts.append(self.get_line_text(i))
        return LF.join(line_range_texts)

    def get_node_col_offset_blanks(self, node):
        blanks_count, tabs_count = self.get_node_col_offset_whitespaces_count(node)
        if tabs_count > 0:
            return ' ' * blanks_count + '\t' * tabs_count
        return ' ' * node.col_offset

    def get_node_col_offset(self, node):
        _blanks_count, tabs_count = self.get_node_col_offset_whitespaces_count(node)
        if tabs_count > 0:
            return node.col_offset - tabs_count + tabs_count * DEFAULT_TAB_WIDTH
        return node.col_offset

    def get_node_line_text(self, node):
        linetext = self.get_line_text(node.lineno - 1)
        return linetext

    def get_node_col_offset_whitespaces_count(self, node):
        linetext = self.get_node_line_text(node)
        col_offset = node.col_offset - 1
        tabs_count = 0
        blanks_count = 0
        while col_offset >= 0:
            if linetext[col_offset] == '\t':
                tabs_count += 1
            else:
                blanks_count += 1
            col_offset -= 1
        return blanks_count, tabs_count

    def iter_scope_childs(self, scope):
        return self.formatter.iter_scope_children(scope)

    def build_class_func_name_node(self, scope):
        return self.formatter.build_name_node(scope)

    def module_has_syntax_error(self):
        if self.formatter.module is None and (
            isinstance(self.formatter.ex, astroid.AstroidSyntaxError)
        ):
            return True
        return False
