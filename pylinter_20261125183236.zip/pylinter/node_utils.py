from __future__ import annotations
import re
import astroid
from astroid.exceptions import AstroidError
from astroid.context import InferenceContext
from astroid.typing import InferenceResult
from astroid import nodes
from .define import MAIN_FUNCTION_NAME, PROPERTY_METHOD_NAME
from .constants import BUILTMODULE_NAME


class ImportNodes:
    def __init__(self, module, formatter):
        self._module = module
        self._formatter = formatter

    def is_import_exist(self, modname):
        for child in self._module.body:
            if isinstance(child, nodes.Import):
                names = [name[0] for name in child.names]
                if modname in names:
                    return True
        return False

    def is_fromimport_exist(self, modname, import_name):
        for child in self._module.body:
            if isinstance(child, nodes.ImportFrom):
                if child.modname == modname:
                    return import_name in [name[0] for name in child.names]
        return False

    def get_import_nodes(self):
        '''
        获取模块范围内的所有导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, (nodes.Import, nodes.ImportFrom)):
                import_nodes.append(child)
        return import_nodes

    def get_top_import_nodes(self):
        '''
        获取模块开头的导入语句
        '''
        import_nodes = []
        for child in self._module.body:
            if isinstance(child, nodes.Assign):
                valid_targets = [
                    isinstance(target, nodes.AssignName)
                    and target.name.startswith("__")
                    and target.name.endswith("__")
                    for target in child.targets
                ]
                if all(valid_targets):
                    continue
            if not isinstance(child, (nodes.Import, nodes.ImportFrom)):
                break
            import_nodes.append(child)
        return import_nodes

    def get_lastimport_node(self, top_imports):
        if top_imports:
            import_nodes = self.get_top_import_nodes()
        else:
            import_nodes = self.get_import_nodes()
        if not import_nodes:
            return None
        return import_nodes[-1]

    def is_fromimport_node_multilines(self, fromimport_node):
        '''from xx import结点是否多行'''
        if not isinstance(fromimport_node, nodes.ImportFrom) or len(fromimport_node.names) <= 1:
            return False
        node_line_text = self._formatter.get_line_text(fromimport_node.lineno - 1)
        matched = re.match(r"from\s+.+\s+import\s+\(", node_line_text)
        if not matched:
            return False
        return True

    def get_import_line(self, top_imports=False):
        last_node = self.get_lastimport_node(top_imports)
        if last_node is not None:
            if self.is_fromimport_node_multilines(last_node):
                # from xx import节点存在多行时,结点的行列号值不准确,获取下一个节点的行号
                next_sibl_node = last_node.next_sibling()
                if next_sibl_node is not None:
                    return next_sibl_node.lineno - 1
                return self._formatter.get_line_count() - 1
            return last_node.lineno
        if self._module.doc_node is None:
            shebang_or_encoding_line = self._formatter.get_shebang_encoding_line()
            return shebang_or_encoding_line
        return self.get_docstring_line()

    def get_docstring_line(self):
        return self._module.doc_node.end_lineno


def is_const_type(node, valtype):
    return isinstance(node, nodes.Const) and isinstance(node.value, valtype)


def get_node_childs(node, childs: list, max_recursion_size=10000):
    for child in node.get_children():
        if len(childs) < max_recursion_size:
            childs.append(child)
        get_node_childs(child, childs, max_recursion_size)


def get_builtin_type(typevalue):
    return typevalue.pytype().replace(f'{BUILTMODULE_NAME}.', '')


def _get_python_type_of_node(node: nodes.NodeNG) -> str | None:
    pytype: Callable[[], str] | None = getattr(node, "pytype", None)
    if callable(pytype):
        return pytype()
    return None


def safe_infer(node: nodes.NodeNG):
    """
    Return the inferred value for the given node.
    Return None if inference failed or if there is some ambiguity (more than
    one node has been inferred of different types).
    If compare_constants is True and if multiple constants are inferred,
    unequal inferred values are also considered ambiguous and return None.
    """
    inferred_types: set[str | None] = set()
    try:
        infer_gen = node.infer()
        value = next(infer_gen)
    except astroid.InferenceError:
        return None
    except Exception as e:
        raise AstroidError from e

    if value is not astroid.Uninferable:
        inferred_types.add(_get_python_type_of_node(value))

    try:
        for inferred in infer_gen:
            inferred_type = _get_python_type_of_node(inferred)
            if inferred_type not in inferred_types:
                return None  # If there is ambiguity on the inferred node.
            if (
                compare_constants
                and isinstance(inferred, nodes.Const)
                and isinstance(value, nodes.Const)
                and inferred.value != value.value
            ):
                return None
            if (
                isinstance(inferred, nodes.FunctionDef)
                and inferred.args.args is not None
                and isinstance(value, nodes.FunctionDef)
                and value.args.args is not None
                and len(inferred.args.args) != len(value.args.args)
            ):
                return None  # Different number of arguments indicates ambiguity
    except astroid.InferenceError:
        return None  # There is some kind of ambiguity
    except StopIteration:
        return value
    except Exception as e:  # pragma: no cover
        raise AstroidError from e
    return value if len(inferred_types) <= 1 else None


def infer_all(
    node: nodes.NodeNG, context: InferenceContext | None = None
) -> list[InferenceResult]:
    try:
        return list(node.infer(context=context))
    except astroid.InferenceError:
        return []
    except Exception as e:  # pragma: no cover
        raise AstroidError from e


def is_main_statement(statement):
    if isinstance(statement, nodes.If) and isinstance(statement.test, nodes.Compare) and (
        isinstance(statement.test.left, nodes.Name) and statement.test.left.name == "__name__") and (
        statement.test.ops and isinstance(statement.test.ops[0][1], nodes.Const)) and (
        statement.test.ops[0][1].value == MAIN_FUNCTION_NAME
    ):
        return True
    return False


def get_import_names(importnode):
    names = []
    for name, asname in importnode.names:
        if asname is not None:
            names.append(asname)
        else:
            names.append(name)
    return names


def get_node_value_type(node):
    '''获取astroid节点对应的python内建类型'''
    if isinstance(node, nodes.Const):
        const_type = get_builtin_type(node)
        if const_type == "bytes":
            return {'value_kind': const_type}
        return {'value': node.value, 'value_kind': const_type}
    if isinstance(node, nodes.UnaryOp):
        if node.op in ('-', '+'):
            kw = get_node_value_type(node.operand)
            if kw:
                kw['value'] = node.as_string()
                return kw
    elif isinstance(node, nodes.List):
        return {'value_kind': 'list'}
    elif isinstance(node, nodes.Set):
        return {'value_kind': 'set'}
    elif isinstance(node, nodes.Dict):
        return {'value_kind': 'dict'}
    elif isinstance(node, nodes.Tuple):
        return {'value_kind': 'tuple'}
    elif isinstance(node, nodes.Call):
        if isinstance(node.func, nodes.Name):
            func_name = node.func.name
            if func_name in ['list', 'tuple', 'set', 'dict']:
                return {'value_kind': func_name}
    return {}


def get_builtintype_default_values(builtintype):
    if builtintype == "bool":
        return [False, True]
    if builtintype == "int":
        return [0, -1]
    if builtintype == "str":
        return ['""',]
    if builtintype == "dict":
        return [{},]
    if builtintype == "set":
        return [{},]
    if builtintype == "list":
        return [[],]
    if builtintype == "tuple":
        return [(),]
    if builtintype == "float":
        return [0.0,]
    return [None,]


def is_function_property(node):
    if not isinstance(node, nodes.FunctionDef):
        return False, False
    decorators = node.decorators
    if decorators is not None:
        for deco in decorators.nodes:
            if isinstance(deco, nodes.Name) and deco.name == PROPERTY_METHOD_NAME:
                return True, False
            if isinstance(deco, nodes.Attribute) and deco.attrname in (
                "getter",
                "setter",
            ):
                return True, True
    return False, False
