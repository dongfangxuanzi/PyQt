import json
import re
import getpass
import os
import datetime
import logging
import astroid
from astroid import nodes
from .node_scope import ScopeFinder
from .constants import (
    CRLF,
    LF,
    CR,
    DEFAULT_INDENT_SIZE,
    ENCODING_DECLARE_LINE_NUM,
    DEFAULT_TAB_INDENTATION_WIDTH,
    DEFAULT_ENCODING_DECLARE
)
from . import strutils
from .encodings import UTF8_ENCODING
log = logging.getLogger(__name__)


class TextFormatter:
    """纯文本操作"""

    def __init__(self, lines, filename):
        self.__lines = lines
        self._lines_count = 0
        self.update_lines_count()
        self._filename = filename

    @property
    def lines(self):
        return self.__lines

    def text(self):
        return ''.join(self.__lines)

    def set_text(self, content):
        self.__lines.clear()
        self.__lines = content.splitlines(keepends=True)

    def update_lines_count(self):
        # 如果文本最后一行以换行符结尾,手动添加一个空行
        if self.__lines and self.line_endswith_linesep(self.__lines[-1]):
            self.__lines.append('')
        self._lines_count = len(self.__lines)

    def encode_string(self, source_str):
        """
        Protected method to encode a string depending on the current mode.
        @param string string to be encoded (str)
        @return encoded string (bytes)
        """
        if isinstance(source_str, bytes):
            return source_str
        return source_str.encode(UTF8_ENCODING)

    def encode_line(self, lineindex):
        return self.encode_string(self.__lines[lineindex])

    def dump(self, filename=None):
        if filename is None:
            text = json.dumps(self.__lines, indent=DEFAULT_INDENT_SIZE)
            log.debug(text)
        else:
            content = ''.join(strutils.normalize_line_endings(self.__lines, LF))
            with open(filename, "w", encoding=UTF8_ENCODING) as f:
                print(content, file=f)

    def get_line_count(self):
        if not self._lines_count:
            self._lines_count = len(self.__lines)
        return self._lines_count

    def get_top_lines(self, line_num):
        lines = []
        for index in range(line_num):
            linetext = self.get_line_text(index)
            if linetext is not None:
                lines.append(linetext)
        return lines

    def get_lineno(self, line):
        if line == -1:
            line = self.GetCtrl().get_current_line()
        return line

    def get_chars(self, startline, startindex, endline, endindex):
        '''
        获取区间范围的文本
        '''
        startline_text = self.__lines[startline]
        # 获取单行区间范围的内容
        if startline == endline:
            chars = self.encode_string(startline_text)[startindex:endindex]
            return strutils.ensure_string(chars)
        chars = b''
        for line in range(startline, endline + 1):
            if line == startline:
                chars += self.encode_line(startline)[startindex:]
            elif line == endline:
                chars += self.encode_line(endline)[0:endindex]
            else:
                chars += self.encode_line(line)
        return strutils.ensure_string(chars)

    def line_endswith_linesep(self, linetext):
        if linetext.endswith(CRLF):
            return True
        if linetext.endswith(CR) or linetext.endswith(LF):
            return True
        return False

    def get_line_end(self, linetext):
        if linetext.endswith(CRLF):
            return CRLF
        if linetext.endswith(CR):
            return CR
        if linetext.endswith(LF):
            return LF
        return None

    def get_line_text(self, line):
        if line >= self._lines_count:
            return None
        linetext = self.__lines[line]
        if linetext.endswith(CRLF):
            return linetext[0:-len(CRLF)]
        if linetext.endswith(CR) or linetext.endswith(LF):
            return linetext[0:-len(CR)]
        return linetext

    def get_line_length(self, line):
        linetext = self.__lines[line]
        if linetext.endswith(CRLF):
            return len(self.encode_string(linetext.rstrip(CRLF))) + 1
        if linetext.endswith(LF):
            return len(self.encode_string(linetext.rstrip(LF))) + 1
        return len(self.encode_string(linetext))

    def position_from_linecol(self, line, col=0):
        '''
        从行列号获取文本内的位置
        '''
        if line >= self._lines_count:
            return len(self.encode_string(self.text()))
        assert line <= self._lines_count - 1
        pos = 0
        for i in range(line):
            line_length = self.get_line_length(i)
            pos += line_length
        return pos + col

    def get_region(self, startline, startindex, endline, endindex):
        chars = self.get_chars(startline, startindex, endline, endindex)
        lines = chars.split(LF)
        head = self.position_from_linecol(startline, startindex)
        tail = self.position_from_linecol(endline, endindex)
        return head, tail, chars, lines

    def set_region(self, head, tail, chars, lines):
        newchars = LF.join(lines)
        if newchars == chars:
            return
        self.delete_target(head, tail)
        self.insert_text(head, newchars)

    def line_from_position(self, pos):
        start_pos = 0
        for i in range(self._lines_count):
            line_length = self.get_line_length(i)
            if start_pos <= pos < (start_pos + line_length):
                return i
            start_pos += line_length
        return self._lines_count - 1

    def index_from_position(self, pos):
        """
        从文本内的位置获取行列号
        """
        line = self.line_from_position(pos)
        linepos = self.position_from_linecol(line)
        return line, pos - linepos

    def insert_text(self, pos, chars):
        line, column = self.index_from_position(pos)
        self.insert_line_col_text(line, column, chars)

    def insert_line_col_text(self, line, column, chars):
        if chars.find(LF) != -1:
            newlines = chars.splitlines(keepends=True)
            if column == 0:
                self.__lines.insert(line, newlines[0])
                newlines[-1] = newlines[-1] + self.get_line_end(self.__lines[line])
            else:
                linetext = self.encode_string(self.__lines[line])
                self.__lines[line] = strutils.ensure_string(linetext[0:column]) + newlines[0]
                line_end_text = strutils.ensure_string(linetext[column:])
                if not self.line_endswith_linesep(newlines[-1]):
                    newlines[-1] = newlines[-1] + line_end_text
            for newline in newlines[1:][::-1]:
                self.__lines.insert(line + 1, newline)
            self.update_lines_count()
        else:
            linetext = self.encode_string(self.__lines[line])
            self.__lines[line] = strutils.ensure_string(
                linetext[0:column]) + chars + strutils.ensure_string(linetext[column:])

    def delete_target(self, head, tail):
        start_line, start_column = self.index_from_position(head)
        end_line, end_column = self.index_from_position(tail)
        start_line_text = self.encode_string(self.__lines[start_line])
        end_line_text = self.encode_string(self.__lines[end_line])
        is_del_lines = False
        for i in range(end_line, start_line - 1, -1):  # Go from len-1 to 0
            if i == start_line:
                self.__lines[i] = strutils.ensure_string(
                    start_line_text[0:start_column] + end_line_text[end_column:]
                )
            else:
                del self.__lines[i]
                is_del_lines = True
        if is_del_lines:
            self.update_lines_count()

    def delete_line(self, line=-1):
        lineno = self.get_lineno(line)
        self.delete_target(
            self.position_from_linecol(lineno),
            self.position_from_linecol(lineno + 1)
        )

    def do_rstrip_line(self, line):
        '''
        清除单行尾的空白字符
        '''
        # 获取不含换行符的行文本
        txt = self.get_line_text(line)
        raw = len(self.encode_string(txt))
        cut = len(self.encode_string(txt.rstrip()))
        # Since text.delete() marks file as changed, even if not,
        # only call it when needed to actually delete something.
        if cut < raw:
            target_start = self.position_from_linecol(line, cut)
            target_end = self.position_from_linecol(line, raw)
            self.delete_target(target_start, target_end)
            return True
        return False

    def expandtabs(self, chars, indent=DEFAULT_TAB_INDENTATION_WIDTH):
        '''
        将字符串里面的制表符替换为几个空白字符
        indent:制表符宽度,相当于几个空白字符
        '''
        return chars.expandtabs(indent)

    def check_eol_mixed(self):
        '''
        检测文本是否混合行尾
        '''
        mixed = False
        tmp = None
        line_end = None
        for cur in self.lines:
            cur_line_end = self.get_line_end(cur)
            if cur_line_end is not None:
                line_end = cur_line_end
            if cur_line_end and not tmp:
                tmp = cur_line_end
            elif tmp:
                if line_end != tmp:
                    mixed = True
                    break
        return line_end, mixed

    def replace_eol(self, replace_line_end):
        '''
        替换换行符
        '''
        replaced = False
        for index, line in enumerate(self.lines):
            cur_line_end = self.get_line_end(line)
            if cur_line_end and replace_line_end != cur_line_end:
                new_line = line[0:-len(cur_line_end)] + replace_line_end
                self.lines[index] = new_line
                replaced = True
        return replaced


class ModuleFormatter(TextFormatter):
    '''模块格式化类'''

    def __init__(self, lines, filename):
        super().__init__(lines, filename)
        self.ex = None
        self._module = None
        self._syntax_error_msg = None

    @property
    def syntax_error_msg(self):
        return self._syntax_error_msg

    @property
    def module(self):
        return self._module

    @staticmethod
    def build_name_node(scope_node):
        position = scope_node.position
        name = scope_node.name
        # 某些python文件格式有问题会导致scope position为空
        if position is not None:
            name_col_offset = position.end_col_offset - len(name)
            name_lineno = position.lineno
            name_end_lineno = position.end_lineno
            name_end_col_offset = position.end_col_offset
        else:
            log.error(
                "find position of scope name:%s,node:%s is null on line %d",
                name,
                scope_node,
                scope_node.lineno
            )
            name_col_offset = 0
            name_lineno = 0
            name_end_lineno = 0
            name_end_col_offset = 0
        return nodes.Name(
            name,
            name_lineno,
            name_col_offset,
            scope_node,
            end_lineno=name_end_lineno,
            end_col_offset=name_end_col_offset
        )

    @staticmethod
    def get_python_coding_declare(lines):
        # Only consider the first two lines
        coding_reg_str = re.compile(r'^[ \t\f]*#.*coding[:=][ \t]*([-\w.]+)')
        blank_reg_str = re.compile(r'^[ \t\f]*(?:[#\r\n]|$)')
        lst = lines[:ENCODING_DECLARE_LINE_NUM]
        hit_line = 0
        for line in lst:
            hit_line += 1
            match = coding_reg_str.match(line)
            if match is not None:
                break
            if not blank_reg_str.match(line):
                return None, -1
        else:
            return None, -1
        name = match.group(1)
        return name, hit_line

    @classmethod
    def iter_scope_children(cls, scope):
        if ScopeFinder.is_class_funcdef_scope(scope):
            yield cls.build_name_node(scope)
        yield from scope.get_children()

    def find_line_col_node(self, lineno, col, scope=None):
        linenodes = []
        self.find_line_nodes(lineno, linenodes, scope)
        if not linenodes:
            scope_range = self.get_scope_range(scope)
            log.error(
                "could not find line nodes on line %d in scope range `%s` of file %s",
                lineno,
                f"{scope_range[0]}, {scope_range[1]}, nodeclass:{scope_range[2]}",
                self._module.file
            )
            return None
        return self.find_col_node(lineno, col, linenodes)

    def find_col_node(self, lineno, col, linenodes: list):
        for linenode in linenodes:
            colnode = self._find_col_node(lineno, col, linenode)
            if colnode:
                return colnode
        return linenodes[-1]

    def parse_module(self):
        module_name = strutils.get_filename_without_ext(self._filename)
        try:
            self._module = astroid.parse(
                self.text(), path=self._filename, module_name=module_name)
        except astroid.AstroidSyntaxError as ex:
            self.ex = ex
            self._syntax_error_msg = str(ex)
            self._module = None
            log.error('parse file %s syntax error:%s', self._filename, str(ex))
        except Exception as exp:
            self.ex = exp
            log.exception('parse file %s ast error:', self._filename)

    def get_scope_range(self, scope):
        if scope is None:
            return 1, 'end of file', self._module.__class__.__name__
        return scope.lineno, scope.end_lineno, scope.__class__.__name__

    def find_line_node(self, lineno, scope=None):
        node_list = []
        self.find_line_nodes(lineno, node_list, scope)
        if node_list:
            return node_list[0]
        scope_range = self.get_scope_range(scope)
        log.error(
            "could not find line nodes on line %d in scope range `%s` of file %s",
            lineno,
            f"{scope_range[0]}, {scope_range[1]}, nodeclass:{scope_range[2]}",
            self._module.file
        )
        return None

    def InsertCommentTemplate(self, insert_line=0):
        file_name = os.path.basename(self._filename)
        now_time = datetime.datetime.now()
        comment_template = '''\'\'\'
Name:        {File}
Purpose:

Author:      {Author}

Created:     {Date}
Copyright:   (c) {Author} {Year}
Licence:     {Licence}
\'\'\'
'''
        comment_template_content = comment_template.format(
            File=file_name,
            Author=getpass.getuser(),
            Date=now_time.date(),
            Year=now_time.date().year,
            Licence='<your licence>'
        )
        self.insert_line_col_text(insert_line, 0, comment_template_content)

    def find_line_nodes(self, lineno, linenodes: list, scope=None):
        if scope is None:
            scope = self._module
        for child in self.iter_scope_children(scope):
            if isinstance(child, nodes.ImportFrom) and (
                child.lineno <= lineno <= child.end_lineno
            ):
                linenodes.append(child)
            elif child.lineno == lineno:
                linenodes.append(child)
            elif child.lineno and child.lineno > lineno:
                log.debug(
                    'skip line %d nodes greater then find line %d',
                    child.lineno,
                    lineno
                )
                break
            else:
                self.find_line_nodes(lineno, linenodes, child)

    def get_shebang_encoding_line(self):
        lines = self.get_top_lines(ENCODING_DECLARE_LINE_NUM)
        encoding_line = self.get_python_coding_declare(lines)[1]
        shebang_line = -1
        for i, line in enumerate(lines):
            match = re.match(
                r'#!\s*(/usr/bin/python|/usr/env/bin\s*python)', line.strip())
            if match is not None:
                shebang_line = i + 1
                break
        if shebang_line > encoding_line:
            return shebang_line
        return 0 if encoding_line < 0 else encoding_line

    def get_child_nodes_with_line(self, scope_node, line):
        child_nodes = []
        for child in self.iter_scope_children(scope_node):
            if child.lineno == line:
                child_nodes.append(child)
        return child_nodes

    def insert_declare_encoding(self):
        lines = self.get_top_lines(ENCODING_DECLARE_LINE_NUM)
        coding_name, line_num = self.get_python_coding_declare(lines)
        if coding_name is not None:
            self.delete_line(line_num - 1)
        else:
            if line_num <= 0:
                line_num = 1
        self.insert_line_col_text(line_num - 1, 0, DEFAULT_ENCODING_DECLARE + "\n")

    def _find_col_node(self, lineno, col, node):
        for child in node.get_children():
            if child.col_offset is not None and (
                child.col_offset <= col <= child.end_col_offset and lineno == child.lineno
            ):
                col_node = self._find_col_node(lineno, col, child)
                if col_node:
                    return col_node
                return child
            col_node = self._find_col_node(lineno, col, child)
            if col_node:
                return col_node
        if node.col_offset is not None and node.col_offset <= col <= node.end_col_offset:
            return node
        return None
