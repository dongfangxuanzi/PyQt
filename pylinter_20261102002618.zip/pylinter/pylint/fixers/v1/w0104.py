# -*- coding: utf-8 -*-
'''
Name:        w0104.py
Purpose:     修复无效的语句和无效的3引号字符串
Author:      wukan
Created:     2026-06-21
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from .... import constants
from .... import node_utils
from ....pylint_fix import PylintFixer
from ....multifixer import MultiOptionFixer


class PylintW0104Fixer(PylintFixer):
    '''
    规则说明:无效的语句
    '''

    def __init__(self):
        super().__init__('W0104', self.FixKind.SINGLEFIX)

    @staticmethod
    def get_fix_node(node):
        parent_node = node
        lineno = parent_node.lineno
        fixnode = parent_node
        while parent_node.lineno == lineno:
            parent_node = parent_node.parent
            if parent_node.lineno == lineno:
                fixnode = parent_node
        return fixnode

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        fixnode = self.get_fix_node(node)
        if not isinstance(fixnode, nodes.Expr):
            return False
        return self.delete_node(fixnode)


class PylintW0105Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:无效的3引号字符串,可以删除或者转换为注释
    '''

    def __init__(self):
        super().__init__('W0105', self.FixKind.SEMI_AUTOFIX)
        MultiOptionFixer.__init__(
            self,
            1,
            title='Process pointless string statement',
            descr="Please choose one option",
            init_options=['Delete them', 'Convert them to comments']
        )

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        if not node_utils.is_const_type(node, str):
            return False
        if not self.is_node_could_deleted(node.parent):
            return False
        self.get_selection()
        if self.selection == 0:
            return self.delete_node(node, delete_node_line=True)
        if self.selection == 1:
            node_offset_blanks = self.get_node_col_offset_blanks(node)
            docstr = node.value.strip()
            fixstr = ''
            fixstr += constants.LF
            doc_lines = docstr.split(constants.LF)
            doc_line_count = len(doc_lines)
            for linestr in doc_lines:
                fixstr += node_offset_blanks
                fixstr += '# '
                fixstr += linestr.strip()
                fixstr += constants.LF
            fix_doc_lines = fixstr.split(constants.LF)
            fix_doc_line_count = len(fix_doc_lines)
            if fix_doc_line_count > doc_line_count:
                fix_doc_lines = fix_doc_lines[0:-1]
                fixstr = constants.LF.join(fix_doc_lines)
            self.fix_node_text(node, fixstr)
            self.delete_text_line(msg.line - 1)
            return True
        return False
