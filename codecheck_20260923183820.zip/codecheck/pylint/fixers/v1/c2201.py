import re
from astroid import nodes
from novalapp.python.parser import node_utils
from ....pylint_fix import PylintFixer


class PylintC2201Fixer(PylintFixer):
    '''
    规则说明:扩展规则,整数比较应该放在比较符号右边
    '''

    def __init__(self):
        super().__init__('C2201', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        if node_utils.is_const_type(node, int) and isinstance(node.parent, nodes.Compare):
            pnode = node.parent
            res = re.search(r"Comparison should be (.*) \(misplaced-comparison-constant\)", msg.msg)
            repstr = res.groups()[0]
            if pnode.as_string() == repstr:
                return False
            self.fix_node_text(pnode, repstr)
            return True
        return False
