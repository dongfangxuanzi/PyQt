import re
from typing import cast
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR6301Fixer(PylintFixer):
    '''
    规则说明:扩展规则,
    成员方法没有引用类成员,
    可以转换为staticmethod,classmethod或者abstractmethod
    '''

    def __init__(self):
        super().__init__('R6301', False)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef):
            scope = cast(nodes.FunctionDef, node.parent)
            choices = ["convert to abstractmethod",
                       "convert to staticmethod", 'convert to classmethod']
            sel = self.ask_input_list(
                "Convert to",
                "Please choose one method option",
                choices,
                selection=0
            )
            blanks = scope.position.col_offset * ' '
            if not sel:
                visitor = self.get_import_nodes_visitor()
                if visitor.is_import_exist('abc'):
                    self.add_range_text(
                        scope.position.lineno,
                        0,
                        blanks + '@abc.abstractmethod' + '\n'
                    )
                elif visitor.is_fromimport_exist('abc', 'abstractmethod'):
                    self.add_range_text(scope.position.lineno, 0, blanks + "@abstractmethod" + "\n")
                else:
                    insert_line = visitor.get_import_line()
                    self.add_range_text(
                        scope.position.lineno,
                        0,
                        blanks + '@abc.abstractmethod' + '\n'
                    )
                    self.add_range_text(insert_line + 1, 0, "import abc" + "\n")
                return True
            else:
                args = scope.args
                argstr = args.as_string()
                if sel == 1:
                    replace_argstr = re.sub(r"self\s*,*", "", argstr).strip()
                    self.fix_funcdef_args(scope, replace_argstr)
                    self.add_range_text(scope.position.lineno, 0, blanks + "@staticmethod" + "\n")
                elif sel == 2:
                    replace_argstr = re.sub(r"self\s*", "cls", argstr).strip()
                    self.fix_funcdef_args(scope, replace_argstr)
                    self.add_range_text(scope.position.lineno, 0, blanks + "@classmethod" + "\n")
                return True
        return False


class PylintR0201Fixer(PylintR6301Fixer):
    '''
    R6301对应的老规则
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'R0201', False)
