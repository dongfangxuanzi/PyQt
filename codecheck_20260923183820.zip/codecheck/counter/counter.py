from novalapp.util import fileutils
from novalapp.project.processor import Processor
from novalapp import _
from novalapp.util import utils, strutils
from novalapp.common.encodings import UTF8_FILE_ENCODING, BINARY
from novalapp.syntax import lang
from novalapp.syntax import syntax
from ..common_check import CommonChecker
from .. import configkeys
from .metrics import Metric, TotalMetric


def is_comment_line(line, line_comment_flags: list):
    if line_comment_flags == []:
        return False
    for line_comment_flag in line_comment_flags:
        if line.startswith(line_comment_flag):
            return True
    return False


def is_block_comment_start(line, block_comment_start_flag):
    if block_comment_start_flag is None:
        return False
    return is_comment_line(line, [block_comment_start_flag])


def is_block_comment_end(line, block_comment_end_flag):
    if block_comment_end_flag is None:
        return False
    line = line.rstrip()
    if line.endswith(block_comment_end_flag):
        return True
    return False


class CodeMetricsProcessor(Processor, CommonChecker):
    """description of class"""

    def __init__(self, parent, statusbar):
        self.metrics_viewer = parent
        super().__init__(statusbar, 'CodeMetrics', False)
        CommonChecker.__init__(self)
        self._total_metric = TotalMetric(0, 0, 0, 0, '', _('All Language'), 0)

    def run(self, doc, filepath):
        super().run(doc, filepath)
        ext = strutils.get_file_extension(filepath)
        if not syntax.SyntaxThemeManager().IsExtSupported(ext):
            return False
        if not self.check_enabled(doc, filepath):
            return False
        if self.stopped:
            utils.get_logger().debug('check codemetrics is stopped when running')
            return False
        if not utils.profile_get_int(configkeys.CHECK_CODE_METRICS_KEY, False):
            utils.get_logger().error('check codemetrics is disabled')
            return False
        encoding = UTF8_FILE_ENCODING
        try:
            encoding = fileutils.detect_file_encoding(filepath)
            utils.get_logger().debug("detect file %s encoding is %s", filepath, encoding)
        except Exception:
            utils.get_logger().error("get file %s encoding error", filepath)
            return False
        if encoding == BINARY or encoding is None:
            return False
        file_lexer = syntax.SyntaxThemeManager().GetLangLexerFromExt(ext)
        language = file_lexer.GetShowName()
        langid = file_lexer.GetLangId()
        self._total_metric.files_count += 1
        with open(filepath, encoding=encoding) as freader:
            lines = freader.readlines()
            line_count = len(lines)
            blank_lines_count = 0
            if lines and strutils.line_endswith_linebreak(lines[-1]):
                blank_lines_count += 1
                line_count += 1
            if langid == lang.ID_LANG_TXT:
                blank_lines_count = sum(not linetext.strip() for linetext in lines)
                metric = Metric(blank_lines_count, 0, 0, line_count, filepath, language)
            else:
                block_comment_start_flag = None
                block_comment_end_flag = None
                # 某个编程语言可能有多个行注释符号
                line_comment_flags = []
                patterns = file_lexer.GetCommentPatterns()
                if len(patterns) == 1:
                    if len(patterns[0]) == 1:
                        line_comment_flag = patterns[0][0]
                        line_comment_flags.append(line_comment_flag)
                    else:
                        block_comment_start_flag = patterns[0][0]
                        block_comment_end_flag = patterns[0][1]
                elif len(patterns) == 2:
                    if len(patterns[0]) == 1:
                        line_comment_flag = patterns[0][0]
                        line_comment_flags.append(line_comment_flag)
                        if len(patterns[1]) == 2:
                            block_comment_start_flag = patterns[1][0]
                            block_comment_end_flag = patterns[1][1]
                        elif len(patterns[1]) == 1:
                            line_comment_flags.append(patterns[1][0])
                    else:
                        if len(patterns[0]) == 2:
                            block_comment_start_flag = patterns[0][0]
                            block_comment_end_flag = patterns[0][1]
                        elif len(patterns[0]) == 1:
                            line_comment_flags.append(patterns[0][0])
                        line_comment_flag = patterns[1][0]
                        line_comment_flags.append(line_comment_flag)
                else:
                    raise
                is_in_blockcomment = False
                count = 0
                valid_lines_count = 0
                comment_lines_count = 0
                for line in lines:  # 一行一行的扫描文件内部。
                    count += 1
                    line = line.strip()
                    if not line:
                        blank_lines_count += 1
                        continue
                    if is_in_blockcomment is True:
                        comment_lines_count += 1
                        if is_block_comment_end(line, block_comment_end_flag):  # 如果是注释结束，就将标识符置为否
                            is_in_blockcomment = False
                            continue
                        else:
                            continue
                    else:
                        # 如果是注释开始，就将标识符置为是
                        if is_block_comment_start(line, block_comment_start_flag):
                            is_in_blockcomment = True
                            comment_lines_count += 1
                            continue
                    if is_comment_line(line, line_comment_flags):  # 如果是注释行，那么就跳转。
                        comment_lines_count += 1
                        continue
                    valid_lines_count += 1
                metric = Metric(
                    blank_lines_count,
                    comment_lines_count,
                    valid_lines_count,
                    line_count,
                    filepath,
                    language
                )
        self._total_metric.blank_lines_count += metric.blank_lines_count
        self._total_metric.comment_lines_count += metric.comment_lines_count
        self._total_metric.code_lines_count += metric.code_lines_count
        self._total_metric.file_lines_count += metric.file_lines_count
        self.metrics_viewer.SIG_APPEND_METRIC_ITEM.emit(metric)
        return True

    def init(self, doc):
        super().init(doc)
        self.init_checker(doc)
        self.enabled = True
        self._total_metric.blank_lines_count = 0
        self._total_metric.comment_lines_count = 0
        self._total_metric.code_lines_count = 0
        self._total_metric.file_lines_count = 0
        self._total_metric.files_count = 0
        self.metrics_viewer.SIG_INIT_PROCESSOR.emit()

    def end(self, doc):
        if self.stopped:
            utils.get_logger().error('codecheck is stopped with some reason')
        super().end(doc)
        self.enabled = False
        self.metrics_viewer.SIG_END_PROCESSOR.emit(self._total_metric)
