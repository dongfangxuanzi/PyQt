import re
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintC1805Fixer(PylintFixer):
    '''
    规则说明: 判断列表是否未空,不能用列表长度为0判断,使用逻辑表达式即可
    '''

    def __init__(self):
        super().__init__('C1805', True)

    def fix_compare_node(self, compare_node, fixstr):
        if compare_node.ops and compare_node.ops[0] and fixstr.find('len(') != -1:
            repname = re.search(r"len\((.*)\)", fixstr).groups()[0]
            if not self.extract_node_with_text(repname):
                return False
            if compare_node.ops[0][0] == '==':
                self.fix_node_text(compare_node, f'not {repname}')
                return True
            if compare_node.ops[0][0] == '!=':
                self.fix_node_text(compare_node, f'{repname}')
                return True
        return False

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg, use_column=True)
        if not node:
            return False
        res = re.search(
            r'"(.*)" can be simplified to "(.*)", if it is strictly an int, as 0 is falsey \(use-implicit-booleaness-not-comparison-to-zero\)',
            msg.msg
        )
        nodestr = res.groups()[1]
        pnode = node.parent
        if isinstance(pnode, nodes.Compare):
            return self.fix_compare_node(pnode, nodestr)
        if isinstance(node, nodes.Name) and node.name == 'len' and (
            isinstance(pnode.parent, nodes.Compare)
        ):
            return self.fix_compare_node(pnode.parent, nodestr)
        return False
