import abc
import os
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp.python.parser.exceptions import CodeSyntaxError
from novalapp import get_app
from novalapp import constants
from novalapp.util import utils, strutils
from novalapp.widgets import simpledialog
from .configkeys import TOOL_RULES_AUTOFIX_KEY, STANDARDIZE_MODULE_NAME_STYLE_KEY
from .codeutils import FixRange, get_node_range, get_add_range, ImportNodes
from .exceptions import FixfileError


class BaseFixer(abc.ABC):
    """description of class"""

    def __init__(self, ruleid, toolname, autofix=False, open_file=True):
        self._ruleid = ruleid
        self._toolname = toolname
        autofix_key = TOOL_RULES_AUTOFIX_KEY % (toolname, ruleid)
        self._autofix = bool(utils.profile_get_int(autofix_key, autofix))
        self._openfile = open_file
        self.fix_tool = None
        self.is_autofix_msg = False
        self._textview = None
        self._textctrl = None

    @property
    def textview(self):
        return self._textview

    @property
    def textctrl(self):
        return self._textctrl

    @property
    def ruleid(self):
        return self._ruleid

    @property
    def toolname(self):
        return self._toolname

    @property
    def openfile(self):
        return self._openfile

    @openfile.setter
    def openfile(self, isopen):
        self._openfile = isopen

    @property
    def autofix(self):
        return self._autofix

    @autofix.setter
    def autofix(self, value):
        self._autofix = value

    @staticmethod
    def is_file_rename_or_removed(filepath):
        fix_module_name = utils.profile_get_int(STANDARDIZE_MODULE_NAME_STYLE_KEY, False)
        if fix_module_name and not os.path.exists(filepath):
            utils.get_logger().warning(
                "file %s is renamed or removed when check result",
                filepath
            )
            return True
        return False

    def get_msg_line_text(self, msg, textctrl=None):
        if textctrl is None:
            return self._textctrl.get_line_text(msg.line - 1)
        return textctrl.get_line_text(msg.line - 1)

    def set_textview(self, textview):
        self._textview = textview
        self._textctrl = self._textview.GetCtrl()

    def open_doc_file(self, doc, msg, is_auto_fix=False):
        del doc
        filepath = msg.filepath
        if self.is_file_rename_or_removed(filepath):
            return None, None
        if is_auto_fix:
            filedoc = get_app().GetDocumentManager().GetDocument(filepath)
            if filedoc is None:
                fileview = get_app().GotoView(
                    filepath,
                    lineNum=msg.line,
                    colno=msg.column,
                    trace_track=False
                )
            else:
                fileview = filedoc.GetFirstView()
                filedoc.reload()
            self.set_textview(fileview)
        else:
            fileview = get_app().GotoView(
                filepath,
                lineNum=msg.line,
                colno=msg.column,
                trace_track=False
            )
            self.set_textview(fileview)
        if fileview is None:
            return None, None
        textctrl = fileview.GetCtrl()
        return fileview, textctrl

    @abc.abstractmethod
    def fix_message(self, doc, msg, **kwargs):
        raise NotImplementedError('You must implemented it in derived class')

    def auto_fix_msg(self, doc, msg):
        textview = None
        if self._openfile:
            if not self.autofix:
                utils.get_logger().warning(
                    "rule %s in tool %s could not autofix code message", msg.ruleid, self.toolname)
                return textview, False
            textview = self.open_doc_file(doc, msg, is_auto_fix=True)[0]
            if textview is None:
                utils.get_logger().error("open document file %s error", msg.filepath)
                return textview, False
        self.is_autofix_msg = True
        result: bool = self.fix_message(doc, msg)
        utils.get_logger().info(
            'fix msgid:%s in line %d, column %d of tool %s in filename %s,result:%s',
            msg.ruleid,
            msg.line,
            msg.column,
            msg.toolname,
            msg.filepath,
            strutils.bool_to_str(result)
        )
        assert isinstance(result, bool), 'fix result type is not bool:%s' % result
        if textview is not None:
            textdoc = textview.GetDocument()
            textdoc.Save()
        self.is_autofix_msg = False
        return textview, result

    def replace_line_text(self, line, replace_line_text):
        fix_range = FixRange(line)
        fix_range.replace_line(self._textview, replace_line_text)

    def replace_range_text(
        self,
        start_line,
        replace_text,
        start_col=None,
        end_line=None,
        end_col=None
    ):
        fixrange = FixRange(start_line, start_col, end_line, end_col)
        fixrange.replace_with_text(self._textview, replace_text)

    def add_range_text(self, line, col, add_text, end=False):
        add_range = get_add_range(line, col)
        add_range.add_text(self._textview, add_text, end)

    def ask_input_string(self, title, label, initialvalue=None):
        ok, newname = simpledialog.askstring(
            title,
            label,
            initialvalue=initialvalue,
            master=self._textctrl
        )
        return ok, newname

    def ask_input_list(self, title, label, choices, selection=-1):
        sel = simpledialog.asklist(
            title,
            label,
            choices,
            selection=selection,
            master=self._textctrl
        )
        return sel

    def delete_text_line(self, lineno):
        self._textview.delete_line(lineno)

    def get_line_text(self, lineno):
        return self._textctrl.get_line_text(lineno)

    def get_linetext_len(self, lineno):
        linetext = self.get_line_text(lineno)
        return len(self._textctrl._encodeString(linetext))

    def do_rstrip_line(self, line):
        '''
        清除单行尾的空白字符
        '''
        self._textview.do_rstrip_line(line)

    def reload_text_doc(self):
        self._textview.GetDocument().reload()

    def is_text_modified(self):
        return self._textview.IsModified()


def fix_code_file_msg(func):
    def wrapper(self, *args):
        textview, textctrl = self.open_doc_file(*args)
        if textview is None:
            utils.get_logger().error(
                "open document file %s error", args[1].filepath)
            return False
        return func(self, *args, **{'textview': textview, 'textctrl': textctrl})
    return wrapper


class BasePythonFixer(BaseFixer):
    ''''''

    @staticmethod
    def get_node_line_text(node, textctrl):
        return textctrl.get_line_text(node.line - 1)

    def is_comment_line(self, line):
        line_text = self._textctrl.get_line_text(line)
        if line_text.lstrip().startswith('#'):
            return True
        return False

    def get_scope_range_texts(self, scope):
        '''获取函数起使至结束行的文本范围信息,同时包含函数上方的注释信息'''
        line_range_texts = []
        top_comment_lines = self.get_function_top_comment_lines(scope)
        if top_comment_lines:
            for top_comment_line in top_comment_lines[::-1]:
                line_range_texts.append(self.get_line_text(top_comment_line))
        for i in range(scope.lineno - 1, scope.end_lineno):
            line_range_texts.append(self.get_line_text(i))
        return constants.LF.join(line_range_texts)

    def get_function_top_comment_lines(self, funcnode):
        '''获取函数上方的注释信息'''
        top_comment_lines = []
        lineno = funcnode.lineno - 1
        while lineno >= 0:
            lineno -= 1
            if lineno >= 0 and self.is_comment_line(lineno):
                top_comment_lines.append(lineno)
            else:
                break
        return top_comment_lines

    def load_module(self, textview, filepath, reload=False):
        if textview.ModuleAnalyzer.Module is None or reload:
            textview.ModuleAnalyzer.parse_module(filepath)
            if textview.ModuleAnalyzer.Module is None:
                raise CodeSyntaxError(textview.ModuleAnalyzer.SyntaxError)

    def find_msg_node(self, textview, msg, use_column=False):
        self.load_msg_module(msg)
        line = msg.line
        scope = ScopeFinder(self.get_module()).find_scope(line)
        if use_column:
            node = self._textview.ModuleAnalyzer.find_line_col_node(line, msg.column, scope)
        else:
            node = self._textview.ModuleAnalyzer.find_line_node(line, scope)
        return node

    def auto_fix_msg(self, doc, msg):
        textview, result = super().auto_fix_msg(doc, msg)
        # 告警修复成功,表示文件内容有变动, 需要重新解析并加载语法树
        if result and textview:
            # 重新解析并加载语法树
            utils.get_logger().info(
                "file %s parse and reload ast tree again",
                msg.filepath
            )
            try:
                self.load_module(textview, msg.filepath, reload=True)
            except CodeSyntaxError as ex:
                utils.get_logger().error(
                    "fix message file %s may occur syntax eror:%s on rule %s of tool %s",
                    msg.filepath,
                    textview.ModuleAnalyzer.SyntaxError,
                    msg.ruleid,
                    msg.toolname
                )
                raise FixfileError(f'Fix file {msg.filepath} Error:{textview.ModuleAnalyzer.SyntaxError}') from ex
        return textview, result

    def get_shebang_encoding_line(self):
        return self._textview.get_shebang_encoding_line()

    def fix_node_text(self, node, fixstr):
        fixrange = get_node_range(node)
        fixrange.replace_with_text(self._textview, fixstr)

    def get_import_nodes_visitor(self):
        return ImportNodes(self._textview.ModuleAnalyzer.Module, self._textview)

    def load_msg_module(self, msg):
        self.load_module(self._textview, msg.filepath)

    def get_module(self):
        module = self._textview.ModuleAnalyzer.Module
        return module

    def insert_comment_template(self):
        self._textview.InsertCommentTemplate()

    def iter_scope_childs(self, scope):
        return self._textview.ModuleAnalyzer.iter_scope_children(scope)

    def find_node_on_line(self, line):
        return self._textview.ModuleAnalyzer.find_line_node(
            line)

    def delete_node(self, node):
        self.fix_node_text(node, "")

    def insert_declare_encoding(self):
        self._textview.insert_declare_encoding(prompt=False)
