import os
import re
from astroid import nodes
from novalapp.widgets import simpledialog
from novalapp.python.parser.define import SELF_ARG_NAME, CLASS_INIT_METHOD
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp import _
from novalapp.lib.pyqt import QRadioButton
from .e0601 import PylintE0601Fixer
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import get_add_range, FixNode
from ...multifixer import MultiOptionFixer


class AttributeInitDialog(simpledialog.SingleChoiceDialog):
    def __init__(self, title, descrption, choices, selection, master):
        super().__init__(
            title,
            descrption,
            choices,
            selection,
            master
        )
        self.rb_remove_attr = QRadioButton(_('Remove attribute node'))
        self.layout.insertWidget(2, self.rb_remove_attr)


class PylintW0201Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:在__init__方法外初始化类属性
    '''

    def __init__(self):
        super().__init__('W0201', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Init self attribute name',
            init_options=PylintE0601Fixer.get_init_values().values()
        )
        self.remove_attr = False

    @staticmethod
    def get_class_func(funcname, classnode):
        for childnode in classnode.body:
            if isinstance(childnode, nodes.FunctionDef) and childnode.name == funcname:
                return childnode
        return None

    def get_selection(self, text_ctrl):
        if self.is_autofix_msg:
            return
        choices = self._options
        dlg = AttributeInitDialog(
            self.title,
            self.description,
            choices,
            selection=self.selection,
            master=text_ctrl
        )
        dlg.exec_()
        self._sel = dlg.selection
        self.remove_attr = dlg.rb_remove_attr.isChecked()

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg, use_column=True)
        res = re.search(
            r"Attribute '(.*)' defined outside __init__ \(attribute-defined-outside-init\)",
            msg.msg
        )
        classnode = ScopeFinder(textview.ModuleAnalyzer.Module).get_class_scope(node)
        if not node or not res or not classnode:
            return False
        attrname = res.groups()[0]
        if isinstance(node, nodes.Name) and node.name == SELF_ARG_NAME and (
            isinstance(node.parent, nodes.AssignAttr) and attrname == node.parent.attrname
        ):
            init_method_node = self.get_class_func(CLASS_INIT_METHOD, classnode)
            if init_method_node is None:
                return False
            descrption = "Please choose attribute '%s' one initial value" % attrname
            self.set_description(descrption)
            self.get_selection(text_ctrl)
            init_values = PylintE0601Fixer.get_init_values()
            if self.selection == self.INVAID_SEL_INDEX:
                return False
            if self.remove_attr:
                fixvalue = FixNode(node.parent.parent, textview)
                fixvalue.replace_node_with_text("")
            first_body = init_method_node.body[0]
            insert_line = first_body.lineno
            if self.is_init_call_node(first_body):
                insert_line += 1
            blanks = first_body.col_offset * ' '
            add_range = get_add_range(insert_line, 0)
            init_atr_value = list(init_values.keys())[self.selection]
            add_range.add_text(
                textview,
                blanks + f"{node.parent.as_string()}={init_atr_value}" + os.linesep
            )
            return True
        return False
