import re
from novalapp.python.parser.define import STATIC_METHOD_NAME
from astroid import nodes
from ....pylint_fix import PylintFixer
from ....multifixer import MultiOptionFixer


class PylintW0211Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:静态方法不能以self作为第一个参数名
    '''

    def __init__(self):
        super().__init__('W0211', True)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Fix staticmethod',
            descr="Please choose one fix option",
            init_options=['Remove self argument', 'Remove staticmethod decorator']
        )

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        pnode = node.parent
        if isinstance(node, nodes.Name) and isinstance(pnode, nodes.FunctionDef) and STATIC_METHOD_NAME == pnode.type:
            if pnode.args.args:
                first_arg = pnode.args.args[0]
                if isinstance(first_arg, nodes.AssignName):
                    if first_arg.name == 'self':
                        self.get_selection()
                        if not self.selection:
                            replace_argstr = re.sub(r"self\s*,*", "", pnode.args.as_string()).strip()
                            self.fix_funcdef_args(pnode, replace_argstr)
                        elif self.selection == 1:
                            decorators = pnode.decorators.nodes
                            self.delete_node(decorators[0], delete_node_line=True)
                        return True
                return False
        return False
