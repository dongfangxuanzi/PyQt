import re
from novalapp.python.parser.define import CLASS_METHOD_NAME
from astroid import nodes
from ....pylint_fix import PylintFixer
from ....multifixer import MultiOptionFixer


class PylintC0202Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:类方法必须用cls作为第一个参数名
    '''

    def __init__(self):
        super().__init__('C0202', True)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Fix cls argument',
            descr="Please choose one fix option",
            init_options=['Remove classmethod decorator', 'Convert self argument to cls']
        )

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        res = re.search(
            r"Class method (.*) should have 'cls' as first argument \(bad-classmethod-argument\)",
            msg.msg
        )
        nodename = res.groups()[0]
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and nodename == node.name:
            if CLASS_METHOD_NAME == node.parent.type:
                start_line = node.lineno
                if node.parent.args.args:
                    first_arg = node.parent.args.args[0]
                    if isinstance(first_arg, nodes.AssignName):
                        if first_arg.name == 'cls':
                            return False
                        self.get_selection()
                        if first_arg.name == 'self':
                            if self.selection == 1:
                                self.fix_node_text(first_arg, 'cls')
                            elif not self.selection:
                                decorators = node.parent.decorators.nodes
                                self.delete_node(decorators[0], delete_node_line=True)
                            return True
                    start_column = first_arg.col_offset
                    self.add_range_text(start_line, start_column, "cls,")
                    return True
        return False
