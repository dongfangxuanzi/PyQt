# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/PyCQA/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/PyCQA/pylint/blob/main/CONTRIBUTORS.txt
from collections import defaultdict
from collections.abc import Sequence
from typing import Callable

from astroid import nodes

# Callable parameter type NodeNG not completely correct.
# Due to contravariance of Callable parameter types,
# it should be a Union of all NodeNG subclasses.
# However, since the methods are only retrieved with
# getattr(checker, member) and thus are inferred as Any,
# NodeNG will work too.
AstCallback = Callable[[nodes.NodeNG], None]


class ASTWalker:
    def __init__(self) -> None:
        # callbacks per node types
        self.nbstatements = 0
        self.visit_events: defaultdict[str,
                                       list[AstCallback]] = defaultdict(list)
        self.leave_events: defaultdict[str, list[AstCallback]] = defaultdict(list)
        self.exception_msg = False

    def add_visitor(self, visitor: Callable) -> None:
        """Walk to the checker's dir and collect visit and leave methods."""
        visits = self.visit_events
        leaves = self.leave_events
        member = visitor.__name__
        cid = member[6:]
        if cid == "default":
            return
        if member.startswith("visit_"):
            visits[cid].append(visitor)
        elif member.startswith("leave_"):
            leaves[cid].append(visitor)

    def walk(self, astroid: nodes.NodeNG) -> None:
        """Call visit events of astroid checkers for the given node, recurse on
        its children, then leave events.
        """
        cid = astroid.__class__.__name__.lower()

        # Detect if the node is a new name for a deprecated alias.
        # In this case, favour the methods for the deprecated
        # alias if any,  in order to maintain backwards
        # compatibility.
        visit_events: Sequence[AstCallback] = self.visit_events.get(cid, ())
        leave_events: Sequence[AstCallback] = self.leave_events.get(cid, ())

        if astroid.is_statement:
            self.nbstatements += 1
        # generate events for this node on each checker
        for callback in visit_events:
            callback(astroid)
        # recurse on children
        if hasattr(astroid, 'body'):
            for child in astroid.body:
                self.walk(child)

        for callback in leave_events:
            callback(astroid)
