# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""Find in files viewer implementation"""
import logging
from uuid import uuid1
from ... import get_app, newid, _, menuitems, globalkeys
from ...enums import MenuItemPosition
from ...util.timeutils import get_locale_datetime
from ...lib.pyqt import (Qt, QSize, QToolBar, QBrush, QHBoxLayout, QWidget, QAction,
                         QLabel, QFrame, QTreeWidget, QApplication, QTreeWidgetItem,
                         QHeaderView, QPalette, QColor, QStackedWidget, QSizePolicy,
                         QVBoxLayout, QCursor)
from ...qtimage import load_icon
from ...widgets.itemdelegates import NoOutlineHeightDelegate
from ...widgets.spacers import ToolBarExpandingSpacer
from ...widgets.labels import HeaderLabel, HeaderFitLabel
from .findsymboldialog import FindSymbolDialog
from .matchtooltip import MatchTooltip
from .symbols import Symbol
from .occurrencesprovider import OccurrencesSearchProvider
from .findsymbolprovider import PythonsymbolsSearchProvider
from .findoccurrences import FindOccurrences
from ..parser.exceptions import CodeSyntaxError
from ..parser.define import SELF_ARG_NAME
from ...util import utils, strutils
from .replacesymbol.replacesymboldialog import ReplaceSymbolDialog
from .replacesymbol.replacesymbolprovider import ReplaceSymbolsProvider
from ...widgets import simpledialog
from ...bars.menubar import NewQMenu
from .replacesymbol.replacesupport import ItemtoReplaceIn

SYMBOL_VIEW_NAME = "SymbolResults"
# Global tooltip instance
searchTooltip = MatchTooltip()


def hideSearchTooltip():
    """Hides the search results tooltip"""
    searchTooltip.tooltipTimer.stop()
    searchTooltip.hide()


class MatchTableItem(QTreeWidgetItem):
    """Match item"""

    def __init__(self, items, tooltip, icon):
        items.insert(1, '')
        QTreeWidgetItem.__init__(self, items)
        self.__intColumn = 0
        self.__tooltip = tooltip
        self.__fileModified = False
        self.setIcon(1, load_icon('findtooltip.png'))
        self.setIcon(0, icon)

    def __lt__(self, other):
        """Integer or string custom sorting"""
        sortColumn = self.treeWidget().sortColumn()
        if sortColumn == self.__intColumn:
            return int(self.text(sortColumn)) < \
                int(other.text(sortColumn))
        return self.text(sortColumn) < other.text(sortColumn)

    def setModified(self, status):
        """Sets the modified flag"""
        self.__fileModified = status

    def __updateTooltipProperties(self):
        """Updates all the tooltip properties"""
        searchTooltip.setItem(self)
        searchTooltip.setModified(self.__fileModified)
        searchTooltip.setText(self.__tooltip)

        filename = self.parent().data(0, Qt.DisplayRole)
        linenumber = self.data(0, Qt.DisplayRole)
        searchTooltip.setLocation(" " + filename + ":" + linenumber)

    def itemEntered(self):
        """Triggered when mouse cursor entered the match"""
        if self.__tooltip:
            searchTooltip.setInside(True)
            if searchTooltip.isVisible():
                hideSearchTooltip()
                self.__updateTooltipProperties()
                searchTooltip.show()
            else:
                searchTooltip.startShowTimer()
                self.__updateTooltipProperties()


class MatchTableFileItem(QTreeWidgetItem):
    """Match file item"""

    def __init__(self, items):
        QTreeWidgetItem.__init__(self, items)


class SymbolSearchResultsTreeWidget(QTreeWidget):
    """Tree widget derivation to intercept the fact that the mouse cursor
       left the widget
    """
    lastEntered = None

    def __init__(self, parent=None):
        QTreeWidget.__init__(self, parent)
        self.setAlternatingRowColors(True)
        self.setRootIsDecorated(True)
        self.setItemsExpandable(True)
        self.setUniformRowHeights(True)
        self.setItemDelegate(NoOutlineHeightDelegate(4))
        header_labels = ['File name / line', '', 'Text']
        self.setHeaderLabels(header_labels)
        self.setMouseTracking(True)
        self.resetCache()
        self.itemActivated.connect(self.__resultActivated)
        self.itemClicked.connect(self.__resultClicked)
        self.itemEntered.connect(self.__itemEntered)

    def resetCache(self):
        """Resets the caches"""
        self.__fNameCache = set()

    def buildCache(self):
        """Builds the caches"""
        index = self.topLevelItemCount() - 1
        while index >= 0:
            item = self.topLevelItem(index)
            fileName = item.data(0, Qt.DisplayRole)
            self.__fNameCache.add(fileName)
            # self.__uuidCache.add(str(item.uuid))
            index -= 1

    def leaveEvent(self, event):
        """Triggered when the cursor leaves the find results tree"""
        searchTooltip.setInside(False)

        QApplication.processEvents()
        hideSearchTooltip()
        QTreeWidget.leaveEvent(self, event)

    def onBufferModified(self, doc, editor_view):
        """Triggered when a buffer is modified"""
        filename = editor_view.GetDocument().GetFilename()
        if filename in self.__fNameCache:
            self.__markByFileName(filename)
            self.__fNameCache.remove(filename)

    def __markByFileName(self, fileName):
        """Marks an item modified basing on the file name"""
        index = self.topLevelItemCount() - 1
        while index >= 0:
            item = self.topLevelItem(index)
            if item.data(0, Qt.DisplayRole) == fileName:
                self.__markItem(item)
                break
            index -= 1

    @staticmethod
    def __markItem(item):
        """Marks a single item modified"""
        brush = QBrush(QColor(255, 227, 227))
        item.setBackground(0, brush)
        item.setBackground(1, brush)
        item.setBackground(2, brush)
        childIndex = item.childCount() - 1
        while childIndex >= 0:
            childItem = item.child(childIndex)
            childItem.setModified(True)
            if searchTooltip.item == childItem:
                searchTooltip.setModified(True)
            childIndex -= 1

    @staticmethod
    def __resultActivated(item, column):
        """Handles the double click (or Enter) on a match"""
        del column  # unused argument
        if isinstance(item, MatchTableItem):
            try:
                fileName = item.parent().data(0, Qt.DisplayRole)
                lineNumber = int(item.data(0, Qt.DisplayRole))
                get_app().GotoView(fileName, lineNum=lineNumber)
                hideSearchTooltip()
            except Exception as exc:
                logging.error(str(exc))

    @staticmethod
    def __resultClicked(item, column):
        """Handles the single click"""
        del item    # unused argument
        del column  # unused argument
        hideSearchTooltip()

    def __itemEntered(self, item, column):
        """Triggered when the mouse cursor entered a row"""
        if not isinstance(item, MatchTableItem):
            self.lastEntered = item
            hideSearchTooltip()
            return

        if column != 1:
            # Show the tooltip only for the column with results
            self.lastEntered = None
            hideSearchTooltip()
            return

        # Memorize the row height for proper tooltip displaying later
        searchTooltip.setCellHeight(self.visualItemRect(item).height())

        if self.lastEntered != item or not searchTooltip.isInside():
            item.itemEntered()
            self.lastEntered = item


class SymbolResultsViewWidget(QWidget):
    """A header plus a tree widget"""

    REPLACE_MATCH_ID = newid()
    REPLACE_MODULE_MATCH_ID = newid()
    REPLACE_MODULES_MATCH_ID = newid()

    def __init__(
        self,
        providerId,
        results,
        parameter,
        searchId,
        parent,
        is_replace=False
    ):
        QWidget.__init__(self, parent)
        self.__providerId = providerId
        self.__parameter = parameter
        self.searchId = searchId
        self.selectedItem = None
        self.__removeItemButton = parent.removeItemButton

        self._menu = None
        self.resultsTree = SymbolSearchResultsTreeWidget()
        self.resultsTree.itemSelectionChanged.connect(
            self.__selectionChanged)
        if self.__providerId != ReplaceSymbolsProvider.getName():
            self.resultsTree.setContextMenuPolicy(Qt.CustomContextMenu)
            self.resultsTree.customContextMenuRequested.connect(self.on_right_click)

        self.indicator = HeaderLabel()
        self.providerLabel = HeaderLabel(
            get_app().search_providers[providerId].getName()
        )
        self.providerLabel.setToolTip(_('Results provider'))
        self.timestampLabel = HeaderLabel()
        self.timestampLabel.setToolTip(_('Search timestamp'))

        self.__label_layout = QHBoxLayout()
        self.__label_layout.setContentsMargins(0, 0, 0, 0)
        self.__label_layout.setSpacing(4)
        self.__label_layout.addWidget(self.indicator)
        self.__label_layout.addWidget(self.providerLabel)
        self.add_headers(providerId)
        self.__label_layout.addWidget(self.timestampLabel)
        self.__vlayout = QVBoxLayout()
        self.__vlayout.setContentsMargins(0, 0, 0, 0)
        self.__vlayout.setSpacing(4)
        self.__vlayout.addLayout(self.__label_layout)
        self.__vlayout.addWidget(self.resultsTree)

        self.setLayout(self.__vlayout)
        self._classes_icon = load_icon('python/symbol/classes.png')
        self._funcs_icon = load_icon('python/symbol/funcs.png')
        self._imports_icon = load_icon('python/symbol/imports.png')
        self._calls_icon = load_icon('python/symbol/call.png')
        self._vars_icon = load_icon('python/symbol/var.png')
        self._others_icon = load_icon('python/symbol/others.png')
        if is_replace:
            self.populate_replaces(results)
        else:
            self.populate(results)

    def on_right_click(self):
        '''
        右键弹出的菜单
        '''
        if self.selectedItem is None or isinstance(
            self.selectedItem, MatchTableFileItem
        ):
            return
        if self._menu is None:
            self._menu = NewQMenu(self)
            self._menu.Append(
                self.REPLACE_MATCH_ID,
                _("Replace"),
                handler=self.replace_match
            )
            self._menu.Append(
                self.REPLACE_MODULE_MATCH_ID,
                _("Replace Module"),
                handler=self.replace_module_match
            )
            self._menu.Append(
                self.REPLACE_MODULES_MATCH_ID,
                _("Replace All Modules"),
                handler=self.replace_all_modules_match
            )
        self._menu.popup(QCursor.pos())

    @staticmethod
    def get_rep_str(findsymbol):
        ok, repsymbol = simpledialog.askstring(
            _("Replace Symbol"),
            _("Please input replace symbol"),
            initialvalue=findsymbol
        )
        if not ok:
            return None
        if repsymbol.strip() == findsymbol:
            return None
        return repsymbol.strip()

    def replace_match(self):
        repsymbol = self.get_rep_str(self.__parameter.findstr)
        if strutils.is_none_empty(repsymbol):
            return
        pitem = self.selectedItem.parent()
        match = self.selectedItem.data(0, Qt.UserRole)
        filename = pitem.text(0)
        fileview = self.get_file_view(filename)
        repitem = ItemtoReplaceIn(filename, repsymbol, fileview)
        repitem.matches = [match]
        repitem.replace()

    @staticmethod
    def get_file_view(filename):
        filedoc = get_app().GetDocumentManager().GetDocument(filename)
        fileview = None
        if filedoc:
            fileview = filedoc.GetFirstView()
        return fileview

    def replace_module_match(self):
        repsymbol = self.get_rep_str(self.__parameter.findstr)
        if strutils.is_none_empty(repsymbol):
            return
        pitem = self.selectedItem.parent()
        self.replace_module_item(pitem, repsymbol)

    def replace_module_item(self, fileitem, repsymbol):
        filename = fileitem.text(0)
        fileview = self.get_file_view(filename)
        repitem = ItemtoReplaceIn(filename, repsymbol, fileview)
        for childindex in range(fileitem.childCount()):
            childitem = fileitem.child(childindex)
            match = childitem.data(0, Qt.UserRole)
            repitem.matches.append(match)
        repitem.replace()

    def replace_all_modules_match(self):
        repsymbol = self.get_rep_str(self.__parameter.findstr)
        if strutils.is_none_empty(repsymbol):
            return
        filecount = self.resultsTree.topLevelItemCount()
        for index in range(filecount):
            toplevelitem = self.resultsTree.topLevelItem(index)
            self.replace_module_item(toplevelitem)

    def add_headers(self, provider_id):
        def add_header(item):
            paramlabel = HeaderFitLabel()
            paramlabel.setText('%s: %s' % item)
            paramlabel.setAlignment(Qt.AlignLeft)
            paramlabel.setSizePolicy(QSizePolicy.Expanding,
                                     QSizePolicy.Fixed)
            self.__label_layout.addWidget(paramlabel)
        # There could be many labels with the search parameters
        for item in get_app().search_providers[provider_id].serialize(self.__parameter):
            add_header(item)

    def get_symbol_type_icon(self, symbol_type):
        if symbol_type == Symbol.CLASSES:
            return self._classes_icon
        if symbol_type == Symbol.FUNCTIONS:
            return self._funcs_icon
        if symbol_type == Symbol.IMPORTS:
            return self._imports_icon
        if symbol_type == Symbol.CALLS:
            return self._calls_icon
        if symbol_type == Symbol.VARS:
            return self._vars_icon
        return self._others_icon

    def init_results(self):
        self.clear()
        self.timestampLabel.setText(get_locale_datetime())

    def build_module_item(self, columns, item):
        file_item = MatchTableFileItem(columns)
        icon = load_icon("python/symbol/python_module.png")
        file_item.setIcon(0, icon)
        if item.tooltip != "":
            file_item.setToolTip(0, item.tooltip)
        self.resultsTree.addTopLevelItem(file_item)
        return file_item

    def build_match_item(self, columns, match, fileitem):
        matchitem = MatchTableItem(
            columns,
            match.tooltip,
            self.get_symbol_type_icon(match.symbol_type)
        )
        item_type = FindSymbolDialog.SYMBOL_NAME_LIST[
            match.symbol_type.value
        ]
        matchitem.setToolTip(0, item_type)
        matchitem.setData(0, Qt.UserRole, match)
        fileitem.addChild(matchitem)

    def populate_replaces(self, results):
        """Populates data in the tree widget"""
        self.init_results()
        # Add the complete information
        total_replaced = 0
        for item in results:
            replaced = len(item.replaces)
            total_replaced += replaced
            if replaced == 1:
                replacetext = " (1 replace)"
            else:
                replacetext = " (" + str(replaced) + " replaces)"
            columns = [item.fileName, '', replacetext]
            file_item = self.build_module_item(columns, item)
            # Matches
            for match in item.replaces:
                columns = [str(match.line), match.text]
                self.build_match_item(columns, match, file_item)
            file_item.setExpanded(True)

        # Update the header with the total number of matches
        header_labels = ["File name / line (total files: " +
                         str(len(results)) + ")",
                         '',
                         "Text (total replaces: " + str(total_replaced) + ")"]
        self.resultsTree.setHeaderLabels(header_labels)
        self.finish_results()

    def populate(self, results):
        """Populates data in the tree widget"""
        self.init_results()
        # Add the complete information
        total_matched = 0
        for item in results:
            matched = len(item.matches)
            total_matched += matched
            if matched == 1:
                matchtext = " (1 match)"
            else:
                matchtext = " (" + str(matched) + " matches)"
            columns = [item.fileName, '', matchtext]
            file_item = self.build_module_item(columns, item)
            # Matches
            for match in item.matches:
                columns = [str(match.line), match.text]
                self.build_match_item(columns, match, file_item)
            file_item.setExpanded(True)

        # Update the header with the total number of matches
        header_labels = ["File name / line (total files: " +
                         str(len(results)) + ")",
                         '',
                         "Text (total matches: " + str(total_matched) + ")"]
        self.resultsTree.setHeaderLabels(header_labels)
        self.finish_results()

    def finish_results(self):
        # Resizing the table
        self.resultsTree.header().resizeSections(QHeaderView.ResizeToContents)
        self.resultsTree.header().setSectionResizeMode(1, QHeaderView.Fixed)
        self.resultsTree.header().resizeSection(1, 30)
        self.resultsTree.buildCache()

    def updateIndicator(self, own, total):
        """Updates the indicator label and tooltip"""
        self.indicator.setText('%d of %d' % (own, total))
        self.indicator.setToolTip(_('Search result %d out of %d') %
                                  (own, total))

    def clear(self):
        """Clean up"""
        self.resultsTree.resetCache()
        self.resultsTree.clear()
        self.selectedItem = None

    def __selectionChanged(self):
        """Selection of an item changed"""
        selected = list(self.resultsTree.selectedItems())
        if selected:
            self.selectedItem = selected[0]
            self.__removeItemButton.setEnabled(True)
        else:
            self.selectedItem = None
            self.__removeItemButton.setEnabled(False)

    def removeSelectedItem(self):
        """Removes the selected item"""
        if self.selectedItem is None:
            return

        if isinstance(self.selectedItem, MatchTableFileItem):
            # This is a top level item
            topItemIndex = self.resultsTree.indexOfTopLevelItem(
                self.selectedItem)
            self.resultsTree.takeTopLevelItem(topItemIndex)
        else:
            # This is a file item, i.e. a child
            parentitem = self.selectedItem.parent()
            childindex = parentitem.indexOfChild(self.selectedItem)
            parentitem.takeChild(childindex)
            if parentitem.childCount() == 0:
                # The top level item needs to be deleted too
                topItemIndex = self.resultsTree.indexOfTopLevelItem(
                    parentitem)
                self.resultsTree.takeTopLevelItem(topItemIndex)

        if self.resultsTree.topLevelItemCount() > 0:
            self.__update_counters()

    def __update_counters(self):
        """Updates the counters after a match is deleted"""
        total = 0
        filecount = self.resultsTree.topLevelItemCount()
        for index in range(filecount):
            toplevel_item = self.resultsTree.topLevelItem(index)
            matchcount = toplevel_item.childCount()
            if matchcount == 1:
                matchtext = " (1 match)"
            else:
                matchtext = " (" + str(matchcount) + " matches)"
            total += matchcount
            toplevel_item.setText(2, matchtext)

        header_labels = ["File name / line (total files: " +
                         str(filecount) + ")",
                         '',
                         "Text (total matches: " + str(total) + ")"]
        self.resultsTree.setHeaderLabels(header_labels)

    def doAgain(self, resultsViewer):
        """Performs the same search again"""
        get_app().search_providers[self.__providerId].searchAgain(
            self.searchId, self.__parameter, resultsViewer)

    def canDoAgain(self):
        """Tells if the do again functionality is available"""
        if self.__providerId in [
            OccurrencesSearchProvider.getName(),
            ReplaceSymbolsProvider.getName()
        ]:
            # There are too many cases when it is problematic to do again
            # jedi needs to have a source code and a cursor position in it
            # however, at least following may brake the search:
            # - the buffer has been changed (could be tracked)
            # - the file was closed so there is no more editor (could be
            # reloaded)
            # - the file was changed outside of the ide (cannot be tracked)
            # - the file is changed between the ide sessions when the feature
            # of saving/restoring results is implemented (cannot be tracked)
            # So for now the redo is just disabled for this provider
            return False
        return True


class SearchSymbolResultsViewer(QWidget):
    """Search results viewer tab widget"""

    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        self.__results = QStackedWidget(self)
        self.__bufferChangeConnected = False

        # Prepare members for reuse
        self.__none_label = QLabel("\n" + _("No results available"))
        self.__none_label.setFrameShape(QFrame.StyledPanel)
        self.__none_label.setAlignment(Qt.AlignHCenter)
        self.__headerFont = self.__none_label.font()
        self.__headerFont.setPointSize(self.__headerFont.pointSize() + 4)
        self.__none_label.setFont(self.__headerFont)
        self.__none_label.setAutoFillBackground(True)
        nonelabel_palette = self.__none_label.palette()
        nonelabel_palette.setColor(QPalette.Background,
                                   get_app().skin['nolexerPaper'])
        self.__none_label.setPalette(nonelabel_palette)

        self.__create_layout(parent)
        self.__update_buttons_status()
        findsymbol_item_id = newid()
        get_app().InsertCommand(
            menuitems.ID_FINDDIR,
            findsymbol_item_id,
            _("&Edit"),
            _("&Find Symbol"),
            self.__on_find_symbol,
            image="python/symbol/symbol.ico",
            pos=MenuItemPosition.INSERT_AFTER
        )
        get_app().InsertCommand(
            findsymbol_item_id,
            newid(),
            _("&Edit"),
            _("&Replace Symbol"),
            self.__on_replace_symbol,
            image="python/symbol/replace.png",
            pos=MenuItemPosition.INSERT_AFTER
        )
        get_app().AddDefaultCommand(
            menuitems.ID_FIND_OCCURRENCES,
            _("&Edit"),
            _("Find Occurrences"),
            self.find_occurrences,
            image="python/symbol/occurrences.ico"
        )
        self.__register_search_providers()

    def find_occurrences(self):
        current_view = get_app().GetDocumentManager().GetCurrentView()
        try:
            def_word = current_view.GetCtrl().get_def_word()
        except CodeSyntaxError as ex:
            utils.get_logger().error(
                'parse code file %s syntax error:%s in func:%s with defword:%s',
                current_view.GetDocument().GetFilename(),
                str(ex),
                self.find_occurrences.__qualname__,
                current_view.GetCtrl().get_current_word()
            )
            current_view.GetCtrl().show_parser_errors_dialog(str(ex))
            return
        utils.get_logger().debug(
            "find def word is %s in current pos,line:%d,col:%d",
            def_word,
            current_view.GetCtrl().get_current_line(),
            current_view.GetCtrl().get_current_column()
        )
        if utils.profile_get_int(globalkeys.TRIM_SELF_ARG_KEY, False):
            if def_word.find(f"{SELF_ARG_NAME}.") != -1:
                def_word = def_word.replace(f"{SELF_ARG_NAME}.", "")
        finder = FindOccurrences(def_word, current_view.GetCtrl().get_current_line(plus=True))
        finder.search()
        self.showReport(
            OccurrencesSearchProvider().getName(),
            finder.search_results,
            finder.get_parameter()
        )
        get_app().MainFrame.activateBottomTab(SYMBOL_VIEW_NAME)

    def __register_search_providers(self):
        """Registers all the search providers"""
        get_app().register_search_provider(PythonsymbolsSearchProvider())
        get_app().register_search_provider(OccurrencesSearchProvider())
        get_app().register_search_provider(ReplaceSymbolsProvider())

    def __on_find_symbol(self):
        dlg = FindSymbolDialog(
            get_app().GetTopWindow(),
            self,
            get_app().MainFrame.GetNotebook().get_find_str()
        )
        dlg.exec_()
        if dlg.searchResults:
            self.__show_search_results(dlg)

    def __show_search_results(self, find_dialog):
        self.showReport(
            PythonsymbolsSearchProvider().getName(),
            find_dialog.searchResults,
            find_dialog.get_parameter()
        )
        get_app().MainFrame.activateBottomTab(SYMBOL_VIEW_NAME)

    def __show_replace_results(self, replace_dialog):
        self.showReport(
            ReplaceSymbolsProvider().getName(),
            replace_dialog.replace_results,
            replace_dialog.get_parameter(),
            is_replace=True
        )
        get_app().MainFrame.activateBottomTab(SYMBOL_VIEW_NAME)

    def __on_replace_symbol(self):
        dlg = ReplaceSymbolDialog(
            get_app().GetTopWindow(),
            self,
            get_app().MainFrame.GetNotebook().get_find_str()
        )
        dlg.exec_()
        if dlg.is_replace_symbol:
            if dlg.replace_results:
                self.__show_replace_results(dlg)
        else:
            self.__show_search_results(dlg)

    def __create_layout(self, parent):
        """Creates the toolbar and layout"""
        del parent  # unused argument

        # Buttons etc.
        self.clearButton = QAction(load_icon('trash.png'),
                                   _('Delete current results'), self)
        self.clearButton.triggered.connect(self.__clear)

        self.prevButton = QAction(load_icon('1leftarrow.png'),
                                  _('Previous results'), self)
        self.prevButton.triggered.connect(self.__previous)

        self.nextButton = QAction(load_icon('1rightarrow.png'),
                                  _('Next results'), self)
        self.nextButton.triggered.connect(self.__next)

        self.doAgainButton = QAction(load_icon('searchagain.png'),
                                     _('Do again'), self)
        self.doAgainButton.triggered.connect(self.__do_again)

        self.removeItemButton = QAction(load_icon('delitem.png'),
                                        _('Remove currently selected item (Del)'),
                                        self)
        self.removeItemButton.triggered.connect(self.__removeitem)

        # The toolbar
        self.toolbar = QToolBar(self)
        self.toolbar.setOrientation(Qt.Vertical)
        self.toolbar.setMovable(False)
        self.toolbar.setAllowedAreas(Qt.RightToolBarArea)
        self.toolbar.setIconSize(QSize(16, 16))
        self.toolbar.setFixedWidth(28)
        self.toolbar.setContentsMargins(0, 0, 0, 0)

        self.toolbar.addAction(self.prevButton)
        self.toolbar.addAction(self.nextButton)
        self.toolbar.addAction(self.doAgainButton)
        self.toolbar.addWidget(ToolBarExpandingSpacer(self.toolbar))
        self.toolbar.addAction(self.removeItemButton)
        self.toolbar.addAction(self.clearButton)

        self.__hlayout = QHBoxLayout()
        self.__hlayout.setContentsMargins(0, 0, 0, 0)
        self.__hlayout.setSpacing(0)
        self.__hlayout.addWidget(self.toolbar)
        self.__hlayout.addWidget(self.__none_label)
        self.__hlayout.addWidget(self.__results)
        self.__results.hide()

        self.setLayout(self.__hlayout)

    def __is_report_shown(self):
        """True is any of the reports is shown"""
        return self.__results.count() > 0

    def getResultsViewer(self):
        """Provides a reference to the results tree"""
        return self.__results

    def __update_buttons_status(self):
        """Updates the buttons status"""
        if self.__is_report_shown():
            index = self.__results.currentIndex()
            widget = self.__results.currentWidget()
            self.prevButton.setEnabled(index > 0)
            self.nextButton.setEnabled(index < self.__results.count() - 1)
            self.doAgainButton.setEnabled(widget.canDoAgain())
            self.removeItemButton.setEnabled(widget.selectedItem is not None)
            self.clearButton.setEnabled(True)
        else:
            self.prevButton.setEnabled(False)
            self.nextButton.setEnabled(False)
            self.doAgainButton.setEnabled(False)
            self.removeItemButton.setEnabled(False)
            self.clearButton.setEnabled(False)

    def __update_indicators(self):
        """Updates all the indicators"""
        total = self.__results.count()
        for index in range(total):
            self.__results.widget(index).updateIndicator(index + 1, total)

    def setFocus(self):
        """Overridden setFocus"""
        self.__results.setFocus()

    def __connect_buffer_change(self):
        """Connects the sigBufferChange"""
        if not self.__bufferChangeConnected:
            self.__bufferChangeConnected = True
            get_app().MainFrame.projectview.SIG_BUFFER_MODIFIED.connect(
                self.onBufferModified
            )

    def __disconnectBufferChange(self):
        """Disconnects the sigBufferModified signal"""
        if self.__bufferChangeConnected:
            self.__bufferChangeConnected = False
            get_app().MainFrame.projectview.SIG_BUFFER_MODIFIED.disconnect(
                self.onBufferModified
            )

    def onBufferModified(self, doc, editor_view):
        """Triggered when a buffer is modified"""
        for index in range(self.__results.count()):
            self.__results.widget(index).resultsTree.onBufferModified(
                doc, editor_view)

    def __previous(self):
        """Switch to the previous results"""
        if self.__is_report_shown():
            index = self.__results.currentIndex()
            if index > 0:
                self.__results.setCurrentIndex(index - 1)
                self.__update_buttons_status()

    def __next(self):
        """Switch to the next results"""
        if self.__is_report_shown():
            index = self.__results.currentIndex()
            if index < self.__results.count() - 1:
                self.__results.setCurrentIndex(index + 1)
                self.__update_buttons_status()

    def keyPressEvent(self, event):
        """Del key processing"""
        if event.key() == Qt.Key_Delete:
            event.accept()
            self.__removeitem()
        else:
            QWidget.keyPressEvent(self, event)

    def __removeitem(self):
        """Removes one entry of the search"""
        widget = self.__results.currentWidget()
        if widget.selectedItem is None:
            return

        widget.removeSelectedItem()
        if widget.resultsTree.topLevelItemCount() == 0:
            # The last result, need to remove the search result
            self.__clear()
        else:
            self.__update_buttons_status()

    def __clear(self):
        """Clears the content of the vertical layout"""
        if not self.__is_report_shown():
            return

        index = self.__results.currentIndex()
        widget = self.__results.currentWidget()
        widget.clear()

        if self.__results.count() == 1:
            self.__results.hide()
            self.__none_label.show()
            self.__disconnectBufferChange()

        self.__results.removeWidget(widget)
        widget.deleteLater()

        if self.__results.count() > 0:
            if index >= self.__results.count():
                index -= 1
            self.__results.setCurrentIndex(index)

        self.__update_buttons_status()
        self.__update_indicators()

    def __do_again(self):
        """Performs the action once again"""
        if self.__is_report_shown():
            self.__results.currentWidget().doAgain(self)

    def showReport(
        self,
        providerId,
        results,
        parameter,
        searchId=None,
        is_replace=False
    ):
        """Shows the find in files results"""
        # Memorize the screen width
        searchTooltip.setScreenWidth(get_app().desktop().screenGeometry().width())
        if searchId is None:
            resultWidget = SymbolResultsViewWidget(providerId, results,
                                                   parameter,
                                                   str(uuid1()), self, is_replace)
            index = self.__results.addWidget(resultWidget)
        else:
            # Find the widget with this searchId
            found = False
            for index in range(self.__results.count()):
                if self.__results.widget(index).searchId == searchId:
                    found = True
                    break
            if not found:
                # add as a new one
                resultWidget = ResultsViewerWidget(providerId, results,
                                                   parameters,
                                                   str(uuid1()), self)
                index = self.__results.addWidget(resultWidget)
            else:
                # Repopulate it
                widget = self.__results.widget(index)
                widget.populate(results)

        self.__results.setCurrentIndex(index)

        # Show the complete information
        self.__none_label.hide()
        self.__results.show()

        self.__update_buttons_status()
        self.__update_indicators()
        self.__connect_buffer_change()
