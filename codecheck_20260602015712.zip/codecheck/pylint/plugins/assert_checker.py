# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/PyCQA/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/PyCQA/pylint/blob/main/CONTRIBUTORS.txt
"""assert checker for Python code."""
from __future__ import annotations
import os
from typing import TYPE_CHECKING
from pylint.checkers import BaseChecker
from pylint.checkers.utils import only_required_for_messages
if TYPE_CHECKING:
    from pylint.lint import PyLinter


class AssertChecker(BaseChecker):
    name = "assert"
    msgs = {
        "W9002": (
            "Assert statement used in product code",
            "no-use-assert",
            "The assert statement is usually used in test code. Dont't use assert function in production code.",
        )
    }

    @only_required_for_messages("no-use-assert")
    def visit_assert(self, node):
        """
        Check if the assert statement is used unnecessarily.
        """
        filepath = node.root().file
        filename = os.path.basename(filepath)[0:-3]
        if filename.startswith('test_') or filename.endswith("_test"):
            return
        self.add_message("no-use-assert", node=node)


def register(linter: PyLinter) -> None:
    linter.register_checker(AssertChecker(linter))
