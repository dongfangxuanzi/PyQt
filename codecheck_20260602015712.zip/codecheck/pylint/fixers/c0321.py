'''
Name:        c0321.py
Purpose:
Author:      wukan
Created:     2026-05-14
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import get_node_range, get_node_col_offset_blanks


class PylintC0321Fixer(PylintFixer):
    '''
    规则说明: 多个语句写在一行
    '''

    def __init__(self):
        super().__init__('C0321', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg, use_column=True)
        if not node or not node.is_statement:
            return False
        prev_sibl = node.previous_sibling()
        if prev_sibl is not None:
            prev_line = prev_sibl.fromlineno
        elif isinstance(node.parent, nodes.Module):
            prev_line = 0
        else:
            prev_line = node.parent.statement().fromlineno
        line = node.fromlineno
        if prev_line == line:
            pnode = node.parent
            fix_range = get_node_range(pnode)
            nodestr = pnode.as_string()
            lines = nodestr.splitlines(keepends=True)
            for i, line in enumerate(lines[1:]):
                lines[i + 1] = get_node_col_offset_blanks(pnode) + line
            newstr = ''.join(lines)
            fix_range.replace_with_text(textview, newstr)
            return True
        return False
