from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import get_node_range


class PylintC0121Fixer(PylintFixer):
    '''
    规则说明: 使用is和None比较,而不是使用==
    '''

    def __init__(self):
        # 支持自动修复
        super().__init__('C0121', True)

    @staticmethod
    def fix_compare_node(node, textview):
        ops = node.ops
        if ops and ops[0][0] in ['==', '!=']:
            if isinstance(ops[0][1], nodes.Const) and ops[0][1].value is None:
                fix_range = get_node_range(node)
                if ops[0][0] == "==":
                    fixtext = f"{node.left.as_string()} is None"
                else:
                    fixtext = f"{node.left.as_string()} is not None"
                fix_range.replace_with_text(textview, fixtext)
                return True
            if isinstance(node.left, nodes.Const) and node.left.value is None:
                fix_range = get_node_range(node)
                if ops[0][0] == "==":
                    fixtext = f"{ops[0][1].as_string()} is None"
                else:
                    fixtext = f"{ops[0][1].as_string()} is not None"
                fix_range.replace_with_text(textview, fixtext)
                return True
        return False

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg, use_column=True)
        pnode = node.parent
        if isinstance(pnode, nodes.Compare):
            return self.fix_compare_node(pnode, textview)
        return False
