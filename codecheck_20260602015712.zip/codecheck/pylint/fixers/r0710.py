'''
Name:        r0710.py
Purpose:
Author:      wukan
Created:     2026-04-07
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import os
from astroid import nodes
import astroid
from ...basefix import fix_code_file_msg
from ...codeutils import get_add_range, FixNode
from ...pylint_fix import PylintFixer


class PylintR1710Fixer(PylintFixer):
    '''
    规则说明: 函数不能有隐式返回,确保函数所有分支均有显式返回语句,
    除非函数任何分支均没有返回值
    '''

    def __init__(self):
        super().__init__('R1710', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef):
            funcnode = node.parent
            if self.fix_implicit_returns(textview, funcnode):
                return True
            # 下面的修复操作不支持自动修复
            if self.is_autofix_msg:
                return False
            end_body = funcnode.body[-1]
            insert_line = funcnode.end_lineno
            blanks = end_body.col_offset * ' '
            add_range = get_add_range(insert_line + 1, 0)
            add_range.add_text(
                textview,
                blanks + "return None" + os.linesep
            )
            return True
        return False

    def fix_implicit_returns(self, textview, funcnode):
        return_nodes = list(
            funcnode.nodes_of_class(nodes.Return, skip_klass=nodes.FunctionDef)
        )
        explicit_returns = [retnode for retnode in return_nodes if retnode.value is not None]
        if not explicit_returns:
            return False
        if len(return_nodes) == len(explicit_returns):
            return False
        implicit_returns = [retnode for retnode in return_nodes if retnode.value is None]
        for implicit_return_node in implicit_returns:
            implicit_return_node.value = astroid.extract_node('None')
            fixnode = FixNode(implicit_return_node, textview)
            fixnode.replace_node_with_text(implicit_return_node.as_string())
        return True
