from typing import Optional, List
from novalapp.widgets import simpledialog


class MultiOptionFixer:
    """description of class"""

    INVAID_SEL_INDEX = -1

    def __init__(self, init_sel=0, title='', descr='', init_options: Optional[List]=None):
        init_options = init_options or []
        self._sel = init_sel
        self._options = init_options
        self._title = title
        self._descr = descr

    @property
    def selection(self):
        return self._sel

    @property
    def title(self):
        return self._title

    @property
    def description(self):
        return self._descr

    @property
    def options(self):
        return self._options

    @options.setter
    def options(self, options):
        self._options = options

    def set_selection(self, sel):
        self._sel = sel

    def set_title(self, title):
        self._title = title

    def set_description(self, descr):
        self._descr = descr

    def get_selection(self, text_ctrl):
        if self.is_autofix_msg:
            return
        choices = self._options
        sel = simpledialog.asklist(
            self.title,
            self.description,
            choices,
            selection=self.selection,
            master=text_ctrl
        )
        self._sel = sel
