'''
Name:        pathutils.py
Purpose:     安全处理文件目录操作的模块
Author:      wukan
Created:     2023-12-27
Copyright:   (c) wukan 2023
Licence:     <your licence>
'''
import os
import shutil
import logging
from typing import Optional
from .fileutils import open_file_directory
from .. import _
from . import exceptions

filelog = logging.getLogger(__name__)


@exceptions.catch_exception
def safe_open_file_directory(path):
    open_file_directory(path)


def delete_dir(dirpath):
    try:
        # 删除空文件夹
        os.removedirs(dirpath)
        filelog.info('Delete dir %s success', dirpath)
    except Exception as e:
        try:
            # 如果不为空文件夹,则递归删除文件夹及其内容
            shutil.rmtree(dirpath)
            filelog.info('Delete dir %s success', dirpath)
        except Exception as e:
            raise RuntimeError(_("Could not delete empty directory '%s'.\n%s") % (dirpath, e)) from e


@exceptions.catch_exception
def safe_delete_dir(dirpath):
    delete_dir(dirpath)


def get_path_dirs(path, dirs:list, filters: Optional[list]=None):
    '''
    获取路径下的子目录列表,非递归目录
    :param path: 根路径
    :type path: str
    :param dirs: 子目录列表
    :type dirs: list
    :param filters: 包含名称的目录
    :type filters: list
    :return:返回子目录列表
    '''
    if not os.path.exists(path):
        return
    for f in os.listdir(path):
        file_path = os.path.join(path, f)
        if os.path.isdir(file_path):
            if not filters:
                dirs.append(f)
            else:
                for filter_name in filters:
                    if f.find(filter_name) != -1:
                        dirs.append(f)
