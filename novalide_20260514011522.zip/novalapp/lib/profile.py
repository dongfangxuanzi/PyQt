import json
import logging
from json.decoder import JSONDecodeError
from . import get_app
logger = logging.getLogger(__name__)


class Profile:
    """description of class"""

    @staticmethod
    def get(key, value=""):
        if isinstance(value, str):
            return get_app().GetConfig().Read(key, value)
        key_value = get_app().GetConfig().Read(key, "")
        if key_value == "":
            logger.warning('key %s may not exist', key)
            return value
        try:
            return json.loads(key_value)
        except JSONDecodeError as ex:
            logger.error('json loads and get key %s value %s error:%s', key, key_value, ex)
            return value

    @staticmethod
    def get_int(key, value=-1):
        return get_app().GetConfig().ReadInt(key, value)

    @staticmethod
    def set(key, value):
        if isinstance(value, (bool, int)):
            get_app().GetConfig().WriteInt(key, value)
        else:
            if isinstance(value, str):
                get_app().GetConfig().Write(key, value)
            elif isinstance(value, (list, dict)):
                get_app().GetConfig().Write(key, json.dumps(value))
            else:
                raise RuntimeError('invalid key value `%s`' % repr(value))
