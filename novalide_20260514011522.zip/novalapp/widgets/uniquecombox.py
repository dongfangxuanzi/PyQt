from ..lib.pyqt import QComboBox


class UniqueComboBox(QComboBox):
    """combox of contain unique item text"""

    def get_items(self):
        """Provides the list of items (text only)"""
        items = []
        for index in range(self.count()):
            items.append(str(self.itemText(index)))
        return items

    def add_unique_item(self, text):
        values = self.get_items()
        if text not in values:
            self.addItem(text)
