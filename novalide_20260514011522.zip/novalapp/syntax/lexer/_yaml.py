# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _xml.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
from novalapp.lib.qsci import QsciLexerYAML
from novalapp.qtimage import load_icon
from novalapp import _
from novalapp.syntax import syndata, lang


# -----------------------------------------------------------------------------#


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Python"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_YAML")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('Yaml File')

    def GetExt(self):
        return "yml yaml"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['#']

    def GetShowName(self):
        return "Yaml"

    def GetDefaultExt(self):
        return "yml"

    def GetDocTypeName(self):
        return "Yaml Document"

    def GetViewTypeName(self):
        return _("Yaml Editor")

    def GetDocIcon(self):
        return load_icon("file/json.png")

    def GetSampleCode(self):
        return self.get_sample_file_code("json.sample")

    def get_lexer(self, parent):
        return QsciLexerYAML(parent)
