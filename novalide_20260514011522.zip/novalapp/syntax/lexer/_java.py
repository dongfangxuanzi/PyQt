# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _javascript.py
Purpose:

Author:      wukan

Created:     2019-01-17
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.qtimage import load_icon
from novalapp.lib.qsci import QsciLexerJava
# -----------------------------------------------------------------------------#
# -----------------------------------------------------------------------------#

KW_LIST = [
    'abstract',
    'continue',
    'for',
    'new',
    'switch',
    'assert',
    'default',
    'goto',
    'package',
    'synchronized',
    'boolean',
    'do',
    'if',
    'private',
    'this',
    'break',
    'double',
    'implements',
    'protected',
    'throw',
    'byte',
    'else',
    'import',
    'public',
    'throws',
    'case',
    'enum',
    'instanceof',
    'return',
    'transient',
    'catch',
    'extends',
    'int',
    'short',
    'try',
    'char',
    'final',
    'interface',
    'static',
    'void',
    'class',
    'finally',
    'long',
    'strictfp',
    'volatile',
    'const',
    'float',
    'native',
    'super',
    'while',
    'true',
    'false',
    'null'
]

KW_LIST2 = [
    'Boolean',
    'Byte',
    'Character',
    'Class',
    'ClassLoader',
    'Compiler',
    'Double',
    'Enum',
    'Float',
    'InheritableThreadLocal',
    'Integer',
    'Long',
    'Math',
    'Number',
    'Object',
    'Package',
    'Process',
    'ProcessBuilder',
    'Runtime',
    'RuntimePermission',
    'SecurityManager',
    'Short',
    'StackTraceElement',
    'StrictMath',
    'String',
    'StringBuffer',
    'StringBuilder',
    'System',
    'Thread',
    'ThreadGroup',
    'ThreadLocal',
    'Throwable'
]


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Java"""

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_JAVA")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('Java File')

    def GetExt(self):
        return "java"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['//']

    def GetCommentPatterns(self):
        """
            js注释有2种,行注释和块注释
        """
        return [self.DefaultCommentPattern, ['/*', '*/']]

    def GetShowName(self):
        return "Java"

    def GetDefaultExt(self):
        return "java"

    def GetDocTypeName(self):
        return "Java Document"

    def GetViewTypeName(self):
        return _("Java Editor")

    def GetDocIcon(self):
        return load_icon("file/java.png")

    def get_lexer(self, parent):
        return QsciLexerJava(parent)

    def GetKeywords(self):
        return KW_LIST + KW_LIST2

    def GetSampleCode(self):
        return self.get_sample_file_code("java.sample")
