from ...findrep.optionpage import SearchTextOptionPanel
from ...lib.pyqt import QCheckBox, QGroupBox, QVBoxLayout, QRadioButton
from ... import _
from ...util import utils
from ... import globalkeys
from ..parser.define import SELF_ARG_NAME
from .findoccurrences import OccurRange


class SearchSymbolOptionPanel(SearchTextOptionPanel):

    def __init__(self, master):
        """
        Initializes the panel by adding an "Options" folder tab to the parent notebook and
        populating the panel with the generic properties of a pydocview application.
        """
        super().__init__(master)
        self.contains_function_args_checkbox = QCheckBox(
            _("Contains function or call args When Search all symbols"))
        self.layout.addWidget(self.contains_function_args_checkbox)
        self.contains_function_args_checkbox.setChecked(
            utils.profile_get_int(globalkeys.CONTAINS_FUNCTION_ARGS_KEY, False))

        self.contains_base_classes_checkbox = QCheckBox(
            _("Contains class bases When Search all symbols"))
        self.layout.addWidget(self.contains_base_classes_checkbox)
        self.contains_base_classes_checkbox.setChecked(
            utils.profile_get_int(globalkeys.CONTAINS_CLASS_BASES_KEY, False))

        self.match_case_occurrences_checkbox = QCheckBox(
            _("Word match case When find occurrences"))
        self.layout.addWidget(self.match_case_occurrences_checkbox)
        self.match_case_occurrences_checkbox.setChecked(
            utils.profile_get_int(globalkeys.MATCH_CASE_OCCURRENCES_KEY, True))

        self.trim_self_arg_checkbox = QCheckBox(
            _("Trim `%s` arg when find class property occurrences") % SELF_ARG_NAME)
        self.layout.addWidget(self.trim_self_arg_checkbox)
        self.trim_self_arg_checkbox.setChecked(
            utils.profile_get_int(globalkeys.TRIM_SELF_ARG_KEY, False))

        sbox_frame = QGroupBox(_("Occurrences Range"))
        sbox_layout = QVBoxLayout()
        self.occur_module_rg_radio = QRadioButton(_('Module'))
        sbox_layout.addWidget(self.occur_module_rg_radio)

        self.occur_class_rg_radio = QRadioButton(_('Class'))
        sbox_layout.addWidget(self.occur_class_rg_radio)

        self.occur_function_rg_radio = QRadioButton(_('Function/Method'))
        sbox_layout.addWidget(self.occur_function_rg_radio)
        sbox_frame.setLayout(sbox_layout)
        self.layout.addWidget(sbox_frame)

        search_occur_range = utils.profile_get_int(
            globalkeys.FIND_OCCURRENCES_RANGE_KEY,
            OccurRange.Module.value
        )
        if search_occur_range == OccurRange.Module.value:
            self.occur_module_rg_radio.setChecked(True)
        elif search_occur_range == OccurRange.Class.value:
            self.occur_class_rg_radio.setChecked(True)
        elif search_occur_range == OccurRange.Function.value:
            self.occur_function_rg_radio.setChecked(True)

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        super().OnOK(options_dialog)
        utils.profile_set(globalkeys.MATCH_CASE_OCCURRENCES_KEY,
                          self.match_case_occurrences_checkbox.isChecked())
        utils.profile_set(globalkeys.CONTAINS_CLASS_BASES_KEY,
                          self.contains_base_classes_checkbox.isChecked())
        utils.profile_set(globalkeys.CONTAINS_FUNCTION_ARGS_KEY,
                          self.contains_function_args_checkbox.isChecked())
        utils.profile_set(globalkeys.TRIM_SELF_ARG_KEY,
                          self.trim_self_arg_checkbox.isChecked())
        if self.occur_module_rg_radio.isChecked():
            utils.profile_set(globalkeys.FIND_OCCURRENCES_RANGE_KEY,
                              OccurRange.Module.value)
        elif self.occur_class_rg_radio.isChecked():
            utils.profile_set(globalkeys.FIND_OCCURRENCES_RANGE_KEY,
                              OccurRange.Class.value)
        elif self.occur_function_rg_radio.isChecked():
            utils.profile_set(globalkeys.FIND_OCCURRENCES_RANGE_KEY,
                              OccurRange.Function.value)
        return True
