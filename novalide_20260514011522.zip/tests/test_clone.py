import sys
from gitcli.clone import GitClone
from PyQt5.QtWidgets import *
from PyQt5 import QtWidgets
from novalapp.util import ui_utils
from novalapp.util import logger

logger.init_logging(debug=True)


class TestDlg(ui_utils.BaseModalDialog):
    def __init__(self, parent):
        super().__init__('test clone', parent)


class MainWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        # Add a title
        self.setWindowTitle("Test Clone")
        # set Vertical layout
        self.setLayout(QtWidgets.QVBoxLayout())

        find_hbox = QtWidgets.QHBoxLayout()
        self.find_indir_label = QtWidgets.QLabel("Repo addr:")
        find_hbox.addWidget(self.find_indir_label)

        # Find text field
        self.path_entry = QtWidgets.QLineEdit()
        self.path_entry.setText('https://gitee.com/wekay/NovalIDE.git')
        find_hbox.addWidget(self.path_entry)

        button = QtWidgets.QPushButton("New Clone repo")
        button.clicked.connect(self.clone)
        find_hbox.addWidget(button)
        self.layout().addLayout(find_hbox)

        self.dest_path_widget = QtWidgets.QLineEdit()
        self.dest_path_widget.setText(r'C:\dev\NovalIDE\tests')
        self.layout().addWidget(self.dest_path_widget)

    def clone(self):
        clone_repo = GitClone(self.dest_path_widget.text(), self.path_entry.text())
        # clone_repo.clone(self)
        print(clone_repo.remote_branchs())


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
