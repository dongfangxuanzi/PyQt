import argparse
import multiprocessing
from novalapp.python.interpreter.interpreter import PythonInterpreter
from novalapp.util import logger


def anaylze(
    interpreter_path,
    dbver,
    outpath,
    path_list,
    multi_process,
    check_updated=False
):
    python_interpreter = PythonInterpreter('', interpreter_path)
    python_interpreter.gen_intellisence_data(
        dbver,
        outpath,
        pathlist=path_list,
        multiprocess=multi_process,
        check_updated=check_updated
    )


if __name__ == "__main__":
    # pyinstaller打包Windows的exe文件后,多进程导致程序反复重启
    # 在if __name__ == '__main__':后,加上一句代码 multiprocessing.freeze_support() 即可
    multiprocessing.freeze_support()
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-i",
        "--interpreter",
        type=str,
        dest="interpreter_path",
        help='path of interpreter',
        required=True
    )
    parser.add_argument('--path', action='append', dest='pathlist',
                        default=[], help='extra pythonpath of interpreter')
    parser.add_argument(
        "--multiprocess",
        action='store_true',
        dest="multiprocess",
        help='use multi process to analyze interpreter code data',
        default=False
    )
    parser.add_argument(
        "--debug",
        action='store_true',
        dest="debug",
        help='show debug log of program or not',
        default=False
    )
    # 是否检查文件更新,默认不检查,检查文件更新表示文件更新时间以后同时代码文件的数据
    parser.add_argument(
        "--update",
        action='store_true',
        dest="check_updated",
        help='',
        default=False
    )

    parser.add_argument(
        "-o",
        "--out",
        type=str,
        dest="outpath",
        help='dest out path of intellisense data',
        required=True
    )
    parser.add_argument(
        "-v",
        "--dbver",
        type=str,
        dest="dbver",
        help='database version of intellisense data',
        required=True
    )
    args = parser.parse_args()
    logger.init_logging(args.debug)
    anaylze(
        args.interpreter_path,
        args.dbver,
        args.outpath,
        args.pathlist,
        args.multiprocess,
        args.check_updated
    )
