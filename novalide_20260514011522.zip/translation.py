# -*- coding: utf-8 -*-

import subprocess
import os

# -p后面第一个路径为输出翻译文件路径, 第二个路径为源文件路径
curdir = os.getcwd()
# 生成pot文件
cmd = r"C:\Users\HongYunVM\AppData\Local\Programs\Python\Python311\Scripts\pybabel.exe extract {0}/novalapp --output-file {0}/novalapp/locale/novalide.pot".format(
    curdir,)
print(cmd)
subprocess.call(cmd)

# po文件需要从pot文件更新,菜单Catalogue/Update from POT file
cmd = r'"C:\Program Files (x86)\Poedit\Poedit.exe" {0}\novalapp\locale\zh_CN.po'.format(
    curdir,)
print(cmd)
os.system(cmd)
