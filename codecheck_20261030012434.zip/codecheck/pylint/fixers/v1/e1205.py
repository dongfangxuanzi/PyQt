'''
Name:        e1205.py
Purpose:     修复%后面的格式化字符错误
Author:      wukan
Created:     2026-10-17
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from novalapp.python.parser import node_utils
from astroid import nodes
from ....multifixer import MultiOptionFixer
from ....pylint_fix import PylintFixer
from .e1200 import PylintE1200Fixer
from ....exceptions import InvalidOptionIndexError


class PylintE1205Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:日志格式化参数过多
    '''

    def __init__(self):
        super().__init__('E1205', self.FixKind.SINGLEFIX)
        MultiOptionFixer.__init__(
            self,
            title='Fix logging tool many arguments',
            descr="Please choose one deleted argument or add percent"
        )

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call):
            if node.value.args and node_utils.is_const_type(node.value.args[0], str):
                log_arg_num = len(node.value.args) - 1
                log_const_str = node.value.args[0].value
                percent_num = log_const_str.count('%')
                # 日志调用的参数格式必须大于常量参数里面%号个数
                if log_arg_num <= percent_num:
                    return False
                text_names = []
                log_args = node.value.args[1:]
                delete_flag = 'Delete '
                for argnode in log_args:
                    text_names.append(f'{delete_flag}logging arg:' + argnode.as_string())
                delete_flag_num = len(text_names)
                add_flag = 'Add '
                text_parts = re.split(r"[\s(,)=:]", log_const_str)
                start = 0
                text_poses = []
                for txt in text_parts:
                    if txt:
                        start = log_const_str.find(txt, start)
                        text_names.append(f'{add_flag}percent after:' + txt)
                        end = start + len(txt)
                        text_poses.append(end)
                        start = end
                self._options = text_names
                self.get_selection()
                seltext = self._options[self.selection]
                if seltext.find(delete_flag) != -1:
                    del node.value.args[self.selection + 1]
                    self.fix_node(node.value)
                else:
                    log_const_node_text = node.value.args[0].as_string()
                    log_format_flags = list(PylintE1200Fixer.LOGGING_FORMAT_FLAGS)
                    sel = self.ask_input_list(
                        'Use logging unsupported format',
                        'Choose one supported format',
                        log_format_flags
                    )
                    if sel == self.INVAID_SEL_INDEX:
                        raise InvalidOptionIndexError('cancel option')
                    index = 1 + text_poses[self.selection - delete_flag_num]
                    log_format = ' %' + log_format_flags[sel]
                    fix_node_text = log_const_node_text[0:index] + log_format
                    fix_node_text += log_const_node_text[index:]
                    self.fix_node_text(node.value.args[0], fix_node_text)
                return True
        return False


class PylintE1206Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:日志格式化参数缺失
    '''

    def __init__(self):
        super().__init__('E1206', self.FixKind.SINGLEFIX)
        MultiOptionFixer.__init__(
            self,
            title='Fix logging not enough arguments',
            descr="Please choose one deleted percent"
        )

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call):
            if node.value.args and node_utils.is_const_type(node.value.args[0], str):
                log_arg_num = len(node.value.args) - 1
                log_const_str = node.value.args[0].value
                percent_num = log_const_str.count('%')
                # 日志调用的参数格式必须小于常量参数里面%号个数
                if log_arg_num >= percent_num:
                    return False
                percent_names = []
                log_const_node_text = node.value.args[0].as_string()
                for i, ch in enumerate(log_const_node_text):
                    if ch == '%':
                        option_text = 'Delete logging percent:' + str(i) + ":" + "%"
                        option_text += log_const_node_text[i + 1]
                        percent_names.append(option_text)
                self._options = percent_names
                self.get_selection()
                seltext = self._options[self.selection]
                index = int(seltext.split(':')[1])
                fix_node_text = log_const_node_text[0:index] + log_const_node_text[index + 2:]
                self.fix_node_text(node.value.args[0], fix_node_text)
                return True
        return False
