from typing import cast
from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ....pylint_fix import PylintFixer
from .r1723 import PylintR1723Fixer


class PylintR1705Fixer(PylintR1723Fixer):
    '''
    规则说明:return表达式后多余的else和elif语句
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'R1705', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        else_return_msg = 'Unnecessary "else" after "return"'
        node = self.find_msg_node(msg, raise_node_exception=False)
        if not node:
            scope = ScopeFinder(self.get_module()).find_scope(msg.line)
            if isinstance(scope, nodes.Try) and msg.msg.find(else_return_msg) != -1:
                return self.delete_backtab_else_statement(scope)
            return False
        if isinstance(node.parent, nodes.If):
            scope = cast(nodes.If, node.parent)
            if msg.msg.find(else_return_msg) != -1:
                return self.delete_backtab_else_statement(scope)
            if msg.msg.find('Unnecessary "elif" after "return"') != -1:
                return self.replace_elif_with_if(scope)
        return False
