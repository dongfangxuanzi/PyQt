'''
Name:        e1123.py
Purpose:
Author:      wukan
Created:     2026-10-17
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from novalapp.python.parser import node_utils
from novalapp.python.parser.node_scope import ScopeFinder
from ....pylint_fix import PylintFixer
from ....multifixer import MultiOptionFixer


class PylintE1123Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明: 调用函数的关键字参数名错误
    '''

    def __init__(self):
        super().__init__('E1123', self.FixKind.SINGLEFIX)
        MultiOptionFixer.__init__(self, 0, 'Rename keyword argument', 'Choose one keyword argument')

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r"Unexpected keyword argument '(.*)' in function call \(unexpected-keyword-arg\)",
            msg.msg
        )
        keyword_name = res.groups()[0]
        parent_node = ScopeFinder.get_parent_node_by_nodeclass(node, nodes.Call)
        if parent_node is not None:
            keywords = [keyword.arg for keyword in parent_node.keywords]
            if keyword_name not in keywords:
                return False
            kindex = keywords.index(keyword_name)
            knode = parent_node.keywords[kindex]
            infer_func_def = node_utils.safe_infer(parent_node.func)
            if not infer_func_def or not isinstance(infer_func_def, nodes.FunctionDef):
                return False
            args = [arg.as_string() for arg in infer_func_def.args.args]
            self._options = args
            self.get_selection()
            kwarg_str = args[self._sel] + "=" + knode.value.as_string()
            self.fix_node_text(knode, kwarg_str)
            return True
        return False
