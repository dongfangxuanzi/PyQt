'''
Name:        pylint_fix.py
Purpose:     pylint规则修复器
Author:      wukan
Created:     2026-08-24
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import base64
import os
import logging
from astroid import AstroidSyntaxError
import astroid
from astroid import nodes
from novalapp import _
from novalapp.lib.pyqt import QMessageBox
from novalapp.project import command as projectcommand
from novalapp.util.cmp_func import py_sorted
from novalapp.util import fileutils, strutils
from novalapp import constants
from novalapp.python.parser.define import SELF_ARG_NAME, CLASS_INIT_METHOD
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp.python.parser import node_utils
from .sarif_loader import SarifLoader
from .strings import PYLINT_TOOL_NAME, COMMON_PYLINT_MESSAGE_ID
from .codeutils import get_node_line_text, get_node_col_offset_blanks, get_scope_range
from .exceptions import InvalidOptionIndexError, DeleteNodeError
from .basefix import BasePythonFixer
log = logging.getLogger(__name__)


class PylintFixer(BasePythonFixer):

    SINGLE_TRIPLE_QUOTE = "'''"
    DOUBLE_TRIPLE_QUOTE = '"""'
    DOUBLE_QUOTE = '"'
    SINGLE_QUOTE = "'"
    # 使用*导入模块成员时允许导入的最大成员数量
    DEFAULT_MAX_MEMBERS_COUNT = 30

    def __init__(self, ruleid, kind, open_file=True):
        super().__init__(ruleid, PYLINT_TOOL_NAME, kind, open_file)

    @staticmethod
    def is_init_call_node(node):
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call) and (
            isinstance(node.value.func, nodes.Attribute)
        ) and node.value.func.attrname == CLASS_INIT_METHOD:
            return True
        return False

    @staticmethod
    def extract_node_with_text(nodetext):
        try:
            node = astroid.extract_node(nodetext)
            return node
        except AstroidSyntaxError as ex:
            log.error(str(ex))
        return None

    @staticmethod
    def get_classtype_parent_node(node, nodeclass, include_node_self=True):
        if include_node_self and isinstance(node, nodeclass):
            return node
        return ScopeFinder.get_parent_node_by_nodeclass(node, nodeclass)

    @staticmethod
    def get_line_str_quote(node):
        '''
        获取行字符串是用单引号还是双引号裹起来
        '''
        linetext = get_node_line_text(node)
        if linetext is None:
            return '"'
        return linetext[node.col_offset]

    @staticmethod
    def compare_with_node_line_col(leftnode, rightnode):
        '''
        按节点行号进行排序,如果左边行号小于右边行号,或者行号相等,左边列号小于右边列号,返回正值表示倒叙,
        否则表示正序,此排序函数表示按行列号进行倒叙排序
        '''
        if leftnode.lineno is None or rightnode.lineno is None:
            return -1
        if leftnode.lineno < rightnode.lineno:
            return 1
        if leftnode.lineno == rightnode.lineno:
            if leftnode.col_offset < rightnode.col_offset:
                return 1
        return -1

    @staticmethod
    def contain_escape_char(linestr):
        '''字符串里面是否包含转义字符'''
        if '\\"' in linestr or "\\'" in linestr:
            return True
        if '\\n' in linestr or '\\r' in linestr or '\\t' in linestr:
            return True
        return False

    @classmethod
    def get_line_str_f_quote(cls, node):
        '''
        获取行字符串引号左边是否是f字符,如果有f,获取f后面的引号字符
        '''
        _is_r_quote, is_f_quote, str_quote = cls.get_line_str_adj_quote(node)
        return is_f_quote, str_quote

    @classmethod
    def get_line_str_adj_quote(cls, node):
        '''
        获取行字符串引号左边毗邻的字符,是r还是f,还是rf
        '''
        str_quote = cls.get_line_str_quote(node)
        log.debug(
            "str quote of line %d is %s",
            node.lineno,
            str_quote
        )
        # 字符串被r包裹
        if str_quote == 'r':
            # 字符串引号在r字符右移1位
            node.col_offset += 1
            str_quote = cls.get_line_str_quote(node)
            if str_quote == 'f':
                node.col_offset += 1
                str_quote = cls.get_line_str_quote(node)
                node.col_offset -= 2
                return True, True, str_quote
            node.col_offset -= 1
            return True, False, str_quote
        if str_quote == 'f':
            node.col_offset += 1
            str_quote = cls.get_line_str_quote(node)
            node.col_offset -= 1
            return False, True, str_quote
        return False, False, str_quote

    @classmethod
    def get_line_str_r_quote(cls, node):
        '''
        获取行字符串引号左边是否是r字符,如果有r,获取r后面的引号字符
        '''
        is_r_quote, _is_f_quote, str_quote = cls.get_line_str_adj_quote(node)
        return is_r_quote, str_quote

    @classmethod
    def get_fix_const_str(cls, const_node, trim_quote=False, is_joined_str=False):
        '''
        :param const_node: 常量字符串节点
        :type const_node: nodes.Const
        :param trim_quote: 是否去除字符串的引号
        :type trim_quote: bool
        :param is_joined_str: 常量字符串是否在f-string字符串中
        :type is_joined_str: bool
        :return: 返回原始的非转义的字符串
        :rtype: str
        '''
        is_r_quote, is_f_quote, str_quote = cls.get_line_str_adj_quote(const_node)
        if str_quote not in (cls.SINGLE_QUOTE, cls.DOUBLE_QUOTE):
            log.error(
                "find str quote on line %d of file error",
                const_node.lineno
            )
            raise RuntimeError(f'fix const str node in line {const_node.lineno} error')
        if is_f_quote:
            log.debug('const node str is in f-string')
        const_nodestr = const_node.as_string()
        const_node_value = const_node.value
        if const_node_value.find('\\') == -1 or cls.contain_escape_char(const_nodestr) or const_nodestr.find('\\\\') != -1:
            if trim_quote:
                return const_nodestr.strip(str_quote)
            return const_nodestr
        # 这里必须使用原始字符串,使用as_string会对原始字符串进行转义,
        # 从而改变原始字符串内容
        const_node_str = ''
        # 字符串被r包裹,如果在f-string中不要在这里添加r字符
        if not is_joined_str and is_r_quote:
            const_node_str += "r"
        if trim_quote:
            const_node_str += const_node_value
        else:
            const_node_str += (str_quote + const_node_value + str_quote)
        return const_node_str

    @classmethod
    def get_joined_node_str(cls, joined_str_node):
        value_nodes = joined_str_node.values
        joined_str = ''
        is_r_quote = False
        is_f_quote = False
        str_quote = ''
        for valnode in value_nodes:
            if node_utils.is_const_type(valnode, str):
                is_r_quote, is_f_quote, str_quote = cls.get_line_str_adj_quote(valnode)
                joined_str += cls.get_fix_const_str(valnode, trim_quote=True, is_joined_str=True)
            else:
                joined_str += valnode.as_string()
        if is_r_quote and is_f_quote:
            joined_str = "rf" + str_quote + joined_str + str_quote
        elif is_f_quote:
            joined_str = "f" + str_quote + joined_str + str_quote
        return joined_str

    def is_node_enclosed_in_brackets(self, const_str_node, linetext=None):
        '''
        判断节点是否用多余的小括号括起来
        '''
        if linetext is None:
            linetext = self.get_line_text(const_str_node.lineno - 1)
        col_offset = const_str_node.col_offset
        while col_offset > 0:
            col_char = linetext[col_offset]
            if col_char == '=':
                break
            if col_char == '(':
                return True
            col_offset -= 1
        return False

    def replace_function_scope_range(self, scope, texts):
        scope_range = self.get_function_scope_range(scope)
        scope_range.replace_with_text(self._textview, texts)

    def get_function_scope_range(self, scope):
        scope_range = get_scope_range(scope)
        # 包含函数上方的注释行
        top_comment_lines = self.get_function_top_comment_lines(scope)
        if top_comment_lines:
            scope_range.start_line = top_comment_lines[-1]
        return scope_range

    def delete_import_name(self, node, import_name):
        if not self.is_node_could_deleted(node):
            log.error("%s node could not be deleted", node.__class__.__name__)
            return False
        for i, (name, asname) in enumerate(node.names):
            if import_name in (name, asname):
                del node.names[i]
                break
        else:
            return False
        if not node.names:
            return self.delete_node(node)
        self.fix_node_text(node, node.as_string())
        return True

    def replace_attribute_name_in_scope(self, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, (nodes.AssignAttr, nodes.Attribute)) and child.attrname == name:
                self.fix_node_text(child, f"{SELF_ARG_NAME}." + newname)
            else:
                self.replace_attribute_name_in_scope(child, name, newname)

    def replace_method_name_in_scope(
        self,
        scope,
        methodname,
        new_methodname,
        is_class_method,
        classname
    ):
        childs = list(self.iter_scope_childs(scope))
        # 将子节点倒序
        for child in childs[::-1]:
            if isinstance(child, nodes.Name) and (
                isinstance(child.parent, nodes.FunctionDef) and child.name == methodname
            ):
                self.fix_node_text(child, new_methodname)
            elif isinstance(child, nodes.Attribute) and child.attrname == methodname:
                if is_class_method:
                    if isinstance(child.expr, nodes.Name):
                        if child.expr.name == 'cls':
                            self.fix_node_text(child, "cls." + new_methodname)
                            continue
                        elif child.expr.name == classname:
                            self.fix_node_text(child, f"{classname}." + new_methodname)
                            continue
                self.fix_node_text(child, f"{SELF_ARG_NAME}." + new_methodname)
            else:
                self.replace_method_name_in_scope(
                    child, methodname, new_methodname, is_class_method, classname)

    def fix_exception_name(self, node, asname):
        '''
        except Exception as xxx
        xxx节点是多行节点,不能用as_string,只能修改行内容
        '''
        offset_blanks = get_node_col_offset_blanks(node)
        fixstr = offset_blanks + 'except %s as %s:' % (node.type.as_string(), asname)
        self.replace_line_text(node.lineno, fixstr)

    def replace_variable_name_in_scope(self, scope, name, newname):
        childs = list(scope.get_children())
        # 将子节点按行列号倒序排序
        for child in py_sorted(childs, self.compare_with_node_line_col):
            if isinstance(child, (nodes.Name, nodes.AssignName)) and child.name == name:
                if isinstance(child.parent, nodes.ExceptHandler):
                    self.fix_exception_name(child.parent, newname)
                else:
                    self.fix_node_text(child, newname)
            else:
                self.replace_variable_name_in_scope(child, name, newname)

    def replace_module_name(self, oldpath, new_module_name):
        ext = strutils.get_file_extension(oldpath, keepdot=True)
        newname = os.path.join(
            fileutils.get_filepath_from_path(oldpath), new_module_name)
        newfilepath = strutils.make_name_end_in_extension(newname, ext)
        ret = self._doc.GetCommandProcessor().Submit(
            projectcommand.ProjectRenameFileCommand(self._doc, oldpath, newfilepath)
        )
        if ret:
            self._doc.Save()
        return ret

    def fix_docstr_position(self, docnode):
        fix_doc_str, changed = self.get_fix_docstr(docnode)
        if fix_doc_str and changed:
            self.fix_node_text(docnode, fix_doc_str)
            return True
        return False

    def get_fix_docstr(self, docnode, blanks=None):
        docstr = docnode.value
        is_r_quote, quote_char = self.get_line_str_r_quote(docnode)
        if quote_char not in [self.DOUBLE_QUOTE, self.SINGLE_QUOTE]:
            log.error("doc node on line %s has not quote char", docnode.lineno)
            return '', True
        triple_quotes = quote_char * 3
        if is_r_quote:
            start_triple_quotes = 'r' + triple_quotes
        else:
            if docstr.find('\\') != -1:
                docstr = docstr.replace('\\', '\\\\')
            start_triple_quotes = triple_quotes
        if docnode.lineno == docnode.end_lineno:
            if docstr.strip() == docstr:
                return '', False
            fix_doc_str = start_triple_quotes + docstr.strip() + triple_quotes
            return fix_doc_str, True
        doclines = docstr.split(constants.LF)
        if blanks is None:
            blanks = get_node_col_offset_blanks(docnode)
        fix_doc_str = start_triple_quotes + constants.LF
        for docline in doclines:
            trim_docline = docline.strip()
            if not trim_docline:
                continue
            fix_docline = blanks + trim_docline + constants.LF
            fix_doc_str += fix_docline
        fix_doc_str += blanks
        fix_doc_str += triple_quotes
        if fix_doc_str == (start_triple_quotes + constants.LF.join(doclines) + triple_quotes):
            return fix_doc_str, False
        return fix_doc_str, True


class SarifFixer(PylintFixer):
    '''
    通用sarif格式修复器
    '''

    def __init__(self, ruleid, kind, open_file=True):
        PylintFixer.__init__(self, ruleid, kind, open_file)

    def fix_message(self, msg):
        if self.check_tool.output_format != self.check_tool.JSON_OUTPUT_FORMAT:
            return False
        fix_options = msg.fixers
        if not fix_options:
            return False
        if len(fix_options) > 1 and not self.fix_only_autofix():
            choices = [fix_option['description']['text'] for fix_option in fix_options]
            sel = self.ask_input_list(
                "Fix code",
                "Please choose one fixer option",
                choices,
                selection=0
            )
            if sel == -1:
                raise InvalidOptionIndexError('cancel option')
        else:
            # sarif自动修复有多个修复选项时默认选第一个作为修复方案
            sel = 0
        fix_option = fix_options[sel]
        chan = fix_option['artifactChanges'][0]
        fixuri = chan['artifactLocation']['uri']
        fixpath = SarifLoader.uri_to_path(fixuri)
        if not fileutils.ComparePath(msg.filepath, fixpath):
            log.error('sarif fix path %s is not source path:%s', fixpath, msg.filepath)
            return False
        replacements = chan['replacements']
        if self.is_text_modified() and not self.fix_only_autofix():
            QMessageBox.critical(self._textctrl, _('Error'), _(
                'Please save your file before fix warnings'))
            return False
        replace_flag = False
        for replacement in replacements:
            if "deletedRegion" in replacement:
                deleted_region = replacement["deletedRegion"]
                if 'byteOffset' in deleted_region:
                    base64_text = bytearray(
                        replacement["insertedContent"]['binary'], encoding="ascii")
                    inserted_content = base64.b64decode(base64_text)
                    byte_offset = deleted_region['byteOffset']
                    byte_len = deleted_region['byteLength']
                    newbytes = b''
                    with open(fixpath, "rb") as fp:
                        byte_content = fp.read()
                        newbytes = byte_content[0:byte_offset] + bytearray(
                            inserted_content) + byte_content[byte_offset + byte_len:]
                    with open(fixpath, "wb") as fw:
                        fw.write(newbytes)
                    self.reload_text_doc()
                elif 'charOffset' in deleted_region:
                    char_offset = deleted_region['charOffset']
                    char_len = deleted_region['charLength']
                    inserted_content = replacement["insertedContent"]["text"]
                    self.replace_offset_range_text(char_offset, char_len, inserted_content)
                else:
                    start_line = deleted_region["startLine"]
                    start_column = deleted_region["startColumn"] - 1
                    end_column = deleted_region["endColumn"] - 1
                    end_line = deleted_region["endLine"]
                    inserted_content = replacement["insertedContent"]["text"]
                    if start_line == end_line and start_column == end_column:
                        self.add_range_text(start_line, start_column, inserted_content)
                    else:
                        self.replace_range_text(
                            start_line,
                            inserted_content,
                            start_column,
                            end_line,
                            end_column
                        )
                replace_flag = True
        return replace_flag


class PylintCommonFixer(PylintFixer):
    '''
    修复pylint告警之外的一些常见问题
    '''

    def __init__(self):
        PylintFixer.__init__(self, COMMON_PYLINT_MESSAGE_ID, self.FixKind.AUTOFIX, True)
        self.enable_format_module_doc = False
        self.enable_remove_print_expression = False
        self.enable_convert_tabs = False

    @classmethod
    def get_fix_docnodes(cls, scope, doc_nodes: list):
        for bodynode in scope.body[::-1]:
            if isinstance(bodynode, nodes.FunctionDef):
                for child in bodynode.body[::-1]:
                    if isinstance(child, nodes.FunctionDef):
                        doc_nodes.append(child.doc_node)
                doc_nodes.append(bodynode.doc_node)
            elif isinstance(bodynode, nodes.ClassDef):
                for child in bodynode.body[::-1]:
                    if isinstance(child, nodes.FunctionDef):
                        doc_nodes.append(child.doc_node)
                    elif hasattr(child, 'body'):
                        cls.get_fix_docnodes(child, doc_nodes)
                doc_nodes.append(bodynode.doc_node)
            elif hasattr(bodynode, 'body'):
                cls.get_fix_docnodes(bodynode, doc_nodes)

    def format_doc_str(self):
        '''
        格式化(模块/类/函数/方法)的文档字符串,对齐边界,保持整齐好看的排列方式
        '''
        module = self.get_module()
        if module is None:
            return False
        fix_docs = 0
        fix_docnodes = []
        self.get_fix_docnodes(module, fix_docnodes)
        fix_docnodes.append(module.doc_node)
        for docnode in fix_docnodes:
            fix_docs += self.fix_doc_node(docnode)
        log.debug('fix docstr nodes count is %d', fix_docs)
        return fix_docs > 0

    def fix_doc_node(self, docnode):
        if docnode is None:
            return 0
        return int(self.fix_docstr_position(docnode))

    def fix_message(self, msg):
        try:
            self.load_module(msg.filepath, reload=True)
        except RuntimeError as ex:
            log.error(str(ex))
            return False
        ret = False
        if self.enable_format_module_doc:
            suc = self.format_doc_str()
            if suc:
                ret = suc
                self.load_module(msg.filepath, reload=True)
        if self.fix_module_imports_blank_line():
            ret = True
            self.load_module(msg.filepath, reload=True)
        if self.enable_remove_print_expression:
            rem_suc = self.remove_print_statements(msg)
            if rem_suc:
                ret = rem_suc
                try:
                    self.load_module(msg.filepath, reload=True)
                except RuntimeError as ex:
                    log.error("remove print statements error:%s", str(ex))
        if self.enable_convert_tabs:
            suc = self.convert_tabs_to_spaces()
            if suc:
                ret = suc
        return ret

    def fix_module_imports_blank_line(self):
        '''
        清除导入语句之间的空行
        '''
        importutils = self.get_import_nodes_visitor()
        top_import_nodes = importutils.get_top_import_nodes()
        if not top_import_nodes:
            return False
        start_line = top_import_nodes[0].lineno
        end_line = top_import_nodes[-1].lineno
        del_lines = []
        for i in range(start_line - 1, end_line):
            line_text = self.get_line_text(i)
            if not line_text.strip():
                del_lines.append(i)
        if not del_lines:
            return False
        del_lines.sort(reverse=True)
        for del_line_index in del_lines:
            self.delete_text_line(del_line_index)
        return True

    def remove_print_statements(self, msg):
        '''移除打印(print)语句'''
        line_count = self.get_line_count()
        # 按行号大小倒序遍历
        ret = False
        for i in range(line_count, 0, -1):
            node = self.find_node_on_line(i)
            if node is None:
                line_text = self.get_line_text(i - 1)
                log.error(
                    'could not find ast node on line %d with line text `%s`',
                    i + 1,
                    line_text
                )
                continue
            if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call) and (
                isinstance(node.value.func, nodes.Name) and node.value.func.name == "print"
            ):
                try:
                    ret = self.delete_node(node, delete_node_line=True, check_deleteable=True)
                    if ret:
                        self.load_module(msg.filepath, reload=True)
                except DeleteNodeError as ex:
                    log.error('remove print statement error:%s', str(ex))
        return ret
