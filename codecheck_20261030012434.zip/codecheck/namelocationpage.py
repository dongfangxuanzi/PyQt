from novalapp.python.project.page import BasePythonProjectNameLocationPage


class CodecheckProjectNameLocationPage(BasePythonProjectNameLocationPage):

    def Init(self):
        super().Init()
        self.create_projectdir_checkbtn.setChecked(False)
