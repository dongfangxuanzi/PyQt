from dataclasses import dataclass
from astroid import nodes


@dataclass(frozen=True)
class Member:
    """代码语法节点的子成员"""
    name: str
    modname: str
    member_tpe: str
    node: nodes.NodeNG


@dataclass(frozen=True)
class ReferMember(Member):
    '''从其它模块中导入的成员引用作为自己的成员'''
    refer_mod_path: str
