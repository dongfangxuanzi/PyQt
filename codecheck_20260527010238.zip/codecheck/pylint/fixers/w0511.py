import re
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg


class PylintW0511Fixer(PylintFixer):
    '''
    规则说明:fixme/todo注释
    '''

    def __init__(self):
        super().__init__('W0511', False)

    @staticmethod
    def is_comment_line(textctrl, line):
        line_text = textctrl.get_line_text(line)
        if line_text.lstrip().startswith('#'):
            return True
        return False

    @classmethod
    def is_todo_line(cls, textctrl, line):
        line_text = textctrl.get_line_text(line)
        return cls.is_todo_line_text(line_text)

    @staticmethod
    def is_todo_line_text(line_text):
        if not re.search(r'#\s*(todo|fixme|XXX)', line_text, re.I):
            return False
        return True

    @classmethod
    def is_msg_todo_line(cls, textctrl, msg):
        line_text = cls.get_msg_line_text(msg, textctrl)
        return cls.is_todo_line_text(line_text)

    @classmethod
    def get_todo_lines(cls, textctrl, line):
        '''
        todo注释可能有多行,如果删除todo则多行todo注释都要删除
        '''
        todo_line_indexes = [line]
        while True:
            line += 1
            if not cls.is_comment_line(textctrl, line) or cls.is_todo_line(textctrl, line):
                break
            todo_line_indexes.append(line)
        return todo_line_indexes

    @classmethod
    def delete_comment_msg_line(cls, textview, textctrl, msg):
        '''
        删除注释行,如果注释在行首则删除整行,如果注释在行尾,则删除行尾注释,不影响代码
        '''
        cls.delete_comment_line(textview, textctrl, msg.line - 1)

    @classmethod
    def delete_comment_line(cls, textview, textctrl, line):
        '''
        删除注释行,如果注释在行首则删除整行,如果注释在行尾,则删除行尾注释,不影响代码
        '''
        msg_line = line
        if cls.is_comment_line(textctrl, msg_line):
            todo_lines = cls.get_todo_lines(textctrl, msg_line)
            for todo_line in todo_lines[::-1]:
                textview.delete_line(todo_line)
        else:
            line_text = textctrl.get_line_text(line)
            comment_index = line_text.find('#')
            start_pos = textctrl.position_from_linecol(
                msg_line, comment_index)
            textlen = len(textctrl._encodeString(line_text))
            end_pos = textctrl.position_from_linecol(msg_line, textlen)
            textctrl.replace_target(start_pos, end_pos, '')

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        if not self.is_msg_todo_line(textctrl, msg):
            return False
        self.delete_comment_msg_line(textview, textctrl, msg)
        return True
