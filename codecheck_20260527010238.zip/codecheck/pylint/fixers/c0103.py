import re
from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp import _
from novalapp.widgets import simpledialog
from slugify import slugify
from ...basefix import fix_code_file_msg
from ...multifixer import MultiOptionFixer
from ...pylint_fix import PylintFixer
from ... import configkeys


class PylintC0103Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:变量和属性命名不符合规范
    '''

    def __init__(self):
        super().__init__('C0103', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Conform to snake_case name',
            descr='Choose one snake_case style',
            init_options=['slugify-lowercase', 'lowercase']
        )

    @staticmethod
    def slugify_str(txt):
        '''
        将含大写的命名风格转换为全部小写+下划线的命名风格
        '''
        chars = ''
        for i, ch in enumerate(txt):
            if i > 0 and ch.isupper() and not txt[i - 1].isupper():
                chars += ' '
            chars += ch
        r = slugify(chars, separator='_')
        if txt.startswith('__'):
            r = "__" + r
        elif txt.startswith('_'):
            r = "_" + r
        return r

    def get_default_valid_name(self, textctrl, varname):
        self.get_selection(textctrl)
        if self.selection == 1:
            return varname.lower()
        if self.selection == 0:
            return self.slugify_str(varname)
        return None

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        res = re.search(
            r'Module name "(?P<modulename>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res:
            modulename = res.groupdict().get('modulename')
            default_modulename = self.get_default_valid_name(text_ctrl, modulename)
            if default_modulename is None:
                return False
            # 模块名支持自动修复
            if self.is_autofix_msg:
                if utils.profile_get_int(
                    configkeys.STANDARDIZE_MODULE_NAME_STYLE_KEY, 
                    False
                ):
                    ok = True
                    newname = default_modulename
                else:
                    return False
            else:
                ok, newname = simpledialog.askstring(
                    _('Rename module name'),
                    _('Input new module name'),
                    initialvalue=default_modulename,
                    master=text_ctrl
                )
            if ok and newname != modulename:
                return self.replace_module_name(doc, msg.filepath, newname)
        node = self.find_msg_node(textview, msg, use_column=True)
        if not node:
            return False
        funcscope = ScopeFinder.get_function_scope(node)
        # 目前仅支持函数范围内的变量名更改替换
        if funcscope is None:
            return False
        res1 = re.search(
            r'Variable name "(?P<varname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res1:
            varname = res1.groupdict().get('varname')
            default_varname = self.get_default_valid_name(text_ctrl, varname)
            if default_varname is None:
                return False
            if not self.is_autofix_msg:
                ok, newname = simpledialog.askstring(
                    _('Rename variable name'),
                    _('Input new variable name'),
                    initialvalue=default_varname,
                    master=text_ctrl
                )
                if not ok or newname == varname:
                    return False
            else:
                if utils.profile_get_int(
                    configkeys.STANDARDIZE_LOCAL_VARIABLE_NAME_STYLE_KEY, False
                ):
                    newname = default_varname
                else:
                    return False
            self.replace_variable_name_in_scope(
                textview, funcscope, varname, newname)
            return True
        res2 = re.search(
            r'Attribute name "(?P<attrname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res2:
            if not isinstance(funcscope.parent, nodes.ClassDef):
                return False
            attrname = res2.groupdict().get('attrname')
            default_attrname = self.get_default_valid_name(text_ctrl, attrname)
            if default_attrname is None:
                return False
            if self.is_autofix_msg:
                if utils.profile_get_int(
                    configkeys.STANDARDIZE_CLASS_ATTR_NAME_STYLE_KEY, False
                ):
                    newname = default_attrname
                else:
                    return False
            else:
                ok, newname = simpledialog.askstring(
                    _('Rename attribute name'),
                    _('Input new attribute name'),
                    initialvalue=default_attrname,
                    master=text_ctrl
                )
                if not ok or newname == attrname:
                    return False
            self.replace_attribute_name_in_scope(
                textview, funcscope.parent, attrname, newname)
            return True
        res3 = re.search(
            r'Argument name "(?P<argname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res3:
            argname = res3.groupdict().get('argname')
            default_argname = self.get_default_valid_name(text_ctrl, argname)
            if default_argname is None:
                return False
            if self.is_autofix_msg:
                if utils.profile_get_int(
                    configkeys.STANDARDIZE_LOCAL_VARIABLE_NAME_STYLE_KEY, False
                ):
                    newname = default_argname
                else:
                    return False
            else:
                ok, newname = simpledialog.askstring(
                    _('Rename argument name'),
                    _('Input new argument name'),
                    initialvalue=default_argname,
                    master=text_ctrl
                )
                if not ok or newname == argname:
                    return False
            self.replace_variable_name_in_scope(
                textview, funcscope, argname, newname)
            return True
        return False
