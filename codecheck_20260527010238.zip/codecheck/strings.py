PYLINT_TOOL_NAME = 'pylint'
FLAKE8_TOOL_NAME = 'flake8'
CODECHECK_TOOL_NANE = "codecheck"
FIX_PROCESSER_NAME = "Codefix"
AUTOPEP8_TOOL_NAME = 'autopep8'
MESSAGE_VIEW_NAME = "Messages"
METRICS_VIEW_NAME = "CodeMetrics"
CODE_CHECK_PROCESSOR_NAME = 'Codecheck'
FLAKE8_ERADICATE_TOOL_NAME = 'flake8-eradicate'
COMMON_PYLINT_MESSAGE_ID = 'pylint-common-msg-id'

PYLINT_PLUGIN_NAMES = [
    'plugins.assert_checker',
    'plugins.tabs_checker',
    'plugins.comment_out_checker',
    'plugins.class_method_order_checker'
]

PYLINT_CFG_MASTER_CONTROL_SECTION = 'MESSAGES CONTROL'
PYLINT_CFG_MASTER_SECTION = 'MASTER'
