import os
import collections
from threading import Thread
import shutil
import winpty
import pyte
from novalapp.executable import Executable
from novalapp import constants
from ...backend.command import PROGRAM_OUTPUT_EVENT_NAME, BackendEvent
from ...util import utils, fileutils
from .cmd_names import CmdName
from ...util.exceptions import BackendTerminatedError
from ...backend.states import BackendState
from ...backend.running import Runner, SubprocessProxy
from .term_config import (
    DEFAULT_SCREEN_COLUMNS,
    DEFAULT_SCREEN_LINES,
    RUN_TERMINAL_BACKENDKEY,
    TERMINAL_SCREEN_LINES_KEY,
    TERMINAL_SCREEN_COLUMNS_KEY,
    TERMINAL_ECHO_COMMAND_KEY
)
from ...settings.setting_wrapper import settings


class CmdRunner(Runner):
    """description of class"""

    def get_backend(self):
        backend_name = settings().get_default(
            RUN_TERMINAL_BACKENDKEY,
            CmdName.POWERSHELLCMD
        )
        if isinstance(backend_name, str):
            backend_name = CmdName(backend_name)
        return backend_name

    def send_program_input(self, data):
        self._proxy.send_program_input(data)


class ShellCmdProxy(SubprocessProxy):
    def __init__(self, executable_name, clean, runner):
        path = self.get_backend_location(executable_name)
        utils.get_logger().info("executable name %s path is %s", executable_name, path)
        super().__init__(clean, path, runner)

    @staticmethod
    def get_backend_location(executable_name):
        path = Executable.get_location(executable_name)
        if path is None:
            raise RuntimeError("Canot locate backend path of %s" % executable_name)
        return path

    def send_program_input(self, data):
        if self._proc is None:
            return
        self._proc.stdin.write(data + constants.LF)
        self._proc.stdin.flush()

    def _get_launcher_with_args(self):
        return []

    def _listen_stdout(self, stdout):
        # will be called from separate thread
        message_queue = self._response_queue
        while not self._is_disconnected():
            self._runner.set_state(BackendState.WAITING_TOPLEVEL_COMMAND)
            utils.get_logger().info('wait for read some stdout data...')
            data = stdout.readline()
            utils.get_logger().debug("read some stdout data `%s` ...", repr(data))
            if data == "":
                break
            message_queue.append(BackendEvent(PROGRAM_OUTPUT_EVENT_NAME,
                                              data=data, stream_name="stdout")
                                 )
            extra_data = ''
            while True:
                char = stdout.read(1)
                extra_data += char
                if char in ('>', ''):
                    break
            self._runner.set_state(BackendState.RUNNING)
            message_queue.append(
                BackendEvent(PROGRAM_OUTPUT_EVENT_NAME,
                             data=extra_data, stream_name="stdout")
            )


class WinPtyProxy(SubprocessProxy):

    DEFAULT_READ_BYTES_LEN = 1024

    def __init__(self, executable_name, clean, runner):
        path = ShellCmdProxy.get_backend_location(executable_name)
        utils.get_logger().info("win pty executable name %s path is %s", executable_name, path)
        self._is_push_command = False
        screen_columns = settings().get_default(TERMINAL_SCREEN_COLUMNS_KEY, DEFAULT_SCREEN_COLUMNS)
        screen_lines = settings().get_default(TERMINAL_SCREEN_LINES_KEY, DEFAULT_SCREEN_LINES)
        self.screen = pyte.Screen(screen_columns, screen_lines)
        self.terminal = pyte.Stream(self.screen)
        super().__init__(clean, path, runner)

    @staticmethod
    def close_echo_command():
        return settings().get_default(TERMINAL_ECHO_COMMAND_KEY, True)

    def feed_screen_data(self, rawdata):
        self.terminal.feed(rawdata)
        values = self.screen.buffer.values()
        str_lines = []
        for linedct in values:
            linestr = ''
            col_keys = map(int, list(linedct.keys()))
            max_col = max(col_keys)
            for col in range(max_col + 1):
                col_char = linedct[col]
                char = col_char.data
                linestr += char
            str_lines.append(linestr)
        strs = os.linesep.join(str_lines)
        if rawdata.endswith(constants.LF):
            strs += os.linesep
        self.screen.reset()
        return strs

    def send_program_input(self, data):
        if self._proc is None:
            return
        self._proc.write(data + os.linesep)
        self._is_push_command = True

    def backend_crash_error(self):
        raise BackendTerminatedError(
            self._proc.exitstatus if self._proc else None)

    def exit_proc(self):
        if not self._is_disconnected():
            self._proc.write('exit' + os.linesep)

    def _start_background_process(self):
        # deque, because in one occasion I need to put messages back
        self._response_queue = collections.deque()
        if not os.path.exists(self._executable):
            raise RuntimeError(
                "WinPty backend path (%s) not found. Please recheck corresponding option!"
                % self._executable
            )
        cmd_line = [self._executable] + self._get_launcher_with_args()
        utils.get_logger().info("Starting the win pty backend: %s %s",
                                Executable.cmd_list_to_str(cmd_line), self._get_initial_cwd())
        self._proc = winpty.PtyProcess.spawn(cmd_line, cwd=self._get_initial_cwd())
        # setup asynchronous output listeners
        Thread(target=self._listen_output, daemon=True).start()

    def _get_initial_cwd(self):
        return self.get_cwd()

    def _listen_output(self):
        # will be called from separate thread
        message_queue = self._response_queue
        while not self._is_disconnected():
            try:
                self._runner.set_state(BackendState.WAITING_TOPLEVEL_COMMAND)
                utils.get_logger().info('wait for read pty some stdout data...')
                data = self._proc.read(self.DEFAULT_READ_BYTES_LEN)
                self._runner.set_state(BackendState.RUNNING)
                utils.get_logger().debug("read some pty stdout data `%s` ...", repr(data))
                if data:
                    str_lines = data.splitlines(keepends=True)
                    for linestr in str_lines:
                        # cmd回显命令不要显示
                        if self.close_echo_command() and linestr.endswith(constants.LF) and self._is_push_command:
                            self._is_push_command = False
                            continue
                        if not self._is_push_command:
                            backend_event = BackendEvent(
                                PROGRAM_OUTPUT_EVENT_NAME,
                                data=self.feed_screen_data(linestr),
                                stream_name='stdout'
                            )
                            message_queue.append(backend_event)
            except (EOFError, OSError) as ex:
                utils.get_logger().error(str(ex))
                break

    def _get_launcher_with_args(self):
        return []

    def _close_backend(self):
        if self._proc is not None:
            self.exit_proc()
            try:
                self._proc.close(force=True)
            except OSError as ex:
                utils.get_logger().error("close backend error:%s", str(ex))
        self._proc = None
        self._response_queue = None

    def _is_disconnected(self):
        return self._proc is None or not self._proc.isalive()


class PowerShellSimulateProxy(WinPtyProxy):
    POWERSHELL_CMD_NAME = "powershell.exe"

    def __init__(self, clean, runner):
        super().__init__(self.POWERSHELL_CMD_NAME, clean, runner)

    @classmethod
    def get_exe_path(cls):
        return ShellCmdProxy.get_backend_location(cls.POWERSHELL_CMD_NAME)


class SystemCmdSimulateProxy(WinPtyProxy):
    SYSTEM_CMD_NAME = "cmd.exe"

    def __init__(self, clean, runner):
        super().__init__(self.SYSTEM_CMD_NAME, clean, runner)

    @classmethod
    def get_exe_path(cls):
        return ShellCmdProxy.get_backend_location(cls.SYSTEM_CMD_NAME)


class PowerShellProxy(ShellCmdProxy):
    def __init__(self, clean, runner):
        super().__init__(PowerShellSimulateProxy.POWERSHELL_CMD_NAME, clean, runner)

    @staticmethod
    def get_exe_path():
        return PowerShellSimulateProxy.get_exe_path()


class SystemCmdProxy(ShellCmdProxy):
    def __init__(self, clean, runner):
        super().__init__(SystemCmdSimulateProxy.SYSTEM_CMD_NAME, clean, runner)

    @staticmethod
    def get_exe_path():
        return SystemCmdSimulateProxy.get_exe_path()

    def _get_launcher_with_args(self):
        # /Q 参数关闭命令回显
        if WinPtyProxy.close_echo_command():
            return ['/Q']
        return []


class GitBashSimulateProxy(WinPtyProxy):
    def __init__(self, clean, runner):
        git_bash_path = self.get_bash_path()
        super().__init__(git_bash_path, clean, runner)

    @staticmethod
    def get_bash_path():
        git_path = shutil.which('git')
        git_install_path = os.path.dirname(os.path.dirname(git_path))
        git_bash_path = fileutils.opj(os.path.join(git_install_path, "bin/bash.exe"))
        utils.get_logger().info("git bash path is %s", git_bash_path)
        return git_bash_path

    @staticmethod
    def get_bash_args():
        return ['--login', '-i']

    @classmethod
    def get_exe_path(cls):
        return cls.get_bash_path()

    def _get_launcher_with_args(self):
        return self.get_bash_args()


class GitBashProxy(ShellCmdProxy):
    def __init__(self, clean, runner):
        git_bash_path = GitBashSimulateProxy.get_bash_path()
        super().__init__(git_bash_path, clean, runner)

    @staticmethod
    def get_exe_path():
        return GitBashSimulateProxy.get_exe_path()

    def _get_launcher_with_args(self):
        return GitBashSimulateProxy.get_bash_args()
