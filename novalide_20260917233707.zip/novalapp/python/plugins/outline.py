# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        outline.py
Purpose:
Author:      wukan
Created:     2019-03-11
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import ast
from astroid import nodes, AstroidSyntaxError
from ...plugin import iface, plugin
from ...lib.pyqt import (
    QTreeWidget,
    Qt,
    QCheckBox,
    QSize,
    QVBoxLayout,
    QAction,
    QToolBar,
    QComboBox,
    QSizePolicy,
    QTreeWidgetItem,
    QCursor
)
from ...bars.menubar import find_menu, NewQMenu, create_action_group
from ... import constants
from ... import menuitems
from ... import globalkeys
from ...sidebar.outline import OutlineView
from ..parser import node_utils
from ..parser.node_scope import ScopeFinder
from ...util import utils, ui_utils, strutils
from ...widgets.colorlabel import QTransparentLabel
from ...qtimage import load_icon
from ..editor import PythonView
from ...preference import preference
from ..ui import ParserErrorsDialog
from ...sidebar import sidebar
from ..parser.define import (
    CLASS_INIT_METHOD,
    MAIN_FUNCTION_NAME
)
from ... import get_app, _
from ..symbol.findoccurrences import FindOccurrences
from ..symbol.occurrencesprovider import OccurrencesSearchProvider
from ..symbol.symbolview import SYMBOL_VIEW_NAME
from ..symbol.replacesymbol.replacesymbol import ReplaceNode
from ..parser import codeparser

QT_CUSTOM_USR_ROLE = Qt.UserRole + 1


def check_name_filtered(func):
    def wrapper(self, *args):
        # if __name__ =="__main__"节点
        if isinstance(args[0], nodes.If):
            name = MAIN_FUNCTION_NAME
        else:
            name = args[0]
        filtered = self.is_name_filtered(name)
        utils.get_logger().debug(
            "node name %s filter names:%s:%s",
            name,
            self._filters,
            filtered
        )
        if filtered:
            return None
        return func(self, *args)
    return wrapper


class OutlineBrowser(QTreeWidget):
    def __init__(self, master=None):
        super().__init__(master)
        self.func_image = get_app().GetImage("python/outline/func.png")
        self.class_image = get_app().GetImage("python/outline/class.png")
        self.property_image = get_app().GetImage("python/outline/property.png")
        self.import_image = get_app().GetImage("python/outline/import.png")
        self.from_import_image = get_app().GetImage("python/outline/from_import.png")
        self.mainfunction_image = get_app().GetImage("python/outline/mainfunction.gif")
        self.error_image = get_app().GetImage("python/outline/error.png")
        self._filters = []

    def set_filter(self, text):
        self._filters = text.lower().split()

    def is_name_filtered(self, name):
        if self._filters != []:
            for filter in self._filters:
                if name.lower().find(filter) != -1:
                    return False
            return True
        return False

    @check_name_filtered
    def add_assign_node(self, name, node, parent):
        return self.add_item(name, node, parent, self.property_image)

    def add_func_node(self, name, node, parent):
        return self.add_item(name, node, parent, self.func_image)

    @check_name_filtered
    def add_import_node(self, name, node, pnode, parent):
        tree_item = self.add_item(name, node, parent, self.import_image)
        tree_item.setData(0, QT_CUSTOM_USR_ROLE, pnode)
        return tree_item

    def add_fromimport_node(self, name, node, parent):
        return self.add_item(name, node, parent, self.from_import_image)

    def add_class_item(self, name, node, parent):
        return self.add_item(name, node, parent, self.class_image)

    @check_name_filtered
    def add_mainfunction_item(self, node, parent):
        return self.add_item(MAIN_FUNCTION_NAME, node, parent, self.mainfunction_image)

    def show_syntax_error(self, ex, parent, filename):
        line = getattr(ex.error, "lineno", None)
        if line is None:
            line = 0
        self.add_item("syntax-error", ex, parent, self.error_image)
        utils.get_logger().error(
            'parse file %s syntax-error:%s on line:%d',
            filename,
            str(ex),
            line
        )

    def show_exception_error(self, ex, parent, filename):
        self.add_item("ast-error", ex, parent, self.error_image)
        utils.get_logger().error(
            'parse file %s ast-error:%s',
            filename,
            str(ex)
        )

    def add_item(self, name, node, parent, img):
        tree_item = QTreeWidgetItem()
        node_text = name
        # 显示基类名称
        if (self.parent()._display_item_flag & PythonOutlineView.DISPLAY_ITEM_CLASS_BASE) and \
                isinstance(node, nodes.ClassDef):
            if node.bases:
                base_str = ",".join([base.as_string() for base in node.bases])
                node_text = "%s(%s)" % (node_text, base_str)
        # 显示函数参数名称
        if (self.parent()._display_item_flag & PythonOutlineView.DISPLAY_ITEM_FUNCTION_PARAMETER) and \
                isinstance(node, nodes.FunctionDef):
            if node.args.args:
                node_text = "%s(%s)" % (node_text, node.args.as_string())
        # 最后显示行号,需放在最后显示
        if self.parent()._display_item_flag & PythonOutlineView.DISPLAY_ITEM_LINE:
            if isinstance(node, AstroidSyntaxError):
                node_text = "%s[%d]" % (node_text, node.error.lineno)
            elif isinstance(node, (nodes.NodeNG, ast.alias)):
                node_text = "%s[%d]" % (node_text, node.lineno)
        tree_item.setText(0, " " + node_text)
        tree_item.setIcon(0, img)
        tree_item.setData(0, Qt.UserRole, node)
        parent.addChild(tree_item)
        return tree_item


class PythonOutlineView(OutlineView):
    # 显示节点名称(默认)
    DISPLAY_ITEM_NAME = 0
    # 显示节点行号
    DISPLAY_ITEM_LINE = 1
    # 显示类节点基类名称
    DISPLAY_ITEM_CLASS_BASE = 2
    # 显示函数节点参数信息
    DISPLAY_ITEM_FUNCTION_PARAMETER = 4

    DEFAULT_NONELABEL_TEXT = "\n" + _("Not a python file")

    def __init__(self, master):
        super().__init__(master)
        self._display_item_flag = self.DISPLAY_ITEM_NAME
        # 显示行号
        if utils.profile_get_int(globalkeys.OUTLINE_SHOWLINENUMBER_KEY, True):
            self._display_item_flag |= self.DISPLAY_ITEM_LINE
        # 显示参数
        if utils.profile_get_int(globalkeys.OUTLINE_SHOWPARAMETER_KEY, False):
            self._display_item_flag |= self.DISPLAY_ITEM_FUNCTION_PARAMETER
        # 显示基类
        if utils.profile_get_int(globalkeys.OUTLINE_SHOWBASECLASS_KEY, False):
            self._display_item_flag |= self.DISPLAY_ITEM_CLASS_BASE
        self.node_childs = {}
        self.tree.itemClicked.connect(self._on_select)

    @staticmethod
    def get_targets(node):
        targets = node.targets
        target = targets[0]
        # 连等表达式
        if isinstance(target, nodes.Tuple):
            targets = target.elts
        return targets

    def on_right_click(self):
        '''
        右键弹出的菜单
        '''
        if self._menu is None:
            view_menu = find_menu(_("&View"), get_app().Menubar)
            self._menu = view_menu.GetMenu(menuitems.ID_OUTLINE_SORT)
        self._menu.popup(QCursor.pos())

    def copy_to_clipboard(self):
        """Copies the path to the file where the element is to the clipboard"""
        dataname = self.get_item_name()
        ui_utils.copytoclipboard(dataname)

    def remove_node_item(self):
        items = self.tree.selectedItems()
        if not items:
            return
        item_nodes = []
        for item in items:
            node = item.data(0, Qt.UserRole)
            if isinstance(node, nodes.NodeNG):
                if isinstance(node.parent, nodes.Assign):
                    node.parent.targets.remove(node)
                    item_nodes.append(node.parent)
                else:
                    if isinstance(node, nodes.ImportFrom):
                        node.names.clear()
                    item_nodes.append(node)
            elif isinstance(node, ast.alias):
                pnode = item.data(0, QT_CUSTOM_USR_ROLE)
                pnode.names.remove((node.name, node.asname))
                item_nodes.append(pnode)
        sorted_nodes = sorted(item_nodes, key=lambda x: x.lineno, reverse=True)
        for sorted_node in sorted_nodes:
            replacenode = ReplaceNode(sorted_node, self.GetCallbackView())
            if isinstance(sorted_node, nodes.Assign):
                if sorted_node.targets == []:
                    replacenode.replace_node_with_text('')
                else:
                    replacenode.replace_node_with_text(sorted_node.as_string())
            elif isinstance(sorted_node, (nodes.Import, nodes.ImportFrom)):
                if sorted_node.names == []:
                    replacenode.replace_node_with_text('')
                else:
                    replacenode.replace_node_with_text(sorted_node.as_string())
            else:
                replacenode.replace_node_with_text('')

    def get_item_name(self, item=None):
        if item is None:
            item = self.tree.currentItem()
        if item is None:
            return ''
        data = item.data(0, Qt.UserRole)
        dataname = ''
        if isinstance(data, (nodes.ClassDef, nodes.FunctionDef)):
            dataname = data.qname()
        elif isinstance(data, nodes.ImportFrom):
            dataname = data.modname
        elif isinstance(data, ast.alias):
            dataname = node_utils.get_alias_name(data)
        elif isinstance(data, nodes.AssignAttr):
            dataname = data.as_string()
        elif isinstance(data, nodes.AssignName):
            dataname = data.name
        elif isinstance(data, nodes.If):
            dataname = MAIN_FUNCTION_NAME
        return dataname

    def LoadOutLine(self, currview, linenum=-1, force_reload=False):
        # 停止大纲显示时不要加载语法信息
        if self._stop_outline_show:
            utils.get_logger().debug('outline view has stop show syntax tree...')
            return
        found_registered_view = False
        # 是否是允许在大纲显示的视图类型
        if self.is_valid_viewtype(currview):
            if not currview.GetDocument()._is_loading_doc:
                currview.LoadOutLine(
                    self,
                    force=force_reload,
                    linenum=linenum
                )
                self.SetCallbackView(currview)
                found_registered_view = True
                if currview.ModuleAnalyzer.Module is not None:
                    self._sort(self.root)
                self.show_nonelabel(show=False)
            else:
                self.show_nonelabel(show=True, labeltext=_('Loading Document'))
                utils.get_logger().debug("%s is loading document,will not load outline",
                                         currview.GetDocument().GetFilename())
        else:
            self.show_nonelabel(show=True, labeltext=self.DEFAULT_NONELABEL_TEXT)
            utils.get_logger().debug(
                'doc view type %s is not support shown in outline window',
                currview.GetViewName()
            )

        # 不支持显示大纲视图的文档类型,大纲内容显示为空
        if not found_registered_view:
            self.SetCallbackView(None)
            self._clear_tree()

    def sync_to_position(self, view, linenum):
        assert view == self.GetCallbackView()
        if linenum >= 0 and view.Module is not None:
            scope = ScopeFinder(view.Module).find_class_funcdef_scope(
                linenum
            )
            if isinstance(scope, nodes.Module):
                return
            self.find_select_node_item(scope)

    def find_select_node_item(self, class_func_node):
        item = self.find_node_item(class_func_node, self.root)
        if item is None:
            utils.get_logger().error("could not find class/func node %s", class_func_node)
            return
        if item.parent() is not None:
            item.parent().setExpanded(True)
        self.clear_selections()
        self.tree.setCurrentItem(item)
        item.setSelected(True)

    def clear_selections(self):
        nodes = self.tree.selectedItems()
        for node in nodes:
            node.setSelected(False)

    def find_node_item(self, defnode, parentitem):
        childcount = parentitem.childCount()
        for i in range(childcount):
            childitem = parentitem.child(i)
            node = childitem.data(0, Qt.UserRole)
            if node == defnode:
                return childitem
            else:
                nodeitem = self.find_node_item(defnode, childitem)
                if nodeitem is not None:
                    return nodeitem
        return None

    def show_parserros_dialog(self):
        ParserErrorsDialog(
            self.GetCallbackView().GetDocument().GetFilename(),
            self.GetCallbackView().ModuleAnalyzer.SyntaxError,
            self
        ).exec_()

    def visit_functiondef(self, node):
        def_name = node.name
        is_property_def, is_setter_property = node_utils.is_function_property(node)
        default_arg_num = len(node.args.defaults)
        arg_num = len(node.args.args)
        for i, _arg in enumerate(node.args.args):
            is_default = False
            # the last serveral argments are default arg if default argment number is not 0
            # 最后面几个是默认参数,如果默认参数不为空的话
            default_value = None
            if i >= arg_num - default_arg_num:
                is_default = True
                defaults = node.args.defaults
                default_value = defaults[i - (arg_num - default_arg_num)].as_string()
            kwargs = {'is_default': is_default}
            if default_value is not None:
                kwargs.update({'value': default_value})
        parent_item = self.get_parent_item(node)
        # is_class_property必须是函数用property装饰并且为类方法时才为True
        if is_property_def:
            defitem = self.tree.add_assign_node(
                def_name, node, parent_item)
            if is_setter_property:
                self.update_tree_func(node, defitem)
        else:
            defitem = self.tree.add_func_node(def_name, node, parent_item)
        self.update_tree_func(node, defitem)

    def visit_asyncfunctiondef(self, node):
        parent_item = self.get_parent_item(node)
        defitem = self.tree.add_func_node(node.name, node, parent_item)
        self.update_tree_func(node, defitem)

    def get_parent_item(self, node):
        parent_scope_node = ScopeFinder.get_parent_scope_node(node)
        parent_item = self.node_childs[parent_scope_node]
        return parent_item

    def visit_classdef(self, node):
        class_name = node.name
        parent = self.get_parent_item(node)
        item = self.tree.add_class_item(
            class_name, node, parent)
        self.update_tree_class(node, item)

    def leave_classdef(self, node):
        class_name = node.name
        parent = self.get_parent_item(node)
        item = self.node_childs[node]
        self.check_parent_item_deleted(class_name, item, parent)

    def leave_functiondef(self, node):
        if node_utils.is_function_property(node)[0]:
            return
        func_name = node.name
        parent = self.get_parent_item(node)
        item = self.node_childs[node]
        self.check_parent_item_deleted(func_name, item, parent)

    def add_target_assign(self, target, node):
        name = target.name
        if ScopeFinder.is_module_range(node):
            self.tree.add_assign_node(name, target, self.root)
        elif ScopeFinder.is_class_range(node) and node.parent in self.node_childs:
            if not ScopeFinder.is_parent_node_classtype(node, nodes.FunctionDef):
                self.tree.add_assign_node(
                    name, target, self.node_childs[node.parent])

    def add_target_assignattr(self, target, node):
        if not (
            isinstance(node.parent, nodes.FunctionDef) and node.parent.name == CLASS_INIT_METHOD
        ):
            return
        # 如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
        if isinstance(target.expr, nodes.Name) and (
            target.expr.name == "self" and isinstance(node.parent.parent, nodes.ClassDef)
        ):
            name = target.attrname
            self.tree.add_assign_node(
                name, target, self.node_childs[node.parent.parent])

    def visit_assign(self, node):
        targets = self.get_targets(node)
        for target in targets:
            if isinstance(target, nodes.AssignName):
                self.add_target_assign(target, node)
            elif isinstance(target, nodes.AssignAttr):
                self.add_target_assignattr(target, node)

    def visit_annassign(self, node):
        target = node.target
        if isinstance(target, nodes.AssignName):
            self.add_target_assign(target, node)
        elif isinstance(target, nodes.AssignAttr):
            self.add_target_assignattr(target, node)

    def visit_import(self, node):
        parentitem = self.get_parent_item(node)
        for alias in node.alias:
            name = node_utils.get_alias_name(alias)
            self.tree.add_import_node(name, alias, node, parentitem)

    def visit_importfrom(self, node):
        if utils.profile_get_int(globalkeys.FIX_IMPORT_NODES_KEY, False):
            self.codeparser.fix_import_node(node)
        parentitem = self.get_parent_item(node)
        mod_name = node_utils.get_fromimport_modname(node)
        item = self.tree.add_fromimport_node(mod_name, node, parentitem)
        for alias in node.alias:
            name = node_utils.get_alias_name(alias)
            self.tree.add_import_node(name, alias, node, item)
        self.check_parent_item_deleted(mod_name, item, parentitem)

    def check_parent_item_deleted(self, name, item, parent):
        '''
        搜索名称时如果父节点下子节点为空,删除父节点
        '''
        if self.tree.is_name_filtered(name) and item.childCount() == 0:
            child_index = parent.indexOfChild(item)
            parent.takeChild(child_index)

    def update_tree_module(self, module):
        self.node_childs[module] = self.root

    def update_tree_class(self, classnode, item):
        self.node_childs[classnode] = item

    def update_tree_func(self, funcnode, item):
        self.node_childs[funcnode] = item

    def show_syntax_error(self, ex, filename):
        self._clear_tree()
        self.tree.show_syntax_error(ex, self.root, filename)

    def show_exception_error(self, ex, filename):
        self._clear_tree()
        self.tree.show_exception_error(ex, self.root, filename)

    def visit_if(self, node):
        if node_utils.is_main_statement(node):
            self.tree.add_mainfunction_item(node, self.root)
        for orelse in node.orelse:
            if isinstance(orelse, nodes.If):
                for child in orelse.body:
                    self.codeparser.visit_child(child)
            else:
                self.codeparser.visit_child(orelse)

    def visit_try(self, node):
        for orelse in node.orelse:
            self.codeparser.visit_child(orelse)
        for handler in node.handlers:
            self.codeparser.visit_child(handler)

    def _create_layout(self):
        """Helper to create the viewer layout"""
        self.tree = OutlineBrowser(self)
        self.tree.setSelectionMode(QTreeWidget.ExtendedSelection)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self.on_right_click)

        # Toolbar part - buttons
        self.definition_button = QAction(
            load_icon('definition.png'),
            _('Jump to highlighted item definition'), self)
        self.definition_button.triggered.connect(self.__goto_definition)
        self.find_button = QAction(
            load_icon('findusage.png'),
            _('Find highlighted item occurences'), self)
        self.find_button.triggered.connect(self.__find_where_used)
        self.copypath_button = QAction(
            load_icon('copymenu.png'), _('Copy select node'), self)
        self.copypath_button.triggered.connect(self.copy_to_clipboard)

        self.remove_item_button = QAction(
            load_icon('removeitem'), _('Remove select node'), self)
        self.remove_item_button.triggered.connect(self.remove_node_item)

        self.toolbar = QToolBar(self)
        self.toolbar.setMovable(False)
        self.toolbar.setAllowedAreas(Qt.TopToolBarArea)
        self.toolbar.setIconSize(QSize(16, 16))
        self.toolbar.setContentsMargins(0, 0, 0, 0)
        self.toolbar.addAction(self.definition_button)
        self.toolbar.addAction(self.find_button)
        self.toolbar.addAction(self.copypath_button)
        self.toolbar.addAction(self.remove_item_button)

        filterabel = QTransparentLabel("  " + _("Filter") + " ")
        self.toolbar.addWidget(filterabel)
        self.filterEdit = QComboBox(self.toolbar)
        self.filterEdit.setSizePolicy(QSizePolicy.Expanding,
                                      QSizePolicy.Expanding)
        self.filterEdit.setMinimumWidth(40)
        self.filterEdit.setEditable(True)
        self.filterEdit.lineEdit().setToolTip(
            _("Space separated regular expressions"))
        self.toolbar.addWidget(self.filterEdit)
        self.filterEdit.editTextChanged.connect(self.__filter_changed)
        get_app().MainFrame.GetNotebook().currentChanged.connect(self._update_frame_contents)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.toolbar)
        self.create_nonelabel(self.DEFAULT_NONELABEL_TEXT)
        layout.addWidget(self.nonelabel)
        layout.addWidget(self.tree)

        self.setLayout(layout)

    def __goto_definition(self):
        item = self.tree.currentItem()
        if item is None:
            return
        node = item.data(0, Qt.UserRole)
        if isinstance(node, AstroidSyntaxError):
            self.show_parserros_dialog()
            lineno = node.error.lineno - 1
            col = 0
        else:
            lineno = node.lineno - 1
            col = node.col_offset
        editor = self._callback_view.GetCtrl()
        editor.ensureLineVisible(lineno)
        get_app().GotoView(
            self._callback_view.GetDocument().GetFilename(),
            lineNum=lineno,
            colno=col
        )

    def __find_where_used(self):
        """Find where used context menu handler"""
        findname = self.get_item_name()
        if strutils.is_none_empty(findname):
            return
        results_viewer = get_app().MainFrame.GetView(SYMBOL_VIEW_NAME)
        finder = FindOccurrences(findname)
        finder.search()
        results_viewer.show_report(
            OccurrencesSearchProvider().get_name(),
            finder.search_results,
            finder.get_parameter()
        )
        get_app().MainFrame.activateBottomTab(SYMBOL_VIEW_NAME)

    # 由于此消息是异步消息,创建标签页时文本控件还没有创建,故需要延迟执行
    # 以便等待文本控件创建成功
    @ui_utils.call_after_with_time(10)
    def _update_frame_contents(self, index):
        if index < 0:
            self._clear_tree()
            return
        currentwidget = get_app().MainFrame.GetNotebook().widget(index)
        if currentwidget is None:
            return
        current_view = currentwidget.GetView()
        if self.is_valid_viewtype(current_view):
            self.codeparser.set_analyzer(current_view.ModuleAnalyzer.codeparser.analyzer)
        self.LoadOutLine(current_view)

    def __filter_changed(self, text):
        """Triggers when the filter text changed"""
        self._cls_viewer = self.tree
        self._cls_viewer.set_filter(text)
        self._clear_tree()
        self.LoadOutLine(self.GetCallbackView(), force_reload=True)

    def _on_select(self):
        if not utils.profile_get_int(globalkeys.CLICK_ITEM_SELECT_CODE_KEY, True):
            return
        editor = get_app().MainFrame.GetNotebook().get_current_editor()
        if editor:
            item = self.tree.currentItem()
            if item is None or not item.isSelected():
                return
            node = item.data(0, Qt.UserRole)
            if isinstance(node, AstroidSyntaxError):
                self.show_parserros_dialog()
                lineno = node.error.lineno - 1
            elif isinstance(node, (nodes.NodeNG, ast.alias)):
                lineno = node.lineno - 1
            elif isinstance(node, Exception):
                self.show_parserros_dialog()
                return
            editor.ensureLineVisible(lineno)
            startpos = editor.positionFromLineIndex(lineno, 0)
            endpos = editor.positionFromLineIndex(lineno + 1, 0) - 1
            editor.set_sel(startpos, endpos)

    def _clear_tree(self):
        super()._clear_tree()
        self.node_childs.clear()


def sort_outline(sort_order):
    get_app().MainFrame.outlineview.sort(sort_order)


class OutlineOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    """

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.__show_linenumber_chkbox = QCheckBox(_("Show line number"))
        self.__show_linenumber_chkbox.setChecked(
            utils.profile_get_int(globalkeys.OUTLINE_SHOWLINENUMBER_KEY, True))
        self.layout.addWidget(self.__show_linenumber_chkbox)

        self.__show_parameter_chkbox = QCheckBox(
            _("Show parameter of function"))
        self.__show_parameter_chkbox.setChecked(
            utils.profile_get_int(globalkeys.OUTLINE_SHOWPARAMETER_KEY, True))
        self.layout.addWidget(self.__show_parameter_chkbox)

        self.__show_classbase_chkbox = QCheckBox(
            _("Show base classes of class"))
        self.__show_classbase_chkbox.setChecked(
            utils.profile_get_int(globalkeys.OUTLINE_SHOWBASECLASS_KEY, True))
        self.layout.addWidget(self.__show_classbase_chkbox)

        self.__fix_import_nodes_chkbox = QCheckBox(
            _("Fix relative imports to absolute imports"))
        self.__fix_import_nodes_chkbox.setChecked(
            utils.profile_get_int(globalkeys.FIX_IMPORT_NODES_KEY, False))
        self.layout.addWidget(self.__fix_import_nodes_chkbox)

        self.__item_click_chkbox = QCheckBox(
            _("Jump to code line when tree item selected"))
        self.__item_click_chkbox.setChecked(
            utils.profile_get_int(globalkeys.CLICK_ITEM_SELECT_CODE_KEY, True))
        self.layout.addWidget(self.__item_click_chkbox)

        self.layout.setAlignment(Qt.AlignTop)

    def OnOK(self, options_dialog):
        utils.profile_set(globalkeys.OUTLINE_SHOWLINENUMBER_KEY,
                          self.__show_linenumber_chkbox.isChecked())
        utils.profile_set(globalkeys.OUTLINE_SHOWPARAMETER_KEY,
                          self.__show_parameter_chkbox.isChecked())
        utils.profile_set(globalkeys.OUTLINE_SHOWBASECLASS_KEY,
                          self.__show_classbase_chkbox.isChecked())

        display_item_flag = PythonOutlineView.DISPLAY_ITEM_NAME
        if self.__show_linenumber_chkbox.isChecked():
            display_item_flag |= PythonOutlineView.DISPLAY_ITEM_LINE

        if self.__show_parameter_chkbox.isChecked():
            display_item_flag |= PythonOutlineView.DISPLAY_ITEM_FUNCTION_PARAMETER

        if self.__show_classbase_chkbox.isChecked():
            display_item_flag |= PythonOutlineView.DISPLAY_ITEM_CLASS_BASE

        outline_view = get_app().MainFrame.GetView(constants.OUTLINE_VIEW_NAME)
        if display_item_flag != outline_view._display_item_flag:
            outline_view._display_item_flag = display_item_flag
            active_text_view = get_app().GetDocumentManager().GetCurrentView()
            if active_text_view is not None and hasattr(active_text_view, "LoadOutLine"):
                active_text_view.LoadOutLine(outline_view, True)
        utils.profile_set(
            globalkeys.FIX_IMPORT_NODES_KEY,
            self.__fix_import_nodes_chkbox.isChecked()
        )
        utils.profile_set(
            globalkeys.CLICK_ITEM_SELECT_CODE_KEY,
            self.__item_click_chkbox.isChecked()
        )
        return True


class PythonOutlineViewLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)

    def load(self):
        outlineview_info = get_app().MainFrame.AddView(
            constants.OUTLINE_VIEW_NAME,
            PythonOutlineView,
            _("Outline"),
            sidebar.SideBar.East,
            image_file="python/outline/outline.ico",
            active=False
        )
        outline_view = outlineview_info['instance']
        _code_parser = codeparser.CodeParser(outline_view)
        outline_view.set_codeparser(_code_parser)
        _code_parser.add_module_visitor()
        view_menu = find_menu(_("&View"), get_app().Menubar)
        outline_menu = NewQMenu(_("Outline sort"))
        outline_sort_order = utils.profile_get_int(
            globalkeys.OUTLINE_SORT_KEY, OutlineView.SORT_BY_NONE)
        view_menu.insert_menu_after(
            menuitems.ID_ZOOM, menuitems.ID_OUTLINE_SORT, outline_menu)
        el_group = create_action_group(outline_view)
        # 设置Python文本视图在大纲中显示语法树
        outline_view.add_viewtype_for_background_handler(PythonView)

        unsort_menu_item = get_app().AddCommand(
            menuitems.ID_SORT_BY_NONE,
            outline_menu, _("Unsorted"),
            lambda: sort_outline(OutlineView.SORT_BY_NONE),
            kind=constants.RADIO_MENU_ITEM_KIND
        )
        sort_line_menu_item = get_app().AddCommand(
            menuitems.ID_SORT_BY_LINE,
            outline_menu,
            _("Sort by line"),
            lambda: sort_outline(OutlineView.SORT_BY_LINE),
            kind=constants.RADIO_MENU_ITEM_KIND
        )
        sort_type_menu_item = get_app().AddCommand(
            menuitems.ID_SORT_BY_TYPE,
            outline_menu,
            _("Sort by type"),
            lambda: sort_outline(OutlineView.SORT_BY_TYPE),
            kind=constants.RADIO_MENU_ITEM_KIND
        )
        sort_name_menu_item = get_app().AddCommand(
            menuitems.ID_SORT_BY_NAME,
            outline_menu,
            _("Sort by name(A-Z)"),
            lambda: sort_outline(OutlineView.SORT_BY_NAME),
            kind=constants.RADIO_MENU_ITEM_KIND
        )
        # 按顺序添加radio action
        el_group.addAction(unsort_menu_item.action)
        el_group.addAction(sort_line_menu_item.action)
        el_group.addAction(sort_name_menu_item.action)
        el_group.addAction(sort_type_menu_item.action)
        # 通过序号获取指定的菜单项
        el_group.actions()[outline_sort_order].setChecked(True)
        # 首选项显示面板
        preference.PreferenceManager().add_options_panel_class(
            _("Misc"), "Outline", _("Outline"), OutlineOptionPanel)
