import re
from astroid import nodes
from ....pylint_fix import PylintFixer
from ....multifixer import MultiOptionFixer


class PylintE0213Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:类成员方法必须用self作为第一个参数,如果第一个参数为cls,可能是classmethod
    '''

    def __init__(self):
        super().__init__('E0213', self.FixKind.SINGLEFIX)
        MultiOptionFixer.__init__(self, 0)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        res = re.search(
            r"Method '(.*)' should have \"self\" as first argument \(no-self-argument\)",
            msg.msg
        )
        nodename = res.groups()[0]
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and (
            nodename == node.name
        ):
            start_line = node.lineno
            scope = node.parent
            blanks = scope.position.col_offset * ' '
            if scope.args.args:
                first_arg = scope.args.args[0]
                if isinstance(first_arg, nodes.AssignName):
                    if first_arg.name == 'self':
                        return False
                    if first_arg.name == 'cls':
                        self._options = [
                            'Convert to self method',
                            'Convert to classmethod'
                        ]
                        self.get_selection()
                        if not self.selection:
                            self.replace_variable_name_in_scope(node.parent, 'cls', 'self')
                        elif self.selection == 1:
                            self.add_range_text(
                                scope.position.lineno,
                                0,
                                blanks + '@classmethod' + '\n'
                            )
                        return True
                self._options = [
                    'Convert to self method',
                    'Convert to staticmethod'
                ]
                self.get_selection()
                if not self.selection:
                    start_column = first_arg.col_offset
                    self.add_range_text(start_line, start_column, "self,")
                elif self.selection == 1:
                    self.add_range_text(
                        scope.position.lineno,
                        0,
                        blanks + '@staticmethod' + '\n'
                    )
                return True
        return False
