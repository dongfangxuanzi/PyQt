import enum
from . import constants
from .replace import get_node_range
DEFAULT_TAB_BLANKS = ' ' * constants.DEFAULT_INDENT_SIZE


class FixChoice(enum.Enum):
    FIX_ALL = 'all'  # 修复所有可修复规则,包括单点修复规则,自动化修复规则
    FIX_AUTOFIX = 'autofix'  # 只修复可完全自动化修复规则
    FIX_SEMI_AUTOFIX = 'semiautofix'  # 修复可自动修复部分场景的规则以及可完全自动化修复规则


def get_func_args_range(funcnode):
    args = funcnode.args
    args.lineno = args.args[0].lineno
    args.col_offset = args.args[0].col_offset
    args.end_lineno = args.args[-1].end_lineno
    args.end_col_offset = args.args[-1].end_col_offset
    default_args = args.defaults or [] + args.kw_defaults or []
    if default_args:
        args.end_lineno = default_args[-1].end_lineno
        args.end_col_offset = default_args[-1].end_col_offset
    return get_node_range(args)
