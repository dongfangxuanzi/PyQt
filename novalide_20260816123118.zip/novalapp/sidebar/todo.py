# -*- coding: utf-8 -*-
"""The todo list viewer implementation"""
import os
import re
from .. import _, get_app
from ..project.processor import Processor
from ..lib.pyqt import (
    Qt,
    QAbstractItemView,
    QHeaderView,
    QTableWidget,
    QTableWidgetItem,
    QWidget,
    pyqtSignal,
    QVBoxLayout,
    QSizePolicy
)
from ..project.document import ProjectDocument
from ..util import fileutils


class TodoProcessor(Processor):

    def __init__(self, totolist_view, statusbar, enabled=True):
        self.totolist_view = totolist_view
        super().__init__(statusbar, 'TodoProcessor', enabled)

    @staticmethod
    def is_todo_line_text(line_text):
        if not re.search(r'#\s*(todo|fixme|XXX)', line_text, re.I):
            return False
        return True

    def run(self, doc, filepath):
        if not os.path.exists(filepath):
            return
        super().run(doc, filepath)
        encoding = fileutils.detect_file_encoding(filepath)
        if encoding is None:
            return
        with open(filepath, 'r', encoding=encoding) as freader:
            for i, line in enumerate(freader):
                if self.is_todo_line_text(line):
                    self.totolist_view.append_todo_signal.emit(i + 1, line, filepath, doc)


class TodolistView(QWidget):
    """The todo list  viewer widget"""
    append_todo_signal = pyqtSignal(int, str, str, ProjectDocument)

    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        self._todo_processor = TodoProcessor(self, get_app().MainFrame.GetStatusBar())
        get_app().MainFrame.projectview.register_sched_processor(self._todo_processor)
        columns = [_('Line'), _('Message'), _('Filepath'), _('Project')]
        self.table = QTableWidget(0, len(columns), self)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.doubleClicked.connect(self.click_message)
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(1, 370)
        self.table.setColumnWidth(2, 710)
        self.table.setColumnWidth(3, 100)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table.setHorizontalHeaderLabels(columns)

        layout = QVBoxLayout()
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(0)
        layout.addWidget(self.table)
        self.setLayout(layout)
        self.append_todo_signal.connect(self.append_todo_msg)

    def find_line_path(self, line, filepath):
        row_count = self.table.rowCount()
        for i in range(row_count):
            cell_path = self.table.item(i, 2).text()
            cell_line = int(self.table.item(i, 0).text())
            if fileutils.ComparePath(cell_path, filepath) and line == cell_line:
                return True
        return False

    def append_todo_msg(self, line, linetext, filepath, projectdoc):
        if self.find_line_path(line, filepath):
            return
        insertrow = 0
        self.table.insertRow(insertrow)
        lineitem = QTableWidgetItem(str(line))
        lineitem.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 0, lineitem)

        messageitem = QTableWidgetItem(linetext.strip())
        self.table.setItem(insertrow, 1, messageitem)

        pathitem = QTableWidgetItem(filepath)
        self.table.setItem(insertrow, 2, pathitem)

        proj_item = QTableWidgetItem(projectdoc.GetModel().name)
        proj_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(insertrow, 3, proj_item)

    def click_message(self, index):
        del index
        row = self.table.currentRow()
        line = int(self.table.item(row, 0).text()) - 1
        path = self.table.item(row, 2).text()
        get_app().GotoView(path, lineNum=line)
