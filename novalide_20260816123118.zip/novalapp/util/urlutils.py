# -*- coding: utf-8 -*-
import logging
import atexit
from concurrent import futures
from typing import Optional
import requests
from .. import constants

url_logger = logging.getLogger('ide.url.request')

# 删除注册全局退出函数,否则会在程序退出时等待ThreadPoolExecutor异步线程执行完才退出,导致程序卡死
try:
    atexit.unregister(futures.thread._python_exit)
except Exception:
    pass


def request_data(
    addr,
    arg: Optional[dict]=None,
    method='get',
    timeout=None,
    to_json=True
):
    '''
    http请求通用接口,支持post,delete,get方法
    stream:是否返回字节流
    to_json:是否返回json字典
    '''
    arg = arg or {}
    params = {}
    try:
        if timeout is not None:
            params['timeout'] = timeout
        else:
            # 如果未设置连接超时时间,使用默认设置的超时时间
            params['timeout'] = constants.DEFAULT_URL_REQUEST_TIMEOUT
        req = None
        if method == 'get':
            params['params'] = arg
            req = requests.get(addr, **params)
        elif method == 'post':
            req = requests.post(addr, data=arg, **params)
        if not to_json:
            return req.text
        return req.json()
    except Exception as e:
        url_logger.error('open %s error:%s', addr, e)
    return None


def upload_file(addr, file, arg: Optional[dict]=None, timeout=None):
    '''
    上传文件
    addr:上传url地址
    file:上传本地文件路径
    arg:url参数
    '''
    arg = arg or {}
    params = {}
    if timeout is not None:
        params['timeout'] = timeout
    files = {
        "file": open(file, "rb")
    }
    try:
        req = requests.post(addr, data=arg, files=files, **params)
    except Exception:
        print('upload file %s error' % file)
        return None
    return req.json()


def fetch_url_future(
    addr,
    arg: Optional[dict] = None,
    method='get',
    timeout=None,
    callback=None,
    error_callback=None
):
    '''
    异步请求获取url数据
    callback:请求正确后回调函数
    error_callback:请求失败后回调函数
    '''
    arg = arg or {}

    def load_url():
        data = request_data(addr, arg, method, timeout)
        if data:
            # 去掉非数据字段
            data.pop('message', '')
            data.pop('code', '')
            if callback:
                callback(data)
        else:
            # 如果error_callback为None,则使用callback
            if not error_callback:
                if callback:
                    callback(None)
            else:
                error_callback(None)
    # 异步请求
    executor = futures.ThreadPoolExecutor(max_workers=1)
    return executor.submit(load_url)
