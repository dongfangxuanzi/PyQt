# -*- coding: utf-8 -*-
from ..lib.pyqt import QLabel, QListWidget, QInputDialog, QRadioButton, QListWidgetItem, Qt
from ..util import ui_utils


class SingleChoiceDialog(ui_utils.BaseModalDialog):
    '''
    单个选择对话框,从列表框中选一
    '''

    def __init__(self, title, label, choices, selection=-1, master=None):
        super().__init__(title, master)
        label = QLabel(label)
        self.layout.addWidget(label)
        self.listbox = QListWidget()
        for item in choices:
            self.listbox.addItem(item)
        if selection != -1:
            self.listbox.setCurrentRow(selection)
        self.listbox.itemDoubleClicked.connect(self.selectionitem)
        self.layout.addWidget(self.listbox)
        self.create_standard_buttons()
        self.selection = -1

    def selectionitem(self):
        self._ok()

    def _ok(self):
        self.selection = self.listbox.currentRow()
        super()._ok()


class RadioChoiceDialog(ui_utils.BaseModalDialog):
    '''
    单个选择对话框,从单选框中选一
    '''

    def __init__(self, title, label, choices, selection=-1, master=None):
        super().__init__(title, master)
        label = QLabel(label)
        self.layout.addWidget(label)
        self.radiobox = []
        for item in choices:
            radio_button = QRadioButton(item)
            self.radiobox.append(radio_button)
            self.layout.addWidget(radio_button)
        if selection != -1:
            self.radiobox[selection].setChecked(True)
        self.create_standard_buttons()
        self.selection = -1

    def _ok(self):
        for i, radiobutton in enumerate(self.radiobox):
            if radiobutton.isChecked():
                self.selection = i
                break
        super()._ok()


class MultiChoiceDialog(ui_utils.BaseModalDialog):
    '''
    多个选择对话框,从列表框中选多个
    '''

    def __init__(self, title, label, choices, master=None):
        super().__init__(title, master)
        label = QLabel(label)
        self.layout.addWidget(label)
        self.listbox = QListWidget()
        for item in choices:
            listitem = QListWidgetItem(item)
            self.listbox.addItem(listitem)
            listitem.setCheckState(Qt.Unchecked)
        self.layout.addWidget(self.listbox)
        self.create_standard_buttons()
        self.selections = []

    def get_selections(self):
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            if listitem.checkState() == Qt.Checked:
                self.selections.append(i)

    def _ok(self):
        self.get_selections()
        super()._ok()


def ask_list_many(title, label, choices, master=None):
    dlg = MultiChoiceDialog(title, label, choices, master)
    dlg.exec_()
    return dlg.selections


def asklist(title, label, choices, selection=-1, master=None):
    dlg = SingleChoiceDialog(title, label, choices, selection, master)
    dlg.exec_()
    return dlg.selection


def askone(title, label, choices, selection=-1, master=None):
    dlg = RadioChoiceDialog(title, label, choices, selection, master)
    dlg.exec_()
    return dlg.selection


def askinteger(title, label, *, default_int=1, minnum=1, maxnum=-1, master=None):
    num, ok = QInputDialog.getInt(
        master, title, label, default_int, minnum, maxnum)
    return ok, num


def askstring(title, label, *, initialvalue=None, master=None):
    name, ok = QInputDialog.getText(master, title, label, text=initialvalue)
    return ok, name


def askitem(title, label, choices, selection=-1, master=None):
    name, ok = QInputDialog.getItem(
        master, title, label, choices, selection, editable=False)
    return name, ok
