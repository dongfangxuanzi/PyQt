"""function order checker for Python code."""
from __future__ import annotations
from typing import TYPE_CHECKING
from typing import Dict, List, NamedTuple, Union, Tuple
from astroid import nodes
from pylint.checkers import BaseChecker
from pylint.checkers.utils import only_required_for_messages
if TYPE_CHECKING:
    from pylint.lint import PyLinter

CLASS_INIT_METHOD = "__init__"
CLASS_NEW_METHOD = "__new__"
CLASS_POST_INIT_METHOD = "__post_init__"
CLASS_PROPERTY_METHOD = "property_method"
CLASS_STATIC_METHOD = "static_method"
CLASS_CLASS_METHOD = "class_method"
CLASS_MAGIC_METHOD = "magic_method"
CLASS_PRIVATE_METHOD = "private_method"
CLASS_METHOD = "method"
CLASS_PRIVATE_STATIC_METHOD = "private_static_method"
CLASS_PRIVATE_CLASS_METHOD = "private_class_method"
CLASS_PRIVATE_PROPERTY_METHOD = "private_property_method"
SPECIAL_METHOD_NAMES = (
    CLASS_NEW_METHOD,
    CLASS_INIT_METHOD,
    CLASS_POST_INIT_METHOD,
)


class ModelPart(NamedTuple):
    model_name: str
    node: nodes.NodeNG
    type_: str
    weight: int


def get_model_parts_info(
    model_ast: nodes.ClassDef, weights: Dict[str, int]
) -> List[ModelPart]:
    parts_info = []
    for child_node in model_ast.body:
        node_type = get_model_node_type(child_node)
        if node_type in weights:
            parts_info.append(
                ModelPart(model_ast.name, child_node, node_type, weights[node_type])
            )
    return parts_info


def get_model_node_type(child_node: nodes.NodeNG) -> str:
    if isinstance(child_node, nodes.If):
        return "if"
    if isinstance(child_node, nodes.Pass):
        return "pass"
    if isinstance(child_node, (nodes.Assign, nodes.AnnAssign)):
        return get_assighment_type(child_node)
    if isinstance(child_node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
        return get_funcdef_type(child_node)
    if isinstance(child_node, nodes.Expr):
        return "docstring" if isinstance(child_node.value, nodes.Const) and isinstance(child_node.value.value, str) else "expression"
    if isinstance(child_node, nodes.ClassDef):
        return "meta_class" if child_node.name == "Meta" else "nested_class"
    return ""


def get_assighment_type(child_node: Union[nodes.Assign, nodes.AnnAssign]) -> str:
    assignee_node = (
        child_node.target
        if isinstance(child_node, nodes.AnnAssign)
        else child_node.targets[0]
    )
    if isinstance(assignee_node, nodes.Subscript):
        return "expression"
    if isinstance(assignee_node, nodes.Name) and is_caps_lock_str(assignee_node.name):
        return "constant"
    return "field"


def get_funcdef_type(child_node: Union[nodes.FunctionDef, nodes.AsyncFunctionDef]) -> str:
    decorator_names_to_types_map = {
        "property": CLASS_PROPERTY_METHOD,
        "cached_property": CLASS_PROPERTY_METHOD,
        "staticmethod": CLASS_STATIC_METHOD,
        "classmethod": CLASS_CLASS_METHOD,
        "private_property": CLASS_PRIVATE_PROPERTY_METHOD,
        "private_cached_property": CLASS_PRIVATE_PROPERTY_METHOD,
        "private_staticmethod": CLASS_PRIVATE_STATIC_METHOD,
        "private_classmethod": CLASS_PRIVATE_CLASS_METHOD,
    }
    if child_node.decorators is not None:
        for decorator_info in child_node.decorators.nodes:
            if (
                isinstance(decorator_info, nodes.Name)
                and decorator_info.name in decorator_names_to_types_map
            ):
                return decorator_names_to_types_map[
                    f"private_{decorator_info.name}"
                    if child_node.name.startswith("_")
                    else decorator_info.name
                ]
            if isinstance(decorator_info, nodes.Attribute) and decorator_info.attrname in (
                "getter",
                "setter",
            ):
                return decorator_names_to_types_map["property"]
    if child_node.name in SPECIAL_METHOD_NAMES:
        return child_node.name
    if child_node.name.startswith("__") and child_node.name.endswith("__"):
        return CLASS_MAGIC_METHOD
    if child_node.name.startswith("_"):
        return CLASS_PRIVATE_METHOD
    return CLASS_METHOD


def is_caps_lock_str(var_name: str) -> bool:
    return var_name.upper() == var_name


class ClassMethodOrderChecker(BaseChecker):
    name = "method-order"
    msgs = {
        "W9003": (
            "`%s` should be after `%s`",
            "class-method-order",
            "The methods of class are recommended to be arranged in a certain order.",
        )
    }
    CLASS_PROPERTY_WEIGHT_INFO = {
        "docstring": 0,
        "pass": 1,
        "meta_class": 2,
        "nested_class": 3,
        "constant": 4,
        "field": 5,
        "outer_field": 6,
        "if": 7,
        "expression": 8,
        CLASS_NEW_METHOD: 9,
        CLASS_INIT_METHOD: 10,
        CLASS_POST_INIT_METHOD: 11,
        CLASS_MAGIC_METHOD: 13,
        CLASS_PROPERTY_METHOD: 20,
        CLASS_PRIVATE_PROPERTY_METHOD: 21,
        CLASS_CLASS_METHOD: 24,
        CLASS_PRIVATE_CLASS_METHOD: 25,
        CLASS_STATIC_METHOD: 22,
        CLASS_PRIVATE_STATIC_METHOD: 23,
        CLASS_METHOD: 26,
        CLASS_PRIVATE_METHOD: 28,
    }

    @staticmethod
    def get_same_weight_index_before_node(end_index, weight, model_parts_info):
        '''
        获取同当前节点连续相同权重最前面的节点
        '''
        start_index = end_index
        for model_part_info in model_parts_info[0:start_index][::-1]:
            if model_part_info.weight == weight:
                start_index -= 1
            else:
                break
        return start_index

    @staticmethod
    def get_same_weight_index_after_node(start_index, weight, model_parts_info):
        '''
        获取同当前节点连续相同权重最下面的节点
        '''
        end_index = start_index
        for model_part_info in model_parts_info[end_index + 1:]:
            if model_part_info.weight == weight:
                end_index += 1
            else:
                break
        return end_index

    @staticmethod
    def get_node_index(node, model_parts_info):
        for i, model_part_info in enumerate(model_parts_info):
            if model_part_info.node == node:
                return i
        return -1

    def get_ordering_errors(
        self, model_parts_info: List[ModelPart],
    ) -> List[Tuple[int, int, str]]:
        errors = []
        for model_part, next_model_part in zip(model_parts_info[:-1], model_parts_info[1:]):
            curr_name, curr_node, curr_type, curr_weight = model_part
            next_name, next_node, next_type, next_weight = next_model_part
            if curr_name == next_name and curr_weight > next_weight:
                # 向下找连续相同权重的节点
                next_node_index = self.get_node_index(next_node, model_parts_info)
                next_same_weight_node_index = self.get_same_weight_index_after_node(
                    next_node_index,
                    next_weight,
                    model_parts_info
                )
                next_same_weight_node = model_parts_info[next_same_weight_node_index].node
                # 向上找连续相同权重的节点
                cur_node_index = self.get_node_index(curr_node, model_parts_info)
                before_same_weight_node_index = self.get_same_weight_index_before_node(
                    cur_node_index,
                    curr_weight,
                    model_parts_info
                )
                before_same_weight_node = model_parts_info[before_same_weight_node_index].node
                # 报相同权重但距离最远的2个节点,可以加快节点调整顺序
                errors.append(
                    (
                        before_same_weight_node,
                        f"{curr_name}.{self.get_node_name(before_same_weight_node, curr_type)}",
                        f"{next_name}.{self.get_node_name(next_same_weight_node, next_type)}"
                    )
                )
        return errors

    @only_required_for_messages("class-method-order")
    def visit_classdef(self, class_def: nodes.ClassDef):
        """
        Check the class method order
        """
        errors: List[Tuple[nodes.NodeNG, str, str]] = []
        errors = self.get_ordering_errors(
            get_model_parts_info(class_def, self.CLASS_PROPERTY_WEIGHT_INFO)
        )
        for node, method_name, after_method_name in errors:
            self.add_message("class-method-order", node=node, args=(method_name, after_method_name))

    def get_node_name(self, node: nodes.NodeNG, node_type: str) -> str:
        if node_type.endswith("docstring"):
            return "docstring"
        if node_type.endswith("meta_class"):
            return "Meta"
        if node_type.endswith("constant"):
            # type: ignore  # noqa
            return node.target.id if isinstance(node, nodes.AnnAssign) else node.targets[0].id
        if node_type.endswith("field"):
            assert isinstance(node, (nodes.Assign, nodes.AnnAssign))
            return self.get_name_for_field_node_type(node)
        if node_type.endswith((CLASS_METHOD, "nested_class") + SPECIAL_METHOD_NAMES):
            return node.name  # type: ignore
        if node_type.endswith("expression"):
            return "<class_level_expression>"
        if node_type.endswith("if"):
            return "if ..."
        return ""

    def get_name_for_field_node_type(self, node: Union[nodes.Assign, nodes.AnnAssign]) -> str:
        default_name = "<class_level_assignment>"
        if isinstance(node, nodes.AnnAssign):
            return node.target.id if isinstance(node.target, nodes.Name) else default_name
        if isinstance(node.targets[0], nodes.Name):
            return node.targets[0].id
        if hasattr(node.targets[0], "attr"):
            return node.targets[0].attr  # type: ignore
        if isinstance(node.targets[0], nodes.Tuple):
            return ", ".join(
                [e.id for e in node.targets[0].elts if isinstance(e, nodes.Name)]
            )
        return default_name


def register(linter: PyLinter) -> None:
    linter.register_checker(ClassMethodOrderChecker(linter))
