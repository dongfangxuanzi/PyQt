import re
import os
from novalapp.python.parser.node_utils import is_main_statement
from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...pylint_fix import PylintFixer
from ...codeutils import ImportNodes, get_add_range, FixNode
from ...multifixer import MultiOptionFixer


class PylintE0601Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:
    1.__main__里面定义的变量必须进行全局声明,否则属于变量未申明即被使用
    2.赋值语句必须在使用变量之前
    '''

    def __init__(self):
        super().__init__('E0601', False)
        MultiOptionFixer.__init__(self, 0, init_options=self.get_init_values().values())

    @staticmethod
    def get_init_values():
        init_values = {
            'None': 'init None',
            "''": 'init empty str',
            "[]": 'init empty list',
            "{}": 'init empty dict',
            'set()': 'init empty set',
            "-1": 'init int(-1)',
            '0': 'init int(0)',
            'True': 'init bool(True)',
            'False': 'init bool(False)'
        }
        return init_values

    @staticmethod
    def get_target_assign_node(target_name, scope):
        for child in scope.body:
            if isinstance(child, nodes.Assign):
                for target in child.targets:
                    if isinstance(target, nodes.AssignName) and target.name == target_name:
                        return target.parent
        return None

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        msg_node = self.find_msg_node(textview, msg)
        parent_scope = ScopeFinder.get_parent_scope(msg_node)
        parent_parent_scope = ScopeFinder.get_parent_scope(parent_scope)
        pattern = r"Using variable '(\w+)' before assignment \(used-before-assignment\)"
        res = re.search(pattern, msg.msg)
        variable_name = None
        if not msg_node or parent_parent_scope is None:
            return False
        variable_name = res.groups()[0]
        target_assign_node = self.get_target_assign_node(variable_name, parent_parent_scope)
        global_target_assign_node = self.get_target_assign_node(
            variable_name,
            textview.ModuleAnalyzer.Module
        )
        if target_assign_node is not None and global_target_assign_node is None:
            remove_node = FixNode(target_assign_node, textview)
            remove_node.replace_node_with_text('')
            insert_line = parent_scope.lineno
            blanks = parent_scope.col_offset * ' '
            add_range = get_add_range(insert_line, 0)
            add_range.add_text(
                textview,
                blanks + f'{target_assign_node.as_string()}' + os.linesep
            )
            return True
        visitor = ImportNodes(textview.ModuleAnalyzer.Module, textview)
        for node in textview.ModuleAnalyzer.Module.body:
            if is_main_statement(node) and self.get_target_assign_node(variable_name, node):
                self.set_title("Create global variable name")
                self.set_description("Please choose one global '%s' value" % variable_name)
                self.get_selection(text_ctrl)
                if self.selection != self.INVAID_SEL_INDEX:
                    init_values = self.get_init_values()
                    insert_line = visitor.get_import_line()
                    add_range = get_add_range(
                        insert_line + 1, 0)
                    init_global_value = list(init_values.keys())[self.selection]
                    add_range.add_text(
                        textview,
                        "%s = %s" % (
                            variable_name, init_global_value) + "\n"
                    )
                    return True
        return False
