'''
Name:        w0401.py
Purpose:
Author:      wukan
Created:     2026-07-10
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from novalapp import get_app
from novalapp.util import utils
from astroid import nodes
from ...codeutils import get_node_range
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...configkeys import WILDCARD_IMPORT_COUNT_KEY


class PylintW0401Fixer(PylintFixer):
    '''
    规则说明: 导入语句使用`from module import *`
    '''
    MAX_MEMBERS_COUNT = 30

    def __init__(self):
        super().__init__('W0401', False)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node or not isinstance(node, nodes.ImportFrom):
            return False
        res = re.search(r'Wildcard import (.*) \(wildcard-import\)', msg.msg)
        modname = res.groups()[0]
        if node.names[0][0] != '*':
            return False
        if modname != node.modname:
            utils.get_logger().warning(
                'msg modname %s is not current node modname %s',
                modname,
                node.modname
            )
            return False
        old_mod_name = node.modname
        old_level = node.level
        textview.ModuleAnalyzer.fix_module_importnodes()
        node = self.find_msg_node(textview, msg)
        mdloader = get_app().intellisence_mananger.GetModule(
            node.modname
        )
        if mdloader is None:
            utils.get_logger().warning(
                'could not find msg modname %s of file:%s on line %d',
                node.modname,
                msg.filepath,
                msg.line
            )
            return False
        members = mdloader.get_member_list()
        node.level = old_level
        node.modname = old_mod_name
        members_count = len(members)
        max_member_count = utils.profile_get_int(WILDCARD_IMPORT_COUNT_KEY, self.MAX_MEMBERS_COUNT)
        if members_count > max_member_count:
            utils.get_logger().warning(
                'import modname %s members count %d is greater then max members limit:%d',
                modname,
                members_count,
                max_member_count
            )
            return False
        fixnode = get_node_range(node)
        fixstr = node.as_string().replace("*", ','.join(members))
        fixnode.replace_with_text(textview, fixstr)
        return True
