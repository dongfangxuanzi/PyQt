import re
import os
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import get_add_range, get_func_args_range
from ...pylint_fix import PylintFixer
from ...multifixer import MultiOptionFixer


class PylintW0613Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:未使用的参数
    '''

    def __init__(self):
        super().__init__('W0613', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Fix unused argument',
            descr="Please choose one fixer option",
            init_options=[
                'Remove argument',
                'Add del statment'
            ]
        )

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg, use_column=True)
        res = re.search(
            r"Unused argument '(\w+)' \(unused-argument\)", msg.msg)
        if not node or not res:
            return False
        unused_arg = res.groups()[0]
        if isinstance(node, nodes.AssignName) and (
            isinstance(node.parent, nodes.Arguments) and node.name == unused_arg
        ):
            funcnode = node.parent.parent
            arguments = node.parent
            arg_num = len(arguments.args)
            defaults = arguments.defaults
            default_num = len(defaults)
            first_body = funcnode.body[0]
            insert_line = first_body.lineno
            self.get_selection(textctrl)
            if self.selection == self.INVAID_SEL_INDEX:
                return False
            if self.selection == 0:
                for i, arg in enumerate(arguments.args):
                    if isinstance(arg, nodes.AssignName) and arg.name == unused_arg:
                        arguments.args.remove(arg)
                        if default_num > 0 and (arg_num - i) <= default_num:
                            del defaults[i - (arg_num - default_num)]
                        del arguments.annotations[i]
                        del arguments.type_comment_args[i]
                        fixrange = get_func_args_range(funcnode)
                        fixrange.replace_with_text(textview, arguments.as_string())
                        return True
            elif self.selection == 1:
                fix_del_str = f"del {unused_arg}"
                for child in funcnode.get_children():
                    if child.as_string().find(fix_del_str) != -1:
                        break
                else:
                    blanks = first_body.col_offset * ' '
                    add_range = get_add_range(insert_line, 0)
                    add_range.add_text(
                        textview,
                        blanks + fix_del_str + os.linesep
                    )
                    return True
        return False
