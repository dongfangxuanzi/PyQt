from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from .r1723 import PylintR1723Fixer


class PylintR1720Fixer(PylintFixer):
    '''
    规则说明:raise表达式后多余的else语句
    '''

    def __init__(self):
        super().__init__('R1720', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        line = msg.line
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(textview.ModuleAnalyzer.Module).find_scope(line)
        if isinstance(scope, nodes.If):
            if msg.msg.find('Unnecessary "else" after "raise"') != -1:
                return PylintR1723Fixer.delete_backtab_else_statement(scope, textview, text_ctrl)
            if msg.msg.find('Unnecessary "elif" after "raise"') != -1:
                return PylintR1723Fixer.replace_elif_with_if(scope, text_ctrl, textview)
        return False
