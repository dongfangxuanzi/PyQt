from astroid import nodes
from novalapp.python.utility import get_builtin_exceptions
from ...basefix import fix_code_file_msg
from ...codeutils import get_node_col_offset_blanks, FixRange
from ...multifixer import MultiOptionFixer
from ...pylint_fix import PylintFixer


class PylintE0704Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:raise抛出异常没有具体的异常类型
    raise
    '''

    def __init__(self):
        super().__init__('E0704', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Fix bare raise',
            descr="Please choose one exception type"
        )

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        line = msg.line
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.Raise) and node.exc is None:
            if not self._options:
                # 搜集所有内建异常类型
                get_builtin_exceptions(self._options)
            self.get_selection(textctrl)
            if self.selection == self.INVAID_SEL_INDEX:
                return False
            fix_range = FixRange(line)
            offset_blanks = get_node_col_offset_blanks(node)
            raise_str = "raise %s" % self._options[self.selection]
            fix_range.replace_line(textview, offset_blanks + raise_str)
            return True
        return False
