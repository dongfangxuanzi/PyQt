'''
Name:        w0622.py
Purpose:     修复内建函数名重名
Author:      wukan
Created:     2026-06-20
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from novalapp.widgets import simpledialog
from novalapp import _
from novalapp.python.parser.node_scope import ScopeFinder
from ...multifixer import MultiOptionFixer
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg


class PylintW0622Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:变量名和内建函数名重名了
    '''

    def __init__(self):
        super().__init__('W0622', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Rename built-in name',
            descr='Please input new name',
            init_options=['Add underline before name', 'Add underline after name']
        )

    @staticmethod
    def get_redefine_varname(selection, varname):
        if selection == 1:
            return varname + "_"
        if selection == 0:
            return "_" + varname
        return None

    def get_default_valid_name(self, textctrl, varname):
        self.get_selection(textctrl)
        return self.get_redefine_varname(self.selection, varname)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg, use_column=True)
        if not node:
            return False
        funcscope = ScopeFinder.get_function_scope(node)
        # 目前仅支持函数范围内的变量名更改替换
        if funcscope is None or not isinstance(node, nodes.AssignName):
            return False
        res = re.search(
            r"Redefining built-in '(\w+)' \(redefined-builtin\)",
            msg.msg
        )
        builtin_name = res.groups()[0]
        if builtin_name != node.name:
            return False
        default_name = self.get_default_valid_name(text_ctrl, builtin_name)
        if default_name is None:
            return False
        if self.is_autofix_msg:
            newname = default_name
        else:
            ok, newname = simpledialog.askstring(
                _('Rename built-in name'),
                _('Input new var name'),
                initialvalue=default_name,
                master=text_ctrl
            )
            if not ok:
                return False
        self.replace_variable_name_in_scope(
            textview, funcscope, builtin_name, newname)
        return True


class PylintW0621Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:局部变量名和全局变量名重名了
    '''

    def __init__(self):
        super().__init__('W0621', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Rename outer scope name',
            descr='Please input new name',
            init_options=['Add underline before name', 'Add underline after name']
        )

    def get_default_valid_name(self, textctrl, varname):
        self.get_selection(textctrl)
        return PylintW0622Fixer.get_redefine_varname(self.selection, varname)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg, use_column=True)
        if not node:
            return False
        funcscope = ScopeFinder.get_function_scope(node)
        # 目前仅支持函数范围内的变量名更改替换
        if funcscope is None or not isinstance(node, nodes.AssignName):
            return False
        res = re.search(
            r"Redefining name '(.*)' from outer scope \(line (\d+)\) \(redefined-outer-name\)",
            msg.msg
        )
        outer_scope_name, outer_name_line = res.groups()
        outer_name_line_text = text_ctrl.get_line_text(int(outer_name_line) - 1)
        if outer_scope_name != node.name or outer_name_line_text.find(outer_scope_name) == -1:
            return False
        default_name = self.get_default_valid_name(text_ctrl, outer_scope_name)
        if default_name is None:
            return False
        if self.is_autofix_msg:
            newname = default_name
        else:
            ok, newname = simpledialog.askstring(
                _('Rename outer scope name'),
                _('Input new var name'),
                initialvalue=default_name,
                master=text_ctrl
            )
            if not ok:
                return False
        self.replace_variable_name_in_scope(
            textview, funcscope, outer_scope_name, newname)
        return True
