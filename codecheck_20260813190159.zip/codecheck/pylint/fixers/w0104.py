# -*- coding: utf-8 -*-
'''
Name:        w0104.py
Purpose:     修复无效的语句和无效的3引号字符串
Author:      wukan
Created:     2026-06-21
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from novalapp import constants
from novalapp.python.parser import node_utils
from ...pylint_fix import PylintFixer
from ...multifixer import MultiOptionFixer
from ...codeutils import FixNode, get_node_col_offset_blanks
from ...basefix import fix_code_file_msg


class PylintW0104Fixer(PylintFixer):
    '''
    规则说明:无效的语句
    '''

    def __init__(self):
        super().__init__('W0104', False)

    @staticmethod
    def get_fix_node(node):
        parent_node = node
        lineno = parent_node.lineno
        fixnode = parent_node
        while parent_node.lineno == lineno:
            parent_node = parent_node.parent
            if parent_node.lineno == lineno:
                fixnode = parent_node
        return fixnode

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg, use_column=True)
        fixnode = self.get_fix_node(node)
        if not isinstance(fixnode, nodes.Expr):
            return False
        exprnode = FixNode(fixnode, textview)
        exprnode.replace_node_with_text('')
        return True


class PylintW0105Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:无效的3引号字符串,可以删除或者转换为注释
    '''

    def __init__(self):
        super().__init__('W0105', True)
        MultiOptionFixer.__init__(
            self,
            1,
            title='Process pointless string statement',
            descr="Please choose one option",
            init_options=['Delete them', 'Convert them to comments']
        )

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg, use_column=True)
        if not node_utils.is_const_type(node, str):
            return False
        if not self.is_node_could_deleted(node.parent):
            return False
        self.get_selection(textctrl)
        if self.selection == self.INVAID_SEL_INDEX:
            return False
        if self.selection == 0:
            fix_const_node = FixNode(node, textview)
            fix_const_node.replace_node_with_text('')
            textview.delete_line(msg.line - 1)
            return True
        if self.selection == 1:
            fix_const_node = FixNode(node, textview)
            node_offset_blanks = get_node_col_offset_blanks(node)
            docstr = node.value.strip()
            fixstr = ''
            fixstr += constants.LF
            doc_lines = docstr.split(constants.LF)
            doc_line_count = len(doc_lines)
            for linestr in doc_lines:
                fixstr += node_offset_blanks
                fixstr += '# '
                fixstr += linestr.strip()
                fixstr += constants.LF
            fix_doc_lines = fixstr.split(constants.LF)
            fix_doc_line_count = len(fix_doc_lines)
            if fix_doc_line_count > doc_line_count:
                fix_doc_lines = fix_doc_lines[0:-1]
                fixstr = constants.LF.join(fix_doc_lines)
            fix_const_node.replace_node_with_text(fixstr)
            textview.delete_line(msg.line - 1)
            return True
        return False
