import os
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import get_node_range, ImportNodes, get_add_range
from ...multifixer import MultiOptionFixer
from ...pylint_fix import PylintFixer


class PylintW1514Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明: open函数参数缺乏encoding参数
    '''

    def __init__(self):
        super().__init__('W1514', False)
        MultiOptionFixer.__init__(
            self,
            1,
            'Open file encoding',
            'please set the file encoding with open',
            init_options=[
                'ascii',
                'utf-8',
                'cp936',
                'gbk',
                'gb2312',
                'gb18030',
                'locale.getencoding()'
            ]
        )

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        node = self.find_msg_node(textview, msg, use_column=True)
        if isinstance(node, nodes.Name) and node.name == "open" and (
            isinstance(node.parent, nodes.Call)
        ):
            callnode = node.parent
            if callnode.as_string().find('encoding=') != -1:
                return False
            self.get_selection(textctrl)
            if self.selection == self.INVAID_SEL_INDEX:
                return False
            arg_strs = [arg.as_string() for arg in callnode.args]
            last_sel_index = len(self.options) - 1
            if self.selection == last_sel_index:
                arg_strs.append('%s=%s' % ('encoding', self.options[self.selection]))
            else:
                arg_strs.append('%s="%s"' % ('encoding', self.options[self.selection]))
            fixrange = get_node_range(callnode)
            fixstr = "open(%s)" % ",".join(arg_strs)
            fixrange.replace_with_text(textview, fixstr)
            if self.selection == last_sel_index:
                visitor = ImportNodes(textview.ModuleAnalyzer.Module, textview)
                if not visitor.is_import_exist('locale'):
                    insert_line = visitor.get_import_line()
                    add_range = get_add_range(insert_line + 1, 0)
                    add_range.add_text(textview, "import locale" + os.linesep)
            return True
        return False
