
from novalapp.python.parser import node_utils
from ...pylint_fix import PylintFixer
from ...codeutils import FixRange
from ...basefix import fix_code_file_msg


class PylintW1406Fixer(PylintFixer):
    '''
    规则说明:unicode字符串不需要加u前缀
    '''

    def __init__(self):
        super().__init__('W1406', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        line = msg.line
        self.load_module(textview, msg.filepath)
        node = self.find_msg_node(textview, msg, use_column=True)
        if node_utils.is_const_type(node, str):
            linetext = self.get_msg_line_text(msg, textctrl)
            if linetext.find("u'") != -1 or linetext.find('u"') != -1:
                fixrange = FixRange(line)
                newlinetext = linetext.replace("u'", self.SINGLE_QUOTE).replace(
                    'u"',
                    self.DOUBLE_QUOTE
                )
                fixrange.replace_line(
                    textview, newlinetext)
                return True
        return False
