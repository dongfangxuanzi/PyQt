import re
from astroid import nodes
from novalapp.util import utils
from ...basefix import fix_code_file_msg
from ...pylint_fix import PylintFixer


class PylintW0611Fixer(PylintFixer):
    '''
    规则说明:未被使用的导入模块
    '''

    def __init__(self):
        super().__init__('W0611', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        self.load_module(textview, msg.filepath)
        node = textview.ModuleAnalyzer.find_line_node(line)
        if node is None:
            return False
        if not self.is_node_could_deleted(node):
            utils.get_logger().error("%s node could not be deleted", node.__class__.__name__)
            return False
        if isinstance(node, nodes.Import):
            res = re.search(
                r"Unused import (\w+(.\w+)?) \(unused-import\)", msg.msg)
            if not res:
                res = re.search(
                    r"Unused (.*) imported as (\w+) \(unused-import\)", msg.msg)
                if not res:
                    return False
                import_name, _import_as_name = res.groups()
            else:
                import_name = res.groups()[0]
            return self.delete_import_name(node, import_name, textview)
        if isinstance(node, nodes.ImportFrom):
            res = re.search(
                r"Unused (\w+) imported from (.*) as (.*) \(unused-import\)", msg.msg)
            if res is not None:
                import_name, import_module = res.groups()[0:2]
                if import_module != node.modname:
                    return False
            else:
                res = re.search(
                    r"Unused (\w+) imported from (.*) \(unused-import\)", msg.msg)
                if res is None:
                    res = re.search(
                        r"Unused import (\w+) \(unused-import\)", msg.msg)
                    if not res:
                        return False
                    import_name = res.groups()[0]
                    if node.modname != '':
                        return False
                else:
                    import_name, import_module = res.groups()
                    if import_module != node.modname:
                        return False
            return self.delete_import_name(node, import_name, textview)
        return False
