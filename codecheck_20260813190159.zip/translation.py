# -*- coding: utf-8 -*-
'''
Name:        translation.py
Purpose:     调用pybabel工具生成翻译多语种文件,然后调用poedit软件实现翻译功能
Author:      wukan
Created:     2026-07-25
Copyright:   (c) wukan 2026
Licence:     Mulan
'''
import subprocess
import os

# -p后面第一个路径为输出翻译文件路径, 第二个路径为源文件路径
curdir = os.getcwd()
PLUGIN_NAME = 'codecheck'
# 生成插件pot文件
BABEL_TOOL_PATH = r"C:\Users\HongYunVM\AppData\Local\Programs\Python\Python311\Scripts\pybabel.exe"
tool_args = " extract {0}/{1} --output-file {0}/{1}/locale/{1}.pot".format(curdir, PLUGIN_NAME)
cmd = BABEL_TOOL_PATH + tool_args
subprocess.call(cmd)

# po文件需要从pot文件更新,菜单Catalogue/Update from POT file
os.system(r'"C:\Program Files (x86)\Poedit\poedit.exe" {0}\{1}\locale\zh_CN.po'.format(
    curdir, PLUGIN_NAME))
