# -- coding: utf-8 --
'''
-------------------------------------------------------------------------------
Name:        _batch.py
Purpose:
Author:      wukan
Created:     2026-03-22
Copyright:   (c) wukan 2019
Licence:     <your licence>
-------------------------------------------------------------------------------
'''
from novalapp import _
from novalapp.syntax import syndata, lang
from novalapp.lib.qsci import QsciLexerBatch
from novalapp.qtimage import load_icon

# -----------------------------------------------------------------------------#
# ---- Keyword Specifications ----#

kwlist = [
    'shift',
    'start',
    'set',
    'pause',
    'exit',
    'goto',
    'if',
    'do',
    'then',
    'elif',
    'else',
    'for',
    'call'
]


_builtinlist = [
    'cls',
    'echo',
    'copy',
    'ren',
    'cd',
    'taskkill',
    'sleep',
    'shutdown',
    'cut',
    'reg',
    'move',
    'del',
    'du',
    'net',
    'ipconfig',
    'ping',
    'rd',
    'time',
    'md'
]


class SyntaxLexer(syndata.CodeBaseLexer):
    """SyntaxData object for Shell/Bash"""
    # ---- Syntax Style Specs ----#

    def __init__(self):
        lang_id = lang.register_new_langid("ID_LANG_BATCH")
        super().__init__(lang_id)

    def GetDescription(self):
        return _('Batch Script')

    def GetExt(self):
        return "bat cmd"

    def GetDefaultCommentPattern(self):
        """Returns a list of characters used to comment a block of code """
        return ['REM ']

    def GetCommentPatterns(self):
        """
        """
        return [self.DefaultCommentPattern, ['::']]

    def GetShowName(self):
        return "Batch"

    def GetDefaultExt(self):
        return "bat"

    def GetDocTypeName(self):
        return "Batch Document"

    def GetViewTypeName(self):
        return _("Batch Editor")

    def GetDocIcon(self):
        return load_icon("file/batch.png")

    def GetKeywords(self):
        return kwlist + _builtinlist

    def get_lexer(self, parent):
        return QsciLexerBatch(parent)
