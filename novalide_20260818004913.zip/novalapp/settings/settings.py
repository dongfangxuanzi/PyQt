# -*- coding: utf-8 -*-
"""novalide settings"""

# pylint: disable=W0702
# pylint: disable=W0703

import os
import os.path
import datetime
import json
import logging
from copy import deepcopy
from ..lib.pyqt import QDir
from ..constants import CONFIG_DIR
from .setting_keys import LAST_OPEN_DOCUMENT_KEY


SETTINGS_DIR = os.path.join(os.path.realpath(QDir.homePath()),
                            CONFIG_DIR) + os.path.sep




_DEFAULT_SETTINGS = {
    # general
    LAST_OPEN_DOCUMENT_KEY: '',
}


def settingsFromJSON(jsonObj):
    """Custom deserialization"""
    if '__class__' in jsonObj:
        if jsonObj['__class__'] == 'ProfilerSettings':
            pSettings = ProfilerSettings()
            pSettings.profSettingsFromJSON(jsonObj)
            return pSettings
        if jsonObj['__class__'] == 'DebuggerSettings':
            dSettings = DebuggerSettings()
            dSettings.debugSettingsFromJSON(jsonObj)
            return dSettings
    return jsonObj


def settingsToJSON(pythonObj):
    """Custom serialization"""
    if isinstance(pythonObj, ProfilerSettings):
        return pythonObj.profSettingsToJSON()
    if isinstance(pythonObj, DebuggerSettings):
        return pythonObj.debugSettingsToJSON()
    raise TypeError(repr(pythonObj) + ' is not JSON serializable')


class SettingsWrapper(QObject,
                      DebuggerEnvironment,
                      SearchEnvironment,
                      FileSystemEnvironment,
                      RunParametersCache,
                      FilePositions,
                      FileEncodings,
                      FlowUICollapsedGroups):

    """Provides settings singleton facility"""

    MAX_SMART_ZOOM = 4
    MIN_SMART_ZOOM = -3

    sigRecentListChanged = pyqtSignal()
    sigFlowSplitterChanged = pyqtSignal()
    sigFlowZoomChanged = pyqtSignal()
    sigTextZoomChanged = pyqtSignal()
    sigHideDocstringsChanged = pyqtSignal()
    sigHideCommentsChanged = pyqtSignal()
    sigHideExceptsChanged = pyqtSignal()
    sigHideDecorsChanged = pyqtSignal()
    sigSmartZoomChanged = pyqtSignal()
    sigRecentFilesChanged = pyqtSignal()
    sigDisasmLevelChanged = pyqtSignal()

    def __init__(self):
        QObject.__init__(self)
        DebuggerEnvironment.__init__(self)
        SearchEnvironment.__init__(self)
        FileSystemEnvironment.__init__(self)
        RunParametersCache.__init__(self)
        FilePositions.__init__(self)
        FileEncodings.__init__(self)
        FlowUICollapsedGroups.__init__(self)

        self.minTextZoom = None
        self.minCFlowZoom = None

        self.__values = deepcopy(_DEFAULT_SETTINGS)

        # make sure that the directory exists
        if not os.path.exists(SETTINGS_DIR):
            os.makedirs(SETTINGS_DIR)

        RunParametersCache.setup(self, SETTINGS_DIR)
        DebuggerEnvironment.setup(self, SETTINGS_DIR)
        SearchEnvironment.setup(self, SETTINGS_DIR)
        FileSystemEnvironment.setup(self, SETTINGS_DIR)
        FilePositions.setup(self, SETTINGS_DIR)
        FileEncodings.setup(self, SETTINGS_DIR)
        FlowUICollapsedGroups.setup(self, SETTINGS_DIR)

        self.webResourceCache = WebResourceCache(SETTINGS_DIR + os.path.sep +
                                                 'webresourcecache')
        self.plantUMLCache = PlantUMLCache(SETTINGS_DIR + os.path.sep +
                                           'plantumlcache')

        # Save the config file name
        self.__fullFileName = SETTINGS_DIR + "settings.json"

        # Create file if does not exist
        if not os.path.exists(self.__fullFileName):
            # Save to file
            self.flush()
            return

        readErrors = []
        print(self.__fullFileName,'-------------------')

        # Load the previous session settings
        try:
            with open(self.__fullFileName, "r",
                      encoding=SETTINGS_ENCODING) as diskfile:
                diskValues = json.load(diskfile, object_hook=settingsFromJSON)
        except Exception as exc:
            # Bad error - save default
            self.__saveErrors('Could not read setting from ' +
                              self.__fullFileName + ': ' + str(exc) +
                              'Overwriting with the default settings...')
            self.flush()
            return

        for item, val in diskValues.items():
            if item in self.__values:
                if type(self.__values[item]) != type(val):
                    readErrors.append("Settings '" + item +
                                      "' type from the disk file " +
                                      self.__fullFileName +
                                      ' does not match the expected one. '
                                      'The default value is used.')
                else:
                    self.__values[item] = val
            else:
                readErrors.append('Disk file ' + self.__fullFileName +
                                  " contains extra value '" + item +
                                  "'. It will be lost.")

        # If format is bad then overwrite the file
        if readErrors:
            self.__saveErrors("\n".join(readErrors))
            self.flush()

        SearchEnvironment.setLimit(self, self.__values['maxSearchEntries'])
        FileSystemEnvironment.setLimit(self, self.__values['maxRecentFiles'])

    @staticmethod
    def __saveErrors(message):
        """Appends the message to the startup errors file"""
        try:
            with open(SETTINGS_DIR + 'startupmessages.log', 'a',
                      encoding=SETTINGS_ENCODING) as diskfile:
                diskfile.write('------ Startup report at ' +
                               str(datetime.datetime.now()) + '\n')
                diskfile.write(message)
                diskfile.write('\n------\n\n')
        except:
            # This is not that important
            pass

    def flush(self):
        """Writes the settings to the disk"""
        try:
            with open(self.__fullFileName, 'w',
                      encoding=SETTINGS_ENCODING) as diskfile:
                json.dump(self.__values, diskfile,
                          default=settingsToJSON, indent=4)
        except Exception as exc:
            logging.error('Error saving setting (to %s): %s',
                          self.__fullFileName, str(exc))

    def addRecentProject(self, projectFile, needFlush=True):
        """Adds the recent project to the list"""
        absProjectFile = os.path.realpath(projectFile)
        recentProjects = self.__values['recentProjects']

        if absProjectFile in recentProjects:
            recentProjects.remove(absProjectFile)

        recentProjects.insert(0, absProjectFile)
        limit = self.__values['maxRecentProjects']
        if len(recentProjects) > limit:
            recentProjects = recentProjects[0:limit]
        self.__values['recentProjects'] = recentProjects
        if needFlush:
            self.flush()
        self.sigRecentListChanged.emit()

    def deleteRecentProject(self, projectFile, needFlush=True):
        """Deletes the recent project from the list"""
        absProjectFile = os.path.realpath(projectFile)
        recentProjects = self.__values['recentProjects']

        if absProjectFile in recentProjects:
            recentProjects.remove(absProjectFile)
            self.__values['recentProjects'] = recentProjects
            if needFlush:
                self.flush()
            self.sigRecentListChanged.emit()

    @staticmethod
    def getDefaultGeometry():
        """Provides the default window size and location"""
        return _DEFAULT_SETTINGS['xpos'], _DEFAULT_SETTINGS['ypos'], \
               _DEFAULT_SETTINGS['width'], _DEFAULT_SETTINGS['height']

    @staticmethod
    def getDefaultRendererWindowGeometry():
        """Provides the default renderer window size and location"""
        # A bit shifted down and half of the width of the main window
        return _DEFAULT_SETTINGS['rendererxpos'], \
               _DEFAULT_SETTINGS['rendererypos'], \
               _DEFAULT_SETTINGS['rendererwidth'], \
               _DEFAULT_SETTINGS['rendererheight']

    def getProfilerSettings(self):
        """Provides the profiler IDE-wide settings"""
        return self.__values['profilerLimits']

    def setProfilerSettings(self, newValue, needFlush=True):
        """Updates the profiler settings"""
        if self.__values['profilerLimits'] != newValue:
            self.__values['profilerLimits'] = newValue
            if needFlush:
                self.flush()

    def getDebuggerSettings(self):
        """Provides the debugger IDE-wide settings"""
        return self.__values['debuggerSettings']

    def setDebuggerSettings(self, newValue, needFlush=True):
        """Updates the debugger settings"""
        if self.__values['debuggerSettings'] != newValue:
            self.__values['debuggerSettings'] = newValue
            if needFlush:
                self.flush()

    def validateZoom(self, minTextZoom, minCFlowZoom):
        """Validates the min zoom values"""
        self.minTextZoom = minTextZoom
        self.minCFlowZoom = minCFlowZoom
        warnings = []
        if self.__values['zoom'] < minTextZoom:
            warnings.append('The current text zoom (' +
                            str(self.__values['zoom']) +
                            ') will be adjusted to ' + str(minTextZoom) +
                            ' due to it is less than min fonts allowed.')
            self.__values['zoom'] = minTextZoom
        if self.__values['flowZoom'] < minCFlowZoom:
            warnings.append('The current flow zoom (' +
                            str(self.__values['flowZoom']) +
                            ') will be adjusted to ' + str(minCFlowZoom) +
                            ' due to it is less than min fonts allowed.')
            self.__values['flowZoom'] = minCFlowZoom
        if self.__values['smartZoom'] < SettingsWrapper.MIN_SMART_ZOOM:
            warnings.append('The current smart zoom (' +
                            str(self.__values['smartZoom']) +
                            ') will be adjusted to ' +
                            str(SettingsWrapper.MIN_SMART_ZOOM) +
                            ' due to it is less than min allowed.')
            self.__values['smartZoom'] = SettingsWrapper.MIN_SMART_ZOOM
        elif self.__values['smartZoom'] > SettingsWrapper.MAX_SMART_ZOOM:
            warnings.append('The current smart zoom (' +
                            str(self.__values['smartZoom']) +
                            ') will be adjusted to ' +
                            str(SettingsWrapper.MAX_SMART_ZOOM) +
                            ' due to it is larger than max allowed.')
            self.__values['smartZoom'] = SettingsWrapper.MAX_SMART_ZOOM

        if warnings:
            self.flush()
        return warnings

    def __getitem__(self, key):
        return self.__values[key]

    def __setitem__(self, key, value):
        self.__values[key] = value
        if key == 'flowSplitterSizes':
            self.sigFlowSplitterChanged.emit()
        elif key == 'hidedocstrings':
            self.sigHideDocstringsChanged.emit()
        elif key == 'hidecomments':
            self.sigHideCommentsChanged.emit()
        elif key == 'hideexcepts':
            self.sigHideExceptsChanged.emit()
        elif key == 'hidedecors':
            self.sigHideDecorsChanged.emit()
        elif key == 'disasmLevel':
            self.sigDisasmLevelChanged.emit()
        self.flush()

    def onTextZoomIn(self):
        """Triggered when the text is zoomed in"""
        self.__values['zoom'] += 1
        self.flush()
        self.sigTextZoomChanged.emit()

    def onTextZoomOut(self):
        """Triggered when the text is zoomed out"""
        if self.__values['zoom'] > self.minTextZoom:
            self.__values['zoom'] -= 1
            self.flush()
            self.sigTextZoomChanged.emit()

    def onTextZoomReset(self):
        """Triggered when the text zoom is reset"""
        if self.__values['zoom'] != 0:
            self.__values['zoom'] = 0
            self.flush()
            self.sigTextZoomChanged.emit()

    def onSmartZoomIn(self):
        """Triggered when the smart zoom is changed"""
        if self.__values['smartZoom'] < SettingsWrapper.MAX_SMART_ZOOM:
            self.__values['smartZoom'] += 1
            self.flush()
            self.sigSmartZoomChanged.emit()

    def onSmartZoomOut(self):
        """Triggered when the smart zoom is changed"""
        if self.__values['smartZoom'] > SettingsWrapper.MIN_SMART_ZOOM:
            self.__values['smartZoom'] -= 1
            self.flush()
            self.sigSmartZoomChanged.emit()

    def onFlowZoomIn(self):
        """Triggered when the flow is zoomed in"""
        self.__values['flowZoom'] += 1
        self.flush()
        self.sigFlowZoomChanged.emit()

    def onFlowZoomOut(self):
        """Triggered when the flow is zoomed out"""
        if self.__values['flowZoom'] > self.minCFlowZoom:
            self.__values['flowZoom'] -= 1
            self.flush()
            self.sigFlowZoomChanged.emit()

    def onFlowZoomReset(self):
        """Triggered when the flow zoom is reset"""
        if self.__values['flowZoom'] != 0:
            self.__values['flowZoom'] = 0
            self.flush()
            self.sigFlowZoomChanged.emit()

    def addRecentFile(self, path):
        """Adds a recent file. True if a new file was inserted."""
        ret = FileSystemEnvironment.addRecentFile(self, path)
        if ret:
            self.sigRecentFilesChanged.emit()
        return ret


SETTINGS_SINGLETON = SettingsWrapper()


def Settings():
    """Settings singleton access"""
    return SETTINGS_SINGLETON
