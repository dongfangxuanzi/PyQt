from ..lib.pyqt import pyqtSignal, QTabBar


class ClickableTabBar(QTabBar):
    """Intercepts clicking on the toolbar"""
    sigCurrentTabClicked = pyqtSignal()
    sigCurrentTabDoubleClicked = pyqtSignal()

    def mousePressEvent(self, event):
        """
        Intercepts clicking on the toolbar and emits a signal.
        It is used to transfer focus to the currently active tab editor.
        """
        tabbar_point = self.mapTo(self, event.pos())
        if self.tabAt(tabbar_point) == self.currentIndex():
            self.sigCurrentTabClicked.emit()
        QTabBar.mousePressEvent(self, event)

    def mouseDoubleClickEvent(self, event):
        tabbar_point = self.mapTo(self, event.pos())
        if self.tabAt(tabbar_point) == self.currentIndex():
            self.sigCurrentTabDoubleClicked.emit()
        QTabBar.mouseDoubleClickEvent(self, event)

    def focusInEvent(self, event):
        """Passes focus to the current tab"""
        del event   # unused argument
        self.parent().setFocus()
