from ..lib.pyqt import QWidget, QVBoxLayout, QSizePolicy
from .notebook import EditorNotebook


class EditorsManagerWidget(QWidget):
    """Tab widget which has tabs with editors and viewers"""

    def __init__(self, parent):
        super().__init__(parent)
        self.editorsManager = EditorNotebook(parent)
        self.editorsManager.setSizePolicy(QSizePolicy.Preferred,
                                          QSizePolicy.Expanding)
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(1, 1, 1, 1)
        self.layout.addWidget(self.editorsManager)
        self.setLayout(self.layout)
