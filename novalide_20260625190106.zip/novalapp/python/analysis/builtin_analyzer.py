import os
import logging
from ...util import utils, fileutils
from .base_analyzer import BaseAnalyzer
from ..parser.define import BUILTINS_DATA_FOLDER, BUILTMODULE_NAME
from ..parser.exceptions import BuiltinModuleNotExistError


logger = logging.getLogger('ide.builtin.analyzer')


class BuiltinAnalyzer(BaseAnalyzer):

    def __init__(self, dbver, data_outpath, interpreter, check_file_updated=False):
        # 解释器自带内建模块数据存放位置
        data_out_path = os.path.join(data_outpath, BUILTINS_DATA_FOLDER)
        super().__init__(dbver, data_out_path, interpreter, check_file_updated)

    def check_builtin_members(self):
        '''
        检查builtins模块的数据文件是否存在,如果不存在,重新更新所有内建模块的数据文件
        '''
        membersfile, memberlistfile = self.get_api_files(BUILTMODULE_NAME)
        if not os.path.exists(membersfile):
            raise BuiltinModuleNotExistError(
                'builtins module data file %s is not exist' % membersfile)
        if not os.path.exists(memberlistfile):
            raise BuiltinModuleNotExistError(
                'builtins module data file %s is not exist' % memberlistfile)

    @utils.compute_time
    def run(self):
        fileutils.makedirs(self.data_out_path)
        self.check_database_renew()
        if not self._need_renew_database:
            try:
                self.check_builtin_members()
                logger.info(
                    'builtin database is the lates version %s,not analyze again', self.dbver)
                return
            except BuiltinModuleNotExistError as ex:
                logger.error("%s", str(ex))
                self._need_renew_database = True
        self.create_builtintypes_members()
        self.update_new_version(self.dbver)
        self.update_last_timestamp()
