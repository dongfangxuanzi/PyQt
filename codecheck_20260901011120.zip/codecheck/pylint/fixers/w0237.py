import re
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintW0237Fixer(PylintFixer):
    '''
    规则说明: 继承方法的参数名称改变了
    '''

    def __init__(self):
        super().__init__('W0237', True)

    def fix_message(self, msg):
        regstr = r"Parameter '(\w+)' has been renamed to '(\w+)' in (overridden|overriding) '(.*)' method"
        res = re.search(regstr, msg.msg)
        if not res:
            return False
        results = res.groups()
        node = self.find_msg_node(msg)
        node_class_name, node_method_name = results[3].split(".")
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and (
            node.name == node_method_name and node.parent.parent.name == node_class_name
        ):
            self.replace_variable_name_in_scope(node, results[1], results[0])
            return True
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and (
            node.name == node_method_name and node.parent.parent.name == node_class_name
        ):
            self.replace_variable_name_in_scope(node.parent, results[1], results[0])
            return True
        return False
