from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintW2301Fixer(PylintFixer):
    '''
    规则说明: 多余的...语句
    '''

    def __init__(self):
        super().__init__('W2301', True)

    def fix_message(self, msg):
        line = msg.line
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Expr) and (
            isinstance(node.value, nodes.Const) and node.value.value == Ellipsis
        ):
            self.delete_text_line(line - 1)
            return True
        return False
