'''
Name:        e1200.py
Purpose:     修复%后面的格式化字符错误
Author:      wukan
Created:     2026-08-15
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from novalapp.python.parser import node_utils
from astroid import nodes
from ...multifixer import MultiOptionFixer
from ...pylint_fix import PylintFixer


class PylintE1200Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:%后面的格式化字符错误
    '''
    LOGGING_FORMAT_FLAGS = "diouxXeEfFgGcrs%a"

    def __init__(self):
        super().__init__('E1200', False)
        MultiOptionFixer.__init__(
            self,
            title='Fix logging unsupported format',
            descr="Please choose one supported format",
            init_options=list(self.LOGGING_FORMAT_FLAGS)
        )

    def fix_message(self, msg):
        res = re.search(
            r"Unsupported logging format character '(.*)' .* at index (\d+) ",
            msg.msg
        )
        fchar, index = res.groups()
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call):
            if node.value.args and node_utils.is_const_type(node.value.args[0], str):
                first_arg = node.value.args[0]
                index = int(index)
                if fchar != first_arg.value[index]:
                    return False
                self.get_selection()
                chars = list(first_arg.value)
                chars[index] = self._options[self.selection]
                const_arg_str = ''
                is_r_quote, str_quote = self.get_line_str_r_quote(first_arg)
                # 字符串被r包裹
                if is_r_quote:
                    const_arg_str += "r"
                const_arg_str += (str_quote + ''.join(chars) + str_quote)
                self.fix_node_text(first_arg, const_arg_str)
                return True
        return False
