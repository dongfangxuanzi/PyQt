from typing import cast
from astroid import nodes
from .r1723 import PylintR1723Fixer
from ...pylint_fix import PylintFixer


class PylintR1705Fixer(PylintR1723Fixer):
    '''
    规则说明:return表达式后多余的else和elif语句
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'R1705', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node.parent, nodes.If):
            scope = cast(nodes.If, node.parent)
            if msg.msg.find('Unnecessary "else" after "return"') != -1:
                return self.delete_backtab_else_statement(scope)
            if msg.msg.find('Unnecessary "elif" after "return"') != -1:
                return self.replace_elif_with_if(scope)
        return False
