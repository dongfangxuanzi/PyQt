import re
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintC2201Fixer(PylintFixer):
    '''
    规则说明:扩展规则,整数比较应该放在比较符号右边
    '''

    def __init__(self):
        super().__init__('C2201', False)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if not isinstance(node, nodes.Compare):
            return False
        res = re.search(r"Comparison should be (.*) \(misplaced-comparison-constant\)", msg.msg)
        repstr = res.groups()[0]
        if node.as_string() == repstr:
            return False
        self.fix_node_text(node, repstr)
        return True
