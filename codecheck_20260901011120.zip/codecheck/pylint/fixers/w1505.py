from astroid import nodes
from novalapp.python.parser.node_utils import infer_all
from novalapp.python.parser.define import PROPERTY_METHOD_NAME
from novalapp.python.parser.node_scope import ScopeFinder
from ...basefix import append_doc_interpreter_path
from ...pylint_fix import PylintFixer


class PylintW1505Fixer(PylintFixer):
    '''
    规则说明: 过期的函数和方法
    '''
    REPLACE_DEPRECATED_METHODS = {
        "logging.warn": "logging.warning",
        "logging.Logger.warn": "logging.Logger.warning",
        "logging.LoggerAdapter.warn": "logging.LoggerAdapter.warning",
        "base64.encodestring": "base64.encodebytes",
        "base64.decodestring": "base64.decodebytes",
        'threading.Thread.getName': ('threading.Thread.name', PROPERTY_METHOD_NAME),
        'threading.Condition.notifyAll': 'threading.Condition.notify_all',
        'threading.currentThread': 'threading.current_thread'
    }

    def __init__(self):
        super().__init__('W1505', True)

    @append_doc_interpreter_path
    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        fix_nodes = list(ScopeFinder.get_parent_nodes_by_classtype(node, nodes.Call))
        for fix_node in fix_nodes:
            func_name = None
            if isinstance(fix_node.func, nodes.Attribute):
                func_name = fix_node.func.attrname
            elif isinstance(fix_node.func, nodes.Name):
                func_name = fix_node.func.name
            else:
                continue
            results = infer_all(fix_node.func)
            for inferred in results:
                qnames = {inferred.qname(), func_name}
                for qname in qnames:
                    if qname in self.REPLACE_DEPRECATED_METHODS:
                        replace_method_qname = self.REPLACE_DEPRECATED_METHODS[qname]
                        method_type = None
                        if isinstance(replace_method_qname, tuple):
                            replace_qname = replace_method_qname[0]
                            method_type = replace_method_qname[1]
                        else:
                            replace_qname = replace_method_qname
                        replace_func_name = replace_qname.split(".")[-1]
                        fixstr = fix_node.func.expr.as_string() + "." + replace_func_name
                        # 类方法转换为类属性
                        if method_type == PROPERTY_METHOD_NAME:
                            self.fix_node_text(fix_node, fixstr)
                        else:
                            self.fix_node_text(fix_node.func, fixstr)
                        return True
        return False


class PylintW4902Fixer(PylintW1505Fixer, PylintFixer):

    def __init__(self):
        PylintFixer.__init__(self, 'W4902', True)
