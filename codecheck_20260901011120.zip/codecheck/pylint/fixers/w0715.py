from astroid import nodes
from novalapp.util import strutils
from novalapp.python.parser import node_utils
from ...pylint_fix import PylintFixer


class PylintW0715Fixer(PylintFixer):
    '''
    规则说明: 字符串格式化要用百分号%,不能使用逗号
    '''

    def __init__(self):
        super().__init__('W0715', True)

    @staticmethod
    def get_call_node(node):
        if isinstance(node, nodes.Call):
            return node
        for child in node.get_children():
            if isinstance(child, nodes.Call):
                return child
        return None

    @staticmethod
    def get_format_arg(args):
        for arg in args:
            if node_utils.is_const_type(arg, str) and arg.value.find("%") != -1:
                return arg.value
        return ''

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        call_node = self.get_call_node(node)
        if call_node is not None:
            format_arg_val = self.get_format_arg(call_node.args)
            if strutils.is_none_empty(format_arg_val):
                return False
            percent_count = format_arg_val.count('%')
            format_args = call_node.args[1:1 + percent_count]
            if not format_args:
                return False
            format_arg_list = []
            for format_arg in format_args:
                format_arg_list.append(format_arg.as_string())
            if len(format_arg_list) == 1:
                fix_arg_str = "'%s'%%%s" % (format_arg_val, ",".join(format_arg_list))
            else:
                fix_arg_str = "'%s'%%(%s)" % (format_arg_val, ",".join(format_arg_list))
            fixstr = '%s(%s)' % (call_node.func.as_string(), fix_arg_str)
            self.fix_node_text(call_node, fixstr)
            return True
        return False
