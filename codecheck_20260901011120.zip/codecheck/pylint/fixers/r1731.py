'''
Name:        wukan.py
Purpose:
Author:      HongYunVM
Created:     2026-05-17
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintR1730Fixer(PylintFixer):
    '''
    规则说明:if表达式if(start>0):start=0,可以用Consider using 'start = min(start, 0)代替'
    '''

    def __init__(self):
        super().__init__('R1730', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r"Consider using '(.*)' instead of unnecessary if block \(consider-using-min-builtin\)",
            msg.msg
        )
        pnode = node.parent
        if isinstance(node, nodes.Compare) and node.ops and (
            node.ops[0] and node.ops[0][0] in ['>', '>='] and isinstance(pnode, nodes.If)
        ):
            if isinstance(node.left, nodes.Name):
                repstr = res.groups()[0]
            else:
                left_attr_str = node.left.as_string()
                cmp_val = node.ops[0][1].value
                repstr = f'{left_attr_str}=min({left_attr_str}, {cmp_val})'
            self.fix_node_text(pnode, repstr)
            return True
        return False


class PylintR1731Fixer(PylintFixer):
    '''
    规则说明:if表达式if(start<0):start=0,可以用Consider using 'start = max(start, 0)代替'
    '''

    def __init__(self):
        super().__init__('R1731', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r"Consider using '(.*)' instead of unnecessary if block \(consider-using-max-builtin\)",
            msg.msg
        )
        pnode = node.parent
        if isinstance(node, nodes.Compare) and node.ops and (
            node.ops[0] and node.ops[0][0] in ['<', '<='] and isinstance(pnode, nodes.If)
        ):
            if isinstance(node.left, nodes.Name):
                repstr = res.groups()[0]
            else:
                left_attr_str = node.left.as_string()
                cmp_val = node.ops[0][1].value
                repstr = f'{left_attr_str}=max({left_attr_str}, {cmp_val})'
            self.fix_node_text(pnode, repstr)
            return True
        return False
