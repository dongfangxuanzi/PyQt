import re
from typing import cast
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintR1723Fixer(PylintFixer):
    '''
    规则说明:break表达式后多余的else和elif语句
    '''

    def __init__(self):
        super().__init__('R1723', True)

    def replace_elif_with_if(self, else_scope):
        orelse = else_scope.orelse
        if not orelse:
            return False
        statement = orelse[0]
        linetext = self.get_line_text(statement.lineno - 1)
        newtext = linetext.replace("elif", "if", 1)
        if linetext != newtext:
            self.replace_line_text(statement.lineno, newtext)
            return True
        return False

    def get_else_line(self, line):
        i = line
        while i > 0:
            line_text = self.get_line_text(i)
            if re.search(r"else\s*:", line_text):
                return i
            i -= 1
        return -1

    def delete_backtab_else_statement(self, else_scope):
        '''
        将else语句向左缩进4个空格,并删除else行
        '''
        orelse = else_scope.orelse
        if not orelse:
            return False
        for statement in orelse:
            # 如果else块内部有复杂的缩进语句,不要自动修复,
            # 让用户手动修复,防止修复出错
            if hasattr(statement, 'body'):
                return False
        for statement in orelse:
            # 将else块内的语句退格
            self.back_text_tab(statement.lineno - 1, statement.col_offset)
        else_line = self.get_else_line(orelse[0].lineno - 1)
        if else_line == -1:
            return False
        # 删除else语句
        self.delete_text_line(else_line)
        return True

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node.parent, nodes.If):
            scope = cast(nodes.If, node.parent)
            if msg.msg.find('Unnecessary "else" after "break"') != -1:
                return self.delete_backtab_else_statement(scope)
            if msg.msg.find('Unnecessary "elif" after "break"') != -1:
                return self.replace_elif_with_if(scope)
        return False


class PylintR1724Fixer(PylintR1723Fixer):
    '''
    规则说明:continue表达式后多余的else和elif语句
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'R1724', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node.parent, nodes.If):
            if msg.msg.find('Unnecessary "elif" after "continue"') != -1:
                return self.replace_elif_with_if(node.parent)
        return False


class PylintW0120Fixer(PylintR1723Fixer):
    '''
    规则说明:for/while循环表达式后多余的else语句
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'W0120', True)

    def fix_message(self, msg):
        scope = self.find_msg_scope(msg)
        if isinstance(scope, (nodes.For, nodes.While)):
            return self.delete_backtab_else_statement(scope)
        return False
