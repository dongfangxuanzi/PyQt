from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintW0101Fixer(PylintFixer):
    '''
    规则说明:永远不能执行或到达的代码段
    '''

    def __init__(self):
        super().__init__('W0101', False)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        prev_node = node.previous_sibling()
        if not isinstance(prev_node, (nodes.Return, nodes.Raise)):
            return False
        self.delete_node(node)
        return True
