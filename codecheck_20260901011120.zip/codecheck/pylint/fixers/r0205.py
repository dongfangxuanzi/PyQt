import re
from ...pylint_fix import PylintFixer


class PylintR0205Fixer(PylintFixer):
    '''
    规则说明:类显式继承object多余
    '''

    def __init__(self):
        super().__init__('R0205', True)

    def fix_message(self, msg):
        line = msg.line
        line_text = self.get_msg_line_text(msg)
        regstr = r'\(\s*object\s*\)'
        if re.search(regstr, line_text):
            replace_text = re.sub(regstr, '', line_text)
            self.replace_line_text(line, replace_text)
            return True
        return False
