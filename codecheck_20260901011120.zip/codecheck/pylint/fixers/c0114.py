'''
Name:        c0114.py
Purpose:     不支持自动插入新文档字符串,如果文件开头有注释,自动将其转换为3引号文档字符串
Author:      wukan
Created:     2026-05-16
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import os
import re
from novalapp.util import fileutils
from novalapp.python.utility import PYTHON_SHEBANG_REGEX
from ...pylint_fix import PylintFixer


class PylintC0114Fixer(PylintFixer):
    '''
    规则说明: 模块缺少文档字符串说明
    '''
    MAX_DOC_LINE = 20

    def __init__(self):
        super().__init__('C0114', True)

    @staticmethod
    def get_fix_comment_line(linestr):
        return linestr.lstrip('#').strip()

    @staticmethod
    def is_encoding_line(linestr):
        return re.match(r'^[ \t\f]*#.*coding[:=][ \t]*([-\w.]+)', linestr)

    @staticmethod
    def is_shebang_line(linestr):
        return PYTHON_SHEBANG_REGEX.match(linestr)

    @classmethod
    def is_matched_doc_comment(cls, filelines):
        match_doc_reg = r'^#\s*(name|author|created|date|modify|modified)\s*:'
        match_doc_comment = False
        for i, linestr in enumerate(filelines):
            if linestr.startswith('#'):
                if re.match(match_doc_reg, linestr, re.I):
                    match_doc_comment = True
            # 只检测文件开头的前f{MAX_DOC_LINE}行注释
            elif i > cls.MAX_DOC_LINE:
                break
        return match_doc_comment

    def file_fix_doc(self, filelines):
        start_line = -1
        end_line = -1
        fixstr = "'''"
        fixstr += os.linesep
        for i, linestr in enumerate(filelines[0:self.MAX_DOC_LINE]):
            if linestr.strip() == "":
                if start_line == -1:
                    continue
                else:
                    break
            elif linestr.startswith('#'):
                if self.is_encoding_line(linestr) or self.is_shebang_line(linestr):
                    continue
                if start_line == -1:
                    start_line = i
                    fixstr += self.get_fix_comment_line(linestr)
                    fixstr += os.linesep
                else:
                    end_line = i + 1
                    fixstr += self.get_fix_comment_line(linestr)
                    fixstr += os.linesep
            else:
                break
        fixstr += "'''"
        fixstr += os.linesep
        start_line = self.get_insert_line()
        self.replace_range_text(start_line + 1, fixstr, 0, end_line + 1, 0)

    def get_insert_line(self):
        return self.get_shebang_encoding_line()

    def fix_message(self, msg):
        self.load_msg_module(msg)
        module = self.get_module()
        if module.doc_node is not None:
            return False
        filecontent = fileutils.get_file_content(msg.filepath)
        lines = filecontent.splitlines()
        match_doc_comment = self.is_matched_doc_comment(lines)
        if not match_doc_comment:
            # 插入新文档字符串不支持自动修复
            if self.is_autofix_msg:
                return False
            self.insert_comment_template()
        else:
            # 自动将文件开头的注释转换成文档字符串
            self.file_fix_doc(lines)
        return True
