'''
Name:        w9002.py
Purpose:     修复断言语句
Author:      wukan
Created:     2026-08-23
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...multifixer import MultiOptionFixer
from ...codeutils import DEFAULT_TAB_BLANKS, get_node_col_offset_blanks


class PylintW9002Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明: 发布代码中使用断言
    '''

    def __init__(self):
        super().__init__('W9002', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Fix assert statement',
            descr='Choose one fixer option',
            init_options=[
                'Delete assert statement',
                'Replace with if statement and raise exception'
            ]
        )

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Assert):
            if self.is_autofix_msg:
                self._sel = 0
            self.get_selection()
            if self.selection == 0:
                self.delete_node(node, check_deleteable=True)
            elif self.selection == 1:
                replace_text = "if not (" + node.test.as_string() + "):"
                self.fix_node_text(node, replace_text)
                lineno = node.lineno + 1
                offset_blanks = get_node_col_offset_blanks(node)
                offset_blanks += DEFAULT_TAB_BLANKS
                if node.fail is None:
                    fixstr = offset_blanks + "raise AssertionError\n"
                    self.add_range_text(lineno, 0, fixstr)
                else:
                    fixstr = offset_blanks + f"raise AssertionError({node.fail.as_string()})\n"
                    self.add_range_text(lineno, 0, fixstr)
            return True
        return False
