'''
Name:        w1201.py
Purpose:
Author:      wukan
Created:     2026-05-17
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from novalapp.python.parser import node_utils
from ...pylint_fix import PylintFixer


class PylintW1201Fixer(PylintFixer):
    '''
    规则说明:日志打印字符串使用可变参数,而不是格式化%字符串的方式
    '''

    def __init__(self):
        super().__init__('W1201', True)

    @classmethod
    def get_op_args(cls, arg, lazy_args: list):
        '''
        获取懒插值日志参数
        '''
        if node_utils.is_const_type(arg.left, str):
            lazy_args.append(arg.right)
            lazy_args.append(arg.left)
            return
        if isinstance(arg.left, nodes.BinOp) and arg.left.op == '+':
            lazy_args.append(arg.right)
            cls.get_op_args(arg.left, lazy_args)

    def fix_lazy_arg(self, arg):
        '''
        修复使用缺省计算值,不用懒插值的日志
        '''
        lazy_args = []
        self.get_op_args(arg, lazy_args)
        first_const_arg = lazy_args.pop(-1)
        qchar = self.get_line_str_quote(first_const_arg)
        leftstr = first_const_arg.value
        fix_str = leftstr
        right_args = []
        for lazy_arg in lazy_args[::-1]:
            if node_utils.is_const_type(lazy_arg, str):
                leftstr += lazy_arg.value
            else:
                leftstr += "%s"
                right_args.append(lazy_arg.as_string())
        fix_str = qchar + leftstr + qchar + "," + ",".join(right_args)
        self.fix_node_text(arg, fix_str)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call):
            if len(node.value.args) == 1 and isinstance(node.value.args[0], nodes.BinOp):
                op = node.value.args[0].op
                arg = node.value.args[0]
                if op == '%':
                    rightstr = arg.right.as_string()
                    if isinstance(arg.right, nodes.Tuple):
                        rightstr = rightstr.strip()[1:-1]
                    fix_str = arg.left.as_string() + "," + rightstr
                    self.fix_node_text(arg, fix_str)
                    return True
                if op == '+':
                    self.fix_lazy_arg(arg)
                    return True
        return False
