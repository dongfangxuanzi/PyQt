import re
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintC0204Fixer(PylintFixer):
    '''
    规则说明:类元方法以mcs作为第一个参数名
    '''

    def __init__(self):
        super().__init__('C0204', False)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        res = re.search(
            r"Metaclass class method (.*) should have 'mcs' as first argument \(bad-mcs-classmethod-argument\)",
            msg.msg
        )
        nodename = res.groups()[0]
        if isinstance(node, nodes.Name) and isinstance(node.parent, nodes.FunctionDef) and (
            nodename == node.name
        ):
            if node.parent.args.args:
                first_arg = node.parent.args.args[0]
                if isinstance(first_arg, nodes.AssignName) and first_arg.name == 'mcs':
                    return False
                self.fix_node_text(first_arg, "mcs")
                return True
        return False
