
class GitNotInstalledError(Exception):
    '''未安装git'''


class ProjectNotRepositoryError(Exception):
    '''项目代码未经git管理'''


class ProjectFileNotCommitError(Exception):
    '''项目代码未提交'''


class FixfileError(Exception):
    '''修复文件错误'''


class Autopep8NotInstalledError(RuntimeError):
    '''
    autopep8工具未安装或者正确安装
    '''


class Flake8EradicateNotInstalledError(RuntimeError):
    '''
    flake8-eradicate工具/模块未安装
    '''


class LineEmptyNodeError(Exception):
    '''行列语法节点为空'''


class InvalidOptionIndexError(Exception):
    '''非法选项值'''
