import os
import re
from novalapp.util import ui_utils, utils, timeutils
from novalapp.lib.pyqt import (
    QLabel,
    QHBoxLayout,
    QCheckBox,
    Qt,
    QListWidget,
    QMessageBox,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QAbstractItemView,
    QHeaderView,
    QCursor,
    pyqtSignal,
    QRadioButton,
    QButtonGroup,
    QVBoxLayout,
    QDateTimeEdit,
    QDate,
    QDateTime
)
from novalapp.util.transfer import FiledownloadSerivce
from novalapp.project.wizard.page import BitmapTitledContainerWizardPage
from novalapp.python.project.property.runui import CommonInterpreterOptionPanel
from novalapp import _, get_app, newid
from novalapp.python.interpreter.exceptions import (
    InterpretertoolNotExistError,
    InterpreterPathNotExistError
)
from novalapp.python.interpreter.interpreterconfiguration.pipenv import InstallPackagesDialog
from novalapp.bars.menubar import NewQMenu
from novalapp.util import fileutils, pathutils
from novalapp.widgets.labels import LinkLabel
from novalapp.python.interpreter.interpreter import BuiltinPythonInterpreter, PythonInterpreter
from novalapp.python.interpreter.interpretermanager import InterpreterManager
from novalapp.preference.manager import GetOptionName
from novalapp.preference.preference import PreferenceDialog
from novalapp.python import prog_lang_ext
from .toolmanager import CodecheckToolManager
from .codeutils import get_tools_data_path, FilesregType, ScanMode
from . import configkeys
from .codeutils import get_file_excludes_reg, check_git_plugin_installed
from .strings import MESSAGE_VIEW_NAME, PYLINT_TOOL_NAME, FLAKE8_TOOL_NAME
from .pkgres import get_pylint_rc_path


def GetEnabledFlag(enabled):
    if enabled:
        return _("Disabled")
    return _("Enabled")


class CodecheckOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    代码检查配置面板
    """
    MAX_PATH_LENGTH = 40
    ID_COPY_TOOL_NAME = newid()
    ID_COPY_TOOL_VERSION = newid()
    ID_COPY_TOOL_PATH = newid()
    ID_GOTO_TOOL_PATH = newid()
    SIG_DOWNLOAD_ERROR = pyqtSignal(str)
    SIG_RELOAD_TOOLS = pyqtSignal()

    def __init__(self, parent, **kwargs):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self._plugin = kwargs.get('plugin')
        self.layout.setAlignment(Qt.AlignTop)

        self.project_repository_chkbox = QCheckBox(
            _("Codecheck project must be a git repository"))
        self.project_repository_chkbox.setChecked(utils.profile_get_int(
            configkeys.CODECHECK_PROJECT_MUSTBE_REPOSITORY_KEY, True))
        self.layout.addWidget(self.project_repository_chkbox)

        self.autorepair_chkbox = QCheckBox(
            _("Code must be committed before automatic repair is enabled"))
        self.autorepair_chkbox.setChecked(utils.profile_get_int(
            configkeys.PROJECT_FILES_MUSTBE_COMMITED_KEY, True))
        self.layout.addWidget(self.autorepair_chkbox)

        self.check_running_chkbox = QCheckBox(
            _("Check codecheck/fix process running when application exit."))
        self.check_running_chkbox.setChecked(utils.profile_get_int(
            configkeys.CHECK_CODECHECK_PROCESS_RUNNING_KEY, True))
        self.layout.addWidget(self.check_running_chkbox)

        self.close_opendoc_chkbox = QCheckBox(
            _("Close the open document after the automatic repair is complete"))
        self.close_opendoc_chkbox.setChecked(utils.profile_get_int(
            configkeys.CLOSE_OPENDOC_KEY, True))
        self.layout.addWidget(self.close_opendoc_chkbox)

        self.check_file_syntax_chkbox = QCheckBox(
            _("Check file syntax after each warning is fixed"))
        self.check_file_syntax_chkbox.setChecked(utils.profile_get_int(
            configkeys.CHECK_FILE_SYNTAX_KEY, True))
        self.layout.addWidget(self.check_file_syntax_chkbox)

        self.autofix_file_chkbox = QCheckBox(
            _("Auto fix file When file is saved"))
        self.autofix_file_chkbox.setChecked(utils.profile_get_int(
            configkeys.AUTOFIX_FILE_SAVE_KEY, False))
        self.layout.addWidget(self.autofix_file_chkbox)

        self.check_metrics_chkbox = QCheckBox(
            _("Check code metrics"))
        self.check_metrics_chkbox.setChecked(utils.profile_get_int(
            configkeys.CHECK_CODE_METRICS_KEY, False))
        self.layout.addWidget(self.check_metrics_chkbox)

        self.display_realtime_check_result_chkbox = QCheckBox(
            _("Display real-time check result in editor"))
        self.display_realtime_check_result_chkbox.setChecked(utils.profile_get_int(
            configkeys.DISPLAY_REALTIME_CHECK_RESULT_KEY, False))
        self.layout.addWidget(self.display_realtime_check_result_chkbox)

        self.skip_pyi_file_extension_chkbox = QCheckBox(
            _("Skip files endswith `.%s` extension") % prog_lang_ext.PYTHON_PYI_FILE_EXT)
        self.skip_pyi_file_extension_chkbox.setChecked(utils.profile_get_int(
            configkeys.SKIP_PYI_EXT_FILES_KEY, True))
        self.layout.addWidget(self.skip_pyi_file_extension_chkbox)

        pylint_tool = CodecheckToolManager.manager().find_tool(PYLINT_TOOL_NAME)
        pylint_tool.update_cfg_file(get_pylint_rc_path())

        self.load_unsafe_extension_chkbox = QCheckBox(_("Load unsafe extension modules"))
        self.load_unsafe_extension_chkbox.setChecked(
            self.is_load_unsafe_extension_checked(pylint_tool)
        )
        self.layout.addWidget(self.load_unsafe_extension_chkbox)

        self.commented_out_string_chkbox = QCheckBox(_("String commented out code"))
        self.commented_out_string_chkbox.setChecked(
            self.is_string_commented_out_checked(pylint_tool)
        )
        self.layout.addWidget(self.commented_out_string_chkbox)

        columns = [_('Name'), _('Version'), _(
            'Path'), _('Status'), _('Action')]
        self.tableview = QTableWidget(1, len(columns), self)
        self.tableview.setColumnWidth(0, 80)
        self.tableview.setColumnWidth(1, 80)
        self.tableview.setColumnWidth(3, 60)
        self.tableview.setColumnWidth(4, 50)
        self.tableview.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableview.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableview.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.layout.addWidget(self.tableview)
        self.tableview.verticalHeader().hide()
        self.tableview.setHorizontalHeaderLabels(columns)
        self.tableview.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tableview.customContextMenuRequested.connect(self.on_context_menu)
        # 表格右键弹出菜单
        self.menu = None
        self._installed_tools_name = None
        self._is_installing_codecheck_tool = False
        self.load_tools()
        self.SIG_DOWNLOAD_ERROR.connect(self.download_url_error)
        self.SIG_RELOAD_TOOLS.connect(self.reload_tools)

    def on_context_menu(self):
        row = self.tableview.currentRow()
        if row == -1:
            return
        if self.menu is None:
            self.menu = NewQMenu(self)
            self.menu.Append(
                CodecheckOptionPanel.ID_COPY_TOOL_NAME,
                _("Copy Name"),
                handler=lambda: self.ProcessEvent(
                    CodecheckOptionPanel.ID_COPY_TOOL_NAME)
            )
            self.menu.Append(
                CodecheckOptionPanel.ID_COPY_TOOL_VERSION,
                _("Copy Version"),
                handler=lambda: self.ProcessEvent(
                    CodecheckOptionPanel.ID_COPY_TOOL_VERSION)
            )
            self.menu.Append(
                CodecheckOptionPanel.ID_COPY_TOOL_PATH,
                _("Copy Path"),
                handler=lambda: self.ProcessEvent(
                    CodecheckOptionPanel.ID_COPY_TOOL_PATH)
            )
            self.menu.Append(
                CodecheckOptionPanel.ID_GOTO_TOOL_PATH,
                _("Open Path in Explorer"),
                handler=lambda: self.ProcessEvent(
                    CodecheckOptionPanel.ID_GOTO_TOOL_PATH)
            )
        self.menu.popup(QCursor.pos())

    def ProcessEvent(self, event_id):
        row = self.tableview.currentRow()
        tool = CodecheckToolManager.manager().CHECK_TOOLS[row]
        if event_id == CodecheckOptionPanel.ID_COPY_TOOL_NAME:
            ui_utils.copytoclipboard(tool.name)
            return True
        if event_id == CodecheckOptionPanel.ID_COPY_TOOL_VERSION:
            ui_utils.copytoclipboard(tool.version)
            return True
        if event_id == CodecheckOptionPanel.ID_COPY_TOOL_PATH:
            # 路径可能显示省略号,因此不能使用界面上显示的路径值
            ui_utils.copytoclipboard(tool.path)
            return True
        if event_id == CodecheckOptionPanel.ID_GOTO_TOOL_PATH:
            self.goto_path(tool.path)
            return True

    def goto_path(self, path):
        pathutils.safe_open_file_directory(path)

    def reload_tools(self):
        self.load_tools()
        utils.get_logger().info('reload codecheck tools info success')
        utils.get_logger().info(
            'install/update codecheck tool `%s` success',
            self._installed_tools_name
        )
        self._is_installing_codecheck_tool = False

    def load_tools(self):
        tools_count = len(CodecheckToolManager.manager().CHECK_TOOLS)
        utils.get_logger().info('load codecheck tools count is %d', tools_count)
        if 0 == tools_count:
            QMessageBox.warning(self, _('Warning'), _('There is no active codecheck tools'))
            return
        self.tableview.setRowCount(tools_count)
        for i, check_tool in enumerate(CodecheckToolManager.manager().CHECK_TOOLS):
            nameitem = QTableWidgetItem(check_tool.name)
            self.tableview.setItem(i, 0, nameitem)

            versionitem = QTableWidgetItem(check_tool.version)
            versionitem.setTextAlignment(Qt.AlignCenter)
            self.tableview.setItem(i, 1, versionitem)

            # 路径过长显示省略号
            path = check_tool.path
            if len(path) > CodecheckOptionPanel.MAX_PATH_LENGTH:
                path = path[0:CodecheckOptionPanel.MAX_PATH_LENGTH] + "..."
            pathitem = QTableWidgetItem(path)
            self.tableview.setItem(i, 2, pathitem)
            if not check_tool.enabled:
                utils.get_logger().warning('codecheck tool %s is disabled', check_tool.name)
            default_button = QPushButton(GetEnabledFlag(check_tool.enabled))
            default_button.setDown(True)  # 默认为按下的状态
            default_button.setStyleSheet('QPushButton{margin:3px};')
            default_button.clicked.connect(self.update_tool_status)
            self.tableview.setCellWidget(i, 3, default_button)

            if check_tool.path == "":
                install_update_label = LinkLabel(
                    _("Install"), self.install_update_tool, alignment=Qt.AlignCenter)
            else:
                install_update_label = LinkLabel(
                    _("Update"), self.install_update_tool, alignment=Qt.AlignCenter)
            self.tableview.setCellWidget(i, 4, install_update_label)

    def install_update_tool(self):
        label = self.sender()
        row = self.tableview.currentRow()
        tool = CodecheckToolManager.manager().CHECK_TOOLS[row]
        self._installed_tools_name = tool.name
        self._is_installing_codecheck_tool = True
        if tool.version == BuiltinPythonInterpreter.UNKNOWN_VERSION_NAME:
            assert (label.text().find(_("Install")) != -1)
            if self._plugin.use_internal_interpreter:
                self.install_internal_packages()
            else:
                interpreter = InterpreterManager.manager().ShowChooseInterpreterDlg(self)
                if not interpreter or interpreter.IsBuiltIn:
                    return
                try:
                    interpreter.find_tool(tool.name)
                    CodecheckToolManager.manager().register_python_tools(interpreter)
                except InterpretertoolNotExistError as ex:
                    utils.get_logger().error(
                        'find tool %s in interpreter "%s" error:%s',
                        tool.name,
                        interpreter.name,
                        str(ex)
                    )
                    dlg = InstallPackagesDialog(
                        get_app().GetTopWindow(),
                        interpreter,
                        pkg_name=tool.name,
                        install_args='--user %s' % tool.name,
                        autorun=False
                    )
                    dlg.exec_()
                finally:
                    self.reload_tools()
        else:
            assert (label.text().find(_("Update")) != -1)
            if self._plugin.use_internal_interpreter:
                QMessageBox.information(
                    self,
                    get_app().GetAppName(),
                    _('There is no available update package')
                )
            else:
                dlg = InstallPackagesDialog(
                    get_app().GetTopWindow(),
                    tool.interpreter,
                    pkg_name=tool.name,
                    install_args='-U %s' % tool.name,
                    autorun=True
                )
                dlg.exec_()

    def install_internal_packages(self):
        filename = "tools.zip"
        fileurl = ""
        if utils.is_windows():
            fileurl = ""
        FiledownloadSerivce().download_file(fileurl, filename, self.end_download, self)

    def end_download(self, package_path, parent):
        tools_data_path = get_tools_data_path()
        fileutils.makedirs(tools_data_path)
        utils.get_logger().info('download tools file %s success..', package_path)
        try:
            fileutils.unzip(package_path, tools_data_path)
        except Exception:
            utils.get_logger().exception(
                'unzip file %s to path %s fail exception',
                package_path,
                tools_data_path
            )
        utils.get_logger().info(
            'unzip tools file %s to dest path %s success..',
            package_path,
            tools_data_path
        )
        venv_cfg_path = os.path.join(
            tools_data_path, r"python\pylint\venv\pyvenv.cfg")
        if not os.path.exists(venv_cfg_path):
            return
        if utils.is_windows():
            home_path = os.path.join(tools_data_path, r"python\python3\win")
            base_executable = os.path.join(home_path, "python.exe")
        PythonInterpreter.update_venv_cfg(venv_cfg_path, "home", home_path)
        PythonInterpreter.update_venv_cfg(
            venv_cfg_path, "base-executable", base_executable)
        utils.get_logger().info(
            'update interpreter base home path %s to pyvenv cfg file %s success',
            home_path,
            venv_cfg_path
        )
        internal_interpreter = self._plugin.load_internal_interpreter(self)
        if internal_interpreter is not None:
            utils.get_logger().info(
                'load internal interpreter `%s` info success',
                internal_interpreter.name
            )
            self.SIG_RELOAD_TOOLS.emit()

    def download_url_error(self, error_msg):
        QMessageBox.critical(self, _("Error"), _(
            "Download fail:%s") % error_msg)

    def update_tool_status(self):
        button = self.sender()
        row = self.tableview.currentRow()
        tool = CodecheckToolManager.manager().CHECK_TOOLS[row]
        tool.enabled = not tool.enabled
        button.setText(GetEnabledFlag(tool.enabled))
        button.setDown(tool.enabled)

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        if self._is_installing_codecheck_tool:
            QMessageBox.warning(self, _('Warning'), _(
                'Please wait a monment for end of install/update `%s` tool') % self._installed_tools_name)
            return False
        utils.profile_set(configkeys.CODECHECK_PROJECT_MUSTBE_REPOSITORY_KEY,
                          self.project_repository_chkbox.isChecked())
        utils.profile_set(configkeys.PROJECT_FILES_MUSTBE_COMMITED_KEY,
                          self.autorepair_chkbox.isChecked())
        utils.profile_set(configkeys.CHECK_CODECHECK_PROCESS_RUNNING_KEY,
                          self.check_running_chkbox.isChecked())

        utils.profile_set(configkeys.CHECK_FILE_SYNTAX_KEY,
                          self.check_file_syntax_chkbox.isChecked())

        utils.profile_set(configkeys.CLOSE_OPENDOC_KEY,
                          self.close_opendoc_chkbox.isChecked())

        utils.profile_set(configkeys.AUTOFIX_FILE_SAVE_KEY,
                          self.autofix_file_chkbox.isChecked())
        utils.profile_set(configkeys.CHECK_CODE_METRICS_KEY,
                          self.check_metrics_chkbox.isChecked())
        utils.profile_set(configkeys.DISPLAY_REALTIME_CHECK_RESULT_KEY,
                          self.display_realtime_check_result_chkbox.isChecked())
        utils.profile_set(configkeys.SKIP_PYI_EXT_FILES_KEY,
                          self.skip_pyi_file_extension_chkbox.isChecked())
        self.write_unsafe_extension_value()
        self.write_string_commented_out_value()
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            utils.profile_set(
                "%s%s" % (check_tool.name, configkeys.TOOL_STATUS_KEY), check_tool.enabled)
        return True

    def is_load_unsafe_extension_checked(self, pylint_tool):

        key_section = pylint_tool.get_key_section(pylint_tool.CFG_UNSAFE_LOAD_EXTENSION_KEY)
        value = pylint_tool.get_section_key_value(
            key_section,
            pylint_tool.CFG_UNSAFE_LOAD_EXTENSION_KEY
        )
        return value == 'yes'

    def is_string_commented_out_checked(self, pylint_tool):
        key_section = pylint_tool.get_key_section(pylint_tool.STRING_COMMENTED_OUT_KEY)
        if key_section is None:
            return False
        value = pylint_tool.get_section_key_value(
            key_section,
            pylint_tool.STRING_COMMENTED_OUT_KEY
        )
        return value == 'yes'

    def write_unsafe_extension_value(self):
        pylint_tool = CodecheckToolManager.manager().find_tool(PYLINT_TOOL_NAME)
        key_section = pylint_tool.get_key_section(pylint_tool.CFG_UNSAFE_LOAD_EXTENSION_KEY)
        key_value = 'yes' if self.load_unsafe_extension_chkbox.isChecked() else 'no'
        is_key_value_changed = pylint_tool.is_cfg_key_value_changed(
            key_section,
            pylint_tool.CFG_UNSAFE_LOAD_EXTENSION_KEY,
            key_value
        )
        if is_key_value_changed:
            pylint_tool.write_key_section_value(
                key_section,
                pylint_tool.CFG_UNSAFE_LOAD_EXTENSION_KEY,
                key_value
            )

    def write_string_commented_out_value(self):
        pylint_tool = CodecheckToolManager.manager().find_tool(PYLINT_TOOL_NAME)
        key_section, sections = pylint_tool.get_key_sections(pylint_tool.STRING_COMMENTED_OUT_KEY)
        key_value = 'yes' if self.commented_out_string_chkbox.isChecked() else 'no'
        if key_section is None:
            is_key_value_changed = True
            key_section = sections[-1]
        else:
            is_key_value_changed = pylint_tool.is_cfg_key_value_changed(
                key_section,
                pylint_tool.STRING_COMMENTED_OUT_KEY,
                key_value
            )
        if is_key_value_changed:
            pylint_tool.write_key_section_value(
                key_section,
                pylint_tool.STRING_COMMENTED_OUT_KEY,
                key_value
            )


class CodecheckPropertyPanel(CommonInterpreterOptionPanel):
    """description of class"""

    QDATE_TIME_FORMAT = "yyyy-MM-dd"

    def __init__(self, parent, item, current_project):
        super().__init__()
        self.layout.setAlignment(Qt.AlignTop)
        self.enable_codecheck_checkbox = QCheckBox(_("Use codecheck"))
        self.enable_codecheck_checkbox.setChecked(utils.profile_get_int(
            current_project.GetKey(configkeys.USE_CODECHECK_PROJECT_KEY), True))
        self.layout.addWidget(self.enable_codecheck_checkbox)
        self.enable_codecheck_checkbox.clicked.connect(self.enable_codecheck)

        self.enable_fix2to3_chkbox = QCheckBox(
            _("Enable fix python2 code to python3"))
        self.enable_fix2to3_chkbox.setChecked(utils.profile_get_int(
            current_project.GetKey(configkeys.ENABLE_FIX_2TO3_KEY), False))
        self.layout.addWidget(self.enable_fix2to3_chkbox)

        self.codecheck_workdir_checkbox = QCheckBox(
            _('Use current project path as codecheck work directory')
        )
        self.codecheck_workdir_checkbox.setChecked(utils.profile_get_int(
            current_project.GetKey(configkeys.CODECHECK_WORKDIR_PROJECT_KEY), True))
        self.layout.addWidget(self.codecheck_workdir_checkbox)

        hbox_layout = QHBoxLayout()
        self.button_group = QButtonGroup()
        self.include_files_radio = QRadioButton(_('Include'))
        self.button_group.addButton(self.include_files_radio)
        self.include_files_radio.clicked.connect(self.update_files_reg)
        file_reg_type = utils.profile_get_int(
            current_project.GetKey(configkeys.FILES_REGTYPE_KEY), -1)
        if file_reg_type == FilesregType.INCLUDE_FILES.value:
            self.include_files_radio.setChecked(True)
        hbox_layout.addWidget(self.include_files_radio)

        self.exclude_files_radio = QRadioButton(_('Exclude'))
        self.button_group.addButton(self.exclude_files_radio)
        self.exclude_files_radio.clicked.connect(self.update_files_reg)
        if file_reg_type == FilesregType.EXCLUDE_FILES.value:
            self.exclude_files_radio.setChecked(True)
        hbox_layout.addWidget(self.exclude_files_radio)

        hbox_layout.addWidget(QLabel(_('these files') + ":"))
        self.files_reg_ctrl = QLineEdit()
        self.files_reg_ctrl.setPlaceholderText(
            _('Input regular expressions to filter files'))

        hbox_layout.addWidget(self.files_reg_ctrl)
        self.test_btn = QPushButton(_("Test regex"))
        self.test_btn.clicked.connect(self.test_regex)
        hbox_layout.addWidget(self.test_btn)
        self.layout.addLayout(hbox_layout)

        vbox_layout = QVBoxLayout()
        vbox_layout.addWidget(QLabel(_('Check modes') + ":"))

        hbox_layout = QHBoxLayout()
        hbox_layout.setAlignment(Qt.AlignLeft)
        self.changed_files_radio = QRadioButton(_('Changed files'))
        self.changed_files_radio.setToolTip(
            _('Check changed files, if no changes, Check last commit changed files')
        )

        self.changed_files_radio.toggled.connect(
            lambda: self.update_datetime_edit(self.changed_files_radio)
        )

        scan_mode = current_project.get_int(
            configkeys.SCAN_MODE_KEY,
            ScanMode.FULL_FILES_MODE.value
        )

        hbox_layout.addWidget(self.changed_files_radio)

        self.full_files_radio = QRadioButton(_('Full files'))
        self.full_files_radio.setToolTip(_("Check full files"))
        # toggled信号与槽函数绑定
        self.full_files_radio.toggled.connect(
            lambda: self.update_datetime_edit(self.full_files_radio)
        )

        hbox_layout.addWidget(self.full_files_radio)

        self.time_section_files_radio = QRadioButton(_('Timespan files'))
        self.time_section_files_radio.setToolTip(_("Check time span files"))
        self.time_section_files_radio.toggled.connect(
            lambda: self.update_datetime_edit(self.time_section_files_radio)
        )

        hbox_layout.addWidget(self.time_section_files_radio)

        vbox_layout.addLayout(hbox_layout)
        # 指定当前地日期为控件的日期，注意没有指定时间
        self.datetime_edit = QDateTimeEdit(QDate.currentDate(), self)
        self.datetime_edit.setDisplayFormat(self.QDATE_TIME_FORMAT)
        # 允许弹出日历控件
        self.datetime_edit.setCalendarPopup(True)
        vbox_layout.addWidget(self.datetime_edit)

        if scan_mode == ScanMode.CHANGED_FILES_MODE.value:
            self.changed_files_radio.setChecked(True)
        elif scan_mode == ScanMode.FULL_FILES_MODE.value:
            self.full_files_radio.setChecked(True)
        elif scan_mode == ScanMode.TIME_SECTION_FILES_MODE.value:
            self.time_section_files_radio.setChecked(True)
        base_timestamp = utils.profile_get_int(
            current_project.GetKey(configkeys.BASE_TIMESTAMP_KEY),
            -1
        )
        if base_timestamp != -1:
            timestr = timeutils.timestamp_to_timestr(base_timestamp)
            utils.get_logger().debug("timespan mode base datetime is %s", timestr)
            dtime = QDateTime.fromString(timestr, self.QDATE_TIME_FORMAT)
            self.time_section_files_radio.setToolTip(_("Check files after date:%s") % timestr)
            self.datetime_edit.setDateTime(dtime)
        self.layout.addLayout(vbox_layout)

        self.plugin = None
        self.current_project = current_project
        self.enable_codecheck()
        self.update_files_reg()

    def update_datetime_edit(self, radio_button):
        if radio_button == self.time_section_files_radio and self.time_section_files_radio.isChecked():
            self.datetime_edit.setVisible(True)
        else:
            self.datetime_edit.setVisible(False)

    def update_files_reg(self):
        if self.exclude_files_radio.isChecked():
            self.files_reg_ctrl.setText(utils.profile_get(
                self.current_project.GetKey(configkeys.CODECHECK_EXCLUDE_FILES_KEY), ""))
            self.test_btn.setEnabled(True)
        elif self.include_files_radio.isChecked():
            self.files_reg_ctrl.setText(utils.profile_get(
                self.current_project.GetKey(configkeys.CODECHECK_INCLUDE_FILES_KEY), ""))
            self.test_btn.setEnabled(True)
        else:
            self.test_btn.setEnabled(False)

    def enable_codecheck(self):
        if self.enable_codecheck_checkbox.isChecked():
            self.include_files_radio.setEnabled(True)
            self.exclude_files_radio.setEnabled(True)
            self.files_reg_ctrl.setEnabled(True)
            self.enable_fix2to3_chkbox.setEnabled(True)
            self.test_btn.setEnabled(True)
            self.changed_files_radio.setEnabled(True)
            self.full_files_radio.setEnabled(True)
            self.time_section_files_radio.setEnabled(True)
        else:
            self.files_reg_ctrl.setEnabled(False)
            self.enable_fix2to3_chkbox.setEnabled(False)
            self.test_btn.setEnabled(False)
            self.include_files_radio.setEnabled(False)
            self.exclude_files_radio.setEnabled(False)
            self.changed_files_radio.setEnabled(False)
            self.full_files_radio.setEnabled(False)
            self.time_section_files_radio.setEnabled(False)

    def test_regex(self):
        text = self.files_reg_ctrl.text().strip()
        if text == "":
            QMessageBox.information(self, get_app().GetAppName(), _(
                "Please input a valid reg text"))
            return
        regstr = get_file_excludes_reg(text)
        matched_files = []
        for filepath in self.current_project.GetModel().filePaths:
            if re.search(regstr, filepath, re.I):
                matched_files.append(filepath)
        matched_files_count = len(matched_files)
        if matched_files_count == 0:
            QMessageBox.information(
                self, get_app().GetAppName(), _("there is no matched files"))
        elif matched_files_count > 50:
            QMessageBox.information(self, get_app().GetAppName(), _(
                "there is total %d matched files") % matched_files_count)
        else:
            if self.include_files_radio.isChecked():
                QMessageBox.information(self, get_app().GetAppName(), _(
                    "Files below will be included:\n") + ",".join(matched_files))
            else:
                QMessageBox.information(self, get_app().GetAppName(), _(
                    "Files below will be excluded:\n") + ",".join(matched_files))

    def set_plugin(self, plugin):
        self.plugin = plugin

    def OnOK(self, options_dialog):
        if self.get_current_interpreter() is None:
            return True
        codecheck_key = self.current_project.GetKey(
            configkeys.USE_CODECHECK_PROJECT_KEY)
        utils.profile_set(
            codecheck_key, self.enable_codecheck_checkbox.isChecked())
        if self.exclude_files_radio.isChecked():
            utils.profile_set(self.current_project.GetKey(configkeys.FILES_REGTYPE_KEY),
                              FilesregType.EXCLUDE_FILES.value)
            utils.profile_set(self.current_project.GetKey(configkeys.CODECHECK_EXCLUDE_FILES_KEY),
                              self.files_reg_ctrl.text().strip())
        elif self.include_files_radio.isChecked():
            utils.profile_set(self.current_project.GetKey(configkeys.FILES_REGTYPE_KEY),
                              FilesregType.INCLUDE_FILES.value)
            utils.profile_set(self.current_project.GetKey(configkeys.CODECHECK_INCLUDE_FILES_KEY),
                              self.files_reg_ctrl.text().strip())
        utils.profile_set(
            self.current_project.GetKey(configkeys.ENABLE_FIX_2TO3_KEY),
            self.enable_fix2to3_chkbox.isChecked()
        )
        utils.profile_set(
            self.current_project.GetKey(configkeys.CODECHECK_WORKDIR_PROJECT_KEY),
            self.codecheck_workdir_checkbox.isChecked()
        )
        if self.changed_files_radio.isChecked():
            try:
                # 检查gitcli插件是否安装
                check_git_plugin_installed()
            except RuntimeError as ex:
                QMessageBox.information(
                    self,
                    get_app().GetAppName(),
                    str(ex)
                )
                return False
            self.current_project.set_value(
                configkeys.SCAN_MODE_KEY,
                ScanMode.CHANGED_FILES_MODE.value
            )
        elif self.full_files_radio.isChecked():
            self.current_project.set_value(configkeys.SCAN_MODE_KEY, ScanMode.FULL_FILES_MODE.value)
        elif self.time_section_files_radio.isChecked():
            self.current_project.set_value(
                configkeys.SCAN_MODE_KEY,
                ScanMode.TIME_SECTION_FILES_MODE.value
            )
            # 日期时间
            date_time = self.datetime_edit.dateTime()
            utils.profile_set(self.current_project.GetKey(configkeys.BASE_TIMESTAMP_KEY),
                              int(date_time.toTime_t()))
        messageviewer = get_app().MainFrame.GetView(MESSAGE_VIEW_NAME)
        messageviewer.doc = self.current_project
        messageviewer.update_state()
        return True


class CodecheckOptionPage(BitmapTitledContainerWizardPage):
    """
    Creates the calculators interface
    @todo: Dissable << and >> when floating values are present
    @todo: When integer values overflow display convert to scientific notation
    @todo: Keybindings to numpad and enter key
    """

    def __init__(self, parent):
        """Initialiases the calculators main interface"""
        BitmapTitledContainerWizardPage.__init__(self, parent, ("New Codecheck Project Wizard"), _(
            "Setup Options\nPlease Specify option of your Codecheck setup"), "python_logo.png")
        self.can_finish = False

    def CreateContent(self, content_frame, **kwargs):
        hbox = QHBoxLayout()
        hbox.addWidget(QLabel(_('Choose codecheck tools') + ":"))
        self.listbox = QListWidget()
        tools = [FLAKE8_TOOL_NAME, PYLINT_TOOL_NAME]
        for i, tool in enumerate(tools):
            self.listbox.addItem(tool)
            listitem = self.listbox.item(i)
            listitem.setCheckState(Qt.Unchecked)
        hbox.addWidget(self.listbox)
        content_frame.addLayout(hbox)

    def Finish(self):
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            tool = CodecheckToolManager.manager().find_tool(listitem.text())
            if listitem.checkState() == Qt.Checked:
                tool.enabled = True
            else:
                tool.enabled = False
        return True

    def Validate(self):
        prev_page = self.GetPrev()
        selections = []
        for i in range(self.listbox.count()):
            listitem = self.listbox.item(i)
            toolname = listitem.text()
            if listitem.checkState() == Qt.Checked:
                selections.append(toolname)
        interpreter = prev_page.get_select_interpreter()
        if not selections:
            QMessageBox.information(self, get_app().GetAppName(), _(
                "Please choose at least one tool"))
            return False
        for name in selections:
            try:
                if not interpreter.GetInstallPackage(name):
                    QMessageBox.information(
                        get_app().GetTopWindow(),
                        _("Tool '%s' not installed") % name,
                        _("Tool '%s' not installed, you would like to use.\nTo set this, go to Tools-->Options and use the 'Codecheck' panel to install this tool.\n") % name
                    )
                    preference_dlg = PreferenceDialog(
                        get_app().MainFrame,
                        selection=GetOptionName(_("Misc"), "CodeCheck")
                    )
                    preference_dlg.exec_()
                    return False
            except InterpreterPathNotExistError as ex:
                QMessageBox.critical(get_app().GetTopWindow(), _('Error'), str(ex))
                return False
        return True
