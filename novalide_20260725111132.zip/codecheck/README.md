Codecheck插件使用文档
--------------------------

简介
----------------------------------
codecheck是一款支持代码缺陷检查，代码修复，以及代码一键式修复的插件。
支持flake8工具格式化告警的一键式修复以及部分pylint工具告警的修复功能。

### 安装
- 安装路径
<br/>
[下载链接](http://)
- 解压并打开NovalIDE软件
<br/>
![Step1](images/1.png)
- 打开Tools/PluginManager菜单
<br/>
![Step2](images/2.png)
- 插件路径
<br/>
[插件链接](http://)
- 安装codecheck插件
<br/>
![Step3](images/3.png)
<br/>
![Step4](images/4.png)
<br/>
<strong>安装完成后需要退出并重启软件。</strong>
- 安装代码检查工具pylint&flake8
<br/>
![tool_options](images/tool_options.png)
![Step5](images/5.png)
- 安装完成以及配置
<br/>
![Step6](images/6.png)

### 新建Codecheck项目
- 新建项目
<br/>
![New1](images/new_project_1.png)
![New2](images/new_project_2.png)
- 选择Codecheck项目
![New3](images/new_project_wizard.png)
- 选择项目位置以及解释器
<br/>
![New4](images/create_project.png)
- 选择项目检查工具pylint&flake8
<br/>
![New5](images/create_project_options.png)
- 选择代码目录导入文件
<br/>
![New6](images/create_project_finish.png)
- 选择项目解释器
![New9](images/project_properties.png)
![New8](images/choose_project_interpreter.png)
- 插件界面概貌
<br/>
![New7](images/messages.png)


### 常见问题
- 无法打开软件
<br/>
软件不能安装在中文路径下，不能在中文路径下打开软件
- 切换中英文界面
<br/>
![New11](images/options.png)
![New12](images/environ_general_options.png)
- 无法保存项目配置
<br/>
如下图：
![ans1](images/filenotin.png)
解决方案：
<br/>
![ans2](images/startup.png)
![ans3](images/pythonfile.png)
![ans4](images/selectfile.png)
### 示例工程
- 打开项目
<br>
![Open1](images/open_sample_project.png)
打开dist下samples子目录下的示例工程：
<br/>
![Open2](images/open_project_file.png)
<br/>
![Open3](images/open_project_view.png)
- 选择项目解释器:
<br/>
![Open4](images/project_properties.png)
<br/>
![Open5](images/choose_project_interpreter.png)
- 开始检查：
<br>
![Open6](images/check.png)
- 一键修复：
<br>
![Open7](images/autofix.png)
![Open8](images/autofix_result.png)
- flake8格式化告警修复比对
<br>
使用Beyond Compare比对软件查看修复告警前后比对结果：
<br>
![Open9](images/compare1.png)
![Open10](images/compare2.png)
![Open11](images/compare3.png)