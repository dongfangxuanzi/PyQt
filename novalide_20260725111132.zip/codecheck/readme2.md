Codecheck插件使用文档
--------------------------

简介
----------------------------------
codecheck是一款支持代码缺陷检查，代码修复，以及代码一键式修复的插件。
支持flake8工具格式化告警的一键式修复以及部分pylint工具告警的修复功能。
### flake8修复规则一览表
| 规范名称 | 规则编号 | 一键修复 | 备注|
|-----|------|-----|------|
||W504|是||
||W503|是||
||W291|是||
||E731|是||
||E722|是||
|G.OPR.05 应该使用is not 运算符而不是not ... is|E714|是||
|G.OPR.06 应该使用not in测试成员关系|E713|是|autopep8工具配置可选参数才支持一键修复|
||E712|是||
||E711|是||
||E703|是||
|G.FMT.08 一行只写一条语句|E704|是||
|G.FMT.08 一行只写一条语句|E702|是||
|G.FMT.08 一行只写一条语句|E701|是||
||E502|是||
||E402|是||
|G.FMT.06 每行只能导入一个模块|E401|是||
||E305|是||
||E304|是||
||E303|是||
|G.FMT.03 合理安排空行|E306|是||
|G.FMT.03 合理安排空行|E302|是||
|G.FMT.03 合理安排空行|E301|是||
||E274|是||
||E273|是||
|G.CMT.04 代码的注释位置和格式应该在项目内保持统一|E262|是||
||E261|是||
|G.FMT.04 用空格突出关键字和重要信息|E272|是||
|G.FMT.04 用空格突出关键字和重要信息|E271|是||
|G.FMT.04 用空格突出关键字和重要信息|E251|是||
|G.FMT.04 用空格突出关键字和重要信息|E231|是||
|G.FMT.04 用空格突出关键字和重要信息|E225|是||
|G.FMT.04 用空格突出关键字和重要信息|E222|是||
|G.FMT.04 用空格突出关键字和重要信息|E221|是||
|G.FMT.04 用空格突出关键字和重要信息|E211|是||
|G.FMT.04 用空格突出关键字和重要信息|E203|是||
|G.FMT.04 用空格突出关键字和重要信息|E202|是||
|G.FMT.04 用空格突出关键字和重要信息|E201|是||
|G.FMT.04 用空格突出关键字和重要信息|E275|是||
|G.FMT.04 用空格突出关键字和重要信息|E241|是||
|G.FMT.04 用空格突出关键字和重要信息|E252|是||
|G.FMT.04 用空格突出关键字和重要信息|E275|是||
|G.FMT.04 用空格突出关键字和重要信息|E227|是||
|G.FMT.04 用空格突出关键字和重要信息|E228|是||
||E224|是||
||E223|是||
||E129|是||
||E128|是||
||E127|是||
||E126|是||
||E125|是||
||E124|是||
||E123|是||
||E122|是||
||E121|是||
||E116|是||
||E115|是||
||E114|是||
|G.FMT.01 程序块应该采用4个空格缩进风格编写|E111|是||
|G.FMT.01 程序块应该采用4个空格缩进风格编写|E101|是||
|G.FMT.01 程序块应该采用4个空格缩进风格编写|E117|是||
|G.FMT.01 程序块应该采用4个空格缩进风格编写|W191|是||

### pylint修复规则一览表
| 规范名称 | 规则编号|规则名称 | 单点修复| 一键修复 | 自研规则|
|-----|------|-----|------|------|-----|
||W1406|redundant-u-string-prefix|是|是|否|
||W1401|anomalous-backslash-in-string|是|是|否|
||W1201|logging-not-lazy|是|是|否|
|G.ERR.05 使用明确业务属性的异常类型|W0702|bare-except|是|否|否|
||W0614|unused-wildcard-import|是|否|否|
|未使用变量|W0612|unused-variable|是|是|否|
|未使用导入模块|W0611|unused-import|是|是|否|
|G.CMT.05 正式交付给客户的代码不应该包含TODO/FIXME注释|W0511|fixme|是|否|否|
|G.FMT.05 导入部分(imports)应该置于模块注释和文档字符串之后，模块全局变量和常量声明之前|W0410|misplaced-future|是|是|否|
|重复导入模块|W0404|reimported|是|是|否|
|G.CLS.02 子类重写父类的方法时，方法签名应该和被重写的方法一致|W0237|arguments-renamed|是|否|否|
|G.TYP.06 同一个字典表达式中各个键值不要相同|W0109|duplicate-key|是|否|否|
||W0107|unnecessary-pass|是|是|否|
|G.FNM.01 禁止使用可变对象作为参数默认值|W0102|dangerous-default-value|是|是|否|
||R1735|use-dict-literal|是|是|否|
||R1734|use-list-literal|是|是|否|
||R1725|super-with-arguments|是|是|否|
||R1723|no-else-break|是|是|否|
||R1720|no-else-raise|是|是|否|
||R1716|chained-comparison|是|是|否|
||R1714|consider-using-in|是|是|否|
||R1705|no-else-return|是|是|否|
||R0402|consider-using-from-import|是|是|否|
||R0205|useless-object-inheritance|是|是|否|
||I0021|useless-suppression|是|是|否|
||F0010|parse-error|是|是|否|
||E0711|notimplemented-raised|是|是|否|
||E0710|raising-non-exception|是|是|否|
|未定义变量|E0602|undefined-variable|是|否|否|
|G.NAM.03 "self"应该是实例方法的第一个参数，"cls"应是类方法的第一个参数|E0213|no-self-argument|是|否|否|
|G.NAM.03 "self"应该是实例方法的第一个参数，"cls"应是类方法的第一个参数|E0211|no-method-argument|是|否|否|
|语法错误|E0001|syntax-error|否|否|否|
||C2503|bad-file-encoding|是|是|否|
|G.TYP.04 建议使用if seq或if not seq 的方式判断序列是否为空|C1802|use-implicit-booleaness-not-len|是|是|否|
|G.FMT.05 导入部分(imports)应该置于模块注释和文档字符串之后，模块全家变量和常量声明之前|C0413|wrong-import-position|是|否|否|
|G.FMT.07 导入部分(imports)应该按照标准库，第三方库，应用程序自定义模块的顺序排列导入|C0411|wrong-import-order|是|是|否|
||C0410|multiple-imports|是|否|否|
|G.FMT.10 代码行的行尾结束符LF和CRLF不应该混用|C0327|mixed-line-endings|是|是|否|
||C0325|superfluous-parens|是|是|否|
||C0303|trailing-whitespace|是|是|否|
|G.FMT.02 行宽不超过120个字符|C0301|line-too-long|是|是|否|
||C0206|consider-using-dict-items|是|否|否|
|G.NAM.03 "self"应该是实例方法的第一个参数，"cls"应是类方法的第一个参数|C0202|bad-classmethod-argument|是|否|否|
|G.CTL.04 建议使用for x in iterable的方式循环处理可迭代对象|C0200|consider-using-enumerate|是|否|否|
|G.TYP.08 必须使用isinstance判断变量类型|C0123|unidiomatic-typecheck|是|是|否|
|G.EXP.01 尽可能使用隐式布尔值|C0121|singleton-comparison|是|是|否|
||C0116|missing-function-docstring|是|否|否|
||C0114|missing-module-docstring|是|否|否|
|G.NAM.01 使用统一的命名风格|C0103|invalid-name|是|否|否|
|G.CMT.02 类的文档字符串写在类声明所在行的下一行，并向后缩进4个空格|C0117|class-docstring-indents-four|是|否|是|
|G.CMT.03 公共函数的文档字符串写在函数声明所在行的下一行，并向后缩进4个空格|C0118|function-docstring-indents-four|是|否|是|
|G.CMT.01 模块文档字符串写在文件的顶部，Shebang和文件编码声明之后，导入(imports)部分之前的位置，不需要缩进|C0119|module-docstring-no-indents|是|否|是|
|G.CMT.01 模块文档字符串写在文件的顶部，Shebang和文件编码声明之后，导入(imports)部分之前的位置，不需要缩进|C0120|module-docstring-position|是|否|是|
|G.NAM.01 使用统一的命名风格|H2101|huawei-invalid-name|是|否|是|
|G.CMT.05 正式交付给客户的代码不应该包含TODO/FIXME注释|H2205|huawei-fixme|是|是|是|
|G.CMT.06 文件头注释应该包含版权许可信息|H2206|header-copyright|是|否|是|
|G.FMT.05 导入部分(imports)应该置于模块注释和文档字符串之后，模块全家变量和常量声明之前|H2305|huawei-wrong-import-position|是|否|是|
|G.FMT.09 合理的运用换行和缩进|H2309|multiline-comprehension|是|否|是|
|G.TYP.07 使用dict[key]获取value时需要注意保证key在有效的范围内|H3107|get-dict-value-exception|是|否|是|
|G.TYP.09 建议优先使用语义更明确的内置函数来判断对象的类型或行为|H3109|hasattr-dunder|是|否|是|
|G.PSL.01 避免使用已经被标记为弃用并有明确替代的方法|H3111|huawei-deprecated-module|是|否|是|
|G.PSL.01 避免使用已经被标记为弃用并有明确替代的方法|H3112|huawei-deprecated-class|是|否|是|
|G.PRJ.05 不要的代码段直接删除，不要注释掉|H3115|comment-out-code|是|是|是|
|G.TYP.08 必须使用isinstance判断变量类型|H3148|huawei-unidiomatic-typecheck|是|是|是|
|G.OPR.02 与None作比较要使用is或is not，不要使用等号|H3212|none-comparision|是|否|是|
|G.TYP.04 建议使用if seq或if not seq 的方式判断序列是否为空|H3221|huawei-use-implicit-booleaness-not-len|是|否|是|
|G.EXP.01 尽可能使用隐式布尔值|H3222|huawei-use-implicit-booleaness-not-comparision|是|否|是|
|G.CTL.05 建议使用单个下划线代替循环体中未使用的循环变量|H3305|unused-loop-variable|是|否|是|
|G.CLS.01 如果子类和父类中都有__init__方法，则子类中的__init__方法必须正确调用其父类__init__方法|H3601|huawei-super-init-not-called|是|否|是|
|G.CLS.02 子类重写父类的方法时，方法签名应该和被重写的方法一致|H3603|huawei-arguments-renames|是|否|是|
|G.CLS.05 子类调用父类初始化的方式，建议使用super类辅助|H3605|base-init-by-name|是|否|是|
|G.CLS.06 类的方法建议统一按照一种规则进行排列|H3606|function-order|是|否|是|
|G.CLS.07 类的方法不需要访问实例时，建议定义为staticmethod或classmethod|H3607|add-staticmethod-or-classmethod-decorator|是|否|是|
|G.CLS.08 避免在__init__方法外定义类实例属性|H3608|class-attribute-defined-outside-init|是|否|是|
|G.ERR.03 异常的类型定义必须继承自Exception|H3703|huawei-raising-non-exception|是|否|是|
|G.ERR.04 对异常做类型转换时要保留原始异常的错误调用栈信息|H3704|huawei-raise-missing-from|是|是|是|
|G.ERR.12 合理地使用object.__exit__处理异常|H3712|dunder-exit|是|否|是|
|G.ERR.10 同时使用多个except语句时, 要注意异常捕获的顺序|H3713|huawei-bad-except-order|是|否|是|
|G.PSL.04 建议用functools.wraps定义函数装饰器|H4004|decorator-add-wraps|是|否|是|
|G.TES.02 使用对应的方法做值断言|H4702|improper-value-assert|是|否|是|
|G.TYP.02 浮点型数据判断相等不要直接使用==|W0135|floating-equal-comparision|是|否|是|
|G.TYP.01 需要精确数值计算的场景, 应使用decimal模块，且不要用浮点数构造Decimal|W1117|decimal-initialization|是|否|是|
|G.FIO.05 构造文件路径时应屏蔽操作系统的差异, 建议使用库函数辅助构造|W1311|use-system-path|是|否|是|
|G.PSL.03 修改sys.path时注意避免模块重名问题|W1805|no-use-sys-path-insert|是|否|是|
|G.PRJ.04 建议同一项目内的编码方式保持一致，推荐使用UTF-8|W1801|not-utf8-encoding|是|是|是|

### 安装
- 安装路径
<br/>
[下载链接](http://)
- 解压并打开NovalIDE软件
<br/>
![Step1](images/1.png)
- 打开Tools/PluginManager菜单
<br/>
![Step2](images/2.png)
- 插件路径
<br/>
[插件链接](http://)
- 安装codecheck插件
<br/>
![Step3](images/3.png)
<br/>
![Step4](images/4.png)
<br/>
<strong>安装完成后需要退出并重启软件。</strong>
- 安装代码检查工具pylint&flake8
<br/>
![tool_options](images/tool_options.png)
![Step5](images/5.png)
- 安装完成以及配置
<br/>
![Step6](images/6.png)

### 新建Codecheck项目
- 新建项目
<br/>
![New1](images/new_project_1.png)
![New2](images/new_project_2.png)
- 选择Codecheck项目
![New3](images/new_project_wizard.png)
- 选择项目位置以及解释器
<br/>
![New4](images/create_project.png)
- 选择项目检查工具pylint&flake8
<br/>
![New5](images/create_project_options.png)
- 选择代码目录导入文件
<br/>
![New6](images/create_project_finish.png)
- 选择项目解释器
![New9](images/project_properties.png)
![New8](images/choose_project_interpreter.png)
- 插件界面概貌
<br/>
![New7](images/messages.png)


### 常见问题
- 无法打开软件
<br/>
软件不能安装在中文路径下，不能在中文路径下打开软件
- 切换中英文界面
<br/>
![New11](images/options.png)
![New12](images/environ_general_options.png)
- 无法保存项目配置
<br/>
如下图：
![ans1](images/filenotin.png)
解决方案：
<br/>
![ans2](images/startup.png)
![ans3](images/pythonfile.png)
![ans4](images/selectfile.png)
### 示例工程
- 打开项目
<br>
![Open1](images/open_sample_project.png)
打开dist下samples子目录下的示例工程：
<br/>
![Open2](images/open_project_file.png)
<br/>
![Open3](images/open_project_view.png)
- 选择项目解释器:
<br/>
![Open4](images/project_properties.png)
<br/>
![Open5](images/choose_project_interpreter.png)
- 开始检查：
<br>
![Open6](images/check.png)
- 一键修复：
<br>
![Open7](images/autofix.png)
![Open8](images/autofix_result.png)
- flake8格式化告警修复比对
<br>
使用Beyond Compare比对软件查看修复告警前后比对结果：
<br>
![Open9](images/compare1.png)
![Open10](images/compare2.png)
![Open11](images/compare3.png)