from novalapp.lib.pyqt import (
    QLabel,
    QRadioButton,
    QHBoxLayout,
    Qt,
    QFileDialog,
    QProgressBar,
    QCoreApplication,
    QCursor,
    QFrame
)
class ClassHierarchyViewer(QFrame):
    """description of class"""

    def __init__(self, parent=None, plugin=None):
        super().__init__(parent)
        self._plugin = plugin