from distutils.core import setup
from setuptools import find_packages


setup(name='DrawClass',
      version='1.0',
      description='''draw class hierarchy''',
      author='wukan',
      author_email='wekay102200@sohu.com',
      url='wekay102200@sohu.com',
      license='Mulan',
      packages=find_packages(),
      install_requires=[],
      zip_safe=False,
      package_data={
          'drawclass': ['res/*.*', 'locale/zh_CN/LC_MESSAGES/codecheck.mo']
      },
      data_files=[],
      classifiers=[
          "Development Status :: 4 - Beta",
          "Programming Language :: Python",
          "Topic :: Software Development :: Libraries :: Python Modules",
          "Programming Language :: Python :: Implementation :: CPython",
          "Programming Language :: Python :: Implementation :: PyPy",
          "Programming Language :: Python :: 3.11"
      ],
      keywords='',
      entry_points="""
        [Noval.plugins]
        DrawClass = drawclass:DrawClassPlugin
        """
      )
