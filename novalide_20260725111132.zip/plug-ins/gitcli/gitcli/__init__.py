from typing import Optional
import os
import shutil
from novalapp.util import utils, pathutils
from novalapp import constants
from novalapp.project.wizard.templatemanager import WizardtemplateManager
from novalapp.widgets.colorlabel import QRedLabel
from novalapp.bars.menubar import NewQMenu
from novalapp.util import ui_utils, strutils, fileutils
from novalapp.lib.pyqt import (
    QMessageBox,
    QListWidgetItem,
    Qt,
    QVBoxLayout,
    QHBoxLayout,
    QListWidget,
    QLabel,
    QSizePolicy,
    QTextEdit,
    QCheckBox,
    QPushButton,
    QDialog,
    QCursor
)
from novalapp import _, get_app, newid
from novalapp.plugin import plugin
from novalapp.plugin import iface
from novalapp.util.transfer import FiledownloadSerivce
from gitcli import gitui
from git.exceptions import GitNotInstalledError
from git.cmd import GitCmd, GitdocCmd, get_askpass_path
from git.repo import Repo, RepofileState, UNKWNOW_BRANCH_NAME
from .logs import LogsDialog
from .command import CommandDialog
from .tags import CreateTagDialog, PushTagDialog, DeleteTagDialog
from .merge import MergeBranchDialog, MergeConflictsDialog
from .ignore import AddIgnoreDlg
from .branch import CheckoutBranchDialog, CreateBranchDialog
from .addr import AddRemoteAddrDialog, RemoteAddrListDialog
from .async_cmd import AsyncCmd
from .config import GitConfigurationDialog, USING_EXTERNAL_KEY
from .diff import FileDiffDialog


class CommitDialog(ui_utils.BaseModalDialog):
    def __init__(
        self,
        master,
        ui,
        commit_files: list,
        single_file,
        commit=True,
        has_unmerged=False
    ):
        branch = ui.current_branch
        if commit:
            title = _('Commit-[%s]') % branch
        else:
            title = _('Checkout-[%s]') % branch
        super().__init__(title, master)
        self.setFixedSize(750, 680)
        self.ui = ui
        self.is_commit = commit
        self._single_file = single_file
        self._commit_files = commit_files
        self._has_unmerged = has_unmerged
        self._show_all_files = False
        self.quick_commit = False

        vbox = QVBoxLayout()

        head_box = QHBoxLayout()
        self.commit_file_label = QLabel()
        head_box.addWidget(self.commit_file_label)

        top_r_vbox = QVBoxLayout()
        self.show_fullpath_chkbox = QCheckBox(_('Show full path'))
        self.show_fullpath_chkbox.clicked.connect(self.show_commit_filepath)
        top_r_vbox.addWidget(self.show_fullpath_chkbox)

        if self.is_commit:
            self.show_all_files_chkbox = QCheckBox(_('Show all files'))
            self.show_all_files_chkbox.clicked.connect(self.show_all_files)
            top_r_vbox.addWidget(self.show_all_files_chkbox)
        head_box.addStretch(1)
        head_box.addLayout(top_r_vbox)
        vbox.addLayout(head_box)

        self.listbox = QListWidget()
        self.listbox.itemClicked.connect(self.on_item_clicked)
        self.listbox.itemChanged.connect(self.on_item_changed)
        self.listbox.itemDoubleClicked.connect(self.on_item_doubleclicked)
        self.listbox.setContextMenuPolicy(Qt.CustomContextMenu)
        self.listbox.customContextMenuRequested.connect(
            self.on_item_rightclick)
        vbox.addWidget(self.listbox)

        h_button_box = QHBoxLayout()
        select_all_btn = QPushButton(_("Select All"))
        select_all_btn.clicked.connect(self.select_all)
        select_all_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        if self.is_commit:
            select_unstaged_btn = QPushButton(_("Select Unstaged Files"))
            select_unstaged_btn.clicked.connect(self.select_all_unstaged_files)
            select_unstaged_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        unselect_all_btn = QPushButton(_("UnSelect All"))
        unselect_all_btn.clicked.connect(self.unselect_all)
        unselect_all_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        rescan_btn = QPushButton(_("Rescan"))
        rescan_btn.clicked.connect(self.rescan)
        rescan_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        h_button_box.addWidget(select_all_btn)
        if self.is_commit:
            h_button_box.addWidget(select_unstaged_btn)
        h_button_box.addWidget(unselect_all_btn)
        h_button_box.addWidget(rescan_btn)
        h_button_box.addStretch(1)

        self.show_state_label = QRedLabel()
        if self.is_commit:
            self.amend_chkbox = QCheckBox(_('Amend last commit'))
            self.amend_chkbox.clicked.connect(self.amend_last_commit)
            h_button_box.addWidget(self.amend_chkbox)
        vbox.addLayout(h_button_box)
        vbox.addWidget(self.show_state_label)

        if self.is_commit:
            vbox.addWidget(QLabel(_('Commit message')))
            self.text = QTextEdit()
            vbox.addWidget(self.text)

            push_hbox = QHBoxLayout()
            self.commit_push_button = QPushButton(_("Commit and Push"))
            self.commit_push_button.clicked.connect(self.commit_and_push)
            push_hbox.addWidget(self.commit_push_button)
            push_hbox.addStretch(1)
            self.quick_commit_button = QPushButton(_("Quick Commit"))
            self.quick_commit_button.clicked.connect(self.quick_commit_files)
            push_hbox.addWidget(self.quick_commit_button)
            
            self.create_standard_buttons(push_hbox)
            vbox.addLayout(push_hbox)
            self.ok_button.setText(_("Commit"))
        else:
            self.create_standard_buttons(vbox)
            self.ok_button.setText(_("Checkout"))
        self.layout.addLayout(vbox)
        self.list_status_files(commit_files)

        self.files = []
        self.msg = ''
        self.push = False
        self._disable_item_checkstate_changed = False

    def get_logs(self, n):
        commit_logs = []
        log_command = 'log'
        f = self.ui.CallGitProcess(log_command + f' -n {n}')
        d = {}
        msg_list = []
        for linestr in f.splitlines():
            if linestr.find(Repo.COMMIT_ID_FLAG) != -1:
                if d:
                    d['msg'] = msg_list.copy()
                    commit_logs.append(d.copy())
                    d.clear()
                    msg_list.clear()
                commit_id = linestr.replace(Repo.COMMIT_ID_FLAG, "").strip()
                d['commit_id'] = commit_id
            elif linestr.find(LogsDialog.AUTHOR_FLAG) != -1 and d:
                author = linestr.replace(LogsDialog.AUTHOR_FLAG, "").strip()
                d['author'] = author
            elif linestr.find(LogsDialog.DATE_FLAG) != -1 and d:
                date = linestr.replace(LogsDialog.DATE_FLAG, "").strip()
                d['date'] = date
            else:
                if linestr.strip():
                    msg_list.append(linestr.strip())
        if d:
            d['msg'] = msg_list.copy()
            commit_logs.append(d.copy())
        return commit_logs

    def amend_last_commit(self):
        if self.amend_chkbox.isChecked():
            logs = self.get_logs(2)
            if logs:
                self.text.setText(os.linesep.join(logs[0]['msg']))
            self.ok_button.setText(_("Ammend Commit"))
            self.commit_push_button.setText(_("Ammend Commit and Push"))
        else:
            self.text.setText('')
            self.ok_button.setText(_("Commit"))
            self.commit_push_button.setText(_("Commit and Push"))

    def on_item_rightclick(self, event):
        menu = NewQMenu(self)
        menu.Append(
            newid(),
            _("&Goto path"),
            handler=self.gotopath
        )
        menu.popup(QCursor.pos())

    def gotopath(self):
        curitem = self.listbox.currentItem()
        item_file_data = curitem.data(Qt.UserRole)
        pathutils.safe_open_file_directory(item_file_data.fullpath)

    def has_unmerged_file(self):
        return self._has_unmerged

    @ui_utils.call_after_with_time(3000)
    def hide_label_state(self):
        self.show_state_label.setText('')

    def on_item_doubleclicked(self, item):
        item_file_data = item.data(Qt.UserRole)
        if item_file_data.file_state == RepofileState.FILE_UNMERGE_MODIFIED:
            dlg = MergeConflictsDialog(
                self,
                self.ui,
                item_file_data
            )
            if dlg.exec_() == QDialog.Accepted:
                self.rescan()
        else:
            FileDiffDialog(
                self,
                self.ui,
                item_file_data.filepath,
                item_file_data.file_state
            ).exec_()

    def on_item_changed(self, item):
        if self._disable_item_checkstate_changed or not self.is_commit:
            return
        item_file_data = item.data(Qt.UserRole)
        if item.checkState() == Qt.Checked:
            if item_file_data.file_state == RepofileState.FILE_UNTRACKED:
                item_file_data.file_state = RepofileState.FILE_NEW_STAGED
            elif item_file_data.file_state == RepofileState.FILE_MODIFIED_UNSTAGED:
                item_file_data.file_state = RepofileState.FILE_MODIFIED_STAGED
            elif item_file_data.file_state == RepofileState.FILE_DELETED_UNSTAGED:
                item_file_data.file_state = RepofileState.FILE_DELETED_STAGED
            elif item_file_data.file_state == RepofileState.FILE_UNMERGE_MODIFIED:
                QMessageBox.information(
                    self,
                    get_app().GetAppName(),
                    _('This file has merge conflicts!')
                )
                return
            try:
                repo = Repo(get_app().get_current_project().GetPath())
                repo.add(item_file_data.filepath)
            except Exception as ex:
                utils.get_logger().error("%s", str(ex))
        else:
            if item_file_data.file_state == RepofileState.FILE_NEW_STAGED:
                item_file_data.file_state = RepofileState.FILE_UNTRACKED
            elif item_file_data.file_state == RepofileState.FILE_MODIFIED_STAGED:
                item_file_data.file_state = RepofileState.FILE_MODIFIED_UNSTAGED
            elif item_file_data.file_state == RepofileState.FILE_DELETED_STAGED:
                item_file_data.file_state = RepofileState.FILE_DELETED_UNSTAGED

            try:
                repo = Repo(get_app().get_current_project().GetPath())
                repo.git.call_output(f"restore --staged {item_file_data.filepath}")
            except Exception as ex:
                utils.get_logger().error("%s", str(ex))

    def on_item_clicked(self, item):
        item_file_data = item.data(Qt.UserRole)
        if item_file_data.file_state == RepofileState.FILE_MODIFIED_STAGED:
            self.show_state_label.setText(_('Modified, Staged for commit'))
        elif item_file_data.file_state == RepofileState.FILE_NEW_STAGED:
            self.show_state_label.setText(_('New, Staged for commit'))
        elif item_file_data.file_state == RepofileState.FILE_MODIFIED_UNSTAGED:
            self.show_state_label.setText(_('Modified, not staged'))
        elif item_file_data.file_state == RepofileState.FILE_DELETED_STAGED:
            self.show_state_label.setText(_('Staged for remove'))
        elif item_file_data.file_state == RepofileState.FILE_DELETED_UNSTAGED:
            self.show_state_label.setText(_('Missing'))
        elif item_file_data.file_state == RepofileState.FILE_UNTRACKED:
            self.show_state_label.setText(_('Untracked file, not staged'))

        elif item_file_data.file_state == RepofileState.FILE_UNMERGE_MODIFIED:
            self.show_state_label.setText(_('Merge conflicts, Modified file'))

        elif item_file_data.file_state == RepofileState.FILE_UNMERGE_DELETED:
            self.show_state_label.setText(_('Merge conflicts, Deleted file'))
        self.hide_label_state()

    def is_project_delete_file(self, root_path, commit_file):
        if commit_file.file_state in [
            RepofileState.FILE_DELETED_STAGED,
            RepofileState.FILE_DELETED_UNSTAGED
        ] and strutils.path_startswith(commit_file.fullpath, root_path):
            return True
        return False

    def is_project_file(self, proj_doc, commit_file):
        if not self._show_all_files:
            doc_model = proj_doc.GetModel()
            # 仅显示项目文件
            return doc_model.FindFile(commit_file.fullpath)
            # 显示项目目录和子目录下的所有文件
        return strutils.path_startswith(commit_file.fullpath, proj_doc.GetPath())

    def list_status_files(self, commit_files):
        # 修改待提交的文件
        commit_files_count = 0
        # 修改但不提交的文件
        unstaged_files_count = 0
        # 未追踪文件
        untracked_files_count = 0
        self._disable_item_checkstate_changed = True
        project_doc = get_app().get_current_project()
        doc_model = project_doc.GetModel()
        root_path = project_doc.GetPath()
        for commit_file in commit_files:
            utils.get_logger().debug(
                'project root path is %s, file path is %s',
                root_path,
                commit_file.fullpath
            )
            # 处理项目包含文件
            if not self._single_file and (
                not self.is_project_file(project_doc, commit_file)
            ) and (
                # 处理项目目录
                not doc_model.find_files(commit_file.fullpath)
            ) and (
                # 处理项目被删除文件
                not self.is_project_delete_file(root_path, commit_file)
            ) and (
                # 处理项目文件本身
                not project_doc.is_project_docfile(commit_file.fullpath)
            ):
                continue
            if not self.is_commit and commit_file.file_state in [
                RepofileState.FILE_MODIFIED_STAGED,
                RepofileState.FILE_DELETED_STAGED,
                RepofileState.FILE_NEW_STAGED,
                RepofileState.FILE_UNTRACKED
            ]:
                continue
            item = QListWidgetItem(commit_file.filepath)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            self.listbox.addItem(item)
            item.setData(Qt.UserRole, commit_file)
            if commit_file.file_state in [
                RepofileState.FILE_MODIFIED_STAGED,
                RepofileState.FILE_DELETED_STAGED,
                RepofileState.FILE_NEW_STAGED
            ]:
                item.setCheckState(Qt.Checked)
                commit_files_count += 1
            else:
                item.setCheckState(Qt.Unchecked)
                if commit_file.file_state == RepofileState.FILE_UNTRACKED:
                    untracked_files_count += 1
                elif commit_file.file_state == RepofileState.FILE_MODIFIED_UNSTAGED or commit_file.file_state == RepofileState.FILE_DELETED_UNSTAGED:
                    unstaged_files_count += 1

        if self.is_commit:
            label_msg = _('Commit files %d,Unstaged files %d,Untracked files %d') % (
                commit_files_count,
                unstaged_files_count,
                untracked_files_count
            )
            self.commit_file_label.setText(label_msg)
        else:
            self.commit_file_label.setText(
                _('Unstaged files %d checkoutable') % unstaged_files_count
            )
        self._disable_item_checkstate_changed = False

    def show_all_files(self):
        self._show_all_files = self.show_all_files_chkbox.isChecked()
        self.rescan()

    def show_commit_filepath(self):
        self._disable_item_checkstate_changed = True
        if self.show_fullpath_chkbox.isChecked():
            for i in range(self.listbox.count()):
                item = self.listbox.item(i)
                data = item.data(Qt.UserRole)
                item.setText(data.fullpath)
        else:
            for i in range(self.listbox.count()):
                item = self.listbox.item(i)
                data = item.data(Qt.UserRole)
                item.setText(data.filepath)
        self._disable_item_checkstate_changed = False

    def rescan(self):
        self.listbox.clear()
        commit_files = []
        repo = Repo(get_app().get_current_project().GetPath())
        if self._single_file:
            try:
                filepath = self._commit_files[0].fullpath
                self._has_unmerged, commit_files = repo.status(filepath)
            except Exception as ex:
                utils.get_logger().error(str(ex))
                return
        else:
            try:
                self._has_unmerged, commit_files = repo.status()
            except Exception as ex:
                utils.get_logger().error(str(ex))
                return
        self.list_status_files(commit_files)

    def select_all_unstaged_files(self):
        self._disable_item_checkstate_changed = True
        select_files = []
        for i in range(self.listbox.count()):
            item = self.listbox.item(i)
            item_data = item.data(Qt.UserRole)
            item_state = item.checkState()
            if item_state != Qt.Checked and (
                item_data.file_state in (RepofileState.FILE_MODIFIED_UNSTAGED, RepofileState.FILE_DELETED_UNSTAGED)
            ):
                select_files.append(item_data.filepath)
                item.setCheckState(Qt.Checked)

        utils.get_logger().debug('select all %d unstaged files', len(select_files))
        self._disable_item_checkstate_changed = False
        if not select_files:
            return
        try:
            repo = Repo(get_app().get_current_project().GetPath())
            repo.add_files(select_files)
        except Exception as ex:
            utils.get_logger().error("%s", str(ex))
            QMessageBox.critical(self, _('Error'), str(ex))
        self.rescan()

    def select_all(self):
        if self.check_unmerge_files():
            return
        add_files = []
        self.check_listbox(add_files, True)
        utils.get_logger().debug('select all add total %d files', len(add_files))
        if not add_files or not self.is_commit:
            return
        try:
            repo = Repo(get_app().get_current_project().GetPath())
            repo.add_files(add_files)
        except Exception as ex:
            utils.get_logger().error("%s", str(ex))
            QMessageBox.critical(self, _('Error'), str(ex))
        self.rescan()

    def check_listbox(self, select_files: list, check=True):
        self._disable_item_checkstate_changed = True
        for i in range(self.listbox.count()):
            item = self.listbox.item(i)
            item_state = item.checkState()
            if check:
                if item_state != Qt.Checked:
                    item_data = item.data(Qt.UserRole)
                    # 不能选择有合并冲突的文件
                    if item_data.file_state == RepofileState.FILE_UNMERGE_MODIFIED:
                        continue
                    select_files.append(item_data.filepath)
                    item.setCheckState(Qt.Checked)
            else:
                if item_state != Qt.Unchecked:
                    item_data = item.data(Qt.UserRole)
                    select_files.append(item_data.filepath)
                    item.setCheckState(Qt.Unchecked)
        self._disable_item_checkstate_changed = False

    def unselect_all(self):
        unstore_files = []
        self.check_listbox(unstore_files, False)
        utils.get_logger().debug('unselect all unstore total %d files', len(unstore_files))
        if not unstore_files or not self.is_commit:
            return
        try:
            repo = Repo(get_app().get_current_project().GetPath())
            filpath_args = repo.filelist_to_args(unstore_files)[0]
            repo.git.call_output(f"restore --staged {filpath_args}")
        except Exception as ex:
            utils.get_logger().error("%s", str(ex))
            QMessageBox.critical(self, _('Error'), str(ex))
        self.rescan()

    def check_unmerge_files(self):
        if self.has_unmerged_file():
            QMessageBox.warning(
                self,
                get_app().GetAppName(),
                _('Current branch has unmerged files, Please resolve merge conflicts first!')
            )
            return True
        return False
        
    def reset_values(self):
        self.quick_commit = False
        self.push = False
        
    def quick_commit_files(self):
        self.quick_commit = True
        self._ok()

    def commit_and_push(self):
        self.push = True
        self._ok()

    def GetFiles(self):
        files = []
        for i in range(self.listbox.count()):
            item = self.listbox.item(i)
            if item.checkState() == Qt.Checked:
                files.append(item.text())
        return files

    def _ok(self):
        self.files = self.GetFiles()
        if not self.files and not self.amend_chkbox.isChecked():
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                _('Please select at least one file')
            )
            self.reset_values()
            return
        if self.is_commit and not self.quick_commit:
            self.msg = self.text.toPlainText()
            if self.msg.strip() == '':
                QMessageBox.information(
                    self,
                    get_app().GetAppName(),
                    _('Commit message could not be empty')
                )
                self.reset_values()
                return
            # 提交文件之前必须先解决冲突
            if self.check_unmerge_files():
                self.reset_values()
                return
        super()._ok()


class GitCliPlugin(plugin.Plugin):
    """plugin description here..."""
    plugin.Implements(iface.MainWindowI)

    def plugit(self, parent):
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing GitCli plugin")
        self.project_browser = get_app().MainFrame.projectview
        # 必须在这里添加翻译文件路径，否则下面向导对话框翻译不生效
        get_app().add_message_catalog('gitcli', __name__)
        try:
            # 必须确保电脑上已经安装git
            GitCmd.check_git()
        except GitNotInstalledError as ex:
            utils.get_logger().error(str(ex))
            self.project_browser.SIG_PROJECTVIEW_POPUP_ROOT_MENU.connect(
                self.append_root_menu)
            return
        WizardtemplateManager.get_manager().AddProjectTemplate(
            _("General"),
            "common_project_from_git_server",
            _("New Common Project From Git Server"),
            [
                (gitui.GitCommonProjectNameLocationPage, {
                    'project_dir_checked': False,
                    'enable_create_project_dir': False}
                 ),
                gitui.LocationSelectionPage,
                gitui.RepositorySourcePage,
                gitui.BranchSelectionPage,
                gitui.LocalDestinationPage,
                gitui.ImportGitfilesPage
            ]
        )

        WizardtemplateManager.get_manager().AddProjectTemplate(
            "Python",
            "python_project_from_git_server",
            _("New Python Project From Git Server"),
            [
                (gitui.GitPythonProjectNameLocationPage, {
                    'project_dir_checked': False,
                    'enable_create_project_dir': False}
                 ),
                gitui.LocationSelectionPage,
                gitui.RepositorySourcePage,
                gitui.BranchSelectionPage,
                gitui.LocalDestinationPage,
                gitui.ImportGitfilesPage
            ]
        )
        # 项目文件节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_FILE_MENU.connect(
            self.append_file_menu)
        # 项目根节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_ROOT_MENU.connect(
            self.append_root_menu)

        self.project_browser.SIG_EDIT_TEXT_POPUP_MENU.connect(
            self.popup_edit_text_menu
        )
        self.current_branch = None

    def end_download(self, package_path, parent):
        dirpath = os.path.dirname(package_path)
        try:
            fileutils.unzip(package_path, dirpath)
        except Exception:
            utils.get_logger().exception(
                'unzip file %s to path %s fail exception',
                package_path,
                dirpath
            )
        src_askpass_path = os.path.join(dirpath, "askpass.exe")
        dest_askpass_path = get_askpass_path()
        try:
            shutil.copy(src_askpass_path, dest_askpass_path)
            utils.get_logger().info(
                'copy askpass path:%s to dest path %s success',
                src_askpass_path,
                dest_askpass_path
            )
        except Exception as ex:
            utils.get_logger().error(
                'copy askpass path %s dest path %s fail:%s',
                src_askpass_path,
                dest_askpass_path,
                str(ex)
            )
            parent.SIG_DOWNLOAD_ERROR.emit(str(ex))

    def copy_askpass(self):
        if utils.is_windows():
            filename = "askpass.zip"
            fileurl = "https://gitee.com/wekay/NovalIDE/raw/dev/shell/askpass.zip"
            FiledownloadSerivce(force_download=False).download_file(
                fileurl,
                filename,
                self.end_download,
                get_app().MainFrame.GetNotebook()
            )

    def remove_askpass(self):
        dest_askpass_path = get_askpass_path()
        if os.path.exists(dest_askpass_path):
            try:
                os.remove(dest_askpass_path)
                utils.get_logger().info(
                    'remove installed askpass path %s success',
                    dest_askpass_path
                )

            except Exception as ex:
                utils.get_logger().error(
                    'remove installed askpass path %s fail:%s',
                    dest_askpass_path,
                    str(ex)
                )

    def InstallHook(self):
        """
        Override in subclasses to allow the plugin to be loaded
        dynamically.
        @return: None
        """
        if utils.profile_get_int(USING_EXTERNAL_KEY, False):
            utils.get_logger().info('use external program to enter username and password..')
            self.copy_askpass()

    def UninstallHook(self):
        self.remove_askpass()

    def EnableHook(self):
        pass

    def DisableHook(self):
        pass

    def GetFree(self):
        return True

    def GetPrice(self):
        pass

    def MatchPlatform(self):
        '''
        这里插件需要区分windows版本和linux版本
        windows版本把adkpass.exe包需要打包进去
        linux版本把可执行脚本adkpass.py包需要打包进去
        '''
        return True

    def append_root_menu(self, menu, item):
        if self.GetProjectDocument() is None:
            return
        submenu = NewQMenu(_("Version Control"))
        menu.AppendMenu(newid(), submenu)
        if GitCmd.GIT_INSTALLED_PATH is None:
            submenu.Append(newid(), _("Configuration"), handler=self.Configuration)
            return
        self.current_branch = self.GetBranch()
        utils.get_logger().info('current branch is %s', self.current_branch)
        if self.current_branch is None:
            submenu.Append(newid(), _("Init"), handler=self.Init)
        else:
            submenu.Append(newid(), _("Checkout files"), handler=self.checkout_commit_files)
            submenu.Append(newid(), _("Ignore files"), handler=self.add_ignore_files)

            pull_menu = NewQMenu(_("Pull"))
            submenu.AppendMenu(newid(), pull_menu)
            pull_menu.Append(newid(), _("Pull branch"), handler=self.pull_branch)
            pull_menu.Append(newid(), _("Pull all"), handler=self.pull_all)

            submenu.Append(newid(), _("Commit"), handler=self.Commit)
            submenu.Append(newid(), _("Push"), handler=self.Pushall)

            branch_menu = NewQMenu(_("Branch"))
            submenu.AppendMenu(newid(), branch_menu)
            branch_menu.Append(newid(), _("Checkout branch"), handler=self.CheckoutBranch)
            branch_menu.Append(newid(), _("New branch"), handler=self.new_branch)
            branch_menu.Append(newid(), _("Delete branch"), handler=self.delete_branch)

            remote_addr_menu = NewQMenu(_("Remote Addr"))
            submenu.AppendMenu(newid(), remote_addr_menu)
            remote_addr_menu.Append(newid(), _("Add Addr"), handler=self.add_remote_addr)
            remote_addr_menu.Append(newid(), _("Addr List"), handler=self.list_remote_addrs)

            logs_menu = NewQMenu(_("Logs"))
            submenu.AppendMenu(newid(), logs_menu)
            logs_menu.Append(newid(), _("Logs of current branch"), handler=self.pull_branch_logs)
            logs_menu.Append(newid(), _("Logs of all branchs"), handler=self.pull_logs)

            tags_menu = NewQMenu(_("Tags"))
            submenu.AppendMenu(newid(), tags_menu)
            tags_menu.Append(newid(), _("New tag"), handler=self.new_tag)
            tags_menu.Append(newid(), _("Push tag"), handler=self.push_tag)
            tags_menu.Append(newid(), _("Delete tag"), handler=self.delete_tag)
            submenu.AppendMenu(newid(), tags_menu)

            submenu.Append(newid(), _("Merge"), handler=self.merge_branch)

            submenu.Append(newid(), _("Command"), handler=self.run_git_command)
            submenu.Append(newid(), _("Configuration"), handler=self.Configuration)

    def merge_branch(self):
        MergeBranchDialog(self.GetProjectFrame(), self).exec_()

    def run_git_command(self):
        CommandDialog(self.GetProjectFrame(), self).exec_()

    def pull_branch_logs(self):
        LogsDialog(self.GetProjectFrame(), self, self.current_branch).exec_()

    def pull_logs(self):
        LogsDialog(self.GetProjectFrame(), self).exec_()

    def list_remote_addrs(self):
        RemoteAddrListDialog(self.GetProjectFrame(), self).exec_()

    def add_remote_addr(self):
        AddRemoteAddrDialog(self.GetProjectFrame(), self).exec_()

    def Configuration(self):
        GitConfigurationDialog(self.GetProjectFrame(), self).exec_()

    def Init(self):
        command = "init"
        self.CallGitProcess(command)

    def CheckoutBranch(self):
        CheckoutBranchDialog(self.GetProjectFrame(), self).exec_()

    def checkout_commit_files(self):
        try:
            repo = Repo(self.GetProjectDocument().GetPath())
            _has_unmerged, commit_files = repo.status()
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return

        dlg = CommitDialog(
            get_app().MainFrame,
            self,
            commit_files,
            single_file=False,
            commit=False
        )
        if dlg.exec_() == CommitDialog.Rejected:
            return
        self.checkout_files(dlg.files)

    def new_tag(self):
        CreateTagDialog(self.GetProjectFrame(), self).exec_()

    def push_tag(self):
        PushTagDialog(self.GetProjectFrame()).exec_()

    def delete_tag(self):
        DeleteTagDialog(self.GetProjectFrame()).exec_()

    def new_branch(self):
        CreateBranchDialog(self.GetProjectFrame(), self).exec_()

    def delete_branch(self):
        ret = QMessageBox.question(
            self.GetProjectFrame(),
            _('Delete branch'),
            _('Current content will clear when branch deleted, Are you sure to delete it?')
        )
        if ret == QMessageBox.No:
            return
        master_branch_name = "master"
        if self.current_branch == master_branch_name:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('%s branch is protected and not allowed to delete') % self.current_branch
            )
            return
        repo = Repo(self.GetProjectDocument().GetPath())
        try:
            repo.checkout(master_branch_name)
        except Exception as ex:
            QMessageBox.critical(
                self.GetProjectFrame(),
                _('Delete branch fail'),
                _('Delete branch %s fail') % self.current_branch + ":" + str(ex)
            )
            return
        if self.CallGitProcess(f"branch -D {self.current_branch}") is not None:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('Delete branch %s success') % self.current_branch
            )

    def pull_branch(self):
        # 刚初始化仓库时需要先拉取master分支
        if self.current_branch == UNKWNOW_BRANCH_NAME:
            command = f"pull origin master"
        else:
            command = f"pull origin {self.current_branch} --allow-unrelated-histories"
        if self.CallGitProcess(command) is not None:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('Pull success')
            )

    def pull_all(self):
        command = "pull"
        if self.CallGitProcess(command) is not None:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('Pull all success')
            )

    def Pushall(self):
        repo = Repo(self.GetProjectDocument().GetPath())
        self.AsyncPush(repo)

    def Push(self, repo):
        try:
            repo.push(self.current_branch)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(self.GetProjectFrame(), _('Push fail'), str(ex))
            return
        QMessageBox.information(
            self.GetProjectFrame(),
            get_app().GetAppName(),
            _('Push success')
        )

    def AsyncPush(self, repo):
        gitcmd = AsyncCmd(repo.repo_path, self.GetProjectFrame())
        retcode, err = gitcmd.call_ret(f"push origin {self.current_branch}")
        if retcode == 0:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('Push success')
            )
        else:
            QMessageBox.critical(self.GetProjectFrame(), _('Push fail'), err)

    def Commit(self):
        commit_files = []
        try:
            repo = Repo(self.GetProjectDocument().GetPath())
            has_unmerged, commit_files = repo.status()
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return
        self.commit_push_files(repo, commit_files, has_unmerged=has_unmerged)

    def commit_push_files(
        self,
        repo,
        commit_files,
        single_file=False,
        has_unmerged=False
    ):
        dlg = CommitDialog(
            get_app().MainFrame,
            self,
            commit_files,
            single_file,
            has_unmerged=has_unmerged
        )
        if dlg.exec_() == CommitDialog.Rejected:
            return
        files = dlg.files
        try:
            if dlg.quick_commit:
                self.quick_commit_repo_files(files)
                return
            amend = False
            if dlg.amend_chkbox.isChecked():
                amend = True
            repo.commit_files(dlg.text.toPlainText(), amend=amend)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(self.GetProjectFrame(), _('Commit fail'), str(ex))
            return
        if dlg.push:
            self.AsyncPush(repo)
        else:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('Commit success')
            )

    def append_file_menu(self, menu, item):
        self.current_branch = self.GetBranch()
        if self.current_branch is None:
            return
        project_browser = self.GetProjectFrame()
        selected_files = project_browser.GetView().GetSelectedFiles()
        self.__append_file_menu_version_ctrol_menu(menu, selected_files)

    def GetProjectFrame(self):
        return get_app().MainFrame.GetView(constants.PROJECT_VIEW_NAME)

    def GetProjectDocument(self):
        project_browser = self.GetProjectFrame()
        return project_browser.GetView().GetDocument()

    def popup_edit_text_menu(self, doc, menu, editor):
        self.current_branch = self.GetBranch()
        if self.current_branch is None:
            return
        edit_view = editor.get_view()
        filepath = edit_view.GetDocument().GetFilename()
        self.__append_edit_text_version_ctrol_menu(menu, filepath)

    def diff_file_content(self, filepath, diff_with_rule=False):
        commit_files = []
        proj_doc = self.GetProjectDocument()
        try:
            repo = Repo(proj_doc.GetPath())
            _has_unmerged, commit_files = repo.status(filepath)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return
        if not commit_files:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('The content of this file has no change')
            )
            return
        diff_file_path = filepath
        proj_file = proj_doc.GetModel().FindFile(filepath)
        if not proj_file:
            utils.get_logger().error(
                "file %s is not in project %s",
                filepath,
                proj_doc.GetModel().name
            )
        else:
            diff_file_path = proj_doc.GetModel().GetRelativePath(proj_file)
        diffdlg = FileDiffDialog(
            self.GetProjectFrame(),
            self,
            diff_file_path,
            commit_files[-1].file_state,
            diff_with_rule
        )
        diffdlg.exec_()

    def checkout_files(self, files):
        ret = QMessageBox.question(
            self.GetProjectFrame(),
            get_app().GetAppName(),
            _('Checkout file will overwrite current file content,Are you sure to checkout?')
        )
        if ret == QMessageBox.No:
            return
        repo = Repo(self.GetProjectDocument().GetPath())
        for filepath in files:
            try:
                repo.checkout(filepath)
            except Exception as ex:
                utils.get_logger().error(str(ex))
                QMessageBox.critical(
                    self.GetProjectFrame(),
                    _('Error'),
                    _('checkout fail:%s') % (str(ex))
                )
                return
        QMessageBox.information(
            self.GetProjectFrame(),
            get_app().GetAppName(),
            _('Checkout success')
        )

    def add_ignore_files(self, filelist=None):
        dlg = AddIgnoreDlg(self.GetProjectDocument(), self.GetProjectFrame())
        if filelist is not None:
            for filepath in filelist:
                dlg.add_to_ignore(os.path.basename(filepath))
        dlg.exec_()

    def add_files(self, filelist: list):
        repo = Repo(self.GetProjectDocument().GetPath())
        try:
            for filepath in filelist:
                repo.add(filepath)
        except Exception as ex:
            QMessageBox.critical(self.GetProjectFrame(), _('Error'), _('Add fail:%s') % str(ex))
            return
        QMessageBox.information(self.GetProjectFrame(), get_app().GetAppName(), _('Add success'))

    def remove_files(self, filelist: list):
        repo = Repo(self.GetProjectDocument().GetPath())
        try:
            for filepath in filelist:
                repo.remove(filepath)
        except Exception as ex:
            QMessageBox.critical(self.GetProjectFrame(), _('Error'), _('Remove fail:%s') % str(ex))
            return
        QMessageBox.information(self.GetProjectFrame(), get_app().GetAppName(), _('Remove success'))

    def delete_files(self, filelist: list):
        yes_no_msg = QMessageBox.question(
            self.GetProjectFrame(),
            _("Delete Files"),
            _("Are you sure to delete files from the project and file system permanently?\n\nPlease use git checkout command to restore the deleted files."),
            QMessageBox.Yes | QMessageBox.No
        )
        if yes_no_msg == QMessageBox.No:
            return
        repo = Repo(self.GetProjectDocument().GetPath())
        try:
            for filepath in filelist:
                repo.remove(filepath, delete=True)
        except Exception as ex:
            QMessageBox.critical(self.GetProjectFrame(), _('Error'), _('Delete fail:%s') % str(ex))
            return
        QMessageBox.information(self.GetProjectFrame(), get_app().GetAppName(), _('Delete success'))
        self.GetProjectDocument().GetFirstView().RemoveFromProject()

    def commit_repo_files(self, filelist):
        commit_files = []
        repo = Repo(self.GetProjectDocument().GetPath())
        try:
            for filepath in filelist:
                _has_unmerged, commited_files = repo.status(filepath)
                commit_files.extend(commited_files)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return
        self.commit_push_files(repo, commit_files, len(filelist) == 1)

    def quick_commit_repo_files(self, filelist):
        simple_commit_text = ''
        docpath = self.GetProjectDocument().GetPath()
        repo = Repo(docpath)
        try:
            for filepath in filelist:
                if not os.path.isabs(filepath):
                    filepath = os.path.join(docpath, filepath)
                commited_files = repo.status(filepath)[1]
                if commited_files:
                    filename = fileutils.get_filename_from_path(filepath)
                    repo.add(filepath)
                    commit_file = commited_files[0]
                    if commit_file.file_state in [RepofileState.FILE_MODIFIED_STAGED, RepofileState.FILE_MODIFIED_UNSTAGED]:
                        simple_commit_text += _('Modify File') + ":" + filename
                        simple_commit_text += os.linesep
                    elif commit_file.file_state in [RepofileState.FILE_DELETED_STAGED, RepofileState.FILE_DELETED_UNSTAGED]:
                        simple_commit_text += _('Delete File') + ":" + filename
                        simple_commit_text += os.linesep
                    elif commit_file.file_state in [RepofileState.FILE_UNTRACKED, RepofileState.FILE_NEW_STAGED]:
                        simple_commit_text += _('Add File') + ":" + filename
                        simple_commit_text += os.linesep
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return
        if not simple_commit_text:
            QMessageBox.information(
                self.GetProjectFrame(),
                get_app().GetAppName(),
                _('No changes to commit')
            )
            return
        repo.commit_files(simple_commit_text)
        QMessageBox.information(
            self.GetProjectFrame(),
            get_app().GetAppName(),
            _('Commit success')
        )

    def CallGitProcess(self, command, ask_pass=False) -> Optional[str]:
        try:
            git_cmd = GitdocCmd(self.GetProjectDocument())
            return git_cmd.call_output(command)
        except Exception as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(self.GetProjectFrame(), _('Error'), str(ex))
        return None

    def GetBranch(self):
        try:
            repo = Repo(self.GetProjectDocument().GetPath())
            return repo.branch()
        except Exception as ex:
            utils.get_logger().error(str(ex))
            return None

    def __append_edit_text_version_ctrol_menu(self, menu, filepath):
        submenu = NewQMenu(_("Version Control"))
        menu.AppendMenu(newid(), submenu)
        submenu.Append(newid(), _("Commit"), handler=lambda: self.commit_repo_files([filepath]))
        submenu.Append(
            newid(),
            _('Quick Commit'),
            handler=lambda: self.quick_commit_repo_files([filepath])
        )
        submenu.Append(newid(), _("Checkout"), handler=lambda: self.checkout_files([filepath]))
        submenu.Append(
            newid(),
            _('Add to ignore'),
            handler=lambda: self.add_ignore_files([filepath])
        )
        submenu.Append(newid(), _("Add"), handler=lambda: self.add_files([filepath]))
        submenu.Append(newid(), _("Remove"), handler=lambda: self.remove_files([filepath]))
        submenu.Append(newid(), _("Delete"), handler=lambda: self.delete_files([filepath]))
        submenu.Append(newid(), _("Diff"), handler=lambda: self.diff_file_content(filepath))
        submenu.Append(
            newid(),
            _('Diff with rules'),
            handler=lambda: self.diff_file_content(filepath, True)
        )

    def __append_file_menu_version_ctrol_menu(self, menu, filelist):
        submenu = NewQMenu(_("Version Control"))
        menu.AppendMenu(newid(), submenu)
        submenu.Append(
            newid(),
            _("Commit"),
            handler=lambda: self.commit_repo_files(filelist)
        )
        submenu.Append(
            newid(),
            _("Checkout"),
            handler=lambda: self.checkout_files(filelist)
        )
        submenu.Append(
            newid(),
            _("Add to ignore"),
            handler=lambda: self.add_ignore_files(filelist)
        )
        submenu.Append(
            newid(),
            _("Add"),
            handler=lambda: self.add_files(filelist)
        )
        submenu.Append(
            newid(),
            _("Remove"),
            handler=lambda: self.remove_files(filelist)
        )
        submenu.Append(
            newid(),
            _("Delete"),
            handler=lambda: self.delete_files(filelist)
        )
        submenu.Append(newid(), _("Diff"), handler=lambda: self.diff_file_content(filelist[0]))
