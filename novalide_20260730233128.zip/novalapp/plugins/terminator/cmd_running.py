import os
import collections
from threading import Thread
import winpty
from novalapp import get_app
from novalapp.executable import Executable
from ...backend.running import Runner, SubprocessProxy
from ...backend.command import PROGRAM_OUTPUT_EVENT_NAME, BackendEvent
from ...util import utils
from .cmd_names import CmdName
from ...util.exceptions import BackendTerminatedError

RUN_TERMINAL_BACKENDKEY = "run.terminal.backend_name"


class CmdRunner(Runner):
    """description of class"""

    def get_backend(self):
        backend_name = utils.profile_get(
            RUN_TERMINAL_BACKENDKEY,
            CmdName.SIMULATECMD
        )
        return backend_name


class ShellCmdProxy(SubprocessProxy):
    def __init__(self, executable_name, clean):
        self._is_welcome_text = True
        path = self.get_backend_location(executable_name)
        utils.get_logger().info("executable name %s path is %s", executable_name, path)
        super().__init__(clean, path)

    @staticmethod
    def get_backend_location(executable_name):
        path = Executable.get_location(executable_name)
        if path is None:
            raise RuntimeError("Canot locate backend path of %s" % executable_name)
        return path

    def send_program_input(self, data):
        if self._proc is None:
            return
        self._proc.stdin.write(data + "\n")
        self._proc.stdin.flush()
        self._is_welcome_text = False

    def get_cwd(self):
        current_project = get_app().get_current_project()
        if current_project is None:
            return super().get_cwd()
        return current_project.GetPath()

    def _get_launcher_with_args(self):
        return []

    def _listen_stdout(self, stdout):
        # will be called from separate thread
        message_queue = self._response_queue
        while not self._is_disconnected():
            data = stdout.readline()
            utils.get_logger().debug("... read some stdout data %s", repr(data))
            if data == "":
                break
            # print first part as it is
            # 第一部分输出为输入命令本身，忽略,但是开头输出的欢迎文本除外
            if self._is_welcome_text:
                message_queue.append(BackendEvent(PROGRAM_OUTPUT_EVENT_NAME,
                                                  data=data, stream_name="stdout")
                                     )
            extra_data = ''
            while True:
                char = stdout.read(1)
                extra_data += char
                if char in ('>', ''):
                    break

            message_queue.append(
                BackendEvent(PROGRAM_OUTPUT_EVENT_NAME,
                             data=extra_data, stream_name="stdout")
            )


class WinPtyProxy(SubprocessProxy):
    def __init__(self, executable_name, clean):
        path = ShellCmdProxy.get_backend_location(executable_name)
        utils.get_logger().info("win pty executable name %s path is %s", executable_name, path)
        super().__init__(clean, path)

    def send_program_input(self, data):
        if self._proc is None:
            return
        self._proc.write(data + os.linesep)

    def get_cwd(self):
        current_project = get_app().get_current_project()
        if current_project is None:
            return super().get_cwd()
        return current_project.GetPath()

    def backend_crash_error(self):
        raise BackendTerminatedError(
            self._proc.exitstatus if self._proc else None)

    def _is_disconnected(self):
        return self._proc is None or not self._proc.isalive()

    def _start_background_process(self):
        # deque, because in one occasion I need to put messages back
        self._response_queue = collections.deque()
        if not os.path.exists(self._executable):
            raise RuntimeError(
                "WinPty backend path (%s) not found. Please recheck corresponding option!"
                % self._executable
            )
        utils.get_logger().info("Starting the win pty backend: %s %s",
                                self._executable, self._get_initial_cwd())
        self._proc = winpty.PtyProcess.spawn(self._executable)
        # setup asynchronous output listeners
        Thread(target=self._listen_output, daemon=True).start()

    def _listen_output(self):
        # will be called from separate thread
        message_queue = self._response_queue
        while not self._is_disconnected():
            data = self._proc.readline()
            utils.get_logger().debug("... read some stdout data %s", repr(data))
            if data:
                message_queue.append(BackendEvent(PROGRAM_OUTPUT_EVENT_NAME,
                                                  data=data, stream_name="stdout")
                                     )
            extra_data = self._proc.read()
            if extra_data:
                message_queue.append(
                    BackendEvent(PROGRAM_OUTPUT_EVENT_NAME,
                                 data=extra_data, stream_name="stdout")
                )

    def _get_launcher_with_args(self):
        return []

    def _close_backend(self):
        if self._proc is not None:
            self._proc.close()
        self._proc = None
        self._response_queue = None


class PowerShellProxy(WinPtyProxy):
    def __init__(self, clean):
        super().__init__("powershell.exe", clean)


class SystemCmdProxy(WinPtyProxy):
    def __init__(self, clean):
        super().__init__("cmd.exe", clean)


class GitBashProxy(ShellCmdProxy):
    def __init__(self, clean):
        super().__init__("git", clean)
        git_install_path = os.path.dirname(os.path.dirname(self._executable))
        self._executable = os.path.join(git_install_path, "git-bash.exe")
        utils.get_logger().info("git bash path is %s", self._executable)
