
LAST_OPEN_DOCUMENT_KEY = "lastOpenDocument"
