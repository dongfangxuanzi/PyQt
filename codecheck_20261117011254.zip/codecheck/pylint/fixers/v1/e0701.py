import re
from novalapp.python.parser import node_utils
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintE0701Fixer(PylintFixer):
    '''
    规则说明:try-except捕获异常顺序不正确
    '''

    def __init__(self):
        super().__init__('E0701', self.FixKind.AUTOFIX)

    @staticmethod
    def is_hander_type_infer_classname(type_node, except_classname):
        infer_val = node_utils.safe_infer(type_node)
        if infer_val is not None and isinstance(infer_val, nodes.ClassDef):
            if infer_val.name == except_classname:
                return True
        return False

    @classmethod
    def get_parent_except_node(cls, parent_except_classname, trynode):
        for hander in trynode.handlers:
            if hander.type:
                if isinstance(hander.type, nodes.Tuple):
                    for elt in hander.type.elts:
                        if cls.is_handler_type_classname(elt, parent_except_classname):
                            return elt
                else:
                    if cls.is_handler_type_classname(hander.type, parent_except_classname):
                        return hander.type
        return None

    @classmethod
    def is_handler_type_classname(cls, type_node, except_name):
        is_typename = type_node.as_string() == except_name
        if is_typename or cls.is_hander_type_infer_classname(type_node, except_name):
            return True
        return False

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        res = re.search(
            r'Bad except clauses order \((.+) is an ancestor class of (.+)\) \(',
            msg.msg
        )
        parent_except_classname, child_except_classname = res.groups()
        pnode = node.parent
        parent_except_node = None
        if isinstance(node, nodes.ExceptHandler) and isinstance(pnode, nodes.Try):
            if node.type:
                if isinstance(node.type, nodes.Tuple):
                    for elt in node.type.elts:
                        if self.is_handler_type_classname(elt, child_except_classname):
                            parent_except_node = self.get_parent_except_node(
                                parent_except_classname,
                                pnode
                            )
                            break
                else:
                    if self.is_handler_type_classname(node.type, child_except_classname):
                        parent_except_node = self.get_parent_except_node(
                            parent_except_classname,
                            pnode
                        )
                if parent_except_node is None:
                    return False
                self.fix_node_text(node.type, parent_except_classname)
                self.fix_node_text(parent_except_node, child_except_classname)
                return True
        return False
