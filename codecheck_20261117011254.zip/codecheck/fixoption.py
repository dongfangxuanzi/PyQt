'''
Name:        fixoption.py
Purpose:
Author:      wukan
Created:     2026-04-11
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from novalapp.util import ui_utils, utils
from novalapp.lib.pyqt import (
    QLabel,
    QHBoxLayout,
    QCheckBox,
    Qt,
    QSpinBox,
    QMessageBox,
    QVBoxLayout,
    QRadioButton,
    QGroupBox,
    QComboBox
)
from novalapp import _, get_app
from novalapp.settings.setting_wrapper import settings
from .strings import (
    PYLINT_TOOL_NAME,
    COMMON_PYLINT_MESSAGE_ID,
    EXTERNAL_PYLINT_FIX_TOOL,
    DEFAULT_PYLINT_FIX_TOOL
)
from .toolmanager import CodecheckToolManager
from .multifixer import MultiOptionFixer
from . import configkeys
from .pylint_fix import PylintFixer


class CodeFixOptionPanel(ui_utils.BaseConfigurationPanel):
    """
    代码修复配置面板
    """

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.layout.setAlignment(Qt.AlignTop)
        fix_depth = utils.profile_get_int(configkeys.AUTOPEP8_FIXDEPTH_KEY, 0)
        self.fix_depth_spin = self.create_label_step_spin_widget(
            _('Please set autopep8 fix depth') + ':',
            fix_depth,
            3,
            0,
            1
        )
        wildcard_import_members_count = utils.profile_get_int(
            configkeys.WILDCARD_IMPORT_COUNT_KEY,
            PylintFixer.DEFAULT_MAX_MEMBERS_COUNT
        )
        self.wildcard_import_spin = self.create_label_step_spin_widget(
            _('Wildcard import max members count') + ':',
            wildcard_import_members_count,
            50,
            10,
            5
        )
        self.convert_tabs_spaces_chkbox = QCheckBox(
            _("Convert all tabs to spaces"))
        self.convert_tabs_spaces_chkbox.setChecked(utils.profile_get_int(
            configkeys.CONVERT_TABS_SPACES_KEY, False))
        self.layout.addWidget(self.convert_tabs_spaces_chkbox)

        self.delete_comment_out_codes_chkbox = QCheckBox(
            _("Delete comment out codes"))
        self.delete_comment_out_codes_chkbox.setChecked(utils.profile_get_int(
            configkeys.DELETE_COMMENT_OUT_CODES_KEY, False))
        self.layout.addWidget(self.delete_comment_out_codes_chkbox)

        self.delete_todo_chkbox = QCheckBox(
            _("Delete todo/fixme tasks"))
        self.delete_todo_chkbox.setChecked(utils.profile_get_int(
            configkeys.DELETE_TODO_KEY, False))
        self.layout.addWidget(self.delete_todo_chkbox)

        self.delete_assert_chkbox = QCheckBox(
            _("Delete all `assert` statements"))
        self.delete_assert_chkbox.setChecked(utils.profile_get_int(
            configkeys.DELETE_ASSERT_KEY, False))
        self.layout.addWidget(self.delete_assert_chkbox)

        self.delete_suppressed_messages_chkbox = QCheckBox(
            _("Delete all pylint suppressed messages"))
        self.delete_suppressed_messages_chkbox.setChecked(utils.profile_get_int(
            configkeys.DELETE_SUPPRESSED_MESSAGE_KEY, False))
        self.layout.addWidget(self.delete_suppressed_messages_chkbox)

        self.remove_print_statement_chkbox = QCheckBox(
            _("Remove all `print` statements after fix one file"))
        self.remove_print_statement_chkbox.setChecked(utils.profile_get_int(
            configkeys.REMOVE_PRINT_STATEMENT_KEY, False))
        self.layout.addWidget(self.remove_print_statement_chkbox)

        self.format_docstr_chkbox = QCheckBox(
            _("Format document str(Module,Class,Function/Method)"))
        self.format_docstr_chkbox.setChecked(utils.profile_get_int(
            configkeys.FORMAT_DOCSTR_KEY, False))
        self.layout.addWidget(self.format_docstr_chkbox)

        sbox = QGroupBox(_("Standardize the naming style of identifiers"))
        hbox = QHBoxLayout()
        hbox.setAlignment(Qt.AlignLeft)
        self.local_variables_naming_style_chkbox = QCheckBox(_("Local variables"))
        self.local_variables_naming_style_chkbox.setChecked(utils.profile_get_int(
            configkeys.STANDARDIZE_LOCAL_VARIABLE_NAME_STYLE_KEY, False))
        hbox.addWidget(self.local_variables_naming_style_chkbox)

        self.class_attribute_naming_style_chkbox = QCheckBox(_("Class attributes"))
        self.class_attribute_naming_style_chkbox.setChecked(utils.profile_get_int(
            configkeys.STANDARDIZE_CLASS_ATTR_NAME_STYLE_KEY, False))
        hbox.addWidget(self.class_attribute_naming_style_chkbox)

        self.function_arg_naming_style_chkbox = QCheckBox(_("Function args"))
        self.function_arg_naming_style_chkbox.setChecked(utils.profile_get_int(
            configkeys.STANDARDIZE_FUNCTION_ARG_NAME_STYLE_KEY, False))
        hbox.addWidget(self.function_arg_naming_style_chkbox)

        self.module_naming_style_chkbox = QCheckBox(_("Modules"))
        self.module_naming_style_chkbox.setChecked(utils.profile_get_int(
            configkeys.STANDARDIZE_MODULE_NAME_STYLE_KEY, False))
        hbox.addWidget(self.module_naming_style_chkbox)
        sbox.setLayout(hbox)
        self.layout.addWidget(sbox)

        self.fix_wildcard_imports_chkbox = QCheckBox(_("Fix wildcard imports"))
        self.fix_wildcard_imports_chkbox.setChecked(utils.profile_get_int(
            configkeys.FIX_WILDCARD_IMPORTS_KEY, False))
        self.layout.addWidget(self.fix_wildcard_imports_chkbox)

        self.fix_format_codefile_chkbox = QCheckBox(_("Format code file before fix warnings"))
        self.fix_format_codefile_chkbox.setChecked(utils.profile_get_int(
            configkeys.FORMAT_CODEFILE_BEFORE_FIX_KEY, False))
        self.layout.addWidget(self.fix_format_codefile_chkbox)

        fixtool_name = settings().get_default(
            configkeys.PYLINT_FIX_TOOL_KEY,
            DEFAULT_PYLINT_FIX_TOOL
        )
        self.ues_pylinter_tool_chkbox = QCheckBox(
            _("Use external tool 'pylinter' to fix pylint warnings")
        )
        self.ues_pylinter_tool_chkbox.setChecked(fixtool_name == EXTERNAL_PYLINT_FIX_TOOL)
        self.ues_pylinter_tool_chkbox.clicked.connect(self.update_repeat_checkstate)
        self.layout.addWidget(self.ues_pylinter_tool_chkbox)

        self.__repeat_fix_chkbox = QCheckBox(
            _("Repeat fix pylint warnings until there are no more fixables")
        )
        self.layout.addWidget(self.__repeat_fix_chkbox)
        fix_tool = CodecheckToolManager.manager().find_tool(PYLINT_TOOL_NAME)
        repeat_times = settings().get_default(
            configkeys.FIX_REPEAT_TIMES,
            fix_tool.MAX_FIX_TRY_TIMES
        )
        self.repeat_times_spin = self.create_label_step_spin_widget(
            _('Max times of repeatition') + ':',
            repeat_times,
            10,
            5,
            1
        )
        self.update_repeat_checkstate()
        repeat_fix_warnings = settings().get_default(configkeys.REPEAT_FIX_WARNINGS_KEY, False)

        self.__repeat_fix_chkbox.setChecked(repeat_fix_warnings)
        self.repeat_times_spin.setValue(repeat_times)

    @staticmethod
    def enable_rule_autofixed(options_dialog, ruleid, autofix_enabled):
        pylint_option_panel = options_dialog.GetOptionPanel(_("CodeCheck"), "Pylint")
        if autofix_enabled and not pylint_option_panel.is_rule_checked(ruleid):
            raise RuntimeError(
                _('Please start using `%s` rule of tool `%s` first.') % (ruleid, PYLINT_TOOL_NAME)
            )
        autofix_key = configkeys.TOOL_RULES_AUTOFIX_KEY % (
            PYLINT_TOOL_NAME, ruleid)
        fix_tool = CodecheckToolManager.manager().find_tool(PYLINT_TOOL_NAME)
        pylint_option_panel.set_autofix_checked(ruleid, autofix_enabled)
        fixer = fix_tool.find_fixer(ruleid)
        if fixer is None:
            utils.get_logger().warning(
                'rule `%s` of tool %s has no fixer',
                ruleid,
                PYLINT_TOOL_NAME
            )
            return
        fixer.autofix = autofix_enabled
        settings().set(autofix_key, fixer.kind.value)

    def update_repeat_checkstate(self):
        if self.ues_pylinter_tool_chkbox.isChecked():
            self.__repeat_fix_chkbox.setEnabled(True)
            self.repeat_times_spin.setEnabled(True)
        else:
            self.__repeat_fix_chkbox.setEnabled(False)
            self.repeat_times_spin.setEnabled(False)

    def create_label_step_spin_widget(self, label, value, maximum, minimum, singleStep):
        widget_hbox = QHBoxLayout()
        widget_hbox.setAlignment(Qt.AlignLeft)
        widget_hbox.addWidget(QLabel(label))
        spinbox = QSpinBox(
            value=value,
            maximum=maximum,
            minimum=minimum,
            singleStep=singleStep
        )
        widget_hbox.addWidget(spinbox)
        self.layout.addLayout(widget_hbox)
        return spinbox

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        utils.profile_set(configkeys.AUTOPEP8_FIXDEPTH_KEY, self.fix_depth_spin.value())
        max_wildcard_members_count = self.wildcard_import_spin.value()
        utils.profile_set(configkeys.WILDCARD_IMPORT_COUNT_KEY, max_wildcard_members_count)

        utils.profile_set(configkeys.CONVERT_TABS_SPACES_KEY,
                          self.convert_tabs_spaces_chkbox.isChecked())
        utils.profile_set(configkeys.DELETE_COMMENT_OUT_CODES_KEY,
                          self.delete_comment_out_codes_chkbox.isChecked())
        utils.profile_set(configkeys.DELETE_TODO_KEY,
                          self.delete_todo_chkbox.isChecked())
        utils.profile_set(configkeys.DELETE_ASSERT_KEY,
                          self.delete_assert_chkbox.isChecked())
        utils.profile_set(configkeys.DELETE_SUPPRESSED_MESSAGE_KEY,
                          self.delete_suppressed_messages_chkbox.isChecked())
        remove_print_checked = self.remove_print_statement_chkbox.isChecked()
        utils.profile_set(configkeys.REMOVE_PRINT_STATEMENT_KEY, remove_print_checked)
        utils.profile_set(configkeys.FORMAT_DOCSTR_KEY,
                          self.format_docstr_chkbox.isChecked())
        utils.profile_set(configkeys.STANDARDIZE_LOCAL_VARIABLE_NAME_STYLE_KEY,
                          self.local_variables_naming_style_chkbox.isChecked())
        utils.profile_set(configkeys.STANDARDIZE_MODULE_NAME_STYLE_KEY,
                          self.module_naming_style_chkbox.isChecked())
        utils.profile_set(configkeys.STANDARDIZE_CLASS_ATTR_NAME_STYLE_KEY,
                          self.class_attribute_naming_style_chkbox.isChecked())
        utils.profile_set(configkeys.STANDARDIZE_FUNCTION_ARG_NAME_STYLE_KEY,
                          self.function_arg_naming_style_chkbox.isChecked())
        utils.profile_set(configkeys.FIX_WILDCARD_IMPORTS_KEY,
                          self.fix_wildcard_imports_chkbox.isChecked())
        utils.profile_set(configkeys.FORMAT_CODEFILE_BEFORE_FIX_KEY,
                          self.fix_format_codefile_chkbox.isChecked())
        is_module_naming_checked = self.module_naming_style_chkbox.isChecked()
        is_class_attr_naming_checked = self.class_attribute_naming_style_chkbox.isChecked()
        is_func_arg_naming_checked = self.function_arg_naming_style_chkbox.isChecked()
        is_localvar_naming_checked = self.local_variables_naming_style_chkbox.isChecked()
        try:
            self.enable_rule_autofixed(
                options_dialog,
                'W9000',
                self.delete_comment_out_codes_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'W0511',
                self.delete_todo_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'W9002',
                self.delete_assert_chkbox.isChecked()
            )
            self.enable_rule_autofixed(
                options_dialog,
                'I0020',
                self.delete_suppressed_messages_chkbox.isChecked()
            )
            is_c0103_autofix_enabled = (
                is_class_attr_naming_checked or is_module_naming_checked
            ) or (
                is_func_arg_naming_checked or is_localvar_naming_checked
            )
            self.enable_rule_autofixed(
                options_dialog,
                'C0103',
                is_c0103_autofix_enabled
            )
            self.enable_rule_autofixed(
                options_dialog,
                'W0401',
                self.fix_wildcard_imports_chkbox.isChecked()
            )
        except RuntimeError as ex:
            QMessageBox.information(
                self,
                get_app().GetAppName(),
                str(ex)
            )
            return False
        fix_tool = CodecheckToolManager.manager().find_tool(PYLINT_TOOL_NAME)
        if not fix_tool.path:
            utils.get_logger().error('find tool %s path is null', PYLINT_TOOL_NAME)
            return True
        c0103_fixer = fix_tool.find_fixer('C0103')
        if c0103_fixer is not None:
            c0103_fixer.standardize_module_name_style = is_module_naming_checked
            c0103_fixer.standardize_local_variable_name_style = is_localvar_naming_checked
            c0103_fixer.standardize_class_attr_name_style = is_class_attr_naming_checked
            c0103_fixer.standardize_function_arg_name_style = is_func_arg_naming_checked

        w0401_fixer = fix_tool.find_fixer('W0401')
        if w0401_fixer is not None:
            w0401_fixer.max_member_count = max_wildcard_members_count

        pylint_common_fixer = fix_tool.find_fixer(COMMON_PYLINT_MESSAGE_ID)
        pylint_common_fixer.enable_format_module_doc = self.format_docstr_chkbox.isChecked()
        pylint_common_fixer.enable_remove_print_expression = remove_print_checked
        pylint_common_fixer.enable_convert_tabs = self.convert_tabs_spaces_chkbox.isChecked()
        pylint_fix_tool = EXTERNAL_PYLINT_FIX_TOOL if self.ues_pylinter_tool_chkbox.isChecked() else DEFAULT_PYLINT_FIX_TOOL
        settings().set(configkeys.PYLINT_FIX_TOOL_KEY, pylint_fix_tool)
        settings().set(configkeys.REPEAT_FIX_WARNINGS_KEY, self.__repeat_fix_chkbox.isChecked())
        settings().set(configkeys.FIX_REPEAT_TIMES, self.repeat_times_spin.value())
        return True


class MultiFixPanel(ui_utils.BaseConfigurationPanel):
    """
    多重修复默认修复方案配置面板
    """

    def __init__(self, parent):
        ui_utils.BaseConfigurationPanel.__init__(self, parent)
        self.layout.setAlignment(Qt.AlignTop)
        self.layout.addWidget(
            QLabel(_("Choose default fix option of multi fixer") + ":"))

        self.multi_fixers = []

        self.fixer_combo_box = QComboBox()
        self.layout.addWidget(self.fixer_combo_box)

        self.fixer_sbox = QGroupBox(_("Fix Options"))
        self.options_hbox = QVBoxLayout()
        self.options_hbox.setAlignment(Qt.AlignLeft)
        self.fixer_sbox.setLayout(self.options_hbox)
        self.layout.addWidget(self.fixer_sbox)
        self.fixer_combo_box.currentIndexChanged.connect(self.load_options)
        self.update_fixer_options()
        self.load_options(self.fixer_combo_box.currentIndex())

    def update_fixer_options(self):
        if self.multi_fixers:
            return
        fix_tool = CodecheckToolManager.manager().find_tool(PYLINT_TOOL_NAME)
        names = []
        for fixer in fix_tool.fixers:
            if isinstance(fixer, MultiOptionFixer):
                self.multi_fixers.append(fixer)
                names.append(fixer.ruleid)
        self.fixer_combo_box.addItems(names)

    def load_options(self, index):
        if index < 0:
            return
        self.remove_options()
        fixer = self.multi_fixers[index]
        for i, option in enumerate(fixer.options):
            option_radio_button = QRadioButton(option, parent=self.fixer_sbox)
            self.options_hbox.addWidget(option_radio_button)
            if i == fixer.selection:
                option_radio_button.setChecked(True)

    def get_fixer_rule_option_index(self, fixer):
        child_radio_buttons = [
            child
            for child in self.fixer_sbox.children()
            if isinstance(child, QRadioButton)
        ]
        if len(child_radio_buttons) != len(fixer.options):
            raise AssertionError('fixer options not equal radio buttons num')
        sel = -1
        for i, radio_button in enumerate(child_radio_buttons):
            if radio_button.isChecked():
                sel = i
                break
        return sel

    def remove_options(self):
        remove_widgets = []
        for child in self.fixer_sbox.children():
            if isinstance(child, QRadioButton):
                remove_widgets.append(child)
        for child in remove_widgets:
            self.options_hbox.removeWidget(child)
        del remove_widgets

    def OnOK(self, options_dialog):
        """
        Updates the config based on the selections in the options panel.
        """
        index = self.fixer_combo_box.currentIndex()
        if index >= 0:
            fixer = self.multi_fixers[index]
            rule_option_key = configkeys.PYLINT_RULES_AUTOFIX_OPTION_KEY % fixer.ruleid
            option_index = self.get_fixer_rule_option_index(fixer)
            settings().set(rule_option_key, option_index)
        return True
