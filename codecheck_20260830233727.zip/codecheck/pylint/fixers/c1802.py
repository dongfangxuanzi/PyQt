'''
Name:        c1802.py
Purpose:     修复隐式表达式
Author:      wukan
Created:     2026-08-24
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintC1802Fixer(PylintFixer):
    '''
    规则说明: 使用列表隐式表达式判断bool值
    '''

    def __init__(self):
        super().__init__('C1802', True)

    @staticmethod
    def is_len_called(node):
        if isinstance(node, nodes.Call) and (
            isinstance(node.func, nodes.Name) and node.func.name == 'len'
        ):
            return True
        return False

    def fix_message(self, doc, msg, **kwargs):
        node = self.find_msg_node(None, msg)
        if self.is_len_called(node):
            nodestr = node.args[0].as_string()
            self.fix_node_text(node, nodestr)
            return True
        if isinstance(node, nodes.UnaryOp) and (
            node.op == 'not' and self.is_len_called(node.operand)
        ):
            nodestr = node.operand.args[0].as_string()
            self.fix_node_text(node.operand, nodestr)
            return True
        return False
