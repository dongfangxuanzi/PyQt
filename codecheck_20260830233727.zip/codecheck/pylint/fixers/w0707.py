# -*- coding: utf-8 -*-
import re
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintW0707Fixer(PylintFixer):
    '''
    规则说明:抛出异常类型要使用from关键字
    '''

    def __init__(self):
        super().__init__('W0707', True)

    def fix_message(self, doc, msg):
        res = re.search(
            r"Consider explicitly re-raising using '(.*)' and '(.*)' \(raise-missing-from\)",
            msg.msg
        )
        if not res:
            res = re.search(
                r"Consider explicitly re-raising using '(.*)' \(raise-missing-from\)",
                msg.msg
            )
            if not res:
                return False
        node = self.find_msg_node(None, msg, use_column=True)
        results = res.groups()
        if len(results) == 1:
            fix_raise_str = results[0]
        elif len(results) == 2:
            fix_raise_str = results[1]
            typname = results[0].split()[1]
            typeasname = results[0].split()[-1]
            if not isinstance(node.parent, nodes.ExceptHandler) or (
                node.parent.name is not None or node.parent.type is None or typname != node.parent.type.as_string()
            ):
                return False
            self.add_node_text(node.parent.type, f' as {typeasname}', end=True)
        if not isinstance(node, nodes.Raise) or (
            fix_raise_str.find(node.as_string()) == -1 or node.cause is not None
        ):
            return False
        self.fix_node_text(node, fix_raise_str)
        return True
