import re
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintW0614Fixer(PylintFixer):
    '''
    规则说明: 使用*号导入成员未被使用
    '''

    def __init__(self):
        super().__init__('W0614', False)

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg)
        if isinstance(node, nodes.ImportFrom):
            res = re.search(
                r'Unused import\(s\) (.*) from wildcard import of (.*) \(unused-wildcard-import\)',
                msg.msg
            )
            if not res:
                return False
            unused_name_str, modname = res.groups()
            unused_names = re.split(r',\s*| and *', unused_name_str)
            if modname == node.modname:
                used_names = []
                for name, stmts in node.root().globals.items():
                    stmt = stmts[0]
                    if isinstance(stmt, nodes.ImportFrom) and stmt.modname == modname:
                        assert stmt.names[0][0] == '*'
                        if name in unused_names:
                            continue
                        used_names.append(name)
                if not used_names:
                    self.delete_text_line(msg.line - 1)
                    return True
                nodestr = 'from %s import ' % modname
                names = []
                for name in used_names:
                    names.append(name)
                self.fix_node_text(node, nodestr + ', '.join(names))
                return True
        return False
