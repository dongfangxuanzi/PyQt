import os
from astroid import nodes
from ...multifixer import MultiOptionFixer
from ...pylint_fix import PylintFixer


class PylintW1514Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明: open函数参数缺乏encoding参数
    '''

    def __init__(self):
        super().__init__('W1514', False)
        MultiOptionFixer.__init__(
            self,
            1,
            'Open file encoding',
            'please set the file encoding with open',
            init_options=[
                'ascii',
                'utf-8',
                'cp936',
                'gbk',
                'gb2312',
                'gb18030',
                'locale.getencoding()'
            ]
        )

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg, use_column=True)
        if isinstance(node, nodes.Name) and node.name == "open" and (
            isinstance(node.parent, nodes.Call)
        ):
            callnode = node.parent
            if callnode.as_string().find('encoding=') != -1:
                return False
            self.get_selection()
            arg_strs = [arg.as_string() for arg in callnode.args]
            last_sel_index = len(self.options) - 1
            if self.selection == last_sel_index:
                arg_strs.append('%s=%s' % ('encoding', self.options[self.selection]))
            else:
                arg_strs.append('%s="%s"' % ('encoding', self.options[self.selection]))
            fixstr = "open(%s)" % ",".join(arg_strs)
            self.fix_node_text(callnode, fixstr)
            if self.selection == last_sel_index:
                visitor = self.get_import_nodes_visitor()
                if not visitor.is_import_exist('locale'):
                    insert_line = visitor.get_import_line()
                    self.add_range_text(insert_line + 1, 0, "import locale" + os.linesep)
            return True
        return False
