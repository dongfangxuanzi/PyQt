from astroid import nodes
from ...codeutils import get_node_col_offset_blanks, DEFAULT_TAB_BLANKS
from ...pylint_fix import PylintFixer


class PylintE0104Fixer(PylintFixer):
    '''
    规则说明: return语句不在函数/方法范围内
    '''

    def __init__(self):
        super().__init__('E0104', True)

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg)
        prev_node = node.previous_sibling()
        if isinstance(node, nodes.Return) and isinstance(prev_node, nodes.FunctionDef):
            return_str = node.as_string()
            offset_blanks = get_node_col_offset_blanks(prev_node)
            if prev_node.col_offset == 0:
                offset_blanks += DEFAULT_TAB_BLANKS
            fix_return_str = offset_blanks + return_str
            self.fix_node_text(node, fix_return_str)
            return True
        return False
