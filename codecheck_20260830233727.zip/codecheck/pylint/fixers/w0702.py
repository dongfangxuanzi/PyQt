# -*- coding: utf-8 -*-
'''
Name:        w0702.py
Purpose:     W0702:捕获异常没有具体的异常类型规则修复器
修复方法:
添加所有异常的基础类型Exception
Author:      wukan
Created:     2023-11-16
Copyright:   (c) wukan 2023
Licence:     <your licence>
'''
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...codeutils import get_node_col_offset_blanks


class PylintW0702Fixer(PylintFixer):
    '''
    规则说明:捕获异常没有具体的异常类型
    try:
    ...
    except:
    ...
    '''

    def __init__(self):
        super().__init__('W0702', True)

    def fix_message(self, doc, msg):
        line = msg.line
        node = self.find_msg_node(None, msg)
        if not isinstance(node, nodes.ExceptHandler) or node.type is not None:
            return False
        offset_blanks = get_node_col_offset_blanks(node)
        self.replace_line_text(line, offset_blanks + "except Exception:")
        return True
