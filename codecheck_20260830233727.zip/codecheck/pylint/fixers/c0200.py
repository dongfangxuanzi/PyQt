from astroid import nodes
from novalapp.python.parser.node_utils import get_node_childs
from novalapp.python.parser.node_scope import ScopeFinder
from ...pylint_fix import PylintFixer


class PylintC0200Fixer(PylintFixer):
    '''
    规则说明:不用使用range(len),使用for xx in enumerate代替
    '''

    def __init__(self):
        super().__init__('C0200', True)

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg)
        parent_scope = ScopeFinder.get_parent_node_by_classtype(node, [nodes.For])
        if isinstance(parent_scope, nodes.For) and isinstance(parent_scope.iter, nodes.Call) and (
            isinstance(parent_scope.iter.func, nodes.Name) and parent_scope.iter.func.name == "range"
        ):
            loop_index = parent_scope.target
            if node != loop_index:
                return False
            parent_scope.iter.func.name = 'enumerate'
            first_arg = parent_scope.iter.args[0]
            if isinstance(first_arg, nodes.Call) and (
                isinstance(first_arg.func, nodes.Name) and first_arg.func.name == "len"
            ):
                child_nodes = []
                get_node_childs(parent_scope, child_nodes)
                first_len_arg = first_arg.args[0]
                child_target_name = ''
                for child in child_nodes:
                    if isinstance(child, nodes.Assign) and isinstance(child.value, nodes.Subscript) and (
                        first_len_arg.as_string() == child.value.value.as_string() and loop_index.name == child.value.slice.name
                    ):
                        child_target_name = child.targets[0].name
                        break
                else:
                    return False
                parent_scope.iter.args[0] = first_len_arg
                self.fix_node_text(parent_scope.iter, parent_scope.iter.as_string())
                self.fix_node_text(parent_scope.target, f'{loop_index.name},{child_target_name}')
                self.delete_node(child)
                return True
        return False
