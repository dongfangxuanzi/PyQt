import re
from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ...basefix import append_doc_path
from ...pylint_fix import PylintFixer


class PylintW0222Fixer(PylintFixer):
    '''
    规则说明: 继承方法的签名改变了
    '''

    def __init__(self):
        super().__init__('W0222', False)

    @append_doc_path
    def fix_message(self, doc, msg):
        regstr = r"Signature differs from overridden '(.*)' method \(signature-differs\)"
        res = re.search(regstr, msg.msg)
        derived_method_name = res.groups()[0]
        node = self.find_msg_node(None, msg)
        pnode = node.parent
        if isinstance(node, nodes.Name) and node.name == derived_method_name and (
            isinstance(pnode, nodes.FunctionDef)
        ):
            if isinstance(pnode.parent, nodes.ClassDef):
                class_node = pnode.parent
                mros = class_node.mro()
                mros.remove(class_node)
                for mro in mros:
                    base_node_method = ScopeFinder.get_class_method_node(mro, pnode.name)
                    if base_node_method:
                        args = base_node_method.args
                        self.fix_funcdef_args(pnode, args.as_string())
                        return True
        return False
