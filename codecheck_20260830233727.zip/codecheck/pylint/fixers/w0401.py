'''
Name:        w0401.py
Purpose:
Author:      wukan
Created:     2026-07-10
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
import logging
from novalapp import get_app
from astroid import nodes
from ...pylint_fix import PylintFixer


log = logging.getLogger(__name__)


class PylintW0401Fixer(PylintFixer):
    '''
    规则说明: 导入语句使用`from module import *`
    '''
    DEFAULT_MAX_MEMBERS_COUNT = 30

    def __init__(self):
        super().__init__('W0401', False)
        self.max_member_count = self.DEFAULT_MAX_MEMBERS_COUNT

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg)
        if not isinstance(node, nodes.ImportFrom):
            return False
        res = re.search(r'Wildcard import (.*) \(wildcard-import\)', msg.msg)
        modname = res.groups()[0]
        if node.names[0][0] != '*':
            return False
        if modname != node.modname:
            log.warning(
                'msg modname %s is not current node modname %s',
                modname,
                node.modname
            )
            return False
        old_mod_name = node.modname
        old_level = node.level
        self.fix_importnodes()
        node = self.find_msg_node(None, msg)
        mdloader = get_app().intellisence_mananger.GetModule(
            node.modname
        )
        if mdloader is None:
            log.warning(
                'could not find msg modname %s of file:%s on line %d',
                node.modname,
                msg.filepath,
                msg.line
            )
            return False
        members = mdloader.get_member_list()
        node.level = old_level
        node.modname = old_mod_name
        members_count = len(members)
        if members_count > self.max_member_count:
            log.warning(
                'import modname %s members count %d is greater then max members limit:%d',
                modname,
                members_count,
                self.max_member_count
            )
            return False
        fixstr = node.as_string().replace("*", ','.join(members))
        self.fix_node_text(node, fixstr)
        return True
