import re
import astroid
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...multifixer import MultiOptionFixer


class PylintC0411Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:模块导入顺序错误
    '''

    def __init__(self):
        super().__init__('C0411', True)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Fix import position',
            descr='Please choose one fixer option',
            init_options=[
                'Reverse import position',
                'Insert top position',
                'Insert bottom position'
            ]
        )

    def reserve_nodes_position(self, top_node, bottom_node):
        '''
        调换2个节点的位置
        '''
        self.fix_node_text(bottom_node, top_node.as_string())
        self.fix_node_text(top_node, bottom_node.as_string())
        return True

    def insert_top_position(self, top_node, bottom_node):
        '''
        将底部的节点插入顶部节点的上方
        '''
        self.delete_node(bottom_node, delete_node_line=True)
        self.add_range_text(top_node.lineno, 0, bottom_node.as_string() + "\n")
        return True

    def insert_bottom_position(self, top_node, bottom_node):
        '''
        将上方的节点插入底部节点的下方
        '''
        self.delete_node(top_node, delete_node_line=True)
        self.add_range_text(bottom_node.lineno, 0, top_node.as_string() + "\n")
        return True

    def fix_nodes_position(
        self,
        top_node,
        bottom_node
    ):
        '''
        修复2个节点之间错误的位置关系,3种修复方案:
        1.调换节点位置
        2.将底部节点插入顶部节点上方
        3.将顶部节点插入底部下方
        '''
        self.get_selection()
        if bottom_node.lineno <= top_node.lineno:
            return False
        if 0 == self.selection:
            return self.reserve_nodes_position(top_node, bottom_node)
        if 1 == self.selection:
            return self.insert_top_position(top_node, bottom_node)
        if 2 == self.selection:
            return self.insert_bottom_position(top_node, bottom_node)
        return False

    def fix_message(self, doc, msg):
        line = msg.line
        self.load_msg_module(msg)
        standard_import_regstr = r'standard import "(.*)" should be placed before "(.*)" \(wrong-import-order\)'
        thirdparty_import_regstr = r'third party import "(.*)" should be placed before "(.*)" \(wrong-import-order\)'
        firstparty_import_regstr = r'first party import "(.*)" should be placed before "(.*)" \(wrong-import-order\)'
        res = re.search(standard_import_regstr, msg.msg)
        if not res:
            res = re.search(thirdparty_import_regstr, msg.msg)
            if not res:
                res = re.search(firstparty_import_regstr, msg.msg)
        if res:
            import_before_str, import_str = res.groups()
            import_node_type = None
            if re.match(r'from .* import \w+', import_str):
                import_node_type = nodes.ImportFrom
            elif re.match('import .*', import_str):
                import_node_type = nodes.Import
            elif re.match(r'from .* import\s+\*', import_str):
                import_node_type = nodes.ImportFrom
            else:
                return False
            extract_import_node = astroid.extract_node(import_str)
            import_before_node = astroid.extract_node(import_before_str)
            import_node = self.get_import_node(
                self.get_module(), line, import_node_type, extract_import_node)
            exchange_import_node = self.find_node_on_line(
                line)
            if import_node and exchange_import_node:
                if exchange_import_node.as_string() == import_before_node.as_string():
                    # 为了防止结点变动或者位置变换导致修复错误,必须满足以上条件才能进行修复功能
                    return self.fix_nodes_position(
                        import_node,
                        exchange_import_node
                    )
        return False

    def get_import_node(self, module, endline, import_node_type, extract_import_node):
        for child in module.body:
            if child.lineno > endline:
                break
            if isinstance(child, import_node_type):
                if isinstance(child, nodes.Import) and child.names == extract_import_node.names:
                    return child
                if isinstance(
                    child,
                    nodes.ImportFrom
                ) and child.modname == extract_import_node.modname and child.names == extract_import_node.names:
                    return child
        return None
