'''
Name:        w1401.py
Purpose:     检查并修复字符串里面的转义字符,尤其是在正则表达式中
Author:      wukan
Created:     2026-06-19
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from astroid import nodes
from novalapp.python.parser import node_utils
from ...pylint_fix import PylintFixer


class PylintW1401Fixer(PylintFixer):
    '''
    规则说明:字符串中包含反斜杆,但不是用作转义,
    可以添加r包含,表示是原生的raw字符串
    '''

    def __init__(self):
        super().__init__('W1401', True)

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg, use_column=True)
        if node_utils.is_const_type(node, str) or isinstance(node, nodes.FormattedValue):
            linetext = self.get_msg_line_text(msg)
            if linetext.find("r'") == -1 and linetext.find('r"') == -1 and (
                linetext.find("rf'") == -1 and linetext.find('rf"') == -1
            ):
                self.add_node_text(node, 'r')
                return True
        return False
