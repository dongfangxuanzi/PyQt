from ...pylint_fix import SarifFixer


class PylintW0212Fixer(SarifFixer):
    '''
    规则说明:
    '''

    def __init__(self):
        super().__init__('W0212', False)

    def fix_message(self, doc, msg):
        self.load_module(None, msg.filepath)
