import os
from novalapp.python.interpreter.interpreter import PythonInterpreter
from novalapp.lib.qsci import QsciScintilla
from novalapp import _, get_app, prog_lang, newid
from novalapp.plugin import iface
from novalapp.plugin import plugin
from novalapp.util import utils, strutils, fileutils
from novalapp.preference import preference
from novalapp.python.interpreter.interpreteradmin import InterpreterAdmin
from novalapp.python.interpreter.interpretermanager import InterpreterManager
from novalapp.project.wizard.templatemanager import WizardtemplateManager
from novalapp.sidebar.sidebar import SideBar
from novalapp.python.interpreter.exceptions import InterpreterError, InterpretertoolNotExistError
from novalapp.bars.menubar import NewQMenu
from novalapp.lib.pyqt import QMessageBox, QColor
from novalapp.project.sched import SchedulerRunner
from novalapp.python import utility
from novalapp.python.project.document import PythonProjectDocument
from novalapp.settings.setting_wrapper import settings
from codecheck import messageviewer
from codecheck import codecheck, fixoption
from .fix2to3 import Fix2to3Processor
from .sched_processor import CodecheckProcessor
from .pkgres import get_message_icon_path, get_metrics_image_path
from .fix_processor import FixerProcessor
from .configure import pylintconfig, flake8config
from .codeutils import get_tools_data_path, FilesregType
from .toolmanager import CodecheckToolManager
from .basetool import BasePythonCheckTool
from .strings import MESSAGE_VIEW_NAME, METRICS_VIEW_NAME
from . import configkeys
from .common_processor import CommonProcessor
from .exceptions import FixfileError
from .counter import metricsviewer
from .counter.counter import CodeMetricsProcessor
from .strings import PYLINT_TOOL_NAME


class CodecheckPlugin(plugin.Plugin):
    """plugin description here..."""
    plugin.Implements(iface.MainWindowI)

    @property
    def use_internal_interpreter(self):
        return self._use_internal_interpreter

    @staticmethod
    def get_tool_file_messages(check_tool, doc, filepath):
        messages = []
        if check_tool.is_filetool_enabled(filepath):
            message_file = check_tool.get_file_log_path(doc, filepath)
            if os.path.exists(message_file):
                try:
                    messages = CommonProcessor.load_file_messages(check_tool, message_file)
                except Exception as ex:
                    utils.get_logger().error(str(ex))
        return messages

    @staticmethod
    def is_code_file(filepath):
        ext = strutils.get_file_extension(filepath)
        return ext in SchedulerRunner.SYNTAX_EXTS

    def select_project(self, i):
        if i < 0:
            utils.get_logger().error('invalid item index `%d` when loading project', i)
            return
        cur_document = self.project_browser.GetView().Documents[i]
        utils.get_logger().info('current project document path is %s', cur_document.GetFilename())
        if not CommonProcessor.use_codecheck(cur_document):
            utils.get_logger().warning(
                'codecheck function of current project %s is disabled...',
                cur_document.GetModel().name
            )

        self.message_viewer.doc = cur_document
        self.message_viewer.update_state()

    def popup_root_menu(self, menu, item):
        submenu = NewQMenu(_("CodeCheck"))
        menu.AppendMenu(newid(), submenu)
        submenu.Append(
            newid(),
            _("Full Files Check"),
            handler=self.check_all_files,
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("BatchFix"),
            handler=self.batch_fix_files,
            tester=self.is_codecheck_menu_enabled
        )

    def popup_file_menu(self, menu, item):
        filepath = self.project_browser.GetView()._GetItemFilePath(item)
        filepath = fileutils.opj(filepath)
        if not self.is_code_file(filepath):
            return
        submenu = NewQMenu(_("CodeCheck"))
        menu.AppendMenu(newid(), submenu)
        submenu.Append(
            newid(),
            _("Single File Check"),
            handler=lambda: self.check_single_file(filepath),
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("Full Files Check"),
            handler=self.check_all_files,
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("AutoFix(Single File)"),
            handler=lambda: self.fix_single_file(filepath),
            tester=self.is_codecheck_menu_enabled
        )
        edit_view = None
        doc = get_app().GetDocumentManager().GetDocument(filepath)
        if doc is not None:
            edit_view = doc.GetFirstView()
        submenu.Append(
            newid(),
            _("Code Format"),
            handler=lambda: self.format_code_file(
                self.project_browser.GetView().GetDocument(),
                filepath,
                edit_view
            ),
            tester=self.is_codecheck_menu_enabled
        )

    def is_codecheck_menu_enabled(self):
        '''
        代码检测或修复过程中,代码检查菜单是禁止状态
        '''
        return not self.message_viewer.processor.running

    def popup_edit_text_menu(self, doc, menu, editor):
        edit_view = editor.get_view()
        if not self.is_code_file(
            edit_view.GetDocument().GetFilename()
        ):
            return
        filepath = edit_view.GetDocument().GetFilename()
        filepath = fileutils.opj(filepath)
        submenu = NewQMenu(_("CodeCheck"))
        menu.AppendMenu(newid(), submenu)
        submenu.Append(
            newid(),
            _("Single File Check"),
            handler=lambda: self.check_single_file(filepath),
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("Full Files Check"),
            handler=self.check_all_files,
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("AutoFix(Single File)"),
            handler=lambda: self.fix_single_file(filepath),
            tester=self.is_codecheck_menu_enabled
        )
        submenu.Append(
            newid(),
            _("Code Format"),
            handler=lambda: self.format_code_file(
                doc,
                filepath,
                editor.get_view()
            ),
            tester=self.is_codecheck_menu_enabled
        )
        if not CommonProcessor.is_filepath_excluded(doc, filepath):
            submenu.Append(
                newid(),
                _("Exclude File"),
                handler=lambda: self.add_exclude_file(
                    doc,
                    filepath
                )
            )
        else:
            submenu.Append(
                newid(),
                _("Remove Exclude"),
                handler=lambda: self.remove_exclude_file(
                    doc,
                    filepath
                )
            )

    def add_exclude_file(self, doc, filepath):
        exclude_files = utils.profile_get(
            doc.GetKey(configkeys.CODECHECK_EXCLUDE_FILES_KEY),
            ""
        )
        filename = fileutils.get_filename_from_path(filepath)
        if strutils.is_none_empty(exclude_files):
            exclude_files = filename
        else:
            exclude_files += ("|" + filename)
        utils.profile_set(
            doc.GetKey(configkeys.CODECHECK_EXCLUDE_FILES_KEY),
            exclude_files
        )
        utils.profile_set(
            doc.GetKey(configkeys.FILES_REGTYPE_KEY),
            FilesregType.EXCLUDE_FILES.value
        )

    def remove_exclude_file(self, doc, filepath):
        exclude_files = utils.profile_get(
            doc.GetKey(configkeys.CODECHECK_EXCLUDE_FILES_KEY),
            ""
        )
        filename = fileutils.get_filename_from_path(filepath)
        assert exclude_files.find(filename) != -1
        if exclude_files.find("|") == -1:
            exclude_files = exclude_files.replace(filename, "")
        else:
            exclude_files = exclude_files.replace("|" + filename, "")
        utils.profile_set(
            doc.GetKey(configkeys.CODECHECK_EXCLUDE_FILES_KEY),
            exclude_files
        )

    def is_enabled_for_extension(self, filepath):
        '''
        插件是否有支持检测该文件后缀的工具
        '''
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            if check_tool.is_filetool_enabled(filepath):
                return True
        ext = strutils.get_file_extension(filepath)
        QMessageBox.critical(
            get_app().GetTopWindow(),
            _('Error'),
            _('There is no valid check tool for file extension `*.%s`') % ext
        )
        return False

    def check_single_file(self, filepath):
        if not self.is_enabled_for_extension(filepath):
            return
        get_app().MainFrame.activateBottomTab(MESSAGE_VIEW_NAME)
        self.message_viewer.code_check_radio.setChecked(True)
        self.message_viewer.set_check_file(filepath)
        # 只检测单个文件
        self.message_viewer.start_run([filepath])

    def check_all_files(self):
        get_app().MainFrame.activateBottomTab(MESSAGE_VIEW_NAME)
        self.message_viewer.code_check_radio.setChecked(True)
        self.message_viewer.start_run()

    def batch_fix_files(self):
        get_app().MainFrame.activateBottomTab(MESSAGE_VIEW_NAME)
        self.message_viewer.code_autofix_radio.setChecked(True)
        self.message_viewer.start_run()

    def format_code_file(self, doc, filepath, edit_view=None):
        if not self.is_enabled_for_extension(filepath):
            return
        ext = strutils.get_file_extension(filepath)
        format_tool = CodecheckToolManager.manager().find_format_tool_with_ext(ext)
        if isinstance(format_tool, BasePythonCheckTool) and format_tool.interpreter is None:
            interpreter = doc.GetModel().interpreter
            if interpreter is None:
                return
            format_tool.update(interpreter)
        fixer = format_tool.fixers[0]
        fixer.openfile = False
        fixer.set_doc(doc)
        try:
            fixer.fix_code_file(filepath, edit_view)
        except FixfileError as ex:
            utils.get_logger().error(str(ex))
            QMessageBox.critical(
                get_app().GetTopWindow(),
                _('Error'),
                str(ex)
            )

    def fix_single_file(self, filepath):
        if not self.is_enabled_for_extension(filepath):
            return
        get_app().MainFrame.activateBottomTab(MESSAGE_VIEW_NAME)
        self.message_viewer.code_autofix_radio.setChecked(True)
        self.message_viewer.set_check_file(filepath)
        # 只修复单个文件
        self.message_viewer.start_run([filepath])
        self.message_viewer.processor.fix_one_file = True

    def plugit(self, parent):
        """Hook the calculator into the menu and bind the event"""
        utils.get_logger().info("Installing codecheck plugin")
        get_app().MainFrame.SIG_SHOW_PROPERTY_DIALOG.connect(self.show_property_page)
        self.statubar = get_app().MainFrame.GetStatusBar()
        self.project_browser = get_app().MainFrame.projectview
        self._use_internal_interpreter = False
        # 此处加载插件翻译文件目录
        get_app().add_message_catalog('codecheck', __name__)
        preference.PreferenceManager.manager().add_options_panel_class(
            _("CodeCheck"),
            "General",
            _("General"),
            codecheck.CodecheckOptionPanel,
            **{'plugin': self}
        )

        preference.PreferenceManager.manager().add_options_panel_class(
            _("CodeCheck"),
            "CodeFix",
            _("CodeFix"),
            fixoption.CodeFixOptionPanel
        )

        preference.PreferenceManager.manager().add_options_panel_class(
            _("CodeCheck"),
            "MultiFix",
            _("MultiFix"),
            fixoption.MultiFixPanel
        )

        preference.PreferenceManager.manager().add_options_panel_class(
            _("CodeCheck"),
            "Pylint",
            _("Pylint"),
            pylintconfig.PylintOptionPanel
        )

        preference.PreferenceManager.manager().add_options_panel_class(
            _("CodeCheck"),
            "Flake8",
            _("Flake8"),
            flake8config.Flake8OptionPanel
        )

        WizardtemplateManager.get_manager().AddProjectTemplate(
            "Python/CodeCheck",
            "CodecheckProject",
            _("Codecheck Project"),
            [
                ("novalapp.python.project.page.BasePythonProjectNameLocationPage", {
                 'can_finish': False}),
                codecheck.CodecheckOptionPage,
                "novalapp.project.wizard.importfiles.ImportfilesPage"
            ]
        )
        message_icon_path = get_message_icon_path()
        view = get_app().MainFrame.AddView(
            MESSAGE_VIEW_NAME,
            messageviewer.MessageViewer,
            _("Messages"),
            SideBar.South,
            create=True,
            image_file=message_icon_path,
            visible_in_menu=True,
            **{'plugin': self}
        )
        self.message_viewer = view['instance']
        metric_image_path = get_metrics_image_path()
        view = get_app().MainFrame.AddView(
            METRICS_VIEW_NAME,
            metricsviewer.MetricsViewer,
            _("CodeMetrics"),
            SideBar.South,
            create=True,
            image_file=metric_image_path,
            visible_in_menu=True
        )
        self.metrics_viewer = view['instance']
        self._check_processor = CodecheckProcessor(
            self.message_viewer, self.statubar)
        self.message_viewer.set_processor(self._check_processor)
        get_app().MainFrame.projectview.register_sched_processor(self._check_processor)

        self._fix2to3_processor = Fix2to3Processor(
            self.message_viewer, self.statubar)
        get_app().MainFrame.projectview.register_sched_processor(self._fix2to3_processor)

        self._metrics_processor = CodeMetricsProcessor(
            self.metrics_viewer, self.statubar)
        get_app().MainFrame.projectview.register_sched_processor(self._metrics_processor)

        self._fix_processor = FixerProcessor(
            self.message_viewer, self.statubar)
        get_app().MainFrame.projectview.register_sched_processor(self._fix_processor)
        get_app().MainFrame.projectview.sigFileUpdated.connect(self.udpate_file_message)
        get_app().MainFrame.projectview.SIG_FILE_OPENED.connect(self.open_file_messages)
        get_app().MainFrame.projectview.SIG_CLOSE_PROJECT_DOC.connect(self.clear_messages)

        # 项目文件节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_FILE_MENU.connect(
            self.popup_file_menu)
        # 项目根节点弹出菜单信号
        self.project_browser.SIG_PROJECTVIEW_POPUP_ROOT_MENU.connect(
            self.popup_root_menu)
        self.project_browser.project_combox.currentIndexChanged.connect(self.select_project)
        get_app().MainFrame.projectview.SIG_EDIT_TEXT_POPUP_MENU.connect(self.popup_edit_text_menu)
        if self._use_internal_interpreter:
            self.load_internal_interpreter(parent)
        else:
            cur_proj_doc = get_app().get_current_project()
            if cur_proj_doc and isinstance(cur_proj_doc, PythonProjectDocument):
                interpreter = cur_proj_doc.GetModel().interpreter
                if interpreter is not None and isinstance(interpreter, PythonInterpreter):
                    try:
                        CodecheckToolManager.manager().register_python_tools(
                            interpreter,
                            self._use_internal_interpreter
                        )
                        return
                    except InterpretertoolNotExistError as ex:
                        utils.get_logger().error(
                            "register interpreter %s python tools error:%s",
                            interpreter.name,
                            str(ex)
                        )
            CodecheckToolManager.manager().init_tools()

    def load_internal_interpreter(self, parent):
        tools_data_path = get_tools_data_path()
        fixer_version = settings().get_default('fixer_version', BasePythonCheckTool.FIXVER_V1)
        if not fixer_version:
            fixer_version = BasePythonCheckTool.FIXVER_V1
        internal_interpreter_path = os.path.join(
            tools_data_path, fixer_version, r"python\pylint\venv\scripts\python.exe")
        if not os.path.exists(internal_interpreter_path):
            CodecheckToolManager.manager().init_tools(self._use_internal_interpreter)
            utils.get_logger().error("internal interpreter path %s is not exist",
                                     internal_interpreter_path)
            return None
        utils.get_logger().info("find internal interpreter path is %s",
                                internal_interpreter_path)
        internal_interpreter_name = "codecheck_python"
        interpreter = None
        try:
            admin = InterpreterAdmin(InterpreterManager.manager().interpreters)
            interpreter = admin.add_python_interpreter(
                internal_interpreter_path, internal_interpreter_name)
            interpreter.gen_id()
        except InterpreterError as error:
            utils.get_logger().warning("%s", str(error))
            interpreter = InterpreterManager.manager(
            ).GetInterpreterByName(internal_interpreter_name)
        except Exception as ex:
            utils.get_logger().error(
                "load interpreter %s information error:%s",
                internal_interpreter_name,
                ex
            )
            return interpreter
        try:
            CodecheckToolManager.manager().register_python_tools(
                interpreter, self._use_internal_interpreter)
        except RuntimeError as ex:
            utils.get_logger().error(str(ex))
            # 弹出告警对话框时关闭启动图片
            get_app().close_splash()
            QMessageBox.warning(parent, _('Warning'), str(ex))
        get_app().interpreters_combo.reload()
        return interpreter

    def clear_messages(self, doc):
        if doc == self.message_viewer.doc:
            self.message_viewer.clear_messages()
            self.metrics_viewer.clear_messages()

    def open_file_messages(self, doc, filepath, textview):
        if not utility.is_python_file(filepath):
            return
        editor = textview.GetCtrl()
        # 定义红色波浪线指示器（编号0）
        editor.indicatorDefine(QsciScintilla.SquiggleIndicator, 0)
        editor.setIndicatorForegroundColor(QColor("red"), 0)
        editor.setIndicatorDrawUnder(0, True)
        editor.SIG_MOUSE_HOVER.connect(self.on_mouse_hover)
        if not utils.profile_get_int(
                configkeys.DISPLAY_REALTIME_CHECK_RESULT_KEY, False):
            return
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            messages = self.get_tool_file_messages(check_tool, doc, filepath)
            for message in messages:
                line = message.line
                line -= 1
                column = message.column
                word = editor.wordAtLineIndex(line, column)
                utils.get_logger().debug(
                    "get line %d col %d word is:%s",
                    line,
                    column,
                    word
                )
                column -= 1
                word_length = len(editor._encodeString(word))
                position = editor.position_from_linecol(line, column)
                editor.call(QsciScintilla.SCI_INDICATORFILLRANGE, position, word_length)

    def on_mouse_hover(self, position, x, y, doc, codeview):
        del x
        del y
        if not utils.profile_get_int(configkeys.DISPLAY_REALTIME_CHECK_RESULT_KEY, False):
            return
        editor = codeview.GetCtrl()
        hover_line, hover_index = editor.lineIndexFromPosition(position)
        filepath = codeview.GetDocument().GetFilename()
        for check_tool in CodecheckToolManager.manager().CHECK_TOOLS:
            messages = self.get_tool_file_messages(check_tool, doc, filepath)
            for message in messages:
                line = message.line
                line -= 1
                column = message.column
                word = editor.wordAtLineIndex(line, column)
                word_length = len(editor._encodeString(word))
                if hover_line == line and column <= hover_index <= column + word_length:
                    utils.get_logger().debug(
                        "get line %d col %d warning message is:%s",
                        hover_line,
                        hover_index,
                        message.msg
                    )
                    editor.call(
                        QsciScintilla.SCI_CALLTIPSHOW,
                        position,
                        editor._encodeString(message.msg)
                    )
                    break

    def udpate_file_message(self, doc, filepath, textview):
        '''保存文件时更新信息视图的文件告警信息'''
        self.message_viewer.doc = doc
        if self.message_viewer.processor is None or not self.message_viewer.processor.use_codecheck(doc):
            utils.get_logger().warning('codecheck is disabled when update file %s', filepath)
            return
        if self.message_viewer.processor.running:
            utils.get_logger().warning(
                'processor %s is running when update file %s',
                self.message_viewer.processor.name,
                filepath
            )
            return
        self.message_viewer.SIG_CLEAR_FILE_MESSAGE_ITEMS.emit(filepath)
        if self.message_viewer.code_autofix_radio.isChecked():
            if utils.profile_get_int(configkeys.AUTOFIX_FILE_SAVE_KEY, False):
                # 只修复单个文件
                self.message_viewer.start_run([filepath], silent=True, updated=True)
                self.message_viewer.processor.fix_one_file = True
            else:
                self.message_viewer.set_current_check_processor()
                self.message_viewer.start_run_processor([filepath], silent=True, updated=True)
        else:
            # 只检测单个文件
            self.message_viewer.start_run([filepath], silent=True, updated=True)

    def show_property_page(self, property_dlg, property_item_type):
        if property_item_type == "root":
            codecheck_panel_name = _('CodeCheck')
            property_dlg.add_panel_item(
                codecheck_panel_name, codecheck.CodecheckPropertyPanel)
            panel = property_dlg.GetOptionPanel(codecheck_panel_name)
            panel.set_plugin(self)

    def GetMinVersion(self):
        """
        Override in subclasses to return the minimum version of novalide that
        the plugin is compatible with. By default it will return the current
        version of novalide.
        @return: version str
        """

    def InstallHook(self):
        """
        Override in subclasses to allow the plugin to be loaded
        dynamically.
        @return: None
        """

    def UninstallHook(self):
        pass

    def EnableHook(self):
        pass

    def DisableHook(self):
        pass

    def get_prog_lang(self):
        return prog_lang.LANGUAGE_NOTSET

    def required_packages(self):
        return ['flake8', 'pylint']

    def HookExit(self, query_exit):
        ''''''
        # 插件退出
        pylint_tool = CodecheckToolManager.manager().find_tool(PYLINT_TOOL_NAME)
        if pylint_tool is not None:
            settings()['fixer_version'] = pylint_tool.fixer_version
        else:
            utils.get_logger().error(
                "codecheck can't find %s tool,tools count is %d",
                PYLINT_TOOL_NAME,
                len(CodecheckToolManager.manager().CHECK_TOOLS)
            )
        return True
