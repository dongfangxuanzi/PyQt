import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR1701Fixer(PylintFixer):
    '''
    规则说明:2个isinstance calls(isinstance(x) or isinstance(y))
    可以合并为1个isinstance call (isinstance(x,y))
    '''

    def __init__(self):
        super().__init__('R1701', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r"Consider merging these isinstance calls to (.*) \(consider-merging-isinstance\)",
            msg.msg
        )
        if isinstance(node, nodes.Name) and node.name == "isinstance" and (
            isinstance(node.parent.parent, nodes.BoolOp) and node.parent.parent.op == 'or'
        ):
            newtext = res.groups()[0]
            self.fix_node_text(node.parent.parent, newtext)
            return True
        return False
