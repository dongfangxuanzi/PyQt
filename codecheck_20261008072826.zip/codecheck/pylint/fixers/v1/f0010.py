from ....pylint_fix import PylintFixer


class PylintF0010Fixer(PylintFixer):
    '''
    规则说明:编码声明错误
    '''

    def __init__(self):
        super().__init__('F0010', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        self.insert_declare_encoding()
        return True
