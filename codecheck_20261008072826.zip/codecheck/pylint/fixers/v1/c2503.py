from ....pylint_fix import PylintFixer


class PylintC2503Fixer(PylintFixer):
    '''
    规则说明:编码不是utf8编码
    '''

    def __init__(self):
        super().__init__('C2503', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        self.insert_declare_encoding()
        return True
