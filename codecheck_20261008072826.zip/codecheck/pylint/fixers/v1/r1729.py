import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR1729Fixer(PylintFixer):
    '''
    规则说明:any表达式参数用生成式代替列表表达式
    '''

    def __init__(self):
        super().__init__('R1729', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(r"Use a generator instead '(.*)' \(use-a-generator\)", msg.msg)
        if not res:
            return False
        pnode = node.parent
        if isinstance(node, nodes.Name) and node.name == "any" and (
            isinstance(pnode, nodes.Call) and isinstance(pnode.args[0], nodes.ListComp)
        ):
            repstr = res.groups()[0]
            self.fix_node_text(pnode, repstr)
            return True
        return False


class PylintR1728Fixer(PylintFixer):
    '''
    规则说明:sum表达式参数用生成式代替列表表达式
    '''

    def __init__(self):
        super().__init__('R1728', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r"Consider using a generator instead '(.*)' \(consider-using-generator\)",
            msg.msg
        )
        pnode = node.parent
        if isinstance(node, nodes.Name) and node.name == "sum" and (
            isinstance(pnode, nodes.Call) and isinstance(pnode.args[0], nodes.ListComp)
        ):
            repstr = res.groups()[0]
            self.fix_node_text(pnode, repstr)
            return True
        return False
