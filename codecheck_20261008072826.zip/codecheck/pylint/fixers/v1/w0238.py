import re
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintW0238Fixer(PylintFixer):
    '''
    规则说明: 私有方法/属性未被使用
    '''

    def __init__(self):
        super().__init__('W0238', self.FixKind.SINGLEFIX)

    def fix_message(self, msg):
        regstr = r"Unused private member `(.*)` \(unused-private-member\)"
        res = re.search(regstr, msg.msg)
        node = self.find_msg_node(msg)
        result = res.groups()[0]
        results = result.split('.')
        str_parts = re.split('[(,)]', results[1])
        if isinstance(node, nodes.Name) and (
            isinstance(node.parent, nodes.FunctionDef) and str_parts[0] == node.name
        ):
            return self.delete_node(node.parent)
        if isinstance(node, nodes.Assign):
            target = node.targets[0]
            if isinstance(target, nodes.AssignAttr) and str_parts[0] == target.attrname:
                return self.delete_node(node)
        return False
