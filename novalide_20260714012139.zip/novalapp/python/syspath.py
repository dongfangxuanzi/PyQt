import sys
import os
import logging
log = logging.getLogger(__name__)


def append_to_syspath(path):
    '''
    添加自定义库路径到syspath,
    为了防止和解释器系统库里面的包混淆,必须插入在系统路径最后,
    可以防止扰乱正常加载的系统路径顺序
    '''
    if path not in sys.path:
        sys.path.append(path)


def remove_syspath(path):
    if path in sys.path:
        sys.path.remove(path)
        log.info('remove sys path %s success', path)


def insert_thirdparty_to_syspath():
    thisfile = os.path.abspath(__file__)
    root = os.path.dirname(thisfile)
    # 添加第三方解析包astroid的搜索路径,以便能找到包
    append_to_syspath(os.path.join(root, "thirdparty"))
