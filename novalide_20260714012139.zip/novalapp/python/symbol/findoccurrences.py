import re
from enum import IntEnum
from ... import get_app
from .symbols import Symbol
from .parameter import OccurrencesParameter
from ...util import utils
from ... import globalkeys
from .searchsupport import ItemToSearchIn
from ..parser import node_scope


class OccurRange(IntEnum):
    Module = 1
    Class = 2
    Function = 3


class FindOccurrences:
    """description of class"""

    def __init__(self, name, line=None):
        self.__name = name
        self.search_results = []
        self.current_docview = get_app().MainFrame.GetNotebook().get_current_view()
        self._occur_line = line

    def search(self):
        item = ItemToSearchIn(
            self.current_docview.GetDocument().GetFilename(),
            self.current_docview
        )
        regexp_text = re.escape(self.__name)
        regexp_text = "\\b%s\\b" % regexp_text
        flags = re.UNICODE
        if not utils.profile_get_int(
            globalkeys.MATCH_CASE_OCCURRENCES_KEY,
            True
        ):
            flags |= re.IGNORECASE
        search_regexp = re.compile(regexp_text, flags)
        search_scope = None
        if self._occur_line is not None:
            search_occur_range = utils.profile_get_int(
                globalkeys.FIND_OCCURRENCES_RANGE_KEY,
                OccurRange.Module.value
            )
            if search_occur_range != OccurRange.Module.value:
                scope_finder = node_scope.ScopeFinder(
                    self.current_docview.ModuleAnalyzer.Module
                )
                if search_occur_range == OccurRange.Class.value:
                    search_scope = scope_finder.find_classdef_scope(self._occur_line)
                elif search_occur_range == OccurRange.Function.value:
                    search_scope = scope_finder.find_funcdef_scope(self._occur_line)
        item.search(
            search_regexp,
            Symbol.ALL.value,
            search_scope
        )
        found = len(item.matches)
        if found > 0:
            self.search_results.append(item)

    def get_parameter(self):
        return OccurrencesParameter(
            self.__name,
            self.current_docview.GetDocument().GetFilename(),
            self.current_docview.GetCtrl().get_current_line(),
            self.current_docview.GetCtrl().get_current_column()
        )
