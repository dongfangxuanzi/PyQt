# -*- coding: utf-8 -*-
import os
import logging
import sys
import psutil
logger = logging.getLogger(__name__)


class SingleInstanceChecker:
    """只允许程序单实例允许的检测器"""

    def __init__(self, appname, lock_path):
        if not os.path.exists(lock_path):
            os.makedirs(lock_path)
        self.lock = os.path.join(lock_path, "lock")
        self.pid = None
        self.__appname = appname
        self.create()

    @staticmethod
    def get_exe_name(exe):
        if sys.platform.startswith("win"):
            return exe + ".exe"
        return exe

    def create(self):
        if not os.path.exists(self.lock):
            self.set_pid()
        else:
            self.getpid()

    def is_another_running(self):
        if self.pid is None:
            return False
        running = True
        try:
            p = psutil.Process(int(self.pid))
            # 有可能进程号被别的程序占用了,故还需要判断进程名是否是novalide或python进程
            if p.name().lower() not in [
                self.get_exe_name(self.__appname.lower()),
                self.get_exe_name("python")
            ]:
                running = False
                logger.info("app process id:%s name:%s is not a ide process", self.pid, p.name())
            # 如果是python进程还需要判断命令行是否包含novalide关键字
            if p.name().lower() == self.get_exe_name("python"):
                for cmd in p.cmdline():
                    if cmd.lower().find(self.__appname.lower()) != -1:
                        if cmd.lower() == "-debug":
                            running = False
                            logger.info(
                                "app python process id:%s name:%s is in ide debug mode",
                                self.pid,
                                p.name()
                            )
                    break
                else:
                    running = False
                    logger.info(
                        "app python process id:%s name:%s is not a ide process",
                        self.pid,
                        p.name()
                    )
        except:
            running = False
            logger.info("app process id %s is not run again", self.pid)
        finally:
            if not running:
                self.set_pid()
        return running

    def getpid(self):
        with open(self.lock) as f:
            self.pid = f.read()

    def set_pid(self):
        with open(self.lock, "w") as f:
            f.write(str(os.getpid()))
