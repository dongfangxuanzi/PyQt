import re
from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from novalapp.python.parser.define import CLASS_METHOD_NAME, STATIC_METHOD_NAME
from ...multifixer import MultiOptionFixer
from ...pylint_fix import PylintFixer


class PylintC0103Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:变量和属性命名不符合规范
    '''

    def __init__(self):
        super().__init__('C0103', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Conform to snake_case name',
            descr='Choose one snake_case style',
            init_options=['slugify-lowercase', 'lowercase']
        )
        self.standardize_module_name_style = False
        self.standardize_local_variable_name_style = False
        self.standardize_class_attr_name_style = False
        self.standardize_function_arg_name_style = False

    @staticmethod
    def is_private_name(name):
        if name.startswith("__"):
            return True
        return False

    @staticmethod
    def is_name_used_in_scope(class_scope, method_name):
        function_scope = ScopeFinder.get_class_method_node(
            class_scope,
            method_name
        )
        return function_scope is not None

    def replace_function_name_in_scope(self, scope, funcname, new_funcname):
        childs = list(self.iter_scope_childs(scope))
        for child in childs:
            if isinstance(child, nodes.FunctionDef) and child.name == funcname:
                for func_child in self.iter_scope_childs(child):
                    if isinstance(func_child, nodes.Name) and func_child.name == funcname:
                        self.fix_node_text(func_child, new_funcname)
                        break
        self.replace_variable_name_in_scope(scope, funcname, new_funcname)

    def fix_message(self, doc, msg):
        res = re.search(
            r'Module name "(?P<modulename>.*)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res:
            modulename = res.groupdict().get('modulename')
            default_modulename = self.get_valid_identifier_name(modulename)
            if default_modulename is None:
                return False
            # 模块名支持自动修复
            if self.is_autofix_msg:
                if self.standardize_module_name_style:
                    ok = True
                    newname = default_modulename
                else:
                    return False
            else:
                ok, newname = self.ask_input_string(
                    'Rename module name',
                    'Input new module name',
                    initialvalue=default_modulename
                )
            if ok and newname != modulename:
                return self.replace_module_name(doc, msg.filepath, newname)
        if self.replace_constant_name_in_module(msg):
            return True
        node = self.find_msg_node(None, msg, use_column=True)
        if not node:
            return False
        funcscope = ScopeFinder.get_function_scope(node)
        # 目前仅支持函数范围内的变量名更改替换
        if funcscope is None:
            return False
        res1 = re.search(
            r'Variable name "(?P<varname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res1:
            varname = res1.groupdict().get('varname')
            default_varname = self.get_valid_identifier_name(varname)
            if default_varname is None:
                return False
            if not self.is_autofix_msg:
                ok, newname = self.ask_input_string(
                    'Rename variable name',
                    'Input new variable name',
                    initialvalue=default_varname
                )
                if not ok or newname == varname:
                    return False
            else:
                if self.standardize_local_variable_name_style:
                    newname = default_varname
                else:
                    return False
            self.replace_variable_name_in_scope(funcscope, varname, newname)
            return True
        res2 = re.search(
            r'Attribute name "(?P<attrname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res2:
            if not isinstance(funcscope.parent, nodes.ClassDef):
                return False
            attrname = res2.groupdict().get('attrname')
            default_attrname = self.get_valid_identifier_name(attrname)
            if default_attrname is None or self.is_name_used_in_scope(funcscope.parent, default_attrname):
                return False
            if self.is_autofix_msg:
                if self.standardize_class_attr_name_style or self.is_private_name(attrname):
                    newname = default_attrname
                else:
                    return False
            else:
                ok, newname = self.ask_input_string(
                    'Rename attribute name',
                    'Input new attribute name',
                    initialvalue=default_attrname
                )
                if not ok or newname == attrname:
                    return False
            self.replace_attribute_name_in_scope(funcscope.parent, attrname, newname)
            return True
        res3 = re.search(
            r'Argument name "(?P<argname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res3:
            argname = res3.groupdict().get('argname')
            default_argname = self.get_valid_identifier_name(argname)
            if default_argname is None:
                return False
            if self.is_autofix_msg:
                if self.standardize_function_arg_name_style:
                    newname = default_argname
                else:
                    return False
            else:
                ok, newname = self.ask_input_string(
                    'Rename argument name',
                    'Input new argument name',
                    initialvalue=default_argname
                )
                if not ok or newname == argname:
                    return False
            self.replace_variable_name_in_scope(funcscope, argname, newname)
            return True
        res4 = re.search(
            r'(Method|Function) name "(?P<methodname>\w+)" doesn\'t conform to snake_case naming style \(invalid-name\)',
            msg.msg
        )
        if res4:
            methodname = res4.groupdict().get('methodname')
            default_methodname = self.get_valid_identifier_name(methodname)
            if default_methodname is None or self.is_name_used_in_scope(funcscope.parent, default_methodname):
                return False
            is_class_method = funcscope.type in [CLASS_METHOD_NAME, STATIC_METHOD_NAME]
            if self.is_autofix_msg:
                if self.is_private_name(methodname):
                    newname = default_methodname
                else:
                    return False
            else:
                ok, newname = self.ask_input_string(
                    'Rename method name',
                    'Input new method name',
                    initialvalue=default_methodname
                )
                if not ok or newname == methodname:
                    return False
            if isinstance(funcscope.parent, nodes.Module):
                self.replace_function_name_in_scope(
                    funcscope.parent,
                    methodname,
                    newname
                )
            else:
                self.replace_method_name_in_scope(
                    funcscope.parent,
                    methodname,
                    newname,
                    is_class_method,
                    funcscope.parent.name
                )
            return True
        return False

    def replace_constant_name_in_module(self, msg):
        res5 = re.search(
            r'Constant name "(?P<constname>\w+)" doesn\'t conform to UPPER_CASE naming style \(invalid-name\)',
            msg.msg
        )
        if res5:
            constname = res5.groupdict().get('constname')
            default_constname = self.get_valid_identifier_name(constname, upper=True)
            if default_constname is None or self.is_autofix_msg:
                return False
            ok, newname = self.ask_input_string(
                'Rename Constant name',
                'Input new Constant name',
                initialvalue=default_constname
            )
            if not ok or newname == constname:
                return False
            self.replace_variable_name_in_scope(
                self.get_module(),
                constname,
                newname
            )
            return True
        return False
