from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintC0121Fixer(PylintFixer):
    '''
    规则说明: 使用is和None比较,而不是使用==
    '''

    def __init__(self):
        # 支持自动修复
        super().__init__('C0121', True)

    def fix_compare_node(self, node):
        '''
        修复比较语句==None为is None
        :param node:
        :type node: astroid.nodes
        :return: 是否修复成功
        :rtype: bool
        '''
        ops = node.ops
        if ops and ops[0][0] in ['==', '!=']:
            if isinstance(ops[0][1], nodes.Const) and ops[0][1].value is None:
                if ops[0][0] == "==":
                    fixtext = f"{node.left.as_string()} is None"
                else:
                    fixtext = f"{node.left.as_string()} is not None"
                self.fix_node_text(node, fixtext)
                return True
            if isinstance(node.left, nodes.Const) and node.left.value is None:
                if ops[0][0] == "==":
                    fixtext = f"{ops[0][1].as_string()} is None"
                else:
                    fixtext = f"{ops[0][1].as_string()} is not None"
                self.fix_node_text(node, fixtext)
                return True
        return False

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg, use_column=True)
        if not node:
            return False
        pnode = node.parent
        if not pnode:
            return False
        if isinstance(pnode, nodes.Compare):
            return self.fix_compare_node(pnode)
        if isinstance(pnode.parent, nodes.Compare):
            return self.fix_compare_node(pnode.parent)
        return False
