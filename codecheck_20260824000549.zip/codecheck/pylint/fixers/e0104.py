from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import FixNode, get_node_col_offset_blanks, DEFAULT_TAB_BLANKS
from ...pylint_fix import PylintFixer


class PylintE0104Fixer(PylintFixer):
    '''
    规则说明: return语句不在函数/方法范围内
    '''

    def __init__(self):
        super().__init__('E0104', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        prev_node = node.previous_sibling()
        if isinstance(node, nodes.Return) and isinstance(prev_node, nodes.FunctionDef):
            return_str = node.as_string()
            offset_blanks = get_node_col_offset_blanks(prev_node)
            if prev_node.col_offset == 0:
                offset_blanks += DEFAULT_TAB_BLANKS
            fix_return_str = offset_blanks + return_str
            FixNode(node, textview).replace_node_with_text(fix_return_str)
            return True
        return False
