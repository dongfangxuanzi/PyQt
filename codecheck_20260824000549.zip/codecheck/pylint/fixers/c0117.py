'''
Name:        c0117.py
Purpose:
Author:      wukan
Created:     2026-05-16
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from novalapp.python.parser import node_utils
from ...pylint_fix import PylintFixer


class PylintC0117Fixer(PylintFixer):
    '''
    规则说明:
    1.2个not表达式(not not x),可以替换成(x/bool(x))
    2.not x in y 可以替换成x not in y
    '''

    def __init__(self):
        super().__init__('C0117', True)

    def fix_message(self, doc, msg):
        msgnode = self.find_msg_node(None, msg, use_column=True)
        if not msgnode:
            return False
        res = re.search(
            r'Consider changing "(.*)" to "(.*)" \(unnecessary-negation\)',
            msg.msg
        )
        nodestr, fixstr = res.groups()
        if nodestr == msgnode.as_string():
            if isinstance(msgnode, nodes.UnaryOp) and msgnode.op == "not":
                if isinstance(msgnode.operand, nodes.UnaryOp) and msgnode.operand.op == "not":
                    infer_value = node_utils.safe_infer(msgnode.operand.operand)
                    if not node_utils.is_const_type(infer_value, bool):
                        fixstr = f"bool({fixstr})"
                self.fix_node_text(msgnode, fixstr)
                return True
        return False
