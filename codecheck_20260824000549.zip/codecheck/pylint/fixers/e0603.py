# -*- coding: utf-8 -*-
'''
Name:        e0603.py
Purpose:     E0603:修复模块__all__导出未定义的变量
Author:      wukan
Created:     2023-11-16
Copyright:   (c) wukan 2023
Licence:     <your licence>
'''
import re
from novalapp.python.parser import node_utils
from astroid import nodes
from ...basefix import fix_code_file_msg
from ...codeutils import get_node_range
from ...pylint_fix import PylintFixer


class PylintE0603Fixer(PylintFixer):
    '''
    规则说明: 模块__all__导出未定义的变量
    '''

    def __init__(self):
        super().__init__('E0603', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        res = re.search(
            r"Undefined variable name '(.*)' in __all__ \(undefined-all-variable\)",
            msg.msg
        )
        undefined_name = res.groups()[0]
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.Assign) and isinstance(node.value, nodes.List):
            targets = node.targets
            if isinstance(targets[0], nodes.AssignName) and targets[0].name == "__all__":
                for i, elt in enumerate(node.value.elts):
                    if node_utils.is_const_type(elt, str) and elt.value == undefined_name:
                        del node.value.elts[i]
                        break
                else:
                    return False
                if not node.value.elts:
                    node_range = get_node_range(node)
                    node_range.replace_with_text(textview, '')
                else:
                    node_range = get_node_range(node.value)
                    node_range.replace_with_text(textview, node.value.as_string())
                return True
        return False
