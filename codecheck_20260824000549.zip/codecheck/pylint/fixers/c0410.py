import re
from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintC0410Fixer(PylintFixer):
    '''
    规则说明: 一行导入多个模块
    '''

    def __init__(self):
        super().__init__('C0410', True)

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg)
        if isinstance(node, nodes.Import):
            res = re.search(
                r'Multiple imports on one line \((.*)\) \(multiple-imports\)', msg.msg)
            if not res:
                return False
            matched_names = [name.strip()
                             for name in res.groups()[0].strip().split(',')]
            names = [name[0] for name in node.names]
            if len(names) >= 2 and matched_names == names:
                imports = []
                for name in names:
                    imports.append("import %s" % name)
                self.fix_node_text(node, '\n'.join(imports))
                return True
        return False
