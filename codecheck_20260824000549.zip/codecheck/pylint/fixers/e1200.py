'''
Name:        e1200.py
Purpose:     修复%后面的格式化字符错误
Author:      wukan
Created:     2026-08-15
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from novalapp.python.parser import node_utils
from astroid import nodes
from ...codeutils import get_node_range
from ...multifixer import MultiOptionFixer
from ...basefix import fix_code_file_msg
from ...pylint_fix import PylintFixer


class PylintE1200Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:%后面的格式化字符错误
    '''
    LOGGING_FORMAT_FLAGS = "diouxXeEfFgGcrs%a"

    def __init__(self):
        super().__init__('E1200', False)
        MultiOptionFixer.__init__(
            self,
            title='Fix logging unsupported format',
            descr="Please choose one supported format",
            init_options=list(self.LOGGING_FORMAT_FLAGS)
        )

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        res = re.search(
            r"Unsupported logging format character '(.*)' .* at index (\d+) ",
            msg.msg
        )
        fchar, index = res.groups()
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call):
            if node.value.args and node_utils.is_const_type(node.value.args[0], str):
                first_arg = node.value.args[0]
                index = int(index)
                if fchar != first_arg.value[index]:
                    return False
                self.get_selection(textctrl)
                if self.selection == self.INVAID_SEL_INDEX:
                    return False
                chars = list(first_arg.value)
                chars[index] = self._options[self.selection]
                const_arg_str = ''
                is_r_quote, str_quote = self.get_line_str_r_quote(first_arg)
                # 字符串被r包裹
                if is_r_quote:
                    const_arg_str += "r"
                const_arg_str += (str_quote + ''.join(chars) + str_quote)
                get_node_range(first_arg).replace_with_text(textview, const_arg_str)
                return True
        return False
