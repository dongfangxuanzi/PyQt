import sys
import argparse
import logging
import os
import fnmatch
from configparser import ConfigParser as SafeConfigParser, Error
import pylint
from .constants import (
    MAX_FIX_TRY_TIMES,
    USER_EXIT_PROG,
    DEFAULT_MAX_MEMBERS_COUNT,
    DEFAULT_MAX_LINE_LENGTH
)
from .exceptions import InvalidOptionIndexError
from .logger import init_logging, available_log_levels
from .utils import compute_run_time
from .autofix import fix_file, supported_fixes
from .codeutils import FixChoice
from .basefix import BaseFixer
from .fileutils import readlines_from_file, match_file
from .strutils import docstring_summary, _split_comma_separated
log = logging.getLogger(__name__)

__version__ = '1.1.1'


EXIT_CODE_OK = 0
EXIT_CODE_ERROR = 1
EXIT_CODE_EXISTS_DIFF = 2
EXIT_CODE_ARGPARSE_ERROR = 99


def _get_package_version():
    packages = ["pylint: {}".format(pylint.__version__)]
    return ", ".join(packages)


if sys.platform == 'win32':  # pragma: no cover
    DEFAULT_CONFIG = os.path.expanduser(r'~\.pylintrc')
else:
    DEFAULT_CONFIG = os.path.join(os.getenv('PYLINTRC') or
                                  os.path.expanduser('~/.config'),
                                  'pylintrc')
# fallback, use .pep8
if not os.path.exists(DEFAULT_CONFIG):  # pragma: no cover
    if sys.platform == 'win32':
        DEFAULT_CONFIG = os.path.expanduser(r'~\pylint.conf')
    else:
        DEFAULT_CONFIG = os.path.join(os.path.expanduser('~/.config'), 'pylint.conf')


def create_parser():
    """Return command-line parser."""
    parser = argparse.ArgumentParser(description=docstring_summary(__doc__),
                                     prog='pylinter')
    parser.add_argument('-v', '--version', action='version',
                        version='%(prog)s {} ({})'.format(
                            __version__, _get_package_version()))
    parser.add_argument(
        '-l',
        '--log-level',
        dest='log_level',
        type=str,
        default=logging.getLevelName(logging.INFO),
        choices=available_log_levels(),
        help='log level choices'
    )
    parser.add_argument('-d', '--debug', action='store_true',
                        help='prog run with debug log or not')
    parser.add_argument('-i', '--in-place', action='store_true',
                        help='make changes to files in place')
    parser.add_argument('--global-config', metavar='filename',
                        default=DEFAULT_CONFIG,
                        help='path to a global pep8 config file; if this file '
                             'does not exist then this is ignored '
                             '(default: {})'.format(DEFAULT_CONFIG))
    parser.add_argument('--ignore-local-config', action='store_true',
                        help="don't look for and apply local config files; "
                             'if not passed, defaults are updated with any '
                             "config files in the project's root directory")
    parser.add_argument('-r', '--recursive', action='store_true',
                        help='run recursively over directories; '
                             'must be used with --in-place')
    parser.add_argument('-j', '--jobs', type=int, metavar='n', default=1,
                        help='number of parallel jobs; '
                             'match CPU count if value is less than 1')
    parser.add_argument('-e', '--epochs', metavar='n',
                        default=MAX_FIX_TRY_TIMES, type=int,
                        help='maximum number of fix try epochs (default: 10)')
    parser.add_argument(
        '--repeat',
        action='store_true',
        help='repeat fix warnings until fixable warnings reduce to zero'
    )

    parser.add_argument('--exclude', metavar='globs',
                        help='exclude file/directory names that match these '
                             'comma-separated globs')
    parser.add_argument('--list-fixes', action='store_true',
                        help='list codes for fixes; '
                        'used by --ignore and --select')
    parser.add_argument('--ignore', metavar='errors', default='',
                        help='do not fix these errors/warnings')
    parser.add_argument('--select', metavar='errors', default='',
                        help='fix only these errors/warnings (e.g. E4,W)')
    parser.add_argument(
        '--max-members-count',
        metavar='n',
        default=DEFAULT_MAX_MEMBERS_COUNT,
        type=int,
        help='set maximum import members count (default: %(default)s)'
    )
    parser.add_argument(
        '--max-line-length',
        metavar='n',
        default=DEFAULT_MAX_LINE_LENGTH,
        type=int,
        help='set maximum allowed line length (default: %(default)s)'
    )

    parser.add_argument(
        '-f',
        '--fix',
        type=str,
        dest='fix_choice',
        help='choices to fix',
        default=FixChoice.FIX_AUTOFIX.value,
        choices=[
            FixChoice.FIX_AUTOFIX.value,
            FixChoice.FIX_ALL.value,
            FixChoice.FIX_SEMI_AUTOFIX.value
        ]
    )
    parser.add_argument(
        '--standardize-module-name',
        action='store_true',
        default=False,
        help='standardize module name to snake_case style'
    )
    parser.add_argument(
        '--standardize-local-variable-name',
        action='store_true',
        default=False,
        help='standardize local variable name to snake_case style'
    )

    parser.add_argument(
        '--standardize-function-arg',
        action='store_true',
        default=False,
        help='standardize function arg name to snake_case style'
    )

    parser.add_argument(
        '--standardize-class-attr',
        action='store_true',
        default=False,
        help='standardize class attribute name to snake_case style'
    )
    parser.add_argument(
        '--remove-print-statement',
        action='store_true',
        default=False,
        help='remove print statement'
    )
    parser.add_argument(
        '--format-doc-str',
        action='store_true',
        default=False,
        help='format method doc string'
    )
    parser.add_argument(
        '--convert-tabs',
        action='store_true',
        default=False,
        help='convert tabs to blanks'
    )
    parser.add_argument(
        '--delete-commented-out-codes',
        action='store_true',
        default=False,
        help='delete all commented out codes'
    )
    parser.add_argument(
        '--delete-todo-comments',
        action='store_true',
        default=False,
        help='delete all fixme/todo task comments'
    )
    parser.add_argument(
        '--delete-assert-statements',
        action='store_true',
        default=False,
        help='delete all assert statements'
    )
    parser.add_argument(
        '--cut-bom-head',
        action='store_true',
        default=False,
        help='cut utf-8 bom 3 bytes at head of file when save file'
    )
    parser.add_argument(
        '--use-raw-encoding',
        action='store_true',
        default=False,
        help='save code file with file raw encoding,otherwise use default utf-8 encoding'
    )
    parser.add_argument('--exit-code', action='store_true',
                        help='change to behavior of exit code.'
                             ' default behavior of return value, 0 is no '
                             'differences, 1 is error exit. return 2 when'
                             ' add this option. 2 is exists differences.')
    parser.add_argument('files', nargs='*',
                        help="files to format or '-' for standard in")

    return parser


def _parser_error_with_code(
    parser: argparse.ArgumentParser, code: int, msg: str,
) -> None:
    """wrap parser.error with exit code"""
    parser.print_usage(sys.stderr)
    parser.exit(code, f"{msg}\n")


def decode_filename(filename):
    """Return Unicode filename."""
    if isinstance(filename, str):
        return filename

    return filename.decode(sys.getfilesystemencoding())


def find_files(filenames, recursive, exclude):
    """Yield filenames."""
    while filenames:
        name = filenames.pop(0)
        if recursive and os.path.isdir(name):
            for root, directories, children in os.walk(name):
                filenames += [os.path.join(root, f) for f in children
                              if match_file(os.path.join(root, f),
                                            exclude)]
                directories[:] = [d for d in directories
                                  if match_file(os.path.join(root, d),
                                                exclude)]
        else:
            is_exclude_match = False
            for pattern in exclude:
                if fnmatch.fnmatch(name, pattern):
                    is_exclude_match = True
                    break
            if not is_exclude_match:
                yield name


def _fix_file(parameters):
    """Helper function for optionally running fix_file() in parallel."""
    try:
        source = None
        if parameters[1].repeat:
            for epoch in range(parameters[1].epochs):
                fixed_source, fixed_count = fix_file(source=source, *parameters)
                if not parameters[1].in_place:
                    source = fixed_source
                if not fixed_count:
                    break
                log.info('fix total %d warnings in %d try times', fixed_count, epoch + 1)
        else:
            fixed_source, fixed_count = fix_file(*parameters)
            log.info('fix %d warnings.', fixed_count)
        return fixed_source, fixed_count
    except IOError as error:
        log.error(str(error))
        raise error


@compute_run_time
def fix_multiple_files(filenames, options, output=None):
    """
    Fix list of files.
    Optionally fix files recursively.
    """
    results = []
    total_fixed_count = 0
    filenames = find_files(filenames, options.recursive, options.exclude)
    if options.jobs > 1:
        import multiprocessing
        pool = multiprocessing.Pool(options.jobs)
        rets = []
        for name in filenames:
            ret = pool.apply_async(_fix_file, ((name, options),))
            rets.append(ret)
        pool.close()
        pool.join()
        results.extend([x.get()[0] for x in rets if x is not None])
        total_fixed_count = sum(x.get()[1] for x in rets if x is not None)
    else:
        for name in filenames:
            ret, fixed_count = _fix_file((name, options, output))
            total_fixed_count += fixed_count
            if ret is None:
                continue
            if options.in_place:
                results.append(ret)
            else:
                original_source = readlines_from_file(name)
                if "".join(original_source).splitlines() != ret.splitlines():
                    results.append(ret)
    return results, total_fixed_count


def read_config(args):
    """Read user configuration."""
    config = SafeConfigParser()
    try:
        if os.path.exists(args.global_config):
            log.debug('read config path: %s', args.global_config)
            config.read(args.global_config)
            max_line_length_key = 'max-line-length'
            for section in config.sections():
                if config.has_option(section, max_line_length_key):
                    args.max_line_length = int(config.get(section, max_line_length_key))
                    break
    except Error as ex:
        # Ignore for now.
        log.error("read config path: %s error:%s", args.global_config, str(ex))


def parse_args(arguments, apply_config=False):
    """Parse command-line options."""
    parser = create_parser()
    args = parser.parse_args(arguments)

    BaseFixer.FIX_MSG_OPTION = FixChoice(args.fix_choice)

    if not args.files and not args.list_fixes:
        _parser_error_with_code(
            parser, EXIT_CODE_ARGPARSE_ERROR, 'incorrect number of arguments',
        )

    args.files = [decode_filename(name) for name in args.files]

    if apply_config:
        read_config(args)
        args = parser.parse_args(arguments)
        args.files = [decode_filename(name) for name in args.files]

    if len(args.files) > 1 and not args.in_place:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            'pylinter only takes one filename as argument '
            'unless the "--in-place" args are used',
        )

    if args.recursive and not args.in_place:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            '--recursive must be used with --in-place',
        )

    if args.max_members_count <= 0:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            '--max-members-count must be greater than 0',
        )
    if args.debug:
        init_logging(args.log_level.upper())
    else:
        logging.lastResort = None

    if args.select:
        args.select = _split_comma_separated(args.select)

    if args.ignore:
        args.ignore = _split_comma_separated(args.ignore)

    if args.exclude:
        args.exclude = _split_comma_separated(args.exclude)
    else:
        args.exclude = {}

    if args.jobs < 1:
        # Do not import multiprocessing globally in case it is not supported
        # on the platform.
        import multiprocessing
        args.jobs = multiprocessing.cpu_count()

    if args.jobs > 1 and not args.in_place:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            'parallel jobs requires --in-place',
        )
    if args.jobs > 1 and BaseFixer.FIX_MSG_OPTION != FixChoice.FIX_AUTOFIX:
        _parser_error_with_code(
            parser,
            EXIT_CODE_ARGPARSE_ERROR,
            'parallel jobs disable --fix all',
        )

    return args


def main(argv=None, apply_config=False):
    """Command-line entry."""
    if argv is None:
        argv = sys.argv
    try:
        args = parse_args(argv[1:], apply_config=apply_config)
        if args.list_fixes:
            for code, fixkind, description in sorted(supported_fixes(args)):
                print('%s - %-11s - %s' % (code, fixkind, description))
            return EXIT_CODE_OK
        if args.in_place:
            args.files = list(set(args.files))
        else:
            assert len(args.files) == 1
            assert not args.recursive
        try:
            results, fixed_count = fix_multiple_files(args.files, args, sys.stdout)
        except InvalidOptionIndexError as ex:
            if str(ex) == USER_EXIT_PROG:
                return EXIT_CODE_ERROR
        log.info('total fix %d warnings.', fixed_count)
        # with in-place option
        ret = any(ret is not None for ret in results)
        if args.exit_code and ret:
            return EXIT_CODE_EXISTS_DIFF
    except IOError:
        return EXIT_CODE_ERROR
    except KeyboardInterrupt:
        return EXIT_CODE_ERROR  # pragma: no cover
    return EXIT_CODE_OK
