LAST_OPEN_DOCUMENT_KEY = "lastOpenDocument"
SHELL_TTY_MODE_KEY = "shell_tty_mode"
BOM_HEAD_ACTION_KEY = 'bom_head_action_key'
