import re
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import get_node_range, FixRange


class PylintC0325Fixer(PylintFixer):
    '''
    规则说明: assert/if/赋值/表达式无需用括号包裹起来
    '''

    def __init__(self):
        super().__init__('C0325', True)

    @staticmethod
    def cannot_fix(node):
        symbols = ['&', '|']
        nodestr = node.as_string()
        for char in symbols:
            if char in nodestr:
                return True
        return False

    @staticmethod
    def get_msg_keyword(msg):
        res = re.search(r"Unnecessary parens after '(\w+)' keyword", msg.msg)
        if not res:
            return None
        keyword_name = res.groups()[0]
        return keyword_name

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        textctrl = kwargs.get('textctrl')
        linestr = self.get_msg_line_text(msg, textctrl)
        result = re.search(r'\(.*\)', linestr)
        if not result:
            return False
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        keyword_name = self.get_msg_keyword(msg)
        if isinstance(node, nodes.Assert) or (
            isinstance(node, nodes.UnaryOp) and keyword_name == "not"
        ):
            if self.cannot_fix(node):
                return False
            fix_range = get_node_range(node)
            nodestr = node.as_string()
            fix_range.replace_with_text(textview, nodestr)
            return True
        if isinstance(node, (nodes.Return, nodes.Assign)):
            fix_range = get_node_range(node)
            nodestr = node.as_string()
            fix_range.replace_with_text(textview, nodestr)
            return True
        if isinstance(node.parent, (nodes.If, nodes.While)) and not isinstance(node, nodes.If):
            pnode = node.parent
            return self.fix_if_while_test(pnode, textview, keyword_name)
        if isinstance(node, nodes.If):
            return self.fix_if_while_test(node, textview, keyword_name)
        return False

    def fix_if_while_test(self, node, textview, keyword_name):
       # if self.cannot_fix(node):
        #    return False
        fixrange = FixRange(node.lineno)
        teststr = node.test.as_string()
        is_ifnode = isinstance(node, nodes.If)
        if is_ifnode:
            if keyword_name not in ['if', 'elif']:
                return False
            nodestr = ' ' * node.col_offset + f"{keyword_name} {teststr}:"
        else:
            nodestr = ' ' * node.col_offset + f"while {teststr}:"
        fixrange.replace_line(textview, nodestr)
        return True
