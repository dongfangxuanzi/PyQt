#!/usr/bin/env python
"""
Automatically formats Python code to conform to the PEP 8 style guide.
Fixes that only need be done once can be added by adding a function of the form
"fix_<code>(source)" to this module. They should return the fixed source code.
These fixes are picked up by apply_global_fixes().
Fixes that depend on pycodestyle should be added as methods to FixPEP8. See the
class documentation for more information.
"""
import copy
import inspect
import io
import re
import sys
import logging
import pylint
from pylint.lint.pylinter import MANAGER
from pylint.lint import Run as PylintRun
from .formatter import ModuleFormatter
from .message import Message
from .fileutils import (
    readlines_from_file,
    read_from_file,
    detect_encoding,
    make_tempfile,
    open_with_encoding
)
from .utils import compute_run_time
from .strutils import normalize_line_endings
from .exceptions import NoFixerError
from .reporter import QuietReport
from .constants import LF, PYLINT_TOOL_NAME, COMMON_PYLINT_MESSAGE_ID
from .pylint_fix import PylintCommonFixer
log = logging.getLogger(__name__)


# these fixes conflict with each other, if the `--ignore` setting causes both
# to be enabled, disable both of them
CONFLICTING_CODES = ('W503', 'W504')


class FixPylintWarnings:
    """
    Fix invalid code.
    Fixer methods are prefixed "fix_". The _fix_source() method looks for these
    automatically.
    The fixer method can take either one or two arguments (in addition to
    self). The first argument is "result", which is the error information from
    pycodestyle. The second argument, "logical", is required only for
    logical-line fixes.
    The fixer method can return the list of modified lines or None. An empty
    list would mean that no changes were made. None would mean that only the
    line reported in the pycodestyle error was modified. Note that the modified
    line numbers that are returned are indexed at 1. This typically would
    correspond with the line number reported in the pycodestyle error
    information.
    [fixed method list]
    """
    FIXVER_V1 = "v1"

    def __init__(self, filename,
                 options,
                 contents=None,
                 long_line_ignore_cache=None):
        self.filename = filename
        if contents is None:
            self._contents_from_file = True
            self.source = readlines_from_file(filename)
        else:
            self._contents_from_file = False
            sio = io.StringIO(contents)
            self.source = sio.readlines()
        self.options = options
        self.name = PYLINT_TOOL_NAME
        self.__fixed_count = 0
        self.original_source = copy.copy(self.source)
        self._formatter = ModuleFormatter(self.source, self.filename)
        self._fixers = []

        # collect imports line
        self.imports = {}
        for i, line in enumerate(self.source):
            if (line.find("import ") == 0 or line.find("from ") == 0) and \
                    line not in self.imports:
                # collect only import statements that first appeared
                self.imports[line] = i

        self.long_line_ignore_cache = (
            set() if long_line_ignore_cache is None
            else long_line_ignore_cache)

        # Many fixers are the same even though pycodestyle categorizes them
        # differently.
        self.add_fixers()
        self.init_fixers(options)

    @property
    def fixer_version(self):
        return self.get_fixer_version(pylint.__version__)

    @property
    def fixed_count(self):
        return self.__fixed_count

    @property
    def fixers(self):
        return self._fixers

    @classmethod
    def get_fixer_version(cls, version_str):
        if version_str.find('3.0.3') != -1:
            return cls.FIXVER_V1
        return None

    def has_empty_fixer(self, ver=None):
        if not self._fixers:
            return True
        if len(self._fixers) <= 5:
            return True
        last_fixer = self._fixers[-2]
        fixer_module_name = last_fixer.__module__
        mods = fixer_module_name.split(".")
        if ver and ver != mods[3]:
            return True
        return False

    def add_fixers(self):
        # pylint3.0.3版本的定制规则修复器对应v1版本
        if self.is_fixer_ver_v1() and self.has_empty_fixer(self.FIXVER_V1):
            from .pylint.fixers import v1
            self.add_fixer(v1.PylintW0611Fixer())
            self.add_fixer(v1.PylintC0327Fixer())
            self.add_fixer(v1.PylintE0001Fixer())
            self.add_fixer(v1.PylintF0010Fixer())
            self.add_fixer(v1.PylintC2503Fixer())
            self.add_fixer(v1.PylintW0404Fixer())
            self.add_fixer(v1.PylintE0711Fixer())
            self.add_fixer(v1.PylintR0402Fixer())
            self.add_fixer(v1.PylintR1705Fixer())
            self.add_fixer(v1.PylintW0107Fixer())
            self.add_fixer(v1.PylintC0303Fixer())
            self.add_fixer(v1.PylintC0411Fixer())
            self.add_fixer(v1.PylintC0325Fixer())
            self.add_fixer(v1.PylintR0205Fixer())
            self.add_fixer(v1.PylintR1725Fixer())
            self.add_fixer(v1.PylintC0114Fixer())
            self.add_fixer(v1.PylintC0116Fixer())
            self.add_fixer(v1.PylintC0115Fixer())
            self.add_fixer(v1.PylintC0410Fixer())
            self.add_fixer(v1.PylintW0614Fixer())
            self.add_fixer(v1.PylintW0235Fixer())
            self.add_fixer(v1.PylintW1201Fixer())
            self.add_fixer(v1.PylintW1202Fixer())
            self.add_fixer(v1.PylintW0612Fixer())
            self.add_fixer(v1.PylintR0201Fixer())
            self.add_fixer(v1.PylintR6301Fixer())
            self.add_fixer(v1.PylintC0121Fixer())
            self.add_fixer(v1.PylintW0702Fixer())
            self.add_fixer(v1.PylintR1720Fixer())
            self.add_fixer(v1.PylintE0213Fixer())
            self.add_fixer(v1.PylintE0211Fixer())
            self.add_fixer(v1.PylintC0202Fixer())
            self.add_fixer(v1.PylintC0301Fixer())
            self.add_fixer(v1.PylintE0602Fixer())
            self.add_fixer(v1.PylintC0200Fixer())
            self.add_fixer(v1.PylintW0410Fixer())
            self.add_fixer(v1.PylintW0109Fixer())
            self.add_fixer(v1.PylintR1734Fixer())
            self.add_fixer(v1.PylintR1735Fixer())
            self.add_fixer(v1.PylintR1716Fixer())
            self.add_fixer(v1.PylintC0103Fixer())
            self.add_fixer(v1.PylintW1401Fixer())
            self.add_fixer(v1.PylintR1714Fixer())
            self.add_fixer(v1.PylintW1505Fixer())
            self.add_fixer(v1.PylintI0021Fixer())
            self.add_fixer(v1.PylintI0020Fixer())
            self.add_fixer(v1.PylintI0023Fixer())
            self.add_fixer(v1.PylintC0413Fixer())
            self.add_fixer(v1.PylintW1406Fixer())
            self.add_fixer(v1.PylintR1723Fixer())
            self.add_fixer(v1.PylintR1724Fixer())
            self.add_fixer(v1.PylintW0237Fixer())
            self.add_fixer(v1.PylintC0206Fixer())
            self.add_fixer(v1.PylintC2201Fixer())
            self.add_fixer(v1.PylintC1802Fixer())
            self.add_fixer(v1.PylintE0601Fixer())
            self.add_fixer(v1.PylintW0123Fixer())
            self.add_fixer(v1.PylintC0412Fixer())
            self.add_fixer(v1.PylintW0715Fixer())
            self.add_fixer(v1.PylintW0613Fixer())
            self.add_fixer(v1.PylintW0201Fixer())
            self.add_fixer(v1.PylintW0246Fixer())
            self.add_fixer(v1.PylintR1710Fixer())
            self.add_fixer(v1.PylintW0707Fixer())
            self.add_fixer(v1.PylintW0104Fixer())
            self.add_fixer(v1.PylintW0105Fixer())
            self.add_fixer(v1.PylintW0602Fixer())
            self.add_fixer(v1.PylintW0238Fixer())
            self.add_fixer(v1.PylintE1003Fixer())
            self.add_fixer(v1.PylintW0511Fixer())
            self.add_fixer(v1.PylintC0123Fixer())
            self.add_fixer(v1.PylintW0102Fixer())
            self.add_fixer(v1.PylintW4902Fixer())
            self.add_fixer(v1.PylintR1729Fixer())
            self.add_fixer(v1.PylintC1805Fixer())
            self.add_fixer(v1.PylintW0101Fixer())
            self.add_fixer(v1.PylintW9000Fixer())
            self.add_fixer(v1.PylintW9001Fixer())
            self.add_fixer(v1.PylintW9002Fixer())
            self.add_fixer(v1.PylintC0204Fixer())
            self.add_fixer(PylintCommonFixer())
            self.add_fixer(v1.PylintC0207Fixer())
            self.add_fixer(v1.PylintR1701Fixer())
            self.add_fixer(v1.PylintW0231Fixer())
            self.add_fixer(v1.PylintC0321Fixer())
            self.add_fixer(v1.PylintR1719Fixer())
            self.add_fixer(v1.PylintC0117Fixer())
            self.add_fixer(v1.PylintR1731Fixer())
            self.add_fixer(v1.PylintR1730Fixer())
            self.add_fixer(v1.PylintW9003Fixer())
            self.add_fixer(v1.PylintW0012Fixer())
            self.add_fixer(v1.PylintW0120Fixer())
            self.add_fixer(v1.PylintC2801Fixer())
            self.add_fixer(v1.PylintW0622Fixer())
            self.add_fixer(v1.PylintW0621Fixer())
            self.add_fixer(v1.PylintW0401Fixer())
            self.add_fixer(v1.PylintW1514Fixer())
            self.add_fixer(v1.PylintW0221Fixer())
            self.add_fixer(v1.PylintW2301Fixer())
            self.add_fixer(v1.PylintE0102Fixer())
            self.add_fixer(v1.PylintE0104Fixer())
            self.add_fixer(v1.PylintW0718Fixer())
            self.add_fixer(v1.PylintE0704Fixer())
            self.add_fixer(v1.PylintW0719Fixer())
            self.add_fixer(v1.PylintE1200Fixer())
            self.add_fixer(v1.PylintE0603Fixer())
            self.add_fixer(v1.PylintW0222Fixer())
            self.add_fixer(v1.PylintE1120Fixer())
            self.add_fixer(v1.PylintE1121Fixer())
            self.add_fixer(v1.PylintE0710Fixer())
            self.add_fixer(v1.PylintW0402Fixer())
            self.add_fixer(v1.PylintW1512Fixer())
            self.add_fixer(v1.PylintR1711Fixer())
            self.add_fixer(v1.PylintC1804Fixer())
            self.add_fixer(v1.PylintC1803Fixer())
            self.add_fixer(v1.PylintR0202Fixer())
            self.add_fixer(v1.PylintR0203Fixer())
            self.add_fixer(v1.PylintE1142Fixer())
            self.add_fixer(v1.PylintW9005Fixer())
            self.add_fixer(v1.PylintR1728Fixer())
            self.add_fixer(v1.PylintW0211Fixer())

        if self.has_empty_fixer():
            raise NoFixerError

    def init_fixers(self, options):
        c0103_fixer = self.find_fixer('C0103')
        c0103_fixer.standardize_module_name_style = options.standardize_module_name
        c0103_fixer.standardize_local_variable_name_style = options.standardize_local_variable_name
# c0103_fixer.standardize_class_attr_name_style = utils.profile_get_int(
# configkeys.STANDARDIZE_CLASS_ATTR_NAME_STYLE_KEY, False
        c0103_fixer.standardize_function_arg_name_style = options.standardize_function_arg
        is_c0103_autofix_enabled = options.standardize_module_name or options.standardize_local_variable_name or options.standardize_function_arg
        c0103_fixer.autofix = is_c0103_autofix_enabled

        w0401_fixer = self.find_fixer('W0401')
        # w0401_fixer.max_member_count = utils.profile_get_int(
        # configkeys.WILDCARD_IMPORT_COUNT_KEY,
        # PylintFixer.DEFAULT_MAX_MEMBERS_COUNT

        pylint_common_fixer = self.find_fixer(COMMON_PYLINT_MESSAGE_ID)
        pylint_common_fixer.enable_format_module_doc = options.format_doc_str
        pylint_common_fixer.enable_remove_print_expression = options.remove_print_statement
        pylint_common_fixer.enable_convert_tabs = options.convert_tabs

    def is_fixer_ver_v1(self):
        return self.fixer_version == self.FIXVER_V1

    def add_fixer(self, fixer):
        if self.find_fixer(fixer.ruleid):
            raise RuntimeError(f'rule id: {fixer.ruleid} is already in fixers')
        assert fixer.toolname == self.name
        fixer.check_tool = self
        fixer.set_formatter(self._formatter)
        self._fixers.append(fixer)

    def is_rule_fixable(self, rule_id):
        for fixer in self._fixers:
            if fixer.ruleid == rule_id and fixer.toolname == self.name:
                return True
        return False

    def find_fixer(self, rule_id):
        for fixer in self._fixers:
            if fixer.ruleid == rule_id and fixer.toolname == self.name:
                return fixer
        return None

    def expand_pylint_args(args: list):
        pass

    def fix(self):
        """Return a version of the source code with PEP 8 violations fixed."""
        if self._contents_from_file:
            pylint_args = [self.filename]
        else:
            source_content = ''.join(normalize_line_endings(self.source, LF))
            temp_py_filename = make_tempfile(source_content)
            pylint_args = [temp_py_filename]
        self.expand_pylint_args(pylint_args)
        results = _execute_pylint(pylint_args, self.source)
        log.info('check total %d pylint issues', len(results))
        if self.options.line_range:
            start, end = self.options.line_range
            results = [r for r in results
                       if start <= r['line'] <= end]

        self._fix_source(filter_results(source=''.join(self.source),
                                        results=results,
                                        ))

        if self.options.line_range:
            # If number of lines has changed then change line_range.
            count = sum(sline.count('\n')
                        for sline in self.source[start - 1:end])
            self.options.line_range[1] = start + count - 1
        return ''.join(self.source)

    def _fix_source(self, results):
        for result in sorted(results, key=lambda x: x['line'], reverse=True):
            result_id = result['id']
            fixer = self.find_fixer(result_id)
            if fixer is not None:
                msg = Message(
                    result['line'],
                    result['column'],
                    result_id,
                    self.filename,
                    result['info'],
                    PYLINT_TOOL_NAME
                )
                log.debug(
                    '--->  %s:%s:%s: %s: %s',
                    self.filename,
                    result['line'],
                    result['column'],
                    result_id,
                    msg.msg
                )
                suc = fixer.auto_fix_msg(msg)
                if suc:
                    log.info(
                        'fix rule %s on line %d column %d success',
                        result_id,
                        result['line'],
                        result['column']
                    )
                    self.__fixed_count += 1
                else:
                    log.info(
                        'fix rule %s on line %d column %d fail',
                        result_id,
                        result['line'],
                        result['column']
                    )
            else:
                log.debug("--->  rule '%s' can't be fixed.", result_id)
                info = result['info'].strip()
                log.debug('--->  %s:%s:%s:%s', self.filename, result['line'], result['column'], info
                          )


def _execute_pylint(args, source):
    """Execute pycodestyle via python method calls."""
    MANAGER.clear_cache()
    runner = PylintRun(args, reporter=QuietReport(), exit=False)
    return runner.linter.reporter.full_error_results()


def filter_results(source, results):
    """
    Filter out spurious reports from pycodestyle.
    If aggressive is True, we allow possibly unsafe fixes (E711, E712).
    """
    for r in results:
        yield r
    yield {
        'id': COMMON_PYLINT_MESSAGE_ID,
        'line': -1,
        'column': -1,
        'info': "common pylint message"
    }


def fix_lines(content, options, filename=''):
    """Return fixed source code."""
    fixed_warnings = 0
    long_line_ignore_cache = set()
    fix = FixPylintWarnings(
        filename,
        options,
        contents=content,
        long_line_ignore_cache=long_line_ignore_cache
    )
    fixed_source = fix.fix()
    fixed_warnings = fix.fixed_count
    sio = io.StringIO(fixed_source)
    return ''.join(normalize_line_endings(sio.readlines(), LF)), fixed_warnings


@compute_run_time
def fix_file(filename, options=None, output=None, source=None, apply_config=False):
    if not options:
        options = parse_args([filename], apply_config=apply_config)

    if source is None:
        fixed_source = None
        original_source = read_from_file(filename)
    else:
        fixed_source = source
        original_source = source

    if options.in_place or output:
        encoding = detect_encoding(filename)
    log.info('start fix file `%s`', filename)
    fixed_source, fixed_count = fix_lines(fixed_source, options, filename=filename)
    if options.in_place:
        original = original_source.splitlines(keepends=True)
        fixed = fixed_source.splitlines(keepends=True)
        original_source_last_line = (
            original[-1].split("\n")[-1] if original else ""
        )
        fixed_source_last_line = fixed_source.split("\n")[-1]
        if original != fixed or (
            original_source_last_line != fixed_source_last_line
        ):
            with open_with_encoding(filename, 'w', encoding=encoding) as fp:
                fp.write(fixed_source)
            return fixed_source, fixed_count
        return None, fixed_count
    else:
        if output:
            output.write(fixed_source)
            output.flush()
    return fixed_source, fixed_count


def _get_parameters(function):
    if sys.version_info.major >= 3:
        # We need to match "getargspec()", which includes "self" as the first
        # value for methods.
        # https://bugs.python.org/issue17481#msg209469
        if inspect.ismethod(function):
            function = function.__func__

        return list(inspect.signature(function).parameters)
    return inspect.getargspec(function)[0]


def _expand_codes(codes, ignore_codes):
    """expand to individual E/W codes"""
    ret = set()

    is_conflict = False
    if all(
            any(
                conflicting_code.startswith(code)
                for code in codes
            )
            for conflicting_code in CONFLICTING_CODES
    ):
        is_conflict = True

    is_ignore_w503 = "W503" in ignore_codes
    is_ignore_w504 = "W504" in ignore_codes

    for code in codes:
        if code == "W":
            if is_ignore_w503 and is_ignore_w504:
                ret.update({"W1", "W2", "W3", "W505", "W6"})
            elif is_ignore_w503:
                ret.update({"W1", "W2", "W3", "W504", "W505", "W6"})
            else:
                ret.update({"W1", "W2", "W3", "W503", "W505", "W6"})
        elif code in ("W5", "W50"):
            if is_ignore_w503 and is_ignore_w504:
                ret.update({"W505"})
            elif is_ignore_w503:
                ret.update({"W504", "W505"})
            else:
                ret.update({"W503", "W505"})
        elif not (code in ("W503", "W504") and is_conflict):
            ret.add(code)

    return ret


def supported_fixes(options):
    """
    Yield pep8 error codes that autopep8 fixes.
    Each item we yield is a tuple of the code followed by its
    description.
    """
    instance = FixPylintWarnings(filename=None, options=options, contents='')
    for fixer in instance.fixers:
        if isinstance(fixer, PylintCommonFixer):
            continue
        yield (
            fixer.ruleid,
            fixer.get_kind(),
            re.sub(r'\s+', ' ',
                   fixer.__doc__)
        )
