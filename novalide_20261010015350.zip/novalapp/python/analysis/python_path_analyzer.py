import os
import glob
import multiprocessing
import time
from .builtin_analyzer import BuiltinAnalyzer
from .base_analyzer import BaseAnalyzer
from ..parser import fileparser
from .. import prog_lang_ext
from ..parser.define import PACKAGE_INIT_FILE, DATABASE_VERSION, BUILTMODULE_NAME
from ..parser.exceptions import (
    ReferenceModuleNotAnalyzedError,
    OutofPythonPathError,
    AnalyzeCodefileError
)
from ..parser import objtypes
from ..parser.define import MEMBERS_FILE_EXTENSION, MEMBERLIST_FILE_EXTENSION, BUILTINS_DATA_FOLDER
from .moduleloader import ModuleLoader
from ..parser.builtinmodule import BuiltinModule
from ...util import utils, fileutils, strutils
from ..apis.member import Member

logger = utils.get_mp_logger(__name__)


class PythonPathAnalyzer(BuiltinAnalyzer):
    """解析系统和用户搜索路径的所有python代码文件并生成语法数据文件"""
    # 多进程分析语法数据时最大进程数量
    MAX_POOL_COUNT = 5
    # 忽略分析的一些第三方包
    SKIP_THIRD_PACKAGES = frozenset(
        (
            '_pyinstaller_hooks_contrib',
            '_virtualenv',
            'distutils',
            'idlelib',
            'pip',
            'pkg_resources',
            'PyInstaller',
            'setuptools',
            'pywin',
            'virtualenv',
            '_distutils_hack',
            'distlib',
            'future',
            '~in32',
            '~in32com',
            'wheel',
            'pywin32_testutil',
            '_testbuffer',
            '_testcapi',
            '_testconsole',
            '_testimportmultiple',
            '_testmultiphase'
        )
    )
    # 需要延迟到最后分析的模块
    DELAY_ANALYZE_MODULES = ['os.path']
    # 需要显式指定父子关系的所有模块
    EXPLICIT_MEMBERSHIP_MODULES = {
        'os': ['os.path']
    }

    def __init__(
        self,
        dbver,
        data_outpath,
        interpreter,
        pathlist,
        builtin_analyzer,
        check_file_updated=False,
        **kwargs
    ):
        if interpreter.IsBuiltIn:
            # 内建解释器语法数据存放位置
            data_out_path = os.path.join(data_outpath, BUILTINS_DATA_FOLDER)
        else:
            # 用户解释器的语法数据存放位置
            data_out_path = os.path.join(data_outpath, interpreter.MinorVersion)
        BaseAnalyzer.__init__(self, dbver, data_out_path,
                              interpreter, check_file_updated)
        self.pathlist = pathlist
        self.builtin_analyzer = builtin_analyzer
        self._builtmodule = None
        # 解析文件出现异常时是否退出
        self._exit_happen_error = False
        # 是否跳过分析导入语句
        self._skip_imports = not kwargs.get('analyze_imports', False)
        # 是否跳过分析导入*语句
        self._skip_import_stars = not kwargs.get('analyze_import_stars', False)

    @property
    def skip_imports(self):
        return self._skip_imports

    @property
    def skip_import_stars(self):
        return self._skip_import_stars

    @property
    def BuiltinModule(self):
        if self._builtmodule is None:
            self.load_builtin_module()
        return self._builtmodule

    @staticmethod
    def is_test_dir(dir_path):
        dir_name = os.path.basename(dir_path).lower()
        if dir_name in ["test", "tests", 'idle_test']:
            return True
        return False

    @staticmethod
    def is_package_dir(dirpath):
        if os.path.exists(os.path.join(dirpath, PACKAGE_INIT_FILE)):
            return True
        return False

    def load_builtin_module(self):
        # 检查内建模块数据库版本是否过期,如果过期不能使用
        if self.builtin_analyzer.need_update_version(DATABASE_VERSION):
            logger.warning("builtin intellisence data path %s is need to update....",
                           self.builtin_analyzer.data_out_path)
            return
        mdloader = self.builtin_analyzer.load_module(BUILTMODULE_NAME)
        if mdloader is None:
            logger.error("load builtins module members file error")
            return
        self._builtmodule = BuiltinModule()
        data = mdloader.data
        self._builtmodule.load(data)
        logger.debug(
            'load %s module data path `%s` success',
            BUILTMODULE_NAME,
            self.builtin_analyzer.get_members_file(BUILTMODULE_NAME)
        )

    def normalize_sys_path(self):
        '''
        格式化python系统路径,有的系统路径是相对路径,转换为绝对路径
        '''
        pathlist = self.pathlist
        for i, path in enumerate(pathlist):
            pathlist[i] = os.path.normcase(os.path.abspath(path))

    @utils.compute_time
    def run(self):
        # 单线程解析文件出错时为了方便调试强制退出
        self._exit_happen_error = True
        fileutils.makedirs(self.data_out_path)
        self.normalize_sys_path()
        self.check_database_renew()
        self.make_pyd_members()
        updated = 0
        for pythonpath in self.pathlist:
            try:
                updated += self.scan_sys_path(pythonpath)
            except Exception as ex:
                logger.error("%s", str(ex))
                break
        self.end()
        logger.info('total update %d code analysis files', updated)

    def scan_sys_path(self, syspath):
        logger.info('start analyze python sys path `%s` intellisence data', syspath)
        start = time.perf_counter()
        updated = self.scan_python_path(syspath)
        logger.info('end analyze python sys path `%s`', syspath)
        end = time.perf_counter()
        elapse = int(end - start)
        logger.info("scan sys path `%s` elapse %d seconds.", syspath, elapse)
        return updated

    @utils.compute_time
    def pool_run(self):
        fileutils.makedirs(self.data_out_path)
        self.normalize_sys_path()
        self.check_database_renew()
        # 首先创建内建模块数据文件,其次是创建pyd/so扩展模块的数据文件,最后创建python代码模块的数据文件
        self.make_pyd_members()
        pool = multiprocessing.Pool(processes=min(self.MAX_POOL_COUNT, len(self.pathlist)))
        result = []
        for path in self.pathlist:
            res = pool.apply_async(self.scan_sys_path, (path,))
            result.append(res)
        pool.close()
        pool.join()
        updated = 0
        try:
            for res in result:
                updated += res.get()
        except Exception:
            logger.exception('crash in pool run code analysis:')
        logger.info('total update %d code analysis files', updated)
        self.end()

    def end(self):
        # 一些延迟分析模块的数据文件生成
        self.make_delay_module_api_files()
        # 最后的清理工作,删除一些不存在的代码数据库文件
        self.clean_deleted_files()
        if self._need_renew_database:
            self.update_new_version(self.dbver)
        self.update_last_timestamp()

    def is_module_skipped(self, modname):
        modnames = modname.split('.')
        if modnames[0] in self.SKIP_THIRD_PACKAGES:
            return True
        return False

    def scan_python_path(self, pythonpath):
        updated = 0
        searchpath = os.path.join(pythonpath, "*")
        for filepath in glob.glob(searchpath):
            if os.path.isfile(filepath):
                ext = strutils.get_file_extension(filepath)
                if ext in prog_lang_ext.PYTHON_CODE_FILE_EXT:
                    modname = self.get_relative_path(filepath)
                    # 过滤掉中文模块名
                    if strutils.find_chinese_character(modname):
                        continue
                    if self.is_module_skipped(modname):
                        logger.debug('module name %s is skipped', modname)
                        continue
                    if not self.need_renew_module(modname, filepath):
                        logger.debug(
                            'python file %s database is not need upate', filepath)
                        continue
                    logger.debug('python file %s modname is %s',
                                 filepath, modname)
                    filename = os.path.basename(filepath)
                    if self.make_code_api_files(filename, filepath, modname):
                        updated += 1
                        logger.info(
                            'analyze new code file %s, modname %s success', filepath, modname)
                    else:
                        logger.error('analyze code file %s error', filepath)
                elif ext in [
                    prog_lang_ext.PYTHON_PYD_FILE_EXT,
                    prog_lang_ext.PYTHON_SO_FILE_EXT
                ]:
                    logger.debug('skip pyd/so file %s', filepath)
                else:
                    logger.debug("skip no python file %s", filepath)
            elif os.path.isdir(filepath):
                if self.is_test_dir(filepath):
                    logger.debug("skip test dir %s", filepath)
                elif not self.is_package_dir(filepath):
                    logger.debug("skip nonpackage dir %s", filepath)
                else:
                    updated += self.scan_python_path(filepath)
        return updated

    def get_relative_path(self, file_path):
        '''
        获取python code/pyd文件的模块路径,相对路径,即导入路径
        '''
        parent_path = os.path.dirname(file_path)
        recent_path = ''
        while True:
            # 文件某个层路径在解释器搜索路径中
            if fileutils.paths_contain_path(self.pathlist, parent_path):
                recent_path = parent_path
                break
            # 文件所有层级路径都在解释器搜索路径之外
            if os.path.dirname(parent_path) == parent_path:
                break
            parent_path = os.path.dirname(parent_path)
        if not recent_path:
            file_dir_path = os.path.dirname(file_path)
            logger.error("file %s dir path %s is outof pythonpath list %s",
                         file_path, file_dir_path, self.pathlist)
            raise OutofPythonPathError(
                "module path %s is outof pythonpath" % file_dir_path)
        # 文件路径相对最近的搜索路径的模块名称
        relative_path = file_path.replace(
            recent_path + os.sep, '').split('.')[0]
        if utils.is_windows():
            relative_path = relative_path.replace(os.sep, '/')
        parts = relative_path.split('/')
        # 包路径
        if parts[-1] == PACKAGE_INIT_FILE.split('.', maxsplit=1)[0]:
            relative_module_name = '.'.join(parts[0:-1])
        else:
            relative_module_name = '.'.join(parts)
        return relative_module_name

    def get_mod_file_path(self, modname):
        mod_to_path = modname.replace(".", os.sep)
        relative_mod_path = mod_to_path + "." + \
            prog_lang_ext.PYTHON_CODE_FILE_EXT[0]
        relative_pyd_path = mod_to_path + "." + prog_lang_ext.PYTHON_PYD_FILE_EXT
        package_mod_path = mod_to_path + os.sep + PACKAGE_INIT_FILE
        for path in self.pathlist:
            modpath = os.path.join(path, relative_mod_path)
            package_path = os.path.join(path, package_mod_path)
            mod_pyd_path = os.path.join(path, relative_pyd_path)
            if os.path.exists(modpath):
                return modpath
            if os.path.exists(package_path):
                return package_path
            if os.path.exists(mod_pyd_path):
                return mod_pyd_path
        return None

    def parse_submodules(self, file_parser, package_file_path):
        package_dir = os.path.dirname(package_file_path)
        submodules = []
        for filename in os.listdir(package_dir):
            if strutils.find_chinese_character(filename):
                continue
            subfile_path = os.path.join(package_dir, filename)
            source = True
            if os.path.isfile(subfile_path):
                ext = strutils.get_file_extension(subfile_path)
                if ext not in prog_lang_ext.PYTHON_CODE_FILE_EXT + (prog_lang_ext.PYTHON_PYD_FILE_EXT, ):
                    continue
                if filename == PACKAGE_INIT_FILE:
                    continue
                sub_mod_name = self.get_relative_path(subfile_path)
                # pyd文件是非源码
                if ext == prog_lang_ext.PYTHON_PYD_FILE_EXT:
                    source = False
            elif os.path.isdir(subfile_path):
                if not self.is_package_dir(subfile_path):
                    continue
                subfile_path = os.path.join(subfile_path, PACKAGE_INIT_FILE)
                sub_mod_name = self.get_relative_path(subfile_path)
            try:
                submodule = file_parser.get_ast(
                    subfile_path, sub_mod_name, source)
                # pyd文件时设置模块文件路径
                if not source:
                    submodule.file = subfile_path
            except Exception as ex:
                submodule = None
                logger.error('parse python file %s modname %s ast error:%s',
                             subfile_path, sub_mod_name, str(ex))
            if submodule is not None:
                submodules.append(Member('', sub_mod_name, objtypes.MODULE, submodule))
        return submodules

    def make_pyd_members(self):
        '''
        创建pyd/so扩展模块的数据文件,使用解释器路径启动进程扫描生成所有pyd模块的数据文件
        '''
        if utils.is_windows():
            extension = prog_lang_ext.PYTHON_PYD_FILE_EXT
        else:
            extension = prog_lang_ext.PYTHON_SO_FILE_EXT
        logger.info('create %s builtin members', extension)
        self.create_builtintypes_members(extension)

    def make_membership_modules(self, file_parser, modname, childs: list):
        '''强制分析那些显式指定父子关系的模块'''
        if modname not in self.EXPLICIT_MEMBERSHIP_MODULES:
            return
        for child_module_name in self.EXPLICIT_MEMBERSHIP_MODULES[modname]:
            chil_module_path = self.interpreter.find_module(child_module_name)
            if not chil_module_path:
                continue
            child_module_ast = file_parser.get_ast(chil_module_path, child_module_name)
            childs.append(Member('', child_module_name, objtypes.MODULE, child_module_ast))

    def make_code_api_files(self, filename, filepath, modname, use_cache=True):
        file_parser = fileparser.CodefileParser(self)
        file_parser.use_cache = use_cache
        try:
            module = file_parser.parse_single_file(filename, filepath, modname)
            if module is None:
                if self._exit_happen_error:
                    # 解析单个代码文件出错,强制退出
                    raise AnalyzeCodefileError(
                        "analyze code file %s error" % filepath)
                return False
            childs = file_parser.childs
            # 解析包文件,包目录下的其他文件都是包的子模块
            if module.package:
                sub_modules = self.parse_submodules(file_parser, filepath)
                childs.extend(sub_modules)
            self.make_membership_modules(file_parser, modname, childs)
            self.make_members_file(
                module,
                modname,
                childs,
                finished=file_parser.finished,
                isbuiltin=self.interpreter.IsBuiltIn
            )
        except ReferenceModuleNotAnalyzedError as ex:
            logger.warning(str(ex))
            return False
        except OutofPythonPathError as e:
            logger.error(str(e))
            logger.exception('parse code file %s occur exception:', filepath)
            return False
        return True

    def make_singleapi_files(self, filepath):
        fileutils.makedirs(self.data_out_path)
        self.normalize_sys_path()
        ext = strutils.get_file_extension(filepath)
        modname = self.get_relative_path(filepath)
        if ext == prog_lang_ext.PYTHON_PYD_FILE_EXT:
            raise RuntimeError('invalid code file extension')
        logger.info('python file %s modname is %s', filepath, modname)
        filename = os.path.basename(filepath)
        return self.make_code_api_files(filename, filepath, modname)

    def make_delay_module_api_files(self):
        for delay_module in self.DELAY_ANALYZE_MODULES:
            if not self.need_renew_module(delay_module):
                logger.info('delay module name %s is no need to updated...', delay_module)
                continue
            delay_module_path = self.interpreter.find_module(delay_module)
            if not delay_module_path:
                continue
            logger.info('delay module %s file path is `%s`', delay_module, delay_module_path)
            self.make_code_api_files('', delay_module_path, delay_module)

    def clean_deleted_files(self):
        '''
        检查数据库里面的代码源文件是否存在如果不存在则删除
        '''
        delete_num = 0
        # iglob和glob功能一样,glob返回整个文件列表,iglob返回生成器,可以避免一次性加载到内存
        for memberlist_filepath in glob.iglob(os.path.join(self.data_out_path, "*" + MEMBERLIST_FILE_EXTENSION)):
            filename = os.path.basename(memberlist_filepath)
            modname = strutils.get_filename_without_ext(filename)
            members_filepath = os.path.abspath(os.path.join(
                self.data_out_path, modname + MEMBERS_FILE_EXTENSION))
            if self.is_module_skipped(modname):
                ModuleLoader('', members_filepath, memberlist_filepath).delete_api_files()
                delete_num += 1
                continue
            if not ModuleLoader('', members_filepath, memberlist_filepath).reload():
                delete_num += 1
        logger.info('delete total %d intelliense database files in path %s',
                    delete_num, self.data_out_path)

    def get_refmod_apifiles(self, modname):
        membersfile, memberlistfile = self.get_api_files(modname)
        return [[membersfile, memberlistfile]]

    def get_refmod_apilist(self, modname):
        if self.interpreter.is_builtin_module(modname):
            return [self.builtin_analyzer.get_api_file(modname)]
        return [self.get_api_file(modname)]
