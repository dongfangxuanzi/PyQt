import sys
import re
import os
import copy
import builtins
from . import prog_lang_ext
from ..lib.docmanager import DocManager
from .project import ext
from ..project import ext as common_project_ext
from .. import constants
from . import pythonenv
from ..lib.pyqt import QMessageBox
from .interpreter.interpreterconfiguration.pipenv import InstallPackagesDialog
from .. import get_app, _
from ..util.exceptions import PluginRequiredPackagesError
from ..util import strutils, environments, apputils, fileutils

# 匹配python文件开头编码声明的正则表达式
CODING_STR_REG = re.compile(r'^[ \t\f]*#.*coding[:=][ \t]*([-\w.]+)')
PYTHON_SHEBANG_REGEX = re.compile(r'#!\s*(/usr/bin/python|/usr/bin/env\s*python)')


def is_python_file(file_path):
    ext = strutils.get_file_extension(file_path)
    return ext in prog_lang_ext.PYTHON_CODE_FILE_EXT


class PydocManager(DocManager):

    def load_project_exts(self, keepstar=False):
        project_extensions = super().load_project_exts(keepstar)
        python_project_template = get_app().GetDocumentManager(
        ).FindTemplateForTestPath(ext.PYTHON_PROJECT_EXTENSION)
        python_project_exts = python_project_template.exts(keepstar=keepstar)
        project_extensions.extend(python_project_exts)
        return project_extensions

    def get_project_filter(self):
        common_project_template = get_app().GetDocumentManager(
        ).FindTemplateForTestPath(common_project_ext.COMMON_PROJECT_EXTENSION)
        project_extensions = self.load_project_exts(keepstar=True)
        descr = ";".join(project_extensions)
        python_project_filter = common_project_template.GetDescription() + \
            f' ({descr})'
        return python_project_filter


def get_python_coding_declare(lines):
    # Only consider the first two lines
    blank_reg_str = re.compile(r'^[ \t\f]*(?:[#\r\n]|$)')
    lst = lines[:constants.ENCODING_DECLARE_LINE_NUM]
    hit_line = 0
    for line in lst:
        hit_line += 1
        match = CODING_STR_REG.match(line)
        if match is not None:
            break
        if not blank_reg_str.match(line):
            return None, -1
    else:
        return None, -1
    name = match.group(1)
    return name, hit_line


def update_pythonpath_env(env, pythonpath):
    if isinstance(pythonpath, list):
        pathstr = os.pathsep.join(pythonpath)
    else:
        pathstr = pythonpath
    if pythonenv.PYTHON_PATH_NAME in env:
        env[pythonenv.PYTHON_PATH_NAME] = env[pythonenv.PYTHON_PATH_NAME] + \
            os.pathsep + pathstr
    else:
        env[pythonenv.PYTHON_PATH_NAME] = pathstr
    return env


def update_environment_with_overrides(env, overrides, overwrite_key=False):
    '''
    将环境变量复制到另一个环境变量中,overwrite_key表示是否覆盖相同key的环境变量值
    '''
    for key in overrides:
        if key not in env:
            env[key] = overrides[key]
        else:
            if overwrite_key:
                env[key] = overrides[key]


def get_override_runparameter(run_parameter):
    interpreter = run_parameter.Interpreter
    environment = run_parameter.Environment
    environ = interpreter.Environ.GetEnviron()
    if pythonenv.PYTHON_PATH_NAME in environ and environment is not None:
        environ = update_pythonpath_env(
            environ, environment.get(pythonenv.PYTHON_PATH_NAME, ''))

    interpreter_specific_keys = [
        "TCL_LIBRARY",
        "TK_LIBRARY",
        "LD_LIBRARY_PATH",
        "DYLD_LIBRARY_PATH",
        "SSL_CERT_DIR",
        "SSL_CERT_FILE",
        "PYTHONHOME",
        "PYTHONNOUSERSITE",
        "PYTHONUSERBASE",
    ]
    if len(environ) > 0:
        if environment is None:
            environment = environ
        else:
            # 如果出现相同名称的环境变量,优先顺序为用户配置环境变量>解释器配置环境变量>系统环境变量
            update_environment_with_overrides(environment, environ)

    # 软件安装路径下面的tk版本和解释器自带的tk版本会混淆,故必须去除系统环境变量中类似TCL_LIBRARY,TK_LIBRARY的变量
    # 如果不去除会出现如下类似错误:
    # version conflict for package "Tcl": have 8.5.15, need exactly 8.6.6
    for key in interpreter_specific_keys:
        if key in os.environ:
            del environment[key]
    # add python path to env
    if len(interpreter.python_path_list) > 0:
        environment = update_pythonpath_env(
            environment, interpreter.python_path_list)
    if run_parameter.Environment == environment:
        return run_parameter
    save_interpreter = run_parameter.Interpreter
    run_parameter.Interpreter = None
    cp_run_parameter = copy.deepcopy(run_parameter)
    cp_run_parameter.Environment = environment
    run_parameter.Interpreter = save_interpreter
    return cp_run_parameter


def check_plugin_required_packages(plugin, interpreter):
    '''
    检查插件需要解释器安装的依赖包列表
    '''
    required_pkgs = plugin.required_packages()
    install_pkgs = []
    for package_name in required_pkgs:
        # 模块名里面可能包含版本号,需要提取出真正模块名
        if package_name.find('==') != -1:
            real_package_name = package_name.split("==")[0]
        else:
            real_package_name = package_name
        if not interpreter.GetInstallPackage(real_package_name):
            install_pkgs.append(package_name)

    if len(install_pkgs) > 0:
        package_names = ','.join(install_pkgs)
        QMessageBox.information(
            get_app().GetTopWindow(),
            get_app().GetAppName(),
            _("Interpreter %s need to install package \"%s\"") % (
                interpreter.name, package_names)
        )
        dlg = InstallPackagesDialog(
            get_app().GetTopWindow(),
            interpreter,
            pkg_name=package_names,
            install_args='--user %s' % package_names,
            autorun=True
        )
        dlg.exec_()
        raise PluginRequiredPackagesError


def get_environment_overrides_for_python_subprocess(target_executable, is_venv=False):
    """
    Take care of not not confusing different interpreter
    with variables meant for bundled interpreter
    """

    # At the moment I'm tweaking the environment only if current
    # exe is bundled for Thonny.
    # In remaining cases it is user's responsibility to avoid
    # calling Thonny with environment which may be confusing for
    # different Pythons called in a subprocess.

    this_executable = sys.executable.replace("pythonw.exe", "python.exe")
    target_executable = target_executable.replace("pythonw.exe", "python.exe")

    interpreter_specific_keys = [
        "TCL_LIBRARY",
        "TK_LIBRARY",
        "LD_LIBRARY_PATH",
        "DYLD_LIBRARY_PATH",
        "SSL_CERT_DIR",
        "SSL_CERT_FILE",
        "PYTHONHOME",
        "PYTHONPATH",
        "PYTHONNOUSERSITE",
        "PYTHONUSERBASE",
        apputils.MAINMODULE_DIR_ENV
    ]

    result = {}
    if fileutils.ComparePath(target_executable, this_executable) or is_venv:
        # bring out some important variables so that they can
        # be explicitly set in macOS Terminal
        # (If they are set then it's most likely because current exe is in Thonny bundle)
        for key in interpreter_specific_keys:
            if key in os.environ:
                result[key] = os.environ[key]

        # never pass some variables to different interpreter
        # (even if it's venv or symlink to current one)
        if not fileutils.ComparePath(target_executable, this_executable):
            for key in ["PYTHONPATH", "PYTHONHOME", "PYTHONNOUSERSITE", "PYTHONUSERBASE"]:
                if key in os.environ:
                    result[key] = None
    else:
        # interpreters are not related
        # interpreter specific keys most likely would confuse other interpreter
        for key in interpreter_specific_keys:
            if key in os.environ:
                result[key] = None

    # some keys should be never passed
    for key in [
        "PYTHONSTARTUP",
        "PYTHONBREAKPOINT",
        "PYTHONDEBUG",
        "PYTHONNOUSERSITE",
        "PYTHONASYNCIODEBUG",
    ]:
        if key in os.environ:
            result[key] = None
    return result


def get_environment_for_python_subprocess(target_executable, is_venv):
    overrides = get_environment_overrides_for_python_subprocess(
        target_executable, is_venv)
    return environments.get_environment_with_overrides(overrides)


def get_builtin_exceptions(exceptions: list):
    '''搜集所有内建异常类型'''
    for name in dir(builtins):
        builtinobj = getattr(builtins, name)
        if isinstance(builtinobj, type) and issubclass(builtinobj, Exception):
            exceptions.append(name)
