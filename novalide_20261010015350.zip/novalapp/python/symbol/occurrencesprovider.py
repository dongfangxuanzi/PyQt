# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2020  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""Occurrences search result providers"""

from ... import _
from .resultprovideriface import SearchResultProviderIFace
from .parameter import OccurrencesParameter


class OccurrencesSearchProvider(SearchResultProviderIFace):
    """occurrences search results provider"""

    def __init__(self):
        SearchResultProviderIFace.__init__(self)

    @staticmethod
    def serialize(parameter: OccurrencesParameter):
        """Provides a string which serializes the search parameters"""
        return [
            (_('Symbol'), parameter.findstr),
            (_('FileName'), parameter.filename),
            (_('Line'), str(parameter.line + 1)),
            (_('Column'), str(parameter.col))
        ]

    @staticmethod
    def searchAgain(search_id, parameter, results_viewer):
        """Repeats the search"""

    @staticmethod
    def get_name():
        """Provides the display name"""
        return _('Find Occurrences')
