# -*- coding: utf-8 -*-
import importlib
import time
import logging
from psutil import NoSuchProcess
import psutil
from .urlutils import *
from .strutils import *
from .. import get_app
from ..lib.profile import Profile
from .logger import *
from .apputils import *
from .appdirs import *
log = logging.getLogger(__name__)


def profile_get(key, value=""):
    return Profile.get(key, value)


def profile_get_int(key, value=-1):
    return Profile.get_int(key, value)


def profile_set(key, value):
    return Profile.set(key, value)


def update_statusbar(msg):
    get_app().MainFrame.PushStatusText(msg)


def get_child_pids(ppid):
    child_ids = []
    for pid in psutil.pids():
        try:
            p = psutil.Process(pid)
            if p.ppid() == ppid:
                child_ids.append(p.pid)
        except (ValueError, NoSuchProcess) as ex:
            log.error(str(ex))
    return child_ids


def get_class_from_dynamicimport_module(full_class_path):
    '''
    从给定字符串中动态获取模块的类
    '''
    parts = full_class_path.split(".")
    full_module_path = ".".join(parts[0:-1])
    class_name = parts[-1]
    # 必须先导入模块,再获取模块里面的方法,不要直接导入类
    module_obj = importlib.import_module(full_module_path)
    log.debug("module %s file path is %s",
              full_module_path, module_obj.__file__)
    class_obj = getattr(module_obj, class_name)
    return class_obj


def compute_time(func):
    '''
    统计函数执行时间的装饰函数
    '''
    def wrapped_func(*args, **kwargs):
        start = time.perf_counter()
        ret = func(*args, **kwargs)
        end = time.perf_counter()
        elapse = end - start
        log.info("function %s elapse %.3f seconds in module %s",
                 func.__qualname__, elapse, func.__module__)
        return ret
    return wrapped_func
