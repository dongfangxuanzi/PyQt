# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        appdirs.py
Purpose:
Author:      wukan
Created:     2019-01-08
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import logging
import sys
import os
from . import apputils
from .. import get_app
from ..constants import APPLICATION_NAME, USER_CACHE_DIR

logger = logging.getLogger(__name__)
PLUGIN_DIR_NAME = "plugins"


def _getSystemDir(kind):
    '''
    获取软件的工作目录,比如项目默认的存放路径等
    '''
    if kind == AG_LOGS_DIR:
        return os.path.join(getSystemDir(AG_SYSTEM_DIR), "logs")
    if kind == AG_DEMOS_DIR:
        return os.path.join(getSystemDir(AG_SYSTEM_DIR), "demos")
    path = os.getenv("AG_DOCUMENTS_DIR")
    if ((path is None) or (len(path) < 1)):
        if apputils.is_windows():
            try:
                from win32com.shell import shell, shellcon
                path = shell.SHGetFolderPath(
                    0, shellcon.CSIDL_PERSONAL, None, 0)
            except Exception:
                logger.exception('')
            if ((path is None) or (len(path) < 1)):
                homedrive = asString(os.getenv("HOMEDRIVE"))
                homepath = os.getenv("HOMEPATH")
                path = os.path.join(homedrive, homepath, "MYDOCU~1")
        else:
            if sys.platform == "darwin":
                try:
                    import macfs
                    import MACFS
                    fsspec_disk, fsspec_desktop = macfs.FindFolder(
                        MACFS.kOnSystemDisk, MACFS.kDocumentsFolderType, 0)
                    path = macfs.FSSpec(
                        (fsspec_disk, fsspec_desktop, '')).as_pathname()
                except Exception:
                    pass

        if ((path is None) or (len(path) < 1)):
            path = os.path.expanduser("~")
        if ((path is None) or (len(path) < 1)):
            path = "/"
        path = os.path.join(path, APPLICATION_NAME)
    return path


AG_SYSTEM_DIR = 0
AG_LOGS_DIR = 1
AG_DEMOS_DIR = 2

__systemDir = None
__logsDir = None
__demosDir = None


def getSystemDir(kind=0):
    if kind == AG_SYSTEM_DIR:
        global __systemDir
        if __systemDir is None:
            __systemDir = _getSystemDir(kind)
        return __systemDir
    if kind == AG_LOGS_DIR:
        global __logsDir
        if __logsDir is None:
            __logsDir = _getSystemDir(kind)
        return __logsDir
    if kind == AG_DEMOS_DIR:
        global __demosDir
        if __demosDir is None:
            __demosDir = _getSystemDir(kind)
        return __demosDir
    return None


# NOTE: We don't set this at startup because wxStandardPaths needs a running
# application object. This makes sure the wxApp will always be created when
# we get the folder.

def get_user_data_path():
    if apputils.is_windows():
        try:
            import ctypes.wintypes
            csidl_appdata = 26
            shgfp_type_current = 0
            buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
            ctypes.windll.shell32.SHGetFolderPathW(
                0, csidl_appdata, 0, shgfp_type_current, buf
            )
            return os.path.join(buf.value, get_app().GetAppName())
        except Exception:
            app_datapath = os.getenv('APPDATA')
            return os.path.join(app_datapath, get_app().GetAppName())
    else:
        # wxBug: on *nix, it wants to point to ~/.appname, but
        # so does wxConfig... For now, redirect this to ~/.appbuilder
        # when this is fixed, we'll migrate settings to the correct place
        return os.path.join(os.path.expanduser("~"), ".Noval")


def createSystemDirs():
    if not os.path.exists(getSystemDir()):
        os.mkdir(getSystemDir())
    if not os.path.exists(getSystemDir(AG_LOGS_DIR)):
        os.mkdir(getSystemDir(AG_LOGS_DIR))
    if not os.path.exists(getSystemDir(AG_DEMOS_DIR)):
        os.mkdir(getSystemDir(AG_DEMOS_DIR))


def get_app_image_location():
    app_image_path = os.path.join(
        apputils.mainModuleDir, "novalapp", "bmp_source")
    return os.path.normpath(app_image_path)


def get_app_data_location():
    app_data_path = os.path.join(apputils.mainModuleDir, "novalapp", "data")
    return app_data_path


def get_app_path():
    return apputils.mainModuleDir


def get_user_plugin_path():
    return os.path.join(get_user_data_path(), PLUGIN_DIR_NAME)


def get_sys_plugin_path():
    return os.path.join(get_app_path(), PLUGIN_DIR_NAME)


def get_cache_path():
    user_data_path = get_user_data_path()
    cache_path = os.path.join(user_data_path, USER_CACHE_DIR)
    return cache_path


def get_home_dir():
    '''
    获取用户的主目录
    '''
    path = ''
    if apputils.is_windows():
        try:
            from win32com.shell import shell, shellcon
            path = shell.SHGetFolderPath(0, shellcon.CSIDL_PROFILE, None, 0)
        except Exception:
            homedrive = os.getenv("HOMEDRIVE")
            homepath = os.getenv("HOMEPATH")
            path = os.path.join(homedrive, homepath)
    else:
        path = os.path.expanduser("~")
    return path
