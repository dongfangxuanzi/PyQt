# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2016-2017  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""QT color and font general utils"""
from .. import get_app
from ..lib.pyqt import QColor, QFont, QFontComboBox


def checkColorRange(value):
    """Checks the color range"""
    if value < 0 or value > 255:
        raise RuntimeError("Invalid color value")


def toHex(value):
    """Converts the value to a double digit hex string"""
    asstr = hex(value)[2:]
    if len(asstr) == 1:
        return '0' + asstr
    return asstr


def buildColor(color):
    """
    Six options are supported:
    #hhh                hexadecimal rgb
    #hhhh               hexadecimal rgba
    #hhhhhh             hexadecimal rrggbb
    #hhhhhhhh           hexadecimal rrggbbaa
    ddd,ddd,ddd         decimal rgb
    ddd,ddd,ddd,ddd     decimal rgba
    """
    if color.startswith('#'):
        def normalizeLength(spec):
            if len(spec) in [6, 8]:
                return spec
            normalized = ''
            for character in spec:
                normalized += 2 * character
            return normalized

        color = color[1:]
        length = len(color)
        if length not in [3, 4, 6, 8]:
            raise RuntimeError("Invalid hexadecimal color format: #" + color)

        try:
            # The most common case
            norm_color = normalizeLength(color)
            red = int(norm_color[0:2], 16)
            checkColorRange(red)
            green = int(norm_color[2:4], 16)
            checkColorRange(green)
            blue = int(norm_color[4:6], 16)
            checkColorRange(blue)

            if length in [3, 6]:
                return QColor(red, green, blue)
            alpha = int(norm_color[6:8], 16)
            checkColorRange(alpha)
            return QColor(red, green, blue, alpha)
        except:
            raise RuntimeError("Invalid hexadecimal color format: #" + color)

    parts = color.split(',')
    length = len(parts)
    if length not in [3, 4]:
        raise RuntimeError("Invalid decimal color format: " + color)

    try:
        red = int(parts[0].strip())
        checkColorRange(red)
        green = int(parts[1].strip())
        checkColorRange(green)
        blue = int(parts[2].strip())
        checkColorRange(blue)

        if length == 3:
            return QColor(red, green, blue)
        alpha = int(parts[3].strip())
        checkColorRange(alpha)
        return QColor(red, green, blue, alpha)
    except:
        raise RuntimeError("Invalid decimal color format: " + color)


def cssLikeColor(color):
    """Converts to a css like string, possibly shortened"""
    as_str = color.name()
    alpha = color.alpha()
    if alpha != 255:
        as_str += toHex(alpha)

    # Shorten it if possible
    if len(as_str) == 7:
        if as_str[1] == as_str[2] and as_str[3] == as_str[4] and \
           as_str[5] == as_str[6]:
            return '#' + as_str[1] + as_str[3] + as_str[5]
        return as_str

    if as_str[1] == as_str[2] and as_str[3] == as_str[4] and \
       as_str[5] == as_str[6] and as_str[7] == as_str[8]:
        return '#' + as_str[1] + as_str[3] + as_str[5] + as_str[7]
    return as_str


def transparentColor(fgColor, bgColor, alpha):
    """Converts the color value considering the background and alpha"""
    if alpha == 255:
        return fgColor

    d_alpha = float(alpha) / 255.0
    d_first = float(fgColor) * d_alpha
    d_second = float(bgColor) * (1.0 - d_alpha)
    return min(255, round(d_first + d_second))


def qtCssColor(color, bgcolor=None):
    """Converts the given color to the QT compatible one (transparency is not supported"""
    alpha = color.alpha()
    if alpha == 255:
        return color.name()

    if bgcolor is None:
        r_transp = transparentColor(color.red(), 255, alpha)
        g_transp = transparentColor(color.green(), 255, alpha)
        b_transp = transparentColor(color.blue(), 255, alpha)
    else:
        r_transp = transparentColor(color.red(), bgcolor.red(), alpha)
        g_transp = transparentColor(color.green(), bgcolor.green(), alpha)
        b_transp = transparentColor(color.blue(), bgcolor.blue(), alpha)
    return ''.join(('#', toHex(r_transp), toHex(g_transp), toHex(b_transp)))


def colorAsString(color, hexadecimal=False):
    """Converts the given color to a string"""
    if hexadecimal:
        return '#' + ''.join([toHex(color.red()),
                              toHex(color.green()),
                              toHex(color.blue()),
                              toHex(color.alpha())])
    return ','.join([str(color.red()),
                     str(color.green()),
                     str(color.blue()),
                     str(color.alpha())])


def buildFont(fontAsStr):
    """Converts saved font into QFont object"""
    fontAsStr = fontAsStr.strip()
    font = QFont()
    font.fromString(fontAsStr)
    return font


def fontAsString(font):
    """Converts a font to a string"""
    return font.toString()


excludeFontList = ['webdings', 'cursor', 'mathematical', 'dingbats', 'hershey']


def isExcludeFont(family):
    """True if the font needs to be excluded"""
    lowerfamily = family.lower()
    for exclusion in excludeFontList:
        if exclusion in lowerfamily:
            return True
    return False


def getFontList(fontType):
    """Provides a list of certain type fonts"""
    result = []
    combo = QFontComboBox()
    combo.setFontFilters(fontType)
    for index in range(combo.count()):
        family = str(combo.itemText(index))
        if not isExcludeFont(family):
            result.append(family)
    return result


def getMonospaceFontList():
    """Provides a list of strings with the system installed monospace fonts"""
    return getFontList(QFontComboBox.MonospacedFonts)


def getScalableFontList():
    """Provides a list of scalable fonts"""
    return getFontList(QFontComboBox.ScalableFonts)


def getProportionalFontList():
    """Provides a list of proportional fonts"""
    return getFontList(QFontComboBox.ProportionalFonts)


def colorFontToJSON(pythonobj):
    """Custom serialization"""
    if isinstance(pythonobj, QColor):
        return colorAsString(pythonobj)
    if isinstance(pythonobj, QFont):
        return fontAsString(pythonobj)
    raise TypeError(repr(pythonobj) + ' is not JSON serializable')


def colorFontFromJSON(jsonObj):
    """Custom deserialization"""
    if '__class__' in jsonObj:
        if jsonObj['__class__'] == 'QColor':
            return buildColor(jsonObj['__value__'])
        if jsonObj['__class__'] == 'QFont':
            return buildFont(jsonObj['__value__'])
    return jsonObj


def getZoomedMonoFont():
    """Provides the current mono font respecting zoom"""
    font = QFont(get_app().skin['monoFont'])
    font.setPointSize(font.pointSize() + 0)
    return font


def setLineEditBackground(widget, color, bgcolor=None):
    """Sets the widget background to the given color"""
    widget.setStyleSheet('QLineEdit {background-color: ' +
                         qtCssColor(color, bgcolor) + '}')
