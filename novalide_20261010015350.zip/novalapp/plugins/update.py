# -*- coding: utf-8 -*-
import sys
import os
import subprocess
import getpass
import shutil
from ..lib.pyqt import QMessageBox
from ..util import apputils, utils, ui_utils, transfer, fileutils
from .. plugin import iface, plugin
from .. import menuitems
from ..executable import Executable
from ..api.api import ApiServer
from .. import get_app, _
from ..api.errors import OK, HAVE_APP_UPDATE


def update_app(app_version):
    download_url = '%s/member/download_app' % (ApiServer.HOST_SERVER_ADDR)
    payload = {
        "new_version": app_version,
        "lang": get_app().locale.GetLanguageCanonicalName(),
        "os_name": sys.platform
    }
    # 下载程序文件
    file_downloader = transfer.FiledownloadSerivce()
    file_downloader.download_file(
        download_url,
        call_back=Install,
        parent=get_app().MainFrame.GetNotebook(),
        **payload
    )


def request_app_update_data():
    api = ApiServer()
    app_version = apputils.get_app_version()
    # 检查更新app时需要向服务器传递本地版本是否是开发版本的参数
    # 如果是开发版本,则在本地版本和服务器版本号一致时仍需要提示更新,否则不提示更新
    param = {
        'app_version': app_version,
        'is_dev': int(utils.is_dev())
    }
    data = api.request_api(
        'update/app',
        arg=param
    )
    return data


def check_app_update():
    data = request_app_update_data()
    if data is None:
        ui_utils.failed_connect_api_server()
        return
    check_app_updateinfo(data)


def check_new_version(data):
    code = data['code']
    if code == HAVE_APP_UPDATE:
        new_version = data['new_version']
        ret = QMessageBox.question(
            get_app().GetTopWindow(),
            _("Update available"),
            _("this latest version '%s' is available,do you want to download and update it?") % new_version
        )
        if ret == QMessageBox.Yes:
            update_app(new_version)


def check_app_updateinfo(data):
    # no update
    code = data['code']
    if code == OK:
        QMessageBox.information(get_app().GetTopWindow(), get_app(
        ).GetAppName(), _("this is the latest version"))
    # have update
    elif code == HAVE_APP_UPDATE:
        check_new_version(data)
    # other error
    else:
        QMessageBox.critical(get_app().GetTopWindow(),
                             get_app().GetAppName(), data['message'])


def Install(app_path, parent):
    if utils.is_windows():
        try:
            os.startfile(app_path)
        except OSError:
            return
    else:
        path = os.path.dirname(sys.executable)
        pip_path = os.path.join(path, "pip")
        cmd = "%s  -c \"from distutils.sysconfig import get_python_lib; print get_python_lib()\"" % (sys.executable,)
        python_lib_path = Executable(pip_path).exec_command_output(cmd)
        user = getpass.getuser()
        should_root = not fileutils.is_writable(python_lib_path, user)
        if should_root:
            cmd = "pkexec " + "%s install %s" % (pip_path, app_path)
        else:
            cmd = "%s install %s" % (pip_path, app_path)
        subprocess.call(cmd, shell=True)
        app_startup_path = shutil.which("NovalIDE")
        # wait a moment to avoid single instance limit
        subprocess.Popen("/bin/sleep 2;%s" % app_startup_path, shell=True)
    get_app().on_exit()


class UpdateLoader(plugin.Plugin):
    plugin.Implements(iface.CommonPluginI)

    def load(self):
        get_app().insert_command(
            menuitems.ID_GOTO_OFFICIAL_WEB,
            menuitems.ID_CHECK_UPDATE,
            _("&Help"),
            _("&Check for updates"),
            handler=self.check_update
        )

    def check_update(self):
        check_app_update()
