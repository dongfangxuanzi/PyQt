# -*- coding: utf-8 -*-
import os
import shutil
from typing import Optional
import uuid
from ..util import filewatcher, utils, fileutils, strutils
from . import command as projectcommand
from .resolver import model as projectmodel
from .resolver import resolver as projectlib
from .resolver.const import PROJECT_VERSION_191025
from ..lib.pyqt import QMessageBox
from . import ext
from .. import constants, globalkeys
from ..util.exceptions import InvalidRunableProjectError
from .. import get_app, _
from ..lib.document import Document
from ..lib.docmanager import DOC_SILENT, DOC_OPEN_ONCE

PROJECT_KEY = "/NOV_Projects"


class ProjectDocument(Document):
    UNPROJECT_MODEL_ID = "8F470CCF-A44F-11E8-88DC-005056C00008"
    # 禁止加入到项目的一些文件后缀类型,也是清理项目时删除的文件类型
    BAN_FILE_EXTS = []

    def __init__(self, model=None):
        super().__init__()
        if model:
            self.SetModel(model)
        else:
            # initial model used by "File | New... | Project"
            self.SetModel(self.GetProjectModel())
        self._stageProjectFile = False
        self._run_parameter = None
        self.document_watcher = filewatcher.FileAlarmWatcher()
        self._commandProcessor = projectcommand.CommandProcessor()
        self._debugger = None
        self._is_version_update = False

    def __copy__(self):
        model = copy.copy(self.GetModel())
        clone = ProjectDocument(model)
        clone.SetFilename(self.GetFilename())
        return clone

    @staticmethod
    def GetProjectModel():
        return projectmodel.Project()

    @classmethod
    def GetUnProjectDocument(cls, extension=ext.COMMON_PROJECT_EXTENSION):
        unproj_model = cls.GetProjectModel()
        unproj_model.Id = ProjectDocument.UNPROJECT_MODEL_ID
        unproj_proj = cls(model=unproj_model)
        project_template = get_app().GetDocumentManager().FindTemplateForTestPath(extension)
        unproj_proj.SetDocumentTemplate(project_template)
        unproj_proj.SetFilename(constants.NOT_IN_ANY_PROJECT)
        unproj_proj.SetDebugger(get_app().GetDebugger())
        return unproj_proj

    @classmethod
    def GetUnProjectFileKey(cls, file_path, lastPart):
        unproj_proj = cls.GetUnProjectDocument()
        unproj_proj.AddFile(file_path)
        return unproj_proj.GetFileKey(file_path, lastPart)

    def PromptToSaveFiles(self):
        def save_docs():
            for modify_doc in modify_docs:
                modify_doc.Save()

        files_modified = False
        modify_docs = []
        docs = get_app().GetDocumentManager().GetDocuments()
        for doc in docs:
            if doc.IsModified() and (self == get_app().MainFrame.projectview.FindProjectFromMapping(doc) or
                                     self.GetModel().FindFile(doc.GetFilename())):
                files_modified = True
                modify_docs.append(doc)
        if files_modified:
            if utils.profile_get_int(globalkeys.SAVEPROJECT_PROMPT_KEY, True):
                yes_no_msg = QMessageBox.question(
                    get_app().MainFrame.projectview,
                    _("Run project"),
                    _("Files have been modified.\nWould you like to save all files before running?"),
                    QMessageBox.Yes | QMessageBox.No
                )
                if yes_no_msg == QMessageBox.Yes:
                    save_docs()
            else:
                save_docs()

    def Debug(self):
        raise InvalidRunableProjectError(self.GetFilename())

    def Run(self, filetoRun=None):
        raise InvalidRunableProjectError(self.GetFilename())

    def GetDebugger(self):
        return self._debugger

    def SetDebugger(self, debugger):
        self._debugger = debugger

    def GetRunConfiguration(self, start_up_file):
        file_key = self.GetFileKey(start_up_file)
        run_configuration_name = utils.ProfileGet(
            file_key + "/RunConfigurationName", "")
        return run_configuration_name

    def GetFirstView(self):
        """
        Bug: workaround. If user tries to open an already open project with main menu "File |
        Open...", docview.DocManager.OnFileOpen() silently returns None if project is already open.
        And to the user, it appears as if nothing has happened. The user expects to see the
        open project.
        This forces the project view to show the correct project.
        """
        view = Document.GetFirstView(self)
        # ensure project is displayed in view
        view.SetProject(self.GetFilename())
        return view

    def GetModel(self):
        return self._projectModel

    def GetPath(self):
        return os.path.dirname(self.GetFilename())

    def is_project_docfile(self, filepath):
        return fileutils.ComparePath(filepath, self.GetFilename())

    def SetModel(self, model):
        self._projectModel = model

    def GetKey(self, lastPart=None):
        if not lastPart:
            return "%s/{%s}" % (PROJECT_KEY, self.GetModel().Id)
        return "%s/{%s}/%s" % (PROJECT_KEY, self.GetModel().Id, lastPart)

    def get_value(self, key, value=""):
        return utils.profile_get(self.GetKey(key), value)

    def get_int(self, key, value=-1):
        return utils.profile_get_int(self.GetKey(key), value)

    def set_value(self, key, value):
        utils.profile_set(self.GetKey(key), value)

    def GetFileKey(self, pj_file, lastPart=None):
        filename = pj_file
        if isinstance(pj_file, str):
            pj_file = self.GetModel().FindFile(pj_file)
        # 文件已经不存在与项目中,返回项目的key路径
        if pj_file is None:
            utils.get_logger().error('file %s is not in project', filename)
            return "%s/{%s}" % (PROJECT_KEY, self.GetModel().Id)

        if pj_file.logicalFolder is None:
            key_path = os.path.basename(pj_file.filePath)
        else:
            key_path = os.path.join(
                pj_file.logicalFolder, os.path.basename(pj_file.filePath))
        key_path = fileutils.opj(key_path)
        if lastPart is None:
            return "%s/{%s}/%s" % (PROJECT_KEY, self.GetModel().Id, key_path.replace(os.sep, '|'))
        return "%s/{%s}/%s/%s" % (PROJECT_KEY, self.GetModel().Id, key_path.replace(os.sep, '|'), lastPart)

    def on_create(self, path, flags):
        view = get_app().MainFrame.projectview.GetView()
        # All project documents share the same view.
        # 所有项目共用一个视图对象
        self.AddView(view)
        return view

    def LoadObject(self, file):
        self.SetModel(projectlib.load(file))
        if self.GetModel().version != PROJECT_VERSION_191025:
            if utils.profile_get_int("PromptProjectAnalyzerDeprecated", True):
                messagebox.showwarning(
                    _("Warning"), _("Project analyzer version '%s' is deprecated,will update to latest verion '%s'") %
                    (self.GetModel().version, PROJECT_VERSION_191025))
            self.GetModel().version = PROJECT_VERSION_191025
            self._is_version_update = True
        return True

    def CleanProject(self):
        self.Cleandir(self.GetPath(), self.BAN_FILE_EXTS)

    def Cleandir(self, path, filters: Optional[list]=None):
        '''
        清理目录下的所有文件或者带某些后缀的文件
        如果后缀列表为空,表示清理目录下的所有文件
        '''
        filters = filters or []
        for root, path, files in os.walk(path):
            for filename in files:
                fullpath = os.path.join(root, filename)
                removed = False
                if not filters:
                    removed = True
                else:
                    ext = strutils.get_file_extension(fullpath)
                    # 清理项目的二进制文件,包括pyc,pyo等后缀文件
                    if ext in filters:
                        removed = True
                if removed:
                    self.Cleanfile(fullpath)

    def Cleanfile(self, filepath):
        get_app().GetTopWindow().PushStatusText(_("Cleaning \"%s\".") % filepath)
        fileutils.safe_remove(filepath)

    def SaveObject(self, file):
        projectlib.save(file, self.GetModel())
        return True

    def OnOpenDocument(self, filename):
        get_app().MainFrame.activateProjectTab()
        view = get_app().MainFrame.projectview.GetView()
        if not os.path.exists(filename):
            get_app().close_splash()
            msgtitle = get_app().GetAppName()
            if not msgtitle:
                msgtitle = _("File Error")
            QMessageBox.warning(
                get_app().GetTopWindow(),
                msgtitle,
                _("Could not find '%s'.") % filename
            )
            if self in self.GetDocumentManager().GetDocuments():
                self.Destroy()
            # if we return False, the Project View is destroyed, Service windows shouldn't be
            # destroyed.
            return True
        get_app().GetTopWindow().PushStatusText(_("Loading project \"%s\".") % filename)
        if not self.load(filename):
            # if we return False, the Project View is destroyed, Service windows shouldn't be
            # destroyed.
            utils.get_logger().error('load project file `%s` error', filename)
            return True
        self.SetFilename(filename, True)
        view.AddProjectToView(self)
        view.Activate()
        self.document_watcher.AddFileDoc(self)
        get_app().GetTopWindow().showStatusBarMessage(
            _("Load project \"%s\" success.") % filename)
        return True

    def reload(self):
        filename = self.GetFilename()
        get_app().GetTopWindow().PushStatusText(_("Reloading project \"%s\".") % filename)
        load_result = self.load(filename)
        if not load_result:
            utils.get_logger().error('load project file `%s` error', filename)
            return False
        self.GetFirstView().ProjectSelect()
        get_app().GetTopWindow().showStatusBarMessage(
            _("Reloading project \"%s\" success.") % filename)
        return load_result

    def load(self, filename):
        file_object = open(filename, 'r')
        try:
            self.LoadObject(file_object)
            file_object.close()
        except Exception as e:
            utils.get_logger().exception('')
            get_app().close_splash()
            msgtitle = get_app().GetAppName()
            if not msgtitle:
                msgtitle = _("File Error")
            QMessageBox.critical(
                get_app().MainFrame.projectview,
                msgtitle,
                _("Could not open '%s'.  %s") % (
                    fileutils.get_filename_from_path(filename), e)
            )
            if self in self.GetDocumentManager().GetDocuments():
                self.Destroy()
            get_app().GetTopWindow().PushStatusText(
                _("Load project \"%s\" fail.") % filename)
            file_object.close()
            return False
        project_obj = self.GetModel()
        # to make compatible to old version,which old project instance has no id attr
        if project_obj.id == '':
            project_obj.id = str(uuid.uuid1()).upper()
            self._is_version_update = True
        if self._is_version_update:
            self.Modify(True)
        else:
            self.Modify(False)
        self.SetDocumentModificationDate()
        self.UpdateAllViews()
        self._saved_yet = True
        return True

    def convert_to(self, project_obj, filepath):
        '''
        将当前项目转换为其它项目
        '''
        utils.get_logger().warning(
            'default project template %s is not same to the template %s assigned in project file,reload project again',
            self.GetDocumentTemplate().__class__,
            project_obj._runinfo.DocumentTemplate
        )
        # 先删除原有的文档
        if self in self.GetDocumentManager().GetDocuments():
            self.Destroy()
            if self in self.GetFirstView().Documents:
                self.GetFirstView().RemoveDocumentUpdate(self)
        project_document_template_class = utils.get_class_from_dynamicimport_module(
            project_obj._runinfo.DocumentTemplate)
        # 用新模板创建文档
        todoc = get_app().GetDocumentManager().CreateTemplateDocument(
            project_document_template_class.CreateProjectTemplate(),
            filepath,
            DOC_SILENT | DOC_OPEN_ONCE
        )
        return todoc

    def need_convert_to(self, project_obj):
        '''
        当前项目模板是否需要转换为其它项目模板
        依据是项目文件里面的项目模板信息
        '''
        # 没有找到项目模板配置信息,不需要转换
        if project_obj._runinfo.DocumentTemplate is None:
            return False
        try:
            project_document_template_class = utils.get_class_from_dynamicimport_module(
                project_obj._runinfo.DocumentTemplate)
        except (ModuleNotFoundError, ImportError) as ex:
            utils.get_logger().error(
                "dynamic import template %s error:%s in project file %s",
                project_obj._runinfo.DocumentTemplate,
                ex,
                self.GetFilename()
            )
            return False
        utils.get_logger().info(
            'project document class is %s, document template class is %s',
            project_document_template_class,
            self.GetDocumentTemplate().__class__
        )
        return project_document_template_class != self.GetDocumentTemplate().__class__

    def OnSaveDocument(self, filename):
        self.document_watcher.StopWatchFile(self)
        suc = Document.OnSaveDocument(self, filename)
        self.document_watcher.StartWatchFile(self)
        return suc

    def AddFile(self, filepath, folderpath=None, type=None, name=None):
        if type:
            types = [type]
        else:
            types = None
        if name:
            names = [name]
        else:
            names = None

        return self.AddFiles([filepath], folderpath, types, names)

    def AddFiles(
        self,
        filepaths=None,
        folderpath=None,
        types=None,
        names=None,
        files=None
    ):
        # Filter out files that are not already in the project
        if filepaths:
            new_file_paths = []
            old_file_paths = []
            for filepath in filepaths:
                if self.GetModel().FindFile(filepath):
                    old_file_paths.append(filepath)
                else:
                    new_file_paths.append(filepath)

            for i, filepath in enumerate(new_file_paths):
                if types:
                    type = types[i]
                else:
                    type = None
                if names:
                    name = names[i]
                else:
                    name = None
                if not folderpath:
                    folder = None
                else:
                    folder = folderpath
                self.GetModel().AddFile(filepath, folder, type, name)
        elif files:
            new_file_paths = []
            old_file_paths = []
            for file in files:
                if self.GetModel().FindFile(file.filePath):
                    old_file_paths.append(file.filePath)
                else:
                    new_file_paths.append(file.filePath)
                    self.GetModel().AddFile(file=file)
        else:
            return False

        self.UpdateAllViews(
            hint=(
                constants.PROJECT_ADD_COMMAND_NAME,
                self,
                new_file_paths,
                old_file_paths
            )
        )
        if new_file_paths:
            self.Modify(True)
            return True
        return False

    def add_progress_files(
        self,
        progress_ui,
        progress_que,
        filepaths=None,
        folderpath=None,
        types=None,
        names=None,
        range_value=0
    ):
        # Filter out files that are not already in the project
        if filepaths:
            new_filepaths = []
            old_filepaths = []
            for filepath in filepaths:
                if self.GetModel().FindFile(filepath):
                    old_filepaths.append(filepath)
                    range_value += 1
                else:
                    new_filepaths.append(filepath)
            for i, filepath in enumerate(new_filepaths):
                if types:
                    type = types[i]
                else:
                    type = None
                if names:
                    name = names[i]
                else:
                    name = None
                if not folderpath:
                    folder = None
                else:
                    folder = folderpath
                self.GetModel().AddFile(filepath, folder, type, name)
        else:
            return False
        self.UpdateAllViews(hint=(constants.PROJECT_ADD_PROGRESS_COMMAND_NAME,
                            self, new_filepaths, range_value, progress_ui, progress_que))
        if new_filepaths:
            self.Modify(True)
            return True
        return False

    def RemoveFile(self, filepath):
        return self.RemoveFiles([filepath])

    def RemoveFiles(self, filepaths=None, files=None):
        removed_files = []
        if files:
            filepaths = []
            for file in files:
                filepaths.append(file.filePath)

        for filepath in filepaths:
            file = self.GetModel().FindFile(filepath)
            if file:
                self.GetModel().RemoveFile(file)
                removed_files.append(file.filePath)
        self.UpdateAllViews(hint=(constants.PROJECT_REMOVE_COMMAND_NAME, self, removed_files))
        if removed_files:
            self.Modify(True)
            return True
        return False

    def RenameFile(self, old_filepath, new_filepath, isproject=False):
        try:
            if old_filepath == new_filepath:
                return False
            opendoc = None
            # projects don't have to exist yet, so not required to rename old file,
            # but files must exist, so we'll try to rename and allow exceptions to occur if can't.
            if not isproject or (isproject and os.path.exists(old_filepath)):
                opendoc = self.GetFirstView().GetOpenDocument(old_filepath)
                if opendoc:
                    opendoc.FileWatcher.StopWatchFile(opendoc)
                os.rename(old_filepath, new_filepath)
            if isproject:
                documents = self.GetDocumentManager().GetDocuments()
                for document in documents:
                    # If the renamed document is open, update it
                    if os.path.normcase(document.GetFilename()) == os.path.normcase(old_filepath):
                        document.SetFilename(new_filepath)
                        document.SetTitle(
                            wx.lib.docview.FileNameFromPath(new_filepath))
                        document.UpdateAllViews(
                            hint=("rename", self, old_filepath, new_filepath))
            else:
                self.UpdateFilePath(old_filepath, new_filepath)
                if opendoc:
                    opendoc.SetFilename(new_filepath, notify_views=True)
                    opendoc.UpdateAllViews(
                        hint=("rename", self, old_filepath, new_filepath))
                    opendoc.FileWatcher.StartWatchFile(opendoc)
                    get_app().MainFrame.outlineview.LoadOutLine(
                        opendoc.GetFirstView(),
                        force_reload=True
                    )
                    get_app().MainFrame.GetNotebook().updateStatusBar()
            return True
        except OSError as e:
            QMessageBox.critical(
                get_app().GetTopWindow(),
                _("Rename file error"),
                _("Could not rename file '%s'.  '%s'") % (
                    fileutils.get_filename_from_path(old_filepath), e),
            )
            return False

    def MoveFile(self, file, new_folderpath):
        return self.MoveFiles([file], new_folderpath)

    def MoveFiles(self, files, new_folderpath):
        filepaths = []
        new_filepaths = []
        move_files = []
        is_array = isinstance(new_folderpath, type([]))
        for i in range(len(files)):
            if is_array:
                files[i].logicalFolder = new_folderpath[i]
            else:
                files[i].logicalFolder = new_folderpath
            old_filepath = files[i].filePath
            filename = os.path.basename(old_filepath)
            if is_array:
                dest_folderpath = new_folderpath[i]
            else:
                dest_folderpath = new_folderpath
            new_filepath = os.path.join(self.GetModel().homeDir,
                                        dest_folderpath, filename)
            # this is the same file,which will ignore
            if fileutils.ComparePath(old_filepath, new_filepath):
                QMessageBox.information(
                    self.GetFirstView().GetFrame(),
                    _("Move File"),
                    _('The source file name is the same as the destination file name')
                )
                continue
            if os.path.exists(new_filepath):
                ret = QMessageBox.question(
                    self.GetFirstView().GetFrame(),
                    _("Move File"),
                    _("Dest file is already exist,Do you want to overwrite it?"),
                )
                if ret == QMessageBox.No:
                    continue
            new_dir_path = os.path.dirname(new_filepath)
            fileutils.makedirs(new_dir_path)
            try:
                if os.path.exists(old_filepath):
                    shutil.move(old_filepath, new_filepath)
            except OSError as e:
                QMessageBox.critical(self.GetFirstView().GetFrame(), _('Error'), str(e))
                return False
            filepaths.append(old_filepath)
            new_filepaths.append(new_filepath)
            move_files.append(files[i])

        self.UpdateAllViews(hint=(constants.PROJECT_REMOVE_COMMAND_NAME, self, filepaths))
        for k in range(len(move_files)):
            move_files[k].filePath = new_filepaths[k]
        self.UpdateAllViews(hint=(constants.PROJECT_ADD_COMMAND_NAME, self, new_filepaths, []))
        self.Modify(True)
        return True

    def UpdateFilePath(self, old_filepath, new_filepath):
        file = self.GetModel().FindFile(old_filepath)
        self.RemoveFile(old_filepath)
        if file:
            self.AddFile(new_filepath, file.logicalFolder,
                         file.type, file.name)
        else:
            self.AddFile(new_filepath)

    def RemoveInvalidPaths(self):
        """
        Makes sure all paths project knows about are valid and point to existing files. Removes
        and returns list of invalid paths.
        """

        invalid_file_refs = [
        ]

        file_refs = self.GetFileRefs()

        for file_ref in file_refs:
            if not os.path.exists(file_ref.filePath):
                invalid_file_refs.append(file_ref)

        for file_ref in invalid_file_refs:
            file_refs.remove(file_ref)

        return [file_ref.filePath for file_ref in invalid_file_refs]

    def archive_project(self, zipdest):
        """
        Zips stagedir, creates a zipfile that has as name the projectname, in zipdest. Returns
        path to zipfile.
        """
        if os.path.exists(zipdest):
            raise AssertionError(
                "Cannot archive project, %s already exists" % zipdest)

        filepaths = self.GetModel().filePaths
        new_filepaths = [self.GetFilename()]
        for filepath in filepaths:
            # 去除空文件夹下生成的虚拟文件
            if os.path.exists(filepath) and os.path.isfile(filepath):
                new_filepaths.append(filepath)
        # 指定basedir则打包到压缩包的文件路径为相对路径,否则打包到压缩包的文件路径为绝对路径
        fileutils.zip_to(zipdest, basedir=self.GetPath(), files=new_filepaths)
        return zipdest

    def RenameFolder(self, old_folder_logicpath, new_folder_logicpath):
        try:
            old_folderpath = os.path.join(
                self.GetModel().homeDir, old_folder_logicpath)
            new_folderpath = os.path.join(
                self.GetModel().homeDir, new_folder_logicpath)
            # 目的文件夹如果存在不要重命名了,直接更改文件夹item路径
            if not os.path.exists(new_folderpath):
                os.rename(old_folderpath, new_folderpath)
        except OSError as e:
            messagebox.showerror(_("Rename Folder Error"), _("Could not rename folder '%s'.  '%s'") % (
                fileutils.get_filename_from_path(old_folderpath), e), parent=GetApp().GetTopWindow())
            return False
        rename_files = []
        for file in self.GetModel()._files:
            if file.logicalFolder == old_folder_logicpath:
                file.logicalFolder = new_folder_logicpath
                old_filepath = file.filePath
                file_name = os.path.basename(old_filepath)
                new_filepath = os.path.join(new_folderpath, file_name)
                rename_files.append((old_filepath, new_filepath))
        for rename_file in rename_files:
            old_filepath, new_filepath = rename_file
            self.UpdateFilePath(old_filepath, new_filepath)
            opendoc = self.GetFirstView().GetOpenDocument(old_filepath)
            if opendoc:
                opendoc.SetFilename(new_filepath, notify_views=True)
                opendoc.UpdateAllViews(
                    hint=("rename", self, old_filepath, new_filepath))
                opendoc.FileWatcher.RemoveFile(old_filepath)
                opendoc.FileWatcher.StartWatchFile(opendoc)
        self.UpdateAllViews(hint=("rename folder", self,
                            old_folder_logicpath, new_folder_logicpath))
        self.Modify(True)
        return True

    def GetFiles(self):
        return self.GetModel().filePaths

    def GetStartupFile(self):
        return self.GetModel().StartupFile

    def GetFileRefs(self):
        return self.GetModel().findAllRefs()

    def SetFileRefs(self, file_refs):
        return self.GetModel().setRefs(file_refs)

    def IsFileInProject(self, filename):
        return self.GetModel().FindFile(filename)

    def GetAppInfo(self):
        return self.GetModel().GetAppInfo()

    def GetAppDocMgr(self):
        return self.GetModel()

    def GetProjectName(self):
        return os.path.splitext(os.path.basename(self.GetFilename()))[0]

    def GetCommandProcessor(self):
        """
        Returns the command processor associated with this document.
        """
        return self._commandProcessor

    def SetCommandProcessor(self, processor):
        """
        Sets the command processor to be used for this document. The document
        will then be responsible for its deletion. Normally you should not
        call this; override OnCreateCommandProcessor instead.
        """
        self._commandProcessor = processor

    def GetRunconfigClass(self):
        '''
        获取项目的运行配置类,是项目文件的_runinfo下面的RunConfig值
        '''
        run_config_name = self.GetDocumentTemplate().GetRunconfigClass()
        if not run_config_name:
            raise RuntimeError(_("We don't know how to run the program"))
        return utils.get_class_from_dynamicimport_module(run_config_name)

    def get_doc_cache_path(self):
        app_cache_path = utils.get_cache_path()
        doc_model = self.GetModel()
        pj_id = doc_model.id.lower()
        doc_cache_path = os.path.join(app_cache_path, pj_id)
        utils.get_logger().debug('project %s data cache path is %s',
                                 doc_model.name, doc_cache_path)
        return doc_cache_path

    def _ValidateFilePaths(self, projectdir, stagedir):
        """
        If paths validate, returns a dict mapping ProjectFile to destination path. Destination
        path is the path the file needs to be copied to for staging. If paths don't validate,
        throws an IOError.
        With our current slightly simplistic staging algorithm, staging will not work iff the
        project has files outside of the projectdir with names (filename without path) that:.
        -  match filenames of files living at the root of the project.
        -  are same as those of any other file that lives outside of the projectdir.
        We have this limitation because we move any file that lives outside of the project dir
        into the root of the stagedir (== copied project dir). We could make this smarter by
        either giving files unique names if we detect a collistion, or by creating some directory
        structure instead of putting all files from outside of the projectdir into the root of
        the stagedir (== copied projectdir).
        """

        # ProjectFile instance -> dest path (string)
        rtn = {}

        project_root_files = sets.Set()   # live at project root
        foreign_files = sets.Set()       # live outside of project

        file_refs_to_deploy = self.GetFileRefs()

        for fileref in file_refs_to_deploy:
            relpath = fileutils.getRelativePath(fileref.filePath, projectdir)
            filename = os.path.basename(fileref.filePath)
            if not relpath:  # file lives outside of project dir...

                # do we have another file with the same name already?
                if filename in foreign_files:
                    raise IOError(
                        "More than one file with name \"%s\" lives outside of the project. These files need to have unique names" %
                        filename)
                foreign_files.add(filename)
                filedest = os.path.join(stagedir, filename)
            else:
                # file lives somewhere within the project dir
                filedest = os.path.join(stagedir, relpath)
                if not os.path.dirname(relpath):
                    project_root_files.add(filename)

            rtn[fileref] = filedest

        # make sure we won't collide with a file that lives at root of
        # projectdir when moving files into project
        for filename in foreign_files:
            if filename in project_root_files:
                raise IOError(
                    "File outside of project, \"%s\", cannot have same name as file at project root" % filename)
        return rtn
