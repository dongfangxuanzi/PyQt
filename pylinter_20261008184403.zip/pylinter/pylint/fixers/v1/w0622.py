'''
Name:        w0622.py
Purpose:     修复内建函数名重名
Author:      wukan
Created:     2026-06-20
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from ....node_scope import ScopeFinder
from ....multifixer import MultiOptionFixer
from ....pylint_fix import PylintFixer
from ....exceptions import InvalidOptionIndexError


class PylintW0622Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:变量名和内建函数名重名了
    '''

    def __init__(self):
        super().__init__('W0622', self.FixKind.SEMI_AUTOFIX)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Rename built-in name',
            descr='Please input new name',
            init_options=['Add underline before name', 'Add underline after name']
        )

    @staticmethod
    def get_redefine_varname(selection, varname):
        if selection == 1:
            return varname + "_"
        if not selection:
            return "_" + varname
        raise InvalidOptionIndexError('invalid option index')

    def get_default_valid_name(self, varname):
        self.get_selection()
        return self.get_redefine_varname(self.selection, varname)

    def fix_message(self, msg):
        res = re.search(
            r"Redefining built-in '(\w+)' \(redefined-builtin\)",
            msg.msg
        )
        builtin_name = res.groups()[0]
        node = self.find_msg_node(msg, use_column=True)
        if isinstance(node, nodes.ImportFrom):
            names = node_utils.get_import_names(node)
            if builtin_name not in names:
                return False
            node_scope = ScopeFinder.get_parent_scope(node)
            newname = node.modname + "." + builtin_name
            importname = node.modname.split('.')[0]
            self.replace_variable_name_in_scope(node_scope, builtin_name, newname)
            self.add_import_node(importname)
            self.delete_node(node)
        else:
            funcscope = ScopeFinder.get_function_scope(node)
            # 目前仅支持函数范围内的变量名更改替换
            if funcscope is None or not isinstance(node, nodes.AssignName):
                return False
            if builtin_name != node.name:
                return False
            default_name = self.get_default_valid_name(builtin_name)
            if self.fix_only_autofix():
                newname = default_name
            else:
                ok, newname = self.ask_input_string(
                    'Rename built-in name',
                    'Input new var name',
                    initialvalue=default_name
                )
                if not ok:
                    return False
            self.replace_variable_name_in_scope(funcscope, builtin_name, newname)
        return True


class PylintW0621Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明:局部变量名和全局变量名重名了
    '''

    def __init__(self):
        super().__init__('W0621', self.FixKind.SINGLEFIX)
        MultiOptionFixer.__init__(
            self,
            0,
            title='Rename outer scope name',
            descr='Please input new name',
            init_options=['Add underline before name', 'Add underline after name']
        )

    def get_default_valid_name(self, varname):
        self.get_selection()
        return PylintW0622Fixer.get_redefine_varname(self.selection, varname)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        funcscope = ScopeFinder.get_function_scope(node)
        # 目前仅支持函数范围内的变量名更改替换
        if funcscope is None or not isinstance(node, nodes.AssignName):
            return False
        res = re.search(
            r"Redefining name '(.*)' from outer scope \(line (\d+)\) \(redefined-outer-name\)",
            msg.msg
        )
        outer_scope_name, outer_name_line = res.groups()
        outer_name_line_text = self.get_line_text(int(outer_name_line) - 1)
        if outer_scope_name != node.name or outer_name_line_text.find(outer_scope_name) == -1:
            return False
        default_name = self.get_default_valid_name(outer_scope_name)
        if self.fix_only_autofix():
            newname = default_name
        else:
            ok, newname = self.ask_input_string(
                'Rename outer scope name',
                'Input new var name',
                initialvalue=default_name
            )
            if not ok:
                return False
        self.replace_variable_name_in_scope(funcscope, outer_scope_name, newname)
        return True
