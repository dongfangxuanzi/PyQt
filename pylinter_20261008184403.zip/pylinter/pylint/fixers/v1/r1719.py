'''
Name:        r1719.py
Purpose:
Author:      wukan
Created:     2026-05-16
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from .... import node_utils
from astroid import nodes
from ....pylint_fix import PylintFixer


class PylintR1719Fixer(PylintFixer):
    '''
    规则说明:if表达式返回bool值可以用test,not test,bool(test)代替
    '''

    def __init__(self):
        super().__init__('R1719', self.FixKind.AUTOFIX)

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        res = re.search(
            r"The if expression can be replaced with '(.*)' \(simplifiable-if-expression\)",
            msg.msg
        )
        if not node_utils.is_const_type(node, bool) or not isinstance(node.parent, nodes.IfExp):
            return False
        test_str = res.groups()[0]
        pnode = node.parent
        if node.value:
            if test_str == 'test':
                self.fix_node_text(pnode, pnode.test.as_string())
            elif test_str == 'bool(test)':
                infer_value = node_utils.safe_infer(pnode.test)
                if not node_utils.is_const_type(infer_value, bool):
                    self.fix_node_text(pnode, f'bool({pnode.test.as_string()})')
                else:
                    self.fix_node_text(pnode, pnode.test.as_string())
            return True
        if not node.value and test_str == 'not test':
            if isinstance(pnode.test, nodes.Name):
                self.fix_node_text(pnode, f'not {pnode.test.as_string()}')
            else:
                self.fix_node_text(pnode, f'not ({pnode.test.as_string()})')
            return True
        return False
