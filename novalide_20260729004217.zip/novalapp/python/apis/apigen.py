import pickle
from astroid import nodes
from ..parser.define import (
    CLASS_INIT_METHOD,
    CLASS_METHOD_NAME,
    STATIC_METHOD_NAME,
    PROPERTY_METHOD_NAME,
    SELF_ARG_NAME
)
from ..parser import objtypes, node_utils
from . import iconid
from . import memberkeys
from ...util import fileutils, strutils
from .member import ReferMember


class APIGenerator:
    """description of class"""

    def __init__(self, datapath, childs, module, modname):
        self._datapath = datapath
        self._childs = childs
        self._module = module
        self._modname = modname

    def gen_api(self, analyzer):
        api_filepath = analyzer.get_api_file(self._modname)
        with open(api_filepath, 'w') as f:
            for child_member in self._childs:
                name = child_member.modname
                nodetype = child_member.member_tpe
                node = child_member.node
                nodename = name.split('.')[-1]
                icon_id = iconid.get_icon_id(nodetype, nodename)
                if icon_id is not None:
                    api_name = "%s?%d" % (name, icon_id)
                else:
                    api_name = name
                # 函数参数提示信息
                if nodetype == objtypes.FUNCTION_DEF and node is not None:
                    api_name = "%s(%s)" % (api_name, node.args.as_string())
                # 如果是类,找到init方法的定义,作为参数提示信息
                elif nodetype == objtypes.CLASS_DEF and node is not None and \
                        isinstance(node, nodes.ClassDef):
                    for child in node.body:
                        # 类节点用init函数节点代替,这样输入类名时会提示构造函数信息
                        if isinstance(child, nodes.FunctionDef) and child.name == CLASS_INIT_METHOD:
                            api_name = "%s(%s)" % (
                                api_name, child.args.as_string())
                            break
                f.write(api_name)
                f.write('\n')

    def sort_childs(self):
        # 按模块名称排序,以便正确弹出代码提示内容
        self._childs.sort(key=lambda k: k.modname)

    def gen_members(self, analyzer, finished, isbuiltin=False):
        # 这里需要对子成员按名称排序,按python默认的排序函数即可,无需自己写排序函数
        self.sort_childs()
        members_file_name = analyzer.get_members_file(self._modname)
        with open(members_file_name, 'wb') as j:
            # Pickle dictionary.
            datas = []
            if isbuiltin:
                path = None
            else:
                path = self._module.file
            for child_member in self._childs:
                data = child_member.to_dict()
                nodetype = child_member.member_tpe
                node = child_member.node
                if nodetype == objtypes.MODULE:
                    assert isinstance(node, nodes.Module)
                    if not isbuiltin:
                        modpath = node.file
                        data.update({memberkeys.PATH_KEY_NAME: modpath})
                else:
                    root_path = node.root().file
                    # 节点原始定义在其它文件
                    if root_path is not None and path is not None and (
                        not fileutils.ComparePath(root_path, path)
                    ):
                        assert isinstance(child_member, ReferMember)
                        data.update({memberkeys.PATH_KEY_NAME: root_path})
                    if isinstance(child_member, ReferMember):
                        if not strutils.is_none_empty(child_member.path):
                            data.update({memberkeys.PATH_KEY_NAME: child_member.path})
                    if isinstance(node, nodes.FunctionDef):
                        func_member = self.gen_func_members(node)
                        data.update(func_member)
                    elif isinstance(node, nodes.ClassDef):
                        class_bases = self.gen_class_bases(node)
                        if class_bases:
                            data.update({memberkeys.BASES_KEY_NAME: class_bases})
                        class_member_datas = []
                        class_childs = child_member.childs
                        for class_child in class_childs:
                            member_data = class_child.to_dict()
                            if isinstance(class_child.node, nodes.FunctionDef):
                                class_method_members = self.gen_func_members(class_child.node)
                                member_data.update(class_method_members)
                            class_member_datas.append(member_data)
                        data[memberkeys.CHILD_KEY_NAME] = class_member_datas
                datas.append(data)
            module_doc = node_utils.get_node_doc(self._module)
            module_dct = {
                memberkeys.NAME_KEY_NAME: self._modname.split('.')[-1],
                memberkeys.MODNAME_KEY_NAME: self._modname,
                memberkeys.CHILD_KEY_NAME: datas,
                memberkeys.OBJTYPE_KEY_NAME: objtypes.MODULE
            }
            if path is not None:
                module_dct.update({memberkeys.PATH_KEY_NAME: path})
            if module_doc is not None:
                module_dct.update({memberkeys.DOC_KEY_NAME: module_doc})
            module_dct.update({'finished': finished})
            pickle.dump(module_dct, j)

    def gen_func_members(self, func_node):
        func_node_args = func_node.args.args
        args = [] if func_node_args is None else func_node_args
        func_data = {}
        func_args = []
        is_method = False
        if (
            isinstance(func_node.parent, nodes.ClassDef) and len(args) > 0
        ) and (
            isinstance(
                args[0], nodes.AssignName) and args[0].name == SELF_ARG_NAME
        ):
            is_method = True
        for arg in args:
            data = {}
            lineno, col_offset = node_utils.get_node_line_col(arg)
            data[memberkeys.LINE_KEY_NAME] = lineno
            data[memberkeys.COL_KEY_NAME] = col_offset
            data[memberkeys.NAME_KEY_NAME] = arg.as_string()
            func_args.append(data)
        func_data[memberkeys.ARGS_KEY_NAME] = func_args
        is_property_method = False
        is_class_method = False
        if func_node.decorators is not None:
            for deco in func_node.decorators.nodes:
                if isinstance(deco, nodes.Name):
                    # property装饰符
                    if deco.name == PROPERTY_METHOD_NAME:
                        is_property_method = True
                        break
                    # classmthod和staticmethod装饰符
                    if deco.name in (CLASS_METHOD_NAME, STATIC_METHOD_NAME):
                        is_class_method = True
                        break
        func_data['is_propertymethod'] = is_property_method
        func_data['is_classmethod'] = is_class_method
        func_data['is_method'] = is_method
        return func_data

    def gen_class_bases(self, node):
        bases = []
        for base in node.bases:
            bases.append({memberkeys.MODNAME_KEY_NAME: base})
        return bases
