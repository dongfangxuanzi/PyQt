# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        model.py
Purpose:
Author:      wukan
Created:     2019-02-15
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import copy
import os
import os.path
from . import xmlutils
from .const import PROJECT_NAMESPACE_URL, PROJECT_VERSION_191025
from ...util import fileutils, strutils
# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------
# Always add new versions, never edit the version number
# This allows you to upgrade the file by checking the version number

# ----------------------------------------------------------------------------
# Classes
# ----------------------------------------------------------------------------


class ProjectModel:
    __xmlname__ = "project"
    # _properties是12版本出现的元素,后面的版本去掉这个元素了
    __xmlexclude__ = ('fileName', '_projectDir', '_getDocCallback',
                      '_cacheEnabled', '_startupfile', '_properties')
    __xmlattributes__ = ("_homeDir", "version", "name", "id")
    __xmlrename__ = {"_homeDir": "homeDir", "_appInfo": "appInfo"}
    __xmlflattensequence__ = {"_files": ("file",)}
    __xmldefaultnamespace__ = xmlutils.AG_NS_URL
    __xmlattrnamespaces__ = {PROJECT_NAMESPACE_URL: ["version", "_homeDir"]}

    def __init__(self):
        self.__xmlnamespaces__ = {PROJECT_NAMESPACE_URL: xmlutils.AG_NS_URL}
        self.version = PROJECT_VERSION_191025
        self._files = []
        self._projectDir = None  # default for homeDir, set on load
        self._homeDir = None         # user set homeDir for use in calculating relative path
        self._cacheEnabled = 0
        self.name = ''
        self.id = ''
        self._startupfile = None
        self._runinfo = RunInfo(self)

    @property
    def runinfo(self):
        return self._runinfo

    @property
    def StartupFile(self):
        return self._startupfile

    @StartupFile.setter
    def StartupFile(self, startupfile):
        if self._startupfile is not None:
            self._startupfile.IsStartup = False
        self._startupfile = startupfile
        if self._startupfile is not None:
            self._startupfile.IsStartup = True
            # 设置启动文件
            self._runinfo.StartupFile = self.GetRelativePath(self._startupfile)

    @property
    def Id(self):
        return self.id

    @Id.setter
    def Id(self, project_id):
        self.id = project_id

    @property
    def Name(self):
        return self.name

    def __copy__(self):
        clone = Project()
        clone._files = [copy.copy(file) for file in self._files]
        clone._projectDir = self._projectDir
        clone._homeDir = self._homeDir
        if not ACTIVEGRID_BASE_IDE:
            clone._appInfo = copy.copy(self._appInfo)
        return clone

    @Name.setter
    def Name(self, name):
        self.name = name

    def initialize(self):
        for file in self._files:
            file._parentProj = self

    def GetAppInfo(self):
        return self._appInfo

    def AddFile(self, filepath=None, logical_folder=None, type=None, name=None, file=None):
        """
        Usage:
        # used for initial generation of object.
        self.AddFile(filePath, logicalFolder, type, name)
        self.AddFile(file=xyzFile)  # normally used for redo/undo
        Add newly created file object using filePath and logicalFolder or given file object
        """
        if file:
            self._files.append(file)
        else:
            self._files.append(
                ProjectFile(
                    self,
                    fileutils.opj(filepath),
                    logical_folder,
                    type,
                    name,
                    getDocCallback=None
                )
            )

    def RemoveFile(self, file):
        if file.IsStartup:
            self.StartupFile = None
        self._files.remove(file)

    def FindFile(self, filepath):
        if filepath:
            for file in self._files:
                if fileutils.ComparePath(file.filePath, filepath):
                    return file
        return None

    def find_files(self, dirpath):
        if not os.path.isdir(dirpath):
            return []
        files = []
        for file in self._files:
            if 0 == strutils.case_insensitive_compare(
                os.path.dirname(file.filePath), dirpath
            ):
                files.append(file)
        return files

    def GetRelativePath(self, pj_file):
        if isinstance(pj_file, ProjectFile):
            filepath = pj_file.filePath
        else:
            filepath = pj_file
        return filepath.replace(self.homeDir, "").lstrip(os.sep)

    def _GetFilePaths(self):
        return [file.filePath for file in self._files]

    filePaths = property(_GetFilePaths)

    def _GetProjectFiles(self):
        return self._files
    projectFiles = property(_GetProjectFiles)

    def _GetLogicalFolders(self):
        folders = []
        for file in self._files:
            if file.logicalFolder and file.logicalFolder not in folders:
                folders.append(file.logicalFolder)
        return folders

    logicalFolders = property(_GetLogicalFolders)

    def _GetPhysicalFolders(self):
        physical_folders = []
        for file in self._files:
            physical_folder = file.physicalFolder
            if physical_folder and physical_folder not in physical_folders:
                physical_folders.append(physical_folder)
        return physical_folders

    physicalFolders = property(_GetPhysicalFolders)

    def _GetHomeDir(self):
        if self._homeDir:
            return self._homeDir
        return self._projectDir

    def _SetHomeDir(self, parentpath):
        self._homeDir = parentpath

    def _IsDefaultHomeDir(self):
        return self._homeDir == None

    isDefaultHomeDir = property(_IsDefaultHomeDir)
    homeDir = property(_GetHomeDir, _SetHomeDir)

    def GetRelativeFolders(self):
        relative_folders = []
        for file in self._files:
            rel_folder = file.GetRelativeFolder(self.homeDir)
            if rel_folder and rel_folder not in relative_folders:
                relative_folders.append(rel_folder)
        return relative_folders

    def AbsToRelativePath(self):
        for file in self._files:
            file.AbsToRelativePath(self.homeDir)

    def RelativeToAbsPath(self):
        for file in self._files:
            file.RelativeToAbsPath(self.homeDir)

    def _SetCache(self, enable):
        """
        Only turn this on if your operation assumes files on disk won't change.
        Once your operation is done, turn this back off.
        Nested enables are allowed, only the last disable will disable the cache.
        This bypasses the IsDocumentModificationDateCorrect call because the modification
        date check is too costly, it hits the disk and takes too long.
        """
        if enable:
            if self._cacheEnabled == 0:
                # clear old cache, don't want to accidentally return stale value
                for file in self._files:
                    file.ClearCache()

            self._cacheEnabled += 1
        else:
            self._cacheEnabled -= 1

    def _GetCache(self):
        return self._cacheEnabled > 0

    cacheEnabled = property(_GetCache, _SetCache)
    # ----------------------------------------------------------------------------
    # BaseDocumentMgr methods
    # ----------------------------------------------------------------------------

    def fullPath(self, filename):
        if os.path.isabs(filename):
            abspath = filename
        elif self.homeDir:
            abspath = os.path.join(self.homeDir, filename)
        else:
            abspath = os.path.abspath(filename)
        return os.path.normpath(abspath)

    def documentRefFactory(self, name, fileType, filePath):
        return ProjectFile(self, filePath=self.fullPath(filePath), type=fileType, name=name, getDocCallback=self._getDocCallback)

    def findAllRefs(self):
        return self._files

    def GetXFormsDirectory(self):
        forms = self.findRefsByFileType(basedocmgr.FILE_TYPE_XFORM)
        file_paths = map(lambda form: form.filePath, forms)
        xformdir = os.path.commonprefix(file_paths)
        if not xformdir:
            xformdir = self.homeDir
        return xformdir

    def setRefs(self, files):
        self._files = files

    def findRefsByFileType(self, fileType):
        file_list = []
        for file in self._files:
            if fileType == file.type:
                file_list.append(file)
        return file_list

    def GenerateServiceRefPath(self, wsdlFilePath):
        # HACK: temporary solution to getting wsdlag path from wsdl path.
        import wx
        from WsdlAgEditor import WsdlAgDocument
        ext = WsdlAgDocument.WSDL_AG_EXT
        for template in wx.GetApp().GetDocumentManager().GetTemplates():
            if template.GetDocumentType() == WsdlAgDocument:
                ext = template.GetDefaultExtension()
                break
        wsdl_ag_file_path = os.path.splitext(wsdlFilePath)[0] + ext
        return wsdl_ag_file_path

    def SetDocCallback(self, getDocCallback):
        self._getDocCallback = getDocCallback
        for file in self._files:
            file._getDocCallback = getDocCallback


class Project(ProjectModel):
    pass


class ProjectFile:
    __xmlname__ = "file"
    __xmlexclude__ = ('_parentProj', '_getDocCallback', '_docCallbackCacheReturnValue',
                      '_docModelCallbackCacheReturnValue', '_doc', 'isStartup')
    __xmlattributes__ = ["filePath", "logicalFolder", "type", "name"]
    __xmldefaultnamespace__ = xmlutils.AG_NS_URL

    def __init__(
        self,
        parent=None,
        filepath=None,
        logicalFolder=None,
        type=None,
        name=None,
        getDocCallback=None
    ):
        self._parentProj = parent
        self.filePath = filepath
        self.logicalFolder = logicalFolder
        self.type = type
        self.name = name
        self._getDocCallback = getDocCallback
        self._docCallbackCacheReturnValue = None
        self._docModelCallbackCacheReturnValue = None
        self._doc = None
        self.isStartup = False

    @property
    def IsStartup(self):
        # 兼容老版本,老版本file格式为:
        # <noval:file filePath="./flows/meta/annotation.py" logicalFolder="flows/meta"
        # isStartup="false"/>.
        # 老版本的文件统统设置为非启动文件
        if isinstance(self.isStartup, str):
            return False
        return self.isStartup

    @IsStartup.setter
    def IsStartup(self, is_startup):
        self.isStartup = is_startup

    def _GetDocumentModel(self):
        if (self._docCallbackCacheReturnValue
                and (self._parentProj.cacheEnabled or self._docCallbackCacheReturnValue.IsDocumentModificationDateCorrect())):
            return self._docModelCallbackCacheReturnValue

        if self._getDocCallback:
            self._docCallbackCacheReturnValue, self._docModelCallbackCacheReturnValue = self._getDocCallback(
                self.filePath)
            return self._docModelCallbackCacheReturnValue

        return None

    document = property(_GetDocumentModel)

    def _GetDocument(self):
        # Return the IDE document wrapper that corresponds to the runtime document model
        if (self._docCallbackCacheReturnValue
                and (self._parentProj.cacheEnabled or self._docCallbackCacheReturnValue.IsDocumentModificationDateCorrect())):
            return self._docCallbackCacheReturnValue

        if self._getDocCallback:
            self._docCallbackCacheReturnValue, self._docModelCallbackCacheReturnValue = self._getDocCallback(
                self.filePath)
            return self._docCallbackCacheReturnValue

        return None

    ideDocument = property(_GetDocument)

    def ClearCache(self):
        self._docCallbackCacheReturnValue = None
        self._docModelCallbackCacheReturnValue = None

    def _typeEnumeration(self):
        return basedocmgr.FILE_TYPE_LIST

    def _GetPhysicalFolder(self):
        dir = None
        if self.filePath:
            dir = os.path.dirname(self.filePath)
            if os.sep != '/':
                dir = dir.replace(os.sep, '/')  # require '/' as delimiter
        return dir

    physicalFolder = property(_GetPhysicalFolder)

    def GetRelativeFolder(self, parentpath):
        parentpath_len = len(parentpath)
        dir = None
        if self.filePath:
            dir = os.path.dirname(self.filePath)
            if dir.startswith(parentpath + os.sep):
                dir = "." + dir[parentpath_len:]  # convert to relative path
            if os.sep != '/':
                # always save out with '/' as path separator for cross-platform compatibility.
                dir = dir.replace(os.sep, '/')
        return dir

    def AbsToRelativePath(self, parentpath):
        """Used to convert path to relative path for saving (disk format)"""
        parentpath_len = len(parentpath)

        if self.filePath.startswith(parentpath + os.sep):
            # convert to relative path
            self.filePath = "." + self.filePath[parentpath_len:]
            if os.sep != '/':
                # always save out with '/' as path separator for cross-platform compatibility.
                self.filePath = self.filePath.replace(os.sep, '/')
        else:
            pass    # not a decendant of project, use absolute path

    def RelativeToAbsPath(self, parentPath):
        """Used to convert path to absolute path (for any necessary disk access)"""
        if self.filePath.startswith("./"):  # relative to project file
            self.filePath = fileutils.opj(os.path.join(
                parentPath, self.filePath))  # also converts '/' to os.sep

    # ----------------------------------------------------------------------------
    # BaseDocumentMgr methods
    # ----------------------------------------------------------------------------

    def _GetDoc(self):
        # HACK: temporary solution.
        import wx
        import wx.lib.docview
        if not self._doc:
            doc_mgr = wx.GetApp().GetDocumentManager()

            try:
                doc = doc_mgr.CreateDocument(self.filePath, doc_mgr.GetFlags(
                ) | wx.lib.docview.DOC_SILENT | wx.lib.docview.DOC_OPEN_ONCE | wx.lib.docview.DOC_NO_VIEW)
                if doc is None:  # already open
                    docs = doc_mgr.GetDocuments()
                    for d in docs:
                        if d.GetFilename() == self.filePath:
                            doc = d
                            break
                self._doc = doc
            except Exception as e:
                logger.reportException(e, stacktrace=True)

        return self._doc

    def _GetLocalServiceProcessName(self):
        # HACK: temporary solution to getting process name from wsdlag file.
        doc = self._GetDoc()
        if doc:
            return doc.GetModel().processName
        return None

    processName = property(_GetLocalServiceProcessName)

    def _GetStateful(self):
        # HACK: temporary solution to getting stateful from wsdlag file.
        return self._GetDoc().GetModel().stateful

    def _SetStateful(self, stateful):
        # HACK: temporary solution to setting stateful from wsdlag file.
        self._GetDoc().GetModel().stateful = stateful

    stateful = property(_GetStateful, _SetStateful)

    def _GetLocalServiceCodeFile(self):
        # HACK: temporary solution to getting class name from wsdlag file.
        return self._GetDoc().GetModel().localServiceCodeFile

    def _SetLocalServiceCodeFile(self, codefile):
        # HACK: temporary solution to setting class name from wsdlag file.
        self._GetDoc().GetModel().localServiceCodeFile = codefile

    localServiceCodeFile = property(
        _GetLocalServiceCodeFile, _SetLocalServiceCodeFile)

    def _GetLocalServiceClassName(self):
        # HACK: temporary solution to getting class name from wsdlag file.
        return self._GetDoc().GetModel().localServiceClassName

    def _SetLocalServiceClassName(self, classname):
        # HACK: temporary solution to setting class name from wsdlag file.
        self._GetDoc().GetModel().localServiceClassName = classname

    localServiceClassName = property(
        _GetLocalServiceClassName, _SetLocalServiceClassName)

    def getServiceParameter(self, message, part):
        return self._GetDoc().GetModel().getServiceParameter(message, part)

    def _GetServiceRefServiceType(self):
        # HACK: temporary solution to getting service type from wsdlag file.
        doc = self._GetDoc()
        if not doc:
            return None
        model = doc.GetModel()
        if hasattr(model, 'serviceType'):
            return model.serviceType
        return None

    def _SetServiceRefServiceType(self, service_type):
        # HACK: temporary solution to getting service type from wsdlag file.
        self._GetDoc().GetModel().serviceType = service_type

    serviceType = property(_GetServiceRefServiceType,
                           _SetServiceRefServiceType)

    def getExternalPackage(self):
        # HACK: temporary solution to getting custom code filename from wsdlag file.
        from activegrid.model import projectmodel
        import wx
        import ProjectEditor

        app_info = self._GetDoc().GetAppInfo()

        if app_info.language is None:
            language = wx.ConfigBase_Get().Read(ProjectEditor.APP_LAST_LANGUAGE,
                                                projectmodel.LANGUAGE_DEFAULT)
        else:
            language = app_info.language

        if language == projectmodel.LANGUAGE_PYTHON:
            suffix = ".py"
        elif language == projectmodel.LANGUAGE_PHP:
            suffix = ".php"
        py_filename = self.name + suffix
        return self._GetDoc().GetAppDocMgr().fullPath(py_filename)


class RunInfo:
    # RunConfig是12版本出现的元素,后面的版本去掉这个元素了
    __xmlexclude__ = ('_parentProj', 'RunConfig')
    __xmlname__ = "runInfo"
    __xmldefaultnamespace__ = xmlutils.AG_NS_URL

    def __init__(self, parent=None):
        self._parentProj = parent
        self.StartupFile = None
        self.DocumentTemplate = None


# ----------------------------------------------------------------------------
# Old Classes
# ----------------------------------------------------------------------------

class Project_10:
    """
    Version 1.0, kept for upgrading to latest version.  Over time, this should be deprecated.
    """
    __xmlname__ = "project"
    __xmlrename__ = {"_files": "files"}
    __xmlexclude__ = ('fileName',)
    __xmlattributes__ = ["version"]

    def __init__(self):
        self.version = PROJECT_VERSION_050730
        self._files = []

    def initialize(self):
        """Required method for xmlmarshaller"""

    def upgradeVersion(self):
        curr_model = Project()
        for file in self._files:
            curr_model._files.append(ProjectFile(curr_model, file))
        return curr_model


# ----------------------------------------------------------------------------
# XML Marshalling Methods
# ----------------------------------------------------------------------------
# 项目xml文件已知节点类型名称列表
# 要想项目文件识别类型,必须添加到这个列表中,否则写入节点信息时会加上objtype="novalapp.project.resolver.model.RunInfo"等类似信息
# 这里是通用项目文件的已知节点类型,Python项目文件的已知节点类型会有增加
KNOWNTYPES = {"%s:project" % PROJECT_NAMESPACE_URL: Project,
              "%s:file" % PROJECT_NAMESPACE_URL: ProjectFile}
