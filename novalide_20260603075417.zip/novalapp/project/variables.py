# -*- coding: utf-8 -*-
import getpass
import sys
import re
import os
from .. import get_app, _
from ..util import ui_utils, utils
from ..util.cmp_func import py_sorted, cmp_name
from ..lib.pyqt import (
    QHBoxLayout,
    QLabel,
    QTableWidget,
    QPushButton,
    QMessageBox,
    QLineEdit,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView
)
from ..project.document import ProjectDocument

PROJECT_NAME_VARIABLE = "ProjectName"
PROJECT_PATH_VARIABLE = "ProjectPath"
PROJECT_DIR_VARIABLE = "ProjectDir"
PROJECT_FILENAME_VARIABLE = "ProjectFileName"
PROJECT_GUID_VARIABLE = "ProjectGuid"
PROJECT_EXT_VARIABLE = "ProjectExtension"


PRJECT_VARIABLES_MANAGER = {}


def GetProjectVariableManager(current_project=None):
    if current_project is None:
        current_project = get_app().MainFrame.projectview.GetCurrentProject()
    if current_project is None:
        current_project = ProjectDocument.GetUnProjectDocument()
    name = current_project.GetModel().name
    if name not in PRJECT_VARIABLES_MANAGER:
        PRJECT_VARIABLES_MANAGER[name] = VariablesManager(current_project)
    return PRJECT_VARIABLES_MANAGER[name]


def create_variable_name(name):
    return "${%s}" % name


class VariablesManager:

    def __init__(self, current_project=None, **kwargs):
        self._current_project = current_project

        self._variables = {}
        if self._current_project is not None:
            project_path = self._current_project.GetFilename()
            self._variables[PROJECT_NAME_VARIABLE] = self._current_project.GetModel(
            ).Name
            self._variables[PROJECT_PATH_VARIABLE] = project_path
            self._variables[PROJECT_DIR_VARIABLE] = os.path.dirname(
                project_path)
            self._variables[PROJECT_FILENAME_VARIABLE] = os.path.basename(
                project_path)
            self._variables[PROJECT_EXT_VARIABLE] = self._current_project.GetDocumentTemplate(
            ).GetDefaultExtension()
            self._variables[PROJECT_GUID_VARIABLE] = self._current_project.GetModel(
            ).Id

        self._variables.update(self.GetGlobalVariables(**kwargs))

    @property
    def Variables(self):
        return self._variables

    @staticmethod
    def EmumSystemEnviroment():
        d = {}
        for env in os.environ:
            d[env] = os.environ[env]
        return d

    def GetVariable(self, name):
        return self._variables.get(name)

    @classmethod
    def GetGlobalVariables(cls, **kwargs):
        d = cls.EmumSystemEnviroment()
        d["Platform"] = sys.platform
        d["ApplicationName"] = get_app().GetAppName()
        d["ApplicationPath"] = sys.executable
        d["InstallPath"] = utils.get_app_path()
        if 'USER' not in d:
            d['USER'] = getpass.getuser()
        d['Licence'] = '<your licence>'
        d.update(kwargs)
        return d

    def EvalulateValue(self, src_text):
        pattern = re.compile(r"(?<=\$\{)\S[^}]+(?=})")
        groups = pattern.findall(src_text)
        for name in groups:
            if name not in self._variables:
                raise RuntimeError(
                    _("Could not evaluate the expression variable of \"%s\"") % name)
            format_name = create_variable_name(name)
            src_text = src_text.replace(
                format_name, str(self.GetVariable(name)))
        return src_text

    def AddVariable(self, name, value, replace_exist=False):
        if name in self._variables and not replace_exist:
            return
        self._variables[name] = value


class NewVariableDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, title):
        super().__init__(title, parent)

        namebox = QHBoxLayout()
        namebox.addWidget(QLabel(_("Name") + ":"))

        self.name_ctrl = QLineEdit()
        namebox.addWidget(self.name_ctrl)
        self.layout.addLayout(namebox)

        value_box = QHBoxLayout()
        value_box.addWidget(QLabel(_("Value:")))

        self.value_ctrl = QLineEdit()
        value_box.addWidget(self.value_ctrl)
        self.layout.addLayout(value_box)
        self.create_standard_buttons()


class VariablesDialog(ui_utils.BaseModalDialog):
    def __init__(self, parent, title, current_project_document=None):
        super().__init__(title, parent)
        self.resize(600, 500)
        self.layout.addWidget(QLabel(_("Input the variable name") + ":"))
        self.current_project_document = current_project_document
        self.search_variable_ctrl = QLineEdit()
        self.layout.addWidget(self.search_variable_ctrl)
        self.search_variable_ctrl.textChanged.connect(self.SeachVariable)
        columns = [_('Name'), _('Value')]
        self.table = QTableWidget(1, len(columns), self)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().hide()
        self.layout.addWidget(self.table)
        self.table.doubleClicked.connect(self._ok)
        self.table.setHorizontalHeaderLabels(columns)
        self.SetVariables()
        button_layout = QHBoxLayout()
        new_button = QPushButton(_("New"))
        button_layout.addWidget(new_button)
        new_button.clicked.connect(self.NewVariable)

        self.create_standard_buttons(button_layout)
        self.ok_button.setText(_("&Insert"))
        self.layout.addLayout(button_layout)

    def SeachVariable(self, *args):
        search_name = self.search_variable_ctrl.text().strip()
        assert args[0].strip() == search_name
        self._clear_tree()
        self.SetVariables(search_name)

    def GetVariableList(self):
        project_variable_manager = GetProjectVariableManager(
            self.current_project_document)
        valirable_name_list = py_sorted(
            project_variable_manager.Variables.keys(), cmp_func=cmp_name)
        return valirable_name_list

    def SetVariables(self, filter_name=""):
        project_variable_manager = GetProjectVariableManager(
            self.current_project_document)
        valirable_name_list = self.GetVariableList()
        self.table.setRowCount(len(valirable_name_list) + 10)
        i = 0
        for name in valirable_name_list:
            if name.lower().find(filter_name.lower()) != -1 or filter_name == "":
                show_name = create_variable_name(name)
                nameitem = QTableWidgetItem(show_name)
                self.table.setItem(i, 0, nameitem)
                value = project_variable_manager.GetVariable(name)
                valueitem = QTableWidgetItem(value)
                self.table.setItem(i, 1, valueitem)
                i += 1

    def _clear_tree(self):
        # 清空表格所有内容
        self.table.clearContents()
        while self.table.rowCount():
            self.table.removeRow(0)

    def NewVariable(self):
        dlg = NewVariableDialog(self, _("New variable"))
        status = dlg.exec_()
        name = dlg.name_ctrl.text().strip()
        value = dlg.value_ctrl.text().strip()
        if status == NewVariableDialog.Accepted and name:
            self.AddVariable(name, value)

    def AddVariable(self, name, value):
        variable_name = create_variable_name(name)
        max_valid_row = 0
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item is None:
                max_valid_row = row
                break
            # 变量不区分大小写
            if item.text().lower() == variable_name.lower():
                ret = QMessageBox.question(
                    self,
                    _("Warning"),
                    _("Variable name has already exist in variable list,Do you wann't to overwrite it?"),
                )
                if ret == QMessageBox.No:
                    return
                max_valid_row = row
                break
        project_variable_manager = VariablesManager(
            self.current_project_document, **{name: value})
        PRJECT_VARIABLES_MANAGER[self.current_project_document.GetModel(
        ).name] = project_variable_manager
        nameitem = QTableWidgetItem(variable_name)
        self.table.setItem(max_valid_row, 0, nameitem)

        valueitem = QTableWidgetItem(value)
        self.table.setItem(max_valid_row, 1, valueitem)
        self.table.setCurrentItem(nameitem)
        project_variable_manager.AddVariable(name, value)

    def _ok(self):
        row = self.table.currentRow()
        if row < 0:
            return
        self.selected_variable_name = self.table.item(row, 0).text()
        super()._ok()
