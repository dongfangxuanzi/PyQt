# -*- coding: utf-8 -*-
#
# codimension - graphics python two-way code editor and analyzer
# Copyright (C) 2010-2020  Sergey Satskiy <sergey.satskiy@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""Search support"""
import os
import re
import logging
from html import escape
from astroid import nodes
from ..parser.codeparser import CodeParser
from ...util import fileutils, utils, strutils
from ..parser.node_utils import get_node_doc
from ..parser.node_scope import ScopeFinder
from .symbols import Symbol
from ... import globalkeys


class Match:
    """Stores info about one match in a file"""

    def __init__(self, line, start, finish, symbol_type):
        self.line = line        # Matched line
        self.start = start      # Match start pos
        self.finish = finish    # Match end pos
        self.tooltip = "not implemented"
        self.text = ""
        self.symbol_type = symbol_type


class ItemToSearchIn:
    """Stores information about one item to search in"""
    CONTEXT_LINES = 15

    def __init__(self, fname, editor_view=None):
        self.fileName = fname       # Could be absolute -> for existing files
        # or relative -> for newly created
        self.tooltip = ""           # For python files only -> docstring
        self.matches = []
        self._editor_view = editor_view
        self._code_parser = CodeParser()
        self.contains_function_args = utils.profile_get_int(
            globalkeys.CONTAINS_FUNCTION_ARGS_KEY,
            True
        )
        self._contains_class_bases = utils.profile_get_int(
            globalkeys.CONTAINS_CLASS_BASES_KEY,
            False
        )

    @property
    def view(self):
        return self._editor_view

    def set_view(self, view):
        self._editor_view = view

    def get_file_content(self):
        if self.view is None:
            return fileutils.get_file_content(self.fileName)
        return self.view.GetCtrl().text()

    def search(self, expression, symbol_type, scope_in=None):
        """Perform search within this item"""
        self.matches = []
        # Here: there were no buffer or have not found it
        #       try searching in a file
        if not os.path.isabs(self.fileName) or not os.path.exists(self.fileName):
            # Unfortunately not all network file systems report the
            # fact that a file has been deleted from the disk so
            # let's simply ignore such files
            return
        # File exists, search in the file
        try:
            content = self.get_file_content().splitlines()
            if scope_in is None:
                if self._editor_view is None:
                    module = self._code_parser.parse_file(self.fileName)
                else:
                    module = self._code_parser.parse_content(
                        self.fileName,
                        self._editor_view.GetCtrl().text()
                    )
                scope_in = module
            self.__look_through_lines(content, scope_in, expression, symbol_type)
        except Exception:
            logging.exception('Error searching in %s:', self.fileName)

    def rebuild_tooltip(self, content, totallines, match):
        match.tooltip = self.__build_tooltip(
            content,
            match.line - 1,
            totallines,
            match.start,
            match.finish
        )

    def get_class_ranges(self, classnode):
        search_ranges = [
            (classnode.name,
             classnode.position.lineno,
             classnode.position.end_col_offset - len(classnode.name)
             )
        ]
        if self._contains_class_bases:
            for base in classnode.bases:
                search_ranges.append(
                    (base.as_string(), base.lineno, base.col_offset
                     ))
        return search_ranges

    def get_func_ranges(self, funcnode):
        search_ranges = [(
            funcnode.name,
            funcnode.position.lineno,
            funcnode.position.end_col_offset - len(funcnode.name)
        )]
        if self.contains_function_args:
            for arg in funcnode.args.args:
                search_ranges.append((arg.as_string(), arg.lineno, arg.col_offset))
        return search_ranges

    def __build_tooltip(self, content, line_index, total_lines,
                        startPos, finishPos):
        """Forms the tooltip for the given match"""
        start, end = self.__calculate_context_start(line_index, total_lines)
        lines = content[start:end]
        match_index = line_index - start

        # Avoid incorrect tooltips for HTML/XML files
        for index in range(0, len(lines)):
            if index != match_index:
                lines[index] = escape(lines[index])

        lines[match_index] = \
            escape(lines[match_index][:startPos]) + \
            "<b>" + \
            escape(lines[match_index][startPos:finishPos]) + \
            "</b>" + \
            escape(lines[match_index][finishPos:])

        # Strip empty lines at the end and at the beginning
        index = len(lines) - 1
        while index >= 0:
            if lines[index].strip() == '':
                del lines[index]
                index -= 1
                continue
            break
        while len(lines) > 0:
            if lines[0].strip() == '':
                del lines[0]
                continue
            break

        return '<p>' + '<br/>'.join(lines).replace(' ', '&nbsp;') + '</p>'

    def get_import_ranges(self, importnode, linetext):
        node_ranges = []
        for alias in importnode.alias:
            node_ranges.append(
                (alias.name, alias.lineno, alias.col_offset)
            )
            if alias.asname is not None:
                result = re.search(r'import\s+(.*)\s+as\s+(.*)', linetext)
                importas_node_span = result.span(2)
                utils.get_logger().debug(
                    'import node:%s as column span is %s',
                    alias.name,
                    importas_node_span
                )
                node_ranges.append(
                    (alias.asname, alias.lineno, importas_node_span[0])
                )
        return node_ranges

    def get_import_modname(self, importnode):
        import_modname = importnode.modname
        if not strutils.is_none_empty(importnode.level):
            import_modname = importnode.level * '.' + import_modname
        return import_modname

    def get_from_import_ranges(self, importnode, linetext):
        node_ranges = []
        import_modname = self.get_import_modname(importnode)
        result = re.search(r'from\s+(.*)\s+import', linetext)
        # 第0个分组为整个词句, 第1个分组为匹配分组的子句
        fromimport_node_span = result.span(1)
        utils.get_logger().debug(
            'modname:%s column span is %s',
            import_modname,
            fromimport_node_span
        )

        node_ranges.append(
            (import_modname, importnode.lineno, fromimport_node_span[0])
        )
        for alias in importnode.alias:
            node_ranges.append(
                (alias.name, alias.lineno, alias.col_offset)
            )
            if alias.asname is not None:
                node_ranges.append(
                    (alias.asname, alias.lineno, alias.col_offset + len(alias.name))
                )
        return node_ranges

    def get_call_ranges(self, callnode):
        search_ranges = [(
            callnode.func.as_string(),
            callnode.func.lineno,
            callnode.func.col_offset
        )
        ]
        if self.contains_function_args:
            for arg in callnode.args:
                search_ranges.append((arg.as_string(), arg.lineno, arg.col_offset))
            for keyword in callnode.keywords:
                search_ranges.append(
                    (keyword.value.as_string(), keyword.value.lineno, keyword.value.col_offset)
                )
        return search_ranges

    def get_var_ranges(self, targets):
        node_ranges = []
        for target in targets:
            if isinstance(target, nodes.Subscript):
                target = target.value
                node_ranges.append((
                    target.as_string(),
                    target.lineno,
                    target.col_offset
                )
                )
            else:
                node_ranges.append((
                    target.as_string(),
                    target.lineno,
                    target.col_offset
                )
                )
        return node_ranges

    def get_attribute_ranges(self, attrnode):
        return [(
                attrnode.as_string(),
                attrnode.lineno,
                attrnode.col_offset
                )
                ]

    def __look_through_node(self, content, total_line, node, expression, symbol_type):
        node_name_ranges = []
        node_symbol_type = Symbol.ALL
        if isinstance(node, nodes.ClassDef):
            node_symbol_type = Symbol.CLASSES
            node_name_ranges = self.get_class_ranges(node)
            if symbol_type == Symbol.FUNCTIONS.value:
                node_name_ranges = []
        elif isinstance(node, nodes.FunctionDef):
            node_symbol_type = Symbol.FUNCTIONS
            node_name_ranges = self.get_func_ranges(node)
        elif isinstance(node, nodes.Import):
            node_symbol_type = Symbol.IMPORTS
            line = content[node.lineno - 1]
            node_name_ranges = self.get_import_ranges(node, line)
        elif isinstance(node, nodes.ImportFrom):
            node_symbol_type = Symbol.IMPORTS
            line = content[node.lineno - 1]
            node_name_ranges = self.get_from_import_ranges(node, line)
        elif isinstance(node, nodes.Call):
            node_symbol_type = Symbol.CALLS
            node_name_ranges = self.get_call_ranges(node)
        elif isinstance(node, nodes.Assign):
            node_symbol_type = Symbol.VARS
            node_name_ranges = self.get_var_ranges(node.targets)
        elif isinstance(node, nodes.Attribute) and (
            not ScopeFinder.is_parent_node_classtype(
                node, nodes.Call) and not ScopeFinder.is_parent_node_classtype(node, nodes.Assign)
        ):
            node_symbol_type = Symbol.VARS
            node_name_ranges = self.get_attribute_ranges(node)

        for nodename, lineno, col_offset in node_name_ranges:
            contains = expression.search(nodename)
            if contains:
                match = Match(
                    lineno,
                    col_offset + contains.start(),
                    col_offset + contains.end(),
                    node_symbol_type
                )
                line = content[lineno - 1]
                match.text = line
                match.tooltip = self.__build_tooltip(
                    content,
                    lineno - 1,
                    total_line,
                    match.start,
                    match.finish
                )
                if len(self.matches) > 1024:
                    # Too much entries, stop here
                    utils.get_logger().warning(
                        "More than 1024 matches in %s. Stop further search in this file.",
                        self.fileName
                    )
                else:
                    self.matches.append(match)

    def __look_through_body(self, content, total_line_count, node, expression, symbol_type):
        for child in node.get_children():
            if symbol_type == Symbol.CLASSES.value and not isinstance(child, nodes.ClassDef):
                continue
            if symbol_type == Symbol.FUNCTIONS.value and not isinstance(
                child, (nodes.ClassDef, nodes.FunctionDef)
            ):
                continue
            if symbol_type == Symbol.IMPORTS.value and not isinstance(
                child, (nodes.Import, nodes.ImportFrom)
            ):
                continue
            if symbol_type == Symbol.CALLS.value and not isinstance(child, nodes.Call):
                continue
            if symbol_type == Symbol.VARS.value and not isinstance(child, nodes.Assign):
                continue
            self.__look_through_node(content, total_line_count, child, expression, symbol_type)
            self.__look_through_body(content, total_line_count, child, expression, symbol_type)

    @staticmethod
    def __calculate_context_start(matchedLine, totalLines):
        """Calculates the start line number for the context tooltip"""
        # matchedLine is a zero based index
        if ItemToSearchIn.CONTEXT_LINES >= totalLines:
            return 0, totalLines

        start = matchedLine - int(ItemToSearchIn.CONTEXT_LINES / 2)
        start = max(start, 0)
        end = start + ItemToSearchIn.CONTEXT_LINES
        if end < totalLines:
            return start, end
        return totalLines - ItemToSearchIn.CONTEXT_LINES, totalLines

    def __look_through_lines(self, content, scope: nodes.NodeNG, expression, symbol_type):
        """Searches through all the given lines"""
        total_lines = len(content)
        self.__look_through_node(content, total_lines, scope, expression, symbol_type)
        self.__look_through_body(content, total_lines, scope, expression, symbol_type)
        # Extract docsting if applicable
        if len(self.matches) > 0:
            self.__extract_docstring(scope)

    def __extract_docstring(self, node):
        """Extracts a docstring and sets it as a tooltip if needed"""
        if self.tooltip != "":
            return
        self.tooltip = ""
        docstring = get_node_doc(node)
        if not strutils.is_none_empty(docstring):
            self.tooltip = docstring
