class ReplaceRange:
    def __init__(self, start_line, start_col=None, end_line=None, end_col=None):
        self.start_line = start_line or 1
        self.start_col = start_col or 0
        self.end_line = end_line or self.start_line
        self.end_col = end_col or self.start_col
        self.start_line -= 1
        self.end_line -= 1

    def replace_with_text(self, textview, text):
        head, tail, chars, lines = textview.get_region(
            self.start_line,
            self.start_col,
            self.end_line,
            self.end_col
        )
        textview.set_region(head, tail, chars, text.split("\n"), selrep=False)

    @staticmethod
    def node_range(node):
        return ReplaceRange(
            node.lineno,
            node.col_offset,
            node.end_lineno,
            node.end_col_offset
        )

    def replace_line(self, textview, text):
        linetext = textview.GetCtrl().get_line_text(self.start_line)
        end_col = len(textview.GetCtrl()._encodeString(linetext))
        head, tail, chars, lines = textview.get_region(
            self.start_line,
            0,
            self.end_line,
            end_col
        )
        textview.set_region(head, tail, chars, text.split("\n"), selrep=False)

    @staticmethod
    def add_range(line, col):
        return ReplaceRange(line, col, line, col)

    def add_text(self, textview, inserted_content, end=False):
        if not end:
            insert_pos = textview.GetCtrl().position_from_linecol(
                self.start_line, self.start_col)
        else:
            insert_pos = textview.GetCtrl().position_from_linecol(
                self.end_line, self.end_col)
        textview.GetCtrl().insert_text(insert_pos, inserted_content)


class ReplaceNode:
    def __init__(self, node, textview):
        self._node = node
        self._textview = textview

    def replace_node_with_text(self, reptext):
        replace_range = ReplaceRange.node_range(self._node)
        replace_range.replace_with_text(self._textview, reptext)
