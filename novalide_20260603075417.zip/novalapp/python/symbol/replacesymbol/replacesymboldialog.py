# -*- coding: utf-8 -*-
'''
Name:        replacesymbol.py
Purpose:
Author:      wukan
Created:     2026-01-11
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
from .... import _
from ..findsymboldialog import FindSymbolDialog
from ....util import utils
from ....lib.pyqt import (
    QLabel,
    QHBoxLayout,
    QPushButton,
    QComboBox,
    QDialogButtonBox
)
from .replacesupport import ItemtoReplaceIn
from .parameter import ReplaceSymbolParameter
from ....findrep import findindir
from ....findrep import findui
# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------


class ReplaceSymbolDialog(FindSymbolDialog):

    REPLACES_PARAM = 'replaces'

    def __init__(self, master, results_view, findstr=''):
        super().__init__(master, results_view, findstr)
        self.setWindowTitle(_("Replace Symbol"))
        self.replace_results = []
        self._is_replace_act = True
        self.replace_button = QPushButton(_('Replace'))
        self.button_box.addButton(self.replace_button, QDialogButtonBox.AcceptRole)
        self.replace_button.clicked.connect(self._perfom_replace)

    @property
    def is_replace_symbol(self):
        return self._is_replace_act

    def init_process(self):
        param = super().init_process()
        if not self._is_replace_act:
            return param
        self.replace_button.setEnabled(False)
        self.replace_results = []
        param.update({
            self.REPLACES_PARAM: 0,
        })
        return param

    def _perfom_replace(self):
        self._is_replace_act = True
        self._update_history(False)
        super()._process()

    def build_item(self, filepath, code_view=None):
        if not self._is_replace_act:
            return super().build_item(filepath, code_view)
        return ItemtoReplaceIn(
            filepath,
            self.replace_entry_combo.currentText(),
            code_view
        )

    def _perfom_find(self):
        self._is_replace_act = False
        self._update_history()
        super()._process()

    def process_item(self, index, findprog, param, item):
        super().process_item(index, findprog, param, item)
        if not self._is_replace_act:
            return
        self.update_progress(
            index,
            _('Replaces') + ': ' + str(param[self.REPLACES_PARAM]) + ' ' + _('Replacing') + ': ' + item.fileName
        )

        item.replace()
        replace_count = len(item.replaces)
        if replace_count > 0:
            param[self.REPLACES_PARAM] += replace_count
            self.replace_results.append(item)

    def finish_process(self, param, files_num):
        if not self._is_replace_act:
            super().finish_process(param, files_num)
            return
        self._in_progress = False
        number_of_replaces = param[self.REPLACES_PARAM]
        utils.get_logger().debug(
            'replace total %d results in %d files',
            number_of_replaces,
            files_num
        )

        if number_of_replaces > 0:
            # If it is redo then close the dialog anyway
            self.close()
        else:
            msg = _('No replaces in') + ' ' + str(files_num) + ' '
            if files_num > 1:
                msg += _('files')
            else:
                msg += _('file')
            self.file_label.setPath(msg)
            self.find_button.setEnabled(True)
            self.replace_button.setEnabled(True)

    def get_parameter(self):
        find_param = super().get_parameter()
        return ReplaceSymbolParameter(
            find_param.findstr,
            self.replace_entry_combo.currentText(),
            find_param.find_in,
            find_param.symbol,
            find_param.match_case,
            find_param.match_whole_word,
            find_param.path
        )

    def clear_combo_items(self, only_find):
        super().clear_combo_items(only_find)
        if only_find:
            return
        self.replace_entry_combo.clear()

    def create_replace_widget(self):
        '''
        create replace widget for replace dialog
        '''
        # Replace text label
        replace_box_layout = QHBoxLayout()
        replace_label = QLabel(_('Replace what') + ":")
        replace_box_layout.addWidget(replace_label)
        # Replace text field
        self.replace_entry_combo = QComboBox()
        findindir.FindIndirDialog.tune_combo(self.replace_entry_combo)
        replace_box_layout.addWidget(self.replace_entry_combo)
        self.layout.addLayout(replace_box_layout)
        self.find_entry_combo.currentIndexChanged[int].connect(
            self.__on_find_index_changed)
        self._populate_history(False)

    def _serialize(self):
        history_item, params = super()._serialize()
        replace_text = self.replace_entry_combo.currentText().strip()
        history_item.update(
            {findui.FIND_MATCHREPLACE: replace_text}
        )
        return history_item, params

    def _populate_history(self, only_find):
        """Populates the history"""
        super()._populate_history(only_find)
        if only_find:
            return
        # No need to react to the change of the current index
        self.find_entry_combo.currentIndexChanged[int].disconnect(
            self.__on_find_index_changed)
        index = 0
        replace_items = []
        for props in self._history:
            if not isinstance(props, dict):
                continue
            replace_item = props.get(findui.FIND_MATCHREPLACE)
            if replace_item and replace_item not in replace_items:
                self.replace_entry_combo.addItem(replace_item)
                replace_items.append(replace_item)
            index += 1
        # Restore the handler
        self.find_entry_combo.currentIndexChanged[int].connect(
            self.__on_find_index_changed)

    def set_find_text(self, findstr):
        super().set_find_text(findstr)
        findstr = self.find_entry_combo.get_text()
        combo_index, history_index = self.find_entry_combo.historyindex_by_findtext(findstr)
        if combo_index is not None and combo_index >= 0:
            self.find_entry_combo.setCurrentIndex(combo_index)
            self.__deserialize(self._history[history_index])
        else:
            self.replace_entry_combo.setEditText('')

    def __deserialize(self, item):
        """Deserializes the history item"""
        self.find_entry_combo.setEditText(item[findui.FIND_MATCHPATTERN])
        self.replace_entry_combo.setEditText(item.get(findui.FIND_MATCHREPLACE, ""))

    def __on_find_index_changed(self, index):
        """Index in history has changed"""
        if index != -1:
            history_index = self.find_entry_combo.itemData(index)
            if history_index is not None:
                self.__deserialize(self._history[history_index])
            else:
                self.__updateHistory()
