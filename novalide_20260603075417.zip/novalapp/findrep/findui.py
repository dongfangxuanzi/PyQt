# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        find.py
Purpose:
Author:      wukan
Created:     2019-03-14
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import re
from .. import _, get_app
from ..lib.pyqt import (
    QDialog,
    QComboBox,
    QDialogButtonBox,
    QVBoxLayout,
    QLabel,
    QGridLayout,
    QHBoxLayout,
    QCheckBox,
    QRadioButton,
    QGroupBox,
    Qt,
    QSizePolicy,
    QPoint
)
from .option import FindOpt
from ..util import utils
from ..widgets.colorlabel import QRedLabel

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------

# 这些常量为保存在配置文件中的键值
FIND_MATCHPATTERN = "FindMatchPattern"
FIND_MATCHPATTERN_LIST = "FindMatchPatterns"
FIND_MATCHREPLACE = "FindMatchReplace"
FIND_MATCHCASE = "FindMatchCase"
FIND_MATCHWHOLEWORD = "FindMatchWholeWordOnly"
FIND_MATCHREGEXPR = "FindMatchRegularExpr"
FIND_MATCHWRAP = "FindMatchWrap"
FIND_MATCHUPDOWN = "FindMatchUpDown"

FR_DOWN = 1
FR_WHOLEWORD = 2
FR_MATCHCASE = 4
FR_REGEXP = max([FR_WHOLEWORD, FR_MATCHCASE, FR_DOWN]) << 1
FR_WRAP = FR_REGEXP << 1

# 文本列表框显示最多字符串数量
MAX_LIST_STR_NUM = 32

_active_find_dialog = None
_active_find_replace_dialog = None


class ReplaceComboBox(QComboBox):
    """Replace Combo box."""

    def __init__(self, parent=None):
        QComboBox.__init__(self, parent)
        self.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLength)
        self.setEditable(True)
        size_policy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        size_policy.setHorizontalStretch(0)
        size_policy.setVerticalStretch(0)
        size_policy.setHeightForWidth(
            self.sizePolicy().hasHeightForWidth())
        self.setSizePolicy(size_policy)
        self.setInsertPolicy(QComboBox.NoInsert)
        self.setCompleter(None)
        self.setDuplicatesEnabled(False)


def getFindHistory():
    find_string_list = utils.profile_get(FIND_MATCHPATTERN_LIST, [])
    return find_string_list


def setFindHistory(values, params):
    utils.profile_set(FIND_MATCHPATTERN_LIST, values)
    for key in params:
        utils.profile_set(key, params[key])


class FindtextCombo(QComboBox):
    def __init__(self, master):
        super().__init__(master)
        self.setEditable(True)
        self.setCompleter(None)
        self.setDuplicatesEnabled(False)
        self.setInsertPolicy(QComboBox.InsertAtTop)

    def get_text(self):
        return self.lineEdit().text()

    @staticmethod
    def format_find_str(findstr):
        return findstr.split('\n')[0].rstrip('\r')

    def set_text(self, text):
        return self.lineEdit().setText(text)

    def set_find_text(self, findstr):
        # 去除搜索文本的换行符,运行文本末尾有空格
        strip_find_text = self.format_find_str(findstr)
        self.set_text(strip_find_text)

    def historyindex_by_findtext(self, text):
        """Provides the history index by the find text"""
        if text:
            for index in range(self.count()):
                if self.itemText(index) == text:
                    return index, self.itemData(index)
        return None, None


class FindtextLabel(QLabel):
    def __init__(self):
        super().__init__(_("Find what") + ":")


class FindDialog(QDialog):
    last_searched_word = None

    def __init__(self, master, findstring=""):
        super().__init__(master)
        # 查找焦点文本控件
        self.textctrl = None
        self.setWindowTitle(_("Find"))
        init_find_option()
        frame_layout = QHBoxLayout()

        left_layout = QVBoxLayout()
        # Find text label
        find_box_layout = QHBoxLayout()
        find_label = FindtextLabel()
        find_box_layout.addWidget(find_label)
        # Find text field
        self.find_entry_combo = FindtextCombo(self)
        findstring = self.get_find_str(findstring)
        find_box_layout.addWidget(self.find_entry_combo, 1)
        left_layout.addLayout(find_box_layout)
        self._history = getFindHistory()
        self.find_entry_combo.setEditText('')
        self.create_replace_widget(left_layout)
        self.set_find_text(findstring)
        # Info text label (invisible by default, used to tell user that searched string was not
        # found etc)
        self.infotext_label = QRedLabel()
        left_layout.addWidget(self.infotext_label)

        bottom_grid_layout = QGridLayout()
        # Case checkbox
        self.case_checkbutton = QCheckBox(_("Case sensitive"))
        self.case_checkbutton.setChecked(CURERNT_FIND_OPTION.match_case)
        bottom_grid_layout.addWidget(self.case_checkbutton, 0, 0)

        self.wholeword_checkbutton = QCheckBox(_("Match whole word"))
        self.wholeword_checkbutton.setChecked(
            CURERNT_FIND_OPTION.match_whole_word)
        bottom_grid_layout.addWidget(self.wholeword_checkbutton, 1, 0)

        self.regular_checkbutton = QCheckBox(_("Regular expression"))
        self.regular_checkbutton.setChecked(CURERNT_FIND_OPTION.regex)
        bottom_grid_layout.addWidget(self.regular_checkbutton, 2, 0)

        self.wrap_checkbutton = QCheckBox(_("Wrap"))
        self.wrap_checkbutton.setChecked(CURERNT_FIND_OPTION.wrap)
        bottom_grid_layout.addWidget(self.wrap_checkbutton, 3, 0)

        group_box = QGroupBox(_("Direction"))
        group_box_layout = QHBoxLayout()
        # Direction radiobuttons
        self.up_radiobutton = QRadioButton(_("Up"))
        group_box_layout.addWidget(self.up_radiobutton)
        if not CURERNT_FIND_OPTION.down:
            self.up_radiobutton.setChecked(True)

        self.down_radiobutton = QRadioButton(_("Down"))
        group_box_layout.addWidget(self.down_radiobutton)

        if CURERNT_FIND_OPTION.down:
            self.down_radiobutton.setChecked(True)

        group_box.setLayout(group_box_layout)
        bottom_grid_layout.addWidget(group_box, 0, 1, 4, 1)
        left_layout.addLayout(bottom_grid_layout)
        frame_layout.addLayout(left_layout)

        buttonbox = QDialogButtonBox(self)
        buttonbox.setOrientation(Qt.Vertical)
        buttonbox.setStandardButtons(QDialogButtonBox.Cancel)
        buttonbox.button(QDialogButtonBox.Cancel).setText(_("Cancel"))
        self.create_buttonbox_buttons(buttonbox)
        self.find_button.setDefault(True)
        self.find_button.clicked.connect(self._perform_find)
        buttonbox.rejected.connect(self.cancel)
        frame_layout.addWidget(buttonbox)

        self.setLayout(frame_layout)
        self.find_entry_combo.editTextChanged.connect(
            self._update_button_statuses)
        self._update_button_statuses()

    @staticmethod
    def get_find_str(findstring=""):
        # 是否有指定的查找文本,则使用上一次的查找文本
        if not findstring:
            findstring = CURERNT_FIND_OPTION.findstr
        return findstring

    def set_find_text(self, findstr):
        self.find_entry_combo.set_find_text(findstr)

    def create_buttonbox_buttons(self, buttonbox):
        self.find_button = buttonbox.addButton(
            _("Find Next"), QDialogButtonBox.AcceptRole)

    def create_replace_widget(self, layout):
        '''
        create replace widget for replace dialog
        '''
        self._populate_history(True)

    def cancel(self):
        global _active_find_dialog
        self.destroy()
        _active_find_dialog = None

    # callback for text modifications on the find entry object, used to dynamically enable and
    # disable buttons
    def GetFindTextOption(self):
        CURERNT_FIND_OPTION.findstr = self.find_entry_combo.get_text()
        CURERNT_FIND_OPTION.match_case = self.case_checkbutton.isChecked()
        CURERNT_FIND_OPTION.match_whole_word = self.wholeword_checkbutton.isChecked()
        CURERNT_FIND_OPTION.regex = self.regular_checkbutton.isChecked()
        CURERNT_FIND_OPTION.down = self.down_radiobutton.isChecked()
        CURERNT_FIND_OPTION.wrap = self.wrap_checkbutton.isChecked()

    def GetCtrl(self):
        '''
        获取当前视图的文本查找控件,只有当当前焦点窗口是是文本视图或者是调试窗口时才能使用查找功能
        '''
        current_view = get_app().GetDocumentManager().GetCurrentView()
        if current_view is None:
            self.infotext_label.setText(_("There is no active view"))
            return None
        self.textctrl = current_view.GetCtrl()
        if self.textctrl is None:
            self.infotext_label.setText(
                _("Current view is not a text or debug view"))
            return None
        return self.textctrl

    def _update_button_statuses(self, text=None):
        find_text = self.find_entry_combo.get_text()
        if not find_text:
            self.find_button.setEnabled(False)
        else:
            self.find_button.setEnabled(True)

    def clear_combo_items(self, only_find):
        self.find_entry_combo.clear()

    def _perform_find(self):
        if self.GetCtrl() is None:
            return
        self._update_history()
        self.do_find()

    def _serialize(self):
        """Sirializes a current search/replace parameters"""
        term_text = self.find_entry_combo.currentText()
        return {FIND_MATCHPATTERN: term_text}, {
            FIND_MATCHPATTERN: term_text,
            FIND_MATCHCASE: self.case_checkbutton.isChecked(),
            FIND_MATCHWHOLEWORD: self.wholeword_checkbutton.isChecked(),
            FIND_MATCHREGEXPR: self.regular_checkbutton.isChecked(),
            FIND_MATCHWRAP: self.wrap_checkbutton.isChecked(),
            FIND_MATCHUPDOWN: self.down_radiobutton.isChecked()
        }

    def adjust_findreplace_dialog_position(self, find_replace_dlg):
        '''
        根据查找选中文本的坐标动态调整对话框的位置,防止文本被对话框遮盖
        '''
        start = self.GetCtrl().get_selection_end()
        point_x, point_y = self.GetCtrl().point_from_position(start)
        new_point = self.GetCtrl().mapToGlobal(QPoint(point_x, point_y))
        current_dlg = find_replace_dlg
        dlg_rect = current_dlg.frameGeometry()
        if dlg_rect.contains(new_point):
            if new_point.y() > dlg_rect.height():
                offset = -(new_point.y() - dlg_rect.bottomRight().y() - 20)
                # 以正方形上方为基准向上移动到指定坐标
                dlg_rect.moveTop(dlg_rect.topLeft().y() - offset)
            else:
                offset = new_point.y() + 40 - dlg_rect.topLeft().y()
                # 以正方形下方为基准向下移动到指定坐标
                dlg_rect.moveBottom(dlg_rect.bottomRight().y() + offset)
            to_point = QPoint(dlg_rect.x(), dlg_rect.y())
            # 移动窗口到指定坐标
            current_dlg.move(to_point)

    @staticmethod
    def get_current_find_replace_dlg():
        if _active_find_dialog is not None:
            return _active_find_dialog
        return _active_find_replace_dialog

    def _update_history(self, only_find=True):
        """Updates history if needed"""
        current_text = self.find_entry_combo.currentText()
        history_item, params = self._serialize()
        combo_index, history_index = self.find_entry_combo.historyindex_by_findtext(current_text)
        if history_index is not None:
            self._history[history_index] = history_item
        else:
            self._history.insert(0, history_item)
            if len(self._history) > MAX_LIST_STR_NUM:
                self._history = self._history[:MAX_LIST_STR_NUM]

        self.clear_combo_items(only_find)
        self._populate_history(only_find)
        combo_index, history_index = self.find_entry_combo.historyindex_by_findtext(current_text)
        self.find_entry_combo.setCurrentIndex(combo_index)
        # Save the combo values for further usage
        setFindHistory(self._history, params)

    def do_find(self, ok=0):
        self.GetFindTextOption()
        self.infotext_label.setText("")  # reset the info label text
        tofind = self.find_entry_combo.get_text()  # get the text to find
        if not tofind:  # in the case of empty string, cancel
            return False
        try:
            res = self.textctrl.do_find(CURERNT_FIND_OPTION, ok=ok)
            if res:
                next_line, next_col = self.textctrl.find_and_select(res)
                if CURERNT_FIND_OPTION.wrap:
                    self.textctrl.do_wrap_search(
                        next_line, next_col, self.infotext_label)
                if ok != 1:
                    self.adjust_findreplace_dialog_position(
                        self.get_current_find_replace_dlg()
                    )
            else:
                self.infotext_label.setText(
                    _("The specified text was not found!"))
                # 弹出系统提示音
                get_app().beep()
                return False
        except re.error as what:
            self.infotext_label.setText(
                _('Invalid regular expression:%s') % str(what))
            return False
        return True

    def _populate_history(self, only_find):
        """Populates the history"""
        index = 0
        for props in self._history:
            if not isinstance(props, dict):
                continue
            self.find_entry_combo.addItem(props[FIND_MATCHPATTERN], index)
            index += 1

    def closeEvent(self, event):
        """Called when the window is closed. responsible for handling all cleanup."""
        self.destroy()
        global _active_find_dialog
        _active_find_dialog = None


class FindReplaceDialog(FindDialog):
    """Find/Replace Dialog with regular expression matching and wrap to top/bottom of file."""

    def __init__(self, parent, findString=None):
        super().__init__(parent, findString)
        self.setWindowTitle(_("Replace"))
        # 替换字符串时需要设置ok标志为1
        self.ok = 1

    def create_buttonbox_buttons(self, buttonbox):
        super().create_buttonbox_buttons(buttonbox)
        # Replace button - replaces the current occurrence, if it exists
        self.replace_and_find_button = buttonbox.addButton(
            _("Replace"), QDialogButtonBox.AcceptRole)
        self.replace_and_find_button.clicked.connect(self._perform_replace)
        self.replace_and_find_button.setEnabled(False)

        # Replace all button - replaces all occurrences
        self.replace_all_button = buttonbox.addButton(
            _("Replace All"), QDialogButtonBox.AcceptRole)
        self.replace_all_button.clicked.connect(self._perform_replace_all)
        if FindDialog.last_searched_word is None:
            self.replace_all_button.setEnabled(False)

    def create_replace_widget(self, layout):
        '''
        create replace widget for replace dialog
        '''
        replace_box_layout = QHBoxLayout()
        # Replace text label
        replace_label = QLabel(_("Replace with") + ":")
        replace_box_layout.addWidget(replace_label)

        # Replace text field
        self.replace_entry = ReplaceComboBox(self)
        replace_box_layout.addWidget(self.replace_entry, 1)
        layout.addLayout(replace_box_layout)
        self.find_entry_combo.currentIndexChanged[int].connect(
            self.__on_find_index_changed)
        self._populate_history(False)

    def set_find_text(self, findstr):
        super().set_find_text(findstr)
        findstr = self.find_entry_combo.get_text()
        combo_index, history_index = self.find_entry_combo.historyindex_by_findtext(findstr)
        if combo_index is not None and combo_index >= 0:
            self.find_entry_combo.setCurrentIndex(combo_index)
            self.__deserialize(self._history[history_index])
        else:
            self.replace_entry.setEditText('')

    def clear_combo_items(self, only_find):
        super().clear_combo_items(only_find)
        if only_find:
            return
        self.replace_entry.clear()

    def __deserialize(self, item):
        """Deserializes the history item"""
        self.find_entry_combo.setEditText(item[FIND_MATCHPATTERN])
        self.replace_entry.setEditText(item.get(FIND_MATCHREPLACE, ""))

    def __on_find_index_changed(self, index):
        """Index in history has changed"""
        if index != -1:
            history_index = self.find_entry_combo.itemData(index)
            if history_index is not None:
                self.__deserialize(self._history[history_index])
            else:
                self.__updateHistory()

    def _serialize(self):
        history_item, params = super()._serialize()
        replacetext = self.replace_entry.currentText()
        history_item.update(
            {FIND_MATCHREPLACE: replacetext}
        )
        return history_item, params

    def closeEvent(self, event):
        """Called when the window is closed. responsible for handling all cleanup."""
        self.destroy()
        # 对话框关闭时销毁实例,下次重新启动一个新实例
        global _active_find_replace_dialog
        _active_find_replace_dialog = None

    def _populate_history(self, only_find):
        """Populates the history"""
        super()._populate_history(only_find)
        if only_find:
            return
        # No need to react to the change of the current index
        self.find_entry_combo.currentIndexChanged[int].disconnect(
            self.__on_find_index_changed)
        index = 0
        replace_items = []
        for props in self._history:
            if not isinstance(props, dict):
                continue
            replace_item = props.get(FIND_MATCHREPLACE)
            if replace_item and replace_item not in replace_items:
                self.replace_entry.addItem(replace_item)
                replace_items.append(replace_item)
            index += 1
        self.replace_entry.addItem('')
        # Restore the handler
        self.find_entry_combo.currentIndexChanged[int].connect(
            self.__on_find_index_changed)

    def do_find(self, ok=0):
        if FindDialog.do_find(self, ok):
            self.ok = 1
            return True
        return False

    # performs the replace operation - replaces the currently active found word with what is
    # entered in the replace field
    def _update_button_statuses(self, text=None):
        # 根据查找文本是否为空更新查找以及替换按钮状态
        super()._update_button_statuses()
        find_text = self.find_entry_combo.get_text()
        # 再更新替换按钮状态
        if not find_text:
            self.replace_and_find_button.setEnabled(False)
            self.replace_all_button.setEnabled(False)
        else:
            self.replace_all_button.setEnabled(True)
            self.replace_and_find_button.setEnabled(True)

    def do_replace(self):
        prog = self.textctrl.getprog()
        if not prog:
            return False
        firstline, firstindex, lastline, lastindex = self.textctrl.get_selection()
        line, col = firstline, firstindex
        chars = self.textctrl.text(line)
        m = prog.match(chars, col)
        if not prog:
            return False
        new = self._replace_expand(m, self.replace_entry.currentText())
        if new is None:
            return False
        if m.group():
            first = self.textctrl.positionFromLineIndex(firstline, firstindex)
            last = self.textctrl.positionFromLineIndex(lastline, lastindex)
            self.textctrl.replace_target(first, last, new)
        self.ok = 0
        return True

    def _perform_replace(self):
        if self.GetCtrl() is None:
            return
        self._update_history(False)
        if self.do_find(self.ok):
            if self.do_replace():   # Only find next match if replace succeeded.
                # A bad re can cause a it to fail.
                # 替换之后再查找一次
                self.do_find(0)

    def _replace_expand(self, m, repl):
        """
        Helper function for expanding a regular expression
        in the replace field, if needed.
        """
        if CURERNT_FIND_OPTION.regex:
            try:
                new = m.expand(repl)
            except re.error:
                new = None
        else:
            new = repl
        return new

    # replaces all occurences of the search string with the replace string
    def _perform_replace_all(self):
        if self.GetCtrl() is None:
            return
        self._update_history(False)
        repl = self.replace_entry.currentText()
        if not FindDialog.do_find(self):
            return
        line = 1
        col = 1
        ok = 1
        first = last = None
        self.textctrl.SetOption(CURERNT_FIND_OPTION)
        prog = self.textctrl.getprog()
        while True:
            res = self.textctrl.search_forward(prog, line, col, 0, ok)
            if not res:
                break
            line, m = res
            orig = m.group()
            new = self._replace_expand(m, repl)
            if new is None:
                break
            i, j = m.span()
            first = self.textctrl.positionFromLineIndex(line, i)
            last = self.textctrl.positionFromLineIndex(line, j)
            if new != orig:
                if first != last:
                    self.textctrl.replace_target(first, last, new)
            col = i + len(new)
            ok = 0


CURERNT_FIND_OPTION = None


def show_findreplace_dialog(master, replace=False, find_string=""):
    if replace:
        global _active_find_replace_dialog
        if _active_find_replace_dialog is None:
            _active_find_replace_dialog = FindReplaceDialog(
                master, find_string)
        _active_find_replace_dialog.show()
    else:
        global _active_find_dialog
        if _active_find_dialog is None:
            _active_find_dialog = FindDialog(master, find_string)
        _active_find_dialog.show()


def init_find_option():
    global CURERNT_FIND_OPTION
    if CURERNT_FIND_OPTION is None:
        CURERNT_FIND_OPTION = FindOpt('')
        CURERNT_FIND_OPTION.findstr = utils.profile_get(
            FIND_MATCHPATTERN, CURERNT_FIND_OPTION.findstr)
        CURERNT_FIND_OPTION.match_case = utils.profile_get_int(
            FIND_MATCHCASE, CURERNT_FIND_OPTION.match_case)
        CURERNT_FIND_OPTION.match_whole_word = utils.profile_get_int(
            FIND_MATCHWHOLEWORD, CURERNT_FIND_OPTION.match_whole_word)
        CURERNT_FIND_OPTION.regex = utils.profile_get_int(
            FIND_MATCHREGEXPR, CURERNT_FIND_OPTION.regex)
        CURERNT_FIND_OPTION.wrap = utils.profile_get_int(
            FIND_MATCHWRAP, CURERNT_FIND_OPTION.wrap)
        CURERNT_FIND_OPTION.down = utils.profile_get_int(
            FIND_MATCHUPDOWN, CURERNT_FIND_OPTION.down)
