import copy
from novalapp.python.parser.node_scope import ScopeFinder
from astroid import nodes
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg
from ...codeutils import DEFAULT_TAB_BLANKS
from ...multifixer import MultiOptionFixer


class PylintC0116Fixer(PylintFixer, MultiOptionFixer):
    '''
    规则说明: 函数或方法缺少文档字符串说明
    '''

    def __init__(self):
        super().__init__('C0116', False)
        MultiOptionFixer.__init__(
            self,
            0,
            title='',
            descr="Please choose one docstring option",
            init_options=['simple docstring', 'detail docstring']
        )

    @classmethod
    def get_function_simple_string(cls, func_node):
        indent_blanks = DEFAULT_TAB_BLANKS + func_node.position.col_offset * ' '
        function_or_method_string = indent_blanks + cls.SINGLE_TRIPLE_QUOTE + cls.SINGLE_TRIPLE_QUOTE
        return function_or_method_string

    @classmethod
    def get_function_detail_string(cls, func_node):
        indent_blanks = DEFAULT_TAB_BLANKS + func_node.position.col_offset * ' '
        function_or_method_string = indent_blanks + cls.SINGLE_TRIPLE_QUOTE
        function_or_method_string += "\n"
        function_or_method_string += "\n"
        args = copy.copy(func_node.args.args)
        if isinstance(func_node.parent, nodes.ClassDef):
            if args[0].as_string() == "self" or args[0].as_string() == "cls":
                args.remove(args[0])
        for arg in args:
            arg_name_str = f":param {arg.name}:"
            function_or_method_string += indent_blanks + arg_name_str
            function_or_method_string += "\n"
            arg_type_str = f":type {arg.name}:"
            function_or_method_string += indent_blanks + arg_type_str
            function_or_method_string += "\n"
        function_or_method_string += indent_blanks + ":return:"
        function_or_method_string += "\n"
        function_or_method_string += indent_blanks + ":rtype:"
        function_or_method_string += "\n"

        function_or_method_string += indent_blanks + cls.SINGLE_TRIPLE_QUOTE
        function_or_method_string += "\n"
        return function_or_method_string

    @classmethod
    def get_function_comments_doc_string(cls, func_node, top_comments):
        indent_blanks = DEFAULT_TAB_BLANKS + func_node.position.col_offset * ' '
        if 1 == len(top_comments):
            function_or_method_string = indent_blanks + cls.SINGLE_TRIPLE_QUOTE + \
                top_comments[0].strip().lstrip('#') + cls.SINGLE_TRIPLE_QUOTE
        else:
            function_or_method_string = indent_blanks + cls.SINGLE_TRIPLE_QUOTE
            function_or_method_string += "\n"
            for comment_text in top_comments:
                function_or_method_string += indent_blanks + comment_text.strip().lstrip('#')
                function_or_method_string += "\n"
            function_or_method_string += indent_blanks + cls.SINGLE_TRIPLE_QUOTE
            function_or_method_string += "\n"
        return function_or_method_string

    @ fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        text_ctrl = kwargs.get('textctrl')
        self.load_module(textview, msg.filepath)
        scope = ScopeFinder(
            textview.ModuleAnalyzer.Module).find_scope(msg.line)
        function_or_method_string = ''
        if isinstance(scope, nodes.FunctionDef):
            func_node = scope
            if isinstance(func_node.parent, nodes.ClassDef):
                self.set_title("Fix method docstring")
            else:
                self.set_title("Fix function docstring")
            func_top_comment_lines = self.get_function_top_comment_lines(text_ctrl, func_node)
            func_top_comments = []
            for func_top_comment_line in func_top_comment_lines[::-1]:
                func_top_comments.append(text_ctrl.get_line_text(func_top_comment_line))
            extra_option_name = 'replace docstring with top comments'
            if func_top_comments and extra_option_name not in self.options:
                self.options.append(extra_option_name)
            self.get_selection(text_ctrl)
            if self.selection == self.INVAID_SEL_INDEX:
                return False
            if 0 == self.selection:
                function_or_method_string = self.get_function_simple_string(func_node)
            if 1 == self.selection:
                function_or_method_string = self.get_function_detail_string(func_node)
            if 2 == self.selection:
                function_or_method_string = self.get_function_comments_doc_string(
                    func_node,
                    func_top_comments
                )
            text_ctrl.GotoPos(msg.line, 0)
            textview.AddText(function_or_method_string + "\n")
            if func_top_comments and 2 == self.selection:
                for func_top_comment_line in func_top_comment_lines:
                    textview.delete_line(func_top_comment_line)
            return True
        return False
