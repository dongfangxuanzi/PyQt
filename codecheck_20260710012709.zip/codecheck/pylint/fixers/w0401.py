import re
from novalapp import get_app
from novalapp.util import utils
from ...basefix import fix_code_file_msg
from ...codeutils import get_node_range
from ...pylint_fix import PylintFixer


class PylintW0401Fixer(PylintFixer):
    '''
    规则说明: 导入语句使用`from module import *`
    '''
    MAX_MEMBERS_COUNT = 30

    def __init__(self):
        super().__init__('W0401', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        res = re.search(r'Wildcard import (.*) \(wildcard-import\)', msg.msg)
        modname = res.groups()[0]
        nodestr = node.as_string()
        if node.names[0][0] != '*':
            return False
        if modname != node.modname:
            utils.get_logger().warn(
                'msg modname %s is not current node modname %s',
                modname,
                node.modname
            )
            return False
        old_mod_name = node.modname
        old_level = node.level
        textview.ModuleAnalyzer.fix_module_importnodes()
        node = self.find_msg_node(textview, msg)
        mdloader = get_app().intellisence_mananger.GetModule(
            node.modname
        )
        members = mdloader.get_member_list()
        node.level = old_level
        node.modname = old_mod_name
        members_count = len(members)
        if members_count > self.MAX_MEMBERS_COUNT:
            utils.get_logger().warn(
                'import modname %s members count %d is greater then max members limit:%d',
                modname,
                members_count,
                self.MAX_MEMBERS_COUNT
            )
            return False
        fixnode = get_node_range(node)
        fixstr = nodestr.replace("*", ','.join(members))
        fixnode.replace_with_text(textview, fixstr)
        return True
