from novalapp.util.ui_utils import BaseModalDialog
from novalapp import _
from novalapp.lib.pyqt import QComboBox, QLabel, QLineEdit, QGridLayout
from .toolmanager import CodecheckToolManager


class RuleOptionDialog(BaseModalDialog):
    '''工具规则配置选项对话框'''

    def __init__(self, parent, tool_name, rule_config_data):
        super().__init__(_('Rule Option'), parent)

        self._config_data = rule_config_data
        self._tool_name = tool_name
        self.checktool = CodecheckToolManager.manager().find_tool(self._tool_name)
        frame_grid_layout = QGridLayout()
        frame_grid_layout.addWidget(QLabel(_("Tool") + ":"), 0, 0)
        frame_grid_layout.addWidget(QLabel(_("Rule") + ":"), 1, 0)
        frame_grid_layout.addWidget(QLabel(_("Config Name") + ":"), 2, 0)
        frame_grid_layout.addWidget(QLabel(_("Config Value") + ":"), 3, 0)

        self._tool_list = QComboBox()
        self._tool_list.setEditable(False)
        tool_names = CodecheckToolManager.manager().tool_names()
        self._tool_list.addItems(tool_names)
        frame_grid_layout.addWidget(self._tool_list, 0, 1)
        self._tool_list.setCurrentIndex(tool_names.index(tool_name))
        self._tool_list.setEnabled(False)

        self._rule_name_edit = QLineEdit()
        self._rule_name_edit.setEnabled(False)
        frame_grid_layout.addWidget(self._rule_name_edit, 1, 1)
        self._rule_name_edit.setText(self._config_data['rule'])

        self._rule_config_name_edit = QLineEdit()
        self._rule_config_name_edit.setEnabled(False)
        frame_grid_layout.addWidget(self._rule_config_name_edit, 2, 1)
        option_key_name = self._config_data['option_key']
        self._rule_config_name_edit.setText(option_key_name)

        self._rule_config_value_edit = QLineEdit()
        frame_grid_layout.addWidget(self._rule_config_value_edit, 3, 1)
        self._rule_config_value_edit.setPlaceholderText(str(self._config_data['default']))
        self._rule_config_value_edit.setText(self.checktool.get_key_value(option_key_name))
        self.layout.addLayout(frame_grid_layout)
        self.create_standard_buttons()

    def _ok(self):
        self.checktool.write_key_value(
            self._config_data['option_key'],
            self._rule_config_value_edit.text().strip()
        )
        super()._ok()
