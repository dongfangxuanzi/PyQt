'''
Name:        w1202.py
Purpose:
Author:      wukan
Created:     2026-05-17
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import re
from astroid import nodes
from ...codeutils import get_node_range
from ...pylint_fix import PylintFixer
from ...basefix import fix_code_file_msg


class PylintW1202Fixer(PylintFixer):
    '''
    规则说明:日志打印字符串使用可变参数,而不是字符串.format的方式
    '''

    def __init__(self):
        super().__init__('W1202', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        node = self.find_msg_node(textview, msg)
        if not node:
            return False
        if isinstance(node, nodes.Expr) and isinstance(node.value, nodes.Call):
            if len(node.value.args) == 1 and isinstance(node.value.args[0], nodes.Call):
                f_arg = node.value.args[0]
                if isinstance(f_arg.func, nodes.Attribute) and f_arg.func.attrname == 'format':
                    format_args = f_arg.args
                    format_arg_list = [arg.as_string() for arg in format_args]
                    arg_range = get_node_range(f_arg)
                    fix_str = re.sub(r'{\d*}', '%s', f_arg.func.expr.as_string())
                    format_arg_str = ",".join(format_arg_list)
                    fix_str += ","
                    fix_str += format_arg_str
                    arg_range.replace_with_text(textview, fix_str)
                    return True
        return False
