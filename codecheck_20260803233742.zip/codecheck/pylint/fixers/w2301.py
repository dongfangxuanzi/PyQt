from astroid import nodes
from ...basefix import fix_code_file_msg
from ...pylint_fix import PylintFixer


class PylintW2301Fixer(PylintFixer):
    '''
    规则说明: 多余的...语句
    '''

    def __init__(self):
        super().__init__('W2301', True)

    @fix_code_file_msg
    def fix_message(self, doc, msg, **kwargs):
        textview = kwargs.get('textview')
        line = msg.line
        node = self.find_msg_node(textview, msg)
        if isinstance(node, nodes.Expr) and (
            isinstance(node.value, nodes.Const) and node.value.value == Ellipsis
        ):
            textview.delete_line(line - 1)
            return True
        return False
