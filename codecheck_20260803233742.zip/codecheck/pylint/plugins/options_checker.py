# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/PyCQA/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/PyCQA/pylint/blob/main/CONTRIBUTORS.txt

"""tabs checker for Python code."""
from __future__ import annotations
from typing import TYPE_CHECKING
from astroid import nodes
from pylint.checkers import BaseChecker
from pylint.checkers.utils import only_required_for_messages
if TYPE_CHECKING:
    from pylint.lint import PyLinter


class OptionsChecker(BaseChecker):
    name = "options"
    msgs = {
        "W9004": (
            "view all options of all checker",
            "linter-options",
            "",
        )
    }

    def __init__(self, linter: PyLinter) -> None:
        super().__init__(linter)
        for checker in linter.get_checkers():
            check_msg_ids = list(checker.msgs.keys())
            print(check_msg_ids)
            for opt, optdict in checker.options:
                print(opt, optdict)
            print("---------------------------")


def register(linter: PyLinter) -> None:
    linter.register_checker(OptionsChecker(linter))
