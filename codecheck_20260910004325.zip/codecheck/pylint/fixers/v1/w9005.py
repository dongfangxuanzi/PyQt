'''
Name:        w9005.py
Purpose:     类方法排序规则
Author:      wukan
Created:     2026-09-09
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''

from astroid import nodes
from novalapp.python.parser.node_scope import ScopeFinder
from ....pylint_fix import PylintFixer


class PylintW9005Fixer(PylintFixer):
    '''
    规则说明:xxx = property(xxx)
    property method赋值给类方法,可以使用property装饰符装饰方法
    '''

    def __init__(self):
        super().__init__('W9005', True)

    def fix_message(self, msg):
        node = self.find_msg_node(msg)
        if isinstance(node, nodes.Assign) and isinstance(node.value, nodes.Call):
            call_node = node.value
            if isinstance(call_node.func, nodes.Name) and call_node.func.name == "property":
                call_args_num = len(call_node.args)
                if call_args_num not in [1, 2]:
                    return False
                first_arg = call_node.args[0]
                first_arg_name = first_arg.as_string()
                parent_scope = ScopeFinder.get_parent_class_node(node)
                target_name = node.targets[0].as_string()
                get_method_scope = ScopeFinder.get_class_method_node(parent_scope, first_arg_name)
                has_setter_property = False
                if get_method_scope is None:
                    return False
                if call_args_num == 2:
                    second_arg = call_node.args[1]
                    second_arg_name = second_arg.as_string()
                    set_method_scope = ScopeFinder.get_class_method_node(
                        parent_scope,
                        second_arg_name
                    )
                    if set_method_scope is None:
                        return False
                    has_setter_property = True
                self.delete_node(node, delete_node_line=True)
                if not has_setter_property:
                    self.add_method_property_decorator(get_method_scope, target_name)
                else:
                    if set_method_scope.position.lineno > get_method_scope.position.lineno:
                        self.add_method_property_decorator(
                            set_method_scope,
                            target_name,
                            is_property_setter=True
                        )
                        self.add_method_property_decorator(get_method_scope, target_name)
                    else:
                        self.add_method_property_decorator(get_method_scope, target_name)
                        self.add_method_property_decorator(
                            set_method_scope,
                            target_name,
                            is_property_setter=True
                        )
                return True
        return False

    def add_method_property_decorator(self, method_scope, property_name, is_property_setter=False):
        func_name_node = self.build_class_func_name_node(method_scope)
        self.fix_node_text(func_name_node, property_name)
        blanks = method_scope.position.col_offset * ' '
        if not is_property_setter:
            self.add_range_text(
                method_scope.position.lineno,
                0,
                blanks + '@property' + '\n'
            )
        else:
            self.add_range_text(
                method_scope.position.lineno,
                0,
                blanks + f'@{property_name}' + ".setter" + '\n'
            )
