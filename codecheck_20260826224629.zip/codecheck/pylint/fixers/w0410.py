from astroid import nodes
from ...pylint_fix import PylintFixer


class PylintW0410Fixer(PylintFixer):
    '''
    规则说明:from __future__ import xx语句必须放在导入语句最前面
    '''

    def __init__(self):
        super().__init__('W0410', True)

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg)
        if node is None:
            return False
        if isinstance(node, nodes.ImportFrom) and node.modname == "__future__":
            pnode = node.parent
            if isinstance(pnode, nodes.Module):
                first_nodoc_node = pnode.body[0]
                self.fix_node_text(first_nodoc_node, node.as_string())
                self.fix_node_text(node, first_nodoc_node.as_string())
                return True
        return False
