import re
from ...pylint_fix import PylintFixer


class PylintR1725Fixer(PylintFixer):
    '''
    规则说明:使用super关键字来调用父类构造函数
    '''

    def __init__(self):
        super().__init__('R1725', True)

    def fix_message(self, doc, msg):
        line = msg.line
        line_text = self.get_msg_line_text(msg)
        regstr = r'super\s*\(.*\)\.'
        if re.search(regstr, line_text):
            replace_text = re.sub(regstr, "super().", line_text)
            self.replace_line_text(line, replace_text)
            return True
        return False


class PylintE1003Fixer(PylintR1725Fixer):

    def __init__(self):
        PylintFixer.__init__(self, 'E1003', True)
