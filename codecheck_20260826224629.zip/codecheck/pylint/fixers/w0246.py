from astroid import nodes
from novalapp.python.parser.define import CLASS_INIT_METHOD
from ...pylint_fix import PylintFixer


class PylintW0246Fixer(PylintFixer):
    '''
    规则说明:显式继承父类__init__方法多余,调用父类__init__方法后没有其它操作,
    可以删除显式继承的__init__方法
    '''

    def __init__(self):
        super().__init__('W0246', True)

    def fix_message(self, doc, msg):
        node = self.find_msg_node(None, msg)
        if isinstance(node, nodes.Name) and (
            isinstance(node.parent, nodes.FunctionDef) and node.parent.name == CLASS_INIT_METHOD
        ):
            if not self.is_node_could_deleted(node.parent):
                return False
            self.delete_node(node.parent)
            return True
        return False


class PylintW0235Fixer(PylintW0246Fixer):
    '''
    规则说明: 子类继承父类时__init__方法仅仅只是调用父类的__init__方法,没有其它实质内容
    此__init__方法多余，新规则是W0246
    '''

    def __init__(self):
        PylintFixer.__init__(self, 'W0235', True)
