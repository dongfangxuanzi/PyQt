# -*- coding: utf-8 -*-
from .enums import AppStyle, AppSkin
APPLICATION_NAME = "NovalIDE"
DEBUG_APPLICATION_NAME = APPLICATION_NAME + "Debug"

DEFAULT_TAB_WIDTH = 4
DEFAULT_TAB_INDENTATION_WIDTH = 4
TEMPLATE_FILE_NAME = "template.xml"
USER_CACHE_DIR = "cache"

DEFAULT_FONT_FAMILY = "Courier New"
DEFAULT_FONT_SIZE = 11

NORMAL_MENU_ITEM_KIND = 0
SUB_MENU_ITEM_KIND = 1
CHECK_MENU_ITEM_KIND = 2
RADIO_MENU_ITEM_KIND = 3


OUTLINE_VIEW_NAME = "Outline"
FILE_VIEW_NAME = "Fileview"
PROJECT_VIEW_NAME = "Projectview"
SEARCH_RESULTS_VIEW_NAME = "SearchResults"
PYTHON_INTERPRETER_VIEW_NAME = "PythonInterpreter"
TODO_LIST_VIEW = "TodoList"


TOOLBAR_ICON_WIDTH = 16
TOOLBAR_ICON_HEIGHT = 16


# 状态栏显示的标签名称,行列以及文件编码
STATUS_BAR_LABEL_LINE = "line"
STATUS_BAR_LABEL_COL = "column"
STATUS_BAR_LABEL_ENCODING = "encoding"

# 工具栏排列在第一行的位置
DEFAULT_TOOL_BAR_ROW = 0
# 工具栏排列在第三行的位置
DEFAULT_STATUS_BAR_ROW = 3
# 主框架排列在第二行的位置
DEFAULT_MAIN_FRAME_ROW = 1

PROJECT_ADD_COMMAND_NAME = "add"
PROJECT_ADD_PROGRESS_COMMAND_NAME = "progress_add"
PROJECT_REMOVE_COMMAND_NAME = "remove"
# the first 2 line no of python file to place encoding declare
ENCODING_DECLARE_LINE_NUM = 2
NOT_IN_ANY_PROJECT = "Not in any project"
DEFAULT_EDGE_GUIDE_WIDTH = 78
MIXED_CRLF = 3
CR = "\r"
LF = "\n"
CRLF = "\r\n"
EOL_CHOICES = ("Windows (\\r\\n)", "Old Machintosh (\\r)", "Unix (\\n)")
INTERACTCONSOLE_TAB_NAME = "InteractConsole"
BREAKPOINTS_TAB_NAME = "Breakpoints"
STACKFRAME_TAB_NAME = "StackFrame"
WATCH_TAB_NAME = "Watchs"
# 默认url请求连接超时时间
DEFAULT_URL_REQUEST_TIMEOUT = 10
APPLICATION_LOOKS = {
    AppStyle.WINDOWS_NATIVE.value: [],
    AppStyle.WINDOWS_QT_NATIVE_APP_STYLE.value: [],
    AppStyle.DEFAULT_APP_STYLE: [
        AppSkin.DEFAULT_APP_SKIN.value,
        AppSkin.OLD_FASHION_GREENBLACK_SKIN.value,
        AppSkin.OLD_FASHION_LIGHT_SKIN.value,
    ]
}

# 显示浏览器页面
INTERNAL_WEB_BROWSER = 16
# 显示起始页
APPLICATION_STARTUP_PAGE = 32
# 进度条结束标志
PROGRESS_END = "end"
DEFUALT_MAX_OPEN_FILES = 10
MAX_OUTPUT_LINELENGTH = 5000
# 默认输入1个字符串弹出自动提示文本框
DEFAULT_AUTOCOMPLETION_THRESHOLD_NUM = 1
# 保存上次打开文件路径的文件名
OPEN_DOCS_FILENAME = "opendocs"

ISO_8601_DATE_FORMAT = "%Y-%m-%d"
ISO_8601_TIME_FORMAT = "%H:%M:%S"
ISO_8601_DATETIME_FORMAT = "%s %s" % (
    ISO_8601_DATE_FORMAT, ISO_8601_TIME_FORMAT)
MIN_FONT_SIZE = 4
MAX_FONT_SIZE = 200
# 版本控制工具生成的隐藏目录
REVISION_CONTROL_DIRS = ('.svn', '.cvs', '.git', '.hg')
DRAG_ITEM_FILE_FLAG = 'item:///'

MAX_LOAD_OPENDOCS_COUNT = 50
CONFIG_DIR = ".novalconfig"
