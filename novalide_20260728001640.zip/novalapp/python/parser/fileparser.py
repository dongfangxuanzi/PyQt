# coding:utf-8
from __future__ import annotations
import traceback
import contextlib
from collections.abc import Callable, Iterator
import functools
import logging
from typing import List
from typing import Protocol
from astroid import nodes
import astroid
from .ast_walker import ASTWalker
from .moduleitem import ModuleItem
from . import objtypes
from .define import CLASS_INIT_METHOD
from ..analysis.moduleloader import ModuleLoader
from ..apis import memberkeys
from ..apis.member import Member, ReferMember
from . import node_utils
from .node_scope import ScopeFinder
from .codebase import CodebaseParser, MANAGER
from .exceptions import OutofPythonPathError
from ...util import strutils


class GetAstProtocol(Protocol):
    def __call__(
        self, filepath: str, modname: str, data: str | None = None
    ) -> nodes.Module:
        ...


logger = logging.getLogger('ide.codefile.parser')


class CodefileParser(CodebaseParser):

    # 需要强制分析导入语句的特殊模块
    CHECK_IMPORTS_MODULES = frozenset(('os', 'ssl', 'socket', 'os.path'))

    def __init__(self, python_path_analyzer):
        super().__init__(python_path_analyzer)
        self._python_path_analyzer = self.analyzer
        self._fileitem = None
        self._childs: List[Member] = []
        self._module = None
        self._finished = True
        self._use_cache = True

    @property
    def use_cache(self):
        return self._use_cache

    @use_cache.setter
    def use_cache(self, val):
        self._use_cache = val

    @property
    def modpath(self):
        return self._fileitem.modname

    @property
    def finished(self):
        return self._finished

    @property
    def childs(self):
        return self._childs

    @staticmethod
    def is_support_mro_class(node):
        for base in node.bases:
            if not isinstance(base, (nodes.Name, nodes.Attribute)):
                return False
        return True

    @staticmethod
    def is_class_range(node):
        is_func_range = ScopeFinder.is_parent_node_classtype(node, nodes.FunctionDef)
        return ScopeFinder.is_class_range(node) and not is_func_range

    def get_ast(
        self, filepath: str, modname: str, source=True, data: str | None = None
    ) -> nodes.Module | None:
        """
        Return an ast(roid) representation of a module or a string.
        :param filepath: path to checked file.
        :param str modname: The name of the module to be checked.
        :param str data: optional contents of the checked file.
        :returns: the AST
        :rtype: astroid.nodes.Module
        :raises AstroidBuildingError: Whenever we encounter an unexpected exception
        """
        try:
            if data is None:
                return self.ast_from_file(
                    filepath,
                    modname,
                    source=source,
                    use_cache=self._use_cache
                )

            return astroid.builder.AstroidBuilder(MANAGER).string_build(
                data, modname, filepath
            )
        except astroid.AstroidSyntaxError as ex:
            line = getattr(ex.error, "lineno", None)
            if line is None:
                line = 0
            logger.error('parse file %s syntax-error:%s', filepath, str(ex))
        except astroid.AstroidBuildingError as ex:
            logger.error("parse file %s error:%s", filepath, ex)
        except Exception as ex:
            traceback.print_exc()
            # We raise BuildingError here as this is essentially an astroid issue
            # Creating an issue template and adding the 'astroid-error' message is handled
            # by caller: _check_files
            raise astroid.AstroidBuildingError(
                "Building error when trying to create ast representation of module '{modname}'",
                modname=modname,
            ) from ex
        return None

    def parse_single_file(self, name: str, filepath: str, modname: str) -> None:
        self.parse_single_file_item(ModuleItem(name, filepath, modname))
        return self._module

    def parse_single_file_item(self, file: ModuleItem) -> None:
        """
        Check single file item.
        The arguments are the same that are documented in _check_files
        initialize() should be called before calling this method
        """
        self._fileitem = file
        with self._astroid_module_visitor() as parse_astroid_module:
            self._parse_file(self.get_ast, parse_astroid_module, file)

    def prepare_visitors(self):
        self._visitors.append(self.visit_functiondef)
        self._visitors.append(self.visit_classdef)
        self._visitors.append(self.visit_assign)
        self._visitors.append(self.visit_annassign)
        self._visitors.append(self.visit_import)
        self._visitors.append(self.visit_importfrom)
        self._visitors.append(self.visit_if)
        self._visitors.append(self.visit_try)
        return self._visitors

    def expand_mod_path(self, names: list):
        return ".".join([self.modpath] + names)

    def visit_functiondef(self, node):
        if self.is_class_range(node):
            parent_class_node = ScopeFinder.get_parent_class_node(node)
            func_mod_path = self.expand_mod_path([parent_class_node.name, node.name])
            class_member = self.find_member_by_node(parent_class_node)
            if class_member is None:
                logger.warning(
                    'functiondef parent class node %s is not in module range',
                    parent_class_node
                )
                return
            method_member = Member(node.name, func_mod_path, objtypes.FUNCTION_DEF, node)
            # 成员方法作为子节点信息保存
            class_member.childs.append(method_member)
        elif ScopeFinder.is_module_range(node):
            func_mod_path = self.expand_mod_path([node.name])
            self._childs.append(Member(node.name, func_mod_path, objtypes.FUNCTION_DEF, node))

    def find_member_by_node(self, node):
        for child in self._childs:
            if child.node == node:
                return child
        return None

    def skip_import_statements(self):
        '''
        包启动__init__模块,以及几个特殊模块需要分析导入语句
        '''
        if self._module.package or self.modpath in self.CHECK_IMPORTS_MODULES:
            return False
        return self.analyzer.skip_imports

    def visit_import(self, node):
        '''分析import语句没有实际意义,而且会增加分析耗时,跳过分析'''
        ...

    def visit_importfrom(self, node):
        if not ScopeFinder.is_module_range(node) or self.skip_import_statements():
            return
        mod_name = self.get_fromimport_modname(node, self._fileitem.filepath)
        if mod_name is None:
            return
        membersfile, memberlistfile = self.check_refmod_analyzed(
            mod_name, self._fileitem.filepath, raise_exception=False)
        # 导入模块存在但是未完成解析,设置未完成标志,等待导入模块解析完成后再次生成新数据
        if membersfile is None:
            self._finished = False
            return
        # 导入模块未找到
        if membersfile == '':
            return
        mdloader = ModuleLoader(mod_name, membersfile, memberlistfile)
        mdloader.load()
        module = mdloader.build_simple_node(mdloader.data)
        for alias in node.alias:
            name = alias.name
            if name == '*':
                if self.analyzer.skip_import_stars and self.skip_import_statements():
                    break
                childs = mdloader.data[memberkeys.CHILD_KEY_NAME]
                for child in childs:
                    data = child
                    child_mod_name = data[memberkeys.MODNAME_KEY_NAME]
                    # 跳过包子模块下的子成员
                    if len(child_mod_name.split(".")) > len(mod_name.split(".")) + 1:
                        logger.debug('skip member %s in child module %s', child_mod_name, mod_name)
                        continue
                    childname = data[memberkeys.NAME_KEY_NAME]
                    attr_mod_path = self.expand_mod_path([childname])
                    node = mdloader.build_simple_node(data, module)
                    path = mdloader.path
                    ref_modname = mod_name
                    refpath = data.get(memberkeys.PATH_KEY_NAME, None)
                    # 引用其它模块的成员也是从其它模块导入的
                    if not strutils.is_none_empty(refpath):
                        path = refpath
                        if memberkeys.REFER_MODULE_NAME in data:
                            ref_modname = data[memberkeys.REFER_MODULE_NAME]
                        else:
                            logger.error('could not find refmodule of modname %s,ref path %s in code file %s',
                                         mod_name, path, mdloader.path)
                    self._childs.append(
                        ReferMember(
                            childname,
                            attr_mod_path,
                            data[memberkeys.OBJTYPE_KEY_NAME],
                            node,
                            [],
                            ref_modname,
                            path
                        )
                    )
            else:
                data = mdloader.find_child(name)
                if data is None:
                    logger.error(
                        'could not find name %s in module %s', name, mod_name)
                    continue
                name = node_utils.get_alias_name(alias)
                attr_mod_path = self.expand_mod_path([name])
                node = mdloader.build_simple_node(data, module)
                self._childs.append(
                    ReferMember(
                        name,
                        attr_mod_path,
                        data[memberkeys.OBJTYPE_KEY_NAME],
                        node,
                        [],
                        mod_name,
                        mdloader.path
                    )
                )

    def visit_assign(self, node):
        targets = node.targets
        for target in targets:
            # 连等表达式
            if isinstance(target, nodes.Tuple):
                elts = target.elts
                for elt in elts:
                    if isinstance(elt, nodes.AssignName):
                        name = elt.name
                        if isinstance(node.value, nodes.Tuple):
                            if ScopeFinder.is_module_range(node):
                                attr_mod_path = self.expand_mod_path([name])
                                self._childs.append(
                                    Member(name, attr_mod_path, objtypes.MODULE_ATTRIBUTE, node))
                            elif self.is_class_range(node):
                                parent_class_node = ScopeFinder.get_parent_class_node(node)
                                class_member = self.find_member_by_node(parent_class_node)
                                classattr_mod_path = self.expand_mod_path(
                                    [parent_class_node.name, name])
                                class_attr_member = Member(
                                    name,
                                    classattr_mod_path,
                                    objtypes.CLASS_ATTRIBUTE,
                                    node
                                )
                                class_member.childs.append(class_attr_member)
            elif isinstance(target, nodes.AssignName):
                name = target.name
                if ScopeFinder.is_module_range(node):
                    attr_mod_path = self.expand_mod_path([name])
                    self._childs.append(
                        Member(name, attr_mod_path, objtypes.MODULE_ATTRIBUTE, node))
                elif self.is_class_range(node):
                    parent_class_node = ScopeFinder.get_parent_class_node(node)
                    class_member = self.find_member_by_node(parent_class_node)
                    if class_member is None:
                        logger.warning(
                            'assign class node %s is not in module range',
                            parent_class_node
                        )
                        continue
                    classattr_mod_path = self.expand_mod_path(
                        [parent_class_node.name, name])
                    class_attr_member = Member(
                        name,
                        classattr_mod_path,
                        objtypes.CLASS_ATTRIBUTE,
                        node
                    )
                    class_member.childs.append(class_attr_member)
            elif isinstance(target, nodes.AssignAttr):
                if not (isinstance(node.parent, nodes.FunctionDef) and node.parent.name == CLASS_INIT_METHOD):
                    return
                # 如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
                if isinstance(target.expr, nodes.Name) and target.expr.name == "self" \
                        and isinstance(node.parent.parent, nodes.ClassDef):
                    name = target.attrname
                    class_member = self.find_member_by_node(node.parent.parent)
                    if class_member is None:
                        logger.warning(
                            'assignattr parent class node %s is not in module range',
                            node.parent.parent
                        )
                        continue
                    classattr_mod_path = self.expand_mod_path([node.parent.parent.name, name])
                    class_attr_member = Member(
                        name,
                        classattr_mod_path,
                        objtypes.OBJECT_PROPERTY,
                        target
                    )
                    class_member.childs.append(class_attr_member)

    def visit_classdef(self, node):
        if not ScopeFinder.is_module_range(node):
            return
        if self.is_support_mro_class(node):
            bases = self.get_class_bases(node)
            node.bases = bases
        else:
            node.bases = []
        class_mod_path = self.expand_mod_path([node.name])
        self._childs.append(Member(node.name, class_mod_path, objtypes.CLASS_DEF, node, []))

    def find_node_import_modname(self, module, nodename):
        node_names = nodename.split(".")
        names_len = len(node_names)
        if names_len > 1:
            for i in range(1, names_len):
                name = ".".join(node_names[0:i])
                import_modname = self.find_import_modname(module, name)
                if import_modname is not None:
                    return import_modname
        else:
            name = node_names[0]
            import_modname = self.find_import_modname(module, name)
            return import_modname
        return None

    def get_class_bases(self, node):
        base_names = []
        bases = node.bases
        for base in bases:
            infer_base = node_utils.safe_infer(base)
            modname = None
            if infer_base is None or infer_base is astroid.Uninferable:
                basename = base.as_string()
                import_modname = self.find_node_import_modname(node.root(), basename)
                if import_modname is not None:
                    if basename.startswith(import_modname):
                        modname = self.modname_to_path(
                            import_modname, basename.replace(import_modname, "").lstrip("."))
                    else:
                        names = basename.split(".")
                        modname = self.modname_to_path(import_modname, names[1:])
            else:
                base_module = infer_base.root()
                file = base_module.file
                if file is not None and base_module.name != '':
                    try:
                        modpath = self.analyzer.get_relative_path(file)
                        if modpath is not None:
                            modname = self.modname_to_path(
                                modpath, infer_base.name)
                    except OutofPythonPathError:
                        logger.error("parse base file %s mros error", file)
                elif file is None:
                    modname = base_module.name + "." + infer_base.name
            if modname not in base_names and modname is not None:
                base_names.append(modname)
        return base_names

    def visit_try(self, node):
        if not ScopeFinder.is_module_range(node):
            return
        for orelse in node.orelse:
            self.visit_child(orelse)
        for handler in node.handlers:
            self.visit_child(handler)

    def visit_if(self, node):
        if node_utils.is_main_statement(node) or not ScopeFinder.is_module_range(node):
            return

        for orelse in node.orelse:
            if isinstance(orelse, nodes.If):
                for child in orelse.body:
                    self.visit_child(child)
            else:
                self.visit_child(orelse)

    def get_doc(self):
        return node_utils.get_node_doc(self._module)

    def visit_annassign(self, node):
        target = node.target
        if isinstance(target, nodes.AssignName):
            name = target.name
            if ScopeFinder.is_module_range(node):
                attr_mod_path = self.expand_mod_path([name])
                self._childs.append(
                    Member(name, attr_mod_path, objtypes.MODULE_ATTRIBUTE, node))
            elif self.is_class_range(node):
                parent_class_node = ScopeFinder.get_parent_class_node(node)
                classattr_mod_path = self.expand_mod_path(
                    [parent_class_node.name, name])
                self._childs.append(
                    Member(name, classattr_mod_path, objtypes.CLASS_ATTRIBUTE, node))

        elif isinstance(target, nodes.AssignAttr):
            pnode = node.parent
            if not (
                isinstance(
                    pnode, nodes.FunctionDef) and pnode.name == CLASS_INIT_METHOD
            ):
                return
            # 如果函数中出现self.xx=yy类似这样的赋值表达式,则应该属于类的属性
            if isinstance(target.expr, nodes.Name) and target.expr.name == "self" \
                    and isinstance(pnode.parent, nodes.ClassDef):
                name = target.attrname
                classattr_mod_path = self.expand_mod_path(
                    [pnode.parent.name, name])
                self._childs.append(
                    Member(name, classattr_mod_path, objtypes.CLASS_ATTRIBUTE, target))

    def _check_astroid_module(
        self,
        node: nodes.Module,
        walker: ASTWalker,
        #  rawcheckers: list[checkers.BaseRawFileChecker],
        # tokencheckers: list[checkers.BaseTokenChecker],
    ) -> bool | None:
        """
        Check given AST node with given walker and checkers.
        :param astroid.nodes.Module node: AST node of the module to check
        :param pylint.utils.ast_walker.ASTWalker walker: AST walker
        :param list rawcheckers: List of token checkers to use
        :param list tokencheckers: List of raw checkers to use
        :returns: True if the module was checked, False if ignored,
        None if the module contents could not be parsed
        """
        # generate events to astroid checkers
        walker.walk(node)
        return True

    @contextlib.contextmanager
    def _astroid_module_visitor(
        self,
    ) -> Iterator[Callable[[nodes.Module], bool | None]]:
        """
        Context manager for checking ASTs.
        The value in the context is callable accepting AST as its only argument.
        """

        _visitors = self.prepare_visitors()
        if not _visitors:
            raise RuntimeError('empty node visitors')
        # notify global begin
        for visitor in _visitors:
            self.walker.add_visitor(visitor)

        yield functools.partial(
            self._check_astroid_module,
            walker=self.walker
        )

    def _parse_file(
        self,
        get_ast: GetAstProtocol,
        check_astroid_module: Callable[[nodes.Module], bool | None],
        file: ModuleItem,
    ) -> None:
        try:
            # get the module representation
            ast_node = get_ast(file.filepath, file.name)
        except Exception as ex:
            logger.error('parse file %s modname %s ast error:%s',
                         file.filepath, file.name, str(ex))
            return
        self._module = ast_node
        self._childs = []
        if ast_node is None:
            return
        if self.skip_import_statements():
            logger.debug('skip analyze code file %s import statements', file.filepath)
        else:
            logger.debug('force analyze code file %s import statements', file.filepath)
        check_astroid_module(ast_node)
