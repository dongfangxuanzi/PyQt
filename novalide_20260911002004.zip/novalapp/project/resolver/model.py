# -*- coding: utf-8 -*-
'''
-------------------------------------------------------------------------------
Name:        model.py
Purpose:
Author:      wukan
Created:     2019-02-15
Copyright:   (c) wukan 2019
Licence:     GPL-3.0
-------------------------------------------------------------------------------
'''
import copy
import os
import os.path
from . import xmlutils
from .const import PROJECT_NAMESPACE_URL, PROJECT_VERSION_191025
from ...util import fileutils, strutils
# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------
# Always add new versions, never edit the version number
# This allows you to upgrade the file by checking the version number

# ----------------------------------------------------------------------------
# Classes
# ----------------------------------------------------------------------------


class ProjectModel:
    __xmlname__ = "project"
    # _properties是12版本出现的元素,后面的版本去掉这个元素了
    __xmlexclude__ = ('fileName', '_projectDir', '_getDocCallback',
                      '_cacheEnabled', '_startupfile', '_properties')
    __xmlattributes__ = ("_homeDir", "version", "name", "id")
    __xmlrename__ = {"_homeDir": "homeDir", "_appInfo": "appInfo"}
    __xmlflattensequence__ = {"_files": ("file",)}
    __xmldefaultnamespace__ = xmlutils.AG_NS_URL
    __xmlattrnamespaces__ = {PROJECT_NAMESPACE_URL: ["version", "_homeDir"]}

    def __init__(self):
        self.__xmlnamespaces__ = {PROJECT_NAMESPACE_URL: xmlutils.AG_NS_URL}
        self.version = PROJECT_VERSION_191025
        self._files = []
        self._projectDir = None  # default for homeDir, set on load
        self._homeDir = None         # user set homeDir for use in calculating relative path
        self._cacheEnabled = 0
        self.name = ''
        self.id = ''
        self._startupfile = None
        self._runinfo = RunInfo(self)

    def __copy__(self):
        clone = Project()
        clone._files = [copy.copy(file) for file in self._files]
        clone._projectDir = self._projectDir
        clone._homeDir = self._homeDir
        clone._appInfo = copy.copy(self._appInfo)
        return clone

    @property
    def runinfo(self):
        return self._runinfo

    @property
    def StartupFile(self):
        return self._startupfile

    @StartupFile.setter
    def StartupFile(self, startupfile):
        if self._startupfile is not None:
            self._startupfile.IsStartup = False
        self._startupfile = startupfile
        if self._startupfile is not None:
            self._startupfile.IsStartup = True
            # 设置启动文件
            self._runinfo.StartupFile = self.GetRelativePath(self._startupfile)

    @property
    def Id(self):
        return self.id

    @Id.setter
    def Id(self, project_id):
        self.id = project_id

    @property
    def Name(self):
        return self.name

    @Name.setter
    def Name(self, name):
        self.name = name

    @property
    def homeDir(self):
        if self._homeDir:
            return self._homeDir
        return self._projectDir

    @property
    def physicalFolders(self):
        physical_folders = []
        for file in self._files:
            physical_folder = file.physicalFolder
            if physical_folder and physical_folder not in physical_folders:
                physical_folders.append(physical_folder)
        return physical_folders

    @property
    def logicalFolders(self):
        folders = []
        for file in self._files:
            if file.logicalFolder and file.logicalFolder not in folders:
                folders.append(file.logicalFolder)
        return folders

    @property
    def projectFiles(self):
        return self._files

    @property
    def filePaths(self):
        return [file.filePath for file in self._files]

    @property
    def isDefaultHomeDir(self):
        return self._homeDir is None

    @homeDir.setter
    def homeDir(self, parentpath):
        self._homeDir = parentpath

    @property
    def cacheEnabled(self):
        return self._cacheEnabled > 0

    @cacheEnabled.setter
    def cacheEnabled(self, enable):
        """
        Only turn this on if your operation assumes files on disk won't change.
        Once your operation is done, turn this back off.
        Nested enables are allowed, only the last disable will disable the cache.
        This bypasses the IsDocumentModificationDateCorrect call because the modification
        date check is too costly, it hits the disk and takes too long.
        """
        if enable:
            if self._cacheEnabled == 0:
                # clear old cache, don't want to accidentally return stale value
                for file in self._files:
                    file.ClearCache()

            self._cacheEnabled += 1
        else:
            self._cacheEnabled -= 1

    def FindFile(self, filepath):
        if filepath:
            for file in self._files:
                if fileutils.ComparePath(file.filePath, filepath):
                    return file
        return None

    def GetRelativePath(self, pj_file):
        if isinstance(pj_file, ProjectFile):
            filepath = pj_file.filePath
        else:
            filepath = pj_file
        return filepath.replace(self.homeDir, "").lstrip(os.sep)

    def find_files(self, dirpath):
        if not os.path.isdir(dirpath):
            return []
        files = []
        for file in self._files:
            if 0 == strutils.case_insensitive_compare(
                os.path.dirname(file.filePath), dirpath
            ):
                files.append(file)
        return files

    def RemoveFile(self, file):
        if file.IsStartup:
            self.StartupFile = None
        self._files.remove(file)

    def AddFile(self, filepath=None, logical_folder=None, type=None, name=None, file=None):
        """
        Usage:
        # used for initial generation of object.
        self.AddFile(filePath, logicalFolder, type, name)
        self.AddFile(file=xyzFile)  # normally used for redo/undo
        Add newly created file object using filePath and logicalFolder or given file object
        """
        if file:
            self._files.append(file)
        else:
            self._files.append(
                ProjectFile(
                    self,
                    fileutils.opj(filepath),
                    logical_folder,
                    type,
                    name,
                    getDocCallback=None
                )
            )

    def GetAppInfo(self):
        return self._appInfo

    def initialize(self):
        for file in self._files:
            file._parentProj = self

    def RelativeToAbsPath(self):
        for file in self._files:
            file.RelativeToAbsPath(self.homeDir)

    def AbsToRelativePath(self):
        for file in self._files:
            file.AbsToRelativePath(self.homeDir)

    def GetRelativeFolders(self):
        relative_folders = []
        for file in self._files:
            rel_folder = file.get_relative_folder(self.homeDir)
            if rel_folder and rel_folder not in relative_folders:
                relative_folders.append(rel_folder)
        return relative_folders

    # ----------------------------------------------------------------------------
    # BaseDocumentMgr methods
    # ----------------------------------------------------------------------------

    def fullPath(self, filename):
        if os.path.isabs(filename):
            abspath = filename
        elif self.homeDir:
            abspath = os.path.join(self.homeDir, filename)
        else:
            abspath = os.path.abspath(filename)
        return os.path.normpath(abspath)

    def documentRefFactory(self, name, fileType, filePath):
        return ProjectFile(
            self,
            filePath=self.fullPath(filePath),
            type=fileType,
            name=name,
            getDocCallback=self._getDocCallback
        )

    def findAllRefs(self):
        return self._files

    def setRefs(self, files):
        self._files = files

    def findRefsByFileType(self, fileType):
        file_list = []
        for file in self._files:
            if fileType == file.type:
                file_list.append(file)
        return file_list

    def SetDocCallback(self, getDocCallback):
        self._getDocCallback = getDocCallback
        for file in self._files:
            file._getDocCallback = getDocCallback


class Project(ProjectModel):
    pass


class ProjectFile:
    __xmlname__ = "file"
    __xmlexclude__ = ('_parentProj', '_getDocCallback', '_docCallbackCacheReturnValue',
                      '_docModelCallbackCacheReturnValue', '_doc', 'isStartup')
    __xmlattributes__ = ["filePath", "logicalFolder", "type", "name"]
    __xmldefaultnamespace__ = xmlutils.AG_NS_URL

    def __init__(
        self,
        parent=None,
        filepath=None,
        logicalFolder=None,
        type=None,
        name=None,
        getDocCallback=None
    ):
        self._parentProj = parent
        self.filePath = filepath
        self.logicalFolder = logicalFolder
        self.type = type
        self.name = name
        self._getDocCallback = getDocCallback
        self._docCallbackCacheReturnValue = None
        self._docModelCallbackCacheReturnValue = None
        self._doc = None
        self.isStartup = False

    @property
    def IsStartup(self):
        # 兼容老版本,老版本file格式为:
        # <noval:file filePath="./flows/meta/annotation.py" logicalFolder="flows/meta"
        # isStartup="false"/>.
        # 老版本的文件统统设置为非启动文件
        if isinstance(self.isStartup, str):
            return False
        return self.isStartup

    @IsStartup.setter
    def IsStartup(self, is_startup):
        self.isStartup = is_startup

    @property
    def document(self):
        if (self._docCallbackCacheReturnValue and (
                self._parentProj.cacheEnabled or self._docCallbackCacheReturnValue.IsDocumentModificationDateCorrect())):
            return self._docModelCallbackCacheReturnValue

        if self._getDocCallback:
            self._docCallbackCacheReturnValue, self._docModelCallbackCacheReturnValue = self._getDocCallback(
                self.filePath)
            return self._docModelCallbackCacheReturnValue

        return None

    @property
    def ideDocument(self):
        # Return the IDE document wrapper that corresponds to the runtime document model
        if (self._docCallbackCacheReturnValue and (
                self._parentProj.cacheEnabled or self._docCallbackCacheReturnValue.IsDocumentModificationDateCorrect())):
            return self._docCallbackCacheReturnValue

        if self._getDocCallback:
            self._docCallbackCacheReturnValue, self._docModelCallbackCacheReturnValue = self._getDocCallback(
                self.filePath)
            return self._docCallbackCacheReturnValue

        return None

    @property
    def physicalFolder(self):
        dir_ = None
        if self.filePath:
            dir_ = os.path.dirname(self.filePath)
            if os.sep != '/':
                dir_ = dir_.replace(os.sep, '/')  # require '/' as delimiter
        return dir_

    @property
    def localServiceCodeFile(self):
        return self._GetDoc().GetModel().localServiceCodeFile

    @property
    def stateful(self):
        return self._GetDoc().GetModel().stateful

    @property
    def processName(self):
        doc = self._GetDoc()
        if doc:
            return doc.GetModel().processName
        return None

    @property
    def localServiceClassName(self):
        return self._GetDoc().GetModel().localServiceClassName

    # ----------------------------------------------------------------------------
    # BaseDocumentMgr methods
    # ----------------------------------------------------------------------------

    @localServiceClassName.setter
    def localServiceClassName(self, classname):
        self._GetDoc().GetModel().localServiceClassName = classname

    @localServiceCodeFile.setter
    def localServiceCodeFile(self, codefile):
        self._GetDoc().GetModel().localServiceCodeFile = codefile

    @property
    def serviceType(self):
        doc = self._GetDoc()
        if not doc:
            return None
        model = doc.GetModel()
        if hasattr(model, 'serviceType'):
            return model.serviceType
        return None

    @stateful.setter
    def stateful(self, stateful):
        self._GetDoc().GetModel().stateful = stateful

    @serviceType.setter
    def serviceType(self, service_type):
        self._GetDoc().GetModel().serviceType = service_type

    def RelativeToAbsPath(self, parentPath):
        """Used to convert path to absolute path (for any necessary disk access)"""
        if self.filePath.startswith("./"):  # relative to project file
            self.filePath = fileutils.opj(os.path.join(
                parentPath, self.filePath))  # also converts '/' to os.sep

    def AbsToRelativePath(self, parentpath):
        """Used to convert path to relative path for saving (disk format)"""
        parentpath_len = len(parentpath)

        if self.filePath.startswith(parentpath + os.sep):
            # convert to relative path
            self.filePath = "." + self.filePath[parentpath_len:]
            if os.sep != '/':
                # always save out with '/' as path separator for cross-platform compatibility.
                self.filePath = self.filePath.replace(os.sep, '/')
        else:
            pass    # not a decendant of project, use absolute path

    def get_relative_folder(self, parentpath):
        parentpath_len = len(parentpath)
        dir_ = None
        if self.filePath:
            dir_ = os.path.dirname(self.filePath)
            if dir_.startswith(parentpath):
                dir_ = dir_[parentpath_len:].lstrip(os.sep)  # convert to relative path
            if os.sep != '/':
                # always save out with '/' as path separator for cross-platform compatibility.
                dir_ = dir_.replace(os.sep, '/')
        return dir_

    def ClearCache(self):
        self._docCallbackCacheReturnValue = None
        self._docModelCallbackCacheReturnValue = None

    def getServiceParameter(self, message, part):
        return self._GetDoc().GetModel().getServiceParameter(message, part)


class RunInfo:
    # RunConfig是12版本出现的元素,后面的版本去掉这个元素了
    __xmlexclude__ = ('_parentProj', 'RunConfig')
    __xmlname__ = "runInfo"
    __xmldefaultnamespace__ = xmlutils.AG_NS_URL

    def __init__(self, parent=None):
        self._parentProj = parent
        self.StartupFile = None
        self.DocumentTemplate = None


# ----------------------------------------------------------------------------
# Old Classes
# ----------------------------------------------------------------------------


# ----------------------------------------------------------------------------
# XML Marshalling Methods
# ----------------------------------------------------------------------------
# 项目xml文件已知节点类型名称列表
# 要想项目文件识别类型,必须添加到这个列表中,否则写入节点信息时会加上objtype="novalapp.project.resolver.model.RunInfo"等类似信息
# 这里是通用项目文件的已知节点类型,Python项目文件的已知节点类型会有增加
KNOWNTYPES = {"%s:project" % PROJECT_NAMESPACE_URL: Project,
              "%s:file" % PROJECT_NAMESPACE_URL: ProjectFile}
