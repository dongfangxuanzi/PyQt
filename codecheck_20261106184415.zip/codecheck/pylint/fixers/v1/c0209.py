'''
Name:        c0209.py
Purpose:
Author:      wukan
Created:     2026-11-05
Copyright:   (c) wukan 2026
Licence:     <your licence>
'''
import logging
from astroid import nodes
from novalapp.python.parser import node_utils
from ....pylint_fix import PylintFixer
log = logging.getLogger(__name__)


class PylintC0209Fixer(PylintFixer):
    '''
    规则说明:使用f_string代替%格式化字符串
    '''

    def __init__(self):
        super().__init__('C0209', self.FixKind.SEMI_AUTOFIX)
        self.max_line_length = 0

    def fix_message(self, msg):
        node = self.find_msg_node(msg, use_column=True)
        if node_utils.is_const_type(node, str) and isinstance(node.parent, nodes.BinOp):
            pnode = node.parent
            if pnode.op == '%':
                right_node = pnode.right
                percent_count = node.value.count('%')
                fix_const_str = self.get_fix_const_str(node)
                fix_text = ''
                if isinstance(right_node, nodes.Name) and percent_count == 1:
                    leftstr = node.value
                    rightstr = right_node.as_string()
                    percent_pos = leftstr.find('%')
                    percent_flag = "%" + leftstr[percent_pos + 1]
                    repnode_text = fix_const_str.replace(percent_flag, "{" + rightstr + "}")
                    fix_text = "f" + repnode_text
                if isinstance(right_node, nodes.Tuple):
                    elts = right_node.elts
                    elt_num = len(elts)
                    if percent_count == elt_num:
                        fix_text = "f"
                        percent_pos = -1
                        elt_index = -1
                        for i, char in enumerate(fix_const_str):
                            skip_char = False
                            if char == '%':
                                percent_pos = i
                                skip_char = True
                                elt_index += 1
                            if percent_pos != -1 and i == percent_pos + 1:
                                skip_char = True
                                fstr = "{" + elts[elt_index].as_string() + "}"
                                fix_text += fstr
                            if not skip_char:
                                fix_text += char
                if fix_text:
                    linetext = self.get_msg_line_text(msg)
                    linetext_length = len(linetext)
                    fix_length = node.col_offset + len(fix_text)
                    log.debug(
                        'text of line %d in filename %s length is %d, fix f-str length is %d,limit length is %d',
                        msg.line,
                        msg.filepath,
                        linetext_length,
                        fix_length,
                        self.max_line_length
                    )
                    if self.fix_only_autofix():
                        if self.max_line_length <= 0:
                            return False
                        if linetext_length < self.max_line_length:
                            return False
                        if fix_length > self.max_line_length:
                            return False
                    self.fix_node_text(pnode, fix_text)
                    return True
        return False
